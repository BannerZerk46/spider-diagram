#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrsvdmy40iWGPheX4G+ZaWMaF6S2JfIzJC483K/3ElJDyABkiBB7OBWkpme2vSo6Rmz+QP9wrzP/El9yRx3ACTA5S6RUd0tM0Vm'
    'BAGHw/24+9nPccdv/6CYc+9oqcTK2+rf//Qb+iF02Vj+/qQaT6hAlRX42aqeTMxXsuOq3u9PvrdIi09RsSFv1d+fdpq6t0zHeyLm'
    'puGpBlTba4q3+l1Rd9pcTeObZ0IzNE+T9bQ7l3X1dwo14mmern7vWZqiOkRRk5eOvP0tG5T+6bd/SKeJvjwjNGj2G/434+6Wz4S3'
    'UgkXeiZkx9ubzoaQXVwmW1ZQi0in4XVdMzaEo+q/P6HCJwINFq638lLNQjupw1Z/IlaOuvj9SZE9+VviyfNfmAJcEnBpuL//haZX'
    'nmd9y2b3+31mz2RMZ5mlSZJE1eEhgaYgbx5QRZIgCZ6F/+H6L0wJ2lHUhRtcAUiq7FQcWdFgmghNQS94mq6iNg4Ufh1dHi+XB/pS'
    'ii+pc7uuZ1qEuVighYnqoLL03NRNBxX9hWbYuagsFnCdvfsSdfclmuMZdXZ5KZsEPCy8jMtR5x6BR09jQM9XAR7AFY+hW6nacuVd'
    '7h38DoWmilhouo7ufEf/AiCgWfl6gWBJeI5suAvT2eI5Qze67KlfKJqg6Az3lcBo9YXK8DwvfI03aJiGGozSMTdqOMIFnpOwLH0G'
    'k85QsWI06rlsoQeO6RvK1aO1qRnxZwGkc82Z6yoxD4aGZ2F+vFzjKWYuA3tYnclw5/owqgdvBKsevCF9oD4lBM2GIEkf6oT/gXfY'
    'd+GyZG9FYApowiJKQy5DNSk2IxIUmZF0JiOkqQzTpBhUwmZYnYYLuGnCYzooSUdFEiqBtwguwxFSvJPsMvxFhMqUngK24mKOk16Z'
    'rodZhTt3NMv7/ieCyGaJnGXpR8xQ4C9wmZkKWKcCOjmuR1iyZnjfgK1s1e1MdVQFWKMJTO6ZUHVXDVjT0fXULQEE5mnGMgONes6R'
    '+CsB/NbfAvVkoouSrgb3wH2gdibo7ndCNwGVe57pAD/KLFXvBZr78ksIsxJwyW+48i9foXWC+C//hfiylb35qqnC4y+/fLGAq6mO'
    'G9A0MFxU9xuhyM7m6y9fM7iq6hL/nvgFFf1CfCN+0RFh/vL1V+K/QotzVOEzEIevo7d/y0aT+ZvrHREfJ4hvjml6xF8xrOn0bPmN'
    '+POCXTDq4le4tWRD1VEJ/oNKgG/DPbUAPiSi+63vqQqU8DOBFslfw2YQBUKhyqiUIqNq8nyuorX5c8C9UNHK3KkOaptakOoclTjm'
    'nkYFs4W8EKOmXA9mOioVUDXFRA0pksLP8WumEYCtimoIJJSEEMyk+Tx4C8pC2BVWVc7Nw6LAYiaGGBTdjNQzZde7LQnrha+Hra4C'
    'RFzO5C80xz1HfzPSVzxnquGn3ZWsmPtvIJAo0joQDPoHv0A+o/8yFPc1aC2JJ3gx0YP/Gq3df0QLnsarjYSls3n6z8nlpCgK2Hh8'
    'OSmZmtPkZTlVVuVUKb6cEi2JMnO1nLTKUIyYWM5AgsWXk+ZokVZjy0nxlEjNrpeTYimOEi/LSc+gdS6+nJRCyyybXE6G5UhhkVhO'
    'WGDyMvHn5YQ14un5zXJeRhot51VJtOzBnN1ZTv6ZFp8ZGtaS/vhicvcXE61WtJb/CDQ9Mw9pVzsBZ/oG1w5iKVAU0P1/XGmKohr/'
    'GZG+5lq6fPxGIOlJ/IO2RQqebHhBxYw2hzpYan4jKN6C9wPRHt0tdPUQvPsrlsPRdSA9vxFz33FgdQsI1F8TUvgbQf96JX9hWpCE'
    '/fVa9p7LASs8DXhmWgbUheI0Y4UjmvmeZxrx8WgGej2NAPyVwPXTGvBXF2ACgFSAZu27nrY4pkNl9vJgiUDhrpqGqcjAVO9i88Em'
    '5gPfbWVniQAmMWzoh47aQXr3MyyFgmTEuV6sAZL8S9gjroPXeCbPN0s8+m/ETna+IDIEVMFLH5UAlkERIpmFjhAnWNwARxamEcKW'
    'pTIskQbVWVfTgeR6JvJIdW7K8x6+L0PdZ+Kppy5NlRi8PD0TXXNmeiaUVVV9p6KpJ1qqr8KTnAMa/jNo54abdlVHC4nmPPvBtKN/'
    'QZAhrVFDqj2A7W+NCEuR3QHmwF/vDBIzFxjUGXFhCbYwDphS19Q1JayGVjgUZRngEPHljwGwd9B6on8fIAJeb5giAi+hJSsKphrA'
    'AEyCsQ5SUT8hYKBPP4TqdlSIiYXghmNfUdAWWiNEqkAuFJdEIhHjEEYhXGsf4opAAuLsVzAOUHHkuYrILhggavzPIMaRxfaQHLaa'
    'EREheYVMmGl//TUBFJ0EisVA8UHh4UzNJJ6qu0ABF3BRF5568M6LimwM3w0J7TzpdLQM8YE84ldXw80YW6hxQwi42/SlWNV1zXI1'
    '93oekm0pSJNJ8LcQxrSuLrxvIZCA89l/xNqgb7jyTlXSYEEbS1C60PsgoI4u2IyuNgN9eWXuVQAC1D5jiV/BHf1jNtbtNyz5oN87'
    'BH6LT7hyiFCaYfleBnhtsO4B3WvGCmjTu7OayUW7u7aJJcElwcLdInwgwb/eX9nHxH2PifleIJ0vq5tBL1tXS3FF5o+pmomNJO0E'
    'xMNfhhwVUZfhxYoe8hoM0jcdifj5StOVC0MIXw6xKYPpwDkDT4XFoLdcr/FDukvQPY/oHqPz2Ur+RviWpTpz0NN/JXSwRQAK1C1e'
    'ugzJqtvrwdJJyQZcXNWRXf/XmMQ4Y86HEDHJrh/NXSDQkigiJDANYZ+ESiKGYYH0x4t5l63E5wotdChXgmEFpPTNML0v3wBdZKBA'
    '5etdYRMno/Dd6IVobs4FiL+gyfUA9zLsBVBFXci+7sUbyWB95LY7rJNeiCUxwaF2ek0cgYKaADFjORos6/FuF2eCDFv5M7ZG7nV4'
    'rnmLZrd9nblTvMfIBorXR344pORc2CtD3iy0cJas7j60QyOuRMcVq+Du/Cp5y2aQ3hShHn2FehfUPMQ0a/QfQtJb0g5gCdfu5h36'
    '/M5lPXR5pupINZxvbhWQx5yJOxN3DIM/iPiXbt2trOsf5iVYwmGrKSR2y3S1QDVzVF32tJ3664VVJaXjrViNYF06cmiSXfAiiWW4'
    'y683dbAjFrqGdQSdfhk6Hb8E74D8/IrW6DlwCFoysiNQwW07wRARngTIEvKBYKQZwAADMAdNUgzgGRTFJySjOKZlBfXOUgip8Irs'
    'rtQbSRdWSQcOVrBE+PP8zmVjJ7sxMwHr9Ukt/4wlM92cb4Clm/58Ba0HaxHION9FnDxgP3FtJ2w/Y5iKGhvUGWNwpcBQvVlleQa0'
    'AdjxK6x3MGtBww90ptDMCvE2xr9v6eyRDhAo0Em5/sCyCWC+5n0Xk/uGinm04OwjXwfG/oW81fRjTJ4l6Mly1HRAUdEEhMaCbBz3'
    '8ALMzAl6VhBB0Ge0Qha8+8bUBvphQHFnywXfRapFwNGCBUuDTgjtxafmPSMG8w+McB8i+wTcGXhFly0XUBomwXigUQdDPBvV16DK'
    'vmfGWDIiE/GandEP4bsjgTWMOrGuQ9geVn1b07hGwqQ+y8SFz2amnNVlEHsEhVr0tfTWNEyMJc/E+fKuNoSBxu6eN1AisBOxyRBg'
    'B5ZZMR3uEudIw6NnIi0iRnfRNchHRIN7vqaZs/fpa2zYAjJn2biiG86OeE8S4e4wVOFgQlCIDO0+XyBHtw9Q+UI6zBkFPf92lhba'
    'QVXOtEGTcbIJ7s4NseTZcmF5MjJAI9Y6l/X5F+CvuxWRJhg6mMAzY8M4+wknRUBlVFJvoTDLQR45Sowm6VMGzufwNuIhF6YXUtLF'
    'T3hF71wG6xVYNp1FToaLFuA/bFHgAAURznY7j0xApBgHixNxLzLOrxJrEtyFbwecIL4KLL9bxWeMPqNdHM7QekZ99lEU+MoNIgaP'
    'A2PJ99LIXfJB5epdlsjct6qSfV1YX8wKviwfmeRiAb7f7fnc7ExGmnM0S/wdOqTvm8uReXIroxNta/H5CdWKpNLxhp0QJ3S8skDX'
    'nPvrmWijNYocBTR2E5CJiaWpswqE3gD9gbDink74T7ip4ev3qiQ9LTR585qunV87OweZm1oZT7M+ohuzN29epEICay5Y/Z5LJEnP'
    'AYhnT9mdtefeXvvzShvy7oKbN47DJK/n48NqwbAeWLHcRZUHaxmUPkAyxJHPnYKSm3iDScQJ7jH/RIWFpntqoHYfw+D916v5nmV8'
    'LRpQgiofT8nnOGlyesjg/rEDFeAqomF8wp6L62N/pniZYeVHbOZhqC3Wb9QSKyuqSF5hwGfBisZUOgCh376drIh7WerYzX3W2x+o'
    '+4l1vraJMJ7LBlh5AWOBdiuoWSrDuoQquyrIxDS8BMr5AuUMhcrnf9iox4Ujb1X3/MZfkb50AScyLmOGYSQt/ozN4tJ71k9Mq39T'
    'C4N/v147SxNOjEAYPjKWYmolUjqT7tgb0+QNs+ehrfRDNpkkSbdG2XtqRqTC+RYgrpqXnXfVXfoD6u74SzjHFx3v1x8L4rwdzTtr'
    'awkWKQaWwH21ONR6fp52F67Vx5U5JqZoIRUrHFoi7BIpvX8BnRfZwueFyqzMLaIw1ws8RJGQxQoZVmHJuEDDOi0dYnQ4IR9mMpGC'
    'eDt/DzTkpA/0dsIe+EGDWU5MUeYcp00OOBG5DjSIs0ORvDFNz5RypyGAfP9MZPAyoeAfLrh26QcWYMZdBWwzEpXUm+yFjMTgVtaM'
    'eItXE48ccRHwUZwKJLXqvuHFi8ykYLAxVx4tkleRO4Hc7X/9eOiWeD9eG9oQj6jgMoAu9kJhD8MjP0oaoyLmKOTFCLkYgmLcbQpQ'
    'pgPPVoyjcOGy4h4/Y0qcOccdOvlMbDoY69nOiVb5NqL7idDlQ90lHKZnmrr7gYB4FPuOjVH85BDfDHQnwLm1qtjIdXQTK7h5OYpS'
    'JV++6De4bj5IrzjP8ZX9H1tINjLir+XgjVZ9bUxzb7gLk5D8x5BjI2mNFO/fnxay7qooqeqxtXh5/Zu6tYCLfAsTE/9KnGWb7HnO'
    'F6xAwuLO1ZWpK+qN5zRq9L535mrOrk018c68ruik0UEngsfYN0LeXZAVc2WtCIkXg6Aze+dFX3+O35r6PSivrMV77Wjb5R3zOMYD'
    'k076yKsRdCQGsvKeT/GqG7zIl2Bw5GrFfAlf/ZoMCiR6iMdoYk2uEjPgXWLND+nxjON8RFzXeVPATRMUx5J3e77rgA1pO67yoom/'
    'eR3Pse3DfWzNxCu1g71mNcEaMo8U2Q8QDXLqv9GjeFba763nw+E+CBuE6VUMTq/iHvuNr0CUr+k/oX/ECceJLfcFB99KO0pSVYKP'
    'LnB2bhI/YkkG7zvu3+89cOGb26RMD128oFKpgQpzcQ2TH9U8HqXCXTS2wMP24xlgV5I+0pN//Tn5aWcQb3K+hGQKDlYxsHPtroz/'
    'nOJy03VSL74TaH9DL44pUN/Dhh4TJOq0p8oODuzfiynTweS+kanEva2WnM3ZjzjiPp5HeZuCFBvLt4U5990Ei78zW7eJA4ijBfm6'
    'W+3wBbR911nOnq+cKTT3l0S0O4E6Cyzj3Tj9vomiIeP6GIZ+SEvECHUX326M1luwM8HF5zJ0L46pa50v5nz5nCMw9H08JunHoN9q'
    'r2TSCfzJqECyEyOQlPed1Wg9ZjIo/vE04aABsFI9P4kWZMzC/1g4JG5hUleMY+loysdVatwvnXQfoBYiTwF/QaKzNgtDcLzAtERV'
    '04AEFjKT0wHrd5Fda6my9wV1mEZp5s8IYlDfvtAciVJEqIXzNZrWuewoCelzMYo/KGkep7qckyxu1J8PGcafi/vFU57ezcq7idde'
    'eBCRobhkzJaKYjt4soK0rufwBjO4dJSz+td3HVb3/BuTL+kw/HonnxP1kgn3BXyekV6ytpKyCa96xlv52xk0KrsWLCrMJ8wFQjoi'
    'C1Tx63v5ST8jN+k2LymwNNnPuQwS40H7U2+tlzfSi2IthPsN7jn66Ds+vjeD4Yx1uJczHcEaj+Mm3Bo3Mv2n+DmCXvH25I/mv/3E'
    'fl1DsyzVu4QhsVaclFVn++tTpsYN1Ff+B5a7SmOAyZ5tNC/Y3hPdBHESXd6idfs1XidtOhpmu5FV+DC0HGKQrCwfuejwoMWLn1+8'
    'SRy/N/5QBscHSt3f4vDR1NYYuI66U2X9LXj5WGrDg8ygGwEZS8S5nxVzj6VGwCRZ617zVqAAXgCNe4svHNJQkSf5c6GOuBgPo1Xh'
    '1OMtmt/CZMYPaAXc/SSJq0jhGdCEVcEk9kUFd8mdX1SGj2sY2M0F72PhH3AcqAM8O03FNT/yrO3eibc91rOAPjfXOcuLhUryfCxe'
    'G+7DvJeREdP2zhkOQTQAMYUHmkaQS6wivn3xsEaFaRykvEyYQH44l+/S8H1f6mVtdCO2Ismde4HJ/9ndepnH+/WiDjOoUSQCcNv3'
    'WkuYVUHiLdqDBvA/X90/THSdO6YLOoHmxJbirUTXc9wEE/8lXpZCkxWPPFKXoALDnYNXfyRbjH4/R+yTiiH5gYSwKACICt/eORWg'
    'savOH/hNHo1TTNIBaiCVaOwDnqLIaxvUIZMtfkyXYJIvGUlfI/kpkjqH9z6bW3FjKyebi0j9c/sCfgTwO3HJ37Lh1vzfsuEhL0gd'
    'RDv2QaMMzsJ4Ip+i0zrQJa7/+9OZkCI6eiJkR5PTATb9/uQ5vvqEdvz/5h63M1NHJ5w8aWndXJpP5zNSnvCOCRb+f/r+2+XMiCeK'
    'fkIHRuBf5/cn5il79zGT4fBzEBZXNWgyqCE9eI7Ovgi7kB42wn+gDnunn/A0i6effpYFajwbTOftzCI5+WBmLwBxBE3t0qJMgfDE'
    '1lKaSlOrNBsvIKidmBgGA0DINEEH1hWBR8DpQpqPFdIZniB1geBzsTJoitxJl1ppuKpy8fs0fXpzUMAOzfcGJcGsESwh6VyaS8AN'
    'ZSuYPk5G04f+BmChDO4qRb3Zr6O+2+8WJhM6hk7T1x3TJCFVpauOybBj5s2O0f5xBx1R9HbfPCERPPov/TZSWLrvvjd/MAx6RbEI'
    'W7kdxb7Z3uFdDBMxXJTYhB8dn8jzZoOub3yaHbDXREbv8LkxNAm/bEZiCPSPDnYQhYwhID8hwwNM6N9YKYJtRaPFwr98hmHDOunY'
    'q1KGFIL2LqVvjmhrvrt8CFhGRvMUoIUU/oewk0pLaWn6Zg/Yyf4RUq9eKJREtLejYgXwC8tOxwvS9FCYJicXmt2xVy8BqsBsMlUR'
    '/wroFyG8+CbQ2FvyAOjwzCjg88QR/xsKHkq8SB507SDOfsWApTgDpuPAbxH/4dJMhkJ/4zMB7JVs8MCf3uYBsmbMzP17E00DHgky'
    'haIyUfvwDyIEKD6vcRqWnETTCYUXSFiCfBOEwPX7LgRQRl6toxgfb5pepYVMnBGDpJLSGakBQgUkjZS7vCwg+mGq7DXmMEkkmH4A'
    '7rRpqR/gZGhSMhysihSTHSD6oJis0nHJQ2UkeB1kDxJALMEnBiRxqJkY4Fi8DLm4kIKJYOLzgMxMCaRyRkSXcVqABzATVUqMv44Y'
    'zZvj3qjHmQkW7zt4TmM8Z894Tsc0LIqP4fl5iXlCXGVIChFaeMFGF2J4ISI2hkvo8xUfXQkExYMsfBN4ZFW9y1VQnqoMQu2MLRwL'
    '/+tMOlYKuEYK+B+0UAKAkxGoa7ZCUYkXODaN2kkD7iWaB+aLG0JNpKN23lAXPjCILSVmRBYdFUcjlBFo3O474DdBjYNJhEuMfQJF'
    'JF+6ByosCb1jQM6IKwavhQR3lISWgnlnJVzvvZVgCB6vLBMtMVxEiABLzQT4EPyKK+r9DtPYIFOVD6AAtI9REXUQXIjogkUPdmwT'
    'ES4SqFBcZedIo6QRD0kzLtI2Eamn315GRdtpH+B7eOigaQAF6Gwa6YCBZAIBDpdp+O9tVUtXZSeN4hLyu7PNEsKQXVE8LCDIVXLF'
    'gwIP/cECk0jSUpwOmIBVCUAPuHyzY7h6d5Yx5UoyGlSktYpV4aymU2gmgbed71HJSkjWf1see2Bgzt9dbIlgV2kJ6wFklUNjBa0a'
    'rt/T2lUHGfHvj5Ld8TFFCAnJIUIgmGKKf09Rnm8+IBmRpkwBJYc6+mPzSdWtT2uiAUe9WCIZEtQ4GXhYuAhcRgQknSORDIXoL+bO'
    'AqLTN6HxHNldfYQFAPrDGvGgt1+ZWcKVHOQRXxiyV9KQvRZvmJqpHR+w6B3/nsRQ36ccSpqzwAO4NAixtOAC/aDf+3Y0FRnS3AOD'
    'nos/f2xVeI62ed8aBvSrXpYLK4YM4iFIOFyRHo8GQl8j5W/oLMnwfFzVwXAA7yLmuuy6vz85oDx+x869eCk+GSYshyehkxbBPati'
    'Ez6sF55Ui9xcvz/ldJ04mr5DhGc+ujAO5KE5173rffnNd9XwWNs/hw4CDD3A/Fs26PgMB95OjaAIzxk6d10I47ALTUdNZlHFcFRZ'
    'GNanBthS9+d24ToazdN3uLmBKP5iG2uS4ZvohpDR0Tn4sGAEGPGl4Dl6qv2V+Nt/+78IE+bJkZcE2idlGp6Jj1IKfMVP39Hbf/tv'
    '//PN7nry7jIB6CZsv/f16Tu6ffflnJt8HWCQCRQGiQHbW2kL79wkIbs3UD2Y4ODIILQWj+efOIcf7q9EeMJyE2pFqCO7lmn5Vog8'
    'QaF6gNVWVCVKSz4PKjjR1CVAfOLZ3a9MGNh5PcPmiSSSEsi78QFMjZwgD5EVjRbjanwUYTdbfBM0H72QnKDIC/10eXynAh7p0/eG'
    'DHTnxaY6rB54bcMXQmEUTk5XTcuOg874wlMTAolzYdBGt7ms60dCXniAu9A2ISvKM4Hyv1E+6E59PqcCYzxWddUD5CBm/myGCRAf'
    '4xWeYI37nZmHJzwbbg56ePpOoB8AXzn+lsVQJuC2EoNEroSn73VVtdywB5dASeAAIMYygGyOcgn2GoCjGXg8WE/EkG+B6+GTcTO/'
    'Za03J/PCCs9V4thYCEfcBJP7Qjll0JMQNM6RwNtfgNplQjH3BiInzXMJdBnNC658ruZeo8wbnQJvvdflDFZwvnomQEvcoWATCqkG'
    'h/oGAQ837DOop36kxxKmpnh/A2Nx3ePT96AaAWhyr80rVLy+/VE87yG3/qfQPB/ii7eSPWKFWFg0FUDhcAMDe4a6aG8DgcYTZvrA'
    'KqGtCis0rfrxbYQubS2YD6IKpjE+ifY89/cw+w1QS/J8FUL3i4tDJyBKF4C9bsCZXXOBznN2PWjAM/dgwbsYwVRDcd+GsAyNAITo'
    'J2wXRo+P77vgxS2oHyCP4KVojn8Lt7bgPkeIq0dDq5p75EZQz+S7VL3onGoUBMchJzcQg4EIwlrb999MC80ksZN1H5oxgGMhIFr4'
    '97ds8PS6Fjobwgf23sS/j2ohcJ6+j+DfRzXMxQK6MjFs6ESlS71sMNDvd2btPCkNGMDVlOCii8piGgY8AvaJg1U3g537zg4M3e8F'
    '/PsISFAiZYR0iDaCqw+BeUtDn2SG3cjvGI6mou0CQYK525nGQvdkhHXoowoBa/4B1TBydUYCl+gmG/8AH3ogWrpqRBV3RgC84G//'
    '9M+Ehb7OEEEfFzgLx9wGp6+bVoYYGIpJACEGTSG2GTWNYudJEfSHuSJeo0Apvh4UgaKoAfkD23YBH1p4qKFqnJQxiFsM8H7os06C'
    'y7DiFGyUvszuW6w9ruz9Ab0PZIvpeAmFKTy670fUwKA19NENZDwgDz/SWeSA8YT8HsszVOvvrAuqtyP7yargCx7gl06r8vWHiDxg'
    'FT20nTXBvNCBF9dT6qg4qg7IdcO9qKfv1P/3fz/iWvRTuA1SVb7Tj6sxT9+Zx0/BTGbjTz/ClQshMcaHZhnLPjq+4mYMwPZBiuAz'
    'HeHyERh6wH4bSd6brIPPxfhehH9/kDvfURvekvhoSJeMXhD9sbtYEs+HpX6CxyyDonuMxLSOMflmHQlAQ6S8zHXNCmIO31HxhZfc'
    'Uv0txUftIXO0FNqh0G7cEP07qZvtgDkQX6LvSXz9mDwpYU0ZWwLAdVBaFtYvZ74OdlKQfO9iH0CkKYIuNEebzZCLBlmsGeLFmOs+'
    'Uv0u59xFIulH7JgYuoccr7y9THUgK8J5HoGEO39JA3Qy5McAuYeKn4mKaS7BhC6acxeryw1t5qjtxUKbq1ddQqdXNGDOD6Bwodaz'
    'iXa+oM91HL4+VOcURITOBttUXzJb5WFN7wCo3tGR+Ma8/UsGSi61kzMSkd8fVYoeUsZbNp11DFErSS3h0nySYs5NvUU4gR8nIp+w'
    'ozsepg+zn8gNd+ho8y4e9mN2FFZ7InAx8PwIvUEKW9rc88EMMBdxP8QHnQLn1gPlBk8itpCwz2cre4jsIqLCCBvQICJKmOQ4FoJK'
    'gHDzDQ3tg8rNA68p9tzf85r2fbABNFlHG3Bkx0DHqyMEQPpF8kNjz2AoqBYxO+LfH/GtIhgeqihxaAN5eBfc3l5DAnGmensVOENg'
    '8aKZRTIOrGZkVX0aMpyOch+y81RfLv6I97qAzjm/eKwVBXmtMGMlQhdspJgE/PtLX559/YER4Zyms6WSxz287ZDVZkCSyyRooTvJ'
    'QNzsGjzkN/5SQhmXfxy+sPM3AURuryvoTADIibm9MIiae/Gw/kGwmlHLbwJWdlT1akUXUJRe6KaM/L+h04H4gjyVpg+XaeCuYN0E'
    '+frYhUig3Qzo2LgVeiGa4z8+sQi2N4EvYtfpfVILniVXPRwLIjjk+4l0gmcidHGfK+KvCX4JmviRcQTBvQ9xi8hHmXRQYkwISQtz'
    'W4SwAfgYWj/wKmpeGGnIfkUMPGjpQxGGN6h8gDMy780pts+DDqc/Mi041/NDs9JVH8GAniTCKz8ECc7+/Bg315SLNoBuCB3HC74R'
    'UQTgyn/9ywWxgPfInn58xhgHlLK5uEiwCxtofqkiNvD0vY+d+W8RquZdUATWPYo5AG64cwdJk2BSSJgOeP53lQOtID0xCvOZocoQ'
    'Ym1AZEhDR15S4HFIn3yOdBW0CRWdkAK/iMrcEOwf5sVBquSZZ2Bg3prIRR7nZtxDLfQkBCf/I6DgrI+PINXiJUzNuAdF8CyE4+VH'
    '4AgTPz4ESQ99OwAl4txVV4KHoUGAAUoDQLm//fd/fnuKteXyUZvBs3iTv6MmU7fh6ovVteitZEu9CksQLi6M6ZtJgwYa9RFxoFqP'
    'jB5L03WwejQUh7lfA6nh3/Pm4dYQuqoY7BpF9mtw8dDOUpGhhQ88NQ39eN3utWmVmIayFgsshbOwwEN4ZxIWb4wQb8sB0wb9PARa'
    'M97z0uC9smCiop93BxVHlq7qqhfWVkB6fJyR/HK2RpCC9x3X/oSEC/xv++AjmDGDEceHQrPpoh+E4blPy0wNNKeEFgXM0FHxsVxX'
    'Y4ksNsQeUYB1DmqqrLtmYHmFFDH8GiQ4oI/3Gj9iEgSp2Gem2Ak6vZcTEUMvDfktz6MI3yHQXqMb514P8GUrP8ap5nsBpAYKuzvL'
    'h1Qyhgrj9FWVN7BI66oosv5IZUDPoqn/gek8vGde/YCbvoHTWEMI0c1dVRWF9IwjEdgKcVUcJb+gF7CmugL9QkeJMFitnZuO8WOy'
    'FKfWnrEGAfWmSoJCcj+cXoLCds8EjkUGzgWgk/nGUF33hizDcOYPjEZNjEb9ewco9POE/F3CE+c++oguMEM21A/53WAuwTgOzgoE'
    'roIin0HUNO6AO29KPqcKPHbF4aZ2kfA4L2ogSuKzrF9vD2BQ3uv9SY+nPVYZ5uF83wcl2NZ+sf+C258GTLTtGXWDNP/j7088wX4W'
    'RhM51S4wBrd/TxjJDEkRbJRMGQf0xxAnTCJ4hDg5TM8fwRy0ATlmQoSc4F8LeVQjJr8RJEGgAfkz5L18vMSp0TZdkIpfFjgKquOP'
    '+0b5JGHqkGlE7PvrTxoOfdmtGTaFtb7gOUvwelpIszvx9MlB4yOXHg0bBbp+AvjieTXug08D9D8E/AxkYhJ2ECMeOht4FSX1/AzY'
    'PzP1nx/hj9Eg3lP0mAb7kSD9CBkin93FvYFufiY3wvvIE0dIUJ9cZgPp/nqMUeDbfyUugVWU+Gz9FBJ5a7p+nHO/kX+EVIjAqZ7M'
    'QAocWTiIhhNBLy5IzNnQR2V104Qh5yxLPyLdNMgJnt110N/vN2nt5bFPLPDNBysd9nDHzHvUYgNj/TkA62g4mdZdoRyLIPRmhoNB'
    '3PqZUDPLDPHv0KG0v+5NZwP6JfDy4P7Wyx2p2F+RvQJtPQj63UIVuaavvdEhGD/PuUyETet3tPUPJ3GdwY7ynD4TxrtcxIOYeDNB'
    'YOHjK3Rmk+X9/hTm9D9n1q5pPKNPkWtz/G2QLCq4KMuP29O2y2ST2NrN/uPl3eCkC7Rd46yaB2cnXDTxOMlER6NGTtAV9QPGBjr1'
    '4hISSsQegRFDk0HbwZAiiILzRJ/CIbrhXew4b5SHj49PxXjkPp9zQJHFhF2fgJHQ7hciS3x9wgnoc3NrIYwIcjAJ11J1HYeOIxMs'
    'hCRm+WNQzJgugG7OqYZJy9xR5zgrpot/gQ0E37p+6DrCO02+t+DfB4Z8nHIQIH3Tdy6CHYdr07NjGodvvTDcG2Qke6qMvezIj4J5'
    'VxCAQjQLeIVdK4r5R0O9RBRivjL9r6AuHWQ07Vc7WAxCDcov7noEOPpCBDJzFxGsyMmlytg9/vRHcS+E5G1wy8GJoxeH2Mo0XbTH'
    'QwNci44jRTneAU4GTPKPbE0K97lfYntBH29D+e6eIKyWRwfvn3cIBTuAcI3bDTdXXeD9Sg9yP3pIPw5Tqn9WVDa2J+ptwP4tZRFc'
    'gVbQTfcBaJFAj+9kI76U3PnXn+Z2S4awrhC6g07Uekow9kWE6iHzv//+S/Cll+SrWlQY9+D8MfL80/28p2s4+jhKkNiKd7UIYcW8'
    'Z9zg7/fw2durGFZqPYizFk3jF5T3uyHkpXxtFvz05evhA4yTsx8cavz0YMEqjqYk66OTA8+1o5/olS0ew+UeHzMXnl4F40JF0fbB'
    '34JbUA513N4yKkHHOeryMSyLlvM3FNEBVikHOcr4m1wRxtyRvknp3gfBH2WqAK9CTUfNxTQqrJ1dvmn2Vutb+aCrxhKfrYJ21CZ6'
    'wyrsRQnFHSbmFeVWnif1nDz5dAeBoGbfXC5jEq+Hcq9ASKzQVpXomIxAD5/73o/IjPNZGxe9KmrtCrWDbNrNTPnel2e/ZdEF2nR3'
    'tkxiZHSpikPOscpulMdzXRsv0o1lYOIdfcT/+/8QQWvuPGwL8Giu6u75SZg9GOst2qPzADDQ6MOKwd7AB9WCxI+o02hHYZYIXO5v'
    'j/0Sc49ACuLmdyv/7Z/+x9/+6f/42z/9n3/7p38Oq+OASqDFgUZ3+14HR7OiINZl60CwRylQYm/fKuKohhm0/uUyeUGn32CFDJRy'
    'iIjlK5reMEKGgyRBiCTKpHLUtOx58r3xFx+ETuSb4AuyBjEQOT0EIYXiLl+JWIeXOI0exnC2d7qMI44cGoBo71KoggfSGxkBuO3A'
    'akU5HG82FM/AQhAl0vECheg6J+tbmN4V+SfRJLpzB3AHtXAyQZvC0yovY4nu6BF0foHmliHjD5/d49TnDwVexO95G3rwLCHp4iwm'
    'eFwxb8VbsNsGHch8N7M3eLEBfx1ktWMcT3pOoh/ZRbwKvRMeuBXyVcyZ8CqE2S1JNhn7atlFXIaoG3x47HoqwhFcvp3x9IO6RDLb'
    '5TKXl4+LPdYacJ03dDf8KGAEfzQp5yOiPzEn+OtedyxTI4+2il2C0rKDVEprFW37+9PdrAcLbT1E3qRHRumKfvpeDTKbH1Zhnr73'
    '/Nnqqtb9Di/fOXr6/op+HiacODjTWrlKkbhvEWO343yLQq1mLO/275imdNtzdIjMv0xy0m3/sYNmLkmIQUkIxeAHMxHDZj8KSHDg'
    'SH8FLHG5ipmIqNQLSz8PR3iMyYdXw3BVxxsY4UFODXyK1DkfCG+QQQc94cRr0AQCzQNdo+30eCfNj6UFQDefA7F9B8CWv52hQgzi'
    'D4JxPsLqfUvVSGRYhEk5gbPqLIMxAtX/cKrE+0isx2EJ81Fw2Y+g7gf6xhPwEhzIGJEuXphzGuajDKRIZ0OaDPFDdt/95KNrjT3G'
    '4/soH/QSVsHZoY9Y+9N3/Bz7de6z2AABsRGMxouTTd9h3zhcgjAERdtA6j/eHg9qdlAzOAo7OFj8ndZBiccdhI76NzbfQ03cQVgz'
    '6OONynhs5+p3RvqeXAnmqmo62gnUaFnv+rGFKAZntP1o+k10xNtHicTBVFEOD2tLpAPGEwA/DUfiELiPeSTO3957Im4+3hnkNsUt'
    '76Dk+kOcb+VF74MglUtsfbQ9NvBg6yAIMkTScLrkTCPtPsibxrYCTp3OvKlmog/9PQWGXsLwQJsJ8LZEbLuC2UosTTXYYR+F4s4O'
    'yrcDO7ifl+3yTiRm6+uehvzel5AMVrbPuveffvuHdJroQ2dLH8qRkeE7xJfQXe5mAy9vOoQkjZ5GkSMYSLgrn2Cwk/frMx4R3tYD'
    'BQ4IQMc38Dyd8zaQh8hCXxYg0umE5u/53l29P3L7hximazt8JLqOs1yvJhzaCLX6i0YOZQWwnmK2TSJcfz7g6b6ujt5+rKk3VDk8'
    'MOIcEPkSsXLAFuy2huU9D/7fhx+K+Emq/F2kQ3OAY2i/adEI8vg2q8VeWDHRw7OxsmKSpiQ8Ck3CGyvT94o4a+hsSn6WFeDNl2fJ'
    'FLo4wuV5NChD3j19v1qbPE6OQf9eJuWN5U1gRengOfJdixcetvDQ0b+3NmtEQGCwa1ZEjbcB1MAe950iMKSn73/9E/EU8r5vxFOS'
    'qp6e4WFISvCUQbdueOwX3KPPaTypW2uFvjn3hL7s5avPqEzHR7FAc+EpK7gQZ7pCWXiADC5D4Ui8fyZ4+U/Ef0VdoA15LwrqkEW3'
    'YUQz6pAML4gnDdUhn/E1zpqH1inEs4K4DPJwPAVPD5eKx8tluH//G2GAZhwUbUAJxkAib3BQhL+ygMr+TM9ohaXD4iD4eW4rsLuh'
    '1n/ySZKZr+jvIySrt9jzkoz2BjWyUCW4slBCjhumSuCoFdzJmN+hcK6me8H+uShsqXkgsxfPBGhksaAmIm9Xxe+60O2lMIhyZsJe'
    'rbBTXw8vdO18whDuRSaC8tl3xA0JxFbCV2ffo+O/ggTi4MAnPPBvxCUbAr2Bt6CFGhwqi+2rAwPXdc99XLwI504iSAGwM4R97K1C'
    '4cboxQWSBpeNUpe3w8UPZ0xDxx6pzwgIA8QYWoyoBfoyLHmG1O3QyzaXHeeIBEXg24qqn4+keRPQ0sFSHW2LD0t0VFU/fksOdXrp'
    'FO11w8I6WMBgD1hUuax5l5rRvq0wLBxbdBx5uYEjC4v7hL7vgmmMStILlaQXZPuB6uCePYMxiknTGVaiBYFmaJbjKJonOTVNsRc6'
    'SlMclyEpimEoUmBIXrqiK/KaglSSoRjqQxRkxhC0EKonF1/q2TF6bxE6CRSDEV6m8toNChSK5hFF2tHhe4C10WtJpIxeRLsso/3C'
    '9ztHsYAQ35KoftvgQjM0d5U514jFAS71sLB2Y+d23S73eaqAk4RBB/m8FzTpQsYn2AXyH8QDRrvruAUM6wKzO79AEoYtLpzkgmN0'
    'EsfoJI4lvPZ440voe4/hGkMKGZHnKYoUKUmgKeaCZQyT4UhSYkRKkCSGJ5l3sUzkJHJ+hWXUXSyLs8Fo0AjcGG+IYd02YBO/JjYH'
    'EyGXN68XUkm0g951oxMEZbS3S72HPkUcDon6jBpEIYwYSGFo4QJR4M6/194I8cGomfOpkJe2gM99iU7qROleoCrH+AtgyvHTp0Ei'
    'QsLJBjD+JeZS0XCihARvbwY7VtzQ3xIctYeNo3e4GZPENCaJaXhrNM7HVlRP1vQEM+MyEilQPMszrMSJvBhDMYqnM8C/SBb4HE0D'
    'oxPew7EFKc5J8grH6Ls4ZiUPiUQT9YuDBSeB8gsx/zHiEjRarlTrsk74+4rPQZ4l2lh1rvS3//7PidW8iVJhCr8jdbMxmTnCukds'
    '3zHePA44/YytTlCQkGeOYC8oHuEMOrzt6tzNCzioFTdwFCGQtegAQnRYJOD/EShnFmMn5zkOo8qRUhguPZtceja59NXAQgODSsPn'
    'JF92wP80JGA+hATkGWAuCTB3i6vnRQKlzUNfxQtOMPsXhpg6Q8wnIeaTENdvY/ZxQEU2AwBxlMQxrMBxfFxPgEeiJLCgKfCgT3A8'
    '/R598bwskosrQJm79IW9HiGz8PAXzMJr51wIcvFv/+1/hpgGt+dyrCpcl2fPb2YT7eHPol23rXxPHHOSvXC7i54QNaZcXoppJ/BO'
    'UuZfV7/AE++2FJfzb/RQwyIHayVxOf9MlGnEGXqIq3+y61aoiiAB8AEI7uk1H+socFy+0XSiwkdbbZq7+Lkf2tnCuddDsOtlox7d'
    'T/aCueL5JI43erjixh9cAkQD7zX6I1OOg4dZIojCvddBHmoGkb7P9hJs8s8Gwizc7v9eb79HvaU/2Rs+liSLDhs13+tjGvURnh3y'
    'yZ7w+V8wquA09/c66yU7632yM5TE+l4X7c9yleDsyWgXevZ8Vt27uJYcS+mz1KJ5l5NK3uuL/EDj2Ti7zsZlBPK3qDFdPZRlMV0r'
    '9LgF2m3wHfY0+nR15PgI7PDzUS0mOot4v0KeG6R4IKXunpEkJIWrkBSuNHJcNeUNVufRHhdiaZpKTMDyGQaEKjKRkCUuscy1LU4y'
    'QkYCy4flKEqSWFH8iV6uj1tP4ckJ0YkKl1l1wmOAz7IyQ+Azue+ei7M0Q/cLmuTwaOKkhySugF4dVXzpEx8VHLNncAwjOmb4nrkU'
    'tX573Pi50WiLRfDlrsBlhN2c2OcVHhONxWOQIB+i0RXcMcMQrK4HPi/C9Y0syruOUNLFid2qey+l+x3DSUxin5jEPnx+SlydE0Bh'
    '4xieZSgBVE5aYK+xjRKYDPsGtgkf8/2c4ZOS8ElJ+NAJLAllk0Yf2hE4iiQ5kRQZJgGaJGV4mhQFlhd4jhOvHQbiZ9xSwSEyUAsf'
    'BXPxql25oakrP3TePMThFaQMS5E8K7IixQmCJMThpQUxw4ksI1I0I0i88EPgUlfgonNpLtBeOwGvvIDhkTQxiEU6Q4okTbEUSwok'
    'I0kJgEU+wwsMxwgMLwoC92MQ01cQRwfkXKC+citRV36l8xk5MbhpWsjwIksLDMuKjEDRSaSVRMAMhqclAJ0S2B+Cm7mCG4NzAfrK'
    'Q0FduygAjVzi32GFJwY3JZEZWHoOrCiaZAVWiJtPIitlYDw0z0s02IG08C6t3fWAXWC8MqWpK1s6OKbhAhxLSRlKoESECGCLcglk'
    'IGkRjFCBZimOYUSWvaY2ivkQdCH94G3RKBCFQbhAfGVLU1fGND5VKO5ORE5DihMBalaCvyIXA1kAehNpZDBLHA/2s/hjEFNJiIPz'
    'jS4QX9nSFH/NINC3MQI1G9BhFpyIFRP3ZIZlAVE5mqFFBkguNgDgIxkgPxFsaZJkJeYHBxCSE073u0TviCilL16Ec1bhjcvwrrQZ'
    'Srhm2EFiQpwJUhyVgQHBqkjAu1mai9MmLFUGODnwE57ieEqS3sPxtzxw2nYZgQewO2gsTyj/4luQf7C21OWvM9lVefY5K62zbC73'
    '2ttMa91lLp97zcEd/OaKWXZZnfQGreKYyvf65LTWLw3gWQkqVF9y+M/rPpfLezOjexxslMJLeTUdabkqtAfvl4IqufxqwrT2uY/8'
    'gb4lb4J/of9+4zX3E/7om+m4tUZXIvqn0D2OyrqMACtj8LpGdF8P7rXovhPcM0o1T6KrQXB/HJZrRXQ1xe2tjKt77ep+Pa/W8PsY'
    'iOLBm1WH6wt8eJ6a0xE3HOBZWqJ/5rlqMzdY5qu5Um0yGprLqPaMh6kvrinU0iaY72ietS3Ml8cOUE8yGsNL9KjQQ+93VvCP50qJ'
    '9hLzPc6v5tvSZTHgzekWnnfqBly3RlBUklCxNbvAn397PIVcMJ7SPDfb53e5Cvzm8joq773m/VylmWssYdDFl1wzlzvkirMsvc/D'
    '/A2KeYRs+0EJfsv510Elv9+/5Pfzan4vNgr7TbP0KvZKq1Kn1C31y6v9uHR4lcvdUrdSKE0qK1KpHsRF6TDXaoUXtZbfq9WDELT9'
    'OoD25tAe+1LIsWo5XxpUV6z6x/4KWRhut5Ar7nOjZTHXg9lfAeiHUj4rvuYqe0xb0DeUJf40S/nXSTW3rGYPuVyqhGhn/wp1XwG+'
    'wUsuopxueZVbNkul5aDy0i9354NyYSkDYnabWpOuHTez0qBWrPWWy/nohWyVNn71MGA6e9Q3IBGix3JAu/E/pQL0Vc4v5y+oXmsF'
    'z5clgPEV5rhZOvedh/eXGM4e9J0fjMqH5bSyyh+gb6faZXudvJh/HTXJWt/dVbP0EpZyX0LjL5Zec9lc26IqVnd54Ounk1WSuvZg'
    '0qyU+rhwP+l2BrJeKeZX/7afvA4mpeaLZbd6W7c4Kqz0Xo1fDywnRy2bL0ZYnNtrqknV5X1rUiz8r/98CY+LtW7XLL4OYEZ6R69E'
    'L1v5/kBerf5NXGXlet3mN5ZljayhsOlWB8dUZ+/4s0WPknuyrQv2oO2zwtqd5U2ZetWo1NYbCMN2h97Sx0OrsGbmhx0z5QYHUnFP'
    '5GLUV+Wu2coOpsxON9dWihnNKU3MG+NNz/a326MBivPi2DwaljJKedsX7TBbsEYvJ26PO7nj6LxF86y5trVtLbsvnNqUK9RlZbYa'
    'Dk5D5tQRXjhVIk+bgSk5Lx61txt98TTkjCo3etmlOlPb6qembapzaoudI/Tn67LMD2xrvOsOhFOTZOgtb02cdcrWGnqnv2emYm29'
    '4svrBt3dC3qHb566HaPqHKT+yYNlU8qncaHW7Q83E6UzMWbDmVh7JduW0DB9f7J1WXEsys6KPHTaNd5ap7q1vbqwqGzOTwm7LtMn'
    '+0w04Vt2ujS3ZN6sy+tB8yV+lbPsQqU0CKj8FbDkX55eYUFXsg2Y0KWGo25RmNCdvrdq7F6sga3oXms344s5ajyoK5294A+HR1Ob'
    'Cim7U1HzG1ZttYcL0z1kvXpLOoyq3dXEa3mlvqLS3qLcr+c6+rhxFPzpwtkxljIc+NPOtFHewuJrzGzVrQKTPBx5JEX1lOnmm4uX'
    'njSzZEaRCuqqbxdLnLbXs2vHa7TtmmtsV1T7QHtDfmjrvpXNj5sDqkv3yVRJXIg5kkz5bLk9W1GvO81iD8xBOq0VPNJFv9ipDe5z'
    'p/yq3MKVBk3nX4E/9hWlQVreZqjq9iA7oBoVip/bPePFJxs81cjqWXpueYf+cGy2u+VOq9tZlQf9jjkzpvwEBATVlHbkhlnmOtu9'
    'NAolj92t28Ouyg0m1cNmaM0Ogi6nnJ6tH0/d4dwfkIM5t31Z7+ozfTAgT7CsS5bBIFUp8nSo3QO4XMlNApY2aeVfQ5aG7qGWnCPL'
    'lWULKrRQBbjNr/5FnxfosjKuHuXGzuyqzLGjQ/loDnh2nLWGW65o2drE8I3luDE82tS4rDTFiW4MSFsf1ocvjrmTl63hoT3R67U1'
    'M5x2hmO2QnW2nbFX2vEtnZpIdLuacqXSgcou7I0kk0LH46htw6t2rLW9yeXIA1L2chTTZqSm0mjVsyNHyOYKTaa2IyeSJfOUuJHq'
    'RmdaPvpZ1faHEp9ipQKdpxV/6k/7W2aS7XtHVpBNruFzJ67aFHqy1V/TtQNfS7Udci1u24h7tHJykdENo17zcnJh/VpZhmwFHoAk'
    'mr1CGfyiB1hOmaDuzqKbiAMFogo1EAqwf90a+S27Xcy9F718KDumxFdaqBKVsuSxJhtT6aQPusM+f2D6p+VxPm7sJrqandqDLe9N'
    '1c5ccLSX3WpIl8lhuQt/2yq1lPeqOh27u4PNG5PdqV8dNrvDlFQjJUemhX7BH7Fb9ThMkdus49N8SfX9rXEa7MX1ZqYUWnJX5ndV'
    '/5VCkBebZJaW+cWaOow31Gk+7oquWp+nrMlRsd0tVxFkSzMoI6XmdkxD53cqa9s7HnAUD1YqurSjaFpD8bcv1lovzV+W3Na3bW7Y'
    'QlzxPEMF9hhK6lHeidAdDQUTAVzlN6a5n6D/0aLmtXV+uf+3/5sz98UCXut6s1KvDF8MjJf7iQ4ccFJxywEv/F/8Kt9dvgZkZyPU'
    'roxLPcS4Rphx1WAlhwHj2sL6DjHjQs9L89OmWSwuJOsotKyBNJRJOtvYtTq6NBb7stCoj93Vwiebxm5ymNGL9agj5mrjktqpHgst'
    'EXpqN4+q566GWUWsUN2sUNftbHc95qrDRZNRj1tp5lrSkTYOc0o5yf2CmRpNDX8tmDOLr8D7nWbDaIm7cbZ8bL8arExnXw/CdmGM'
    'Ox5wLydbVuwxu60NveF0zc3mqXlR6QwRknJ1f7ix143NWM86gwHX7vcckitTZXHgDLzsPk+RWTFX5rNL6IlEPdX5dp+rr1PFTdPq'
    '1KWheKq50qt4krOrk6Bl1936jnr1ydlwVEvJ2kTc7Vuk1IBZqubottsemjO+Z1R9S+JXO3JAqzXKk4ebo1ixjYPtDV92/pjbKjK9'
    '2s+Mgmytd2uhObMoxHWodo3q7OnXY2PjTO0xOZaHfUZidq3D1B85VGHcaB017nXnDIYvtsrSulF3GVbx/ZpgFbBAQctX5q7X7731'
    '/YPPoaxSWqABOBEv7+ObvN2e8CvWWdd1j3EYUufaKUpOeQPD4Esgb3bTsn/q78Z1vSqXZjWzOe5wxfy+3nJ3NW/kH0hr5PDHVE/h'
    'jeL8QC2OlYlNTgzBkFO8QznCoisUjboNf3T4O7ItlRoOVapvNHeyzHTbwsRazDqFTsOQcopzHI8oWy+bbLZsO+OUKtA1aDrLmXPh'
    'WB10GpxjzY+8oxSAo6dMwxeGkmXv59yG93SueqKOvt0u5aA7B/4zc635tT9qcBABPyiBblBHasiSw7qWYreFib3djnPtJZu1BX0+'
    'tWdHcjosqJpXsbOtjsaRu4oyno/1hrNgDvXsTvI6nCWOOu3lbFahTs1DqiLtulT/IKkT0E2Hii/MepzsWP6gwQwHNt8Q+oJcPDZA'
    'xz/NC6x+Kh1nurXoaQ1puGi1ub6dqvFMl58taiwzBdtlRInyYmORfs2rrhm1zLBTkRX3ygbh/zp/FPtt11IPDanMrw/W2BdJqeo1'
    '16PigqRIqrsbHNlCDSR5wUfyYBTgiAJsJsSMcSAZML4EkuGzNaptZaAM6HaHOTSrI0mv0bCwzmzMOtXsa6uz4SVtIp2Y+al5qg6K'
    'Nt2ancatuXIoF7mhkC0Nq5Y3UDw5dSJV2ahLr9JsPLOpSbY0cGRT0HeUJU0XtU6Xc+hU9wBL6wtz2x/XeZvnddUGq2w41PtjLgWC'
    '2iMn2Yq6M7O15lHJn3bD3ct8qQ+NalZpKurBLqd2gw21qO3kOb+THTs31zfTFlOzGcHrb5a5nPuOH9NbcaP+itnsJl7KP837lF2e'
    'CMWV6pe79dm4Trd2Xakl9z1AjGP2hd1Upto01dV6wrAntNfHvNBZTv2aQQ92E7U72w1UXR4KA5EUSMnaNNU6S3c3E49q+C3VH8mk'
    'JGvWYMxU+2KfOhgsP6BFnurqZI0/LobOTCq3rUPLagwXhWxF6IxPa9ARyzWtT7aWB8tv8g47bsmGZGWnjpayFv0xZlHcq9dS6sNB'
    'HdRVk68bsrZNuVzLzhY9qtuZD6v7/QS5WEQsc7cmBSqVWwnNTPzoFT1ZV7iO3m6zRx1YW92j9bFvjT17TNdooyqeKLDzvKGjuUq9'
    'JAxSW9/kU/Ig28q+7OfOQJyV11LPWVPd04uxVFbHtrISlUlqe5pr2qnLVwVqVRKodo5f8/5xLsyq+5Y7q4zdkZV1KEssrYoG9Hps'
    'Mi/2sWlLY8WnFGnYy2abm1J/471SvLQ5tMo7Vl6MFhxdbh5zOTlwvaVknm8obUpRWnW1bu/zUm7fyDbnyrTP08PuYLfqSjOpmN8p'
    'PdZrZF/phndY7Fo941Bjpvnd69xR+e3R3rmuSnVTtaGd6q4Yf8bVuaw9tPp7MH8LyvFVcfs+4wwdoSd0u6m6VWoX/ak6nKfI44wa'
    'GyN7U1goS8HewSSagngkd/ogy5fqKZU9Gv6OGqrDQrbE7kvCJscfOaq2tLJFeUctSFNb2D3QQ92Uo43LIr955Za4VtuxlcVwv+mf'
    '/IVYsn3LXVNzmTS2ti2XSoKbYzSpxxmmOypJWraZGvKbE5U9ukqHH6am1muLzs101Uy9ZnV3IQxTk+yuZmSPE5C7HojCbY6Z5P0N'
    'vERmj6KyQC9JNaqxhWVbO9zL7tSq5P098B6pP606E8pa1IavKZI3HKld7e30eZZtK6gRkqoOJG/Bij2vU/eyy6HF62Cbay5Dipvu'
    'QpubhdYxp6y7VP7gjRfjuSXync3YEw8Hb6EAAaRq5b7UX+1Rrezs1Oyx9HY4tRd753XXs4cvUt201XrVqKVIChiv1OqRTmGjCnm+'
    'OW2XDc4vDz1tqvAHFsx/rSEUT1vqWFFm2dxL0xc3jZFtToeO4fdMQaBa8kI1+2xhW7drStN+Vb3JYlxtjUrdxk7obExjmtVG9Fjk'
    'Ry1vvaBXI7rbNNb1zZh0Zv5O0PussW459uylL4wr3rAmUUMrNd2OVGsOZt246pOL1bC+28wKjO0rMjc8dRaHlNWWasJQ5gV2ZBu8'
    '5DQ8h23MugtysOtTFpmyFb+rWKLQ6rLUlNutZ7uU2VstCl759dRodye7xYRxlJPY6tWng1l3qnfaL+Lu2N/1VHeoyGLOUNQdIJnV'
    'L+/E3Jgpkb7ulI+CZvFDC3B4oaqznGXT2qnG1Tu5GWnMuIVktrjhsNlfO0pdXc08mVK5SnZAjl+UgchtbZ+ejafWmJp1qFKftuiU'
    'SJrNumRvxyo7ZGpiu0q+zA1hCH+AO/QcWBswXHaybbC5SeiUzztNw2i33Sx3ZIZiQ+4IKZby+1RrSFvrybHGDsf13dI4tZU8WEG5'
    'WfWFczaz027TmPX3nuUIKXE/04/cfCxz4+Fotx44xr5gveRypeWnolZHp/oy9dagNPukxc7aBlefUmu7sam3jzu+LqTqui6dKka+'
    'oL0qrQm/9ezjWBzZW7luSMCvsy1xps4kNrUe753uQMrO54PCVn7J87WZPxL0NgVGotep6OOOK/Km43jUbDCkBg5rOhVlLZ6OLcM/'
    'yjYp1kGLH3v1qZmn2fb04Fs22S0dm/LWEahyX+X6U5ZpzxVVKPuOPN77L8xO0LbydFk55UXoyef63syxnP7BGu5fiyc3V/mjcb0i'
    '7zF1QRnBGOzVoqKP8uJyWc3Sr7//HgREiac9ioLzZHi3QrFRFmXbBPFbHCLtBUHdp97Tg30LQWZzlAt43oQYpTKFMd7rxLln9BFN'
    'dFYEyrj6kkjcG57rfsXbEqAi2sZu4V0id88Ay6DjITYE/pgMShAMv/mS+Ghj0O29lDvqKuuJukp7Cnbgr4IP6qn4c2SE6/mLRTxs'
    'zbBChhMoRqQ4WpI4Jp79IAlcBuW6SyzJkAxUeC9q/Ym89hUdfOo43OoXpZ3NZXTu4uqSUxzbSBqMB+34nOHjA/CAYscHPAeLGK3J'
    '7NIIymsLLrXvidxf7fzA/34+FCdKMPseS8lzv7vxs27CKu73t3eeno+kcc8J+vEKUGioLtrMggG/7OVLZLk9LovvIkwcL+Peybgr'
    '4wQ+1XIf77D7yF4DTDX3txtUzf0f3GyADze5kx8bHXqC8yHjJ5t8LP02ScrxhqPPPEW0nTgE5mONo3N27rSMv2kUJjZCe8FROz+S'
    '0AusjHCd+e//6X/nePzvHI//nePxL5HjUSrl1NxNjkcV0xR0t7/O8Zi/5F8nOIeisMiWciUSzXIR7mH8brPw+prPB3QQ5VlUS92X'
    'VfN12X8dlgblw1IbbnHOxcDsK4VheUht+NHBlao98jBYN/Vaf7KVe+ypdTTt3vqVaRe8ThHlk8wwLS+bAc3H/uRzg3xuPynkswBP'
    '0ewC3HBfKhYAVlw/d4Gn9DrovU5LFZj7VXNYPpDdYX8Cs+/OS6OX9cvpVW+sxOL4MDfr2ms2C3S1h/nPFUqvzW6uKOb8Sq64V5e5'
    'f70/i+JitpvNqrPaTFfsY31jvWwEvsunDqW+aku9mm0bTLnvCuL4NLEO606xXLfpI7NT8j2XLw9bJyM1PFp86XU9Hu7tUlM4CmS1'
    'C3rOfM4YpSHlZbsqtdHHaz03UgvT0cjeU7p8KJM0x233L35W017WOin6xqa5YF6z0suiN069LJfltpDypey+K9VXxy65re95dZEi'
    'dybZ313qKWQn26uSYKW+vOTXFrWQmD1Af1Q3qpWVeuJRSfHVbK7+mtqAPVVqw41V5HvZAyCq0nayfqpQpfvkmupk7fEWt7wvBg02'
    'V3J7kJ9y/MppWBPZ17TxulZsbugTNyBnvmiYdRGskZTvAZCcgWDs7W21AzDa9HjptlhPl7yNcvTK0+qQ3Gzt1mbqHPqaZvpSWeyh'
    'eRXX4nhYqcynA6pTawpShSl03XK/6jB23eecbMmu2+ps4C3HZWde3xXbYkrmJZP06r46O20bPJk1s/ISeNzg52BRvTmuVOStX+73'
    'qfauc+j505pzoDfDwZjWuaOfreeOvFPv8cNKo9HJuVR50PCozWCmplYLckf2GVscjs3xeKwNaZO0+kurMVecY50q6LNxkwe7mBYn'
    '4tCwpVQPzJ3BVBqcO++oTLffZwrbpUUOp1Zt5K67JQoMS/vF8BonXUn1JZ0ZDVuMJQ6Zrb4odgdHq9btHlvkSO0zjlRmhIZab5CO'
    'Zfnd3iEPelNPLxQ3Eic6nMyvev5sW65sRaEy39G76lBwc7myNh/8HGKyX+y6ZtmaCO21+rvKKJUXvKZLzVbHzag7pIZk3V8NjzzP'
    'OyfZshd52mz6uzyTzTW8bqrJuBWLrPd5pjwvLIrDGV+gJ5RVW4i5WmpqGvLyyIvVRUoYLNYv4knaV1f9Qqpo99hRnVK0YVPfTwtc'
    'dlpypFGj+mJbpnS0DrJh1lIvW27A+ItBFYxnSW92BXvdX3c3FHTEktWBQDt2q1Liye02dTjOxqeWfCyg5suVou2zY5pSdKqp7BcF'
    'CjXfqtSqFbtmHo61w3xn1YrCoDIeL4UsI6/F6VLtnQSDWoj2cTF93bgaZZLcYOIdxjlZshWhR1W8Qlnu9RYTq9XgtppiFxvOXsnu'
    'C2hkzdVU9JtFequ4Unl1XPe6O6Fhefasq3otb0iOD1tquamv+uOR6SwHpDTcWc5UH22o7HGxBb7eK/xcDlmo+cMWDCgv2ofstF9y'
    'N/25PWM6dpEbrlPH7QvFpPovvtoH/rLhO1o7OXyorRtQO8sNN6njqjYtW6l+aW7uRGMEkhEId/8pcDoV3+ZHS6tW9z17IsvGui8v'
    'GnWp4snGyLYV21YrumXJW3PTa1dq2rHXGS8pG/h4ammXt/p6y7LkznVdAE1xV6o9UBqOSTlqoT1s60dEvBTJlldWyjjual6N7Qmj'
    '/qxy1JWefFo1vOmk4p/Wx6w1HXdravVkU0p5VNlu5oZFkuNT9ST5p1xnzzvSQB2O8mSdLNACcxhvxho5YgTA9SpTtlVmuqyyyjBl'
    'd6ozd18U23Z2WNWHy6mUG+3UVAe0ValAZ9HVG7U7r2WH2a2zMC2v3g5d5WXDoyf5VHW4sNenSbM1XbKdQ7lNG54iWgxVlE6T6WBU'
    'E3R+0+Vr9m5D1Wf58rDcHYy7A7au1kRDUBzB3W7VKV/ryime3o4P+WI2V1BclVKyliW2ma2pdMaDzaK97x/b1KJRdUy7PbaGts0c'
    'zZ1WW7bHviMr3lBpL+S14Wir+mowr81A03uVrxX7buto7eYps6OPOkJ9om+0md5XOel1UXcX9OBQ8UG52nbnorEQja4IKvxinnKy'
    '+qgv1Euo9sZNcdI4W3cNelBrvHid42Stl7MbngH9uNfbXuNQ3lRlul5zxrkjSfPDCW8rPtV4odTUerrvlnh9vNjxJdHKU5WsNSrv'
    '6ruhUBbHTGl78uqIAder8mniHLRdUbK3o4LrD/rTrTihXxzmZTfwjxrf4PoVxR0Xq/vtglsdCjIK+/kwpLa8a2gpveYbhfp4tzgc'
    'dxtF73MN2l5LfH8mHVOrljEr7w9izUhN5m26sVqzfcCHZvuln3dSNG1KpFoUT4y0nXV2OmBWf0of5s1FYZrdVouexk5SpVMWVc+d'
    'ax/uVq5afTa791ova0CjLgjc8malaqrRn7+qxTo345cGdVjvF9vJoqadDvSRdY6NOkmK5X6Blo3tGphX6iitN8OyyFfN18ZyV/KG'
    'K571VEowyLlmbsROudx3+vawoL5MK/1uU9fma5bxuqdxbT8ss3WFMkf+QBpZ7d7oVO/IO3s3mXv2Vj+5da2vTnbulM7lVX10Xj3Z'
    'MnIpZTtqv1QHKcpzun5XMSRKKSnZw7Bn1FSNJwflo6eDBLF8Kj/Y71abviNz5e7CqU9Yas/Mm3V2ZTe68xfmhW8pwIhbJX09XnIw'
    'z5I/HraX/HojjdbuyRJSJF/t1l1lO+ws6G05lyetxVnXqEjTQq/fPE1c+1Uct3WZa3u7VodqzPSmUF2dKmKrltcqx5EvNsEyHNVt'
    'q9Lp0kZ+2B0JUmcytfVT5/TibnatYYu0h8NONlfieTCps+KG3snzrK0CH5Jto7fxrcl+sDVHA8e3vAHXsEcF+rXOjRw9N06VK54/'
    '1D1pbB2UEkf2HF6xOpMZ2PlZt9W317O1PNO79q53murAIrqLycDrdwW/ys9T+cGJ9LlVyugs+7lizxlunWWdbfW34uvra3vMeL0D'
    'OTKM+dbwWrYnnTxvP/MG5b1V99ptt3QaZ3Pl+qusF5x+tlp2Dt2S0bUHQLOD0Zrf5+T1KCeXt4ftbtVvaNsJLZyOw9ZBn3r7UWpL'
    'Kk2uxb9wtG2uR7Jpyw7VMDVeLs/E3hz4na5Kp1nndbQ97XneG77oht5tW+P2eDpOUcVpQa+PR+sjVyufXgfNsZ7nfNu2t41B/1Cb'
    '2WMly66Y19GMWSlSdbDjui7fejl45m4LlruSn+7UMkMqvaxe9JcusysIfNtaHFek/EoDM79SG4a6YDZawt5Pre2xaB4qdZdxD83B'
    'KNVmGKbUmSqtan1zGimrgdCqmhoMw51oYrXB9/tjlwNGq219123Vd7JiqANeJGlz1xnSunulMhgczw5P6qm03824xmLivkragNzY'
    'p/aULvd3lGq/aI4tac4etJvmLj7AV3M055VWdzYetIbQD6cO62KJtDod0F/F/aCZGIJClrcSO150qUZqMPPXvXp21l00y8U2Xzip'
    'YmNn8nq23h7NzU6LcjbD+eiFa1szpcerx6ZS2bS8sgg6yN45mu6MTimlHZWfzai+zZUV8+SqwxI/6J5USWoMG1Wuzzns4FS1GM8V'
    'Rb0zn4xeUurSHnRdp8SPWyTTmTk+1T/I5tau+Ep9oJKg3W5TuRxlmDmxbrsmP2wBJ10u+85m091R25Izn00m1mAs++7AlgaN4ULq'
    'ySV5p44k0Ee2VLl6kLu+NaJkJzXO7/Zd97VVcOZko1uxrd6gNR40KJ8e1STZEYp5ypfBUOkOrIbS28tiWXUM26DKrTE3lMfdbGo7'
    'FkpMtnpoVHSzJQ2y3fVBHougSZQ5o7NZrDV2zvr+0al4Ym9WVIq71rpT9g4L95Vyj4vjgOy97Nz+4EAdvPaL9TJtWHO5vpszc4ez'
    'aP//Z+/NmhNJloXB9/4V2Tp9W9BIQLIjdVWZNhACAWJHdeq7nWQmkJDkzlqnzO7bzMM8jY3ZzJjNPI/N7/j+yfkl4+4RuYBU1X2/'
    'e+/b1DktMiNjDw/fwsNdTBdEMVt4rMHCKHO77NoDr6drjX12YReWiWJbVe6tqr5PJwCYrN1eXFSn0roEwnzrsWWG1K2ducnuu+OW'
    'N7EGg5Gy8HpT8Wndy0gPtZziVUbThlN56S8GGQOAKLEqNDfd/PSpqN6Ou5oFdHwxt2rV4nP/eTLOPIk1TapNX1ovntPP7x25XWo9'
    'q42DkZv28496bzR3X6ypfTCy00P5Xry5LddazbAr89JwPHZX9Ynk3ar2k96pwp4ARrq6GYr7Sfp5ey/eyWazq5WeD9WeVtqp1ZfD'
    'sGRkdt1evbDceLvZYjAYVLvPrzVbbYxk9VEuDw9bHRigVUrtSXeqN9xUEpu82mkOrVE3NSppD+t8wTPmjUHCaSZKykGctO+GIBRM'
    'yvmm+WippdS0VMnfpw1lijzri55tD9zSk7QRXzfZxVp1XnNdEcY0Bf7vptzIGsXUbFNTl0WnnNrXukXDzqgP3qjgZouHVk7at7dz'
    'EK30zqgxGEkdrWDuTXkx3lRsYDudfAVER/vp5TZv2Hq2OZazpcWh0W+ArJx3c2PRqTbHO7spic2q12k+dFpmqWDrlr1urwq2MTde'
    'E8Xa7vGpUGn3H+4bo+FLaWWPRo3FTfmQ0W252b8ftXLr2ditp0o3t/1mb71+yTzU9cpQsx39ZV14mNSXi+lLvjmVuuu7QW/jrIxE'
    'dZJbapX8yErNV/uNLubbynbs6J5as4evbdWza48dpzC0i4XFYDJfllf3E5j4Xqas91xnPe0OGkq/pNXtRvFONJ/E9qhht3NuezfS'
    'Z6sXUc0vMrnpuqSZqULv0Ntusu4y8VR/WiiJ5eH1sZOYSJ2hYQ1L5v1jZek51pM1mY669dUO2OdnreFJsloabO61Ybo+LHnVgmvL'
    '6XGjfd/bveyGGe3Vq4t2zck/tVJyXmnnlXkz1d8MJyN70Mr1FnXNLafKI/F5UO7O+5bXWrrl/H2ztPZ2Gz1rTzzF3g9dx7Y7r0+W'
    'VRHl8j7VN160p3XnofOQfdzdPIytl7suSNtS6SG33DX7ud5u2qktxcwMZM3R7VO+2rIko6PoTd1ZSkVJzE66jexhaKVX+7G8T3ut'
    '++dqzt29rubSwF5vX7PDfbp/b+VrS9u2KqPyWHNlce9mJ7qYHtjtUU+e5+W0MTvM5jcP7rBdG1UHB08BJhr4OcUtienXg37/MoKN'
    'U7fsqrPpvb7iEEy7YTn2ap162aqPME2DkZrLGZ6zNIvKcCxZ2UFlej/stjqZvVgZdVZbcd8a9HsDILlre3JoZR831fuX7WTyKt9k'
    'teKrPHIelWY/fd+YvOYzqGNcZK3n/EEfa/Xdg+QMeuWxUdkrT65+2Ld3g4n85O46w1HvvtT0ll53VG+W9GF+YT0Mm68Pc2mxevK6'
    'tjZ1Legk7NimdX9b2TZ3+6EnbteZV8/wyrY5qYzE5cHqa1Yx+1AYalProTzI75z+YJDuVAbN9rQ2XxUH+kQzquqzPOykncm9ZE7a'
    'w4Ml1+dpLV3eWFmrlq+8PmZte/GQGUlP1lrSpMJkln9qO9W7522vuGrP1OV2sx87zad+JnPYj6xJ0W2tlWqmNRA7d3n3sCo+H/qi'
    'uutnlMyms81WHW9f3a29JgaH3DWBv21khvvden33JFe0QmICnSvd6Lm1u7XMcc2+3VRvXPf5JbfxKtsN0GDJ6UiNaW056I2ykg08'
    '4evTungYdQZiMb/pFPMtd7cer2+LxVmr7HqD8mI2SKcbrwVVNZb5fVVtKkBBH4HfEjtqvbaxXg5eo3U7E0GYPoxaG7ectorGpG4P'
    'dbugdp5q1jhbFw+DjqLOEs/V3u0ke7tSWjV3kFMWTrVlFrrWGJjN+7HpKY+mUWk6I9mWGvlyawbMx6o5OWSd1wn0fGQuOodh4tC5'
    'e2p1Rmo1vZIqvVdrVZQHe3NUvKuv7KdG1W53suV1xjAa5uNtYb5/dbKVQ6tftIfbrN4pJCwlO1nkHrvDjNe3K/X64mXhNbwp7M5a'
    'x5JvcpZTye+H+uTeKRbU1+b01bZWhUZ9bct2Y5iVqs2WXjNFpThIP/Vuc4BXlaZVltN5tVFyq9Km3iobiYrdnm3aT1alouvjcV+0'
    'X+29NdptOra6A6z3ute2+ny9SA+r6f7eNm5fq6XcBuRZ8TlzlzOl5rjf3heeB0V3o+3XdmGhiNOd+LhrLR+en++bWrXeetr0d3bN'
    'cFuHjKfuhm0A63Wv0x80+4P7ZWW5XLq1+etE7fUmon4Y24nXV3tiSLcF4Fjng8rYTm3vRPVx2evcVxUAz0Qzn1r1E6Vlv9IY5FvS'
    '6wCW2nQaRdfJNyt6T1wlrF1mLD4usu38UokWOS5e3RQbhUFBl0d5Y5POTxNu4q6ktdbioJOqllKH+lRtRZ679duyXq6Xu+tGaVeQ'
    'YQ4qxna07IgZG9B31ki89oqHtFVyGmOx0GjLhXVn011UPclOQOE7EAmfpb5hrAa76erRURLiAkSGTW1XXrii53p1rz2xX93GID0o'
    'rhvAOXVtZ/c8uxkN6vqdfvtiOXdD2KEt2V4a9ck+c3Mzud//uf5Jy9aL1pM0bXeLh26tXBX7lWbj0dkO7BfvdV0aOpVSwlKXDtQo'
    'P+wHnu0lWvX606jbrz91B3azNz1014Nhu3TQB7BX82ot238ar9RX4NO3Nw8lEcTgQzdd7jz2X7ptbUUCqjsCCRVQZF0r35nWeKqv'
    'RkN4M24fBr1WQboVna4zfbALzWk9388YdU2pmytDyxbk7nrWbix0ayXrjrx3m4PV6/o1UXneuk/ZbraXk+ZWYSCCpOeAKGq2JqtB'
    'cSnvBpmlYhZnmtwfVNLPi/mhMnx0R/nC6yJTOIyq+qj8PHyqV+fGoFDb2/rro9sa2OVWOVPsaQuln628vKitScF9fc6DhF6tNKxZ'
    'cenkZxkpoSx2sAIFQzessZXpNXresHtbNcuHysAGMWqgIIrpi7nVfb7vLsTtQB88OHrmYVsS900xKzmPt/bGfZmNq4N7Zz/ed6d7'
    'tMPf7lJFvZMqq31d2m2fd6N5u9VrZMSB3qwAZ7Br9AdK+75RX0qHnWdXbbsGchnwW1arozpSbyRbA/Ou/7yp9Rqt8dLM5l7yz+v7'
    'ulrsvgyePWc3enwa7l663mryYLcNtdCQJNuT7dpaK9RtEAKkVTG3W1dr0uaxX226D0Oj0XXcg915Wo2N9UTvdleDmijll4sMQE0l'
    'LQJxN26VSq7ed28XqxTgheFwn3IVb5MYiKXdSCrej+VezrQn+eeCbdX37rTS6bsTo1CcjLPt1+xKM+16XnE6alstPO5KzlpX5Ofm'
    'uAKi5tKUtHTTVLfrvfRUaNws11p9UYUhF1/T41RvYVmbUd+x7+vzeR7mEEH/tmE8PVjWa6lU7DUevUmz2ROf3ZUmlQtuYzVJOGr5'
    'rvw0TC274/rKhO0oT8R0d7dZ1xWtX29NTHsLnEw5sennCzVNbpebasuuLO9uR/rq1dPWIBGkDfN/WO/7uBimveYwLYuPw5cOCEGt'
    '3Tg/tqpm3snYOBWNXaffHoPoXyrJs4k4b7mrdaYyrmvFzFNhPT3IkwoIopaT2IOAv5E0+fEpny4MZuX+wLZxKkG67qf6L+IIyHX1'
    '9rnba7RVt55Z24ayHk5W/dfaRleznX1JdZfbdXVtd3JyK5dqvVSy7jD/kq+MX71J0VDl1rOVA95sCNKUIy1HZdFRlaw9yG90bXuY'
    'yi+eVarnusrLdt/K1NXVwn61rKcWCEcH1F3LQ12XBpNdczt88IrFu/WmkVhITcBQ2TXw8627nDrMPq23u8qLNRwfzAr0foATo/Tq'
    'O7c7PbQkYPKzy1Fvv8qVD0X9PldLdZuDhPRSEIeVFjAtRrWsGOkn5Wlt3XYlqbwodufjRkGJZm7ly/t56WFqoVl/c9odr7Lj1xe3'
    'Uj768Cgn8i+Ju3Z6MZiuFtZzx302h3cJI5q8sl9nsnF/9+xVvdG8nmn0ejsrK9YTti5nOu0H4OYGgDPneV3paG5u0lQGa+Dpuodi'
    'JaM3Z73Ra6kx7rpeWbnVRnc9O1NvZnbt3sa2clZVkUxnZME+bqyfMltvWV5OtLusu26a2/QeuJXDypHrjjQGqLT3Rb05aPSlwcge'
    'ystuemMP0hmzfT/Ml61O+QFv2sIOWecfXox27VC7K48tZ9zYaQXdbgzGw5aUWr32hy3V7fUGD5JRcSpZaQ2sU0ctF9Jee240jJt1'
    'NT88DEd3IEW8Zlqdw+t63CkBmzqz24qdbz9bXqdoyE3nobvtt0olqa5bhfpiZtrdyrLS7O08TdPGq8XwWYI/JkgBNa2mbm+rANn/'
    'kX+tx7W00zZqHqjnyrZt2KE3j0/mSqq+6qvtqLe20sDOKkZTXFjDVuq1oKubTb80qvS6bsYt1ADlOc353cD1OpvXxqggeYuR1TGG'
    'm0Wuqr1Kr6+jw+NgktCLXqPZG+6K3rpr6eKwa47sV2dXsosLwBjd8RZ447J6uF9nN4lSV1uX+3pr+jzUMpaSyE+zs/H67r46nFTr'
    'njeY9vdqQt2o2/6hbXfalV3fHemGLr7Klb7Umkn6QDa89Mp5tLL7stTsZZ3eWG4Oq+JYxssSbrm6X1m5dK6ZW48ceVMZlF6X+zbI'
    'Kt115TB4Avw2Wad2pYUylkbV7LQljryemtqXtjd3RiO8DCM+PjduBuZu2q0XXu2+uB1nu3V7vEptbxab7LJWWc13r7quwdYcpUvG'
    'BoBxblenfVttaHNptkvUGo1Jozx5bUwVaaB3bsqtO2ASRG9k9jWx+NpTxUd7ORiULRDc8vtVeSVlE1P4ox9Wj5I7emnOBsO0cpCy'
    'w+5KLpYdZ6CV62o6++L0VhU9rz5XB9NC31vC0kwyrYxZ0NqDp1oltUrn1NFsYunzVfZxIIuS3N83NSPb1BylWd2MzA4IqbB8a132'
    '2mO73GtWHFs2e3mtODw0NlngTTY3q9rj/WMTutiUFyt7BfxHwbQfn1qN7f8IFBZauiat94WOVjdenGWrNZ2nFp1Utvb8vNMfzftD'
    'PvGYaD6mbh5rkU+vncJNKeG/S9bqcQWUsZopv9bXitcZbnrlXrcDQsGmJKXWVk5sevVF3+n1YeZfHVs0++Zazs5rmbvUSMtk6plu'
    'tl4QZaXR6zxlQbzYjexOS58+DKxD9zBYZ57r87LhTp4KXXGjuE/Vw8iQDOiTpNxB9fnDXXZYGO8Ow113b4x36aKoJCzLFNNzK1OW'
    'ysOiZhf302e75Ex6s0JFn/TN/XpzvywWTNlQd+qTpjzqOaOz9YqTbs22RolyP9tYpzbTbWtqjNbN/rKg3Be9tppIbe83yq75tF/t'
    'B51Nc2RUn4eOdzAdddPJ5dvbxNJQ681lfzLOrVBtU1sMvV7noWd37t07bdMoeGovU1iUM/mKKA2VenrupsViuXhzU5s3TjGEu6h2'
    'O+vFciwWATPknaXY6Rf0l/n0uVh/epTzilzvFBobpfFipROtdqltPtm3tp0eiwOtU1k7LV15yUhaKT3Y7LOHxnpVec1k7FJzZTuS'
    'mNm7k7KqWKnyevNiFG19VnxSJlPVUR7lxusA6Hm7tsofBrmGCP/LLfryXvaKI239JI56ZkZb209Zt9gvZnqA+a3S5mHeyowaFXW4'
    'enrctseFSqGVGqZLWmHX8wrpQjl7269JRt8z3EMhV873XpxsdQUceDZrq/lytlxc30py1Rk/7A6v8rBf7/bTh3Hd06aOPezsa+XN'
    'ouf0duakeUjDPqi8puR5e9F61vXnTUEZVobAeed7rVzLaL+kdsNpttZS5ynNTa1fyo8gBUY+yN5yIa8Xr9X6pq/NXlvbm9vlX9kr'
    'iWoqK81dBaZvI1tryaoPm6N9qzB90BTJXms1EGfMQfdwe+jumprtqUtl1JxMpIU3trvGcrDOt+428kpbjzJK98GS7US+tx3Lbtld'
    'qHlXGfU3S73Tul8uOs2H0WGDHGet2F6WrXJ7pS57QxC1M+PWi1hI2XLx8PA4b3jl9cvNvX2/4sdNGnJNDdOWK83i9n6la9M7b1QV'
    'xVFDdmTNOuhP/X093zQSnX3B3k1fRdMyZ82BNO85u0x9KZuZtFTuLhqStblvHMbKpnI7LTa6WTXTLRW7YqPpacDYWek6/VcwN8vn'
    '2Yu+7030dnvsZCVj3RlLXVNbLQrpYeexZqu98tCw+qt0QhqVvfQwZ3SHxZTUNvWFrDx5OREwxE355ubhRZ+9ne3tbcZ0Hl+BRR7d'
    'dYZ98fkgqXhOXyw/dNogL2hPObG9rk3zPW/arLwW25Nh3e4MnktLp9zSx2lJQz8qnemLZIu9VWGyBHScK7Rf9AF0ovM4bMk79yVn'
    '2K9DRe/2m+tBtrDW54prWekJTIG80bNKtyaNb/oPQAZK+9dSyhZtXRqKfXV4c6Pe98lrR2VQETtK5SV3c7vO3Jb2bmc8AXLUFfve'
    '1ts3suVGKzVSUrW8MpiUR1qjMWwV+krBazaVxrRx8Jp9N5PLSlJDDOZ18WKtevn962TebI8b1sR6tAFT24AOTDvlFqWGbSzFVycv'
    'Nqo7Z5/x5uV5Wp1nxZ6hjlclC5Dlk3xzO3kc/ilQPwxK1uLeLee2wDkWBtpm5fXtQ1sySpW91B71dhLAeM0aAGtWhi3TGpdt4Gab'
    'j01UbbSs7r28lee5gm3rTqk2kJsNz/FaprQY1DJldVtuDnqpm6ptGADTLSvdHhQGd8ah8pob5lMveWPo1e2BVSp3hqPNCPjPm2Wr'
    '9zR9bjpeNSNVCspE2jd6mXVrI70eKolaLjWqTXdGT11OeqKr1ltK4Rbt6revj9un22KvNd7sHh8L+fvEs2IZz6PcYlGW56lqu9u0'
    'Cpl2pdqajUZ2Xq52SncvavqwapQ6u8T6JbV4jDawSC8k1VvsXiK1378uN6tavtAc7nfPnem0MXwpPBUeq4nx7b4yNJyaXayUX29b'
    'O83M16urwUDKq1ZR7LRb2tOmcOgNRfVg7jJGv1dqudm+Ul8XXE9/kUqqedg8zbfFtuRWB82cbYoLfZ12Rjtv0KzkdRASAb6AOJb7'
    'hXR6ZD1JLXdS7XS8xWIsgvwI9EVaAUsqPwCFmbaddV6XRWvwOjmsi8PsYNNZdIe5m5vF8nR/PYxL5mp3GLXvnit7IJZqIrO3EyAC'
    'D0arbE1rjQ71xWC0q1lPu11tt1xOzHy1qe72ddRsDSodtV6fO3Za7M9yG7VTtGeOpteX5Xx39pDL5faDrgkScvZOHFRuFuLgYHfN'
    'QV8Sp/nHmlZ4yunlJ6tRsp4VTzF1S1ONoT6qWMVR5akl2jv1+fFh4DXWNpCL8QQmLP1SLZXt0aOxez6I60bppdhft9vaq+HIsMi7'
    'Q2VUdnJVx2weCuvR7WpxkzW8bq6UeFqp3m6qPUr6Ll/qPZcnWuqhNbZT3vRGuV1PB/vcc3p8XHUns9gvdxlYaUUar2BZsy075z2U'
    '771e+3kwzWxmrVm2jUAk1YatfLu50D31/jF7Z07c/ag+Moa1zeMqY5nZdLm0WQ7ub3OV/bBYBQhJgThx22+O12m9cm87o4a1zmQb'
    'lmMCY9/rqJue3KuLD5JY9fCYId15yNV6xVZGvy3KB7NZTe+Bvz+Ig7Gan/bzN7evj92b///fD/QTqdTr3898x9RBGPHgyg9FE8fw'
    'IXgTx1x7p9dtUu+UGaoTFiCUfJVjnBc/TJnEYiH+/WzueZZ7lUqpRnKrLTVLVTQpaTqzFL6lnjVD+deVZEHHHFVSMIDa2hNWkCpA'
    'qn9/RvJDl/HQNiyuaPy0h3Pn5P4S85ot62uMj7LFSFp4f4mFRsFahqZDzrafJWepmNv3b36d+JMWTxxKZ9HdeoOcdP/K5iLq/LiQ'
    'TqbTmWK6WE6n04Uj79K5XDmZz5QzpVKuKKbFUu4/0ct65nv3wKijb697dVlsLykaX49Ct0Zv6TXC+1rc2zjOIY9zTbfeMJKHzsLY'
    's3glYdA6csN7ISiSO2cOzhXT89S3l8YmHyWMkxFxvS55gqpRmCrVUI5dt3tzAAcjDLyCEYj++W//141l6XvsAIuEyHzB//Pf/m+B'
    'xck7ShYoglYYLSqAJZqr5TtzRcnCwtSMsMvGnkJR8RA8kUFhxCuBbrsJijYFcQID+oURjpLCyczzgG9+xQoFPGNTuxRgphVdPQqi'
    'SPHD3sYVYDcfeXSv70ZvilynmrALeGHoqGjRpHB3EtYXQ7/uddUPdXdc7UkoFZafxxd7N+bbiQf0zIkH9HsGMxQc+q9trXxZTBbS'
    '2WwRfTKUSm/civt7+K85bqeGQyfAOHDmBhi7dUY3YcOxnPhHz5z4R78nqD8dCwarS2bS+XQ2Xy5l8tmoi+Z8vpAs5/L5nIg+9HN5'
    '8c/H8gMf098bC3XrdCynwfhOvKZTQJsothOh/8lSNp/LidmimCscuZrGqE65bKaYQUfa6eJfGMeP/DIfj4NQBnl+N94M4sSLeubE'
    'i3oPUcjpehTLuWShDHBTShfSpYzvLp6No1BKpku5MiDtTDaTFzN/Oo4f3dQ9HgcFgiBP8Nir05Gc+FrPnPhaZ3gJqCggNbZ7QzwT'
    'GVs+l02WxEIJI4ClxUL5aN+kcdyFYjGbLWTT2T8fWmZaVnO5k6Hlwi6fOFvPnDhbz1GMXWkDyGmKJP9XwZ1LR7F2C/lcspxJl8S8'
    'WMhAZyPhDjKimCyl87AE+UwWPon/ifTzO/eosxiWB4ibTxSyAVHgwThcP2BPgAx5KPFIKDtNxzC3GP+TQvTOKbRdGFrkIgjFThiZ'
    'uhAwMT4mjoROP3cFQ1qpSMcoTLdpCUQJCOvSF+0NKwcdH2MAFV0DIujs3w4nGtcG45m/CWlDN59Zr/2OEG81p8WkK9ZAFDaauiUa'
    'JzkAlLjExCgqLsUywbDc7kUQt86/NA6jDm6Ms+G/0/0uwMk7C/FeHBn/3nGs3azGI6SZRT5BTgS4P+Qr9gI6p/9RMBfiF2NJxZR3'
    '0Zq2sFvnxC/RwHyusmqaM1jge1OG9Y6ERMRlDeLTTFSK+jlnXJN7EVl0fGLMNWWR8A7+j3rnc7GRKI5hFFpLxw5EgmPh57VH0WWO'
    'mao709pHIy86gQsGCrsYGdX7gWL+JPhi5iScQeYknAGPZ4X7yP3PQQQ+1vnLEWQyJyEJMichCR5hOa5OgD8huATl/2Vd/nEgjsyJ'
    'f4rMiX+Kh0DmgV1wwUD0V2Fl/mch27cdfp96hx0+EasyJ2JVS0eemZClsLZgihWSMVauqv8XAsb7pDqMGXvCqWZPONXaP//t/1wB'
    'm4wRuzlei7JHmWz6e1zeqTCY/1Nihm28IWZpGcCk/D0vLJWwWy7IQuj9Y6KSZw+SFvYhkmIYAQP84r4HkQ5DDlP41S0FUEdUb62J'
    '4qySwg2PZ/3Grws2+Napy2mcaHVleTwoMKsC5RYKGszjzyYFCmaMTRy5dKG4xTzQmYWRqM0pC4nMw4Idyxo/0SKeMRGdLeNZ9oRd'
    '90Fk6pirKItlhpznKa/JIeOEV/Z5J15RAChmhI16h/vmlZ3GJs4eVRb4nsHKCnxoP337PeXKjmZ5H3/63X+QTcP1hF+ED4IrfPgY'
    'ROBL2mtAXUzyNJ2YG7/mOd3NDPL+Ejv/mywZG8k9j18gvdYVnkrPmOh66F+HJdIzJmK8cFhblspezoOqK61mDz6dX0ognKuX7t71'
    '1NWFcIvL8SzJXXqvwPJeALswM1WhX7sQOibItuaF8Iib3tNkSWiqa+AvbhxN0qEXkuFeuqqjTc+vf0qlhFs/FDsFb0NSzAO+sTBt'
    'Vxi3EcEPFRYA4ejEBdmAFbzMMFogCN8q1jvRsRHYZ9oMGrfWjoXiswU9TfLRtG8aD73eAwzo8zmnJucXwjnH0vTI8B89MqxCj4xh'
    'pke2V+lRLBdFOUOP+WlWkVmGspwtTPL0KGcy+bx8/sWfzU6r1fvXSq3RwCnlLOy5/7Hba3Wwa+eM9bzkJOpqIwZZas/Vf+3WXh+6'
    'kO2r0AWJJ30hPCOKgt8GiuDwO2og4KaFb+Eadp5vem9rDqqFHj386+Ch0621mpAtdw1gCusyWa8s2JiaK8QQrUjkDAr94+AGfq5V'
    'Ozc9KNCNk4oOySqLqSphKDwXmAfGv/EA3z/9hI5+ADWQ15cPhBl5O5GI1aSoiGnQKdQqAl7wcUb8J+YnyFjeYaw9F5fwCy/vK1rc'
    'c4wZiNXILA9uPPZVApTqYUDyLfmkQu4IA07isLhacQoTAt/CdhoSIFls5+s33g51TlOEy48cnaIWR8dswhb4Q6zdEGJfhd2FsIcN'
    'eCHMhW+wv7AxXjtrELYYPLOGsDQF8g1mJDIg1Hi5Km9CQ6YT69g6GuAdg8oDarjA2YPisPLItxNk7FAJIuzp7xLAAxCUMFNhMnA0'
    'kKQpd+ba8PjrnEXOhh5A8a7qxWD3Y+VrQzG7HkZMxMm+oPCp0Xd0ANRDZ1x+7y8o5HvwwgcavOvAj94Do0td9KBzCKLYELILj6Qk'
    'C/JiUhOloKBmzQFq80GYSrqrIiYDHmgoOYaq+InXP3FwVtSptNY9XLtYHBEorAkQq7nkai6PaQUlFNV/Jmb6SjhnURxh424dyYL3'
    'FQxgvYJ3ae2ZPSCqrAAsqr9xhp2bNo3GIPICQ0oWLwRWDnU3GCISmhGTecBf0+mVUDNAmtJgIMHmnOgS7Yegp+jYrKZQaVf1cAKh'
    'b/6QYvELBupXtHKGqWDPvwpp/KMptODI1UDvn4OwmhdH8MB4E86aCMiW4FAhM+QjjuQqgqa+4f9guKnfhMvgH8EnF5CZMAwgvpI8'
    'xn0wro+C2kd4wbA00sCB6rgaiKOAW2Ad90KMtB+EWqDTIWoRAIOAcIYcxIYXIWEGO4DzBFPEOCB04EY9Ya7PsI0JeSHzKPA85t9K'
    'e+gboi4FsAHrK7B8a0JSfu0YTBBqVhXWKG4I7FX8ihQ9sJEEkBYgC9cG+KsVLhVfE5g2zhIB+afJOUud8UbOWF0ZAVAlADiFEYRl'
    '0dcun8erN4iaOsuLM24c/mWFgCnUtY3K1dVnPO1MiAE/htwkdOcsfk3TZJAHNMSrEbk2xiAiAhCsfvjH4CJOzSPjejnVTYn2tN/y'
    '28LCOeYEDsLn2WA9vC2QaYGr24PaeR3XggVDpUMIpp2mcKe8eqZpYz0g/QXUiGMBsR2jsko68FOokIDhHilXgkYQ36A65YIp17aa'
    'i3iba18AAqYeTAgi8nBG4kmhgyoYHCefP4AigLSVKiE0IlgH9cumpUFHiYUFYd+yAE1O19DIJstBP0LNUNdAhyzIkpOewHQJpc+Z'
    'GmjP2fulYW6TrImc4CsTYNAyoJk9QO0ZkQQYszsn8RB9IWJMYgTggHrAMLoBgIWjv6YMHJiCYcxMEthwP/EREUcedocf8emMKkou'
    'nSdMAOos3E5KdJSBR0cSM7CJmuFqTBCkGZIC8RuImqTDznS/v5U4wgOMCS1WYEZTSNbxAbAxrAfS9qTwW+onGeiLC5zmVnXw6wNg'
    'ZAeoO5BK2M3s7es3jnUjKOYDsewi4FiOgJPJpHIRbEXGPF1Edh8SdSiRCUrQJH43f/YiQOlK8nSMmBaON8TsVCVwAqjQQ9yGUILY'
    'DbYaqsS4HJWOcz0Ui0U91Rw3ckrFAIjvpCuhNVkAj5XEyXuAWmCJYzxJ5a/QPcJd//gHdCGeXElWLPZ5Cd3/grSJgwomdD1U4sWW'
    'kPwBuMr0ufBJoHkzfkReACdeYV00e2wOs6ezHsxajnIAlZyuDYq/TJuJ042YEof2HBWpg8C8OiY1t2Z46kx1YsqnJK8mDv1S/Bdo'
    'HL6wEX4CTA7E8Brkr6D+lQYQ6akxdCEYJ5hA1mSD3EW0Zfx6DR+1qRDbCB+PeOe4gL4vt0Q2juEwdm7g+3mk6O+CGM3vZzO9cHuw'
    '7CywOJU4buwrUjIJOhhC8+fNF95F6jk++uO/pjMJbPtnSvZRLKy2t7dU3LfR5J9xZU0CkPO/1k++HljL9U/+Rgv26gfeWdQNw07R'
    'tYMaYXao6Xc2Byaf4IOro34Gm4YS6fmCqah5Ej1HWDaGQ7A7HPC+u3Gjk32B8AkbhNWG0O634Tcg4L6Nf29nv8UAwb7kuy4cSJLj'
    'u3jA0DZqzYd/7fbGDRL8Pp/ToTwKmOwsk55IF3EOXPlNp9MasnwG8DD4ETAg/oDE73j4ANL5HLMOa/e9R5YVNTf4iS0OPtFZFoqu'
    'wQ6RdaB/aE0Q0xH4uOyGBPrcpYj1V5x/Mo1LzrAKGwmEcmbRsVQt7yckmDgkmQlWHCJ14ddfo6NM8oMTN6YniSeIxwWZPUE5nnZU'
    'mI06Wo44cipHT1SOno7KsSmIlqPDPCrH4rtjOXqKwLiMAA6j76iTtaYrEYIWI5lTIpzBBAc6WQLag9KU4BqSBYTai8NsqEQjaca2'
    'qq5fIiACIWUzlhQqxDwA1ceG6CSBVW3sSfhkDCzXmQDaBUaCwtRTcnAUpRJDjsTZp79cBj5HhsdZri1iobnmDlsCigxCDnncldxL'
    'DToS2uTgCuIhGfEbJAFjY64EEg0wFsqRHmB/7qg+T+JwIVtVkiE0hWhAYeiW67Jwa34Ktg4jRhfo3pV9iJAon9f2IYlVADwuilMb'
    'lPF0fcLE1TRJVwGpqKAQpsYSmzjCwIaQHRKs8O0caVpiA7varyVsYa7uoEoZa0z9t799Tl+Wpcvpl6+Fb7+ktCQqGmIyIUQU/GOs'
    'yOelukdCiuzRCdWFkcXj/CSZZdZQpGV9jUE5qotj7jfEToPJg8mAIr+DPA1PPxsRjG6coHGoH2Z1rV5HWsOTxw/C25qNJCPl8Whm'
    'mbNL1CHFlzX91pIEGMQTuMQi4CTyVOACmCAK6wN17+Ikj7KXffyC1+lzD9ipT2xJIBPviZ+JS6mwDFCWXuLUDj0KrDAspJEkcYRm'
    'gEQSyBRKtle+MvAzzN2/+C9JXTVm3vwLa+pbOPNQJ6IEqvGDX/WHaNX8wed2wqJGktSY0JEAxt4AIs9DaIfl/iD4idGaguM5ahu1'
    'EVgikkppkW77K4Oevll/J6aJeByhgafyz9F2eFjyaCN+0kkL7wwFj2NpYwXPMv3iptGllRV7lrx5EsRzQwmyXwiXwCgXIrD++dzS'
    'dJ2Rqx1RMV3XYJBEmwCizr+EWBsqQSGHUQkSd3BQ9BStMKCbsAmIEFLI9uOKMJo71YMPVA0+HM3NaoaDS/230Nn031Mxy5j9A11O'
    '/2OmTf+xVSdW3Hc+/Vm6PACOSKQ+fEkEGIKqSeLe5xOFr1vgJ9OR9zm+x4MNJ1PTqG6CcrgteBUXwvYqqOJCmF+F5TkEs64H2uPP'
    '9Bm9/3+Js1q7bHmCdFbs21s4YkfcR1ucthqlY2U8g58URR4k4n+IsBEGsjpqFL/xrctRJCA/oMiYhe9LbIDXgj+sIBEB2MVfsO5r'
    'dq6CrAn5zvePnFZr7AAKqEwHJCGWuNSBWul+FlTYoIg7M5EuE3iiNkpC1sa6Jn0Ql4lVF6Ri1kgMMA7T0nJFCNDPleaivBYKZ0cn'
    'iwJIGXOikaSqooM60/WSxwTDiFAKxhHEaJwnpMJVjxS3uLDKFz6hVBvKMBYtB+vfNbz51O6afaHps7746D7E77gg/lckKthYci65'
    'MQt7EVQZqK59rMhR4bWgkEWhwJb5Wpg4qrS85lAlsOokRYHqQnALZJT3xp50YTpjBgkRQeMR0h1Fy0xzFfKpTMsgERC4Hq1mICmf'
    '0l7CTytpF7sUifGPgiPvCQrHDPVBGwlBfAuKXyME8j9JGesDd7CdliHz84bZ0N9jNoCBYsWYjP8f5jt+1hnPQePWSbnw5SjFM+md'
    'faKVwbT3ORF2zvHBZyf0JE845id4ctJRLV2S1Vjq724iNQNkLpzHk5BrFQM4AUqlxmB+xQzgT2Q9WDs09qP1wW5d8e7BaplX1D9a'
    '9ai4w+Q/5Dj0kOP46i8RTwuFQMzMOo+52BP/eLqKAGa1I5j7U3h7A5I0qmOQDJlVJp4GkwoAwFOOZ5XLsX9tVjPpyKxykYgBEg78'
    'REYOZoXtEC4IB8NFDhDZei4WizA8NiUJfP6JIQpfpPZRU3ia4yb9Z0Jr7HSI52JnPG4Sf99+5ac+LiGnkKRJaF5G/Fz4Ejkb4oXZ'
    'CRFI2CRRIisRHBad45kP/prTaZS1cJNYCOGGPQmREyZea3jO5Cb954AH4yzpRYhouMqA1GmhxgVPcDWF2w0kA4zk6z8k4mrYadMx'
    'jg2yB7qSpaa4QW1QEGAAmCEPhYM3OBgQgl9MczumSWThXUztn9qSxSPQ3yugjwEqRmHxiFwGdRIK/V6d7/L7YX/IguYvlP3wpix2'
    'LDxIPJoD1iUkSo4Xi0kXwoQd4Umcg//0SZCSiCcvhdgkTJtgWjyiVoGJaE1jBpIqruoLuuhT6jh2XWhGZDJ/25FajyuKg0sggsRq'
    'RpsNUuUDWqOjeTpm17gxzzsqY3bZxrfjgT0VmPLw6YBtEEwGHjtHZZoYJBB4qyi00cTF4p/TsAWUyGgV1fLmbLR0gI3C+fUPBv71'
    '7dCVRAJGHegbj7S47nriwfoRffrKUSAydR8E2gQhU6SxhjWQm/HSFOMv4T2RiEdpqYxEFPdBDHJ91r4AycTs1tqdx2RcyWAlIBl7'
    'wneZMbvXplOcqwAwwgET8pMmbkwC2ICP/yLEMsJvLLldC6tUgP/niTCvkSxQTEF99nV4jkySFVd8BE0yLKsZsclFiHHh6wYBEKDm'
    'WZJdAQ+r/vm//B/cpoGZoDM7H/YNLTvZ6RpQG36ZxcFzG7z5tQdYk1EtxO76xJOR/YrCYgp+/qG158BvwY+kpLj4I220meSZThLI'
    'jYeaL+QSwlRo17mZMe2Dr6aAmupA7pCW4di8kFZhD//OLpkRzYLRMBs1oF0nmbpzber9nZG2f/5P/w/kfJvHryO0glpG2mUj+xR2'
    'KOYhMfRoQm+YkKPJeGDhW5+4lgNiZtTSm58WWiA6XqMVnCct+RkOU+j5Gdy1Q3IIHaYBhQxmF+v/wAzIoUt//I4WYHT+9eFMk88E'
    'ydGkS2bW8eEMicfZx99xKelu39nftMtfvmLZb2epj7+noOzHP65/OjnjZ2pxOuv9FQ8+oSv4HMmBR24MR8oeKsQCMzUZAMNTH3QV'
    '32Lnvk1acqZ6d8D2wThi5xklnF3S5lbIBI3RLcLDaWIhpi6Z8wnTLRo7Ice8I7M8wdqjRR0xFyy/GOQXiyx/wc8vlnh+kTEjLBev'
    'NR/kyrFcJdxUsJZ3c1Ttymgo4zKToTOXoc8z6jKJeGRvSaiVzBjZiTo3qOFa11A741uPJ7ktlHyvqhY3wmHfgoSo2h17UEcUxNj1'
    'I+ud63etd96KkkS5fHaf6THeoFq/4s/+N2STY++kwlZNR6SevyhoNkHQC4RMUh1hQjA7iK/ZWEgoNBhyjciMXKxHSqfANKkk0KP8'
    'TlI58IACXx5Uh+MlOJpRn/Jx8oCgxpTZsCvpvHqNEv3WYBcfUQqPrsv123X598zth2Bu35N3JlAjq57o/wXRhoA+XvLHSWSmw858'
    'RjbiS1RuePMNVgnEVyXuyxt/2u2fI0vNK/jTkeCy4zgM1nveT07Om8D38AV/j7BPCCgmp4Sd8/zy+8M8/nA8xpATYhal/jm5SaYl'
    'sIJoNr09ZTcjzGacwZLB7auRc4qcWETW6ge8GuOFjO8P/IesHFufjeZqExLb3uE7iYv9mW8VVMcYpxzlVNt1VR3RBa1rhFGL+92O'
    'FEe2Lc6NCBkTF2xhmtA7vD9OdjMSGSEQXRMzgnku4xfYTKQqw20Wzmvs7cSiASNbj3dnlyq7wRZofgMBFsmCzyIDaxOwT55kZPDs'
    'ADaKk8TDleSOHne4X3w+KSVkIjIqcOmnvBZmjr6/4cUYUA3ZaZc/ABcNhuRwXlZojI9puGxMVI3MCrfawP1HE+STgYhJErbhqMAK'
    'oSEXN3BTNIdjLayZg5FlakSO0O4N5FmDASyKqoqCmC2yLq6HGmyUTvAmkoOV6ft4ZMbdLWykd2bcOgFQrpJjYh0p//xj0OiShSqH'
    'GUP2fvnvLJoVLpqFi3YZzWJRlhlmsSjLDLJEVjKSlR5d4HGlOGdyZRM463g8FIkn++6WIfCQG48MXsLGI++TgDOZ7Fv8MObfKd8R'
    'A9FlwIB3O5k9JGVBMNClPdId7rGBFBBJYYgGgyj2X+IFDoHW/ZxxhWTtqvAKYsRfofEWtEFJJM5JdInUISt5hQXWlWYzZFKuT03f'
    'IpDrokiHy6TvmQGzz2JSxXSixMR/koFgZEzcRV2Br5YJVRWfggm78uc8mEpU8ASTaaHqTd2h4BCRU0KFKzVmYWsc5y2pCzCzhEd5'
    'SdJ48S/B9C8JGTKSiWuAM8d2IRtndPBsspBLpVNttLViM4xrhESDnzvSCTadJvhIPYJrAckdVBoZ9Rhwbth7mit/JpJQ64Mkz2Ox'
    '5YWgcZFwGRz3addo8hGVZVnVN4D7oaSssi0aoeJWhIrjBqVcSBJZB5KsByv1eI58OhQ/7jqD2m8/MbMG18TrWgHCA5hRp1PERhuV'
    'W3qgzaZPXmFqHA1P4reaEbWzJAYGliLkm3075sgEYnXH+IeAjnQ2MTLhQlstny1CAxuZCRshAAYqQCC9in+GFnvLzQDTCh+vGR95'
    'S7yAF3AL5+iRYXcRMJHEJOIRJDeFJC0i0T46NaV7urO1Ljk0/uOKyFMFa4bNQQy59bQvAjKtC9bNONgLGCL/5HO2PsNK3+PMzpk+'
    '+rwNxSkmzpW1g0bXawCGfdQSEwRbldnrIjTjTF/jNQ4WTpqacjgP7aiXjCH2EQ7WLk2494dwaRgahUlGgQtm+efoQgW8WcgoBVwa'
    'rKEY0Ur7lWSwElzST0KMKv8ISfgMWDUTB/rNUunlSiC1M0kU4SmI6hwjdgkALjaBEoDWf0OxPMpuR7R+nwK5Ew1QfKkQq4uJeViR'
    'XJzJh5HDavoIwmUujlWLvuB4XAZFSEopXwglru7ntnCuTwdZdZMkpHBWwzK3MTGJlbADcQauEaI63QYH9YFKGMYAMjFZSATppOOG'
    'Dzn6EGFLkTJBJVd8tllBTArbODk6xz7EQuGazuFRa03n8tGuRU/KI4XSpEWnM/eIlE4HidgDdgqPFbJj+EiNaLIDc5PC/rnRQwaB'
    'zANlWBkXVwfwKFklXAk//+wbLVz4FvXYGwAKyVVpnC7TnHuwE66O4QBhk60hLGES19DdnmThliiUK5OElc3wswlcfz5tqDsmwwTI'
    'XxCujlfa2sFKLzl4vFMg/6bAngowzX5opEqKmBN+DW+TcSyKc4XqGKA1pCD445evDd9yA2acP9Gkn3/Db9PtN4F+3W/QxV++4n2/'
    'b39cR4+nhri9GslwTTMFBB0/BUEjk8UUOhb6DfPS2jWSOPeUgvdkPh+hbDwBYYghsuz8JEYIbCx+5sZDn4TPX6ABLNRD9RFPhuJo'
    'VIR9jNYyP95mDbbNxGSmFD0X23IjApfrfqGR6Bkc+4Qcho5YhSaVzz51gQCdTsd8g8ErRlpIubxlF7K0OWmZf4qYjoRqaRzpOyYZ'
    'VO/z+RchFTkk8207uF0H8AnURGSUvgXJb4KLX+fvfZ3zr+Hp40xC5Al1/frr6WSU/AFx/TLWqCE1xzKJ49y/waT7Yw/6JauaHguG'
    '4OFmhf9CQIJxNpLvbAUEpRzplxps28BeE7B1ec7ScGdk/EkN60MTUl7fz0F98bA/2AvogJhPxzkL0MG5AR6XbgjIwJAHl4uYPyaX'
    '30AkcQpVsgh0sZXpepzzYpd8XOQNJZ2DL5mMIIokqs0awiNBdjGDs0zAlmg65yl9309M5UttaBFLhWfAMVEDTi4whDT5GQYIdGM/'
    '/wFAw9SBKHwRnjxcshSYUH9N4yTIwOa5FHDHxOnzVQi9R1W/O9dvUn2LrWMzgw4uJY25A3LR2o19ZQjxyi98ISiEXmDVaQvhiTrx'
    'WB9wkNBJ1vVLoQMfHJOuNcY6KEACsvmNvlD23ziYsP5TEucNqRDZVp1CRwi5gCCYaoBVTVKmDew8lo3H44FajQFhBI5PR328IbYM'
    'FWVgG86PPszpQzZ/ZG+5/M6azvcWiOLYR7aIz8Qq0RvMSWw/D9JorkLsxPq7hMGLpMR607flux1bxkMdbNRslIPREYkG5Nnglyrh'
    'B5YQt/6WLSYiAfxdzcZkpwkf98xgM/FD5MKg15tfvfPpG9fRVIEPBSEUHdUQpWBuBoB8WdoO7yzF6JyCDMH8syt0exPZlud4Aw/F'
    'Oxi9Acw0qtTZpvatnyNyS0CMPLqISEQoQpT5oeMX5EO84PDoDRnxOP0Qfv9AVZzol0HelHzMk3QtXfNi539ndk2B+pUbxPk2LpHS'
    'NBVQGmvhpVNCIhWPmBQG3DjV8on9JJCwwV8qf0U/UTtCHBB0nI5wWdvedagWDuy7fKQROTGNmPsJftlo7Vw5SfiNL/FHLmdQo1Q+'
    'cveAX4uifqJK0TerC5f0ip0gAJ8YXHXzT3+jrVz6mutIL7S3bYcmMFoche7Ly7DU0SCPMl4LEZtF/kULpuFbxNTy7UR9C3cWHjAH'
    'Ki3VlX33EG54fvn5198/nn3B80uZ3245//UceL1fpZV1jTYpv9Ob7tHLR3qZsZczekE3odfnwrfP8pd4oLpxZig6kdX7x4B7wetF'
    'AFeuWjM8NIzi40L7HbEQKrU/b4SPMI2FC4EeSsKvQiafxzd6+EIn2JE7WDusC3Y6/J9ulke3FKoRoS+YA1qZ8DeeD/YZMiiBNonx'
    'PdJn7QvJg/gLIiGe4KNUGNUl/oG1/PJ1GkvHv13gr8h/M/Fv8T84crkBWo5XRdFkD6SA8MIwMgjs0JZEBqAvM21zfJgL0KPqUxTy'
    'SfhHUQJdM6l6BJuwBD748PrZZ2gQVnPyJTJ0Yko3ONANosV8PsLVrnZResYLo0mVEaRrRiSdbIGgUAJyxBmSVVD9skKd68rwebo5'
    'Y2ddieR2Be3FFCQuYqC1BZYCaaWOOymkNogCFJCu56xKJI8OSvexGTN8SAn49V9IXOLfZ/gdxXeHfSYifCXEHFQCB0m5iNCawY0A'
    'PfuN9SedzORpiWF0+EnH9U8ni3n4pp+oBHAPvTOIDB8FcMswIeyyx28nGYEs/guR3kycHqgETDS2iG+yTxe5TaYDwuUM/puIuJaf'
    'P4OcCkudBvrwGX5l/pimxx1/xA88Q5o/yvS4+/Llc4zx1lOQ/JzYnGYReeYCPX2JwPf53xCXRzsQQlBkqwTQIUZsRdCpBAIHTQaC'
    'WtIz+e1P2OVJS1K6eKksBtN0ngaylET/qrHzc//cpMI03+QDDTlpfiRLB3Ir0wTMS84C6GQjOLK94CcmisDPPr5/rJTE4z52QYq2'
    'mqJaxMzTrSp+F1rR0DeyrPoGGQAqrP6rY6UdHgL75hdrj50Hu1xXx32xYkvTwE/uyW5Glp1KwITM1aBQknkZvgg0/ew2PSkWJSoM'
    'UkfEWERa0YD8eSHVH10N5ybMK8kDposZ61D6SlW9JKknm+YWRQf06ayyk21kBsi3gu/6BCbShdGrsTgzQvCLMSMEbLSr2sw0KlAr'
    '0vKgKSDM4x5EF81eq4IkO6YbuBLktfMZR7sWtBharyaGpKEC1TTjEb02tNk7VmFMI5YDRyep/q0eTAstoeED7/hnqsy0uKrRRzo/'
    'T1G8nCYd3LPwk2bXbf2TVq5BjB4mvQP5sQirzQ6qpkl5h0L4nj3v47x24rQjrcXj/gboBepeX1nOxDzfwxHX5hq4bnjplCQ82B3o'
    'NId8aXEjVHQfAhtovp4kTyaSxh6eR/+suY/rSSxyfhf/kyPn8DxwDvX5x9shZ+gvV1DqWDMWXLviJIwnIBkLD7Q1Y9ky3jIR75G3'
    'oBlA5OUyoB0HEFA6mS8V4XlGz6KYg+cJ8mcFUjL+TSyIRXFCeq2/Tenf+TU34+EuPgP3UhZT1q9gY8qxuCApkuW5AW7yMUCMuRiR'
    'nMuJjlcIz0Ds8878r8wtCfNEqRnkiVJYmYoamL/1Hh+eH3zfApQPFcyTWaR/yElY6N0qkgLThO8ZJStmS+fk2Yfe84WsOjlnHncw'
    'QZmoRSqAS4Z+Z5JihlkD49fCpJgppblVsXzFeEEZr0XjVYMYPqGpBmnLkeOChGSxBDObTJeQPl6EXUKjFFW1eKloCcqVpn8g6ZJZ'
    'Mk5DOEwxJ+bFUnSY4jSTyRTDYao5Na+Ww2EWVKk0VSPDFNWsVFCjw8zlw2FKJWk6kU6HSbAZYgoEDnmqZNU0AsefTEIB6XlS9OeA'
    'A9WfzIE/UzgH3J+RZFk9hLCoUZz/wM3iknh5zAXE7bGMqDjA+SPLc/YAYyTIYU7S7piWyCGVSdQzFlIuRlnQHYjkBIe/W9/hFLzS'
    'ZzTjJx9XgTVvRAsjIOsFQ5t9TyV39IGOAoBRm0WUwCLyacW4r8hGhIoqR2IqZ0kNdReZDFXEdBI0rEfAgUAwhRg6zYoTFlx7pOuK'
    'jE+SPZTG+TAv2N0sdPPFtXTkVYtpXUKfu1h7zFBnzKbiA1ehxTk5JokeVX7qTkK7iICgQg+IskGWg+pEDVR48/ca2q8Sc7aPkjC0'
    'ekAfW+y4EWBmF7X0RerBbr2iSX+Yvqf0fWBkMXtfk+QbsEQoEtSfwvy+0gfqpXdf4YMMqX+6xNZii+swjx8zps6pNm4Gddlkz8ns'
    'LnwVE6BqG7uuMMsMX33onBJS1ruAjtrIvMYjhNXeY0JgpINdO8ps7+OYASUATkPv1hNNFm7/+/970GAHcN9ukit8JocGF6R6cEwd'
    'LcH8RwA54AO/+IAePST093CM3KRJyR3Jh0TeJbRDoc2/xy979mVPX/b0hbwyhAZh6uHGi7UDiS0UU+mgqP0Zefr2Z/HLBYkjk/CD'
    'SB8y/IMcfsjQhyx9iMwsfaU//hAuWNqEBAZ89eJHJ0Wk7rlVD/+13QsP7E86p/pJYQdXfhLafpyM7/Nn1huoAL6uUNJZUS6Ztffl'
    'S6j6cNcTGBcuJw4NHZ4xLB6M+Gjo6TgbIHGAiLI8ZNI8xrL5j3iyDO0zixFZMoxQaOGmIxtffECGiB7MrYQesT0yT7vg+GPqM3v8'
    '5udHVAjEKDaEo04BeyhR2xFCNChLQUen7C4a3kELxX/0xc0bDBSDvvpKpMsLH4Rcid9aiOrYg24m8Oo6cqXwghCswbChRKAJnsYi'
    'QByn/obaQdIumqjogX6gn0BS9fm3q/zOLJm4sMQJhr4sqS++PoLuFMagkgQUZ6jntN0VGeywlqkJSLgGfI6eD03/1VcqcniZa9Eb'
    'ynyavBOFmWcGyhvkGZCQOHLgjQwDfzA5EJ2Zm1t0WgkEgmQsoJh/QNIfwn//35mTR6YljLnazEDnGktuJUEEJYIPzC15p+T7AF6P'
    'zFoQqQaIhhOCAL3gfg6UND6Gx0xxbuRq0nUSbu02M2JU+28nSBRJCv+go2PUXCYd1Q75ziFjDO1NEN+xoxSiHtiD37AhQoAxhgEn'
    'iPoYrieSE2Ripg3+BpYuAhQAQJyBjNkIjookTb74ohG5MiMTLOJnHJlRcvSMEshBJK47awOdX841blA5VbcoX0djnYRFXbpg7p+n'
    '/cT9dob3VUhVqgixP/DShfHHlW9SGWz3FfAIQ9yx/rkesgqqzYxrqG60aGSe17BqYjT8Xsg63gX3zJlK12FIZHYDKc73Osh11TRA'
    'uvohCXjZReeoxndNz+xxAGA91SFjPzzCkgKFRgTyyO8pelaNWReCb4OFnpBwjHQOcUoCCA4shMM9/u7RRejETzd4Okq6EQMWVMHo'
    'xzAagecIpfxdyGbSnG8EcS3n6xEnuGy+R09XRtO8D4FPzJOjD/L/OyU9GFZxIVyyn3QyS89ZfMzTYx4fS/RY+nKMCNE95zvbMjRe'
    'n7PTmfQFSXv+cf0Jrs2wi2LZ9BGq9dtAfUmAzRDBZsX4EZbkJ0LkAZAWJqzhDfdo+mqM8BAl2Nk2TbaJu/b3CGcm0plmJNeecu1Z'
    'rvlRrigTC1TLxoWzWdYSu4HhuWiFf3JX3/8FIGTxSlwWyCE0iUbY1CWLeaGEqQR0iVGGGFk0zIkJW89VuTvyqyNPCuyGS/JoTpl9'
    '+gO5E4j22TrucwGR4wljfvQ9em71c1gpzARtDWYf6QWqUJw/j2bZZrMs5o7m1qO55ZWLaAeGUAMTFqFGoXUHwRYZiqVhAQi+fhNy'
    'aZ/1xQqPsfYl22LMuoy4T9gEv5PRTTqZJp91kVv5LnyiTYQL5+8m99rfZe3wyJYjafwQ8lHkb+v+oXLTb/SYQ2m8OYkCPBnGXQmB'
    'vxTu3Nb3J0YHlleBrzDEHEwmD0sGjsn+rGh4gZE8cf1r5eau1+qw3gC+R/SBx0UsPznFJb9k6FO3EJZdG+RBmQuREQXTCbZi35Ge'
    'Xofn1YDviK4RxiMyiL4mmfKoZfDwaMzwk4E6nSzzZ4A3kES6gyp3p4WXmXEaWalY95LxjoAFQhrANVC+zzBsh9tFxcnUmIxK/sAp'
    '/QM/XPgBvGJhFWjvbRA7wz1e8+sGRyQR6NgDi8AGQi2QPcNgUjG/j+D5/A+pmNEbNlMwz4nqBIpHsokhHfJRqDNSJjCfX+QJm9TQ'
    'LmUkUuWrJHgAE39KSPDGPc/Lk8ZTc5gJDhJafp2NObMNz3FdcnwmHd1fQB0H+WdgNI/pBrjyEU3PLtBJrBslfF/ZRAZepNni+ASJ'
    '4WZ+ar/Wwmxzgq5zpqlijspDR9SqfsedP3yg9kJyiVp17Afs5ihwf6ZjYNoJKPF4DMlRIvdUR7K/oZyT54yTdPLdh8Xo4OWdgszL'
    '33eLXv8HuAAkh+2IPdAyTvSVzSI0+D4XQhiL2Hk6DoxaAb7neoHVGeUnJ3h0GuEnWVKUn4zUHyLUUKT/GFG4hFxKRErZkXLgiCe+'
    'DrpBc7HaBUqBb8dJEz5rXxi6pY4EFe9ZxVE++qRiiU/yKqx4cpTkV8wFO9g2N2zVlzjlPhzAI7EPaMf/5dMbHd4FFbw9Kohw5xcz'
    'vleMGQhSoU9CFo08IyaUafIGhh36dCTL2oiCv0u1L7FSOsYU48c2hiCaf+Ad/ZMKjXcqFC+YfbjoQyiX9JGAAvEMlGjn55G4AT52'
    '8cw1Hkz6rg/QSzhgFw7zd0hXSesQUTlE/QFKuIMLaDFDRlzAis4lHcW1bDIfpIrc6rCN8gZD37A1qXDM0yy6AYAnaPV4RPWAPvMR'
    'F6t46IdOceh6ucduoKEjByJMKEhQbZdMUmUNke9Dfk4JDSAV9UJ9BojD4Q0zfvuADvMgK57QIiEjAsC2Nzs3JZdVwgrmijXheuwS'
    'QWB1Q/3DMDNMZ6sT0+efYbI+kq0yEJglSHFKaMbIxgzbpc7MP0xGyKNKDc0KOO060ynZ0YQAYuDZCVg6RvkdwgZQA0KNQzgAXwh6'
    'cAn8Njl7xUEF+YoYFWIcIblW5K/1zzC1vwnZL1gj1cU4Qz/P/igP0/BGZClfd/2BFp/iG9CAP9Mb4QG/JfiURDtYAhX2iiawCGKE'
    'J/zWgg+YLxEWQ1DkfmO+X2/iL9Z7eVLvFw7V/g1JAgDGC4RhaZHYuMCAIOdiqCcWr+E2QPDy1gC0p9RfiJFAzFrS/FAbzHcKKijn'
    '3OG4xtkVlLAt1M4ovmmpqwcOyIPmaH9Ethr2nAxzf+Iuw3S60k/muFGdgn+wH64lfmyRtw/4dMEC3r4DwI6Kee4+o1dWhIoTSRPl'
    'eqZLoyfU7fnPiQ9oZ/LWao8+RnDlHceVEchnQiM0zfElfyHIx+KR7l7hY1Ri4kDKdXV3bM/RjNEL2zFJsgGIvcHRNBUhlv6IYTDC'
    'u6NeVGTiabz1wC0w0ah4FP3eMUsYNt9IBQjpx8MCRA1Pi/j5fapzcXTrAMCcsWB3TLGtWT5rdUc6aYB39j0YuMiONOCDnzP4lPbr'
    'ZncPrRCyFms6B6ezLWKnA0Dk/Dfz1uvLxJa5VMnt9no29zF48s/m5U/BgI01hAT+HqBBAEs0lfqr8/pX2qOSRy2ylLdtvrM2OO1/'
    'PP/yFVciuUOzPHrafxPu8FEMEkVKxKdMkJYJ0rJBGqLi6P0WFFQDy0zmX5odxZL8ClvrD6S+sBaXmIQ3Rvcfzn75ihQ9m8xg7fiY'
    'Sea+nf0hXL2th7nl/k49JNOf1HAe5dARQh4ZdxFQCZj2OHP6YqGSRflwBvNDKB1HSDj7m9DgST+mHkGBHxOP71eX+GvVHdOMb69n'
    'ZP6E8yh/O+Pzcvx2SeLRhzMxSMCZReOyD2ck6Z6lPkZXkdyN2WxaZM2RUZO6wyoBDKFSec+e9/Ds+OsnJjNkTVL6FukPinLfqPKI'
    'f3M8OmByrIoOGtGrtRsKvpLnSXidP7RI3L4HUQEkbLmhP1pW81bgI/OgzmxFfIYKiCZqYLhky+3A0K82o39AX6H5iTabUTwSJCHM'
    '6jyQUj9FoOSXr0owUNTGRCfeF2LfzD/OVEIofztaBlmy/FUAiVeSNQ+mN5nFWQsAGDsCROuvNS9/p213+92GoTrYR984FPDWmEzz'
    'Kdw3MYbffBzOtQNxtlFRooGJ53nip133JauT6rrszNnH/d+tkiNMv1LEomst/u+ZF4puwiNJvpma4MgcVeJbUu/GoZ5fvs417xtT'
    'w304A87dNZ0rOuBQHX/LHJuTB8djLJgkM7PkZEoC3kRXAsdFAaQHxo/8K4/qSBKCaXjkMk+L3pXg/kyABLMb8m+dkNAZIHNASl4G'
    'fA8kvLPsCJCCBaLDfTeqP+OaNzTEYkEPZdN0FM3AmG9JYa19YFdiI2bZ6NjTj/vGDbmjbjHIPnKtXQjcNiew54mqkjCeHrPy+kzZ'
    'vjBsFLhqii66748F04IwbBGP9SgF8Cl633uT4cYjcjqeiQb3QCl7xIgzMLuO6lkwQ/zdWn/gtIj5/2HWfUdGVd/3ZhQaJJIEduTd'
    'J5J1yrOi/Sbz4/PpE+qcZBBOHGQV5P0Vc+ripK/enjY54WmTg77jBUfkweSInUYzzIgRPL5fCG9MOamSwH1MeJ0LQIwsctEKkoGM'
    'gR4zyO6P9K7IqAU2w7557DVT2kp0vfiCM30oPJ+hvRnb39E7A9E79VhH6MeXBAGVropHWQFmJQxsAEa7NA1faflGxCAi8oFnCa00'
    'uW0cN5LrJbFXZMFmHvnfDixzQ3dPvgEK3i/uJeXA4378R2v/ZoEvyHcg3UfG92//+OUrrwgfsReMKeMHNTQl6Mb4y6nQQygi/IxV'
    'YkO/fOWmy4mEXxGbShd4cDdyO+pdu4UPQoHbLbDshKBd5qhvCpsIEW6MrIgTx2a+eDNOSKHNfYrgjsiVaV3SyLBUMG2nxrGsWDz+'
    'zcfK+I/WnRpHsJL0amh8jZVpSCl8iOsbAIgfztBRYhdD8LaMvgvEg3E9aKccsD1oqOzzPayTH4G04kC//Z46bsjvypFU9sfa0WN/'
    'YzPMZp2uxQihTlhVZqrLNeR00OfP948xDncoZMTfRyjKkUFdkgumrC2YpED7HzFsJq0zu4EYPdxK4vEDOZZhrshRrepv8ouI+8BC'
    '4KYAfVCg7s4PH0yqEyQJQF6vhD/QePMSe4Jzit1D3v1b/Nizc3j2TvN0Grr0NMYoV6MwNIIfQ8rq83N+KLRIaDbSWyIXSu5JUKMR'
    'SJPsPoNh+P5M0GiAbgWEqGdqymT5udaYG44jh65BrNZ3fLyGBJ0STp1yUL0s9CdrIlLtW6fD3H81HcXSZfuwduaYm+EjVhMQpehn'
    '0rL4H+M+QOr+vB6hUGb4wY53JuaOuRpgd/yN6KHhsSXn8Ulh5EyEwi74ERdYsAUOA/y8n5+IB3aHlqQceztKX4TmO+z0QWKH+hdk'
    'J4RnBsy60794RO5b+blGJONlmDFBrRDI/va9hvbU0Nwvzw4n5u80xE5KIhkvw4ysoWPln+67QSN+UuKOzzG0ILvYsNLQSRnufYTg'
    'c9e3pgk9BvlW9+QCxzK9UD33UxiC98R2gIxiDHbyyVokH9K+5hBeKA/j/ehOfTzcAdgIcz0a801vYD0jZPWN2Qq+3JmUELVcOUJ2'
    'HrNcYYYpuQxZqpTIdIUMWAoF/Juhv0VKEelrKfPl+7YlvHseZ60IGm0OjXYyCDh8fVRcZh1loJ90VGUtqzEk/Ew5KcMycjDFS4Em'
    'RmBBzcYF8+9Jm+SvlMrFeYnQUIJu4uXjx9pE1GoGE0guIMPJxK+B7YJzfI2YlxTj3C4lavvHhka3ZrHwsQKfWTxwUhVZIP1teI0Q'
    'EwUXjBm2nZmhh6fwHPvi7RF1hHZJIUcfYjF2tHqCvUKuRyJENnmfGAZn04CwuE80kxSuvk80iax7/De82+kfboensk3ykQdMefzE'
    'Qiz+js1TmtuXBkZPzGCGT3QEIsniCZWFfNIk1F+wqcPjISeqO6dbTmoQi4ERRO5NG5+PuEqdDI+5BPJJQDYqiL5wBa9YA0riK5/M'
    'kLPiX2Eqfg7IBbxOwtdwsqFUPOQlzn+fRTQZYv7s4/n3uY1wDt/hNFifTqJHkIUMbJ8MIISAm2AmMywCNZ9Jf01OGA3MScwkYzRC'
    'K4SrkHBzSo3zpSmhVQJOE5L1b/HvDz0180fL76sxJMpPGKOImx9/sDHSCaGueWi16Ekz7oWX3MAFOm9us4k1MffVgV8AHtsDb9fH'
    '2CAiodD5MN74KSCpiG46oc5WzPvI5cjjUSGdFoDRfePP6DgOEdYUeHDgvbkQxCLq9b3tSTyO0BfQj504xOPHDR171/C25JawwJzZ'
    'vPVjkRBKzEie06QjgsSuIa+I2HPKv6cEJMqBDw5/XzG+8rOe9EOdoLmCb1XwllZwdokkj5nwDsx9R6H0y1fcfJ+E8+PNw91Lffwd'
    'T5cFEkhQGiFhBCWRULcIL3MV5WR8m6OQsguVW8CrcNaD6bZ8HW0vOZkdqY3f3wSEMVgsAl1+R7n43VJ4R0lMZkgyC+wwfZ8kFBTX'
    '8/03/vE7ueuhTq+S4SDxhjoWwZWNaez+Ig4Bc1+i6gClQ7apzoCTgaFKhneJtkLYCswz2mVJ+hm5I7mcSitNp4oJmnkqeokjkc71'
    'U7Z8KmEHhLOFYwd5T3VlAFMQ+LALH/8IL2qjs48ICvgWWtL4exQduv1gi74Lb7BpjmgEjp/45TRxy+kwCk6AiBgQYjKQuJOYGsSN'
    'T5gYiOYe+Cqx1/iP5cz372bt6Lpx5H4T201GMnK3id17QaIT3ouN2A0z73IMqMgVhi9Oulu64Bji2xkPJUdWTmRRiQwGd5rnl7sO'
    'q2K2ktfsGAGJL1ms0Q1aDCzJ+Z5gmaLVk0e9t7XjvS+m6WGVzpLw8+nk+l6Gibtxv8FeEm890r3IXP642aD+XpIud55UKyYLfiWQ'
    'RL7+jisj6o1zFIkw9/beYWQc5xFd+Pk7U+U3Fs4EcylILePHq2gPsvFowwy08cppjzyJMN0XOfYNRolfo5yJs3t7ay76nYZyQ/o6'
    'domD7ve4hHdhaI5Eomn8zX1L/8IfRzt4fMOTuGLHILFQCZU7Bolvyj7AnRyg8X3P3uf83ccI0yPk6b535vMN/lA/v4U48ArVUiFC'
    '97sRIDzlCLVDN46QO3Qj6KKz+w/05kiPzM4fPgjRwJiwmMeeX69/Yr7zUTEVJXFMqca0N37wDIx/dPYxoooMNSMhWIQ1RefjUiiE'
    '08FeorOBpD9D+kPW6U9o4Y323KfT9KOMJ+TRwVUAfiLmFyMDw/h3z9mIHr6Z4czZO0fTBSEXaiaZc2HqDUzG7B0ne1/D+wE3bwJe'
    'cIMvXVuqIcvoehJzqifTNbrI7Z7QuiayoZBf87f9B3/j0/aezNCnKX1C5OseBQtAf38RKdRfOb4/YyKaHKR9V6GuSxVcHPEzeeBn'
    'kEj6RUCkz/+wQOnsPH4aPnMWdVL43vyddgz6lOUX7FlUbrKeh9Q/wpZoPeliPAgFvMl36gmHF8xR/CSc6Rsle5Q+apxAaj6FTGDi'
    'ajY+ndQ/fpcBVbXp5gdsLXzxt1eUFdQCrKGdYAztFGVoPs4oUKAav/ojtuyP3ykCKw9tQw2yqKhQ9H+oPWzlEk9nP5yR4jsyjvgZ'
    'XjV0VWBpblwLRtRBP+wfznbPmjKG/wTygRXum+h9kH06Mn0eYgiAiiMhgF/YhtQIP+/nCXyH64Hv8DfTH/KiRoQXxUMLjdf7X8SC'
    'zpJvmVBKJdQ9izig5eWYNMGSfXEhoAhArwOWVQ9ZVj6l8esfsAxse0Vn9RS01/vjZaAf/4pU5i1Ikxi7E33aixvC8wnsnpLXCFW7'
    'TEidozkyQY4fWbngHCGfhNbYSYzknfGNrb9r/3ACY3gwLil4kdJg/siOEXDsLJE/C8ISYYwiYIEkwV2hjePZP//n//XMl/QD0xHT'
    'Uv1IFUnhFj01eeZs5uNlfuyHeIINeQtTk7vAi7MfhH04lSHlOF0IP9jneQK9U8X8uG1EYaM7AupE3lIkeYoCfwYyc/HtcnHSzroa'
    'Ie/vy69RtDQhNXqwcJSEu1QUo0hjEkUZmQzDTqL4PYOmI1E1pLepEwwWbtzJLmz8v2SzipmTfVqMCou+kEH7j2bb334oIv7xRkR8'
    'yx29Zb/i72Cqf+8yUSDRj3ccrDlYQs8o+djgaxLyxhN+7Cmmo8oDklj+zOwsWXizSBFMQLCSS+YDHDAJccAE9wP/lgm+/aixzPf3'
    'eHTWf8CSkhpNBbmcQpJ9Pb6rySP24V1CzzNXl7o69eJXFB2EXR7QPGb6E707RpYOFEKPLNwYZ8YwRDTbyZ1NHx0A6zL3EQGyppdC'
    '9rtblRTFaCv1XTAgK9O5pIWAcI99f9NnTOHnQ+rKB47jNTyClHkIKfO/CCnvM9DvQctRtD3sFedG5keCwvxEUsDd6WMX2qn/HjY+'
    'mfuuld53bSjfBbC55DYxdjudzB9x9px3J/9uFINQ475WGWg57L4IycVXRxGfMDobiwwf40Uky7oIIQyWjggOu35/BFXGMZEB2DL+'
    'KmxRi38ZvbQsFvtUdd8HnpBWGLiIJX8RDSIT6cgqFiKrWGY0IvsfR0GfL/G2u3iB10lIDYlqBV8PGeVTCDsFuMkIhHPOpJDDGy0w'
    'c8Bbxbl4gK7C7D/uXf4HnEmoXYx0/0jLeCSshF8id5VjZAyDGhB8AHKEP0CN6I3ZmaJYxtWHVBeFrwnM+DD47X6gqdtY1GyPjghI'
    'm4TnVLFfvm4gBzOdpqf9t7jgypIefFpyYxcyLUSLuhvPc7TJGgozrRQGyjxn3u5+iZ3/jR2M7s/jP84LNVqmq2FPUaFqOrFj9z2O'
    'iqeLvOusbc2AbfXYe8ZwD8xGEQ+PqKrIWPHV3RtyzzT1ieSECbSl25LhGyKSoRX2GNfvWTXW0GXGIcYpf4Mns9yes8czKxOmBkMq'
    'AQLA8dU8dRXr9lqdhwvhqdtqJllAcW26x+PUuB9qgDxWslh0P1Moq6HkGCziY+RVYEFNrgEZSK4XO4cRoHEzIfq1Z7roq9vHN465'
    'BTFM+Oe//W8UorYrsbBp5DoEb8dJU4wngtfLKaTRUWRTQEvQ6P4klGkk3OZqpXkxpn00NHd+Y2D082s87zW7qLVg55Xvj5cIdJAx'
    '9GGdT8cjFbgYhTZGrg55EjcKQlPWe83x9rHjUFBoEAETFVu4pvG2Z6iebKsUJpYhblT0+gcbPAIn9A+f6R49cIKs++TAmVXK+35i'
    'A/Rz8yg84HFQ5+Pe+hB71G8cMk2lq6qAEPD1nLf08+k0+baGkVn50Uz7UxJZFtOKxU/njbdPLYb1nrb4l9bWbzHSvaDFExjjzBgS'
    'NUdi5lfH4Ebk9Gy+niAalTBEn2+yxT2DXnHXqqHvW3IbG/q+5b5kAF9zGovWqsZxGMZzFxsiD5Yp0ogH7i2RKdzTuckM0DZenrsQ'
    '1OQsyZyPrifkpMAy1RU3c8DbCC76HVqx+Gd+lOfH9cQPrB6Y833XcJiHSMZAtVwwDbyaRkIg+65ReVcldLvNrIoksmjB1Ihoi8/T'
    'aDhz5F2xIVYQpOE1LJvv/xMWiy5fYZPkVih6xcpv2VXRY76n6vuIWTgGsKMz9SB6HboZjNIWV5ug9pFHzvtx/DosS7LSe/5t8aK7'
    'RHYwWOVn/BMRiaO+nds3jYde7+FzLEYFPvkJQCwUdYc2JpAc2kxcinQEjS6i/YysXt8nUxV9JdKCnLtBnMqTFaEQJzzuIMEouzLN'
    '4IQ5imBL43tivGYQiLUSPE7XDrHtFHbX9/akOcGCA1jTnuDJkU0R9XjEUiogwcSg4poSek3TfC8+kWNBUjX7K8PyR01Rl+/buX89'
    'ambJQhKfRjoIXYn7q6ElEu/NcJjZt+ZmoRW/Rjs6CwLOsysRpOd6t3PRrs1Y1/jpXFBAkK/5GSDP8M0/9F++zcKGFwbS7ah8QRgi'
    'ChY1AAcWT5B7HvF31dsl4kwMowDU6nnAgARCKyNoyArFuAklo8Iny+gFIQ/9ncWwTvx4Ojx/KAFRivJWqB5DOxVyBwMs9MxgrnN8'
    'J1l8bwU3MphlqhEqXcl4mUolOYz7QXj9snTl5Pq7J9CIIY+vcJxENo14DBV+//+Ie5P+trFkX3DvTwG7soqkRVGDh3JSltQe5LRf'
    'eWpLrqz7ZGUaJCEJKZJgEqCGlPR+d9WrXvWiuxfdm7d4i/5Y9Uk6/hFxJgCk5Ky891X+yiKAM8aJEyciTgwS5RP3O6smElspLJGJ'
    'IiplcRf04Iktyqq4axuRPeUIZHyQsIXlIVtLgib3OeE58oV0o/gsvhD1wERDo5tcmMqCIaWRJJCSuAJqEDiRoLNCE/z8BjDTe08M'
    '6qQG4JrSAoKel7rSJ513y+CWNJ8uA6iXEPbEpZc9sellrWkwB2TZjJa9DMFtkwt806T9tfyxl/O2bE/gZbjVuxdp+cYstpXe2AH2'
    'oRqcnauFHRpb8tIQ+5blE4tNkzI2TTwDZEniSGBeJc7SeZkjXRTxg7DtW3sCB3PIYI9aUlx6p/NtuWJZMV1lzxUDESRlW3+Aiyrk'
    'QXzwhP55+NdVpGnbX/srPQTfDlpzzWkxwuW5lrSDhAkij62sQh7EnC/9yKVrptXElO7UxE4bxHBBF9CXTSx9q00F/CAOP4FSiv/H'
    'xAVee7RqIzDaWF6afJjX9ImWV5PpclFJWixFH4XdYStM+DZhaqpJw2KoMuELDPtJGgpNbWtIXGvevDkKBWFeKW8YtdrpdOg9dlnC'
    'uTXHRy/Tw0MY5iStlg31jLzZXmqMQSxzcgZ6Eq1sC4tNBClZ/p5tf/MgXNklR1RmI/qSPorNeisWvX7KKQlihGsH4JuGMlpCqLX7'
    'PkXR+ZVSKhLj+QKUT/i6uHAmGpfX1bTYEz1ZMLCJMzvAhAYJYXcSeW83bhDd6TwWL+OBySlRdrmcjfGcS/4izwUK1srgSN8Mlpba'
    'UCXATZHDADlKy+Pkghmhwr6xzcIsodPvsr8OQJflJgIU/QKxYrJGj6lxme0Kqy/bPuCEgQQT49XEHEHX5XrmAmwOKyBl5kNEyXTg'
    'sbF48JaEwBGsiKzCrfkFD0yVxW3V+keaDNbM8Vk51rxtuoU64jAiYWw0zvs+zOAK7FJLHxZqG858udg8Y/BNhr7obcIZa7bwQFuV'
    'M8r1Z9OmHGAWMEqFc866C7GiS3/saXTt5CwrCnaN/0vvQsNJIBYqseVAvDMo913q8VRCC3luGeLvO9VMFB7b3wnm8I56a/6u1YIU'
    '2etl501ClwqCez41miy7nDBcFRNMqUZso+sygo+8jOC32g/O92YJuU7FatZpPrwNIkcYgXBAlVGkYfeLZdR1V1Rx//dgYS0W8WKD'
    'oVs+HGaS7tkmP0vgP8MO2+PMIYPoDrDWKDxMYrilpYXGNED4pgmyYRbh6nKi52/ejcxHcS3ZQjbTTSEaSsJcYq+l52Q0KS4kUGbV'
    '7DzvU//jksgl4YzzUxJ5hvBg/JGT6UlMY1Htgg8WTa5ENXZlX7OO3i984QobQYlTXvVL/hESJ5b+PMWJw1Y99sSNOdhJjAAnKLG0'
    'yclM48IMti/HOg+mL/7HPIRrzwN5V1RCsQk7IUlBK8od65ZsTKsyBB/GFYYoqxB8Ii30q1UUdeafJLfcIDLFC/4xbzcAH2t3gwZk'
    'UoONyq5YQCSnyYikjF21UAjESjl6nVxptJ93jRvzpcNJc05bh599LX1Q1Zq6bWg0hdcBcS6pS0VbarE+twrGO8bjlSkkvafChmYp'
    'V8J2uC48kujAn9kgB+MkGXhZYaGmc5gwh6geqaM4nQO7SWFtLHImiCXuPmXJDzVaPoAsJpSK72OJhgeeGxVMENKSHxVrL6hJDvFg'
    'fDlh5eLeIYJUdUW0Q0EMc7IFAr1PF4O8B4nyJv0FaofF6FHBC19XchNG+Md1mQza5Sdhy2vTD1/Zr6qg8qB7T8uRG52ORPvTlAOs'
    'vet6YQoSdmHTiqavKSt3ptwGIgqVlSWccUbUcTaKG7Q8ZX1fyuxyP5kUnpIv0PCZYOaeok/Hkvu6Ih2PjIZXTgKBBGAqK/RCPVm9'
    'LtU2fWKn6qELbuTionk4vtWptnCRo0Ms7cbNKDpNBJ+FzFXSXI5NEBRJUfTeZbhMOU6E2cYqiLi4HdoWE3HZUOMOqLENZeTuEsI0'
    'enyBNOF8e1WrCoNXE2hkOXRFzm6Q3LXhxxzHL2PAWI1z8DPFDG2PA2VYzJT4+HIF0ORPpXsQgFHVSYK5uFrO1VHY3COYwGh3m7X3'
    'DmqUxKhirn5aAcqJdFOE0o03FeKvjRrdcyhnqcvKW1wyb2nmHxaqRIWnqR5YuBJFXZn2MlwHUHBg5VvgEJB/Z0Oe+JJ8cLGhl5kr'
    '0ScO2kCiBXFqdO76OvcjCbx4lgyOLOOkVi8TWuRsCgykuiq3KOvXhDbPxkLlKDasqKchjqA46EQ7LgC0eAZyODtkbkrGfH+iKRPF'
    '1xMFFCtTk4TRhBpNC824wEyoZFS0rbATIWrLBJDMkOPl6dcsOiZpmAowUoAhICThezbRPkoIaTZVgh4LcbGBth6dKXg7eicDXlTP'
    'TwGtu2B3e9pGjgWbqOgLZpkTxmlk7THIZARmBfTgVQoe80UxHS6tUkPLh3ScJ+xaOU1+nRGbZsjtiNrROzCRztRAgC9cGM2iJnHx'
    'en8NtatJ8+VHxdahT+hcA8NuIlUbChMEKCr7TVmV98JwQxrbmLixIGoNMuTZLV8xQU1xf5dKVso4d7mbBac2eNF9A1UGn7r/K10Q'
    'qZrT7vghLNQHxKnrVXHMCnvPM6TlIj3wxNqyN2k7HrSqEqZczdgzSCezHe1Dw2kukpTIac2zsa3nwnPBOwOghLMaBMoHrMNfe+Ln'
    'ZRFbTFsZkN03UZGa3JdHuax6jlp334yTPu2qE8mGhLjD3K7oyiVkJY1Rzsuu/alL9joeHrKNqJ9bziz8QBfC7eKRiJCc7xTML9fU'
    'nKASn8EUrYnwe9SORq0g54LVcEqmWadirWpMTYnjMI+Z9j2/db/uWaVlv2/cn6x7GYZfPXtfUtZzAqXwboOPkXiV/k9LPp0YXbWc'
    'f7IFDuMxp7fDdiZWeGyPU3OhL3RD7tNMfiFJbMOhaj0fGXuSm04kQG5EstUkGUtY/nFw4h/HA5MVl9MRIP2ROYU5ZAyfIkdZIXF9'
    'vXPDHgIuPpOqn94LLsHlHiGR4tVoC8CqpH+KoTiP1zT8ebwqSZ2oBiAr79b03ZJ759+untiLdWWMOODjSX5bvD+amBsTm12FEzVC'
    'a7pauXQQ3rJy35BP4jFPRyYLZPF7olEX0ALChTuGxxCKS/ZD0/mJn9zFKBKmE0CHA8geTRh37aM+NUN4b0dP4BH2yPk1TUtZv2Uz'
    'aH1CjnX/psAq9zHAttPgc9pA2ySuzjaZplevIUZ0quGWTb9X7iJGthXZGsJ5Q+ukYKEdYovE7K9EL51p4HXp0pcDcc259lWt0g3G'
    'MjgVde8pe6ksbMRT4IhpgYenh3D0xVwnK/qfOO+SulgdkgIO1pX3PaphUCUX6ynA28PfwuBvUYO/Gy7SiY6mHVxgIhwZ9yne8p1H'
    'XsfBp1V7kQjN7ztRQNjbDOUYwBkP43PW9inzk2fD0+SD8lgV1oF1AefQk66yQiB0+PCSn8lpCq4YpZkplldgiy+q+5D5Yk/c6bB/'
    'VXOtdTOjbK0Ynk0lw1hANdUZsc+ihHKKJmeXhr6PWX/KRJGj67vUXs7SCG9T5pQRuRy+w+BUDJZxrBj/Wtxaz+f+VYGnD510olfC'
    'ziBqEXvntLxBs1ETx1kaRnGPGW5NGM7Hr8sUDo0yVH8SCp3tm4jwHyfn8REz/8c0owtid31jDQ8hPFl0lDurP4MnI2uM9BS3mk7D'
    'pTelJp3sKGCEOp2OWcmRf70vLM/dUihQZtXUOsbDIk80PqoQ9GoSUvHYGrlIjyNoeJf8IpWsqNd8VfDIy0oh/jc2jAbvXw2lwb85'
    'S4cLLsbBD6QOkbmuwqPJZVsaL9+EjTc4sInLRReALK4zI5AmnS2BPp+3nJmAnJvGgLoZR3/2SD+ReBT1n8vfNyIThk6SfIEi+JvG'
    'bBFvX0hmob6XCCg3Qeoyk8SvknuPkFjTRyCJXgKTvRgiH/C6bp8xZmtIPBkJIqXPJswg4UJLotWOB9q1sIIkynpywiDUhe6PlA77'
    'vD9q74xZyTI3Sh0Qk4PU7b9vViI8cWSgUoCn1kGZXo5A1mgXedTsTsnSQHGmxSmMWAQ0cQTtzkx5PmbIncNhXLyDVwAyy/QO5CzJ'
    'JjSKWCLkjTjMgVG8yqdei08ikmqkFmQb82VupdhV6tHCcaX9gyD+ASMOnZ+SK5tqWzZtRoLDPmsFmRLKOOltuCupAHMdmdnASGiH'
    '8th4+HjBH3VL24+aOdizp/CgzjyEIGCrPnnpuk1eKkI+QiuycoEgrZgrLDFt8IrdSHAeL1GDvlGKTUOnqylWNp7dAu1xpLmftirW'
    'HsaWoVJCjD6sQ+z1vAheJkKa0GyN5WXL/QKpk+9G6Wel7C8eOGjSVIl2Mx0tAz+LagCKiY02t58eSH4WffzlgENtVnMETFxygImE'
    '843ZxGUq12RTXA3/Kk++PYnxqL+6oma3UGkJZfnxqZPu6P0yvZ9r+2KFUip4P9LS+NWDFRD9GFgOGsfOsc3B+uvUy3K9yqPW+tLk'
    'fflbjgk1cqY9bv4tU5q6Qv5jZ+PTdIDxy8zHpxFa5rhDXk1uVTJKLZuPtmv66OW0cgXqai/V1w5w8FaJPmsyY8pUnNDFPKngIxtg'
    'TkoZJjKHPZkb7FODORqAcK7NU9+sJMvbzUrD5nw1rZvzl0Nf0ryaGZ+n9hCnZwT2T5YfBFZP/dokjX1r9pSF9k78VqJh46JVx4Au'
    'wxCOxLVMmHae6ZlOsxZR98JWuzB32H7+YWrfcUWSghivlJRWWfCBz4OrKYWXTNMFb7+07L1jyQc+T67X/8LgyjFOD0MkhELIwEo0'
    'R40iheN/alGMz6J4MJCheNbKuGchYa8oEGB7PCQoeOJfHjWZY2FF4tkxdQdFy3EM0wi4IKRFKxpM08PCpfX2c4NJ1gWTSphlBXG+'
    'sEay9oqCyw7AgZwN7L18L6M2+fiBvIELDLHDSWAclPY70buAx4dSGTplky3Yl2ONgCGMTo84KeLsWdPciZ5ZAx5V6wcQAO1wMsId'
    'zjqBAKpnsRjua+4vCBO022Q2fYAoCe/prGjoiQnIk8UWaDUiuoub53M54VVWcbNE4JQ256seLWlLYA33eL7m25PS57WF9qWC33r3'
    'sljIkI6t9gQibBBDjNjn8yDy/PmalFjySlwEbVystsOgYygRtHGx1rbhKkyJIDo3zDPyNi81jPR4aXBXiFj6NEaqeC6KN4mq3+R4'
    'IBfm1TQIr3++pqL5xRoL5FpocM5x2wYXLnCbs3HgpRcCPcO6zToYSqsqF6Ig58iSGwOpZ8OazIwr64xQwb03DhJSWS1SUsRZ9tn2'
    'P5xhZwAbfPQ5ah0Hx57je2Z9IVkMiFdu8rz2/XIHDBEwJsG3nvvmEi3dHeZl3zTPvei3xPha+RKsC5EOUdY9OZm2Eh9zbb0UHFNF'
    'j4xzUww1zKE3b6NlAxFlH3uiGjB7ROR53k7in4WQHp4kx1qNs6wmPu5w0YrRVh2IVf/+CS8TDPmLTLye7WK1JEig+hqLuMIAR6hq'
    'zD/8zL5WPMLQ3wJQBR+9JL96EqOTLb2HviU027RXIn9qjEQT/5MtkG2WZj8YeJ6OZjjmOIwV5wwL6SFOoU3dFAx8uyHkHORKxFIb'
    'zPdZfU0alxacopx/VZOUvwKvcXgojWde42w/p627/OL3OWemWsyZrzavuHzlsbg0SbjCKlKW3G1uJK6aDIzG29vwglxG61lOhz6L'
    'o81gs7UjdjT0985Gqc4p8zciNx4e7s96ByYDLIaNNzErbk6Z6RERUstpSliv3EVFWDnlqpo9utQ1p/7DhQZ20P7JgULooSv3SnoH'
    'M3R6zkzz/ehwQ18zj3R6EbyW0VdKy2CD0iZFe6uS4cITAgWzbiUDhkV/8VHJzPeZwVUW8p7bJ8h4vAzPO32zDr/IMjzDG4Fv6paB'
    'yl24chdS7sKV+7ZlkGS1z5j/f87/rq2tIvuYK8gWaVRsC4qCS4JoWoYzvmL1HmzI1xDcwddfyita/hourPfVBDc3f+edhpfBwO/q'
    '4eodDYFoGULqlQJaZtFqs65jRDNff4Rwn49oVCOTLlelSV0cjFohcz862bCLYd9f8PsS4gVsCVWxcdetPtHkC1T1oUlNDoacLfVz'
    'yysf4x8iJFAbdjn4ALHBYm8xZQPn8YwDPzQlZ/kda5XB2vBsrHeaLBS4xE/8cZrks2EhQwC722Iu21inIdkXeF64OYu4QN1CJjNj'
    '91SK/f6Zl9xB6KmXdfp+ZDS3kuvQSz0t30xJPymsyIQ4DMLzIU+O6k/mfZNF2pCzgPNwWavrvgYpp8MSPb9+r1y/59X3jlyPSbfg'
    'AglC3m6xcY1W50aaxxRDAnVpL0q58lKA3VSaMJEzQBIY9Uk08+7TRfDpokohS6TPH0It4duXxU7pT9o7YAPgI6aB+0hxTS/h3vir'
    '+fDLQUh4Ugnxn05AvczDr/zQ87/ow69V3YV6d/XPHNbdj9zjr9B/iDl6n10taUixKSKPPS7ScgskVt9uAwfb2C3j/eghLN2X7Gow'
    'N2HUESOTG6KsyFX9ia+YVY6Bc51CAGVDH5Y3c14YzcHtJxi6TQIOu6bFFMZxjFby82m0Zn67NTUukpK/tY7x8vVQd6UlWpwSDZbt'
    'Iz4iq+XsG7FoFlPO7/ng++8JNtIOEkD+tXL9Iok91h8Byt/Dda0ppf8cPXQ3/V6vTlEMa9X76lPglMP61ozqOlDRC8Np2FLh8VoS'
    '8xpUqEnfvSvv/oK8HU6VRTTf3t/PPdFIwrOaKD5jNvDmwntzYfLoeHL6DGI6tynqJ7MKFVGe5ceSNgo9BvoodLhhb4iN2qSr7l2e'
    'kbOaSQbmeJ3oo5rCspHMsV4vx4x5yMUJ9VahaZhYn3OMhDaaH5GLN3KOOMJurZ07bIky5jQWkkbJOd1YA2JrnXy31mWI1d7T+Mhn'
    'DYIYMc5ebsoyHu7BcF0kGpuyYdy+tYw7aPn2kH7W5OzbWynbDOzjeDkQmwF2DXCrthl5K7YZXfhm9gV0KJNkyrbb437SGSPIAHGK'
    'M94/T1ZDF2gOe3NWSSbv62FgpYcyy9Q2q7RnU2ovEYfuNePbOqFu8EBr+6BV0STpjCAzrcmckJsqFMKsaklD4Iznaaf3jTnFJkOm'
    'c5QUTWuDErFWaTNi7Y5R2mCrY8AbrC7ajFjP07SKHP0YUHhj7W82uabYASp22EgVN5Fiogos4jg2r/C+CbBqRbbJDrBX6ba+uyQw'
    'QD1F1bqLWit55frI63AfbQaKESz/sNScG/9NSMclsUpo/H1ZjV2PgqWp1gaYkLiWJlwlK7EicRhwUynbo5c8hW7lWle2Tt1EvKbw'
    'FWudBskhVM5V59t6RwXV0qtLY96IxAW5bGLF4VsKl2vOWDE2jFmhrQhW23dbs3aHYv0NDDJ+zrWepYikNhwaeA44oqxvw82jRRhZ'
    '/vB7Y4uMrZFZy/lPOFfuOy6arUQcFuC0qjf7Yi6jPilY5lHHX+hRsGIc8qzStgXhguZrnWG8Gxp+Pgm6Ppnb9RxHVJ/uO3Q5FOgx'
    'pryfsaeBZ+ZkLxzYY0QtuGGdypcu8TlJfOLMxiIZjJzUWH4jqrehD64fQlM0kfjXngT+M/XpdCuqskdlVRlKoMOBsZmfL6uMb6lL'
    'Gc9RpDi7gbHoUHryEwqUo9jcOqjm66hnXgR6L/9Wz8iS5krPSJph2eyc7aNjtn8+6nXOTIwYgNEP4HAOw5MLLXwshY/nFb4IIk9Q'
    'H0/1Wp5awM/qGWeAbBCwdDuOJlB5G9kzWKDZjpYRppLjo6MHjmHFbDdflbsKUL7SiGoqXXCl0h0wIK22tXFLq+tzr6WxMTmLX95T'
    'RiC3cUFi0RuNoCOht6I/3MSA5LknvKd8722IEG2+98oxV+8yTPxToCZyIUe6r4kk95LILwet5ItJIDFN7snq6uRcnPZGPRhdQbuC'
    'sKjR509vo+bH9z+IPXgqfKxE0Z8mtB0vEFMR9osm50r/otW5EyMoZOTtxHjwBnWah+kwCIM2m+KIoU46fSpUJKLnp2cpaaNJ+reB'
    'oyPlJqVJw5RIJH/IZ9OhumOfxSmX7wySfjawRXXrQyGDj+OYwBgPxRucUJHj0IyPw6/q/20+5yWOkABIGG9v4sZnaCHMexwkCjNZ'
    'psWegIZC69zyTUZqCh1LoY2SVztR4xk0UArBnSHro5oN4ndO4xwRFPty44AsZng4Nh4kx0FTBeepAff4grYgLiwa6wOTngJ3GfAf'
    'EpATXDhXxKomHAvMubgZKk4NcemXhEZNr3AHeOWZ1Q8nx7EloiEBfaBGSeeOgLKPvJxZk3PccTyFEAxWzDQkcUEl92P5+pMQpKsF'
    't2muRYbBAdsajNIrk/FRA8Si5tMvk+SowYk3OTuVzYmGXARj3giXjMfT5DQ78fCYsLEl4mNpU+QKH3YGcfuiHt0FlUv7yHHjc9kX'
    '3+VU2D1pj/7dcPzdHO7O0htbczf9jYap/uY8EsR6IIKB4Koq3XKIE1w/qjefFNMADoJP1zbMqzb1IpsRN4PQYBztSjz7UK9RDzva'
    '/dzse+xqG4rnPwOINRGALrn569Z8MH77fMvEfMwxmzm0Q8IhgOdFpLUhEdL8fXJm9hUisdHk4qGAx0QcNQEbsml61FX8QB9am8jc'
    'OJ5066L1Cu6znlIa1gtulR5aXmOcj4zLmJAN2VQucq1JP4p5H9W1z2OsfPmTNhgdPLzyKuVqNc7a2fTf0BaTCBAEmU9AzqbfvRKV'
    'dlTz0txVWlW/gEWigePYxDsalC/JlWM0O/nNYlb5ml5kfP3cCc1IaoL/ybWMxBzxtCvBoYEUJW1O4AIyFX5h+6+HbYkwfD86kfOm'
    'yRradT8H9FFncoH8vi1zd6NnhEuIUk5Isy0pUrrG9ITNVCZirTJUYxRqR+/xJTysWQ0OPtK2jPUhkpmaYNvU1Viulkwyy+vJ+Vc4'
    'dU1cKQyof6GFjm0hbo+PPi56JjXl+OM3x/IG1g6gbPwO+WnQkvv0o1ZAjhotjAHjhUtWI784PY3ETW60Teba5LXrkYFhW59ILC/+'
    'UoG9TgdTiZ7odK5bNYoPJlSi3QgdeBfjHrafftzwKIJRVpT3ouG/A8QVlNVdrkPYjpIOCAqBIthY00Sckla+5EvfrbQRk92o7OXk'
    'CEQpUaQjDyzRnZHYZNwNElAxye4wobJ2x3GPeNgMFnPgDyWUFeIVQIhrmhDIOStu2eFFHKWd7UHLE05Ef3R5s94oUPPYW1o5XE3A'
    'hYUxtctRqYM7UtaZjQ0lFdDKmSIBXO+Ijk+/+xDbloXpamL7yAOzwk2CL3MpDjVsGze4o8UI9pViLba0CiJhJx2cFzdHKjcB+RxN'
    '52sDGV2rpGBSHKKdsnNKgHyb5kUypnqNdDyZFcSRNfWqIKCjFl4eBgZhx6ntuS33hrOpbdhnBhZVOkkuoOSieolRHxM8iEx9JPyL'
    'jxh33GSTDpUX9c0OSWOThDNYJp0JTrdx8TI5jGdDCRTi+jdxAP0YMH5DyFDRkPwuEjX+b8nFLZpd0ORe3Js7MC8slAN8uWFPWeri'
    '0Q2EySFglNgcDpNwnAwnSF8+h8Epsh8RJrEZiJHQ5SNWF8kczyEs0WBecNiuT3TaGLbBXYbRFCWq1z9ghtPBkTM3BJgp+m9cFO6l'
    '9fG/PLIsselsiOl/1QZ1QeCFy2+KGvwH2KRyO3+AXWrVcbfnhYdSMz+XLdhOtToFUWf1FkzBheibZ1YrKrDeguGLVUNv/vA/Yvgu'
    'TX0rFGTXRJBdXzXWCs4SbnwS9bIzdh2aFRLBJHUBdMBmTtI+oS6LUN5y/8qXoEib/JHYdQxrde4yiwvG41ro/MrQeVwLF/HreFwL'
    'kV8ZIo9bdfFVz+WOG02cdSNrKUxsmN4xyYYBdCaSiuIVa1v19Pf4myIwHfcDP/6oW94L5deOXgcvVWezHD3kW76gqx+t5vE1/1J+'
    'HyKZDT1yQeNrcqIDhFQ40lgLca+FyymImKJkptPceEXbHnx2S2mErzDqPGw7aCL4bdt9/BEuRD0bxBuT4hfH+kL5A2WPMRNht5sh'
    'nhP76AQF5ZI3ua11Y1/kEDooHCSI8cgawrsRuk1sPoNqGHRj0w91VRgCXav8zhjogRXuURDOfNJxwc83vWAgD0ulXNjzTSujUCkX'
    '77x0FqnThLqugW/0rJNLhxMQGeXfZQwUYQQZny4jsUnmDGrXuNpASrHjLMuNk3c5H1nmXWWBKYU1XFMv4omnlKaOhFcv8fpSyoSp'
    'C4MDihxc1yPXYtfZW4Ta92bpT63rRiVBGgsk/eE8yeCQ2AmngbopFGyWvzeVrErpBef4qgVL1CRGiaNGMT/eapTi9PNbBpaevKX1'
    'qBmVxIgsDSzMy+QHYwYb7Yv7xBHRJuEuJz6Vilk2Mv2L78Dilr8+RQ7ZaLB57913l7FkmIo7F9fR2+8uJ/JICDw/VfPrnXc7u/u0'
    'b/eOk1FyMCfl26O63M1/jR4tTBtakTZ5vsZaITATCWbsbtxlTcyawxREY2AS7eWnTTXocBQTLlreZkPAhF5i/KkQXwYaM7huIcqV'
    'zUQjXlsx8VBsizlIDw8TDis2FB5Crgx1X3N0QxzBfNKaYAhiZJanBac4lVAizv60Mz92dF1gVBud0urZZMPQpE0kU40fCr5Z5cWK'
    'qUBk9sZbnn4n+pxLgArk3CIWbzzjTSG61+PsjIO4Iod2o46qjTKkwAqpFw7MqjyjGe/KMo0ICOo7B2lw9fbWCPDVd1nCKiZHdXL2'
    'JJYfFn8MklkeKiCmYiYMh38OTAUlACqUTHmSjkTr6/CIANt9TfJ+YO47fFwnQXqp4FuLPCkkfjZTWP9QCnMusJPRvF5sEssDRwmH'
    'ueQ3M/R+aZjbDm15E+aWORz68lFW6EU8AXtIq6JL9mZQG3B0vGjqnMrQG9C4kERcwMmlsZs9l6uGvkU+RskmxjFta3ofntwAEh8a'
    'J9q59rE0PAmgEWyWhUFWVdlR3yuiBh74Z543ZdpopkcUu1WwX8PTcywX0NKuZkj2D7SUg/LCoCFzCtyjBaMU+yBvnAWrXkpmQ0vF'
    'kR2wfKqFx43Y32anfCdjt8UcLnoZF2o6VyJ883aHKzboDdWqbpkD3OMCusPuR4/Y+ti+S8WeRVLUenbBvrBuC58jBZmTzO179up+'
    'LGaI8krsyro8Drm1p7G0mR6TqGIbZ4nFNWnvN6iar3HkrFzKYeldi8mlVEqJ52k8mG+bmHImOvqk5YQONiA1+bS7oR9vDZkJRwJ4'
    'JZ14aPQ9EkluWCy5vL2xx1CZmK04MzX8CrENd5zSUo+jenyXcpZSedG3+cPNpOnG6Rhwzx1MxTXYqbsQaQQnbrcc+TYSFpxx4YJj'
    'ikOcaQge8HS60cTchMGrlIMKsYFq2tb4Ufr34qC14GasLRYrXXPxpoJPMCBjZe0DNdDnlsdKxyANNQ/xNfcRFr5UXRUK4fTUNTLf'
    'tV2xKkdOzY4t44uFuM3yQVpayDJg/mWWwR3bPtvs6EwoE5RZCrzrABSilQQ0DJJYMZjLnEIC9ukFv83PN5wELOUuvHL/ZsupCZQv'
    'ANee72UaOTBxOkxDwCcXy5dlT+/DRTDZjlg4hTRvwJWdXE5E7aEPFa+iu5oJrFfbnCKHTVe5sNHZayg0SZPsRUOTLMmDwHgaJJTD'
    'DcDyicORv5e1MKEc68LSe2FvOZ+JMwIlDq8B/wziWqe4h0j9CNIaY0+zg7OO5q7tHxcQVvvAIzApFQUY2WSPzzQYtVBVKk5/TAZF'
    'N2YT/XrbfO7W2ea2PA0UvUUC8aYnZRtU3u4IqpYNxXWgJdw2VtM0tMKcdKGIiJS55oXuf7WJ+V3CcXD6Vxjam/jY2q2o57luog1D'
    'pW4SrwMqw9tZ9jLWRqgw+8oMOhWzNtn7dnFL58NcdK/BdR/NnVWQhlYfsAeC60ghomD/lCzHRUFCYDJwhNIe+PUeFpzeYeCj3F2r'
    'l8HJ/lsiAdDDQoYfMBHWjfIpl2w/eZcNRRqS/hWyDV9fljeAWY7S5dzgNpdzCwy9F5L82QQEX/bKTceDoOgtyp8dJ1LO3adVbqFu'
    'JTcSSD8gTuO7uN+GFm+ZNsMRkZy8P0UiFuK8Joi2a1OfUDmcARsIwSJRvYiDG3MExz4ic/PAWoh1+8///f9eklai37JslHe85A19'
    'vYlDFXAm8jRKiljZND26lsG/DJJhEf/DHlPu3b9t1B5HHpG+4e6rLXay1RsvtYet3G+5nX6yjlv9YTxCJAU+hdREJDmfNJfNAGEx'
    '62a5Ld7+MIVdXV17BJtG0W8/CLXWHDyqyf+ae7f76NBcqXknNgeiavK/5uKtrijw+WS9qsCGgdYEBieniTJlkVw9rkQv2TRADGUl'
    'nYEhrYipKQmGXNgK0SeY2xgpCNtnfOnkkxSRcWBSBjoMgZhzIglRrCI3aCeUgRa/a+9Ya7k2Jg9CUHkmi7rg4D72LnsehXYtLmwu'
    'm9ywG2/RgedcxsgHwXGP090nUwRRSRBq0fJHh+XT4JCPDuGj8h/T4tiYZzZKt6FlFk04CsNEKIXHy21niClMQTs6hAloYGLIDjlt'
    'CAiHPrOOVX5FY24eKt9gbXFrqB8dJhW2eK5xDoCz3+l0RPidsKM7DFK3BUY4MPcPWgdy1cIO4IsgY6E37y7fgkAnejjvhv4kuRCn'
    '+zm38+P41PKuc1LT1TjpDurccxfdeLOKyrBRnNqmNrgyh5eQO+7chpGQu2rOXWji+Z3CwGwAhvgUVmQDxE1NphMbWbWXN6UI0yAu'
    'cu5xddKMuU/kmls2sN9a51H94Ex8Nym4JPXuSxAeEw8OJZ4SfNiNdsDB4OiVdaIdO2sal/vS6LA4VFto3OuZToqeTr1ad0cZMeFD'
    '5Pgbc3jVYcpBgWPxvkkG7KAaBzk9+tmIlgmhj/keVBKu0apxTg+9uT5G5mo6QSd5SzxXzbFc9V4NrTrrM9yUw/iKWyQzjzVbaL9/'
    'jjBW0L7DQGubzjbjGolMf87hVLmuUTpYjp17b5yOGA9NeBpiu46TeCDO5tLDra+gJc77Q1gaZEXBlyWvCZNwIQQQ5Y1WJzs8pE1o'
    'b6xhpVln68l3+9Yystn3zTfEopNv+IMSS0EJ19aFbYsNOvu+CYe0dbFWLrEUlPB8Z6F/gS3pMAOtbSOSK/0Tn/O5c5xCRZfRrqA3'
    'CB5IIt02Hen0Z0kK6a00lVmi0vKsgVWzqAedjLp6cW7TiOgzFX2qDeFfbr+LnqSTbe2KXnQjz8mXRXUeLVtGwAJiBGMCGlRL5XX5'
    'esGhzfirLJqnojhnZg407gb30oANVUid2/WBCscCuD3HVflf9k9eZyOCm5yTLWOWi14ATsAeD5aLcoDfVnQkEo3RbW32DaYVWOTB'
    '2w0dgL3aC72Ir+8Yj3LouJ+zD6Qx1JPsXGJ3QBu7Jx9xF9YctzqHZzSqv8KND8ea38obMeKd105qPt+1vwNHWa89MQaBfFzXkH4T'
    'hrqpz9TUKkKBIUr/Azb7rTa+gKuosTqsNy+U2MzaDgF4eiEWARk10sEtYnecFc19Mfc9aDE7FdzYBZKHBPXMRsnOUC2E7VZw2h98'
    'n8D34zgeD4ZJbp1/aWy5HWh4GbHdIZrIl0yNVk2T/AXIQifcolbVmplAWdeB6NnhEwEL0prwg6NM7o2MUMPtqOQmdJkBbIPcZ6y+'
    'O/HNMOdxWjyDD8Q3soEuD0ouzjjNjr1Gq4E39RKyuHylhmB3b7MzKGvzxHfaGepwfps7lEBrDq0AjwFqg6YNHGn1HKa5i7nNSQtz'
    'K+a3G0dO8sozgQZ+Lmgwm9tgxuCdWzG53UhIyCX+5sOswFUeD0jefHz/Q03j2vbK3LZLF3bzh9e7oQkQvQXV0xuqC7WbP4NN1sbp'
    'w9KC1eYQiGtz21m+qery/LqrjfmCCvvwp7BVUtfywMfP11+WEncqBSyl6+Q4nMHO9ab/ap2fmieBglv2OmsvI2NurZdvVkCpG7te'
    'D5tbPtbddjWq0NlUKJYNjekbvIGcsR2smRJiXAYj2o6aNZlIJcYmTaDRaHGY+a7noeVD6uRma297l2mkuEALeivS5+ctr6//UjLz'
    'eivwPO6fsAZmATaFiX7rW9aV1KdoPgVgX5pFU3TW+uG9VmDspHd5gZ3CfAuC69qenk2n2dnb5LCYf5aQsI2c5qtzxsotfIJEsbCJ'
    'm1r4PFlYnfhku5Vr6+MS/qYWqg1Uttxd/4q7njYMTewUXUi+d9d7WEm3LH4htBfmKTjo0ME+/AsfIqz6Naq9Tb7t1fyCojNkZ3lO'
    'X1Rxs9/jPJacjpkkxzFHtDGcCp4wyRT506B5xDXxUM26WIM4lsiE/YQPwYF+Rn2XYcWLdEF7fy8thonncwhyUOCdNQS1b6w2iHp6'
    'D+HEGuHqC89Vq9OU2V/9kmfj1ncrqfXbUumc01PatD98a865fJojATWoz+cx9zsgMTefDGldGl8IIRBlTzyVnNURWrMJgzZJODFD'
    'C75sMcWTV5IXRXBQwvcSL8zkrsHxDBDpRUoSK77MkSD4UbWM2vzX7y5Lza37rV1zU6aMjgKueWyM+NWJJflwdmQFiaZbFgfR/Z++'
    'nH1Zjg6WVo4YlIFbHL+jgzPk6RiGsgzLBqUIZIxksBJBUEuNf4nEgdAPSuA7sertomS01olef9jdEx6TDp/TNGZ02xXkfqmZw0ms'
    'k+ykw3iGoDIIbSXZAiUyJmI+RLuEkyRY8h/C35UI/CywfZgdcf5Rzh9POz+HzSR6X+9EL46n2SidYTdAZRrtXpAMM4qe9ftJnkfP'
    'Pr6Rkg860UdOYw+xZpjFyPLHW4KZ9aj5Kp0mh9m5jW0fjLVrxyRXzWwbKMnu+7Hkl5R1AigQDiElZvess/vxzcudTz/jpZHkqP7H'
    'lK/I7nJZoj+N/Dg7Q/sYPj6CV6CBSiOm4oQ/7F1MeFvsX0aDJO9PU85X0Y0aCm6zjMi+h3zYXSJpDYjUqYxzBdut0Y32G0p9Ggc4'
    'JQ5ML6/evN35eXfvw6cd2CWHuNEFuBobrG/Dz48xOwiLqvUsntLqvzSwrbpcuNvAU7UsALkd4A1UFRtIw3QGIiEnrbNVt6993Z1I'
    '9LQPtoX0AJUNlVHSwATOAsQL1M7MyyYryagBNAXztPFoQciLnC1D2vS9uLEUp8MeyV3FexlnY0wDwMuC0zoTM8M2k+habHqLsDi9'
    'aGzw67BC45///t/NB571ppuoZkloiIUaTdEQAOauiCdojkdtBPFuCsy3o31qR9MmWTNyCxDXgVoHgAww2IvjNLdghfbO4sJ29PXL'
    '+LtL83z9lV1EW2q2LCAzzdpRYE5RQ0qitTlruj3vi1BkhIlwjTRC4tMwxwB2XEtiOPDOHe4W2RQXS7imIKLRdOjfLptgXVqcb9u+'
    '24q/HILcxmK49m3bqWW+yBlz8Ym/ZUTPEFnbAzdZRQ1/l6GmvHhtqkl9/55d3DaC7WOoXbM3zHptbrfsUjAPnWNZurhDh8HhnGA6'
    'aBUceGfgdr6MPYaiuq8G+gSFvXSUIIqXHGF1AU2kI9pl66urq55Kjoh9yq7Ne+J6Ky2UlqfIGMxiKCfwXbPqM9uCrY0L1+c09uZ+'
    '0HqzddB2xnEVuslKs1LEkHiSNieMFb2MtbyX12UHUgkPcpgQdmjRywjJTTJEt/tIONlo8xVAMs2ZXuuGXwaxb9SNgw7zfywLji/v'
    'EQxB0YHbdLzTA+IhYywVK0K8bAUJAX5xwUs6aJkYCkZiXSVC+oQY7Wm3vKOYvYQPMqxJpjM2w+nIaY0M2Uc4Z4licJALYXwbJmcA'
    'a/imnewEm/iXDrdPe5IO8TNelR28aOoHlEEYh7iY5Vgf3+H2l41q+BZIu8le1pSt4a/DmZ2pfFNM/pEqxDZEmxQ463AzTYsZLLOZ'
    'b6xZs1jNSKctyhb397bvZbHLVLqhXMd70d1XY/ewasqLKogXt3CfcnFpDJ0DZ2Hoh0sr49AReNtYoX9XcrnJv2Qa0/XIHK7Qu1Fp'
    'g3A8GjPzqU562kFdq1uszlkKWp2KkRJe6zoZLz+BsS6iV8CPddMkzGjZiDf00CHeOYc6GOe+C4CDaWn4IGbW5L6NsJI/iKLH8y81'
    '+sE5i/Is/z3LouRndkQncyFxKAyNp+UhKUg4LBJ/OshA6UlO265kl7n/Jh9shmsLTzRZeYcD0Q2rvRznvOB2YAvW2o8/Pe2IMmJo'
    'XBrmYEHN8usXje5901IuUL4pAx1Muh5/5KnKXDe9ib9n+dmDA0g/UWGf275u2eGEw+aln8rsVS3Ry6YFU7BGK9CzXzMPpEexR1ja'
    'ru+ApIRvBT4lFptYJ/NboezwrLvgG7Ao2tNtQIdDLDlTsugim02NlAdnLhasJE17rTwn+F9h/MVouLKJRHdu1QgVxF2AsqjaMNGK'
    'AxxElzoiwkIJpVTBxrql+x0YZ0W1D2qcUxHV5m/E/eMDO69qE81Lg3Z/nFhHLAKf6CrfeTtZ94oPOhmY/jmGMQMjYUu0WsDS4/B0'
    'M4Fk/rUNAYGDZcqW4xVr8UZNoZhrL4/60I7x0J0xtrZfXtDjFoy4htcASWxHyBQ4DY9Yjl8pWjsNtFMY3iSS8kro/04cHaKzoALc'
    'h1i8+PvOp903H95v+E2NUhohsRxcsOaw85X2FnUJ8Ygzor2QHUbvk7NkCjAxrHWliULsecIabVWo+QaSv0+sDmmopzJImNaEexwK'
    'E44+PpsMkDTKWR82tINudG8PEeZEj5JDMxJHeYCy94L7gLkH5eFwlh+bG8qSNyxs/D5KAASvhIQ9goG7MP4MOVXVqtJQcivXefks'
    'CDYsVtTPhkMjTdUEHa6R6gKW75gg8DobJb6breAFicgfRE8mSj9i1QW6A5PCURHIrEqTFU+Gl0bUUQl+CFZZ7ABaLGZrq0YryTvJ'
    '21/VC37NAWCtRH3bSb3ZtlaT7pUJr9dobBjDP99WkckMBy0QzdkA9oKslbMKoZD4Q/DG3Q61qzKHI/ti1xkIJCRbtREnFfKhi6OX'
    'B8q6iI7W00QjInCEvbiHyCcY553wsDkMd3GgEjiqqARarQ1n7OiJ5ocd87Dhi/Dy+j0Lw0bNddjhX3wz49QFfuokq1AkCQtRPDD3'
    'lZ/+hMFvNjtLre9WNBVCBb53746s3YAhGbT7aToXRhW0W4DICNFr0NLbzoDBY2NOFJWO3mV89QQEiXn7+dObF9loko2hKxjtryGt'
    'PJ0Xx3TKT7FUtzia25AuJUV4+TS2SVVVk1oTSysh9E9mzHU4LOaNzcBW8Ue46bpbnZo7GrmH70YISyyhiKGe5+uGTK7rS/cxGj1m'
    'mPX2sudEKh8/hH0kPRodw0fopgm1kHrD22ZTDTSMpfvEkj/fOHYyw0QJulMtgp3kijI3HO1GC8BGaYT4fJabcLKqirkWDb7oq8c6'
    'JZCXFJEFY1G0M+8nenWrsDf7R5OiI5twFFumtVMnFO1w455qqR2d0Hot4PJuFE9kvKF00vXaNpKK1PMhLwC4QWRRyWTHQCUQTgKr'
    'pEWSyspsfDLGhVuTDgb2PrmScTMf1zLSnI/QOIxfoH3Rn4ImAbemCR+pJeaayH0yjtkTC4UVJjAUuZFhrdP3eVqIYOLKLgXhEyr8'
    '12R8xIqybMLJdUPt1kSuMnDQUDkOEkIUmw+JNjv/gjChZkceYPMgdcAcQoYguJjwIpGIXZ7gDM3mbMLWybTpm3rhyk21Qs/hahin'
    'Ce8jmMb+aIwY+0k61ABI+Ho/Wm+JWa3/9dj76onwHAD869P89Cg6Hw3H+ea946KYdFdWzs7OOmcPOtn0aAV6yxUqcS/S0CjfXf54'
    'fU/jguLpNT3B8vF5do5HiTBGnV1HeLhwDz/iHyq99d2lwOD6KRre8tKk1kYrd7HKG7xNxFCfai7RoDfoyKdjrticFYfLT9rAgGRc'
    'IeVU3dOFlWOcy9uAsrH/h9PvTnFA25Scu/FhPE1pWrBGNi4uuMrLEY+M5cq//0BkZpRxrrv4sADriA59e2gJK6+YJA+ESUtAO35y'
    'OHeruOVo10Yu/xHBz9FIEMH8tX175zZxzJnUNAXRbcB6pFC3W8O9BUtznJDcJ4leOCtuOhxy6FfqQGPuFBJwp3e0YUuw25XEO9fh'
    't+2QlRrMjaZeU8GpvirLiSjlvOlpMf0A5nX0wbNdq3qflNl879AQTDLUBYoQp+RCZ9TzRPx6Kl32s8nFLTt0h45ibnyaHsUItGm9'
    'X1Tbuw8ovDAvmfW79CffdWOlM+YgdOUEw0CjSiUru216XlBy8531lPFpnA6Z2LOCEhpLaF/4AKd2G86bAqYfZ8fZ0BqAwJfFZFIx'
    'yVoiDYSGeKdItsAXZm3jYpDzqTMWTVCPGMGkyNscKxwd0EnQP+GDn4WRtfUoa/C7TrTj8u5IT1GPdumIs2Vq2+YOfIJrdr2rscHa'
    'nD15c+wMOEIzhftfxvQP2ypEuIGcmgg+Bk85xvx2JI7GfO+3zwt0wFd/5jdMMQpCG+aDPiCWkTFt6Yq7BQsFAhZYvljI0fa0cOpE'
    'u8j9Eg+7pcxBECXslAFN9FJpJp/1LMSbx+utTvTKxd3IIzjU0ijSKZvt5BJI3AC5B4iTFJPDCzsveLzoxFTWcFWc9KgT3SOmiKjK'
    'PYwLUZqI3sKhhttgfxqYTciaLPucrGflIw2CU86tj4yCfH567GFcvDNJzSWPuQmysh3t7yOHOckXB7hfxu/wm4Srkq/7JtG55BTl'
    'WnL5ZPGo+b6ZtcRaZWYtfjg3tloiklQdNb+71Mfrll48h4HcdN7PAZk8sCYYeYZG7WhEzDZCa44CsyD4At21lk6S6j5nJysJTMhJ'
    '2iXzPVw3Z4U6QattZn+Wwz2HFWNm41g0dOzULJe46cRFttmnEGE+6ERhgFCj4nEt6kJTAIva5d8EBwezMRsPdkXOw5rZMv5y4xV7'
    'uWEh2DyA+wsuCZVMcBLJAbKonsL6rRcjQqD1F/E86/pQJWVwQ08GJp0Zj7sxTGkwffD22ojgbpcb46ye9JYvmLTPZr9ju0SUSu1W'
    'VYj25OUlM3KGdMWApd5GUGBU8+Sd+GPkMp1gpJB3TzgDg45wNRjWCQ/LMy8MgqyEIxBx+1LXybOou64OS3Jr5S5FkxvNqDIaP41s'
    '3axKM1ovT2mtfkrrTvjxNHeM7zaFlz/P48ocGx848IbSq0a7ZtjeoA8l82KS5CVEObSIwkmW6od9yMNe81bCES/aMJof7JkOBhaT'
    '7OlBR+M7YqwhLYmjdS5bR4R9IT1dsVLqRJ8hZzii3+Y23Ikq+5lzbGoeMdO0LbNhON5YB06Hgn7SWBkSJlCaitjDSLIg+FFSaeB7'
    'mWm7eVyMGOYybpuPww6LZIA//elPDULNik1CxmZMYHhefnj3EUIBiVGiBHtFpHmXLQaaX5/CYIBEkDxGmo3f1J8E/bZIHuGPX+ms'
    'BshW8JbObLx0lOP52w8v/kY9rfzU/Hj1ev3q9YOrz2+vPry9evvmir/9r58/7O1cffy0c7X37Plb+vf1zrOXV3vPP7z8t6u9Vx8+'
    '7F3tfaKXV3svr15/an234iUZyPvvJEwYkSABAXgCWjPHUTT3v3z5ev/n/S8HT7euDlrMWHz58t2ab2d6NuXkbcgdXLTCyLLSKgi/'
    'iXzvYp/6/rb77SiGXyISUOOap7BquyaxMy0aRf5l9+D+dosfVYHnItvCUxH/Twf6q2ed11TSkxwt4mSeuzECjeSgMXH4y0SYK7SC'
    'HML9Dl7umZBH8Ivt7O38Y+/n9x9e7mADosWlTYGvlv57Jc2C4dEkWrt4INsEBaVu7ppudt6SZPPe9FSfcpTTPXSK+EjMqziWqVWH'
    'CSCo7T5M2t7z5HxlT6Gm/WyRrw+7e58+gIk288J6Nxv37ze08WbLNmFNxLXqG7+dnXeVNm7RxG5pKG/+tuO/ebnzttzqf/tvt2j2'
    'BUGw4Yw6+hKNtu9bC26YZs3e4EJd/uNiJTe+Nlgz9fUrK4S4DNjqr1+Zo/7qv/zacEtcHtCzRjVLuVqNscD8rKAN1JuRmNXAa5hS'
    'GjNMnavH7cv/SsNvSnkO69dLJCsQ97ANG2vh+8AD4p0wgGxMZpvDZdXXfS3JfneM4Fzo+kAretbUzdaX/ABoXlWRtKj9MFt5De68'
    '83DOzKGxrwoQlle+3t1Hv2X45NN+w++h3PLzTzUNfxnzekUR/ahUJDr0+Wr383P6/8erd88+/Y1okCgoi1alKV0OjO/pd5dFaDB+'
    'TYeBFqADoOZzOGptWmtsVBO78wEd0DoIPNjvjjlslX2S+VwU7tqSQQmFX6aBw5TD7A6FXkzhS+qTwmFqCI34XL1905hHlqCEY0JE'
    'jZk6vBof3jYEA9OlpesOyx3LCKg36zFqYwK8oRpArSQumtJSx+avL2eDlLiSiNBBw3N07sCIGH2A424tGffpK5sX0brjtLXLbQlr'
    'y5EW4TKY68IseMTXonVMptBCKtGlcZk96p0EYzlTx2Jh0mtdf61jS/uSwsBbBoOW84bnDwso0ewzTFt1SCRFxafii9pfexjF5n28'
    'cmVEgh+BwpqWNXBdxvVvo5g2WgcslhasFUPBYmpncWBl4GLgmta8Q8lQaBvDrhj4J9atNB72/oL3Zcs0iD8ef/PT1f5PX74ctL5c'
    'cRPfrX35ctUoG3rsoxKLds8Qmbvp0gO0o+YSjS2kP/1sKHbsIJJrrWiZ/mEBlyBC8NAF8GPP3QUgSxmkXWogPaGGuZ/ngQbDlQBc'
    'hq3ZES2rubcgn3pj53aWXenyuCzbZscRdkNNN6fGASe6AgdTwhyfyphRNK74dKxW5q191Qj4uX1ecnQLwbNtKrvxm0EvL8Mhp9oa'
    'T5eHLT5Da+L8hGYJHefiOWt8cuUSy6hu9RGWYg7ZJtK9U1lsqBqIln9bWThU5moWUeVcajnNBPTQXssmRmgdX+pviXkcai3ryBw5'
    'Sw9VsnEpvctg+rXcKU+x2VrIdha+oXkd11mzU/V4/ujxZeeaN8tA6tyD1HlrPjf1et1nEl8/qGGuvKbtl3IX5kg/BzNkpEI+rMwT'
    'EXrXCfiIP4kPBej+ObtvfL1/Hz/v33eEfd6onUDX8AYhaElrYTEXuOu76wl2O40fxoH2eShbsi+G/jadyxaTHHkDV+wfXSZVXBVg'
    'yioTV/xVjjbDAn8Z06vGgpX7/NZfuQ9vfUiYc6yxYAavPzVqFrDhjA4YKEw55jXBgrTfiti390ud2s9EbOwaBcdrsFFqGDZ9pZWh'
    'U7B60OdZNkzicbjmzqFDuIy3ysepXR5RV95unGiuFj2g552w394QWuWQcpfVvM3DUeHrPHwKyPqskcJrNGjUxP3kpFEljXE5cbpo'
    'kpDnfMxRW+WZI8qGmhopIN+hsXGqn54XfHiYYgtyQIHww/G67E3W5nSNVqdEwSTeNgbDv1z2zK/335r7gu59vmeWAp4T6lcvlZ8G'
    '/PK6Fz2mh1CNP/GJ1lOjnkYNLgbDD+qixz99YwPrNS0sbsKVjhzrTTOHMpHP2WWvuq26soLcFyd6R8ariYwdM1b/yXWNVQFmU0Vj'
    'DjdsbrPTqdHvmcQfJG0iCptc1gQrJmxOzQADqaAMjGEahAjIfXLBe0OnJh/l3OGp+CAUquZtw6biJm9CJnQNJY4Bpavvl5+1eF13'
    '2rbXXEVj/o07rw50Kmxtb0errVujssWfTduSDXcl32wu38er4E3nIloA/BJeyTD8fVldtUjgKvtUGylvVJRrNUrNerTHa7WytgvI'
    'kafsjmBfWYUYyA9Ijx1rwwdFVevuUWb/xL180L5WgZE/aTpRwTfV1O9ygAI1tovzCImM2owfiHOJK1exesW+YzaNY33/kGVHJOW9'
    'zPrwGv8xmw46lRMBLXnJE6GwZtVpW6yaN6PlNc/YYyhMLG4uwQiLNWmTS8JeEXuQW1iiJp6uDNOtpyuz4VZDYgQtL7OF58adW2P2'
    'ohMFsYt8Bby/fi0/C+sNB8HTydbTdMudBk9X0i06EJK836ziGhQ8ky3/ZPA2011HiUI22iQXANZQzeO1Bifnk8un43X8Ikbzel/a'
    'ObBHGPvUcbAPA1TWPsVH0DjJAHlHidZJXvOIiYNlOFx/3Sipbq69QQtZ3eK1aZVW82lkzwV/SWkxn9Kq6oIuLZlgKpYSyphN3Y0y'
    'NkhdqWE+eRMxFBq32GaVvz4dpKdbZkJPV/DkuVBf3/EB5fYbWjcJmYD51oo1jjqDrH8uBgu/pZxz6h/v3oqLTyd6PiNmLepdsOF6'
    '1IShMBygaNdko8k0yXOYkMgxBhM9zAQxO3GDRmPvTeNpimZgeM5GBui7HezE5mzC5qy0iV5O09OkxQfrW6qbfDg8JNm242xoX3x6'
    '8TOzruAIm62q2Qhuqz7TZn+wLqL0+iNJEWnTYWILr25EWFH6Rj8kHyarYySkqS16IkWR/OAJ/UFBFOlHf+EAIKvnOy+fP3nyYH01'
    '+ok2b7S1tRVxgA/9uREV++MDroDn1cCPEFeOraZ1Pe5P+w8Q7bp3URgTYDOi1fNX+r8Nn0ycY524uIzKQmafhvJTRBLeX2iCjw7c'
    '2J44x0su4hpu2QF6HDKhAtsxqasXm6x6wE7GfQU37Ah2WP0tQYoRAJiZ6LYEzYyH+iSpfPg+EQbm3vVakYo7e3YGNdPrbDaF6cXT'
    'p9HaWnRlXr+jXSuR6ujDI/d+N6FGBnjPUHehNuGNssnBKNlXiTiuf0tiaK2Xo7Xvn6xyO99TO6bEO6IMx3zSrJX7cAPm6zQOlsrY'
    'cafmkhoAK1FssfUnmHXkoqCpXkht49oD8KJuR545Yh3fr+JUDeqJl1BXi7aBOsAxIJBzDLK3K4nYiSPiWZvY1KOWr4PUKMVuUWKO'
    'qIkH3j3PZ0hhx5WdXHgKdxjZYtANUptBBh6L4adKYINTB/EIaEjNB7A3PF99uPrgYe+R4cSGpuW1x82H8O+3Gcf8L4+55pPV+q9P'
    '2DjBG4//cQ2fUlbdVGuurfNi1Hykia49ZEDXt4zvT2QlLR9Y08b6+g1laBDrj8UYu1RGI5zSxlJe2tjRVxa8byD8UOC0vrrmQbg/'
    'F8L9EMJzvjypwL5fAm8I/H4JvgHwg48PS8Dv+8B9XAW+/x2DrQNsUObhDWUA/Cfzge+39ZBmIiQgLCLETrWKnlF9ZAgGHe4PVtWi'
    '3t3teMMK0/yYgK3aLp27M+KQmxDAJJw+tM0dnAFvdcAm0u7C7by+Lps5CTcyLezj1UdAFgucJFx64QhKAExKCFBXqNQZMEEIUrkN'
    'XewKcD0LZAnH0el0eDuwFlwBRFO3YTk0p64elaMh0tNsRnyy5t717V+ebt3j69u+xrFo/AWRNP4SjyYb4G+f8tOw4IctfjiSh3v8'
    '8Osso0fiVPscHKdkgAy2iocLR8qPcqfrH6E//vx+F7KFugjk/eNkFOcdcJI0ZBFgcnYZOCOmaTLNEKqKjoTRED4Ej1dgi+hFLPp0'
    '6+YyZqteqgG8NDZNhuzklSNcutfqdDY29jNfn551p1v0D4O0y3ERN++BCUympwm8EATSTebAqdgW/p367gi0aDGfRzBjbyMAtBgS'
    'bnJIHu1jgj4mH6ewKWJz9215LbbvZ93TeAi/CP52jTSxoo0mEQBtcddSm8ZuxjLxRzFKBmnsW15eKjmdpuo55O1CGMoT0D8xHJpy'
    '5rI2QOK7Vy6eUYw78G5vuWVMcvpm8GZ0xF41bcMVfGWDZGLorzs8hWu9HpdG1JSzMr5Q42qXRkdLPyddtQgapHmxt3lv9R7/em5/'
    'vbW/PuHX1lc9v5fQ2qRLI4GmpM8+KP3z63s0Wf55AZijBOH3x2mUDvB2TN8xxs17iugRv5OC/fenP0zjyXHa52DatDZP4+6R9+Yt'
    'X0qNsxfsbfosnyT9YvPeGqqv1Nb3x2qb8loF8Ytm09T63yzYDQoys6vU+OLe1lP61Z2gWfwYn9LEMHI80IB05qtm2uqoiyGbEiiP'
    'GfjV/YHjfW+YTl6lwyHGjt/RtMtRHdEgrTa3F3eJFURYIPw0Lh5o2PuwEjRW7iWfCMzPD6cj/CUCEJ3z4C/wL/cBLcm8xV5xVSfT'
    'vPghyUYRfmzem9JQ7uF9fPo210GZIjoq6XzFQNMf20qwYFvesyy8YDCTEYvYjqR415omK07dDqXj8uO0jrjQvx6xcPu8ZpNXaUjv'
    '8UMV1sTra4vFzid80LLlejMuiPTTt5JLph42uCiMpy8kIcxqy09MkxY7oxmmctaOjjmLwY/87+uWJxlyEiP+0r8wd+acN7uJt9H9'
    'CGkSzlTXSkW2tIVLqeqV7yPYPj5SBZrqhjSIF9BmWPMAyWahl7WhsSysUZiItTlsxVgsXFUjDucCMZe1mnBJHIeIARrOFH4RrBBv'
    'dTx7crTOLkqARa9CaMW1zSjB6MmzNaCnOTYGXloOATT8nzpIyEp/CNprT9afMIO79uCva4+dB3mMsOxUfz0dk+y91nmUjv2xiFp5'
    's+aqBkhHn+ncQtYrbCpc8b3hClYx5I6xgKwrWjcNsjXVc6/VNj58QcIdz5mPnaKgkMUPNPzLJIG3lNkSGBUOcKhKz7rsUEcEdx20'
    'wNr3fC0bD4ANYaUhlkIAD5s71TR+i7uO3F1RBS+4vtnDWlc8H9RbR02rAgOwNwbmorejIT14vIpsYFY3r+4DT1SkX0IBk20Ftrfa'
    'h97FcGnWUY1nRIIhfHfoqLB9sv0rvES/X11/bMZ9RtySTZT37CHGeZSO8zvYI+I0ruraf/5v/4fo3YxTeFkTCw2JGuW/n42c6Zor'
    '9Yl5CDGY9JzELWcBnS2HWgxUunxNJL0YZoLZCG7n2umEpoiB4S02MdsfZDgVSw/ucZ1a9sZrJJjgnVwyuHzgke0Dl2hQ+iXsy6R5'
    'FRQBOPAwaEQSo0qRs7SwIeDLxsOLqIhPqPzH9z+s/JePOz9wdiAaGTVVIParZDOGAtZRE/RAnFeuwhHssVp1qZ7YUcdP83R3bFTo'
    'oeLYz/7YxhHAuR9DFbypKpbesBZbeQqqRaU37zX3f7p3sNS6t3LUCi1bzFAR24H9bOeZG6ajkmsvvVG/XvrXlJVIFsZP17npeg6H'
    'VfMX7Aexbln5yVGVLyAraoaHgXn0JSxGxGa7XJAJkOZdsWovb5wMbFZ6l61YbuWt6/nq0izHMWFSPOScSIHHrvsmuY6cXUzVZTfw'
    'kRUXWepHRw7nVxNTwXd+3VC4MWDKxjB2aUm8BWAgrjJh71p+QnR4yn2cdcuT4YuS8iSsNGDu2Gh3QV4hkXFCeyKF/lYDwvDu5F+8'
    'm4Qt5pw36TTJ3X6ZfuToRKEbwbnnRCDZ8PrsPnYuNxrEmL3K4MBNB0reT4n5JnDm2TDO79Gr42fjvPSqn3vPK1tByz2v2V7pW+p9'
    'S0vfcu8bNKgnSakAKKFXpp8NkWVLhMrVR48fvFgrDwVnj1fjmEA+ZLBrrYtkOMzOyrVmHH623N3MVIIgP0zKlWARzNXy2URr4aQG'
    'ZXtGfY6d9CtlaV/RHwkFxsc81Uum+sxMRcBPnCs/MmWO95y5Wvx2rIchzv3ivOs5gYF1MUwOMAnHXtt4XXGYb7HJ1hPXma7AR/m1'
    'esGurzyIWGjPGUlDl6V/jIbqq0Rdt0oWuP/hjkj/oa5IniollwuJAXbkYVsCQLTKZsGht86N/jq389jxXBx8Y8bFjjsbXi1nxGmw'
    'klUsH6fNQwLv71MKeSMKzjdHMX+vn9Ack82TlBlY30oztIy8jXMQ1rGJlkC+O50OLWTPGEaYNXWt3tpfqKbZ9PbNfl7Y0Oz2DX2L'
    'M1JNT/k39PQ5BPPnjwtb3i/5kRzcvie4syxsGyT+9s2pY9X85nAs3r4531enYRR5PVYd4aExv+azRrAhj2mDTDkl+7QrajkVG5r1'
    '7lUtDh1TM35JDRSOn3ev7cHfv/VeTVWKI/yqYYGQC7PWq6lCddKRnaWnpCEmiBkmiMId5pYwdiPSi0QPgd5Kg3hJ4uH3j9Yf6Zzo'
    '6fGDR4gV9/jRXyHrt+oIkO+k5MHqsLyw1+H9pxrBlm5AP7J/PFydymop1kcZVXdFP2V13FzXV0fV+UQNkknpXFERZzZ6M5jrn+Qk'
    'PhbQ1wiCw9Ohn9vxCZ/O1v5Qutm43dG1wM3qGxyt/mc5QFlPw49NxgH2CL+kzaFagWVPJdEE2GAGWL21QGA6YmBi1nKydrxLa/KR'
    'dzwD2/J3eLq2Jd4M3Bd+FLWsqf3VG+e/5lGlszRW6LzCgaXprbDceFMxMoJ3rMHFW/lVhQIvPI5wGcWOVNZLaM3b4zc5KrVpw7dK'
    'NtFlr6M151qzwKvL3MYSGhRiko5ksuiqWSBZ8Gqrph8bY+xwmGXTZtMhD8NohccC20oR0+Q4+HNekhnoMf9t895D/iH81iqLUxBl'
    'Nu89f4X/nGRhFarcKMO8UXAu9Qa6xV/JMItfU07XhXhObK382v38e0O83NhrSNqyPGPjz4jfkFg3qUYNUcBmKHrDLfkjKE8/fqSB'
    'n/FVA8BznyFwjdlAj7p5b3Aes0qSBZBt08gb1qdyNXyolFdq+dVuiiVT87kAgVpUcAhT6j5IsbfxBUZtWj1Mz5OBbEb6+ILkvXcx'
    'T4CHxSN5sloeBE5yFRPrv6+Era0YwNQM+4dpOqAx4+mIfr7Ihj7YWNAzlsmMQmZWXO9rDTUuOEk2kLzGJTvRCN0dCUXGVDM4L1jq'
    'Yd6tsi9YodfUK45SJV+gAGLMclYuIvAYASEPTo5wtANO6T2tPTv8i1dLCNxGVGdA9GUszzlXeivqTZP4xGc2eDxLMAKsSkvHTHgq'
    'MwpK8iSUFyv6jC19RfR+Gc/HNUg+1tRiZpl3Qe8c3Q/uutlYl5Ucx/Zs4OTnHiVAuGI84s5w896rdfwHuiBtMIr0A3wTnNMjLvBH'
    'RTxF6vDSSTrUCM4/Mx0Y1T2G/Umj7mYB9wpimS69+kztdbjiG7IMT3nh5IEtL28N3OvajaZlJ+bRZ2A9FroA48UbQKBbTC2les0R'
    'WLU+XjfMWvDYBJ6eYFs9Ke38iQw2GNDspjIfYDVHq3XgbEpcJ5igJDXHK1OmTWbXrIM5l6XFevB41XDAm1FwBpVOjBhnkNQScEye'
    'D3y6V3Mqra17x9ITDxmfPcZ/uhzcTiNwKLIXaXyjY6l96eqMqX14V1ayLdFgIFv6Y5ugrPw2psP+LK2gts+3tiser/N8Xk1ABOpU'
    'tgtXbFtoXTrhXXeKSAv1rq/f4Pz6B7i/luSrG5lkasvXFJkoN6ET7S3VOSXH2lo9Ta1KxlMOOKD3AxJ1M+znyqwLnWkdckqcmZqu'
    'sc8879lL7niRWkhFW7Ro51VqxCJuVY5Qlep3l/bAe9AO5rIdrdMIHnD8OzTLiaUl2ztfNvMl7/XXFrvrEDRlIHPF3wUOvBi4cQ01'
    'S+ALDHMdcOeC9yZf3IrfJ+xhU4kGmCqhKutQbNI3X3F5GShqbqXFHJa0mFWON5AVA8rze09roVm3WZt6x2JfoFtdtAc8PZQ7mgzJ'
    'Fxmhnug/9mj+Wp0o4tH88mwWeCZjIOqXrGLkRq1WpoR+FVm1RHPmiK5VT2UDruvgGjn/cGhsIO6WXbDY/61kA3JHkmzYW46yY529'
    'Y6mahdgrFs/d0Ity+KTlX7VwZDdC4zsSxujG/lbbXtg81ww2A+x4iF7UORivRS5An2fAEMCk5FLGQAlsr+o4nidie/IvG9A4ldkd'
    'J0Jxl8rKpSyaBfd+j77Hf4qnhuOrpwTOMS4KCMGczn5vN5bg1PvcuY49TSAYGc0uKNzNN3kV4gRmA59mr1Vx5Qv8Yg3l5r7McdzY'
    '00CWoUNrxfTZ+lA/G3Li4DiSu1Rn/AG/OzpDcvhCR5MphwQ/4+A0HGqbzccOkQ2ADW4msA/zAoWrAU6nxF9Mxkeed5iY6YUJjUzc'
    '5kuJHN8F+okuxIvV3TXxE3koXTpkr1utTuxZ17cqrM2g4mBDXXV6XNxYlyEytOR2jI6z4SBXg6hz2umwfbEtWpCrYdgETuYNCYTt'
    '1N+DUyjBrEE9vIz8N+sQ0x799cHaIxjsP364Co+OeZLb+sNV0WX80rcHF6z4pp6A4iitGZ9nvAfLvSVDJORBqahFtGiuU2bRck0G'
    'wQI4yAPQTjmhNca82pAIQbl1LmcTE8m3QCvbYLP0r/M1s2VaDDpcp6ldq1XR/h4IecboagbD+rRtIhEmAxB111m9J2HoaJqb9z7v'
    'vVom8QupnwbxMBsnsFPI721v3YGVuGmGkxSI6AxvBBKd5c0Ubz75b84mv8OWOvRbeCkfTYvx72gQLg+mPu2Bf8m8GywN2wvgD3g/'
    'BNhWLcHR7m+iUlhb+36VuZtj+v34yYMnstCTo3cxyHqREVjWHj5k5d5UEjiYR2GY3LOcXuZJdvvmvb+uspB8SOyG93g0K6waADhk'
    'hraig2aLaF1E3yr5MJMM0HW2ODHccVPfFMe9SeK8eJancfCSzXP0UbXJqocXI45/DQe1kQoGbgl+agqeXM9SfdyyxiuYKS/ab2a/'
    'ra/L2uS/vcjL74Yx0zR+l4yXf3juH8Ir5R4m5ad5DAtWNcW01h8/NA+fZsNEmXnle7UPv9WVcI4WHlZzNbGXRPRqIOWUt+aCbwab'
    '994Dy4cMMHYl0fnpa573r694JygSoeJNfdnW+TyvNC5vuW3E2B58GNd1O4YN3MLhzAerHjgrtoQySm6hH9UstLzzVvTbJmtOkcp8'
    'TQT/tT9yzshG9h5WSCEAJFfV5r0H64xZgVE2FVTu7a07i+oB1avyt2uvHjwhDF0J4figBo4P/hA4rs+F4/p/IhyJ3t8ryRe1YFy7'
    'LRjXXz16+P3jMhjXH9fQncd/BBgfzAXjg/9EMK499sH4eC4Y128Lxoer+K8Cxoc1YHz4L4ExvG0vwxJfo9Jl/AKA3oZ2mVn1xYx4'
    'Fg93pUh4EphZmJ+5f4Rz+iW+pP3nv/93CHz//L/+B//5P/+/hucQcDiSKAuNQdJPaZB8nQvjqLcJWAf7+CkbxWO/opZ/K94Om5Hn'
    'sQTXIsjs3eh7qCybPxu1Grhh4YHBCrN5ghzU7H0S7CPmd1+NCs9SlUa6n0Z/jh4cKJtMbex56Plnag4KjeuO/fxfrLABrumeD/RQ'
    'FaAuH6nn4cH3P3AkZB7kwePV0jlMzZf1dubK5D8HJOJvUguK7y55+Svg+p8CD+sG8y9yeq6dWmYv7iG9dL94P4N20Xt6w/6VKMKZ'
    'Oxhj+ZbCEMML4kwH7/CNl04NBbCIrCLxmgr0Mws7XPvWDoP9tLDfMfc39vsJOi8f62Ovvu9VA5V3OjBIGLRKWDi4nt/yGo/4G9D7'
    'Ay34FKqVejT3PgcnqVfTR61rOyv3TufX0E+CKL6wMZU9+fsR8JPv2V5Ky7dAbiTCfQKvjqp3PM3fbzMC4KdvBnxBk9+L9vhEUvF5'
    'JTdvOTPu5j15hmMZYFXXDq1YuRELGNdO4KPGyyr+4kCOkaxgpXEq02Gn4lLz7L7imuaGVlDYuDT7a6ghtVzAzdqOhrUdWfNR15m7'
    'WelIlH3z6V02oJo753SYjfkMDhEpWNVABE5FNt1nzBLPeaT90vuknzGi/ABQa5gsob8ft7ix34lTfRnQMid1J5xSaTDClMcyEOD+'
    'vUhHLqD007mfjgelXpa1h06AsEuKbTU94Mv8DubXmwAXg3rWB2pODfh/1VbhD1THEhPiyYr37FTPCqQV6/u1eLA10JBAF7Z+OYxG'
    'x36BXslAae44vK37h45C2r2x+3DH/6EjsE0vGgSHe8gmOSHuNPn2MRjMRO1l55lmelzhrbT1lY6hcOP+jE2wAoTO/4AN+591GKyV'
    'SV8Yc8XRvyqGzzkW1k2L/8poV0ZJEQOGK6VlcAOqLjNWp0RuK6tUqfUHrFV/0kVrH+0glX/sT74ZCPOnLU0OnCp5MpsORXHcX0nE'
    'zTRfWeusrbiydCSN8toK/MWWPM/TOQmA11b+8e7tLg9+OR1j8n3o2gb9Ll+yues/lwgOh579jpLsCZtNt8Ks0FzIfHqqY5UXySCi'
    'ERnTOP3y44MXL/de4cLRBebrFNmb3Q/qVtfSBAMIifB96/q/ooOgUcKOykrVYEgF0S2G2NuI2iqO6toKxomwrnhAJW0NJ4LUVhIa'
    '4w8upDfMg3LNg9K9qqTiA8PU0tBXXsAe07wwVDB9GHVc3LYuPXmxfNT8oBR2sfEHnXASWL0+K+8HjYV+i0S5Vveg6bxVC0TCrUmu'
    'HKSaQHobG0Id4bA4kTdft9rgWGgGDx/Tvpfz2Bgx2IhffsB2G+arG/kB2mFqwM6dI41hzFY//IaDF5tw6JWc9F5OYSwStdnGP/OS'
    'Cv/h8HLph4OY8wwwd2sOp+60f6zZE4NMvSb3Zj6bnqaniQ2CXIl6TIgrYY+lyd+T7djeRXuOtDULJXGUvZXyiiN+dKkZWaC6BefQ'
    '+5V27IKahlyyZZtu+YWkWkaqZAAkmQsOa2jrBxu/ETqcP9VHy3L/iifzUz6bEOe/O/Gz9m6SP1ssBc5q7x8mfGwHmWw53u88hPRw'
    'D2P0tuen7IwKHaeDAQfCNl/gZu2/R/7b8yCnLscjfpeMZzqKMv205KvqBdSh97NGq0W00nYAC6U685YFzezH0zRePo7zSTaZTQ7Q'
    'YA9BGDxHIS5BBJH2UzKA+pQtPRphduAiOyLk4an0Cg4SbcPXYKAIoozfyjdE4v8h6eolyFFRZGMvDt0YcZ6opQ7U9RrUYjftDSV5'
    'AJF60b6hoM5/w8R3Fnji0fsK8Gs1k8JCH1tRniQkPKNwl48i1ErFEg8jWAwNZQZMYwwVC+94MNg55UDytMuQxa0xIUGdJs1EmENS'
    'bmlWgLvwJAGj2eFJ5MV2Rxd5GZkNsTD+7Jhi39FIOvI/tRdaoTN0ehKNEIPI+2gjRe+93nm38/Pu3odPiBXdyJlJWtaM6F028Wl4'
    '0Y5p9nt41yyQ53yEGGxTRTXBWTqHuQBeAmR28uaHrh4f6dRap/BLY+qm2ZaGZBlm/Xi4SxgKqYhqMHn1hs2mVI46XOtm7PEwaMOx'
    'bSnILIzeadLGgBJwaUhkCDkBR1mmiaCC+sxJ6j4+zkZJ+X25ud2zFAPh4F1YAYCe23cf7JJY0uE37A+4fiY2VTOq7QwVqRHJC6HE'
    'XtPLZstGjCKWbkykMSc6gPgbkigbLTIzNR5INsHrOxx85x1YsGajOZkmhySJLPOF1DKLD3SmYNwtGkgVkfsckdDisFrZgYOAnwJi'
    '2Wzocpp3wbIeVZe1vKY8X67ccliYdEyAqm2zAp5BGlMmAwhv9vkFDXsUzcbEOubRRTZrnHJYLRgskmR1p2YzoRryPzA56EorTDgT'
    'Ti18wilM8JZPsqFePxZZWFKMmUr70E8cn4h06bFMVBemlNFdgSIccW3e+H39eGBjuF1GJ+l4wCAYnyAXQ++Xbk15OKyKSUU3evvm'
    '/c7PL3dePfv8dm+Xy/nRrThuHycItd2/x5h8Vpyz9NxN809ZVjTzFjsW6DCKacJJu9l8PNfx5B0G0tUVuxzMGwmqsl8CI48NUsuW'
    'y3sSO2jMatV//vv/892ll95+XM5t7wSzB6ut63/++//7dSNkAbCw3rHr7Dz9FTE71b0DDXAG+DhS4IzTQGsNTp18wl46YqFLy6EG'
    'zl95PU0stO8u7Yya75tFhyDEVw4kxzLLWve9yFqSZugroyRhmV+qYDvmloRHNSNW5iMcb2GMjhvCBHA+bcZQ8GC8o2txOi0Y3YlL'
    '658gkJgUoDeYZqdsUjulXbeY6+ARYgEiou9HONvKLAu1UVNP2ISGNdDtdQZpDhZwwIuhhoR0gsZ5DlLVEbak2chw2t6l5SLEFZju'
    'owdzJEHvcYDcN3RKKXZWv7d4ZXv25ak1QTQwfz6Nx/1jn+WjU5xxgv32eW/4a/QpyRmpKpMwBV7S5EMeMmiQkcwv/xbZeW8qfh0c'
    '7kCoJubXjpjLvWlHMFUuDP0RujEapd7Xyjbwo8Y5TtoDtYJ3wLONZHn43YbIHd4bGpGVDgOpJEg7yeE6ZFsw6WlHUrsrlY1jwy0H'
    'hBZ0PLbah94vhJadk+Qil9SSNjOR162CT2dhp2e/b9jMP+5QDg+HTFCqeZtVqeLavFXyNlvKDsT5rIcKSknA/JokWd5oW3QQ0JfO'
    'HBgTUIN5usIb8ycJs35Bwf8QvPMmeoJ57jdYQwYhJp7SBscP9j9rlNHvhNd6wboF0/mXaB8aI1pTw2KB3DopwVDHzagsKjjCKH7c'
    'vZbd2WUq1g4JWJ0YQTOLR0z4jxEjm+WCeRwMl01Uw3p7vY9JXq6SMtpocHSH8wURDdPxZFYIu04FhciLy3nUkHE0NviLbunIqYjl'
    'PbvLwYtAIkhw3eKYJFOdZMM0bRj9xg5kNRyA0n47Qrh8HJVQSw870dsEyoa0iJLRpLjAF7ajSn3RFjdotM2SWILH89RLIru+5DpN'
    'GoCO95AAkZvBC0vpUq0MMt6FzPH6d7wAN72H6ZrzfcaSoIK/fSLThNEa+GlPLBhro5+ZRNaWzVpfXbVW/OdUZZSdMtRLk7WDlRHx'
    'GOlAPmWSBY2+Ql5i5bpPnq6f94Hue6HfrchVpMMhJEL204bbsH4eKn8Yd08Nr801wq5ubg8BnoFSTRccGMCobms6MwLxX0bTyYts'
    'gnuC+Ih12k3P1yjBOaNx0YCRDbOvml6WDTsfv3TejyeJK67yEcbXmj/A3nAGMzlx6PY7apk8Wb6clGVDeHGGBAIYykq7vXSUTDd8'
    'PRE0eaP8qEzvQQr4I4hYUeJb+ZhFJXxy3B0NvdkA3NU4C36j6DCbEVNse0cl+8DSTWEKyRT9JhV3tVXG7FUvY0Z+BunzBWRkNqX4'
    '9OHD3s+v3rx9y15GH5+93dnb26GjA7ORskleEvD9JthWpC+2IkLCIx7K5j0pdY/vQ5b7bP92fU/udzbv9eL+yRHHKO/Ke0ZJLbT1'
    'dEWaCm3XSiO65WnT908bc270NXY6nzI8Ec4Vfd0qSVl7ghrB0V4WL7dVurTxbxlEzKYfJdloPydm5AAEYUQEFI5decspbCx77DHQ'
    'RnzedPJr826OFppp/i5GBBSmLCDLRFyNMya2y5rXNIfIxLVLvSghbkiTZNz06hAohvEkLw1IOr97guA0JKLKjGwdDk1dKl/XYLgf'
    '8u1OX79xPI4d1keyYGfr2FY+jwdZqQvCnGy3ICzy0utw2U9Jpew0qZb9BgVzR5BOFMtzBTNecceZ9Hk98g4ro+pZ1v3Gnw6f01nO'
    '6WwP3xQxoa/83kWMfTH0pSLp0ZH5vXsMYsg/kQxCfokMhp/ps8EAfOB3zLjWroj02Jo/j7eYx9vO4Vm0tRn9VU9FrqkjvLluygVd'
    'RRm1vYPA2ud4JaekLcYzCkrBXT4sxDOs0Y9KmGaOAtDMOWMAJxH/JEf/P//9fzBmRequimc7vHQ3/a2E8Pz6E9PRMmbbbAR+VW/I'
    '9BUvedTv7LDzndHk2F2BCmcHxTBYzLxDvNdxnKd2kfJX8SCZX/yQvtqiz2ZFNr8ofJX2UgmEy8U5Iaw35KA0+Ho3iB9ZaV9fEgp9'
    'd6ZknD8HkeeT03Z0OOYzSZCwQqW1hEdox8nZN7Df7PAv4X8RGdyxN8R4fCSGhirZrzRkcILDeHyCx5w59tVA9oG7sXwrCP+SJigu'
    'cnkiQFpmWCG9vHufnFlpAnd1L4rpcOm/gmc+ArOAENxD1sZGON7kegm4SbQ4YUHNHFBuxlRGSoAS+0U4Uan5iAtB/yNUysHHZ3n5'
    '87PcFniBWCb+d+EZaGX4S7M/g2uzLY4Txi9N5fDKfDfCjlciEKFsO69Ej1rtFR+arj+9Eyt1qW9tKT0og16xP3dVT20LAtv9YgU9'
    'uzGlRXVIl3p9RpjQcAhxbSvx6ePVwtFjP/JxE4zK+yiWCJCU/SLMnni3jUmHVgAe6KIscJAxOt5K5ctF1TdK+mF/Km9FxV4CANt7'
    '45NbFU8X6BX3FTp+SXsCOSio9O6Xqi6hTT3hXwuG6xqOX3Hsd0NUFiSoym8+vv/BbZdsEiAQzEL87zu+YU21Kf0QNFdT2DM2MUW9'
    '+3oUNLdT1Qt/qlBnBeB6VP6pAmkBkfnu7UHz6pnwFAvXB5fJw6GpQeJLj/Eh4UwN15UmQTvyb2+UmduwRWERf88QzaWaa+sTNd/L'
    'zm5GRikXYqHcbc6lI3IBLcOQKz93wRzcusqdHxgTfhX0Idx7pQ+Pa6cWeKh62lEzODP0ybRjGUxLDhkF8NYWcZxnWOiNYeOkmMeU'
    'hmOizU4cD3JSu14tz1pb1CtpOdrwNlZs4JpjgetY+UVPkhOuhLgsZKIiHiFB9hnXrOGOF7fK/OXtG62QOdUvBK1WFbY9XYLUwhlA'
    '4L9m8hiIp8AdQ3nr9cxcb6Vf5kBHR7AmZKacvrmFNx8qMDBy8aE/cbZI3F/FbUUICw43I6Zr4O09uZdFZ4lxkSNQxqGPvsIY3wh/'
    'wyyXlyCYu/LhN4DdQI7Z8+BplxMMab4fSb0ufzG5N4MkbvjdCT9dhVqNtt7psNWwMTokzuY3EFHVasktPmvnimwQXzTyCPFkqF2I'
    'mhtsESe3l2xbNI6g7EA6MjY0Gg/EFqXKzQcKdOk8ZGpNQVbu26mxEFKLEJaJrpNK6nqr78shgEgwt+8LIs0N/bi2WTC5fduQVWpQ'
    '7KYZiKR0+25YeFrYD9omfPgb8OEkuRA7wPyYmIb+DOE8sukJLi1E8T7LzQWG6ic7dxboKDTAkKjN2ibekGjc7aNeP3Ro5+zE/eMm'
    'YnpBhVoV0nphMNznn/f2PrznM2uUzfJkNuFTywJG2ciyVrLXgR4WsgVNHLj+icn/hx4HwppqqYkIbcSaU/vMfFPbMI2+4IBKrVYn'
    'kwrN/PSoetej+cXiMZEm9xr6ZMzRGAf04zFHX4qmMLOVOiaHVzuCJqHVifjspB2aRLEEsJrEOdRTxfE0mx0dlzKAiXkqtRvDSIdD'
    '9BfHMZwae7PUxHlSR7AI5hFR3p9CkUSzizpitMZ25fqRpE2IjqwEp+E2iigfzXAOoxsiC5L5J4eMjRYJ9oMhYn7TeQOWuXCdNc+O'
    'MUuijoRIVKGX9GPYlbJdRDwDszaNnn18A5PGaUJQgnoDvfBA+D4JobcIIqovEaBw8tIBwSPOJVPW509vc07QJn55JEZcAOUOlzGQ'
    'GMdnxxntMag/8jKJgmUs+knVRO4Er59nJMTRWkMJzy9eZVO1ydLyRhXuvXrB+7JgJYiG8uL3n9goRC26/NGAj7JhX++6AVpzTCn7'
    '/sPezs97z37Y5StjsVCLj6LlLQkuybcvNI3YZDdk81AqwQYnq1FzNgYF6uo54JAi54R3uDz9yBkZnn+SP/yvJKbhn2/43513/Oez'
    'fDVl3vxth3++3Hkrrz5r9c/SJrKj8A/kNeEfHz/xX+r19VqX42gR/q/zp9cP5M9DvH+A94/sr8fm12fp6IP8eSuDc4FD+fGZjPud'
    'jP/1J+2Qwz/yKw4yLr+QXkl+IcWS/PqkheSPFHz55u80BND93Y/P3nNgw1cf3u/hx51rs1QvP334aJZq5aembJkrvnO4Sg+RYPhK'
    '/s3Y+OGKUfqqoJNuGBfJ1TgzNU6Prmj7HF+Bcl7x3cQV/IyucCt/hUgSV2A/rpiiXgnVvRJqewXWgrZLfHVKOzy7imeDNLuSXHat'
    '71ZS/4ahmszKv2fgbH83Z8aCTTbHRUMDWyZRFh5EdXpTfixV4XGU5HkX14P01I8ecBYPT7BxQC8gLXgxqv2ki7DfJQ4YpWrDHUtG'
    'RI5fuSi9FXXQofOAjgnRV5UGCQMy1HFNcSjjFmsHy8kPq13ODbFscUmiLI+9SPlz0zaCLmxGftFOkX2msWteo3Y0nfElr6Up+1Tu'
    'IMiTiBKYNYCsgcAJwsFkhAjNxidj5EohiAuJmeCsio+U0pjkvF7bPDyTXKiSGoCTjyp46lIKmQSwcnUeBnK+S7sN3nD5dpc2Tjos'
    'sm5rJRXIse/3DTMqxRoMBoucQ3y7HSaiRIDEKzgYXx2lh1dnSW/S2sDOfPywvR8v/7a6/P3SyuaX/GDpOzOQmplxViKd2LxF5RNr'
    'zs7AxoOtH68qBpvztgSrxO+6WJAwt1UQQzNcEaTQyauQF2PU2jUxAbs3qlWnCUvA4wxqATorxxnbR09x+b4xH9KtaksAUu0YwpxO'
    'QVN7kkPCPb8OjZlikY1NChekJ8nO+OdBFTVhz8GE7824bhWRU3NttYSRp5xwgQ0wntLX1eq84nZ0WolyWaI1ajWM/3nYa99eGzsJ'
    '/shZP4mQ+obG9OjbwJsbExKshNtUi+C7Jhct3/auPEU26CuOj3x1PG196VkUNhlrCbb629m3PN3/aevg/tbVX8a9fLLBpi4uKzPb'
    '1IGIu/PH6Ys46y/fA5AgD5udwD9i4X1MhW3yrWTkxiVl6ZStS5SXa6pzijNBU/847ptAoDxhJ831yhgdAhwGOUwBY2Hk52Ksbldm'
    'AVmfp1ZIoPjact7UtvizuZT2DE0iXO+ItMVWLWphQXIXN8s3TaUSJFBJl1O1sC17TBml3WX5RmsORI2FU4kZLpvxGemSQ8wyr52N'
    'a835m3l8auRLSB1p0chhLo2X4GXHAzk/2CZJlemd0DbivR2md2131zcr8Ey1TPJjGbsaNsCo4L19zTjdLBnuy+OmnTc1GuCRMet3'
    'aWJsL4H5v61vbjdViOCoxyXThDESn1ds8z+rbb5CsNGaY4OeJwmDTsSb0Fa5tAPmr76scDoIJ4Eq23jbtYu/YN7b/rS9KnZreXfo'
    'mHJ9fmubTsNU64f7USs3gKCsFBDXOlujIpQFEJEirEZAYrrL0ADKCXq0wwKpz1M1OPi1o4cwV4h4G/wIN063Dwi7jXTMnqKSGx5r'
    '1on26LfkuVX/AeSyg+7gNM2RWDvnHYJbPxJxk4m3Dfy1E879dsO/xepVsVa2V2g+zEcJOP3N8vKVFxlytug8zdEDR/aM81NzC9fA'
    'Lf7V9dTf2q9Bh0A3Lt4EY9aohjv9brj0oR1iBS3EgFRN4eHf/TKdFhfuUBirznZsDkx6Dm0k9VsNNdzzDIBpIXsJiJ4emAOI5oNM'
    '7tr5Ur7VBYuCy/zZWHy+iL8TZ2ta+ZitduAfzK88TIKQRjjiYUbVGuH2yC2eZ2VKH8FucSX6ZBwYz9hlmNUJs2mOCIyxKGOMOSOG'
    'ACtNcSNnRRP7i01zTCeZFiZvuHiyMkg6ixw/c3PAlfR+oWlceBKaNSQuBXXYfsw/31VTlDc5aSifmc+K5mqrA3zJxs/GfeJ6sukL'
    'VShNWY4ItDqVigg0Ys97e1DBki8XU9fAym/K7cuu0Vo8oRr+wp5h0nXdLNznhROYC60or2MucsdPuA7KfuH48mI0aPZHA/WDicxF'
    'TXg413NVbgPXQCRwik3Okz62L2FVU5wRfkyL4xe7u8Z70ToxzqvFQ9Si4rHjjgtzFtQsnWWeBX3xTY8vIYFbFgYNKYGvbA5TUbP4'
    'GNCPae6cN6Fi5lnFZVFIDgTxPJTeruAhG1XYZffOX6OCEAS6SfuhnXFBl7LPEzBcUxVcHCQtTk4ySDyXxCoPp/Atu+/faBbJPS6D'
    '3OTRvlj5jgYHzrWNk285cUB9aflN2KzixW6BCDWeCeVoUHaoXegal41LEfV7rKXy13fb+Zscr7ej4wdtyQnDnojtaDJNnF3gmOt4'
    'BnBobhv/erodT66PWD1ZE1fEoStfl+YS/8XHNRL2cpuXzFuCQ1afSWkWjzgBgqBWjl2ndo8rDHQFMBqTSDUS5IIEoIHc0x62fHi6'
    'UBqzoYSjQMmIo6RwKBsubNyYuVXjIBZuQPnGkSvFDhzWlyQLc0TJDv24vucbcnNEyMnW0x5ClE62SlEYiNKJJdI3Ui019hZJZf6q'
    'xw16mqvcYg1Wd2WlYbb6bArWajLNRpMCuSTGJxggUUhcDGpnjjlDaTBIqMQ5Kkxz/kClScSVcnq0mzRoVJoWWGrigdi6/nA2IFRq'
    '/C/iZXI3fIsucVkn7TBf7g1mCU0tIPUYTkmgBezVmqay/F+fxqw8xHoneZ9Hy9nH7cPTlXhLlBKSKoN5N0usRURX0zSUD8NyYKWf'
    'yThi/iOosWDsUkzWQMbaCPPhwMVtU3RTwFdODPn16XeX9OZaEVMfbOrVB5iFSwGpxLcCCR7t1tMC9wbIRJadwR6Io1rKu6eFKujl'
    '04CjbrrfVEyTQGhLbqN8LVE3ZKacj+jFAGk9cb1mxDSU9wvELMVa9MNn65OvpOHjrPA5TNgmaHMsL/lXAsVUu/BOKc4gqnmgg0Sy'
    'SFN1/uGwyX22/XTR3PqijNHl9YULZGlxF9xjoJkNd0+BLZ6ySTD9eeonoTWeAlGKBKXTRfcPrnFawNatSvamVm3avDkV77bAvFM8'
    'zwYpm+mIZhXv9AoE96V8AgWtwU4e+Pmco703p+3oNp01y73BDp9Wm6fEekdmKrkviGLOUtf6M5cXidDALpLvaerlKfa8deZA7RZD'
    'x1bjuGAIwhT1v2EtaIkDWPXbkUOGfaDxUrR2YGe/odGdamdLQqmPlcXUuRMurHQzlMIh0cIEDdfsDmpV9jnr2mo2lyMULcUov8kS'
    'Sw7XOXMYV8VDsS5pB5Vg9zG3AotWbGtu7CfnaIzYcGZ+O+rs55QxC0vX+C5qxKZswNY7/WI6/FtyAYglHVz60kM7OuFvVDlk+pwt'
    'WNVj8ZIqEEeJ7jVmLvsbBP4LZpxiKCNoZfEDI6KzvcZ3sr5pX7Nc39SJXlLdcnSJ5BYFNLbVq4CpDH7e0MXJ3C4sh1eq701zL+7x'
    'jd+cs22YCr9b17rhKoKhN7L/v7av224jOdK811OU6J4FYIEgJbc9PhRFHkmt7patlnREtrU9ak2rQBTJGoIoGAWQomXupc9ezMXu'
    '7MXsO+wDzP3Mm/STbHxfRGZl1g9IecbndIsAqiorfyIj4/eL1RIlBckctEZiz5sCukkljrn3hJK25q+n1Vma0onTTkmdHb+UfhWX'
    'xIDsp8TLHia9n5i7ErrxhnU33vohEBwvHELLq5vw2nIQo/sOqw7F7fY1RpR14d8P3uMbUr2PGYm5Ri3xnh0CaDoFoiE+RZpRw7ZZ'
    '6wsEePzth/EM7kUaRlETzPhjU/LUu2DlxxStfYmCEg4snrJ7wieL9ET458LNeUtW9A3PF/MmydVWBhryISoXCiH8ZxfmbtvKPGyn'
    'lK4cb6vDWJTR6Y3N+7ooc9yHiJXXAI7bN8qSO/67zbl8/AFSYLfbzroqL8DugQ9veYAx4ZdRcXws31XerL473urMhIsat4m7ybt8'
    'Hwfxo+tubR8MO9xF2xYFaqnFFrJZJuercsmgv2WWTkOp24LylGzL0Z2/1kRTIQ+1BHxqXGd4MDaXH0az/xLz0HgNr63SHLBDY2OQ'
    'C801y0xLaK7f2Roc7u6DbheH5V5DnaqCfWeHlJI6g+UvWuJ6OyPlLwaR0noRvaiegWWnob9OYmmP9eeEPj8/aQb7+yvd0f6Oe8Qh'
    '/50B/w3iLaNRUE7DyRelNHnxQyn8K2GFkQcOhWySbHKSKR4JYoGTfPmQ9xDDRgNS1cGRTUZB/OXBT29boB6VxBT+5uEdNX9ZhJrc'
    'fa8Vrs9aM+yNy0Hobqc1e6RdeSRt3Et684+9yAbpF0JjmVtxCNoQMm84eiFzg8YuAkG4rU8sUErchP7RND2faxXyt7y6KY9X3OjB'
    'b7eHSXD1l8n26O8Hg2pM1ctXcx8F+8msG+hP+6gsGQN/fLJe+50rHGSruSm6a4AxbUmGYYxP2/gZ5VM3CXMcnWsQ97bztqqroHHt'
    'arvDwwC2fG2xgwz1yWRAlfejN+/FnURFZHXA4XRHlF46u1L/nQimvryxxoginE89neUpLLM4E87TM71lDD0QsVwKXJwBx/hK4e1G'
    'd24WRj6ZoB3LDyxSsh9YD5EIXYJRt4kAmKAbxJb/ordg3g4sOyI5Ra3oHXrij1A5gaH2CmJbKgc5Oi3yo6ydhXz7/OXhQQsDYas1'
    'rNhv8VsfsRqqjBPqlPe1IR94EAu4IPjQw+CZQ95Vh0+RuxDHQdyCj2oQT74FFfhcECgqet3lidhtB/4ODy7evqc44qF7V+8+VZ/t'
    'GmFaenrQ02amsZ+R9nnw7qZgJhiOGKfgVgqu31++4VY2zf5rhIF0PvJb+Ad9Wmc9JwQQs8hg2EGuhLzMRwDMgJwKzMfxIl2IVl9m'
    '6ULTH2q5I4dhqsSxqGZllLJR1psCVOsErvW5KND61uUpwgQMqZXK2wR7m3EFljoykQ6gaUabCGn3LOJqyMDdpO9yw6xo9ICPpK5C'
    '+CbSzZhITHORYuQacm6QeKF4uwEYsEuscF13SRR8uLSY8+/SeROPNzn4wzfJXOZgLsfQvfNlfp7ZS5b5lH5KInZZw/sjvA268DxU'
    'QewqL9JL8T/gcpobFFd41SslO8k82KPC01A8PHbVorqFiJyXcoxtIdxzW47DJXL1c62l+O4320i4zOSJSe/9MNHv5/lsJfoxvj/4'
    'Ur4Lx13w298PkZR7xc9fjn71a6DsZdkZv99/gCeF7k/59fkMIZFLoabelZBT7/175z2C1FjWXHrvIDUMCbL2HhI0OxjBSya7rAtf'
    '2URn7tw/Tz/2kdOBz8fToliIbMkzWB3B3h5qo8Tc/tOKgfiX2P4fvvg0u07kH1T+kj8MkAWWNHlD7xoT+8FFBl8kW4/YDxe/qALd'
    'pZBgscSmcHvqUtbU1BMU1LQAnAzGZmQ0zulC0BiqHnOElgqPEQTLePqijhSuLC1C6DgujEB113+2L6Q+fHPJ1QoeyyBkEvLoNC37'
    'Z7S4OK+G/g5ARvz+MHgNoOb0zB8mQG0aJg7taJhoECbRD86erhYXiDTDZ0KVliqAEDn64sRAfnu9uPSD4pBAkSPGyHkuM7fM+r87'
    'ePVSEzr0o8aO58dXfR2unIp5dsn0uQYwtpCOwgAqO0J+1mouzU5YjaC4Y1Ulvl4oRGAWrxeSzRBqdZLPNNhzBpaV/KkoyCSR0pUu'
    '9IxNZW/PKhaKTGVLbUtdsQkTYdPFGSXJ8iibufjZIdEex+PiI0KLL0NKHo8gYGMb/ubLbbl4Gl88tYtfemA+fQ3wFcejj3IVDWwl'
    'D2Sj8+8wueKlK146tUv8q89X6/NhVz4nmNwnxUfWqcO+uMI/l/jn9HoDsQDMOnxczkWpfQNrx6ONj9/lkx/k/+Q8y5YbiVYeIHk8'
    '2kAYG7yeOg/Xu1vyDnUXBkdXSCLcacI70ukU52H/ryQ/g0o0c6rReKk0PnRvjLCv9aeWSAVIC4p685k4PM3CBRHKexgS7k4hVR8H'
    'LXcYU+fRHBxbB/xBDX16sYKXtO8hwiRtW9++Ojj04SjRcack4dsWtrQqG5HAuo+r275Z5HX0qQ+7k/zCQd7hnk0CaW7s/RBKBzCV'
    '6AYqZatllhwaV3dCzmvS3x3vxTLqpqz16uPu1ngP0kPz8nl6xFgz2cW4aTCCv/j5TJmu0xdECmEKbLkE4gGEEdnX1EggkbCqbcpj'
    '31od7W7JsGJndwgVvWbO3JAdTPfXOaMgVVpykwAALrdI9kCtEkAl3fpl03CWdJ73e1vy75Zdcdksusf62WLhVvyGnm65BCp5L/XA'
    'LY22kBZG51lZIgUWwyCl6nwu0zHZ5SLjHNYW0KK/Q7kQUxC01zaf8bCDyIcKg0qmob6fNGjWjfBrlT6pMUfg2Rpae8eVWwX4K6s/'
    'ADLS5428G/3y3v4/fvHpuj/487sf3//443vmjvz44xf/rRdGyp3mJ6fELOljIiGkLs5NdsH554z15RGv10HvltgF9ojdij++G5og'
    'fvLs47zPjvbZ0EBOht5JjkAGK30K/go2KxyWHz+EvA0tWujvY1WnREk8yhZzIRyaTbjxNNrbOAy6JP3ENQuIdWC6mj8Xpj3MclHf'
    'W4ZvmMDwC2J+8VTDTYgpSkF3myLDTbk822umyEl/OetOSEs+amJptqscCH3b9DVJu7vy8c9/ZhxDuqSXiS/LH9q7lj6koQrq0se8'
    'fNQLSvMqUwhOZDmK5fbN5Nc4qzOgVNu1fMb5sOZ51z2+817y2+1wbfrapuwoh8dHpZYPq/DPG9j6oBW1F+h+ePVuErwxbrCGzV1t'
    'rSqeLGA4cfTYH1tOG8MQNrjgaFGNAuShP4puOJWDkX0dOBfMk6KYZunML75z4jgVRx0viJs7rkxvLj3Myb2K1Xv94wyfKbnrR0zA'
    '9YcmlTmYcfRsRD20z+0uLVa2F6EPv+jVYejrcRyL2ICafzs6QDeepbmU0KH4xVHLblmuFaS3bTbMg3B1UCyW4ZwDmysqVUWkOatB'
    'gXy9sWLIjVwvaDrInhbnCA0RodF+H1ZJCkMaDGbwQl2IkiY0ghxRVBezMnRVs3icWoVQeeo+c4dyoUoUlQvv5hzxXv0ku0+HpDfV'
    '8pLiVY9BS9ccUroCersrxqEakPv1GkyDqp3xLah2BIP1Z3Apyh2LziQsPLKWxllsxObmw43NBsWZoQ+AvCuyFon2GHklNeIGF62N'
    'DOEFxluVtD133fFCmKurtUzd1iBGmGmx1Q/XAV558u//lnxQ7RbXjyBRX1vij/+hOSruNdpgpWG04X+4Vv2Jn4OGWaomvJk/XFNO'
    'r643Z88Ubz4Es4YRnRVC8VsyEjIxz2gT2jCbxIS/TpURuqBUU+k3kkVBuGX6/jYgv/AUQSF6BWZGKy5wU9schGjMPINh23EXEdlp'
    'CbFhp6h2QPsJdHlWNRUp0m7v7PMu0n5dQ+N0ciJqFKE5RDgTLUou7tlw3ItjoGkYj9OpjUe/dI7oAPZQoQ4116HDambV75uQ6hiF'
    'afjTLSNFeKafgtok4B1osxKUPENSco5nJH4alO2iZvH51je79dExDBrPffGJO24/JiPbb3F38WOtrx/iqedvgXZwHZS2CDb0QNnB'
    'aDVjGE6/Dg5+xBKI2eWG7FPVm15ml0/lx2pJYEmVtQhAVwNY8I7oBX0pg9/bGGeXriZqLI21rjAXuSSmdi2nJKt0mpLjmN2vqDRA'
    'FTavsuXIqQ6s6EXTMLRAeZkWhAQwlfQpP4KJYAjFjjZjaaqAzWd2BX3Q7NLUEKnSdZmm+1BOTFMQMW0Mn5jr/iA8ilrUXJ3YCovd'
    'qS3WXL9N7vLXQhEZMEmPvNK3P3Kd0/CVShr6EHGF9u0q1JFEWwC0b3RmzACOv0292/OEkB0si7npAZoNnZcN1vAxZAjGjyJc+qRL'
    'DYvtBOO9F/GC7HDJvvjEOUH6QTRkHDEeLv94mn3cHAOMbQc0sbE3K2aZ4426N93A3X56PJl8XRuJ7ahELlkfRG6OeV2zC3tK+9mE'
    'ikrkBIF/GXIfpq5cjW1YNaKmomx+j8rvyTgcGC0xeDVZjtzcBrjSZ4eFQXhXOE0TZIdivuQeUeTO+z2aWlzqhzNUnsrp77I4NSZC'
    'esZjxZmj2Zv0av/HWf8Hs48g9TNf0j6tBz2wf0eDSAvGgA6L1SJUKYKOxnnv0yKdOHBrloDQIhGrBULLYmEPim7NoJB9TM/nIubq'
    'pPdCLOrHM3fVjXjHdDb224tAgE6iIR7ocomqwEcIi7nMXQXUmhEQ40N8E9UmHp9+nM3jG6knXBCvT8TI2etnJ4zYWLRYeNAVSig9'
    'iPF8+zVqsgSTujBxcWHVtxd64reYhGzmQuuOplDWxq9kbME7aAxVfYi5+Olap6Iy7Ld1vXokVMgWI624M9V06MqqtXhYK4EZ1g2+'
    'qes1jn3rEFaVklrjWN8FYtT7KqxSf9Dg1WYMYLBmeqNfsB17lw/ksleLYsghYlAKTVwfofdsPfT2imZvfxGIDr1AqQ0g5WMNZc2Y'
    '0d1gxLh7EO8Gujx8LSrSGQNGblyGzqDzz++SxRbXQsI1xtj/mHQHSN80IAsp7jjSbk9h52upKziXQyI7H8TbLzL0bkWPhRR2HlAX'
    'btFOB7JpB+H4M1LrN3a+WEbt3hoCqgaSIeB9Lf+h2s3RfQ533IXntd92Y6EA3LSuVgCL8harCHuZ58KhyA2LPJ2GiOxabPEmDOyW'
    'kq6DBH4hPu4uhfGBNFbr6VTvJ/rmQa6/zabzGztaOYuCO90pEw27HZb7c1G4wyaN+tum6CbT+921NzxsyM8B9jcGFk2LueXkBnMD'
    'fAaH6fSjDddmvKxNbLF6X23hjK4CMP1xrhxnEn4352d86NUdepYlFQsT163JIls9TZLRHU60IG2tiwPe5DzsTEsxVhu+7VH0Nrrc'
    'C5Uxs2Sc0Ssuh1wgK6jr4VGkayUNZu9yJuTe2hHE3+pnUNfUPEaFyK9AFms63TZF3b3bD9aoK1eplhfPrhS9dQdSBcwBz80reCe/'
    'S5GDl2mdxQokGQowo9CS/s///H+pk6AMC1IbRWifpxOR4Uti1g4Cxw3hhKVF9ZlHGimQ27KW3IPDRZa95bUqVwBC3ZAQDV/TqD06'
    '+PbV25+A1jC0TZEeHWVzJiPsKLDbLMxa9KePwowOk1+IVD6dyN8A9RbATdUbvn7+4vDZm5/ePPvds6eHwqSalx4/ffrs9eHQ22J8'
    'ZqswGaCj2wiZq0mcTOFwCqdjSJmwxRYyOb+HfhL8XnfgAU1sbcj/O2rViIkK6lQGgBCkzqmrTeg+Ra/3lx+GTwTN8bm4DGb0dHir'
    '87DWIfnXlTZV2jobU5pkbcXYIA9a/gqMPDmrBwv8/M//r+cDdTIQsMMnkj0Rd6Oc364fBEQE5tk8jiANvnpHGYiqmE7hhWYcz7//'
    'W4L436QqtYdLBrY4F839NLzVHi4W+hD5V+PBtuqJrL4+1ViUuIJi4IPVXYyNqPf3N6COqk1hY5hs6JabbCANCCAUPudF2WWFrqZY'
    'dghvGzEirVjJhU2r6l1VtVdeziqmMJhRLzYop75cRmxPmZCdw4tXENQpUwinoLzrExZzZWVqfEXsS7GIbAGVFITiVwgDzNMIxNeg'
    'Q62WvZXNUy9kHTSrM9LGv1yhFKv6gO5bKxigd5hoJWILF3pntQg/JR93kv7L/lQLtzOeCt+WhXweWDhVdMdVcMcV71APn5WRTssy'
    'P5n13bxp2D5EdCR90JOEcCu+51z+/SWjr0Zn1/OPH7AC8+qWK95yFd1irM237gQJm3HUPZ+OlMj2981j5G9uRhj5SwG6U9XzAPlC'
    'E9Di13pHd+vPsSFUl1IphEFa3pQSLKoTqevu6Jh2/APCXxFYWnv7rYrc3n+w3aAoRznN6XKYk2GF2WlQ7dbNuEPPbalr625pVLW1'
    'C8262r4btxJxO/IROyrOdqQ8B2tkZTs6BcAbUruDlqrYdJDumlG1lKoN+oJSTxcnbXmi42mH5j09W6N5g5YChXt61jWWirPdm555'
    'eXNqit6dlqLbF6LH5Cg+AbC8dDplKQvhvqu5PJ21HA4skzCaX4E/n88ZEocpB6geA+JF+MtSAkeB6YveeGTR7iVqM/Qm2UUviF2d'
    'FsVZyTPWXuhY+ePXr3/6w7M3B89fvcQp/WD7wW9G97dHD+S/+w9+K/OHG75//dXjw2c/ff/mhYX9MVpnXKyWj+caGmzD2wnbG7p3'
    '7bjcn6N09lyH73+y6cgm9kvi0eqfvzw4fPzixU8Hh6/ePGtNb9u0hzeL42Mh4Yd1WyUsoY/Ry8AYrTGPaloNRlC3rfJSr55NpXZ5'
    'e2rklk602bu1WRI2EE7sXUWbuPAVL226ECDaiGnw7dtNDqvigvr4V7Kc02LOKgpYbqrmf7A7kSpQf7wqNouiMd+zz5EmXh+PQyO2'
    'lXqFuQ3Qg2p3D5qFTY6qF/k45we/tjLLQtkvs0vofnMRTmQ7i5jj9waSuwDvKS/ybgj5s0KBIPisMsonCLBHtPyswJ6e6Vkk+kxt'
    '9WfymoXNTIMA1tnVdWRbHEavyiBYjNKLNJ8yHWZfvrnl2fEIlE2L93EGI26NOO4lPXt29E9lMdtfPsK6VSkakAuOZIuLktQTIieQ'
    'U8/O+Crh1uGXsQ3UgQnW23oMkO+QDPfllwrqrjZd4aqdp7OVk9Tq5vwLP7h4giuV5EJRiLWtJynyMGoVzF37atbe+KFY9ZDtN3Nw'
    'oSAPG87GII4Rb3n8qUsE5BAiJpc8XmTqZ5vBore/UceFrHfU57RpCwQ/aMQ9P2YwsFt/UVVqjiktHDO5Gvn9Hrdmel20bS/iW78p'
    'Gq8F4YIDaHdd2koPBgwwOoBUt7QRlOeNgsxXbtCtQeb1O9wJ51kS+tsgocVqZgQUCvkXpiWsaW+YnBTRXej6w8+NsQ9j2itFk9AU'
    'rGGkx6MWDzKBEFjU2fR4J5m4WQwAa8F0VjxzCW9b5elG9Q/G02Lst0R//bavBacfnS5Q1qgcIS53/4Js4KJr9w9GeFNVWaJCW+nC'
    'bkp7/maFTJF7pSN2m2om8p2hxU/Q9ju84T06gHTUnbAgCmvASTN+nh6tH00PN1sevuvETdvKUTIKI71yZkJ0bt2LVBlmRId7vtSk'
    'HZOlg8LDo57ryknRFOSTBvhjxVki8tAxdPCWZgS7vCvYhO5tN00GN5KQvcsFMIml/aiiAa93a7fuTe8+9INMJvlk9qNMAAwSMn21'
    'wRgAVeiIlF33Q5DLAF54ls09mrJLuUg1/OGkICgz8fU1+0Ije1jjDfcj6wNYhsiPHN1i2t7ovcHEtUHZ/XbboOvMLOmOs0R0pfO8'
    'zPqLWsW2hWZaRcn67Wd9b6vXeX6rF29UnGlUup3fGAHObx8l/KEnuv517wOwQGSrntVT+hk4cUSFThRbkGW/Kqbt+WdYb9jxZedD'
    '0ZtepMu2KqSfus8HS5gIamdXIuVNfrJQvnCKZGgsaoqcPnViVtRhcvnL3butudGR3lCX4M3AeEqISy/LVnoJQzb871454c+zIoxm'
    'sgciURrtekxvpsjX7m4lWv+68koOmnOV998S8Kp04d09RCU1E2rI9wj2kwjPX3EzuWwmelpyBJWdMZgn0cxU7Ciyx9A4GGdvS8PO'
    'TXM+6lns3roeSJvl364DnraDiXyyjKuwUxCpQDqqY7rOMXO3bLqVW5bakXm7DuRCjNYuGhbsuWvwrig8H5EDjgCctsQob86tFpKS'
    '3We2EK9EL5Kb49OgOtdyp41viOjRCKAJfb3WmZdF20Zfg7QQ7cZhHa3gum2WkxbzydLc3q1G9GU23xxfbeKv8IuyhFAOY/p8AbTH'
    'Ix8DNtKil7wvLc/0CIJmWai4hyhHZI+enC5V6bRqhItiWuJVPCQyJ19Iy9KECpCiBByj5gDpvcyy0iEbTLR8TNLPTT0pwxwqbYhB'
    'fjO1zqR4z7GcRIpTWVbVNTMWjRkJkWRY4pQOgoLVzWVasN/GWVKe5URQQZQbatYdZxktTdyC8n6KFCOab5arZa3q4+H3h53GFjf/'
    'MRqIdCm7IF2tlvsjfIctDr9VaXVfPXvx0++f/QBzdAmnz766gqi6aMl79/5V7rLvPuyOXZTlKmfcPGJMEftoGSPpOTeq+RA1o0wL'
    'OYFRO5WBLlf9OEINJ9iSR6ytZKK7lWb30ZNn+aTsM02iP3i3/R73ugQdvlKRm3QFjlcLsjNaGrIJk8Y1ThoeE4QTYhF45mfpYprz'
    'VnnXJQQcW6chE8YVObhEAXEf0xik/6+WB5nWf4m8FlU3h8l4G7ndNhr+VtkKshnp55FOWv+cU3SuJZ5pl/rOBUPSDV614pJP9h4l'
    'D3BFugdrOdzsWpQrL98UBSsAAdgSUzdrzljYSqXSsU+3dvHUS0tb7x/Veg8Q1/OQGAZunHLf69NiWcgpATNqXgapfOgmMTB6b5HQ'
    '7/Y42Jz7AQBD9gMWL0cGGrBzyx7n+fIUceX95sztJr8aJC/7eFxRds8xPwPXJ775XeMxeqCs9HaVDYYFZgpjtMxDRBaz8y8Yp4M+'
    'OqnuaboYI9Q7Lz7K/ERd5WKNuxdrV9Yq6vg46ri8890NTdQGoW44DF+dKVc0yobVn4/dArsIXq2lS17oQnl9MfDCWHsJo1EvqH2h'
    'LOzZa6AZvZPGPmkou/Cat0AQPqdOHx+evaGe6jK0HWMDH3bne4dMaHanDoIE7LgwfhyA2Dg9BTyYBXOE5etuXsopkxhKBM/u1lMJ'
    '8OUugWS+Vx1R8UHkkBDRCTKc1jOomB1ltbNnlPj47YJea/UBCweCUOZxeGR/02iVIOs77lOVwTPf2HuOOp5nSLCABJTc304UJqas'
    '3oNKaRnHLUIfUwY9DMoXn1Yiif3Hv/YG10PLFVf/M+REUG4lDemt+wjJt+B9K/2+LObs34fkehitMTGvKQb5AO8eEN7h6pHLGk7S'
    'sd7PCIVkUqhTXlXv1C6lyCbx7TI5wXTac5H/USnrObRYN4u+pFyfiweH7CSltVtmDfaCQW3dfwcsGgAYBO54voVogN5alWhAdwlg'
    'M52L/IgLLowJiCglZRgFl6Eff/dsPNmjj293Cx/RnjLYNYv81EIGwsJtFjMw0hYPkLh0L2zXJkuREjBCSJfA7XLNIDQd2wVMBAVZ'
    'y2R8ZbSr6zk0OJhZtlPpkC0HXgTqs/5IYz53TCXQY1JjoxF5jMnrOujjraPgKnfALfEwnOnDdGzzAVeFKjdKyU/0jYNrGK4Btud7'
    'gQMOuxAbWCY4pgvWvmHJPFA3tkz7unZNYeuBfr9tUs6Rputuj2fGUOzXzY0fTOu0hISCidEpcc2Gc2IASuBdLMmm8H3xnLCK40mB'
    'OVvNlvm0tumZ3SJbSXh1Vo0Im2kNySOTzguEwilrySBD9brmzir5Ee63KV4LUALUCZO3j41z3nYZflVfhm9EGZGx8QC/JWE+cX0G'
    '5z0F4/Wj0J7l0sXLmSgOuoMxsXKBM+bvrJFVRcR+VXRikTi+aK4HqAfzfVloYjH5lt5L7zQoV9+1ZgGeuNMdUlf3QJgXNVmk8mnM'
    'QDYt66aRT6ozueEFbHxGvnuLxaF8O/bKwPgGiba+gN8BqdSwNPBSyLSIUc7g4IZd4bbn0felmq65Hj//5X/9/Jf//fNf/s/Pf/kX'
    'W5gUwasInaM4RIDUqpIpg2twaFX828o5NngL+Q71j1oNVDtzSn/ojJLDAqusMfp6NOEEwlYwF8kQ10O7jr9LG93RdTHo5inQKd2h'
    'DuAK1A+UxQ9OUbp66wISInMiKjbCWS+3KBsqj2z+NN8IlM81CimDB9mOaqKysjxXoCFYLBcmVtjZIhd6UZ0IaZlUid5BARqaRvqe'
    'YKwhsbHFuhqFR8hW7D1ylNlHtvae1cuqs615jWfgbNAgRdWuTRZAKcdOOhy7W38x/p73tVJkvZprjWd88ck0/euAzXPpZXAqwA0g'
    'I5URl6Vg2OAnLwvwYqsjWaUb8j2IZ773D7V3sPwot4S841mELwnrjllHcNcsU7mzakslGdfiImP2cN7CKwwYiGYOoOf11MOkJabC'
    '3znZzfXQyFHpVmkc4q9iDGwmWgTsuUWBkvayLcCw7QjVWyoZcjNdLnmGLXVfwWxaHdvksenS133FSoHd+tWi+pRShGtdtcZp6jO6'
    'l7lu5XPhMRfSUv+x6FWb+HVA5u1Hg+UiJiP52clUDpNS159xT1qEMzmE6OebUKkpOJapO+XkDT3RL1LOBYAWHZ8QdfJoOb2yGqF4'
    '52U6U6DtWSDcKkHcY8Av+oO5gnTtFVFvZcsDol4zJ1E4LhPfEcF8lDXEQVsdDKylOvU6VqXR9J/JrPShz2ZX7l3kT/rFOJRdUR7V'
    '2AeHWDRCSndwI9wAXmQKOhxIHXshojKKDLIXPGUoKtxsB5N4RfpfsCZlSIqzLAUpKBAuVVWqwpOJomIz4lv9yN6+V+m5pRCA7qeC'
    'SdwBJap860wMosLCJl/jcm91F+GxYfAQhh8ovTISWTxYAWBfZjAfu1ieBV7y1teZpqdOa+0rVf9QKbGXraFaOIOdn4GtplPZspYz'
    'nsCRdgklz20uZNCAKUlnufGgCCoA5xHQGRXkdynC8snpbVjskv1jRa/gV/RjZxKQR4PInlI2LzuJrLxUMIsbzzrdkSlVAdWJTey3'
    'hZ6nQh1Lq5N9eVpMM6/U2RTdzCy/yS+yQNmGfyBdnFGf2aTYba/sVzH/MlsDX4c+YtMhXqHpJEPY/Y5YP0D6NFFAZOQuzEnONlfJ'
    'cTpRXiS0frxMWBwHCROXhC4yIa309b/1jcI2FTw2Xd5M/9ieb7RPNqYyNKRQTyCNzZHMpJvSZtNOATckISMR/W9BQHjNokkfX7MC'
    'xpI6bQeJHD8pmHx0/HyZytLj0wGsetA45GJ+cqKfDk7TOWSn46/zKdJF5Zbikg28ycps2WlfpMNpMWG5RdMhXXFqrc9RtnH/nZCM'
    'VtO93Wm+Bz0o6VcSzRM9uhyBoPfh5ed2eXdLnnVNyUdds8c//89/UegQfruHz6CXUseO/Tvm2DmkehtUWcZ7JeaES9uf50DPHhcf'
    'RYOeTvM5VGlpg8c8gRDVkKnPwR2Cx9js7paML1BWgBQ6I0sWRXNkHdQ5lj6SZPwmIrkILSvscpfe1zzcOJWuyjzq2Y1s/viZNTn0'
    'EwaoH9HnBn29VhDyOgNy/romteWiQ4fEkx8QCfsX+ZtMqzS0K//Gdan7o+se/jzS9yv2pZNmvUOIDOywipzK/a5rVtHKHxwp6T0Q'
    'hngLDAKofeJ5uYqeTesVKBizxm1dGXTUp6IcVDvjqKoitXXiZeEfk+bA1PYTGlBp1naxw7df9vz8pLGEjCzsllLscuuyoDC9t63L'
    'plbDJ/27RqDDWhJWuDraspB0sA6B/WzQMsUKx8ZKMmadRzlVqBpDupfLIY0lCo1cWtVTM/sYpY6St0zz8nKOaY5Hhu9qhWpuYcCp'
    'MOBUGjBniP4CrJ1RwiFSKrCop4l6zyHZZB/nBU+wt8LjQQ7fyWGIADxnOe9aVi2F/IoJs20Oy5mh1lFg1XJRPi9o990/7r3/5R5z'
    'g3xqUMupIVusMppdplfd9OEqAt9SmzarVxnb5EKy8A3GlLHlqEI0NqI0lKos1ZSVoS6LvA8Qcgy7AHFCfjuHm0YBAbEiy9URQgsw'
    'uhqlqVfAWDXbccrlaoY3k5hP5IAOV2heIL5kWZU+aS6Lr42BMpuKeVWF4Vy3HO92C2O11rRWX74DZN2x/5RKu9fuhVxeo3bU1w4F'
    'eeSbtz8PbOsUsXiOVkPZvIy6A6/ZxMIHcnkdTtFiCg3N+Y1EFSlQ+ROTbsspN9HqUepvepICtd7KDdA8Iou2ZtfaOY8IUkYuBCIs'
    'OnuSQ01SUcycOmYn8Lqqym3IMLo9w2VTsn6mpp5pcrX6xRxcXW31tL44PIqXzpy5fgnPOpbvBeEmgVBWb26IgTJ4aJIjGAkqrduP'
    'zIRl4CBBErldLP2ktk1q5GHE4BOHlRvKyjHXF2eXGWkATwZLgixycb7JcmBHxWJGZ0jDrCPKX6zJccA4zY1ru60aPbTGdGAgnNGK'
    '+PzKQQWP3NiOax9I9nzTrZtRs5Jv3okiCdVUNuu/8xMy8tiFP3FPpaXagva1QJTlVsexA7ZoYEtrhxGGqlTB9++AZPs+Cr0ZJgg0'
    'YmIqhJ3nk3v3qmdc+meU8sz0OWxzmGp2kpRGmWWxE/gfWGVa2t3fT/A9uX4YZTInblHqhK78usorj924h7QL29nezqGw+cnUyWMS'
    'yi/VzrAkZmSMR5ox5JyGIKibjlaT9IpmfhdeZwlcop1i3MVOqw/BZcY3stepR4Q+80HUccutZ/zbbr5X5dXvbuV7N3kLGiZtNQWV'
    'obcE3epie0ZSTEGOiIqccMpiQJoKDk1iOlKfDj9qRTt+pAarHzmYFp/TgvLDjLJ+e+jDGC7xDn74apYpNKbXIkrwezk+KqjgIVfV'
    'BeKYuYyxBwxeQ52eUfI0YEeVC548CU7s9FYu7DUmkjywyKgWaHZeru8oqWiMzN2ZpNQRWdFtNap1/FDhk33YwRoG6O5o9xL6puqy'
    'JH3T/hgLlgpXOpbqMZXk6kmFNZ0WMBbY8SGC8jAw88ixXDr9APuS5xZM43IGAbMbQrVG3sTrx04IK8Bqud3Eujh0BXYvlD+VagZu'
    '27WzItQtohBw9fUlX8GVkSbBINuOP9qpnDvjtmJHXmJUFrDY6TejkF+Fd8Vrc7NN+gabbCXVy0ryVRU5MkJBY5SrWAYV6an/LDVO'
    '2YkVZje5EsWMxo4TtbhyQ57KjVdy4oybyuKsev8zVgjEPLWb4VwcfhDsRsPKar6Oddq4wrgL1uApzegTuupNDwkslCdFMTFV+Y8r'
    'nl/ycmJd3Gzsw1ztcLc1nXK8xiSSpjXwHwDzQr5E/JdwL+ZdBrwvPvl4ZhnxayDGOG0IqDFD55pT6BhXoaYFPoah0HLjQXWjQ56h'
    'hMrIhWHl6Ws0gEd61z4MQH2L3etu+ztf1hTJbWfqQbTAwgU2qj7gIikqX5xfkXYiMIyQWeCq9DGAQeiCTg7crVWrhnbbyZh5D4Sm'
    '0Ug/X7cricHSY6xKD5ihSYdiyoId6bjsK7JKsmUvk4+byf2BsPLt0favcRLzztOrebHsG27Lprv34zAxnBb/0xUe/XJ74F5fqbat'
    'AYxhjZWQFkV+YMGHdbIenaA8ZH2opNYVRv4BgSGEhL433N8KN3yPG26GhCUnPNGG5pP4zMng0Nq7owvXkMRb85amrpk0TBLUkH5N'
    '/MPrIJBQtsSX9hM7sv3chXilmdV1RSO9UDbebXwdyz0MfzBsQW+F5YXHZScLYBCb3FLbSgduKynbi4KR6HNvASZ3LDDKnqI1xQJj'
    'wQAINONSGoKp/uKTZYc714J2TetZtsTPKlGA+SLWZhqXn1Je44tiWR2g0+wc8Zq2dk62IsIITWkakQuM93jZmQ3KfIi8VN9hlQ8a'
    '1OCKE0JTNTtOWFIKARlIVqIhMl/i5SDmC+UuCuourCQ9dg6h63YC/IHBIGiJrmIIJamj9HpQdpTI5o3KtziCSlJDnQaf0abZkCb0'
    '59sLE3p/ZEPKMlWmXF+p61rAskveaXEZkQRfv/zGmX/NfrQ0rI0v/+NfEy3FCfJT+/6CXslqGyGCQk2KS5QxtgiA8FiKXUPSOXmn'
    '2XBVqSudldelsIuCh7wKvPWbooD18qviCBFuxWAY2IEXltWvsdDsBSlYxVzNqYIq4IzLLe6kONwZwADqc8x99KnBUcihOWeNYQVf'
    'u1K0t3KZ3YIY6KfOqkVuxgTRz1tMsvXsybBbOx2JpI4OANdyNaOEcV4gVcLzAo0HQHhNtryUDtsqMzHTdWqUwOeWm/Bh0Q4qAqja'
    'JWfA8a28sEsOoD58B/wBDlRmy42uATIksJJB76JeOOQEjaVibJOWtG6j9FpAazqZVEFPw2Zwsl0vNTK5YoUqukKNZVQFkjvAEfNZ'
    'mwfUDgZfjbrBgtXGp1yY/hlTqV09aw/p2d16e2KEi8JfRukrPEbafKoukoXnShcjDAIKGD6HSBceThXIPi3CepxMiyVjBI6zlH4l'
    'r5iEZALjnNI5SOJ9mFQYghzfqojA7TFC9FCpvlUGOdE5X2esxBjgiWhd2vE0nZ0pEO5UEQQqhMEGriDImEVsiVn3METorTKcME8y'
    'QqQR9rdjRLzwUh4VcV6yBq/Pb3qXe6xE5l4idGkxkAHKae1AC+SC/c68KuZ7iqQ7ZGO0uM52uKoH2RKWS927hsvFBxUsSJEM1+T4'
    '+sTRYXLAIr3S93riPVPi5b1gCpNBldXICeHvWPj9EXodIB0dn6PXp6q9q7pVAZqy9rUvE7YEYFcHlo1cY73YRu49X01TsbBKR3ag'
    'jDlDOyHPYDFkz+XJveS+VRPzy+CsPKIfXH9A/T2257NyUXKq774NfA0+3yeFV6AF0Cx+j5L+/e3t5JdJLupHv+09A5a6/7te0Mwh'
    '2Gn70Mhpw1sVgCCES5Up1m4bEEVw91coSz1oQqX47gMgq7qc8+jZDu549lFkg9r7win/EBWkkV30aMNYihW5sm9VhZnG/SiTtNda'
    'BslXR7NET01etJ695EQ8VMSSN9kfV/kCSbxM7VWIoCqdekfz74uZiDyrGTJCSk20oymD4aYldw8i8mzpmeurccfALZkxK7Wb9H7v'
    'GTCmPNlJGoR0IH3BBZtk+WnjRYaD8aTYwEg5oIfuVQFIy927bIvZgPCYRi37BxwoVfw0AOeKapisioQD8Eh0eETj9Pwc8znKVEBh'
    'HAnTF+mt35sv8nMUeh0mVS8+Gzl5JOu1eSIqGXA0s2nwGi1oIPKFv+FhyGsM0VtGHX5lipjFWA8+pyNBI/WOIO291gv59kJIhU/F'
    'XJ5bFshI1ekG7owgR2HZXCjkMuNLNWlhYRh3ASaMgGW6lqqneKn+KF9QbWYd+6TaGrrreQLGcyDaDXGOa4T8rvdSBIa7yDnGo/zw'
    'TQEPDT++zhbH8vjd3vt3eHue/F3y5XttvZNZv2wF9/EkHt/VBCSqteLw1lqera2gI9e/OYlW1Ws5J25peOqCN9QxFT9VR70ygHwQ'
    'Cws4nRjAndz/jUEt4niGZHshgpSRHIEYFcXgLVPBU8+/vCXWOXc0FNHwL2Chc3o4MdGE7yyyK01nVaO2Y5q0MiL9ryzuGAabF0T9'
    'TZcpJCYLM6G+Okr63zOLg0nB+DC9hMGKyFODIL/76auXh29evUCKdw9RTvQJgOMPE/uqvgb/laVHhokzoIWu5IfRpqy2ayB5FRD0'
    '3gVbX+WnEW1EQ2hn6DaMR2+k1733UT1Y8p4ax7HaaPLo51JZOHoPG+8Kf85WALadVpC2I4OBqaDwLB9X3pHqA5jbsoorZ/SBna+y'
    '1kHzHCx3WHVqoR5G9brijFHafbaLdFzE+wI4Ny9WpUHSWbrn/sgqCeIhDw3ZcnhgyxTHxzg8rAMGWh/wUpEBWrSFz5KJnRT/2fsd'
    'fVu33Xm9Qzx13PdvyWRaRHa9MZbaY1HdsJYciwzQfhRJGRVRtJjcoWIoA6LZgVr7wwcU4utNRWv0MOJbeiIY73J4Q060vP27m01u'
    'NppsVMmp4KIaXQ8L6ImYlVp2peNj+z/Ofpwx3R+/0k2VsVgGrUOgt5lDhQiyRRzOgRp1PTaCBzzYb8E52MBKR9N3JxyTyteNeYpg'
    'Q7rArqXZAOv67jgUE2qv1FvGHraTBc7B00w87w2Cun8GZR4XGWuBdNL5aOA5fc38hsUKm8S8xYn6K+om4ytYxyz0IzxkLBmVfG5m'
    'fmiHtXFHS43LK96sAsFDd0rwezu0XB0VCSq0epba73fbq1Vrbm2siZB1h8XsofsOGoVaXMfNRiD9/t3Bq5fIvyqz/poeubJVlIxZ'
    '0qQcmLlDAwfzP2X9Mu4GLu/vV/YQ9gtOFxkPbC/lCLU3kU80oPP+Txl4lgG932mUmRomDgNe7SLcwvB/oWks0iIrhQ8eBhxaxxr+'
    '3jrEDr7mSwZhgbli6Qr+6Qn8UrDZDOq2p4d3PGBx9VKXG9DWAn6sLDT3/EPvY1mtuuAOZ6dOBSmJNA3KAVL1gR6ejo5bCay+a5Aj'
    'CXDA1E2yI5LXST5zlm14h+Yyc3cCnPSHd3a3tPzOnnxCRR/8BdDq3p3/D1HdQyE='
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.10.20.2128'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = ''        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def do_POST(self):
        global last_seen
        if not self.host_ok() or self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': VERSION, 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        while True:
            time.sleep(15)
            if time.time() - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. Everything stops by itself about '
          f'{IDLE_EXIT // 60} minutes after you close the browser tab.')
    if browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
