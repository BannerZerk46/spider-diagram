#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrsvdmS40iSIPheX4H2lOqMKDpJ3EdEZMyQdNLpvJ23s6YeQAIkQYIAiINXTYv0U8s8zvauyP7B/MK+7/5JfcmqGW4efkRGdfeI'
    'dGRGEDAYzNTM9FY1w7d/UMyZe7RUYulu9O9/+IZ+CF02Fr/dqcYdKlBlBX42qisTs6VsO6r7253nzrPiXVhsyBv1t7udpu4t03bv'
    'iJlpuKoB1faa4i5/U9SdNlOz+Oae0AzN1WQ968xkXf2NQo24mqur33uWpqg28aDJC1vefMv7pX/49g/ZLNGXp4QGzX7B/+ac3eKe'
    'cJcq4UDPhGy7e9NeE7KDy2TL8msR2Sy8rmvGmrBV/bc7VHhHoMHC9UZeqHloJ3PY6HfE0lbnv90psit/ST25/yNTgksCLg3ntz/S'
    '9NJ1rS/5/H6/z+2ZnGkv8jRJkqg6PCTQFBTNA6pIEiTBs/A/XP+RKUM7ijp3/CsASZXtR1tWNJgmQlPQC66mq6iNA4VfR5fH+PJA'
    'x6X4koradVzTIsz5HC1MWAeVZWembtqo6I80w85EZT6H6/zVl6irL9Ecz6jT+KV8GvCgMB6Xrc5cAo+exoBGVz4ewBWPoVuq2mLp'
    'xvc2fodCU0XMNV1Hd56tfwIQ0Kx8jiFYEK4tG87ctDd4ztCNLrvqJ4omKDrHfSYwWn2icjzPC5+TDRqmofqjtM21GoxwjuckKMtG'
    'YNI5KlGMRj2TLfTANj1DOXu0MjUj+cyHdKbZM10lZv7Q8CzMjvE1nmImHtjN6kyOi+rDqG684a+6/4b0jvqU4DcbgCS9qxP+B95h'
    '34TLkt0lgSmgCYsoDbkc1aTYnEhQZE7SmZyQpXJMk2JQCZtjdRou4KYJj2m/JBsWSagE3iK4HEdIyU7yi+AXESpTvvPZioM5TnZp'
    'Oi5mFc7M1iz3+x8IIp8nCpalHzFDgb/AZaYqYJ0K6GQ7LmHJmuF+AbayUTdT1VYVYI0mMLl7QtUd1WdNR8dVNwQQmKsZixw06tpH'
    '4q8E8FtvA9STCy/KuurfA/eB2jm/u98I3QRU7rmmDfwot1DdJ2ju068BzIrPJb/gyr9+htYJ4r//d+LTRnZny6YKjz/9+skCrqba'
    'jk/TwHBR3S+EItvrz79+zuGqqkP8F+JXVPQr8YX4VUeE+evnr8Q/QYszVOEjEAevo7e/5cPJ/Oa4R8THCeKLbZou8VcMazY7XXwh'
    'fpmzc0adf4VbSzZUHZXgP6gE+DbcU3PgQyK633iuqkAJPxVokfwaNIMoEApVRqUUGVWTZzMVrc0vPvdCRUtzp9qobWpOqjNUYpt7'
    'GhVM5/JcDJtyXJjpsFRA1RQTNaRICj/Dr5mGD7YqqgGQUBJAMJVmM/8tKAtgV1hViZqHRYHFTA3RL7oYqWvKjntZEtQLXg9aXfqI'
    'uJjKn2iOuw//5qTPeM5Uw8s6S1kx919AIFGkdSAY9A9+gbxH/+Uo7rPfWhpP8GKiB/8Urt2f0YJn8WojYWmv7/6SXk6KooCNJ5eT'
    'kqkZTcbLqbIqp0rJ5ZRoSZSZs+WkVYZixNRy+hIsuZw0R4u0mlhOiqdEanq+nBRLcZQYLyc9hda55HJSCi2zbHo5GZYjhXlqOWGB'
    'yXjio+WENeLp2cVyxiMNl/OsJFx2f86uLCd/T4v3DA1rSb9/Mbnri4lWK1zLPwFNT81D1tFOwJm+wLWNWAoU+XT/56WmKKrxF0T6'
    'mmPp8vELgaQn8Q/aBil4suH6FXPaDOpgqfmFoHgL3vdFe3g319WD/+5XLIfDa196fiFmnm3D6pYQqF9TUvgLQX89k78wLUjCfj2X'
    'vVE5YIWrAc/MyoC6UJxlrGBEU891TSM5Hs1Ar2cRgF8JXD+rAX91ACYASAVoVp7javNjNlBm4wcLBAp31jRMRQ6mepeYDzY1H/hu'
    'I9sLBDCJYUM/dNgO0rvvYSkUJCOieokGSPKPQY+4Dl7jqTxbL/DovxA72f6EyBBQBS99WAJYBkWIZOY6Qhx/cX0cmZtGAFueyrFE'
    'FlRnXc36kuueKCLVuSnPevi+AnXvibueujBVYvB0d090zanpmlBWVfWdiqaeaKmeCk8KNmj496CdG07WUW0tIJpo9v1pR/+CIENa'
    'o4ZUewDb2xghliK7A8yBv14ZJGYuMKgIcWEJNjAOmFLH1DUlqIZWOBBlOeAQyeVPALC30Xqif28gAl5vmCICL6ElKwqmGsAATIKJ'
    'DjJhPwFgoE/fhOpyVIiJBeAGY19S0BZaI0SqQC4Ul0YiEeMQRiFcax/gikAC4uyXMA5QceSZisjOHyBq/BcQ48hiu0kOG80IiZA8'
    'QybMtD9/TQFFp4FiMVC8X3iIqJnEU3UVKOACDurCVQ9utKjIxvCcgNCiSafDZUgO5Ba/OhtuzthAjQtCwN1m42JV1zXL0ZzzeUi3'
    'pSBNJsXfAhizujp3vwRAAs7n/4S1Qc9w5J2qZMGCNhagdKH3QUAdHbAZHW0K+vLS3KsABKh9xgK/gjv6Uz7R7Rcs+aDfKwR+iU+4'
    'coBQmmF5bg54rb/uPt1rxhJo072ymulFu7q2qSXBJf7CXSK8L8E/X1/Z28R9jYl5ri+d49XNoZets6U4I/PbVM0kRpK1feLh4yGH'
    'RVQ8vETRTV6DQfqiIxE/W2q6EjOE4OUAm3KYDuwIeCooBr3lfI1v0l2K7nlE9xidIyv5C+FZlmrPQE//SuhgiwAUqFu8dDmSVTfn'
    'g6XTkg24uKoju/6vCYkRYc67EDHNrm/NnS/Q0igipDANYZ+ESkKGYYH0x4t5la0k5wotdCBX/GH5pPTFMN1PXwBdZKBA5fNVYZMk'
    'o+Dd8IVwbqICxF/Q5LqAezk2BlRR57Knu8lGclgfuewO66QxsaQmONBOz4nDV1BTIOYsW4NlPV7tIiLIoJVfsDVyrcOo5iWaXfYV'
    'cadkj6ENlKyP/HBIyYnZK0NeLLQQSVZnH9ihIVeik4qVfxe9Sl6yGaQ3hahHn6FejJqHhGaN/kNIeknaPizB2l28Q0fvxOuhy1NV'
    'R6rhbH2pgNzmTFxE3AkMfifix906G1nX381LsITDVlNA7JbpaL5qZqu67Go79WvMqtLS8VKshrAubDkwyWK8SGMZ7vLzRR3siIWu'
    'YR1Bp18ETsdP/jsgPz+jNbr3HYKWjOwIVHDZjj9EhCc+sgR8wB9pDjDAAMxBk5QAeApFyQnJKbZpWX69SAohFV6RnaV6IemCKlnf'
    'wQqWCB/N70w2drKTMBOwXp/W8iMsmermbA0s3fRmS2jdXwtfxnkO4uQ++0lqO0H7OcNU1MSgIozBlXxD9WKV5SnQBmDHV1hvf9b8'
    'hm/oTIGZFeBtgn9f0tktHcBXoNNy/YZl48N8zvtik/uCinm04OwtXwfG/rm80fRjQp6l6Mmy1axPUeEEBMaCbBz38ALMzAl6VhBB'
    '0BFaIQveeWVqff3Qp7jIcsF3oWrhczR/wbKgE0J7yal5y4jB/AMj3LvIPgV3Dl7RZcsBlIZJMG5o1P4QI6P6HFTZc80ES0ZkIp6z'
    'M/omfFcksIZRJ9F1ANvNqq9rGudImNZnmaTwWU+VSF0GsUdQqEVPy25Mw8RYck9El1e1IQw0dve8ghK+nYhNBh87sMxK6HBxnCML'
    'j+6JrIgYXaxrkLeIBvd8TjOR9+lzYtgCMmfZpKIbzI54TRLh7jBUwWACUIgc7dzHkKPbG6gckw4ToaDrXc7SXDuoSkQbNJkkG/8u'
    'aoglI8uF5cnQAA1Z60zWZ5+Av+6WRJZgaH8CI8aGcfYDTgqfyqi03kJhloM8cpQYTtKHDJyP4W3IQ2KmF1BS7Cc8o3cuh/UKLJsi'
    'kZPjwgX4rxsUOEBBhMhu55EJiBRjf3FC7kUm+VVqTfy74G2fEyRXgeV3y+SM0RHaJeEMrGfUZx9Fgc/cIKL/2DeWPDeL3CXvVK7e'
    'ZInMdasq3VfM+hJWcLx8ZJqL+fh+teeo2amMNOdwlvgrdEhfN5dD8+RSRqfa1pLzE6gVaaXjFTshSeh4ZYGuOedrRLThGoWOAhq7'
    'CcjUxNJUpAKhN0B/IKykpxP+Ey5qePq1KmlPC01evKZr0WuRc5C5qJVzNes9ujF78WYsFVJYE2P1Wy6RND37IEaesitrz72+9tFK'
    'G/Iuxs0Lx2Ga1/PJYbVgWDesWC5W5cFaBqUPkAxx5KhTUHJTbzCpOME15p+qMNd0V/XV7mMQvP98Nt/TnKeFA0pR5e0p+RgnTU8P'
    '6d/fdqACXA9oGB+w55L62C8ULzOsfIvN3Ay1JfoNW2JlRRXJMwz4KFjhmMoHIPTLt9MVcS8LHbu5I739hrqfWudzmwjjuWyAlecz'
    'Fmj3ETVL5ViHUGVHBZmYhZdAOZ+jnKFA+fyva/U4t+WN6kRv/BXpSzE4oXGZMAxDafELNovLb1k/Ca3+VS0M/v187ixNOTF8YXjL'
    'WEqolUjpTLtjL0yTV8yem7bSD9lkkiRdGmVvqRmhCjdHM2f/FF13/CmY4Gg5+GiyN5rxiUOc/z7S6/4Iah0y9z5/fkvx+ntoWdfi'
    'a4kJeUL+93OjP6kuvCuSFQsYKqU23XDlcxc21lse2isO9mAADQ1ZMClVjiORKnemQp+/80XdWCAVvshzN4hcBNHUX1smiKopyBuH'
    'wJkov176PeLxktF436fAYU41Vz7CCsVLEcle9bld1Q2gs7c8uiFMQewoQoVUmJi8Jv0RsiTjG1FLOKL1bo/czUDXTUmHO8Gujnc7'
    'Ea+29ZGgW2x7sGHEG4PhLs50Guq6pp7SwoQr0yklRTF2fWOcBeVGm6kO9mecGZ8JRhVRKBaI72NbSIX6iFWJMfEqoobcD+YoIKTU'
    'hEUm7j7khbeMbzyr/ogjXn3NifNDAfPXMyciyzhaKNF3EOG/V10QAVX8DEs6CqEEovH9tjOT485i2jw2PQJGH85mKieGThG3f3c9'
    'wJJs4nvo3wooG/6j+TjTAIOI8gxQoHF/Hj30nU05Z+lraKFWTr2qyZChxr2RNSPZ4tn6Iw4TjoaM6UZ1XgkYhMTsjz7Bo2iRPJtQ'
    'ATD36/uzRN6W8YGJeDPgGA+gix3eKeI/d9lmMWpi/YWMGUHscxKT0gKgzPpO9AQj4OJ1Vp2PeC2uCChfJCaNxXekwfhjjVwq4Spf'
    'Jo/8FOHhD9M1Td15R+5NmGbzNc0YPjLEV3NqUuBcOnDY0Et9EZa8eDkMiKdfjiykL1+WMJM4e/ITei271z+fi88U3V+8sNEcB9r9'
    'fEvo4rVQ1JlpB7aTh9QtNAlBPOpGu668uA3JrehcSn3xpwHlhTnvS3NKr6UY2UQXGttHBCR77ttl6D9e10RTAOcMPesGuP+mMkPl'
    'uOt5VR/Pr7gGyI/6Dq64D5MtR3idsC1SsfELt+SHY8z2RtbTNi1ij9dGuTBvItsNB+vZ61FGwW2Ev/YioM15GmZSe75ijr9zdnOK'
    'ejOanvAeXbizuTM2Erf2WkbXxQtaYES+YvIx7zD5Un6RSz3pyuMbkbIo8+syUe4Sbn+k99eezM2Zl2AnKfBvcvYoHHwtKSw1zfpU'
    'P8sPS6kcf3wfNsKg4wUIBecrEMfitujn9EYvnfOpWKSzYeTofFAXyHQeweFeiVGnIflzoJWj+UPe3t/u5rLuqCiT/zYVxK+H9nyw'
    'GyZh0Muua3/CXkvgajN1aeqKehGuj6jlplWSmLPz+IAYOSvjOks6bRXSqYxFHJAjE17OxIvMmTkppF70Mx3ZKy96+n3y1tSvQXkW'
    'orjWjrZZXInJJFAznRkShtL8jnDm73XyPOsGL3KKuHB8H0tUfPU17ZRK9ZBMDEo0uUzNgKsk5M1bagAfqlnnyfqgRKQYCUte7fmq'
    'hyXQ8q7LpMTreI63Htwn1iyYyrTfNql0+mvI3PKevoNoUCbJKz3GWtG19bw53Bu5KkFOP4Nz+rnbyQpnIMqvqqhJwrHT6sU7lMA0'
    'VaW46xxvCUvjRyKz9e1skbd79/NGzI16zbWjGTgYQSbzEch3a6M39l/g8aEeg7Duj287OLP56CC/4OvP2RQRgXix0UBI531jYxNH'
    'dK9aex8zYS+6TrtMrmR3vu4yCU3p70FDtwkSddpTZRtnk15zm9I0+R6f+m0DNeVjfCvO8P7NO1fc8vFYXtWfEkGe82xVxNH8TWIb'
    '7fBJMwjHXkzvzyJ4NPfHVIplCnXmWMY7Sfp9FUUDxvU+DH2Xv+C2q/R6SCAFds6/+Ni2sNgiO7f+ExG/j0WYgoDbbZK+DfqlH4NM'
    'Zx58MBUl3YnhS8rrtjJaj6nsaE5yb5rfgOPKrpdGCzLMjCLfG8JJ+hqpM8axsDXl/So17tfXwaKFRi2ESVx8jESRNgtDsF3fyYiq'
    'ZgEJLOQwzfqs30EeTkuV3U+owyza23iPIAb17RPN4bgkNbc/h9M6k20lJX1i9+g7Jc3t/OrITr9Qf/4OYdCkL+HNrSAXSYIxDyJy'
    'FJdOFKTChCI8WZG1iG8wg8uGG6X++qbb/pqn++VTNsj5u2Ivol5ywWbUjzPSeKtAWjbhVc+5S28zhUZlx4JFzWIPBkI6Ig9U8fWt'
    'pPifkRB/mQzvW5rsx5zHqfGgQ1EurZdXctoTLQSbXC9d2QGSfcQVyNzwPwSwJpMHU168C5n+Uzzefq/4TJz3xkt/Yr+OoVmW6sa5'
    'b1grTsuqyP76kKlxAfWZ/4HlznJnYbKna83195SHN35yji5v0Lp9TdbJmraG2W5oFd7MZwwwSFYWt4I1eNBinF8iXvisro0/kMGv'
    'x5eF6zln1/dTJcC11Z0q66/ByyfyaW+ko18IyET29/VU7GssNQQmzVr3mrsEBTAGNBk3jDmkoaKY4sdivkkxHqRIBVOPzwX5EkUs'
    '3iQX7nq8/yw9LQI0ZVUwqc34/l36uAEqxyc1DOzmgvex8Pc5DorE5oksldT8yEjb/ZBXGehzfb5Rbj5XSZ5PJAkGh39cSwNOaHtU'
    'Oi6MmMINTcPfwKYivh1HUcLCLM6MiydMIN+9gSRu+HpULV4b3UisSPq4CN/k/+gREbnbh0SEHeZQo0gE4LavtZYyq/zdXsjnC/Df'
    'n93f3F01s00HdALNTizFa7urogg6Jv44gy2DJiuZOkLF4WWGOw+Xp9I9KD7a+/Z7djDQb+9b+KDeSL4jfS7MoUCFr+/m97HcUWc3'
    '3Cqv5tSkG8ikGnt/LDOoc5aQ8T5Vg0m/ZKRdkeSHKC7KA/loKPHClE43F3KCj+1V/RHArySwfMsHx0V9ywcHDyJtEZ0iBQqnfz7b'
    'HXkXniCHLnH93+4iOgvJ7I6QbU3O+tj0251re+odOoXqm3PcTE0dnbp3p2V1c2HeRef23eFdvCz8f/f9W3yO2R1F36FDzPCv/dsd'
    'c5e/+pjJcfg5yJKzGjTp15BuPEfnsQVdSDcb4d9Rh73ST3DC2t1PP18NNZ73p/NyZpEYvTGzMUAcQVO7rCijHCdsTGWpLLXMsskC'
    'gtqJqWEwAIRME7RvfBF4BJwuZPlEIZ3jCVIXCL6QKIOmyJ0U18rCVZVL3mfp06uDAnZovjUoCWaNYAlJ57JcCm4oW8L0cTKaPvTX'
    'BwvtKqxS1Kv92uqb/W5gMqFj6DR73jFNElJVOuuYDDpmXu0YnWlko2MzX++bJySCR/9lX0cKS/ect+YPhkEvKRZhK7ej2FfbO7yJ'
    'YSKGixKb8KPjUyJfbdDxjA+zA/acyOgdPsuQJuGXzUkMgf7RwUyikK0E5CfkeIAJ/ZsoRbAtabRY+JfPMWxQJ5t4VcqRgt9eXPrq'
    'iDbmm8uHgGVkNE8+WkjBfwg7qayUlSav9oB98O8h9WpMoSSivR2VKIBfWHY6WZClh8IkPbnQ7I49ewlQBWaTqYr4V0C/COHFV4HG'
    'zpQbQAfnmAKfJ47430DwUGIsedC1jTj7GQOWkgyYTgK/QfyHyzI5Cv1NzgSwV7LBA396nQfImjE1929NNA14JMgUCtqE7cM/iBCg'
    'OFrjLCw5iaYTCmNIWIJ8FQTfM/wmBFBGnq2jmBxvll5mhVySEYOkkrI5qQFCBSSNVIhfFhD9MFX2HHOYNBJM3gF31rTUd3AyNCk5'
    'DlZFSsgOEH1QTFbppOShchK8DrIHCSCW4FMDkjjUTAJwLF6GXFJIwUQwyXlAVqgEUjknosskLcADmIkqJSZfR4zm1XGv1ePUBIP4'
    'DTynMZ6zEZ7TCQ2L4hN4Hi0xT4jLHEkhQgsu2PBCDC5ExMZwCR1d8eGVAPYKyMJXgUdG15tcBe2dkkGoRdjCsfC/zmQTpYBrpID/'
    'QQslADg5gTpnKxSVeoFjs6idLOBeqnlgvrgh1EQ2bOcVdeEdg9hQYk5k0fHFNEIZgcbtvgF+E9Q4AWUpChj7BIpIv3QNVFgSeseA'
    'nBGXDF4LCe4oCS0F88ZKOO5bK8EQPF5ZJlxiuAgRAZaa8fHB/xWX1NsdZrFBpirvQAFoH6Mi6sC/ENEFix7s2CYiXCRQobjKzpBG'
    'SSMekmUcpG0iUs++voyKttPewffw0EHTAArQ2SzSAX3JBAIcLrPw3+uqlq7KdhaFLeQ3Z5slhCG7pHhYQJCr5JIHBR76gwUmkaSl'
    'OB0wAasSgB5w+WrHcPXmLGPKlWQ0qFBrFatCpKZTaCaBt0X3qGQppOu/Lo9dMDBnby62RLDLrIT1ALLKobGCVg3Xb2ntfrbo26Nk'
    'd3xCEUJCcogQCKaY4t9SlGfrd0hGpClTQMmBjn7bfFJ168OaqM9RY0skR4IaJwMPCxaBy4mApDMkkqEQ/cXcWUB0+io0ri07y/ew'
    'AEB/WCMe9PYzM0s4k4M84gtD9kwasufiDVMzteN9Fr3j35IY6tuUQ0kzFngAlwUhlhUcoB/0e92OpkJDmrth0HPJ57etCtfW1m9b'
    'w4B+1Xi5sGLIIB6ChMMZ6fFoIPQ5Un5D55sH32xQbQwH8C5ipsuO89udDcrjd+zcS5bi0wqDcngS+HAR3NMqNuGDesHXE5Cb67e7'
    'gq4TR9OzieAccgfGgTw0Ud2r3pdvnqMGn1r4JXAQYOgB5m95v+MIDrwFCkERnH0ZdV0KwrRzTUdN5lHFYFR5GNaHBthS91G7cB2O'
    '5u473FxAlHyxjTXJ4E10Q8joOEf8AQsEGPGp5Np6pv2Z+Ns//1+ECfNkywsC7d03DdfEx3v6ruS77+jtv/3z/3q1u568iycA3QTt'
    '9z7ffUe3b75ccNKvAwwygaIkCWB7S23uRk0SsnMB1Y0J9o+xRGtxe/6JKDpxfSWCr340oVaIOrJjmZZnBcjjF6oHWG1FVcKs5WhQ'
    '/in7DgHiE8/ufmnCwKL1DJon0khKIO/GOzA1dILcRFY0WoyryVEE3Wzwjd98+EJ6gkIv9F38+EoFPNK77w0Z6M5NTHVQ3ffaBi8E'
    'wiiYnK6alW0bnTuLpyYAEqfKoMMXZrKuHwl/gza0TciKck+g9HCULrpT76NMYYzHqq66gBzB3m2YKT8p3v+qCu53ah7u8Gw4Bejh'
    '7juBfgB85fgtj6FMwW2lBolcCXff66pqOdHucJQjDgBiLAPIZijVYK8BOJqBx4P1RAz5Brge/lpD7lveenUyY1YYVUliYykYcRNM'
    '7phyKqAnIWjsI4H3SQK1y4Ri7g1ETprrEOgynBdcOarmnKPMK50Cb73W5RRWcLa8J0BL3KFYFIq4+h+a8AMeTtCnX099T49lTE3J'
    '/gbG/LzHu+9+NQLQ5FqbZ6h4fvujeN5Dbv0PoXkxwBd3KbvEErGwcCqAwuEGBnYPddHWBwKNJ0gEglVCOxmWaFr14+sIXd5YMB9E'
    'NdxWF839Ncx+BdSyPFsG0P3q4NAJiNI5YK/jc2bHnKNvjDguNOCae7DgHYxgqqE4r0NYgUYAQvQTtAujx0dKx3hxCeo7yMN/KZzj'
    'b8EeSNznCHH1cGhVc4/cCGpEvgvVDb+dgmLkOOTk+GLQF0FYa/v+zbTQTBI7WfegGQM4FgKihX+/5f2n57XQeWUesPcm/r1VC4Fz'
    '930E/96qYc7n0JWJYUOnfMb18v5Av1+ZtWhSGjCAsynBRbHKYhoGPAL2iYNVF4OdefYODN3vJfx7C0hQImWEdIg2/Kt3gXlJQx9k'
    'ht3Q7xiM5lHb+YIEc7eIxgL3ZIh16ENfPmv+AdUwdHWGApfopht/Bx+6IVq6akgVV0YAvOBv//KvhIW+GBZCnxQ4c9vc+F8EMq0c'
    'MTAUkwBC9JtCbDNsGsXO0yLod3NFvEa+Unw+KAJFUX3yB7btAD608FAD1TgtYxC3GFiKjOKjgU6Cy7Di5OEH8ey+xtqTyt7v0PtA'
    'tpi2m1KYguOkf0QN9FtDH4JDxgPy8COdRfYZT8DvsTxDtf7OuqB6ObKfrAo+4QF+6rQeP/8QkfusoofOPUgxL3QI2/mU2iqOqgNy'
    'XXAv6u479f/937e4Fn0X7JdXle/07WrM3Xfm9lMwk9nk0/dw5VJAjMmhWcaij45UuxgDsH2QIviccbi8BYbus99Gmvem6+Cz2r4/'
    'wL8/yJ2vqA2vSXw0pDjhF0R/4i6RxPNuqZ/iMQu/6BojMa1jQr5ZRwLQECkvM12z/JjDd1Qc85JLqr+k+LA9ZI6WAzsU2k0aon8n'
    'dbPtMwfiU/iNs8/vkydlrCljS0BG+5kVvLUWlB8d7CQ/N9/BPoBQUwRdaIb2oiEXDbJYc8STMdM9pPrFZy+HIulH7JgEugccr7KJ'
    'p9qXFcE8j0DCRV93A50M+TFA7qHie+LRNBdgQj+YMweryw1taqvt+VybqWddQqdnNGDODqBwodbzqXY+oU/IHT7fVOcURIT2GttU'
    'n3Ib5WZN9wCo3tGR+Ma8/VMOSm7WNqeOBlYvsK52cAVPPB29dtKs+LX0RIZU+3t1qZsE9ZopaB0DjEwTWbCiHyS0qKnX6M13/4RU'
    'F3R0xTH1bq4Veu8OHW3WxcO+zcWCancELgZREVIFCG9Lm7keWA/mPOm+eKcvIWrd14nwJGLDCruKNrKLqDWkRYznPukiWoZJTiIv'
    'aBIIpS9o8lavGMVwt6HILxDBti0YCk6auMcuQQtv5ELW0j2BMrETdivA458/AMzlz3/Gl3/5Czr+AvAWLELfjkVki2YmaBxoIkTz'
    'e1wBWY4wZdYS+58JdDSUk/LeAg9ycTO+6gp6IIHPfHNNM4AoTTeAFQA47hM5cS2UIntb3X2npnjDBY3DINdc0H0PDCpN1tFmJ9k2'
    '0PeTEFkgZS39JeF7sLpUi5ge8e+POKoRDDf1vSS0vnJxFdwezCMy+lV3r8J6+e4DtDpIYSA2JjJRPwwZzu25Dlk01fHF7wkFlNCH'
    'jGL3v6IgFyBGUyLwZ4dani8MP/Xl6ecfGBFOEIvMviLu4XXvtjYFslikQQt8cwYSDefgIYr7VEbpq78fvqDzVwFEPsQz6EwAyE74'
    'EDGImhO7q38nWM2w5VcBq9iqeraicyjKznVTRs70gCcRn5Db1/TgMgsyB9iDvzcC+2N97oAGhF4I5/j3TyyC7VXgH7Af+jqp+c/S'
    'qx6MJWSHIYe9J4J4QVQRfy78k9/Ej4zDj5S+i1uEDt+0txdjQkBaWAYhhA3FAzLSfRctMH8/bJP/jMSa39K7wjWvUPkAp7dem1Ps'
    '7PA7nPzItODE2XfNSle9BQN6kopV/RAkOJX2fdxcU2IdCd0QOg6+fCHCcMpZMODXGLGA98iufvQFsIWEauRvwvEAoPmFitjA3fc+'
    'joy8RqiaG6MIrHsYwAHccGY2kib+pJAwHfD87yoHWn6uZxgzNQNFKsBan8iQuYNczsDjkHJ+H2pwaMMvOo0Gfn2lxgf7h3mxn3ca'
    '8QwMzGsTOS/iRJdrqIWeBOAUfwQUnELzHqSaPwV5Lteg8J8FcDz9CBxBFs27IOmhj4OhrKar6or/MLCuMEBZAKjwt//xr69PsbZY'
    '3GrTf5Zs8jfUZOYy9h+bsPPeUrbUsxgPqLCoMKFvpu09aNRDxIFq3bIJLU3XwYTUUFDreg1knHwvmodL8/Csor9DFzkD/IubRquK'
    'rFb8RQPT0I/n7Z4bnKlpqGiJKF0wC3M8hDcmYf7KCPEeJzD40M9NoDXjLZcX3pcM9j76eXNQSWTpqo4as7YS0uOTjOTXyEZDCt53'
    'XPsDEs53Zu79r9wnzGgcbAuMyVg/CGKdH5aZGmhOKS0KmKGt4iPQzsYS2rGIPaJo9QzUVFl3TN8eDShi+NnPFjEtJPd/hAPgvPaI'
    'KXb8Tq8lmCTQS0NO4GgUwTsE2rh14SntAb5s5Ns41XwrGtdAOQz24iaVjKHCOHtW5RUs0roqSlO4pTKgZ+HU/8B0Ht4yr34g5tHA'
    'OcEBhOjmqqqK4qPGkfBthaQqjjKJ0AtYU12CfqGjrCKs1s5M2/gxWYrzlCOsQUC9qpKg+OYP5+qgGOg9gQO7vosD6GS2NlTHuSDL'
    'IDb8A6NRU6NR/97RHj2akL9LrCfqo4/oAjNkQ32XNxLmEoxj/1xG4CoojOyHoJNuyWgDeJR3cdtBiZvahcIjWlRflCRnWT/fa8Gg'
    'JOLrk57MIa0yzM35vg6Kf4RAbP/5tz8NmHCLOeoGaf7H3+54gv0ojCZyNcYw+rd/TxjJHEkRbJiZmgT0xxAnyMi4hTgFTM/vwRy0'
    'mzthQgSc4N8LeVQjIb8RJH7UBvkz5L18jIP+aM8zSMVPcxxSRgzzS5ScE+RhmUbIvj//pOHQ8dbXoCms9fnPWYLXs0KW3YmnDw4a'
    'H291a9jIB/wTwBej1bgOPg3Q/xDwU5CJadhBjLjoRP5lmCH1M2D/yNR/fIQ/RoN4g9ZtGuyHgvQ9ZIh8drF7A938TG6EN+Wnjuug'
    'PrjM/lHjCUaBb/+duARWUZKz9VNI5LXp+nHO/UoyF1IhfKd6Op3Ld2Th0CLOqo1dkJizyRtQN00ThlywLP2IdFM/wXp61UF/vd+0'
    'tVfEPjHfN++vNO6B+OSzVt8yWphqEJIKMmwxnkcpk5+vGoW3+m9gGoli37aG85idJUpv8cOXZjB0BMA9oeYWOeIf0XHBX/emvQZt'
    'FDi/f3/pEw8V8s/IuoG2bgROL6EKHdnnvusAjJ/niiaCpvUruv278+cisMMUs48E/eKLZCAY7+Pw/QH4Cp2mZbm/3QXbKe5zK8c0'
    '7mXAO22GT//Po4Kkan2jORyqfNDsO8I/aMw/GsZEDlt4oFmAvmEbtxvRNos0WNi+zv8p7t8/qATttvn2D9ks8kLiz0jhLGT8FR58'
    'DPsuTK63wfQJg6ZAazjIrXwJUmGD/L37wCpCMe858piZ6JxiF6zuHJHNQkeh1RF8s+oucuuiQj+LryjHXji/WgRyvLfGr9rHfqkr'
    'WT7+40fzInHgu59CiA6hu5p34L/YgL82ogf4ueRgEbxoNp784d2C2MejD1uB6GyXEP3/kN5VlOg0Nfw/nNNoomLRNS5nInh25h24'
    '3kAwIYAiqZl77ZXWjVjIg2n8ihIdgVEu5HPR/Ts8G8HyhD/JNUqRXELshEc5h4GEJfX99y3VWfwelBlo0m/bJ9IQIv/847uAaJ3g'
    'LvH5AbQxCB/3jGfNuY+S0hF94fABSmUgiE9Envh8h3fEzMyNhfiknxROOJaq6zgpJXRjhJgUe88wKGZCn0Y3Ue5z2rsFLAin6XXx'
    'L4jS2RJFkm66X/HWt+8t+PeGM+wcb/ogF2PlGKc8ZKfHLE6BcIOUCZ85uaqMI1WILWH57wdxEdsBbovdk4r5e9MliDBN43VsLx9k'
    'NO1nW+oMQvXL45BXyFWRq2gewoocxaqMQ0x3vxf3AkheB7fin5AcO5WXpumgTWca4Fp4fDLadOLjpK86/J69ksHBG3F83O/jdSiH'
    'SAAm8mVsPKVnKXBR0hDejxHO86fQCS0TKEUO+eVSmxeDep/PM+outwyewfTmxklsbocfL4m2UfrbJHGNN7vAmzpvZLr1kN0bCNuf'
    'lW2R2Dj6OmD/kbKDzkAr6aZzA7RQUU8mjBGfys7s888WOmc6QYDjHXTs4F1K2MxD8gsVmqvv9/Ap5Ok3/ZPJ72688WhrSro+Ov4z'
    'qn0uFDdY8Mb3+KzI4Iw5mBdUFG7y/ebfgh2h4/YWYQk6k1WXj0FZqKl8Q6FC4B+yv5MAf+ooHO0VkZQWeX2QhmEKFBALajpsLqEt'
    'Y0U+/hr2a61v5IOuGgt8AhLa957qDVs7sb2CO0zNK8qAjiY1SnG+u4KHULNvLhYJMdBD+jOwoiXaUBYeZuObbDPP/RFGGp2IEysb'
    'YWtnFOJrw+up8r0vT7/l0QXaGhuZvAl1Ma6KcxkSlZ0wQey8Nl6kCyPSxPtuif/3/yH81pxZ0Bbg0UzVnehJkKyb6C3cSXcDMDD+'
    'gor+Dt4b1fyMorDTcN9vnvBjOa+PPU7mCEHyEzKuVv7bv/zPv/3L//G3f/k///Yv/xpUx5E6X7UBNefyvQ4Ok0aCKdrg40suX7O7'
    'fOsBh8tMv/VP8eT5nX4h0IcWQewgYvmMpjcIveLomx97C1P0bDUru658bfwPN2Jy8kVUDwlWDERBD0DIoIDeZyLRYRwA1IPg4OZK'
    'l0nECXwmqPFQL/XFB9KMcdu+gwMlB11djnDJ0Ye7o8kkPk2PBFJA7/2lRHP/C/qG5GUjT4Zf5Qvx5z8jZfUvfwlSfBJrc49fJuAv'
    '2szq27i/oBOV0Un4OfjnHxfuV//DC1FGNsoUclxfX8cfbnLemIlkbiLqO5Wo6qsU59mKX4LEx9Bzj7DAmdmA/KiFkwn6CMYLeZHY'
    'T4MeQecxNJcSBX+I95qo8b+Ofmbcxlw58cX4M15bSa7OF7y4SJfBKwSiRXF87Qk5ysL0cn/FPmbapOFEX3FPjiItC2UHsebAF6FG'
    'ItlnxBjpgiyxtFRIfHM3NmkDSvU/m3s+cbFjIPjez90PegXSWWOxRyD+NO5tZwCu84quhB8FxPI7k9veoyml5gR/m/aKdWoU0f7V'
    'OLlDtmV/M0AQCP7D1ewhC7kpkFf2lmG6pO++V30qvVmFufve86bLs1rXO4y/zXb3/Rn93EzcsvE+DuUs1ei6VYzd97MNSlkwE/nr'
    'f8d0v8uew5Ot/m2S/C77T5x+FSfzBp8L9qEY/GBGb9DsewHxT0HqL4GBLpYJkwyVukHpx+EIzlZ692oYjmq7AyM4XQ5ztzivDu/a'
    'QyIHb2AAmeQrWugaO2HR9r4fS6+Bbj4GYvsKgC1vM0WFGMQfBCM6V+9ty9BIZSoFyW2+wypSOTAC1X93ytHbSKwnYQnyunDZj6Du'
    'O/rGE/DknxIbki5emCid+VYmX6iiIsWN+CHf7PUkvnMDJcHj+yivOnb14CzrW6z97jt+jv0o11msj4DYt43Gi5O232DfOOyIMARF'
    'rUHq3z6zA6wKv6Z/Pr//MYQ3WgebBXcQhLBeOREEauIOgpp+H69UxmOLql8Z6VtyxZ+rqmlrJ7AaZL3rJRbiwT848kfT2MJzJ99L'
    'JDamikpwgmQqrTaZSPthOFInU77PgRN9L/SOuPjgsJ8jmFQ//ZLzjwff2F+AvlqAY7cOsfHQhn3fha2DFMhdMz9SVlXSCMFtmobq'
    'myLRxmMU7AX17ZfQCLkHCwUxznviT39Cgv9Pf/qcu6bW4yEjjuncpTUzDMqr+iz6Curd9zPYweiIYYUbzGkDK0fDQ0Lp3WCmAMX5'
    'ToOyM0uHzFP7ZV8PvmJAnjaLK5HOi3DptzxW+yMrwI989qGzhQflyDjybOJT4Lx38r5/NxtAkkVPw+guyJEg6Ekw2L37+R7vRMUb'
    '9aDABlFsewZeoSgTK9p06kdDYxvERSbTFQskDEIEuK5rO/zFCB3nrZ+tCLQR2BexbQBlJbD6ElHSVAJOdP7ddasBvX3bZmiocnCe'
    'ThSe+RQKFRAy2ByG5Y0G/1+Cz+z8JKPiKlaiOcARvW9aOIIivs1riReWTPgwMpuWTNoEhkdBdPXCOvbcB5wHGAWlP8qU8CbzSEYG'
    'zoxgeW4NypB3d9/P1qaI093Qv/GkvLK8KawoH1xbvho7h4ctPHT07/lsxwTkzGzNCqnxMsnB9yN49gOwxrvvf/0DcRdw4S/EXZqq'
    '7u7hYUBK8JRBt05wKiLco48R3akba4m+2HmHvovoqfeoTMcnVUFzwSFUuBDnrkNZcL4WLkMeBLwjzn/5D8Q/oS7QFtsnBXXIotsg'
    'vhp2SAYXxJ2G6pD3+Brvg4HWKcSzeoG/B6w6/+khrniML4PjTb4QBujoftEa1HEMJHLD+0X4IzSo7Bd6SissHRT7odioLd8DALX+'
    'm0eSzGxJfx8hrWGDPUbp2LNfIw9V/CsLpdg5QfITjlfBnYz5HQoua7rr74gNg6iaC9rD/J4A3TARYkXk7aj4XQe6jQv9mGsu6NUK'
    'OvX04ELXogPYcC8y4ZdPv/vZJMBWglen38PTEf0tAf55eIGLLs5YQm9gJ1GgS6KyxE5ZMLUdJ+oj9mdEnYSQAmARhH3sZUPBz/DF'
    'OZIG8dbH+O1g8YMZC4UxAGGAGEOLEbZAx8OSp0jxD9ybM9m2j0hQ+D65sHp0YtergJYPlmprG3yWrK2q+vFLeqiTuFO0exVnDfgL'
    '6CsMYeWK5sY1w52YQZA6seg4T+MCjjws7h36/BWmMSpNL1SaXpAVKiuKE3k0ExSTpXOsRAsCzdAsx1E0T3JqlmJjOspSHJcjKYph'
    'KFJgSF46oyvynIJUkqEY6l0UZCYQtBQ4pGMnduSRvrYInRSKwQjjqTx33wKFonlEcX/kPgasDV9LI2X4IgpYhycAXO8cBWECfEuj'
    '+mWDc83QnGUuqpEIwMT1sLB2EscaXi53NFXASYJoT+wfT/vu8QGfvvwH8YDR7jxgBMOKYXZmMSRBvCjmJDGO0Wkco9M4lgqX4K1s'
    'QdAjgWsMKeREnqcoUqQkgaaYGMsYJseRpMSIlCBJDE8yb2KZyEnk7AzLqKtYlmSD4aARuAnekMC6jc8mvqa2+xMBlzfPF1JJtYPe'
    'dcIDVmW0W1O9hj4PfoJE0GfYIIodJUAKrI8YIj8Mca29EeKDYTPRoblxW8DnPoUHGaOUTFCVE/wFMOX44cNywzgMGv8Cc6lwOGEq'
    'grs3/T1oTuD58U8ixWbaG9yMSWMak8Y0fNgB3mGhqK6s6SlmxuUkUqB4lmdYiRN5MYFiFE/ngH+RLPA5mgZGJ7yFY3NSnJHkGY7R'
    'V3HMSp+hiybqVxsLTmwWYv5jJCVouFyZVrxO+Ou0937mNNoqGVX62//419RqXoQHMYVfkbr5hMwcYd0jcZIAPg4CH9WDTGBQkJCP'
    'kGBjFA9xBp1teXYscQwOasXxXVYIZC08nxWdpQv4fwTKmSbYSTTHQTg/VAqDpWfTS8+ml77qW2hgUGn4GPn4TIufhgTMu5CAjADm'
    '0gBzl7gaLRIobS76pqh/wOO/McRUBDGfhphPQ1y/TJZIAiqyOQCIoySOYQWO45N6AjwSJYEFTYEHfYLj6bfoi+dlkZyfAcpcpS/s'
    'AQqYhYs/8Bhc21EhyMW//fP/CjANbqNyrCqcl+ejN/Op9vBXI8/bVr6nDi7Kx9wu1hPCxpT4pYR2Au+kZf559RieZLflpJx/pYca'
    'FjlYK0nK+XuiQiPO0ENc/YNdtwJVBAmAd0BwTa95X0e+C/WVplMV3ttq09wlT/LRIgvnWg/+Pra1enQ+2AvmitHZOq/0cMaN37kE'
    'iAbeavRHphyHMfOEHw98q4Mi1PRjjh/txT+2I+8Ls+AAj7d6+y3sLfvB3vBBQ3l0FrP5Vh+TsI/gNKAP9oTPOYRR+R+7eKuzXrqz'
    '3gc7Q+mrb3XR/ihX8Y/mDc+VyEdHeb6Ja+mxlD9KLZobnz30Vl/kOxrPJ9l1PikjkL9FTejqgSxL6FqBx83Xbqcm3G2yujp3Q8eH'
    'b4dHhy+Z6Kj2/RJ5bpDigZS6a0aSkBauQlq40shx1ZTXWJ3Hu9YWpqkkBCyfY0CoIhMJWeISy5zb4iQj5CSwfFiOoiSJFcWf6OV6'
    'v/UUnIUSnpESz6odnJIeycocgT9ZcPWkq4UZuF/QJAcnt6c9JEkF9Owk97hPfJJ6wp7BMYzwFPZr5lLY+uXXGKJGww0f/ocNfZcR'
    'dnNin1dwij4Wj366foBGZ3AnDEOwum74vAjHM/Io4zpESQendKvOtWTuNwwnMY19Yhr78IlISXVOAIWNY3iWoQRQOWmBPcc2SmBy'
    '7CvYJrzP9xPBJ6Xhk9LwoTOVUsomjb5DJnAUSXIiKTJMCjRJyvE0KQosL/AcJ547DMSPuKX8Y6GgFj7cKfaqnbmhqTM/dNE8JOEV'
    'pBxLkTwrsiLFCYIkJOGlBTHHiSwjUjQjSLzwQ+BSZ+Cik6ZiaM+dgGdewOCQqQTEIp0jRZKmWIolBZKRpBTAIp/jBYZjBIYXBYH7'
    'MYjpM4jDI69iqM/cStSZXyk69SoBN00LOV5kaYFhWZERKDqNtJIImMHwtASgUwL7Q3AzZ3BjcGKgzzwU1LmLAtDIIf4RKzwJuCmJ'
    'zMHSc2BF0SQrsELSfBJZKQfjoXleosEOpIU3ae2qByyG8cyUps5saf/glRg4lpJylECJCBHAFuVSyEDSIhihAs1SHMOILHtObRTz'
    'LugC+sEHHaBAFAYhhvjMlqbOjGl8TljSnYichhQnAtSsBH9FLgGyAPQm0shgljge7GfxxyCm0hD7J5bFEJ/Z0hR/ziDQp4N8NRvQ'
    'YeqfcZcQ92SOZQFROZqhRQZILjEA4CM5ID8RbGmSZCXmBwcQkBNOPIyjd0SYXJgswtmz8EY8vDNthhLOGbafz5RkghRH5WBAsCoS'
    '8G6W5pK0CUuVA04O/ISnOJ6SpLdw/DUPnLZZhOAB7DYayx3KBPni5x+sLHXxdSo7Ks/e56VVni0UnnvrSa27KBQLzwW4g9/CQ55d'
    'VF96g9bDmCr2+uSk1i8P4FkZKlSfCvjP875QKLpTo3scrJXSU2U5GWmFKrQH75f9KoXi8oVp7Qvv+QN9S+4L/oX++43nwk/4o68n'
    '49YKXYnon1L3OKroMgKsgsHrGuF93b/XwvuOf88o1SKJrgb+/XFYqT2gqwlub2mc3Wtn96tZtYbfx0A8HNxpdbiK4cPz1JyMuOEA'
    'z9IC/TMrVJuFwaJYLZRrL6OhuQhrT3mY+ocVhVpa+/MdzrO2gfly2QHqSUZjeAoflXro/c4S/nEdKdVear7HxeVsU44XA96cbOB5'
    'p27AdWsERWUJFVvTGP7i6+MpFfzxlGeF6b64KzzCb6Goo/Lec9ErPDYLjQUM+uGp0CwUDoWHaZ7eF2H+Bg9FhGz7QRl+K8XnwWNx'
    'v38q7mfV4l5slPbrZvlZ7JWX5U65W+5Xlvtx+fAsV7rl7mOp/PK4JJXqQZyXDzOtVnpSa8W9Wj0IftvPA2hvBu2xT6UCq1aK5UF1'
    'yaq/76+Qh+F2S4WHfWG0eCj0YPaXAPqhXMyLz4XHPaYt6BvKUn+a5eLzS7WwqOYPhUKmjGhn/wx1nwG+wVMhpJxuZVlYNMvlxeDx'
    'qV/pzgaV0kIGxOw2tSZdO66n5UHtodZbLGajJ7JVXnvVw4Dp7FHfgESIHis+7Sb/lEvQV6W4mD2heq0lPF+UAcZnmONmOeq7CO8v'
    'MJw96Ls4GFUOi8njsniAvu1ql+11imLxedQka31nV83TC1jKfRmN/6H8XMgX2hb1aHUXB75+OlllqbsdvDQfy31cuH/pdgay/vhQ'
    'XP7HfvI8eCk3n6xtq7dxHkalpd6r8auBZReoRfPJCIoLe001qbq8b708lP73f76Axw+1btd8eB7AjPSObpletIr9gbxc/oe4ysv1'
    '+pZfW5Y1sobCulsdHDOdve1N5z1K7slbXdgO2h4rrJxp0ZSpZ43KbNyBMGx36A19PLRKK2Z22DETbnAgFedEzkd9Ve6arfxgwux0'
    'c2VlmNGM0sSiMV73tt5mczRAcZ4fm0fDUkYZd/OkHaZz1ugVxM1xJ3dsnbdonjVXW21Ty+9LpzblCHVZmS6Hg9OQOXWEJ06VyNN6'
    'YEr2k0vtt42+eBpyRpUbPe0yncnW6mcmbapzaoudI/Tn6bLMD7bWeNcdCKcmydAb3nqxV5mt1tA7/T0zEWurJV9ZNejuXtA7fPPU'
    '7RhV+yD1Ty4sm1I5jUu1bn+4flE6L8Z0OBVrz2TbEhqm571sHFYci7K9JA+ddo23Vpluba/OLSpf8DLCrsv0yT4TTviGnSzMDVk0'
    '6/Jq0HxKXhWsbemxPPCp/Bmw5N+eXmFBl/IWMKFLDUfdB+GF7vTdZWP3ZA22iu62dlP+oUCNB3Wlsxe84fBoahMhs+08qsU1q7ba'
    'w7npHPJuvSUdRtXu8sVtueW+otLuvNKvFzr6uHEUvMnc3jGWMhx4k86kUdnA4mvMdNmtApM8HHkkRfWM6RSb86eeNLVkRpFK6rK/'
    'fShz2l7Pr2y30d7WHGOzpNoH2h3yw63uWfniuDmgunSfzJTFuVggyYzHVtrTJfW80yz2wByk00rBI533Hzq1wXXuVFxWWrjSoGn/'
    'O/DHvqI0SMtdD1V9O8gPqMYjxc+2PePJIxs81cjreXpmuYf+cGy2u5VOq9tZVgb9jjk1JvwLCAiqKe3INbModDZ7aRRInm23vh12'
    'VW7wUj2sh9b0IOhyxu5t9eOpO5x5A3Iw4zZPq119qg8G5AmWdcEyGKQqRZ4OtWsAVx4LLz5Le2kVnwOWhu6hllwgK4+LFlRooQpw'
    'W1z+mz4v0RVlXD3KjZ3ZVZljR4fy0Qzw7DhtDTfcg7XVXgzPWIwbw+OWGleUpviiGwNyqw/rwyfb3MmL1vDQftHrtRUznHSGY/aR'
    '6mw6Y7e841s69SLR7WrGkcoHKj/friWZFDouR20abrVjrbbrQoE8IGWvQDFtRmoqjVY9P7KFfKHUZGo78kWyZJ4S11Ld6EwqRy+v'
    'br2hxGdYqUQXacWbeJP+hnnJ990jK8gm1/C4E1dtCj3Z6q/o2oGvZdo2uRI3bcQ9WgX5gdENo15zC3Jp9fy4CNgKPABJNH2GMvhF'
    'D7CcMkHdnYY3IQfyRRVqIBBg/741iht2M5+5T3rlULFNiX9soUpUxpLHmmxMpJM+6A77/IHpnxbH2bixe9HV/GQ72PDuRO3MBFt7'
    '2i2HdIUcVrrwt61SC3mvqpOxsztseeNld+pXh83uMCPVSMmWaaFf8kbsRj0OM+Qmb3s0X1Y9b2OcBntxtZ4qpZbclfld1XumEOQP'
    'TTJPy/x8RR3Ga+o0G3dFR63PMtbLUdk6G+5RkC3NoIyMWtgxDZ3fqex2u+MBR/FgpQeHthVNayje5sla6eXZ04LbeNstN2whrhjN'
    'UIk9BpJ6VLRDdEdDwUQAV8W1ae5f0P9oUYvaqrjY/8f/LZj7hxJe63rzsf44fDIwXu5fdOCAL49OxeeF/5tfFbuLZ5/stgi1H8fl'
    'HmJcI8y4arCSQ59xbWB9h5hxoefl2WndfHiYS9ZRaFkDaSiTdL6xa3V0aSz2ZaFRHzvLuUc2jd3LYUrPV6OOWKiNy2qneiy1ROip'
    '3TyqrrMc5hXxkermhbq+zXdXY646nDcZ9biRpo4lHWnjMKOUk9wvmZnRxPBWgjm1+Ed4v9NsGC1xN85Xju1ng5Xp/PNB2MyNcccF'
    '7mXnK8p2zG5qQ3c4WXHTWWb2oHSGCEm5ujdcb1eN9VjP24MB1+73bJKrUBVxYA/c/L5IkXmxUOHzC+iJRD3V+Xafq68yD+um1alL'
    'Q/FUc6Rn8STnlydBy6+69R317JHT4aiWkbUXcbdvkVIDZqlaoNtOe2hO+Z5R9SyJX+7IAa3WKFcero/i49Y4bN3h084bcxtFppf7'
    'qVGSrdVuJTSnFoW4DtWuUZ09/XxsrO3JdkyO5WGfkZhd6zDxRjZVGjdaR4173tmD4dNWZWndqDsMq3heTbBKWKCg5atw5+v31vr+'
    'zudQ9lieowHYIS/v45vitv3CL1l7VdddxmZInWtnKDnjDgyDL4O82U0q3qm/G9f1qlye1szmuMM9FPf1lrOruSPvQFojmz9megpv'
    'PMwO1Pz4+LIlXwzBkDO8TdnCvCs8GPUt/NHh72hrqdRwqFJ9o7mTZabbFl6s+bRT6jQMqaDYx/GI2uoVk81XtvY4owp0DZrOc+ZM'
    'OFYHnQZnW7Mjbysl4OgZ0/CEoWRt9zNuzbs6Vz1RR2/bLhegOxv+Mwut2bk/anAQAT8ogW5QR2rIksO6lmE3pZftZjMutBdsfivo'
    's8l2eiQnw5KquY/bfKujceTuURnPxnrDnjOHen4nuR3OEked9mI6faROzUPmUdp1qf5BUl9ANx0qnjDtcbJteYMGMxxs+YbQF+SH'
    'YwN0/NOsxOqn8nGqW/Oe1pCG81ab628zNZ7p8tN5jWUmYLuMKFGery3Sq7nVFaNWGHYisuJeWSP8XxWPYr/tWOqhIVX41cEaeyIp'
    'Vd3mavQwJymS6u4GR7ZUA0le8pA8GPk4ogCbCTBj7EsGjC++ZPhojWpbGSgDut1hDs3qSNJrNCysPR2zdjX/3OqseUl7kU7M7NQ8'
    'VQcPW7o1PY1bM+VQeeCGQr48rFruQHHlzIlUZaMuPUvT8XRLveTLA1s2BX1HWdJkXut0OZvOdA+wtJ4w23rjOr/leV3dglU2HOr9'
    'MZcBQe2SL/lHdWfma82jUjzthrun2UIfGtW80lTUw7aS2Q3W1Ly2k2f8Tra3hZm+nrSY2pYR3P56USg4b/gx3SU36i+Z9e7FzXin'
    'WZ/aVl6Eh6XqVbr16bhOt3ZdqSX3XUCMY/6JXT9OtEmmq/WEYU9or45FobOYeDWDHuxe1O50N1B1eSgMRFIgJWvdVOss3V2/uFTD'
    'a6neSCYlWbMGY6baF/vUwWD5AS3yVFcna/xxPrSnUqVtHVpWYzgv5R+Fzvi0Ah2xUtP6ZGtxsLwmb7PjlmxIVn5iaxlr3h9jFsU9'
    'uy2lPhzUQV01+boha5uMw7W2+QeX6nZmw+p+/4JcLCKWuRuTApXKeQzMTPzoGT1ZPXIdvd1mjzqwtrpL62PPGrvbMV2jjap4osDO'
    'c4e25ij1sjDIbDyTz8iDfCv/tJ/ZA3FaWUk9e0V1T0/GQlke28pSVF4ym9NM005dvipQy7JAtQv8iveOM2Fa3bec6ePYGVl5m7LE'
    '8vLBgF6PTeZpe2xupbHiUYo07OXzzXW5v3afKV5aH1qVHSvPR3OOrjSPhYLsu94yMs83lDalKK26Wt/ui1Jh38g3Z8qkz9PD7mC3'
    '7EpT6aG4U3qs28g/0w33MN+1esahxkyKu+eZrfKb43bnOCrVzdSG20x3yXhTrs7lt0Orvwfzt6QcnxWn7zH20BZ6QrebqVvl9oM3'
    'UYezDHmcUmNjtF2X5spC2O5gEk1BPJI7fZDny/WMyh4Nb0cN1WEpX2b3ZWFd4I8cVVtY+Qd5R81JU5tve6CHOhlbG1dEfv3MLXCt'
    'tr1V5sP9un/y5mJ561nOiprJpLHZbuVyWXAKjCb1OMN0RmVJyzczQ359ovJHR+nww8zEem7RhamumpnnvO7MhWHmJb+rGfnjC8hd'
    'F0ThpsC8FL01vETmj6IyRy9JNaqxgWVb2dzT7tR6LHp74D1Sf1K1XyhrXhs+Z0jesKV2tbfTZ3m2raBGSKo6kNw5K/bcTt3NL4YW'
    'r4NtrjkMKa67c21mllrHgrLqUsWDO56PZ5bId9ZjVzwc3LkCBJCpVfpSf7lHtfLTU7PH0pvhZDvf28+73nb4JNXNrVqvGrUMSQHj'
    'lVo90i6tVaHINyftisF5laGrTRT+wIL5rzWEh9OGOj4q03zhqemJ68Zoa06GtuH1TEGgWvJcNftsaVPf1pTm9ll1X+bjamtU7jZ2'
    'QmdtGpO8NqLHIj9quas5vRzR3aaxqq/HpD31doLeZ41Vy95On/rC+NEd1iRqaGUmm5FqzcCsG1c9cr4c1nfraYnZeorMDU+d+SFj'
    'taWaMJR5gR1tDV6yG67NNqbdOTnY9SmLzGwVr6tYotDqstSE262mu4zZW85LbuX51Gh3X3bzF8ZWTmKrV58Mpt2J3mk/ibtjf9dT'
    'naEiiwVDUXeAZFa/shMLY6ZMerpdOQqaxQ8twOG5qk4L1pbWTjWu3ilMSWPKzSWzxQ2Hzf7KVurqcurKlMo95gfk+EkZiNxm69HT'
    '8cQaU9MOVe7TFp0RSbNZl7abscoOmZrYrpJPM0MYwh/gDj0b1gYMl528NdjCS+CUL9pNw2i3nTx3ZIZiQ+4IGZby+lRrSFurl2ON'
    'HY7ru4VxaitFsIIK0+oTZ6+np926Me3vXcsWMuJ+qh+52VjmxsPRbjWwjX3JeioUyosPRa2OdvVp4q5AafZIi522Da4+oVbbxrre'
    'Pu74upCp67p0ejSKJe1Zab3wG3d7HIuj7UauGxLw63xLnKpTic2sxnu7O5Dys9mgtJGfinxt6o0EvU2Bkeh2HvVxxxF507ZdajoY'
    'UgObNe1HZSWeji3DO8pbUqyDFj926xOzSLPtycGztmS3fGzKG1ugKn2V609Ypj1TVKHi2fJ47z0xO0HbyJPF46koQk8e13entmX3'
    'D9Zw//xwcgqPvzeu98C7TF1QRjCG7XL+qI+K4mJRzdPPv/3mB0SJuz2KgvNkcLdEsVEWZdv48VscIu35Qd273t2NfQt+ZnOYCxht'
    'QgxTmYIY73ni3D36LC46tQJlXH1KJe4No7qf8bYEqIhOtbDwLpGrh6/l0EEVawJ/HgolCAZfcUp9htXv9lrKHXWW9USdpT35ZwEs'
    '/U9kqvgDg4TjevN5MmzNsEKOEyhGpDhakjgmmf0gCVwO5bpLLMmQDFR4K2r9gbz2Je1/CT7Y6hemnc1kdErzMs4pTmwk9ceDdnxO'
    '8VkGeECJswyCLy+HazKNG0F5bf6l9j2V+6tFD7zv0fE8YYLZ90RKnvPdSZ66E1Rxvr++8zQ6HMeJEvSTFaDQUB20mQUDHu/lS2W5'
    '3S5L7iJMHXTjXMm4q+AEPtVybu+we89eA0w117cbVM3979xsgI9ZuZIfGx6/gvMhk2esvC/9Nk3KyYbDD7eFtJ06juZ9jaPzK660'
    'jL9SFiQ2Qnv+oT8/ktALrIxw7Nlv/+0/czz+M8fjP3M8/i1yPMrlglq4yPGoYpqC7vbnOR6zp+LzC86hKM3z5UKZRLP8APcwfqdZ'
    'en4uFn06CPMsquXu07L5vOg/D8uDymGhDTc452Jg9pXSsDKk1vzo4EjVHnkYrJp6rf+ykXvsqXU0t73VM9MuuZ0HlE8yxbS8aPo0'
    'n/hTLAyKhf1LqZgHeB7MLsAN9+WHEsCK6xdieMrPg97zpPwIc79sDisHsjvsv8DsO7Py6Gn1dHrWG0vxYXyYmXXtOZ8HutrD/BdK'
    '5edmt/AgFrzHwsNeXRT+/f7MH+bT3XRandamurI91tfW01rgu3zmUO6rW6lX224NptJ3BHF8erEOq85Dpb6lj8xOKfYcvjJsnYzM'
    '8Gjx5efVeLjflpvCUSCrXdBzZjPGKA8pN99VqbU+XumFkVqajEbbPaXLhwpJc9xm/+TlNe1ppZOiZ6ybc+Y5Lz3Ne+PM02JRaQsZ'
    'T8rvu1J9eeySm/qeV+cZcmeS/V1cTyE7+V6VBCv16am4sqi5xOwB+qO6Vq281BOPSoav5gv158wa7KlyG26sB76XPwCiKm0772VK'
    'VbpPrqhOfjve4Jb3D36DzaXcHhQnHL+0G9aL7GnaeFV7aK7pEzcgp55omHURrJGM5wKQnIFg7O23agdg3NLjhdNiXV1y18rRrUyq'
    'Q3K92bbWE/vQ1zTTkypiD82ruBLHw8fH2WRAdWpNQXpkSl2n0q/azLbucXa+vK1v1enAXYwr9qy+e2iLGZmXTNKte+r0tGnwZN7M'
    'ywvgcYOfg0X15vjxUd54lX6fau86h543qdkHej0cjGmdO3r5euHI2/UeP3xsNDoFh6oMGi61HkzVzHJO7sg+sxWHY3M8HmtD2iSt'
    '/sJqzBT7WKdK+nTc5MEupsUXcWhspUwPzJ3BRBpEnXdUptvvM6XNwiKHE6s2clbdMgWG5fbJcBsnXcn0JZ0ZDVuMJQ6ZjT5/6A6O'
    'Vq3bPbbIkdpnbKnCCA213iBty/K6vUMR9KaeXnpYS5xoczK/7HnTTeVxIwqPsx29qw4Fp1CoaLPBzyGm7dO2rllbTYT2Wv3d4yhT'
    'FNymQ02Xx/WoO6SGZN1bDo88z9sn2drOi7TZ9HZFJl9ouN1Mk3EeLbLe55nKrDR/GE75Ev1CWbW5WKhlJqYhL468WJ1nhMF89SSe'
    'pH112S9lHrY9dlSnFG3Y1PeTEpeflG1p1Kg+bS1TOloH2TBrmacNN2C8+aAKxrOkN7vCdtVfddcUdMSS1YFA29vWY5knN5vM4Tgd'
    'n1rysYSarzw+bD12TFOKTjWV/bxEoeZbj7Xq47ZmHo61w2xn1R6EweN4vBDyjLwSJwu1dxIMai5uj/PJ89rRKJPkBi/uYVyQpa0i'
    '9KhHt1SRe735i9VqcBtN2T407L2S35fQyJrLieg1H+iN4kiV5XHV6+6EhuVup13VbblDcnzYUIt1fdkfj0x7MSCl4c6yJ/poTeWP'
    '8w3w9V7p53LIUs0btmBARXF7yE/6ZWfdn22nTGf7wA1XmePmiWIy/SdP7QN/WfMdrZ0ePtTWDaid54brzHFZm1SsTL88M3eiMQLJ'
    'CIS7/xA4nUdvy48WVq3uudsXWTZWfXneqEuPrmyMtltlu1UfdcuSN+a6136sacdeZ7ygtsDHM4ttZaOvNixL7hzHAdAUZ6luB0rD'
    'NilbLbWHbf2IiJci2crSyhjHXc2tsT1h1J8+HnWlJ5+WDXfy8uidVse8NRl3a2r1tKWUyuhxs54ZFkmOT9WT5J0KnT1vSwN1OCqS'
    'dbJEC8xhvB5r5IgRANerTGWrMpNFlVWGmW2nOnX2D2J7mx9W9eFiIhVGOzXTAW1VKtF5dPVK7c5zxWZ2qzxMy7O7Q1dF2XDpl2Km'
    'OpxvV6eXZmuyYDuHSps2XEW0GOpBOr1MBqOaoPPrLl/b7tZUfVqsDCvdwbg7YOtqTTQExRaczUad8LWunOHpzfhQfMgXSoqjUkre'
    'ssQ2szGVzniwnrf3/WObmjeqtrltj63hdssczZ1WW7THni0r7lBpz+WVYWvL+nIwq01B03uWzxX7buto7WYZs6OPOkL9RV9rU72v'
    'ctLzvO7M6cHh0QPlatOdicZcNLoiqPDzWcbO66O+UC+j2msnw0njfN0x6EGt8eR2ji8rvZJf8wzox73e5hyHiqYq0/WaPS4cSZof'
    'vvBbxaMaT5SaWU323TKvj+c7vixaReoxb40qu/puKFTEMVPenNw6YsD1qnx6sQ/a7kHabkYlxxv0JxvxhX6ymafdwDtqfIPrPyrO'
    '+KG638y55aEko7CfB0Nqy7uGltFrnlGqj3fzw3G3VvQ+16C3K4nvT6VjZtkyppX9QawZmZdZm24sV2wf8KHZfuoX7QxNmxKpPogn'
    'RtpMOzsdMKs/oQ+z5rw0yW+qD67GvmTKpzyqXohqH65Wrlp9Nr93W08rQKMuCNzKeqlqqtGfPasPdW7KLwzqsNrPNy/zmnY60EfW'
    'PjbqJClW+iVaNjYrYF6Zo7RaDysiXzWfG4td2R0uedZVKcEgZ5q5FjuVSt/ub4cl9Wny2O82dW22Yhm3exrX9sMKW1coc+QNpJHV'
    '7o1O9Y682+5eZu52o5+cutZXX3bOhC4UVX0UrZ5sGYWMshm1n6qDDOXaXa+rGBKllJX8YdgzaqrGk4PK0dVBglgeVRzsd8t135a5'
    'Sndu119Yas/MmnV2uW10Z0/ME99SgBG3yvpqvOBgniVvPGwv+NVaGq2ckyVkSL7arTvKZtiZ05tKoUha80jXeJQmpV6/eXpxts/i'
    'uK3LXNvdtTpUY6o3hery9Ci2akXt8TjyxCZYhqP61nrsdGmjOOyOBKnzMtnqp87pyVnvWsMWuR0OO/lCmefBpM6La3onz/JbFfiQ'
    'vDV6a8962Q825mhge5Y74BrbUYl+rnMjWy+MM5VH1xvqrjS2DkqZI3s2r1idlynY+Xmn1d+upit5qne3u95pogOL6M5fBm6/K3hV'
    'fpYpDk6kxy0zRmfRLzz07OHGXtTZVn8jPj8/t8eM2zuQI8OYbQy3tXWlk+vup+6gsrfqbrvtlE/jfKFSf5b1kt3PVyv2oVs2utsB'
    '0OxgtOL3BXk1KsiVzWGzW/Yb2uaFFk7HYeugT9z9KLMhlSbX4p84emuuRrK5lW2qYWq8XJmKvRnwO12VTtPO82hz2vO8O3zSDb3b'
    'tsbt8WScoR4mJb0+Hq2OXK1yeh40x3qR87bb7aYx6B9q0+1YybNL5nk0ZZaKVB3suK7Dt54OrrnbgOWuFCc7tcKQSi+vP3gLh9mV'
    'BL5tzY9LUn6mgZmfqQ1DXTAbLWHvZVbbsWgeHusO4xyag1GmzTBMuTNRWtX6+jRSlgOhVTU1GIbzoonVBt/vjx0OGK228RynVd/J'
    'iqEOeJGkzf+fvTdbUhxbFgXf6ytUuetUQBEBiJnIykqLCYKAAIIZcufdKSQBAqGZMXeanbd+6ffuNut+buvvuH9yvqTdfS0NEJFZ'
    'daa3W9t2hpDWvHz5vNy37UFGd89YBiNfyA2O6vFht53mG7Ox+1LW+umVfWxNMpXeVlTtmubYZc3ZAXfzvI1O8MUcygWl2ZmO+s0B'
    '9JNXB/XSQ9pqt4F/Le36zydTUNKVdTk3mnXERqI/3Sy79dS0M3uu3LcKd0e11NiaBT1Vbw1ls90UndVAHtbyLWuqdAvq4Vmprppe'
    'pQQ8yM45mO40k1AetuLtdCr27HxFMY+uOngo9DtHtVxuDBqP+V7eyfWPj1bWc0slvS2Ph7WEOrf7Hdd5KIya6Wx76mzE3l4y13Z1'
    'o9T7ahq423Xi5kY0zJtS3XbNwqAJmHQ+7zmrVWcrrh8ceToeW/2RtHH7drnfGMzKXelB2qrDMvAja7HyuJc6G2soSk5idLvdddyX'
    '5p0jpxudqm11+81RvyFuMsOnsuQU72/FjQSCSqdvNZTuTipVVMewDbHSHOUH0qiTSqxHxYds6nHfqOpms9xPdZZ7aVQCTqKSN9qr'
    '2VLLybnN5uBUvVJ3eq/cb5vLdsXbz9wX0T3MDv10t7Z1e/29uPdaNas2aViyVN/KWdnJW5mNmC6IYrbwWIONURZ22bUHXk/XGofs'
    '0i6sEsW2qtxbVf2QTgAwWfuDuKzOpE0JhPnWY8sMqVs7c5M9dMctb2oNBiNl6fVm4tOml5EeajnFq4xmDafy0l8OMgYAUWJdaG67'
    '+dlTUb0ddzUL6PhyYdWqxef+83SceRJrmlSbvbRePKefPzhyu9R6VhtHIzfr5x/13mjhvlgz+2hkZ8fyvXhzW661muFQFqXheOyu'
    '61PJu1XtJ71ThTMBjHR1OxQP0/Tz7l68k81mVys9H6s9rbRXqy/HYcnI7Lu9emG19fbz5WAwqHafJzVbbYxk9VEuD487HRigdUrt'
    'SXeqN9xWEtu82mkOrVE3NSppD5t8wTMWjUHCaSZKylGctu+GIBRMy/mm+WippdSsVMnfpw1lhjzri55tD9zSk7QVJ9vscqM6k1xX'
    'hDnNgP+7KTeyRjE139bUVdEppw61btGwM+qDNyq42eKxlZMO7d0CRCu9M2oMRlJHK5gHU16OtxUb2E4nXwHR0X56uc0btp5tjuVs'
    'aXls9BsgK+fd3Fh0qs3x3m5KYrPqdZoPnZZZKti6ZW/a64JtLIxJoljbPz4VKu3+w31jNHwpre3RqLG8KR8zui03+/ejVm4zH7v1'
    'VOnmtt/sbTYvmYe6XhlqtqO/bAoP0/pqOXvJN2dSd3M36G2dtZGoTnMrrZIfWanF+rDVxXxb2Y0d3VNr9nDSVj279thxCkO7WFgO'
    'potVeX0/hYXvZcp6z3U2s+6gofRLWt1uFO9E80lsjxp2O+e29yN9vn4R1fwyk5ttSpqZKvSOvd02664ST/WnpZJYHSePncRU6gwN'
    'a1gy7x8rK8+xnqzpbNStr/fAPj9rDU+S1dJge68N0/VhyasWXFtOjxvt+97+ZT/MaBOvLto1J//USsl5pZ1XFs1UfzucjuxBK9db'
    '1jW3nCqPxOdBubvoW15r5Zbz983Sxttv9aw99RT7MHQd2+5MniyrIsrlQ6pvvGhPm85D5yH7uL95GFsvd12QtqXSQ261b/Zzvf2s'
    'U1uJmTnImqPbp3y1ZUlGR9GburOSipKYnXYb2ePQSq8PY/mQ9lr3z9Wcu5+sF9LA3uwm2eEh3b+38rWVbVuVUXmsubJ4cLNTXUwP'
    '7PaoJy/yctqYH+eLmwd32K6NqoOjpwATDfyc4pbE9OSo37+M4ODULbvqbHuTCU7BtBuWY683qZed+gjLNBipuZzhOSuzqAzHkpUd'
    'VGb3w26rkzmIlVFnvRMPrUG/NwCSu7Gnx1b2cVu9f9lNpxP5JqsVJ/LIeVSa/fR9YzrJZ1DHuMxaz/mjPtbq+wfJGfTKY6NyUJ5c'
    '/Xho7wdT+cndd4aj3n2p6a287qjeLOnD/NJ6GDYnDwtpuX7yurY2cy0YJJzYpnV/W9k194ehJ+42mYlneGXbnFZG4upo9TWrmH0o'
    'DLWZ9VAe5PdOfzBIdyqDZntWW6yLA32qGVX1WR520s70XjKn7eHRkuuLtJYub62sVctXJo9Z214+ZEbSk7WRNKkwneef2k717nnX'
    'K67bc3W12x7GTvOpn8kcDyNrWnRbG6WaaQ3Ezl3ePa6Lz8e+qO77GSWz7eyyVcc7VPcbr4mpKvdN4G8bmeFhv9ncPckVrZCYwuBK'
    'N3pu4+4sc1yzb7fVG9d9fsltvcpuCzRYcjpSY1ZbDXqjrGQDTzh52hSPo85ALOa3nWK+5e43481tsThvlV1vUF7OB+l0Y1JQVWOV'
    'P1TVpgIU9BH4LbGj1mtb6+XoNVq3cxGE6eOotXXLaatoTOv2ULcLauepZo2zdfE46CjqPPFc7d1Os7drpVVzBzll6VRbZqFrjYHZ'
    'vB+bnvJoGpWmM5JtqZEvt+bAfKyb02PWmUxh5CNz2TkOE8fO3VOrM1Kr6bVU6U2sdVEeHMxR8a6+tp8aVbvdyZY3GcNomI+3hcVh'
    '4mQrx1a/aA93Wb1TSFhKdrrMPXaHGa9vV+r15cvSa3gzOJ21jiXf5Cynkj8M9em9Uyyok+ZsYlvrQqO+sWW7McxK1WZLr5miUhyk'
    'n3q3OcCrStMqy+m82ii5VWlbb5WNRMVuz7ftJ6tS0fXxuC/aE/tgjfbbjq3uAetNDtpOX2yW6WE13T/Yxu2kWsptQZ4VnzN3OVNq'
    'jvvtQ+F5UHS32mFjF5aKONuLj/vW6uH5+b6pVeutp21/b9cMt3XMeOp+2Aaw3vQ6/UGzP7hfVVarlVtbTKZqrzcV9ePYTkwm9tSQ'
    'bgvAsS4GlbGd2t2J6uOq17mvKgCeiWY+te4nSqt+pTHIt6TJALbadBpF18k3K3pPXCesfWYsPi6z7fxKiVY5rV7dFhuFQUGXR3lj'
    'm87PEm7irqS1NuKgk6qWUsf6TG1Fnrv127Jerpe7m0ZpX5BhDSrGbrTqiBkb0HfWSEx6xWPaKjmNsVhotOXCprPtLqueZCeg8h2I'
    'hM9S3zDWg/1s/egoCXEJIsO2ti8vXdFzvbrXntoTtzFID4qbBnBOXdvZP89vRoO6fqffvljO3RBOaEu2V0Z9esjc3EzvD3+uf9Ky'
    '9aL1JM3a3eKxWytXxX6l2Xh0dgP7xZtsSkOnUkpY6sqBFuWHw8CzvUSrXn8adfv1p+7AbvZmx+5mMGyXjvoAzmperWX7T+O1OgE+'
    'fXfzUBJBDD520+XOY/+l29bWJKC6I5BQAUXWtfKdaY1n+no0hF/G7cOg1ypIt6LTdWYPdqE5q+f7GaOuKXVzbWjZgtzdzNuNpW6t'
    'Zd2RD25zsJ5sJonK8859ynazvZy0sAoDESQ9B0RRszVdD4oreT/IrBSzONfk/qCSfl4ujpXhozvKFybLTOE4quqj8vPwqV5dGINC'
    '7WDrk0e3NbDLrXKm2NOWSj9beXlRW9OCO3nOg4RerTSseXHl5OcZKaEs97ADBUM3rLGV6TV63rB7WzXLx8rABjFqoCCK6Yu59X2+'
    '7y7F3UAfPDh65mFXEg9NMSs5j7f21n2Zj6uDe+cwPnRnB/TD3+1TRb2TKqt9XdrvnvejRbvVa2TEgd6sAGewb/QHSvu+UV9Jx71n'
    'V227BnIZ8FtWq6M6Um8kWwPzrv+8rfUarfHKzOZe8s+b+7pa7L4Mnj1nP3p8Gu5fut56+mC3DbXQkCTbk+3aRivUbRACpHUxt99U'
    'a9L2sV9tug9Do9F13KPdeVqPjc1U73bXg5oo5VfLDEBNJS0CcTdulUqu3ndvl+sU4IXh8JByFW+bGIil/Ugq3o/lXs60p/nngm3V'
    'D+6s0um7U6NQnI6z7Ul2rZl2Pa84HbWtFh73JWejK/Jzc1wBUXNlSlq6aaq7zUF6KjRuVhutvqzClIuT9DjVW1rWdtR37Pv6YpGH'
    'NUTQv20YTw+WNSmVir3GozdtNnvis7vWpHLBbaynCUct35WfhqlVd1xfm3Ac5amY7u63m7qi9eutqWnvgJMpJ7b9fKGmye1yU23Z'
    'ldXd7UhfTzxtAxJB2jD/w3rfx+Uw7TWHaVl8HL50QAhq7cf5sVU1807GxqVo7Dv99hhE/1JJnk/FRctdbzKVcV0rZp4Km9lRnlZA'
    'ELWcxAEE/K2kyY9P+XRhMC/3B7aNSwnSdT/VfxFHQK6rt8/dXqOtuvXMxjaUzXC67k9qW13Ndg4l1V3tNtWN3cnJrVyq9VLJusP8'
    'S74ynnjToqHKrWcrB7zZEKQpR1qNyqKjKll7kN/q2u44k188q1TPdZWX3aGVqavrpT2xrKcWCEdH1F3LQ12XBtN9czd88IrFu822'
    'kVhKTcBQ2Q3w8627nDrMPm12+8qLNRwfzQqMfoALo/Tqe7c7O7YkYPKzq1HvsM6Vj0X9PldLdZuDhPRSEIeVFjAtRrWsGOkn5Wlj'
    '3XYlqbwsdhfjRkGJFm7ly4dF6WFmoVt/c9Ydr7PjyYtbKZ98eJQT+ZfEXTu9HMzWS+u54z6bw7uEEX29tidz2bi/e/aq3mhRzzR6'
    'vb2VFesJW5cznfYDcHMDwJmLvK50NDc3bSqDDfB03WOxktGb895oUmqMu65XVm610V3PztSbmX27t7WtnFVVJNMZWXCOG5unzM5b'
    'lVdT7S7rbprmLn0AbuW4duS6I40BKu1DUW8OGn1pMLKH8qqb3tqDdMZs3w/zZatTfsCbtnBCNvmHF6NdO9buymPLGTf2WkG3G4Px'
    'sCWl1pP+sKW6vd7gQTIqTiUrbYB16qjlQtprL4yGcbOp5ofH4egOpIhJptU5TjbjTgnY1LndVux8+9nyOkVDbjoP3V2/VSpJdd0q'
    '1Jdz0+5WVpVmb+9pmjZeL4fPEvxjghRQ02rq7rYKkP2f+a/1uJH22lbNA/Vc27YNJ/Tm8clcS9WJvt6NehsrDeysYjTFpTVspSYF'
    'Xd1u+6VRpdd1M26hBijPaS7uBq7X2U4ao4LkLUdWxxhul7mqNpEmk9HxcTBN6EWv0ewN90Vv07V0cdg1R/bE2Zfs4hIwRne8A964'
    'rB7vN9ltotTVNuW+3po9D7WMpSTys+x8vLm7rw6n1brnDWb9g5pQt+quf2zbnXZl33dHuqGLE7nSl1pzSR/IhpdeO49W9lCWmr2s'
    '0xvLzWFVHMt4WcItVw9rK5fONXObkSNvK4PSZHVog6zS3VSOgyfAb9NNal9aKmNpVM3OWuLI66mpQ2l3c2c0wssw4uNz42Zg7mfd'
    'emFi98XdONut2+N1anez3GZXtcp6sZ/ougZHc5QuGVsAxoVdnfVttaEtpPk+UWs0po3ydNKYKdJA79yUW3fAJIjeyOxrYnHSU8VH'
    'ezUYlC0Q3PKHdXktZRMz+Ec/rh8ld/TSnA+GaeUoZYfdtVwsO85AK9fVdPbF6a0rel59rg5mhb63gq2ZZloZs6C1B0+1Smqdzqmj'
    '+dTSF+vs40AWJbl/aGpGtqk5SrO6HZkdEFJh+za67LXHdrnXrDi2bPbyWnF4bGyzwJtsb9a1x/vHJgyxKS/X9hr4j4JpPz61Grv/'
    'CBQWWrombQ6FjlY3XpxVqzVbpJadVLb2/LzXH837Yz7xmGg+pm4ea5FPk07hppTwf0vW+nENlLGaKU/qG8XrDLe9cq/bAaFgW5JS'
    'GysnNr36su/0+rDyE8cWzb65kbOLWuYuNdIymXqmm60XRFlp9DpPWRAv9iO709JnDwPr2D0ONpnn+qJsuNOnQlfcKu5T9TgyJAPG'
    'JCl30Hz+eJcdFsb743DfPRjjfbooKgnLMsX0wsqUpfKwqNnFw+zZLjnT3rxQ0ad987DZ3q+KBVM21L36pCmPes7o7LzitFuzrVGi'
    '3M82NqntbNeaGaNNs78qKPdFr60mUrv7rbJvPh3Wh0Fn2xwZ1eeh4x1NR912cvn2LrEy1Hpz1Z+Oc2tU29SWQ6/XeejZnXv3Tts2'
    'Cp7ayxSW5Uy+IkpDpZ5euGmxWC7e3NQWjXMM4S6r3c5muRqLRcAMeWcldvoF/WUxey7Wnx7lvCLXO4XGVmm8WOlEq11qm0/2rW2n'
    'x+JA61Q2TktXXjKSVkoPtofssbFZVyaZjF1qrm1HEjMHd1pWFStV3mxfjKKtz4tPynSmOsqj3JgMgJ63a+v8cZBriPC/3LIvH2Sv'
    'ONI2T+KoZ2a0jf2UdYv9YqYHmN8qbR8WrcyoUVGH66fHXXtcqBRaqWG6pBX2Pa+QLpSzt/2aZPQ9wz0WcuV878XJVtfAgWeztpov'
    'Z8vFza0kV53xw/44kYf9erefPo7rnjZz7GHnUCtvlz2ntzenzWMazkFlkpIX7WXrWdeftwVlWBkC553vtXIto/2S2g9n2VpLXaQ0'
    'N7V5KT+CFBj5IHurpbxZTqr1bV+bT1q7m9vVXzkriWoqKy1cBZZvK1sbyaoPm6NDqzB70BTJ3mg1EGfMQfd4e+zum5rtqStl1JxO'
    'paU3trvGarDJt+628lrbjDJK98GS7US+txvLbtldqnlXGfW3K73Tul8tO82H0XGLHGet2F6VrXJ7ra56QxC1M+PWi1hI2XLx+PC4'
    'aHjlzcvNvX2/5uYmDbmmhmnLlWZxd7/WtdmdN6qK4qghO7JmHfWn/qGebxqJzqFg72cT0bTMeXMgLXrOPlNfyWYmLZW7y4Zkbe8b'
    'x7GyrdzOio1uVs10S8Wu2Gh6GjB2VrpO/y+Y29Xz/EU/9KZ6uz12spKx6Yylrqmtl4X0sPNYs9VeeWhY/XU6IY3KXnqYM7rDYkpq'
    'm/pSVp68nAgY4qZ8c/Pwos9fr/buNmM6jxNgkUd3nWFffD5KKtrpi+WHThvkBe0pJ7Y3tVm+582alUmxPR3W7c7gubRyyi19nJY0'
    'jKPSmb1ItthbF6YrQMe5QvtFH8AgOo/Dlrx3X3KGPRkqerff3AyyhY2+UFzLSk9hCeStnlW6NWl8038AMlA6TEopW7R1aSj21eHN'
    'jXrfp6gdlUFF7CiVl9zN7SZzWzq4nfEUyFFX7Hs779DIlhut1EhJ1fLKYFoeaY3GsFXoKwWv2VQas8bRa/bdTC4rSQ0xWNfli7Xu'
    '5Q+T6aLZHjesqfVoA6a2AR2YdsotSg3bWIkTJy82qnvnkPEW5UVaXWTFnqGO1yULkOWTfHM7fRz+KVA/DErW8t4t53bAORYG2nbt'
    '9e1jWzJKlYPUHvX2EsB4zRoAa1aGI9Mal23gZpuPTVRttKzuvbyTF7mCbetOqTaQmw3P8VqmtBzUMmV1V24Oeqmbqm0YANMtK90e'
    'FAZ3xrEyyQ3zqZe8MfTq9sAqlTvD0XYE/OfNqtV7mj03Ha+akSoFZSodGr3MprWVJsdKopZLjWqzvdFTV9Oe6Kr1llK4Rb/63eRx'
    '93Rb7LXG2/3jYyF/n3hWLON5lFsuy/IiVW13m1Yh065UW/PRyM7L1U7p7kVNH9eNUmef2Lyklo/RDpbppaR6y/1LpPX7yWq7ruUL'
    'zeFh/9yZzRrDl8JT4bGaGN8eKkPDqdnFSnly29prZr5eXQ8GUl61imKn3dKetoVjbyiqR3OfMfq9UsvN9pX6puB6+otUUs3j9mmx'
    'K7Yltzpo5mxTXOqbtDPae4NmJa+DkAjwBcSx3C+k0yPrSWq502qn4y2XYxHkR6Av0hpYUvkBKMys7Wzyuixag8n0uCkOs4NtZ9kd'
    '5m5ulqvz8/UwLpnr/XHUvnuuHIBYqonMwU6ACDwYrbM1rTU61peD0b5mPe33tf1qNTXz1aa6P9RRszWodNR6feHYabE/z23VTtGe'
    'O5peX5Xz3flDLpc7DLomSMjZO3FQuVmKg6PdNQd9SZzlH2ta4Smnl5+sRsl6VjzF1C1NNYb6qGIVR5Wnlmjv1efHh4HX2NhALsZT'
    'WLD0S7VUtkePxv75KG4apZdif9NuaxPDkWGT98fKqOzkqo7ZPBY2o9v18iZreN1cKfG0Vr39THuU9H2+1HsuT7XUQ2tsp7zZjXK7'
    'mQ0Ouef0+LTpTmZ5WO0zsNOKNF7DtmZbds57KN97vfbzYJbZzlvzbBuBSKoNW/l2c6l76v1j9s6cuodRfWQMa9vHdcYys+lyabsa'
    '3N/mKodhsQoQkgJx4rbfHG/SeuXedkYNa5PJNizHBMa+11G3PblXFx8kseqhmSHdecjVesVWRr8tykezWU0fgL8/ioOxmp/18ze3'
    'k8fuzf/67wf6iVRq8vd3fmDqIKF5cOWH8ppj+hC8iWNuvPPrNqk36gzVKc8HirHKMc+Ln6ZMYrkQ//5u4XmWe51KqUZyp600S1U0'
    'KWk68xT+Sj1rhvKPtWTBwBxVUjCB2sYT1vBWgLf+/RnJT13GU9uYlIUzfj7ChXN2f4lFzZb1DeZH2WEmLby/xFKjYCtD06Fg2352'
    '1Tdvfp3FkxbPAkpnMdx6g4J0/8rWIhr8uJBOptOZYrpYTqfThZPo0rlcOZnPlDOlUq4opsVS7r8wynrme/fAaKCvr3t1WW4vKZpf'
    'D5f45JZeI7yvxaON4xryjNt06w0zeegsLy3LVxImraMwvJeCIrkLFuBcMT1PfX1pbPqHhHkyIqHXJc/PKKsaymnodm8B4GCEiVcw'
    'A9G//ev/fWNZ+gEHwDIhsljw//av/4/A8uSdvBYog1aYLSqAJVqr1RtrRa+FpakZ4ZCNA6Wi4il4IpPCjFcC3XYTFG0G4gQm9Asz'
    'HCWFs5XnCd/8hhVKeMaWdiXASiu6epJEkfKHvc4rwG4+nuUWfpW9KXKdasou4IWpo6JVk4KfN4+GAU1j6teDrvqp7k6bPUulwsrz'
    '/GJv5nw7i4CeOYuAfs9ghtJU/7WjlS+LyUI6my1iTIZS6VVYcf8M/7XA7dRxGAQYJ87CAOOw3tFN2HAuZ/HRM2fx0e8J6s/ngsnq'
    'kpl0Pp3Nl0uZfDYaojmfLyTLuXw+J2IM/Vxe/PO5/CDG9PfmQsM6n8t5Mr6zqOmU0CaK7UQYf7KUzedyYrYo5gonoaYxq1Mumylm'
    'MJB2uvgX5vGjuMyn8yCUQZHfjVeTOIuinjmLot5DFHK+H8VyLlkoA9yU0oV0KeOHi2fzKJSS6VKuDEg7k83kxcyfzuNHN3VP50GJ'
    'ICgSPI7qfCZnsdYzZ7HWGV4CKgpIjZ3eEM9E5pbPZZMlsVDCDGBpsVA+OTdpnHehWMxmC9l09s+nlpmV1VzubGq5cMhnwdYzZ8HW'
    'c5RjV9oCcpohyf9VcBfSSa7dQj6XLGfSJTEvFjIw2Ei6g4woJkvpPGxBPpOFT+J/If38zj3qLKblAeLmE4VsQBR4Mg7XT9gTIEOe'
    'SjySyk7TMc0t5v+kFL0LSm0Xpha59K/Ju4SRaQgBE+Nj4kjq9AtXMKS1inSM0nSblkCUgLAufdFesXIw8DEmUNE1IILO4fV0onlt'
    'MJ/5q5Q2dPOZjdofCPFWC9pMumINRGGrqTuicZIDQIlbTIyi4lIuE0zL7V4Geev8S+Mw6+DGOJv+G8PvApy8sRFv5ZHx7x3H2s1q'
    'PEKaWeYT5ESA+0O+4iBgcPofJXMhfjGWVEx5H21pB6d1QfwSTcznKqumOYcNvjdl2O9ISkTc1iA/zVSlrJ8LxjW5l5FNxyfGXFMR'
    'Ce/g/2h0PhcbyeIYZqG1dBxAJDkWft54lF3mlKm6M61DNPOiE4RgoLSLkVm9nSjmT5IvZs7SGWTO0hnwfFZ4jtz/GkTgY52/nEEm'
    'c5aSIHOWkuARtuP6DPgTgktQ/t825B8n4sicxafInMWneAhkHjgFlwxEfxXW5n8Vsn094LepdzjgM7EqcyZWtXTkmQlZChsLllgh'
    'GWPtqvp/I2C8TarDnLFnnGr2jFOt/du//l9rYJMxYzfHa1H2KJNNf4/LOxcG839KzLCPV8QsLQOYlL8XhaUSDssFWQijf0xViuxB'
    '0sIhRFIMI2CCXzz3INJhymFKv7qjBOqI6q0NUZx1Urjh+axfxXXBDl8HdTnPE62uLY8nBWZNoNxCSYN5/tmkQMmMsYuTkC6Ut5gn'
    'OrMwE7U5YymReVqwU1njJ9rEd0xEZ9v4LnvGrvsgMnPMdZTFMkPO85zX5JBxxiv7vBNvKAAUM8JGvcF988bOcxNnTxoLYs9gYwU+'
    'tZ++/Z5yZUezvD9++t1/kE3D9YRfhA+CK3z4I8jAl7Q3gLqY5Gk6MTf+npd0t3Mo+0vs4m+yZGwl9yJ+ifRaV/hbesaXrofxddhL'
    'esaXmC8c9pa9ZT8ugqYrrWYPPl1cSSCcq1fuwfXU9aVwi9vxLMld+l2B7b0EdmFuqkK/dil0TJBtzUvhEQ+9p8mS0FQ3wF/cOJqk'
    'wygkw71yVUebXbz/KZUSbv1U7JS8DUkxT/jG0rRdY95GBD9UWACEYxAXZAPW8GOO2QJB+Fax3amOncA50+bQubVxLBSfLRhpks+m'
    'fdN46PUeYEKfLjg1ubgULjiWpkeG/+iRYRV6ZAwzPbKzSo9iuSjKGXrMz7KKzAqU5WxhmqdHOZPJ5+WLz/5qdlqt3j8qtUYDl5Sz'
    'sBf+x26v1cGhXTDW84qTqOutGBSpPVf/0a1NHrpQ7KvQBYknfSk8I4qCvw0UweHvqIGAmxa+hXvYeb7pvW45aBZG9PCPwUOnW2s1'
    'oVjuPYAp7Mt0s7bgYGquEEO0IlEwKIyPgwf4uVbt3PSgQjdOKjokqyynqoSp8FxgHhj/xhN8//QTBvoB1EBRXz4QZuT9RDJWk6Ii'
    'psGgUKsIeMHHGfGfWJwgY3WHufZc3MLPvL6vaHEvMGcgNiOzMnjw2FcJUKqHCcl3FJMKuSNMOInT4mrFGSwIfAv7aUiAZLGfr994'
    'PzQ4TRGu/uDoFLU4OhYTdsAfYuuGEPsq7C+FAxzAS2EhfIPzhZ3x1lmHcMTgmXWEtSmRb7AikQmhxstVeRcaMp3Yxs7RAO8YVB9Q'
    'wyWuHlSHnUe+nSBjj0oQ4UD/rgA8AEEJcxUWA2cDrzTlztwYHv+5YJmzYQRQvat6MTj92PjGUMyuhxkTcbEvKX1q9DcGAOphMC5/'
    '9JeU8j34wSca/NaBH70HRpeG6MHgEESxI2QXHklJFpTFV02UgoKWNQeozQdhJumuipgMeKCh5Biq4r98/xMHZ0WdSRvdw72LxRGB'
    'wp4AsVpIrubynFZQQ1H9Z2Kmr4ULlsURDu7OkSz4vYYJbNbwW9p4Zg+IKqsAm+ofnGHnpk2zMYi8wJSSxUuB1UPdDaaIhG7EZB7w'
    '12x2LdQMkKY0mEhwOKe6ROchGCkGNqspVNtVPVxAGJs/pVj8koH6Ne2cYSo48q9CGv/RFNpw5Gpg9M9BWs3LE3hgvAlnTQRkS3Cq'
    'UBjKEUdyHUFT3/B/MN3Ub8JV8B/BJxeQmTAMIL6WPMZ9MK6PktpHeMGwNtLAgeq4GoijgFtgHw9CjLQfhFpg0CFqEQCDgHCGHMSW'
    'VyFhBgeA6wRLxDggDOBGI2Ghz7CPKUUh8yjxPJbfSQcYG6IuBbABGyuwfBtCUn7rmEwQWlYV1ikeCBxV/JoUPXCQBJAWoAjXBvi7'
    'FW4V3xNYNs4SAfmnxXmXesc7ecfaygiAKgHAKY0gbIu+cfk6Xr9C1DRYXp1x4/BfVgiYQl3bqlxd/Y6/eyfEgB9DbhKG8y7+npbJ'
    'oAhoiFcjcm2MQUQEIFj78B+Dizh1j4zr1Uw3JTrTfs+vKwsXWBI4CJ9ng/3wdkCmBa5uD1rnbbwXLJgqGSGYdprSnfLmmaaNjYD0'
    'F9AizgXEdszKKunAT6FCAqZ7olwJOkF8g+qUS6Zc22ku4m2ufQEImHmwIIjIwxWJJ4UOqmBwnnz9AIoA0taqhNCIYB20L5uWBgMl'
    'FhaEfcsCNDnbQCfbLAf9CDVDXQMZWZAlJz2B6RJKXzA10IGz9yvD3CVZFznBVybApGVAMweA2ndEEmDO7oLEQ4yFiDmJEYAD6gHT'
    '6AYAFs7+PRXgwBRMY26SwIbnic+IOPJwONzEpzOqKLlkT5gC1Fl4nJToLIOIjiRmYBc1w9WYIEgrJAXiNxA1SYeT6X7/KHGEBxgT'
    'eqzAiqaQrOMDYGPYD6TtSeG31E8y0BcXOM2d6uDXB8DIDlB3IJVwmtmvr9841o2gmA/EsouAYzkCTiaTymVwFBnzdBk5fUjUoUYm'
    'qEGL+N3y2csApSvJ8zniu3C+IWanJoETQIUe4jaEEsRucNRQJcblqHSc66FYLuqZ5rgRKxUDIH6SroXWdAk8VhIX7wFagS2O8Vcq'
    '/wnDI9z1z3/CEOLJtWTFYp9WMPzPSJs4qOCLrodKvNgKXn8ArjJ9IXwUaN2MH5EXwInX2BatHlvD7PmqB6uWoxJAJWcbg/Iv02Hi'
    'dCOmxKE/R0XqILCojknNrRmeOledmPIxyZuJw7gU/wd0Dl/YDD8CJgdi+B7kr6D9tQYQ6akxDCEYJ5hA1mSL3EW0Z/z6Hj5qMyG2'
    'Ff444Z3jAsa+3BHZOIXD2IWBvy8iVX8XxGh5v5jphceDFWeJxanGaWdfkZJJMMAQmj9tP/Mh0sjx0Z//e7JJYN8/02sfxcJuewdL'
    'xXMbff0z7qxJAHLx18bJ9wNbef+Tf9CCs/qBDxZ1w3BSdO2oRpgd6vqNw4Gvz/DB9ck4g0NDL+n5kqmo+St6jrBsDIfgcDjgfffg'
    'Rhf7EuETDghrDaHd78PvQMBzG//eyX6NAYJzyU9dOJEkx3fxgKFt1JoP/+j2xg0S/D5dkFEeBUxmy6Qn0kVcAFd+0+m0hqycATwM'
    'fgQMiH9A4nc8fADpfIFFh7X73iMripob/MQ2B5/IloWia3BCZB3oH3oTxHQEPi67IYG+cClj/TXnn0zjijOswlYCoZx5dKxUy/sJ'
    'CSZOSWaCFYdIXfj11+gsk9xw4sb0JPEE8bggsyeox9+dVGazjtYjjpzq0RPVo6eTemwJovXImEf1WH53rEdPERiXEcBh9h11utF0'
    'JULQYiRzSoQzmOBAliWgPShNCa4hWUCovTishko0klZsp+r6FQIiEFK2YkmhQswDUH3siCwJrGnjQMInY2C5zgTQLjASlKaeXgem'
    'KJUYciTOPv3lMvAFMjzOamMRC801d9gTUGQQcijiruReaTCQ0CcHdxCNZMRvkASMnbkSSDTAWCgneoDDhaP6PInDhWxVSYbQFKIB'
    'haFbrsvCo/kxODqMGF1ieFf2IUKifF7bhyTWAPC4KE5tUcbT9SkTV9MkXQWkooJCmBpLbOMIA1tCdkiwwl8XSNMSWzjVfithDwt1'
    'D03K2GLqf/ztU/qqLF3NPn8tfPslpSVR0RCTCSGi4B9jVT6t1AMSUmSPzqguzCwe55ZkVlhDkZaNNQb1qC2OuV8ROw0WDxYDqvwO'
    '8jQ8/WxEMLpxhsahfVjVjfo+0htaHj8Ir1s2koyUx6OFZc4u0YAUX9b0e0sSYBBP4BKLgIvI3wIXwARR2B9oex8neZT9OMQveZs+'
    '94CD+si2BArxkfiFuJQK2wB16Uec+qFHgVWGjTSSJI7QCpBIAoVCyfbaVwZ+grX7F/9HUleNubf4zLr6Fq48tIkogVr84Df9Ido0'
    'f/C5nbCqkSQ1JgwkgLFXgMjLENphpT8I/stoS4F5jvpGbQTWiLyld5Fh+zuDkb7ZeKemiXgcoYG/5Z+j/fC05NFO/FdnPbwxFTTH'
    '0sEKnmX6i4dGl9ZW7FnyFkkQzw0lKH4pXAGjXIjA+qcLS9N1Rq72RMV0XYNJEm0CiLr4HGJtaASFHEYlSNzBSdFTtMGAbsIhIEJI'
    'KdtPG8Js7tQOPlAz+HCyNus5Ti71P8Jg039PxSxj/k8MOf3PuTb7506dWnE/+PQn6eoIOCKR+vA5EWAIaiaJZ58vFP7cAT+Zjvxe'
    '4O94cOBk6hrVTVAPjwVv4lLYXQdNXAqL67A+h2A29EB7/Ik+Y/T/z3HWapdtT/CeVfv2Go6YifvkiNNRo/fYGC/gv4oiDxLxP0TY'
    'CANZHTWK3/jR5SgSkB9QZCzCzyV2wFvBP6wiEQE4xZ+x7ffMroKsCcXO901O6w0OAAVUpgOSEEtc6UCtdL8IKmxQxJ2bSJcJPFEb'
    'JSFrY70nfRCXiVUXpGLWSQwwDtPSckUI0M+15qK8FgpnJ5ZFAaSMBdFIUlWRoc50veQpwTAilIJxBDGa5xmpcNUTxS1urPKZLyi1'
    'hjKMRdvBxvcefvnU7j37QstnffbRfYjfcUP8r0hUsLPkQnJjFo4iaDJQXftYkaPC94JCHoUC2+b3wtRRpdV7DlUCa05SFGguBLdA'
    'Rnlr7kkXljNmkBARdB4h3VG0zDRXIZ/KtAwSAYHr0W4GkvI57SX8tJb2sSuRGP8oOPKRoHDMUB/0kRDE16D4NUIg/4uUsT5wB8dp'
    'FTI/r5gN/S1mAxgoVo3J+P9pvuNnnfEcNG+dlAufT954Jv1mn2hn8N3bnAizc3zw2Qk9yV+c8hP8ddJRLV2S1Vjq724iNQdkLlzE'
    'k1BqHQM4AUqlxmB9xQzgT2Q9WD8095P9wWFd8+HBbpnXND7a9ai4w+Q/5Dj0kOP46m8RfxcKgViYDR5LsafTj4QdA/pKxfCNb2Fg'
    'Zc93HECydgKffwqbr8CXVuAUfEPGlomywQYAsPA3pzvAZd6/tgOZdGQHuPjEgA7X4UyeDhaJnSYuNAfTRW4RRQAuQoswPbYkCXz+'
    'iSEVX/z20Vho+XGT/jOhQGZJ4qWYPchN4t/XX7mFyCVEFpI/CV3RiPcLf0TsSLwysyaBNE7SJ7IdgWHpAu1D+NeczaJsiJvESghj'
    '7EmIWKN4q6FNyk36zwE8cfb1MkRKXL1AqrdQO4PWXk3hPgbJAHv5uhKJOCBmmTrFx0HxQK+y0hQ3aA0qAgwA4+ShIPEKXwPy8Ktp'
    'bsc0iYS8idV9Cy95RwKtvgZaGqBtFCxPSGvQJqHb77X5pmwQjoe8bf5C3Q+v6uLAQqPjyRqwISEBc7xYTLoUpszcJ3Fu/+NHQUoi'
    'Tr0SYtPw3RTfxSMqGFiI1ixmIFnjasFgiD5Vj+PQhWZEfvOPHakAuVI5uDAiSKxl9O8gtT+gQDLjk0le444/b6iX2cUc3+cHzlTg'
    '9sOXA45BsBhooo7KPzF4QeCtooBHCxeLf0rDEVAis1VUy1uw2ZKxGwX59z+Y+NfXU1cSCZh1oJs80fi6m6kH+0e07CtHgcgAfhDo'
    'EIQMlMY61kDGxgtWjBeF34lEPEp3ZSS4eA5iUOqT9hnIKxa3Nu4iJuNOBjsBr3Ek/JQZ83ttNsO1CgAjnDAhP2nqxiSADfj4L0Is'
    'I/zGXrdrYZMKyAr8JaxrpAhUU1D3/T60OZMUxpUkQZcMy2pGbHoZYlz4ukUABKh5lmRXQMPWv/3v/yf3f2Du6swniH1DL1BmiQNq'
    'wy++OGjjwVtiB4A1GVVI7F5QPBk5ryhYpuDPP7X2Angz+CMpKS4qSVttLnmmkwRy46GWDDmK8C3069zMmabCV2lAS3Ugd0jLcG5e'
    'SKtwhH9nF9KIZsFsmD8b0K6zQt2FNvP+zkjbv/1v/y+UfF3GbyP0mFpF+mUz+xgOKOYhMfRoQW+YQKTJaNzwPVVcywGRNOoVzi2L'
    'FoiZ79FjzpNW3N7DlH9+AXfjkMxChjegkMHqYvsfmLM5DOnL7+gtRrayD+80+Z0gOZp0xVxAPrxD4vHuj99xK+ke4Lu/aVe/fMW6'
    '396l/vg9BXX/+PL+pzN/AKZCJ7vwr2gkhaHgc6QEmucYjpQ9VJ4FLm0yAIanPugq/opd+P5rybnq3QGLCPOIXWSUcHVJ81shdzVG'
    'twgPp4mFmLnk+ifMdugYhdz1nlz4BOuA3nfEXLDyYlBeLLLyBb+8WOLlRcaMsFK81XxQKsdKlfBQwV7eLVANLKNTjcvci965DH2+'
    'oyGTOEi+mYRayeWRWd+58w3X0IaaHN/TPMn9puR7VbW4ww77FryIquhxBHVEQYy1P/H0ef+mp89rsZMoly8aMJ3HK1TrN/zJ/4Ys'
    'deyNt3BU0xEJ6S8KpU0QCgOBlNRM+CJYHcTXbC4kQBoMuUbkS64CQEqnwDKpJPyjrE8SPPCAAt8eVJ3jhTlaUZ/ycfKAoMYU33Aq'
    'yba9Qel/Z7BLkiixR/fl/et9+fes7Ydgbd+SjabQImue6P8l0YaAPl7xx2lkpcPBfEI24nNUbnj1DXYJRF0l7ssbfzrsnyNbzRv4'
    '05ngtuM8DDZ6Pk5OzpvA9/ANf4uwTwkopueEnfP88tvTPP1wOseQE2Lep75N3SQ3FNhBdLHenbObEWYzzmDJ4L7YyDlFrBuRvfoB'
    'r8Z4IeP7E/8hK8f2Z6u52pTEtjf4TuJif+ZHBVU3xjlHOdP2XVVHdEH7GmHU4v6wI9WRbYtzh0PGxAVHmBb0Du+ak4+NRA4LRNfE'
    'jGBeyPgFDhOp1fCYhesae72w6OzI9uPN1aXGbrAHWt9AgEWy4LPIwNoE7JMnGRm0M8BBcZJoiEnu6XGP58Xnk1JCJiKjApd+zmth'
    '4ejvV7wYA6ohs4z5E3DRuUgO12WNjvv4DreNiaqRVeEeHnj+aIF8MhBxX8I+HBVYIXT64s5wiuZwrIUtczCyTI3IEfrIgTxrMIBF'
    'UVVRELNF9sX1UNuN0gneWnKwMf0Qj6y4u4OD9MaKW2cAytV3TKwjRaFvMo1uWahymDNk79f/zqZZ4aZZuGlX0SIWFZljEYuKzKFI'
    'ZCcjRenRBR5XinMmVzaBs47HQ5F4eujuGAIPufHI5CXsPPJ7GnAm00OLG27+nfIdMRBdBgx4D5T5TlIRBANdOiDd4dEdSAGRFIbo'
    'XIhi/xVe9hBo3y8YV0iesQpvIEb8FTp6QR/0isQ5iS6cOuRRr7AkvNJ8jkzK+3M3uQjkuijS4TbpB+bs7LOY1DBZn5j4TzIQzIyJ'
    'u6gr8NUyoariY7Bg1/6aB0uJCp5gMS1U06l7FBwickqonKXOLOyN47wVDQFWlvAor0kaL/4lWP4VIUNGMnEPcOXYKWTzjE6eLRZy'
    'qWQBR78stsK4R0g0uI2SrN1kefCRegTXApI7qjQzGjHg3HD0tFb+SiSh1QdJXsRiq0tB4yLhKjANau/RPSQqy7KmbwD3Q01ZZUc0'
    'QsWtCBXHA0qlkCSyASTZCNbq6Rr5dCh+OnQGtd9+Yi4QrolXuwKEBzCjzmaIjbYq9wpB/06fvMLSOBpa7XeaEfXJJAYGtiLkm32f'
    '58gCYnOn+IeAjnQ2MXL3Qr8uny1CZxyZCRshAAYqQCC9im9vi73mZoBphY/vGR95S7yAF3ALFxi9YX8ZMJHEJKK5krtNkhaRaB9Z'
    'WOlO73yjSw7N/7QhimrBumFrEENuPe2LgEzrgm0zDvYSpsg/+Zytz7DS9zjziaaPPm9DOY2Jc2X9oIP2BoDhEPXaBMFWZb69CM24'
    '0u/xygdLPU1dOZyHdtQrxhD7CAdbl6Y8UkS4NQyNwiKjwAWr/HN0owLeLGSUAi4N9lCMaKX9RjLYCG7pRyFGjf8Br/AZsGomDvSb'
    'vaUf1wKpnUmiCC0mqnOK2CUAuNgUagBa/w3F8ii7HdH6fQzkTnRW8aVCbC4m5mFHcnEmH0YM2/QRhMtcHJsWfcHxtA6KkPSmfCmU'
    'uLqf+825Ph1kzU2T8IazGpa5i4lJbIQZzxm4RojqbBcY9aMmBpCJyZsieE86bviQow8RthQpEzRyzVebVcRXYR9nZnYcQywUrslm'
    'j1prsuFHhxa1qkcqpUmLTvb5iJRORkccAbPYY4PMZB9pEd17YG1SOD43amQQyJVQhp1xcXcAj5IHw7Xw88++g8Ol732PowGgkFyV'
    '5ukyzbkHJ+H6FA4QNtkewhYmcQ/d3VkR7rVCpTJJ2NkMt03g/vNlQ90xOTFA+YJwfbrT1h52esXB440K+VcVDlSBafZDh1ZSxJzx'
    'a3jzjGNRXCtUxwCtIQXBl1++NnwvD1hx/kSLfvENv8123wT6636DIf7yFe8GfvvyPmqeGuLxaiTDPc0UEHT8NwgamSy+IbPQb1iW'
    '9q6RxLWnN3in5tMJykYLCEMMkW3nlhgh8Mf4mTsafRQ+fYYOsFIP1Uf8NVRHByQcY7SVxekxa7BjJiYzpahdbMcdDlyu+4VOojY4'
    '9gk5DB2xCi0qX30aAgE6Wcd858JrRlpIubxjl7e0BWmZf4q4mYRqaZzpG+4b1O7zxWchFTGS+X4g3AcE+ATqIjJL39vkN8HFr4u3'
    'vi7419D6OJcQeUJbv/56vhglf0Jcv4wtakjNsU7itPRvsOj+3INxyaqmx4IpeHhY4f8hIME8G8k3jgKCUo70Sw12bOCsCdi7vGDv'
    '8GRk/EUN20N3U97ez0F78XA8OAoYgJhPxzkL0MG1AR6XbhPIwJAHF5FY7CaX31YkcQpVsgh0sbXpepzzYheCXOQNJZ2DL7mXIIok'
    'qs06QpMgu8TBWSZgSzSd85R+nCim8qU+tIhXwzPgmKizJxcYQpr8DBMEunFY/ACgYelAFL4MLQ9X7A0sqL+ncRJk4PBcCXhi4vT5'
    'OoTek6bfXOtXb33vrlOXhA5uJc25A3LRxo19ZQjx2q98KSiEXmDX6QihgZ14rA84SRgkG/qV0IEPjklXIGMdFCAB2fxGX6j4bxxM'
    '2PjpFecNqRL5YZ1DRwi5gCCYaoA1TVKmDew81o3H4/GIV1JPmrvcS/hvHj5rbLO5A5WreQwq0GUZnSA0D+3ijLdkN7z8nU8GOs6D'
    '4MqSHrnIH3DiDArZ1R1vgToWeyM5HgdXpoUg7zvgGafafB7EDnMFvNbJX+E4QxiiUX+gP1zRwtx82avQ8o/E0Qv5GFw0Ubx8A9um'
    'k8UcHV3cKiR7knKKkTyOlMX8a6JVAN7kl6/e92iSvACowov0OERC0R73+/fIbS7cw1dY++JvF7Crno+04RkH9i0eKDlouhzI/+A9'
    'BH5q2C8z/dFdV/8G7BRt2F8SMOJI5auTyt++/NnI/qz+qyGfrseQ8COOD4T2DWxWzN2sLwWZ6To2GBRFRgKSDrRjuHewo6xS0KkY'
    '9znS6DalgSt6HwWWx6C7U1xzureFPFHFS6xRJUpzUgcOovxmzXQyn49HcU+0GtkJhMQHv9EEjec9JwZ/jv/ZaoXEBcWFEzpEbC4j'
    'Q2IBIENQkaN+s5l4eAHnpIlzxHdKE3eMG8lA7cXJhwV9yOZP3LNX30Hri4NlejFEUwyPP5O0tOPnLXZYBO8IXYYMChvvCsBbJD32'
    'q7Gt3hzYKh6aYaJe5lcxossnuxE/U7zSVbAGv5UNfwCvIz+wYxgeOQP8u56PydEbPh6Yx3fihxwHI2ne4vr1J8acE9jwrSK8RZD4'
    'SP+O/R5ej54W9BvX/FYBwSoHCpVF/CcLdAJMsaXt8dYknWTmiupbxDHw1inKRsQWT8KCGiCio6GOsQr+/YuINiRgcT26Ck2sbYTV'
    '564Mn1G68QKT9Ctk4iM44fcP1MSZ1cqSHMnnZ5KuBfQodvF35lkZGHW4S67vZRepTUsBtbEVXjslJFLxiFNzIONTKx/ZnwSyy/Av'
    '1b+mP1FPZpwQDJwcQ1jf3vvQ2BR4mPqsSMQPI+JwLPh1o61zkwdxTQFqZ9oL6pTqR24/8YuZNE40VPiOveGWXjO7JBDb4LKt71MS'
    '7eXKt4dFRqG97jskr1ocVXlXV2Gtk0meFHwvRLym+RctWIZvEWfv1wv1LTya6LYSKMpVV/YD1LihV8SnX3//491n9IqQOZ29+PUC'
    'JMhfpbX1Hj3dfqdfukc//qAfc/bjHf3AQMXvL4Rvn+TP8UAh7MxRIUP3bv4IZCK84Ahw5ao1w0PXTD4v9AoEXByYyj5thT9gGQuX'
    'Aj2UhF+FTD6Pv+jhM/nFRG6B7rGtS2QPPIptET1SaJyAsWAJ6GXKf/FycM5Q7Al01IxKSZ+0z6Rlwr9XAv4kXVPUQvEFW/nl6yyW'
    'jn+7xL8i/5uJf4t/4cjlBng0vKyO/JEOYBaELECxg7mCkCICiNFc2566iAD0qPoMVYekUkQFBQaHU/UINmEv+OTDC7CfoEPYzenn'
    'yNSJj9riRLeI//L5CMFf76PEj1dGR00jeK8ZkffkYQiVElAizrC0guzfGi05a8OXFBdMSHYl0gYq6IWqIL0SA1sQCCrIgevEmJxw'
    'BIoSp/o4NKC4DuoMY3PmTpUS8Ou/kBKGf5/jd1QKOuwzsfbXQsxB01LwKhdRhWXwIMDIfmPjSSczedpimB1+0nH/gcnNwzf9TNGI'
    'Z+iNSWT4LEAGhwVh181+OysIlPZfiJpn4vRANWChsUf8JfuElXuFO8B8z+H/UxH38tMn+RIj1aSBPnyCvzJ/TNPjnj/iB14gzR9l'
    'etx//vwpxiT2mW6aTmxBq4gcY4GePkfgm3HS0QGEEBQ5KgF0iJcnbOcWgYMWA0Et6Zn8/jmc8iTwt1281hqDZbpIA1lKYoTn2MWF'
    'b42tMHsaRWFE+Zw7epCZf22agHkpXAnZSwNHkEtuh1UEblH9vrE6iQIYu6JJR01RLVIR0L1OHo1B0TA6u6z6bl4AKqz961NTAEpR'
    'vlPXxmNeJi63APBo0NjTLIjUfXaaURFANWBBFmpQKcninF8G9kMWz4NESokqa4YXcUGT1jQhf11IOKTgFPwSxVrygBFiLoD0fq2q'
    'XpKMHk2QWjUWVV5l/jLIDFB0Fz/4EiykC7NXY3Hm2uRXY65N2GlXtZnDZWCsoO1BB2NYxwOIwZq9UQVJdkw3CGbKW+crjt5y6Ie4'
    'WU8NSUOzjGnGI9Yy6LN3qhidRfyRTvwz/HuF+C68iwEf+MA/UWOmxQ0YPtL5eYZKq1nSwTMLf9Lswr/vv8HtElET9RuQH4tw78z8'
    'PUvKe1TtHdjzIc5bJ+Y90ls87h+AXmBE8k1wTHnkx1jjNiID9w2vvZPeCE4Hhu2iaH7ctR0DGMEBWmymybOFpLmHXi4/a+7jZhqL'
    'eAXE/8SRJfQyWEB7vtNMyBn62xXUOtW3Bxc/OQnjL5CMhW4ymrFqGa+ZiLfIW9ANIPJyGdCOAwgI5MxSEZ7n9CyKqLGYIn9WINPF'
    '38SCWBSnpC3/24z+u3jPnQN5kOEgwJ3FlDhrOJhyLC5IimR5boCbfAwQY0GOJOdqquMl5ncOYKt3/lcWGInFwtUMioUrrE1FDZxq'
    'e48Pzw9+dBMqh2ar6TwyPuQkLIyvF3kDy4S/M0pWzJYuKLYY/c4Xsur0gsX8whfKVC1SBdwyjHyVFDPsjgF+LUyLmVKa31WQrxkv'
    'KGNgBrzsFMMndAAjhQNyXPAiWSzByibTJaSPl+GQ0NVNVS1eK1qDSqXpPxCe6bIDLkM4TTEn5sVSdJriLJPJFMNpqjk1r5bDaRZU'
    'qTRTI9MU1axUUKPTzOXDaUolaTaVzqdJsBliCgQOeaZk1TQCx58sQgHpeVL014AD1Z+sgb9SuAY8oppkWT2EsKirrf/AnW2TeH3V'
    'BcTtsYKoi8D1o/ss7AHmSJDDwjTeMd2zQ4rYaGw+pFyMsmBAIskJXEp2fsg7+Emf8XIQRdkL7ghEdLsCsl4wtfn3FP3zNzQvsXnE'
    'tCQin1aM++YxRKhoyCCmcp7UUB2SyVBDTM1B03oEHAgEU4hh2L44YcGNRxr0yPwk2UNpnE/zkt0OxUCDXPdPcf2YIieM+o2txwx1'
    'zjy1PnDFfJyTY5Lo0ZCg7iX0tgoIKoyAKBsUOapO1O2Nd3+voVc8MWeHKAlDXyqM8secGABm9tH7A0g92L17vCgUvj/Q+0Og1Zy/'
    'rZzy3eIiFAnaT2F5X48E7dJvX4cU1RCyvdjhPizip4ypc67jn0NbNnmJM28uX2sFqNrGoSvM38s3SjjnhJSNLqCjNjKv8QhhtQ/4'
    'IlRuwtBOCtuHOCk/r7Bp5ta4mWqycPs//7+jBieAR5eUXOEThVS5JNWDY+roX+o/AsgBH/jZB/So64F/hmMUqFFK7kk+JPIuoXcb'
    'Hf4DfjmwLwf6cqAvpM0N3UzV440XawcSWyimkvm5/Ql5+vYn8fMliSPT8INIHzL8gxx+yNCHLH2IrCx9pX/8KVyyd1MSGPCnFz+x'
    'P5O651Y9/vcOL3QDOhuc6r8KB7j2X6FH2dn8Pn1io4EG4OsaJZ01lZJZf58/h6oPdzOFeeF24tRQZ82weDDjk6mn42yCxAEiyvKQ'
    'SfMYy+Y/or8K9M/80GTJMEKhhTukbX3xARkiejB3Esbk98jp9ZLjj5nP7PG753+gQiBG2WkcdQbYQ4l6pBGiQVkKBjpjt2HxFmwo'
    '/mM2AN5hoBj01VciXYn6IORK/C5U1HIXDDOBwTOQK4UfCMEaTBtqBMrlWSwCxHEab6gdJO2iiYoeGAdGKiVVn39n0x/MiokLK1xg'
    'GMuKxuLrI+hWcwwaSUB1hnrO+12TGyDrmbqAF1yVT53TT1+pyOFloUVjJPBl8s4UZp4ZKG+QZ0BC4shBPERMPcTkQEynYO4wbC4Q'
    'CJKxgGJ+gVdfhP/5f7Aws0xLGHO1uYHhfVbc94oISgQfmDuKj8vPAfw8cZZDpBogGk4IAvSC5zlQ0vgYHgvFueu8SZfUuA/t3IhR'
    '67+dIVEkKfyDjqGZc5l0VDvkh6eNMbQ3RXzHDLREPXAEv2FHhABjDANOEfUxXE8kJyjEHKb8AyxdBigAgDgDBbMRHBV5Nf3si0YU'
    'TJEcO4mfcWRGyTE2UyAHkbjubAwMv7vQuJv2TN2hfB3NthRWdSnEhW+l/4lHDg5vwZGqVBFiX/Aql/Hl2nfUDo77GniEIZ5Y31sA'
    'WQXVZi571Db6SbPYj9g0MRr+KGQdo1F45lylS3YkMruBFOfHPeW6apogXSiTBLxCp3NU4yfHYF5+ALCe6pALMRrGpUChEYE8iryM'
    'sZ1j1qXge3aSEWVFUPXp8zkJIDiwEA4P+PeAQYqn/nuDv0dJN+IWhyoY/RRGI/AcoZS/C9lMmvONIK7lfD3iFLfNjynsyujw+yGI'
    'yntm+pgyEzzqwbCJS+GK/Ukns/Scxcc8PebxsUSPpc+niBADBL9xLMMrMQtmnUlfkrTnOwGd4doMu36aTZ+gWr8P1JcE2AwRbFaM'
    'n2BJbhGiGKS0MWELr7hH01djhEaU4GTbtNgmntrfI5yZSJ4SkVIHKnVgpRYnpaJMLFAtGzfOZkVL7F6X5+LdnrNoIf5fAEKWMcll'
    'qWTCixYIm7pkMS8JWEpAl5jnjJFFw5yacPRclSdEuD6J5cLuzSVP1pTdenmggCbRMVunYy4gcjxjzE++R+1WP4eNwkrQ0WBe116g'
    'CsX182iVbbbKYu5kbT1aW964iN6lCDWwYBFqFPqMEWyR+2kaNoDg6zchl/ZZX2zwFGtfsSPGfFaJ+4RD8Du58qWTaYqaGYkL4sIn'
    'OkS4cf5pct/7p6wdWoE5ksYPIR9FEf/uHyo3/UaPhbTH+9gowJO77bUQRGzi4bX9iIZksLwOohUi5mAyeVgzCI34Z1XDa9EUC/Af'
    'lZu7XqvDRgP4/po8DC55uDoKy02RETGqdyGsuzEohjsXIiMKpjNsxb4jPX0fGrwB3xFdI4xHZBCj3TLlUcvgCRqZOzkDdbIs82eA'
    'N5BEuoMqD+iHIRJwGVmtWPeK8Y6ABUIawDVQftRC7Id7W8bpAgM5En3BJf2CHy79FIKxsAm8RWIQO8Nj7vNLTCckEejYA8sBCUIt'
    'kD3DYFIxv+Xk+fwPqZgxHj9TMC+I6gSKR/K0Ix3ySbJFUiawqIMUi5/U0C4VJFLlqyR4CiV/SUjwxjPP65PGU3OYYx8SWn5JNnS2'
    'Cun7AYYXZbdQx0ERYhjNY7oBrnxEh9ZLDFPtRgnfV7aQQRx7tjk+QWK4mVvtN1pYbEHQdcE0VSxVQhgKX9XvePiZD9RfSC5Rq47j'
    'gNMcBe5PZAamk4ASj8eQHL3ksTJJ9jeUC4rdc/aeoodiNTK8vFGRxRn9btX3/wkuAMlhO+JluIoTfWWrCB2+zYUQxiJ2nsyBUd/i'
    'twK6sDaj/OQUTacRfpK9ivKTkfZDhBqK9H9EFC4hlxKRUvakHDjhid8Hw6C1WO8DpcC301dTvmqfGbqlgQQNH1jDUT76rGGJL/I6'
    'bHh68spvmAt2cGxu2K6vcMl9OIBHYh/wdtDnj690eJdU8fakIsKdX834XjXmdkyVPgpZdB2PeJelKR4hDujjiSxrIwr+LtW+wkbJ'
    'jCnGTz2XQTT/wAf6Jw0abzQoXrJbJ2LgIcjEeySgQDwDJdrFRSRziY9dPHODhkk/oArmKQDswmH+DukqaR0iKodoRFJymSygxwz5'
    'hQErupB0FNeyyXzwVuS+zG2UNxj6hqNJlWOeZtG9IrSg1eMR1QNm7UBcrKLRjzxSDcK2dK8Vw8MQYUJBglq7YpIq64iir3I7JXSA'
    'VNQL9RkgDof3VvmdJjLmQVG00CIhIwLAjjezm1LQPGENa8W6cD12NSnwuqHxYaIrprPVienzbZhsjHQDAgjMCqQ4JXRsZXOG41Jn'
    '7h8mI+RRpYZmBZx2nemU7OiLAGLg2QlYOkb5HcIG0AJCjUM4AH8Q9OAW+H1y9oqDCvIVMarEOEIK7sp/1j/B0v4mZD9ji9QW4wz9'
    'MoeTMkzDG5GlfN31B9p8yrBCE/5EvwgP+D3BpyQ6QBKosJ/oWI8gRnjC7y34gOUSYTUERR6N6vvtJv5iu1dn7X7mUO3fuyYAYLxA'
    'mBgbiY0LDAhyLoZ65kcfHgMEL28DQHtO/YUYCcSsJ81P9sMiMqGCcsFTHmicXUEJ20LtjOI7rLt6kAIh6I7OR+So4cjJ3f8nHrRQ'
    'Z27a2GNUp+Ab9sO9xI8tiiEEny5Zyu03ANhRsczdJ4wLjVBxJmmiXM90afSEuj3/OfEB/Uxee+3RxwiuvOO4MgL5TGiErjm+5D8I'
    '8rF6ZLjX+BiVmDiQcl3dHTtztGL0g52YJPkAxF7haFqKEEv/gYl4whvpXlRk4u9470FgcqJR8Sj6vWOeMGy9kQoQ0o+HFYganlfx'
    'y/tU5/LkLhOAOWPB7phiW7N81uqOdNIA7+x7MHGRmTTgg18y+JT222Y3mq0QspYbsoOTbYvY6QAQOf/N4oX7MrFlrlQK/L+ZL3wM'
    'nvyzdflTMGBzDSGB/w7QILsPkP+r6/pX+qOaJz2yN6/7fGNvcNm/PP/yFXciuUe3PHo6fBPu8FEMXor0Ep8ywbtM8C4bvENUHL2h'
    'gIJq4JnJItwzUyzJr3C0viD1hb24wld4D/3w4d0vX5GiZ5MZbB0fM8nct3dfhOvX7bDEAN9ph2T6sxYuohw6Qsgj4y4CKuFfFfjy'
    'u4VKFuXDO1gfQuk4Q8LZ34QGf/Vj6hFU+DHx+H5zib/W3CnN+DZ5R+5PuI7yt3d8XU5/XZF49OGdGLzAlUXnsg/vSNJ9l/ojuosU'
    'xNBmyyJrjoya1D02CWAIjcoH9nyAZ8ffPzGZIW+S0rfIeFCU+0aNRzIsoOmAybEqhojF6x5uKPhKnidhkJDQI3H3FkQFkLDjdwfQ'
    's5r3Ah9ZDgfmK+IzVEA0UQPDJVvuB4aR/Rn9A/qq+beEOKfKvM4DKfVjBEp++aoEE0VtTHThfSH21frjSiWE8reTbZAly98FkHgl'
    'WfNgeZNZXLUAgHEgQLT+Wvfyd/p2d9/tGJqDc/SNQwHvjck0H8NzE2P4zcfhXDsQZwcVJRpYeF4mfj50X7I6a67LbM4+7v9ukxxh'
    '+o0iFt1o8X/PulB+JZ7L9tXShJe6cpfCjtS7cWjnl68LzfvG1HAf3gHn7prONRk4VMc/Mqfu5IF5jKWzZW6WnExJwJvoShAOLYD0'
    'wPmRf+V5ZUlCMA2PAnFq0bsSPEoSkGAWd+N1aCOyAbIQyBS7xI9rxAfLTICUrhRTfrhR/RnXvKEjFku7Kpumo2gGZp1MChvtA7to'
    'H3HLxtDCfuZJ7sgdDbZD/pEb7VLgvjmBP09UlYQZPZmX1ycq9plhoyAAXHTT/ShP+C5IBBnJmYFSAF+it2PCGW48IqejTTS4XU7F'
    'I06cgdt1VM+CBeJvtvqDUGgsqhjz7jtxqvp+jLTQIZEksJOYYZGiM14U/TdZdLCPH1HnJINw4iCrIB+uWagoJ3392trkhNYmB7NX'
    'CI7I01kSO41umBEnePx9Kbxy5aRGgqBUJ5dEySMXvSAZyBgYh4f8/kjvioxa4DPsu8e+Z0pbiYIWXHKmD4Xnd+hvxs539M5ANFIH'
    'thFGEidBQKWLm1FWgHkJAxuA+XZNw1davhIxiIh84EVCL03uG8ed5HpJHBV5sJknGQACz9wwiJzvgIJRC3pJOcj5Ef/R3r/a4EuK'
    'SEpRDvD3t3/+8pU3hI84CsaUcUMNLQkGUv98LvQQigg/Y5PY0S9fuetyIuE3xJbSBR7cjdyOetNv4YNQ4H4LrDghaJeF/5zBIUKE'
    'GyMv4sSpmy9ethNS6HOfIrgjcmVaVzQzrBUs27lzLKsWj3/zsTL+R/tOnSNYSXo1dL7GxjSkFD7E9Q0AxA/vMPxqF5OAt4y+C8SD'
    'cT3opxywPeio7PM9bJB/AGnFiX77PXXakT+UE6nsy8bRY39jK8xWna7FCKFOWFXmqss15GTo89f7xxiHhykz4m8jFOXEoS6pnGAQ'
    '2PMGu1Q1M+WN25NYFIrgWnQYzdv/Ho8WiLpHv1GUs2ULOMJ0jJmlE+rSENh0YZ9iwTA+Che/zyPMkFh69weL3YGOboGhItItKcjZ'
    'bcuoHS6JlhKKrMXyNqAG2MdHl5H4qYUgTgsG4UE1o59rnbQ8SL2AE7gWvqCf6RWOGLcfVxLFjG9xguTo6FNzf8CnUe9DDwLa7fMU'
    '0Oe5mrkyiCFD/BjyBz5X6qeUjKS4JO0r8tIUugn1MoFMzG5lGIYf6wldH+huA7+AHxsSL0G7g4qaYM+wI9aFKlPIKx5t6drvHvsM'
    'NnYeGacnYQJpqIqKjYtIaO14eF8BIQVmvNHYBcEIDJ4F2w5ybr8Rfztki+hFGDAJzey4qDpPys3dVYkIMf9eZjXjN9rZDQ9tNlOJ'
    'gLOMB2GkYgzoFlw48CmZxqNRhbHUmLqZtpI5sQHbo0qU/R32gl30eHdHEYOB8SeWke6iIJd143vGo3MUGyGGn8YwY5HYBdQ6s5a9'
    'EaFVf510BZkYnjPhLHY7xvPDO2QshlyUAjJCw/NUfEx6ZsPcqc6d5HLeil+qhlK4c/QAnGM4NGgu/OETGT9b1Ukyh7CKf430VSar'
    '07NEYMJycjMAisDJDya+VllkmxBcWMYMRqZZS8CrRT+T8tH/GPfxtO4f1BPOgvlDMavn1NyzuD4soI4RtaWfOjifGtAjpkIKn+Cn'
    'QmJZkE5iIPiOIoE7riUpp6EF05ehVxszyknM1+WS3OfQlMacnv37eBQrnZv7IgWvwoIUiiFOu//b9zo6UEcLvz6z2S3e6IgZECMF'
    'r8KCrKNTnbjuxxylMyPx84k5f9l9n7WGEUERLBFfXbi+k1kYns+/jELx5izTC7XWrCMmv5261JCvmMEcAqjHy0Ahz/0HDtxdgBnq'
    '/XG5msfj0OHNVq7h+4nTQ4WjlEhFPOZrwjUaOmIwRTnzX6NhoYoiiCIbTwpfyK8BPRKifneEXoLJ8JhglNgYBiKrQR7xEBsyx4cQ'
    'uTDD/qfPkZuhsFIsWHnMd6ujMAZAUiJ88yu/NPxxZ9KLqGvadzjH0OX1lXI+Tca/2Iruh7LgZVehTz6Fa1gxqEENaDoXNWfxAXtc'
    'kKJDZvNDZtMhw0hL36Ksrh+TK/2G7xkFoCSDPSI/i3AL3alD8hp1cLLC2Ly/C76DWfasiC80QRHfuywbZ/37rlChmYsWkiGZIOIJ'
    'SB7MOiJDVY4Q8FayiUnoULXKw58QOvortXJxXoMtwm9C4cTLyqN7wfn4qW0DbSzBblOY63Dn8WvgSeWcBjXgNWErmZdc1BOZzZPu'
    '8GPlU3Mi8786MQMuzakbgO1fJYZBBAR2GuZmGNgydLS5fO1DE6GSUqhyCOkJ8/04oyMhzZSIpEzf5tYD5xkgHTwUrEkWIT8UrETu'
    'h/4vvHzue9+EbiNNCg3cjOHXExfW+BtOmWnuAB94ZTKPPr72kUNELplozeCLJnkMd6ER2lPxSklo3KNrmGqQrorxujyJCD6fiL0Y'
    'TjfkNSgyW8g5+JmyThiQzycZt+hiBdewfBRQTAzyW12zxtlbfMRXPdr/ExlJo5BaAWMBQ5BYAiXiCuDnNPxJnm+xt+QlXPc/F5mm'
    'b5aJAAiMJh5KR2cSUR4koven8lNELgr3/Q2ZCGf9KikYuR0CSsgk86Hcw/wQKQmT70rtw9GZSIQlSUJnIlHo2nXNmfqQccdN0pTQ'
    '1Qs3Arn8bz+YOopTP4DZgg+z0IMfpwrm9wpsC2hnZJPCMQRdItrw6+nBVHE5ECK+nYQ8C13vSD2J/opM3WvCkea29GvhxLcQcQZ3'
    'XYwn/7Ny/FmQ8sv/gONZ1Jv7Tx3IMAalxFLr0NXia+Gv+4RxQPoY+meduYW98gJ763vgEgZ9v3L0Or9Wce719cb36ee/gv7eAqV2'
    'gP18MCJ549tbqSbehCTcbQQ2f7/5lfaAVXT9GA3sjBLTyKPmoUDOEn4EbCMxjPwiB1byA+lxj8IQj/4cY4eQXjwomhccw1fBi0hV'
    'Stef0ZAr5n0a/0acutdh6k7To2JLQVgnPppLQSzi6nm7s9R/YdjRH0d2isdPOzqN4uXtKAJ6gcXNfB04KyGU2M05zsyecrK0ICxC'
    'yZpAm0s/B3qBQL3wb3v6FI0paz7pST8PI3oy+g6HbzCWTGQkpeRceANzfsfW9MtXBJ+PwsUpCeDxbP/4HR3PBNJVoqKS9JSopAzN'
    'jvBjoeJ5xl8L1F/uQ7sXyGtc/GJmL99820tO5ycW5bdROZFVlvxMl9+wO363Fl5fFpMZUtoGVzT8eGcICjHPDxj/5XeK/kiDXifD'
    'SWLwGqyC+xvTWGgDnAKWvkKrAiqOmUT4DnAdTFUyvCt0I8ZeYJ3RZVvS31GksquZtNZ0aphgmr/FqJKk7XX9Nzu+lHAOwtXCuf/x'
    'y1fVlQFYv/2ewiH88SWM4YJxwCKE7FvoZOufVOQnfnBQ34S3czKH8yedQZo0Bukw7WZAThkQ4mtgLs8UQaSRmDINMXqC4k+J/TwN'
    'hOjrnfxH9/umtqg66fxa954ilUSuRrPTZiQj16LZlVnk3MKQGpErRyzcNQM6iqLlq3fdHcVGCLmKOc+DTfSNLmMg68+jePv13odN'
    'sWsW75kHAtIFkokp+EZMjvtSTLCN0eYpxPfr1vHKODMSsUbnSfjz8ezmf4apn+N+h70kBkygkAq5/Gm3Qfu9JMWFOGtWTBb8RuAV'
    'BR8/bYy4YFyjSHrs1yELIvO4iJjRL95YKr+zcCVYjHPqGT9eR0eQjUc7ZqCP0Sp6FISMmc0o00gwS/waZWGc/esL99HvNJUbMvWx'
    '+590NdglvAxTcyRS38VfhWrwYwUEHMyX3/krbhMyiE9RQruQQXyGcghwKwdo/H1gvxf8t48xZifI1X3LXeQb/EPj/BbiyGu0aIUI'
    '3x9GgBCVE9QPwzhB/jCMYIjO/j8xmhMDEnNd+MAs3DzrG2zmaSqK9z+xZF5o04qSQGaPY9YUP5sfJmTFQf1lc9QZcSwFxDFiCQ0o'
    'UQS0wtFE1/RKKIRLyn5EVxSZDAqgyif+ES+Y4XWy86X+UcEzEuzgTgLnEvOrsRDC33XzIZr7apcy797wjCsIudAwyjKm0GhgMeZv'
    'RI79Gl5PvHmVxY/7m+vaSg2ZU9eTWKRwmW7xRy4Xh869kUNJQYw56vjgIw9CEdO5cM0/IQI/CbiM+FyMqJ38neNnPCaix2Paz3/g'
    'utTA5QlY5IFnQkLsV8lfYgTxH1QAMIpHNVIMQUYir7+1fucDgzFleXwfjA3JL+/B2y9hT7SfFJcHxGfe5RvthNML1igiNvuB9k9t'
    '/FEaq3Eiq/lUNoEv1/Px+aJ++V0GdNemi6dwPPGHf0Sj7KYWYB7tDOto52hH8/FOgbJv+s2fsH5fftfWGO2M5eukDtewwg6ylf+h'
    '/rCXK3QO+/CO7O6RecTfYaQDVwW26ca1YEYdTC714d3+WVPG8H+BQnCG5yZ6HfWQjiyfhxgCoOJE3ODxYv5/4t6kO24kWRfc61dA'
    'LFUFIAaDg4ZUBkXpaCzpXk0tMiurLpOVRESAJJIxZQDBISm+U6t3etGLPu/06e5F9+Yt3qJ/Vv2Sts/MfAIQJJWZdd+tc1MMwCe4'
    'm5ubmZt9Rk89ncGUsQmRhjYhUm36nbw79uRd2GFzbfdfJOYeduqCLj9l9n/oZdXQeqKxyGPDde2pQme+FYuHTizWKU184awKdm0v'
    'VKH6Mmi8Z57v+1Qt0NaeauYnMqZ34Ezavgd3O1MEP2ZTxL8OJehTr14F/IDvgjlhEZz76djxsAVtUj9VwCsx6NSOAn934PZoBOVd'
    'ebLH4GqPHj7Kvn3YYk3flgUcnzn2wGfksQti987POxe2/X05S6kbTDumW14lC5XK/br22LeUZok7Pfwbz7EBiPZ3HfdQ3Xco6AlB'
    'Xj3PLTiQNejjnQoZKJ1O9uAyIhnTGRCqjMI53IbpnzG8NcamPdc+6V+2d8prtETVHia0F8y2sEso0KL6syt/sLJm9w30x31HCfjQ'
    'LfOlyz78KA/EA7CvQiM3C/pyoPl8rHqYzM9Dxsf/mFurjfohwiaqs3UjMTMh2UXhx3Pw8bMNJ1P7JTZsiavc2jHv0G4Qfkln82Nx'
    '4oEOtdDhucLV4QmbDoCcMhYA4lDkiZeWHyzZ7MZIdUyKSxoVI9yjLv3zf/1vSwar0/qKT6aZSXjZiZ4DmrWcHB4aSUj9/MDD5JNP'
    'aWrut+HosRWdu6l0slp1IcRiQAu3DJqJTfp3lmn9M4jahEa4zlYSvkGx9rBv6sulArkM1RPKmxmIzzl67CAQ7LcezsX1dZ9h9Hxm'
    'sbEhXGJ9fVEEQyMv2KiYi/yd3ztznf9Ltvj6RmVzf9OwuWVr82w3bFzP8FPXR+pKU9IgG3ztMpU5CelPXihZK1nSyPhxGOHRcxpt'
    'T/0c19d8kyDbGa6LM+k8rC2SxwmYVu6DiysP6Dke0MN+0Hcb9t1VnW0s3uP+rF+hBLJymQ1yxozwtR82WMLzCu71vUlZTkYrw+yg'
    'TLqcZFREgbwUX38fLIKvfUjW7LPDhuZKH3u+Hk1q0ZFhB6QsHBlGAGVwJbq3cKvyxSuCIxaSATudHKW5I4SXGHttzHiini/ZyBBH'
    'uIYBpRw5Sjm6IaU0q6xN1DIvjBLwh5y/UeX/o0A1P6ro5tidhrvwTv0axblzf2FYzsKgqUYCO0qLD0iAxFd4gS5tEiBBxcn7uOpR'
    '6VNIayYB4mzN6gaJo5HknZMqRbFWSafTtqMwWjo+cARvK6CqcXjIEG2Nb0pb3OON2ctHDICrNBOPOyvGWMRHVizjY2LNW8WH3ip+'
    'K2fEvd/OgnZXAG+13kb8OF8uwBhobhd8OYW5k+VNY2tSUyGFES5z6ywMP6T7iWVXrvjVo3twhWTi7gy84Qd3B4F5wL3xwIli9n6H'
    '3RJ/0HGEf+g04l/71pdaLwW4Lc6Ca+N2iMCG53/Js9PYj9Ph6z+2AcPvI75zcUIlJFaS/zq/TCR/l3l1rN7tHEuEm+ZnZTnLe3Oq'
    'LLZkUtVGLYG3vhO3/iCOSOet5Oqy1OJ0UuQYKa5JJrM4xOucZfDW0aFL3/mYttWbnffIGilBSXBs4Ka8b8XP4nzc35lMhr105h7w'
    'lv6Ujk3kEUdWYMRYv/fZeE5DFgkx4fLv9LGULmfnuBGe0NQgMzMxAHzf2zIbxds7Hz+/akf/tv3xQ6fgZAD5wTnckxKTsZAh6iWl'
    '/W3OiP19OhuzSBh5PyPJjbpJzCAtyrhFX4BoRmb083JSIDmP4TezyWlBjP+f//g/InDa7VSyrzNWIOAw0gOkJQWeFGdGvhut2P8j'
    'MRidnvuP7q56KJyT0SgvY7kzGOfF0bNxPqJJgP/UZBt2QrlWb/5ePqBtQZe05sFa4jVQHOUHZczY5vpI/ecRu/Yyn5XncZhRGq6e'
    'NFHxT8VkXB8ZLhU+EcHQUIRx43rGXFeKFzn8JPA3A2eRJCjD54wt0qiOveKufluc0xMRNzjzArWOmGuE4AWjNRQbjBufzFNZZBkx'
    'BPxsaU+3q9Nkgou8Wblqps2UeMsymcZJdd60f+7RtVvt8UZra3r0hmd7rNCYCmM41GapRCqE5MbH6dLRvAc2StJPYaMb1DO/qy72'
    'LtkF54lwyS4UPJL4tZ6xCE+T7WHrtAp0xJD1q3yPZfHsIRSes5kJViOgZbSjrHPYkWwD8x6jkk0n2UjdBhF+XABodCRp1NU0i+QC'
    'ICscQtbvZ2Gk4KZ89jiziQ5sGgMvPiEMTYhS5NkRn5JUrFIa9aCqLf4+UCclDlSA7IqOpCJpw3NaNgP4j6xwMImhS8YR9TEVTM9F'
    'hhRZZTY89+JAETbBBjBkiMflG9/g+GdLkbPzJodPZANJJK++j5rIXb0dtS7rSk0JLeCdk7KrKZrcxX88ldhP5mICEeKYKzy1AQc5'
    'rdoZfDbpsXMihL/xMgy7DZEJkjQN4Oi8IC0T1kirEq4IZ8nkj2wLjQpGktCJIMPJ0hjo9U2hQLTK9Hgwn7HYjhzoFt41n9kFJ7Lm'
    'PaGPvU3hQ5zKk9ekwcTU8NuBg0nOjdezZ0Xlyx2zMlLe91k7bg5svQi6wfol9dRmLneQWY18ebk59qMavonwRURUeAM9xECPETMs'
    'MdBiWW4anD+0Qxma3qnbClF/U2/utcClceU5rheRz2MpjGnhc6YLIozILqolB4kTUqhBs6vqS6RCjJwA3GvLCiBWaZUDDaJQrH4a'
    'cgpXltHk743tzhKuk4TTUZpPsYeSL1vBPAYfNMZ/JBH6cCxYmQYVV/eWDcGWmJuxu+ZgL0eu5S5yx+LjonU5xnxzod8IOGQYsx2C'
    '5vspAqLHAuuPG9U1A71cwSE1aQOkLG5f7z2yRdkUd2lTMOUMOcwHCceOYHZT5sn9o3woCQK7UXqanot5YKq5kMRnom1EMGRGljzU'
    'AiSmDvhTyTIhPMFPaAZP+A8koE4bJlxz2EHRY8qfdqqs83Z1uplYJffZsYNrLdPxBr3CdEzhvHbMJtspzaINemIExq1ohSt8eiu3'
    'icV0lrk8t5/eWvlYz7RpUvcC+kDDDILZtWVvJFP1AqKRTNV4jIQ21d7EzK3O0GfqsY7Glk2JShDm1FLTtEpNU8/LqSgzDnYGlL0H'
    'K4Ws0yQPSrQKEKWggz1IpLj0TufbyqC692ZrHDViZgResRv3cDW8hv88QpLhb9bYx3X9G/oRvNtLFobXYIQrDZE16tGeMUPksVVN'
    'yAM4v6DA3citJj7pVgNY8iAF5pRMfdUx2Y+C0IkfpOErcEoJ+J46pOUHazZ8x4L39icFvOd5TR9p+SMT1hMWLRBnpkUfhN1hK0z5'
    'NmFmA4S4YXEvm/IFhn0lDYXRLA0sLln03Qw7R5RXST9OrXY6HXqOXZZxmOX48GV+cAB3uyxJbG4XIlA/Fx6mGt/knG8FnvgJFpsY'
    'UrbyLYfXFAE+8QWnUOHwwIo9iiNnakEzfpJacR7HtQPoTV3Il4GtfNfnKPp9l8FpgGC1F+B8ItelpXOsurj0+ZM4rk/1ZJHAKXvT'
    'gg8aZETdWeQ93bxGdafzWO5yByaJXBVjZT7G70JuZz3MA7i9QyJ9O1hebsOUAFwSxv10nJbHyQUnRAq7xuMSXwmbfpcD9DF1k8J4'
    '3tNfYFbM1uhnbjByuiLqy7YPJGEQwdTAGLBE0OUCH/EnF+BQDZlSFj5ElcwHnhiLH96S0HQEKyKrcGN5wZum2uImjYAosC/s5Eiu'
    'cOHpseZp7BbqkHEDQzBkTtw+nAD7ZzjpH3OEpugeFrFTYogw+JhnX+w24Rdvk7AB8LRAo2CS689nsRxgdmKUCxdYjgJqRZf+safR'
    'pdOzrCrYNZG9Ei0elTmSH5BYDsI7hXEfn7vCj3PBEvUCTgXgZ6ap5zyxvxN8w3vqLf5VqwUtstebnMVELjUC96KFWeT0fKpgDyXy'
    'UsMEc6oR+993pOjTp/QnS2bLggR7g/3gooqJoTwUhuJZPrwNIkcYTeGAKqNIy+4XK6jrrqjT/q+hwkYq4sWGQLdyMJykbHew2Y5t'
    'qC0JaY4YxHaAtUbhYZaeSLyugJgBr3U6L0PMJlrd17ig/erdyHIU15ItZN1PSrFQEuWSeC09Z6NpeS7I+F4ktMJsFn3qf1xRuSTo'
    'pjghlWcIyJLvOXu2JDER0y7kYLHkSjyNK/uGbfR+4XNX2ChKnOO2Xwm4kcQQ9M9jnDjsR2dP3JTRDVMgGqLEMmA7E2mGB9uXY50H'
    '05fYWZO33AZpbYtJKDU4c3xBnNeMOxa9wTgzTpBtBFcYYqwC2lxe6ltrKOosPkluuEHkE8/5j0W7AfTYuBsUgVUdNmq74gomOctG'
    'pGVsq4dCoFbK0ev0SmP9vG1wiwJQJP1qvnrc1aJ7zmFh+LSDOUzUEL2/g4ssvlmULE5Mwbu7dy5kPj+kI4QscnRscrm3ZxZK7ruI'
    'eJdqJTm8NrlcMlD70i4D0M7Hw6woeA/K93LQ1L51CteNZYSNhu+omX4dL1FzZ6BMFIIQ6Ft9xehrN2+ReBUlwo8ZfcEBoYb1qnDF'
    'QQAO1lVM+c8sONs4y4DsjxxsejB6BL3gbDhUgCs6zraz0rqKFMzXK0pKzgosaiT+FFmCrhTfBaUN97zoanhS5JXwajbCUJMMTWfA'
    'NuCs455h7etroh0KfZsDOrBL+Ow9yNeWqYjVv8J6Uqdyn0BqlOGbfGo0UaEIX+qocnO7/KQzem36sPv9uiWtCLr3jDWFMU0JSrmm'
    'SmMjZNeDV8s4sl0rmr5mbKOacRtAQq3afDhTplgVLfo0jFVVs2XOUn8/m5aerTIwVJokTJ69UsdS+CYvHY+MhldOAAyDaaraJUNz'
    'X7NJ2DZ9bD/VIxdcLKZlfDC+0eF85SJHB1jazetJdJYJPQu35ogXX3YdG/BGSa36IdYibc4dzbjBvI1Vn3J4g9oWn0WyocYdHCoW'
    'gtVdiYTpv/kebMp5wuvOIYaupjAsM+RewegI3LURK53iImPAWA16yzOlDG2PAf4sZUpeL7nJiPlV5ToH06hWMaFc3JAbPCZzHWIA'
    'nW/Hjdcn6lvFpGJusJKA5ERJK0MlzfsUUhPMbYCH+MPKo1UbuWSRaMZS1g3FEqkp6lhHFHtjlffyvA7YRZlWPumwd+fgbFN+8V3/'
    '4HxT72RXo88MNkcaEh12ZTe4OjgUwPjTbHBo5T913pnSIk9moECqq+qXSrAxjJI2hwOHt/N9Aw1xBPtHJ3rlEtdIuDLDcCPjbDbm'
    'ayBN9S4QECigVJmb5PEmRUJeKmINy9KSCd62wnHOqC0fgCTsjPOtbyfRESn1VICJAuc8EQlfF4oRVRBt2OMK5jjk8wHZenym5O3o'
    'nQx4UD8/ZWqdn4Db09Y3HdKuki9kfk50rRmBxmCTEWQQ8IPXOUTlF+VsuLxGDa0c0HGecbz3LPt5TtKmYbcjakev8kTJVD8Hvjdi'
    'MotiUkb0Gh7WY5Oe2M/mo0Of0rkGvcNk2DEcJgBWrQZtWsv9lTCpmpOFhKwAbROZve2Wr3nSQhJMc0acg3ieRsDZGBqi2+RF9/1s'
    'efoU1Ej5ghgHOF1o51YtAM3dOqj9m+8dvLC0xEFx8Ye1ZW/SdtxL6oqy3DDZM0g/5mm0C0OtuQ/L/dhYMC1Tz8EKI6wLU4lIWujF'
    '9/gqYv2Rn09SXEptZczsrkFzjbkvj3NZKyO17t4ZbB/aVceSxRX5UrhdMfkL1D6NUc7Lrv1Tl+xNOjxgV1c/J7ZZ+IEuhNvFI9GE'
    'sWoHEH65ZsoehwqgZYo2ZCY5bEejJMgVZw21o0SCZ4yluG74NSWOwvzL2vfi1v26p7WW/b5xDbRx3zX9+tmHyp0DJ34Nr2j4GEnX'
    '6P9pyWdTD+fhmdkCB+mY03JjO5MoPLbHqfFLEL4h14ImL6ok5GQNxwuusye56UQSe0RHwBocSzqxcXDiH6U43ofnrDng1v90Yk9h'
    'ASYEhz+clJKPxDs37CHgcGXVivZBaAlgOYByTdeiJ5isWtraFPb/dF3TNqVrkoyWamBm5dm6Plt2z/xL4mPrH6CCEQPVHxc3pfvD'
    'qbn4sVkhOcE8jL9rtbsTkS1r1ybFNB3z58jHglj8nmjUJYyZQJlIEWqI4pK13XR+7CelNPaQ2RSzw4kvDqdMu/an/orD+X4aPUIo'
    '6QMXEBlY9pBWlTeD1ifi2PAvPOwdBQbYdhcRnO7cNokbwC3m6fXblBGdargs1Pe1K5WRbUW2hkjeMJ7ptNAOsUVSDnSkh87DsQKo'
    'IgDCC26v1Th2jc8PTkXdeypeqggb8Scw0nMQXu4RHL0xt+JK/scuSKYJqEdQP+EketfjGoZUCnECw3x79Fsa+i0b6HfTYaLpaNrB'
    'PSxglLlPgfLoPPA6Dl6t2ftQGLDfiwHCXsqoxADJeJiesdFShZ9iMjzJPqqMVRMd2BZwBnPvGhsEwrgVL2mznKaQilGahWJ5BLH4'
    'vL4PWS721J0OB2bG68n1grJ1xng2k8zIAdfUKOY+qxIqKZpcw5qyK2UzMDNFzgrmUhI7hymGgGJJGRmXAFwAScVQGUPI+bf7Ngig'
    '8G88PLPutBO9FnEmRqJLBBkl3qDZN2smGI5pjwVuHBIkTfLxazNbcBZMWDAlhRO7aRHjP8rO0kMW/o/oi85J3PV9TjyC8HTRUeGc'
    'Fw2djKxP1WNczjoLl174MhoDqgWCUKfTMSs58r0UROS5XUlhwKKaOvl4VOSpxoc1hu77gfgI9SOHUD+CoXrZL8IAq3TkJ0aauOQb'
    'jwdeNj0JI7IYP7x/FeeH/2aMKof+ysgsUofYXFfnI+ayieb5MumuDA1s4Y7UIcSmTd4Q0qRzidDfZ4nzdpBz0/iBx2n0R4/1E4tH'
    'Uf939f1mZICnJTkxOIK/acwW8faFZETtewlMC4sLbZKP13KGExFr2jsk/87geZhC5QNdN+0zpmwFwZaRIMPTfMoCEu7lJMvG2IA8'
    'iygIc3DHS20T2EJ3R8qHfdkftV+N2ciyEEYYhMkowrsf4hrwI4PvVXAfk70qvxyBrdEu8rjZrYrDhNJMwqlXWQU02JZ2Zwpquxly'
    '52CYlu8R3ACgtN6enCWTKY0iFQjjEWOsGMOrvOolfBKRViO1oNuYNwsrpa5SjxaOK+3uBeArTDh0frI2gwQ+Vkybk+Kwy1ZB5oQy'
    'Tnoa7koqwFLHxGxgJOJGeWw8vDznl7ql7ctzQS/13EKq0K1CgEkTBC38vRSBVpV8A2wOylHKFZGYNnjN/SU4j5epQd+3xqbP1tU0'
    '+HLW/YL2+AxSVFJzWjEuGbUS4rtiI+kvFyHbGSxV4dmKcWfL/QStk6946c9a2Z+86aCPpkq0m0vgCfey8jSD1/TpJJiKqQWp3c33'
    'BIhXf/60x7j79dxmU5fUbCppSFL21JnJbd8MN9w/yy/fLcZAcXz5Qs0+QaVllOWfj512R89X6PlCFx6rlFLBu5GWxl89ODPRHwMr'
    'QePYOTJfUPw8K2MfAdvVlybvyr9V2LqR81By35+Y0tQVyVIj56oUu4nxyyympxFaZlA0rya3KplwV8xL2zW99HLxugJNtZebawc0'
    'WPNUMynVF/qqTdjHWD7FKV0skwo9sh/ptJIZb+KoZ+IG+9hQjkIVL3Td6puVlLj5WsPmfDWtm/OXscnpu+IJn6f2EKffSEiWrdwL'
    'nLf6jcnl+9Z7axK6bfFTyeKD+2IdA7oMkZ9Japky7zzVM52+WlTdc1utAvrJIjjad1IRi+D8SFlpXQQf+DK4eoSwElRNOnVhxXsn'
    'kg98mVy9GETAlWOcfgyRyBZIwjXcZ4W4w/E/syTGZ1E6GMhQPKdr3LOQsleWSAw0HtIseOpfEcUssbAh0WSkQHzvYcGRFHmZRINZ'
    'fgBdk+2LYU5jyRZ3S4GiWVeQGBLr62uvKLjsABLI6cC6F/Qm1CYfP9A3cIEh7kQZfJzyfid6H8j4MCrDpqyBKoEeaxQMEXR6JEmR'
    'ZM+W5k70zPohqVk/mAHwDqcj3OJseUC4P00l/kBzFkOZoN0mX9PHFGXhPZ1VDT01Afl92ZGuQUV30J6+lBNeZZXXawTOaHO25vGS'
    'tiDyuJ9n675bLL1ev9JNVuhb716uVjKkY2s9gQobABiS+HwWZMw6W5cSy16J86CN87V2iHiIEkEb5+tti7phSgRZheBlUrR5qeFr'
    'yEuDu0LkAKMxUsWzdUXURTawmIGEzs2jWZAW7GxdVfPzdVbItdDgjEElB+cOVdL5OPDSC4OeY93mHQwlqeuFKMi5feXGQOpZPKS5'
    'icidEym45ybOQyqrY02ORBi+2P67C+w8wYYefYlax8HAmHzPrA8k+xrJyjF/165fbo9nBIJJ8K7n3rkEsbeHRTXEzouS+iUzIWO+'
    'ButSO0GVdb+cTluD8F3fqOD3quox4Zx6Q8Vg9b7bWNlSk42CuAa8N5Exi7eThJkBmcTT5NiqATtzDTZ/eNWK0VYdSHDC7jEvE+IR'
    'yokEb9vF0lQ2GjIt6gpPeDsSGNPwNYeMCaZOYC7ArEKOXpa/egIjzA7rQ9+hm13za+DECuBqIIrZkZpR/twuMYs3muOYY/w7znUc'
    '8kOcQlu6KXjy7YaQc5ArkUhtKN8X9TXZdY5kCvfW+K96Io3XkDUODqTxidc4uwFq66JoiTyKpLrq+GfesqYlkiin3L20uQBSTdNX'
    '5qy525yuXDUbGIu3t+GFuIzV86ICoTVPo61gs7Ujjpf0985mpc4JyzeiNx4c7M57ewalHMPGk5QNNycs9IgKqeUUttwrd15TVk64'
    'KrsvrVe75pTluNDADto93jOZSFy519I7hCEa5yprFgeb+phlJBqW/1hGXystgw1KG5CnpJaZz1MChbJupAOGRX/yScl87zNDq6zk'
    'Pbe/oOPxMjzv9M06/CTL8AxPZH5ztwxU7tyVO5dy567c1y3DIadDesby/3P+7/r6GrImu4LskUbFnsBQcEEzmlfnGW+xevc25W04'
    '3cHbn6orWn0bLqz39jJA5lp8Gl4EA7+th6t3NASqZThTr3Wi5SuSNts6RvTlGw+AqPaARjUCqJprxiwORq0zczc63rSLYZ+f8/MK'
    '4QViCVWxGVqsPdFkQVLzIVvb4eKB+2JJfWRk5SP8hxjJjBPNAUOBxGDxt5ixn/Z4zvgVcTokGbxwKdjYGj4Z650mKwUuYS2/nGXF'
    'fFjKECDuJixlG+80JCmGzItobVEXqFvoZGbsnkmx3z/1sm8JP/UyI9yNjOVWcrR76RHknSnpWYQlaQ4fBuH5UGSHzSfzrkmKYNhZ'
    'IHmc2TwLTW/P/aQJYYmeX79Xrd/z6ntHriek2+kCCyJFSH1co7WFGRjwiSGDurAXpVx5OaBuKk2UyJnraRr1l1jm3avz4NV5nUNW'
    'WJ8/hEbGtyuLndM/eW+PHYAPmQfuTtvRz/QQUZo/mxc/7YWMJ5fMP/kU3Mv8+Jl/9Pw3+uPnuu1Cg9T6p47q7kbu58+wf4hXfZ8j'
    'RmlIqSkiP3tcJHEL5DJNXda3sVvGu9F9OOwv29VgacKYI0YmpVTVkKv2E98wqxIDbTpRQNVXm3vBwsD9UFKlWdeim+QVs2tazuAc'
    'x2THfxZWsLKoIiTfCX5P5TlzxvtgikST0s5jbUR/O6IwoaIszDVKbr4h67a0RqtbYeKy/yRWZs3lizBXT2yaBO7rRufet9/S5Eo7'
    'd6P1zje1+xvJcbbxAMv0LUL4Yin9x8hhQfq9Oksz3F3vamyFsy7rUzOqy8DGLxKrkWtFSEwEsR9sLKb33p15/4oUYc4WRoeGdQBY'
    'eCSSimhNWXxIbeLJuffk3GRK9BT9OfR8blPsV2YVarYAVkAr5iz0GBi00OGmvWI2dpeuhrl5XtLqZxn483WiT+pLy142R3o/nTLp'
    'Hh7Cs4z9qjnEgQ1CR0hZqInhuXirYOQVDu/t3GJXljGnsJLMpy74yHogW/fm242hU2w3nwFO3ckWAVaOc7ibsZKIizTcN4nJp+pZ'
    't2td6/YS36HSTyUx+fpWqk4Huzif9sTpgGML3KptRd6KbUXnvp9+CSPMNJux8/e4n3XGAFsgUXPO++fRWhgKzvA/p9UTufQNOXDz'
    'Q5kVaptt4vMZtZdJYPu6ifGdUjf4QWt7L6mZovSLoHStyzchW1moxVnblEIBjReZt3eNP8YWz0znMCtj68QSsVlqK2LzkLH6YKtj'
    'wJtsb9qK2FAUW0uQvgyOCBMuYDa5ZvMDKXbYyxVXmeLjCipiPJ/XeB5jWrUiO3UH1KuMX59d0DTAvkXVule1VolO9onX0T7aDCwr'
    'WP5hpTk3/uuIjktildD4h6odvJkEK5/aCLQh+J4GtpOtYJFEHLhPqTq0V0KNbhRiWHVv3QJuVfiIzVaD7AA263oQcnOkg5r5NbSz'
    'aEUSil310WIYm9KlpzZukC3jl2grQlb3w/es46K4j4OCTLx3Y4QtEOWGQzOfA0bW9Z3AebSA0+UXvxZjZWy91BIXgOFC2m85VF9B'
    'XpbJSequAeJvo0EtWOZRx1/oUbBiDP1Wa9tO4RXNN0bTeFc8/Ps46Pp4YdcLAnJ9vu/I5UBmjynlw5xDFTw/KXtjwSEn6gIO91a+'
    'tUnPSGWUaDjW6eAlpd72m1GzE35wfxH6sonJYP1REIBT+O7kgWwZ2NoeVG1tKIEOB8bpfrGyM76hMWa8wBLjHA/GYoTpyZ+wwBym'
    '5tpCTWeHPfMgMJz514JGGTV3gkZVDctOztjBOmUH6sNe59Rg5WAafSCLM3iunGvhIyl8tKjweYDAQX081nt9agF/1s84M8mGACvX'
    '62gClZ8i9w9rRE+jFYj7nJkBPTCWF4vdfNfuKsB6SyNqqHTOlSqXyJhpdc5NE62uv3uJ6hik85As11NBoLD4KKkYnkYwstBTMUBu'
    'YUDyuyeyp7zvbYoWbt73qtizt3lOkiBStYauxzk2GhD1XhL7ZfBOvtkEEdPHPVpbm55J1N+oB68tmGcADxt99/ldFH/68GdxKM9F'
    'jpX8HbOMtuM5sCXhAGkyRvXPk86tFOCYkbcT08Fb1IkP8mEABzef4YihTjp9KlRmclFAv6WkRdX0rxNHhypNSpNGKJEcItDPZkMN'
    'Sz9Ncy7fGWT9ycAW1a0Piw5ejlOaxnQoUfFEiozHMz4K32ocvHldVCRCmkCieHuVNz5FC0nQX5AMcb3tOyTQUGidE9/npKHQkRTa'
    'rET3Ezeew4SlM/hqyAatuEXyzklaAEmyL1cWyNSIH0cmBOUoaKrkLFuQHl/QFsSNR2tjYBLj4DIEAUgy5TQvnKVmTVIfhv5g3AwV'
    'p4a49Esio9gr3AFdeX75w+lRaployEDvqVfTmWOgjBWgKbnPcEnyGEowRDHTkOCjSprp6v0pEUhXCz6lby0nGByorcUkvTodH7bA'
    'LBpe/TTNDpHQp/OIc+/ZjI/IgjLmjXDBdDzLTibHHh0TNSaiPlY2RaHzw9Ekbl80k7uQcmUfOWl8ofjix6yKuCft0X83nXy3QLqz'
    '/MbW3M5/sSH/LR4JMC+IYQBkVrVbhnrB/aWGA0oxBbIQerq0cLfa1IvJnKQZQKQx6peEBqJeq3nuaPdzsx+wqy0k0X/GJDYgIV1w'
    '85fJ4mn8+u+tMvMxY1czxEXGUMiLkHktNERefMhOzb4CIh19XKogDwZ51QBXTGb5YVfpA31obWJz43TabUItFtpnQ6c0rDfkqj0k'
    'XmOcTZHLGOiKyUxugm1MAIp5LzU20BOsfP2TNhgdPLzyquVqNc6nE/tPaIsJEgbNzGcQZ+x3r0ylHTU8NJed9q5ApkVQ0XFs4hkN'
    'ytfkqljVTn+zlFW95xcdX193Qj+UBhBEudcR7BXPuhIcGkjV0ubUUWBT4Rt2ILvfFqTlu9GxnDcxm3itcVGKTs/b0UMOkvN66rvE'
    'MNVUWE8lVUzX+K6wn8tU3F2G6s1C7agjgMDkmtVgEJa2FawPkHDcgI5TV2O5mzKpei+nZ/uICpu6UhhQ/1wLHdlC3B4ffVz0VGrK'
    '8cdPjuQJ3CXA2fgZMmOhJffqe62A7FhaGAPGA5cmS/7ixFiCH92S7jFJb1yPPBm29algmvGb2tzr5+BTokf6OZdJg+GDGZVYN8II'
    '4KtpD9tPX256HMEYK6p70cjfAeEKyeou1yE8jbIOGApNRbCxZplENa3+UCzfWW0Dm97Y/OXkCFQpMaQj1zXxnZE4ddwOUt8xy+4w'
    'o3L5vnokw07gcgf5UCC9AHgAJS42UNAFG245YkYirZ3zQuIpJ2I/urjebhSYeew1rxyuBrHhSmzxKjp3cMnKNrOx4aQytXKmCJDt'
    'LbHx6Xt/xp7KwgCRSE8xO806bwJCzaUYctk2bmhHi9Hc14ol7KoVIIJnHZwX1yG203TQtH2fH+efs4Miltba2kHiLgV8ns/XCjL6'
    'pGKAUhqjnfTqhCb6XV6U2ZjqtfLxdF6SxBbrVULAZ+18ehQawLNT2wtb7g3nM9uwLyxcVek4O4cRjOplxrxM80Vs7BPRZ3rItOU+'
    'NutQeTHvvCJtbZpxft6sM8XpNy5fZgfpfChIJK5/g5fog8z4DSGTR0vy4Ai6/r9n5zdo9oomd9LewoF58Flu4qsNe8ZUh9s3ECGI'
    'JqMiBjEOw1E2nGazYpEAVE6+B5xkHKiZsPUD04x0kudQpmgwLxje7DOdRkascJdl9ImCfvZX+Pl0cCQthEozRf/GRRG/2oyT5rFt'
    'wfCzUNy/1cn1CmSHi69CV/4dnF65nd/B8bUeGdzz8KfUj9DlSrefWv8EMXf1rvgEB2W4yG9XTGS9K4YvbhO9xcP/hOFjwC+Qwr1I'
    'QkV3XRTdjTXjDuFc7cbHUW9yyrFJ81IgUnKH0AMxdJr3iXRZxfKW+2e+JEXS+E8kzmNYawuXWWI8HjbOzs88Ow8b50UCRx42zsjP'
    'PCMPkyYc2jO5A0cTp93IuiKTmKZ3ULJhMDtTSdnxmq2xKh148k8Z+Kb7AJnf65b3IA/b0Zvgodp0VqL7fAsYdPW9tUy+4b9UH4DK'
    'ZrFNzml8MSeE8DKLlmkvweUVVFAxQtNpb8KubQ++OKY8wjcode633WwCJLjtXiIHatyzYOf4KH5wpA9UflDxGV8i4ngc0jmJl06R'
    'UCl6i9vaMA5MjqCDwkEiHY+tAT+OyG1q8z7U4eJN0ADMWSFUvFb5lVjxgZvvYQD7Pu04kPgtD23kfqWUg4ffsjoMlXK48JWzSKMy'
    'NDYOcqXn/lw5nEDIKP9+wpMigiLT00UkTs+cae4SVx9IvXY0mRQmiryat23iXXVBaIW7XawX9SRzSlOHIstXdAEpZXDwQvRB0ZOb'
    'euRaHJt7g5QE3lf6n9Z1oxIwyxLJkTgLPCQkjvJpoW4OA5yV/00la3J6wbnQGqcliklQYlgqlteTViWfAT/lydKTt7IeDaMSbMnK'
    'wML8VT5oNcRs3xxAEhFtEu5y6nOplHUn078EJ1zd8v5jZLeOBltL7+9cpJKJK+2cX0bv7lxM5ScR8OIk8m9evX+1vUv7ducoG2V7'
    'C1LjPWjKKv9N9ODK9Ko1bZS/13gzBG4kwRe7G3lZE7PmcBVRkE3ivfxrSx0+HMdEDJi32YDI0MtMwBYAbGBRQ2wYYLRsxh4JC0tJ'
    'hmJnz0F+cJAxbtlQZAi5UtR9zfCJOIL5pDVoC+LFVuQlp4IVrBLn4NpZjLHdBCBr4S+tHU42DH20QXxViFLIzapP1lwJIrM33vHn'
    'd6LvCkHAQG4yEvHGc94UYps9mpwy2O1kcly0mrjaaIJUYSH3woFZ12c0M2BVpxEFQYPzoC2u3dxbAWAALptazSWpSQ+fpvKHpR9D'
    'ZFaGCpip+CEDUYCRr2AkQIWKq0/WETjADo8Ic7vLqRJpqcx9iE/rpGgvl3yrUWSl4Iwzh/UPpRBOlv0UF/Vik33uOU44LCQPnOH3'
    'y8PCdmjLGzhglnDozSdZoRfpFOIhrYou2dtBI6Lp+KpPZ5xeb0DjUhKWgSaXx+7ruVwdXRd5KyXrGoPmNvTO6dcX90+c2esdhaX/'
    '8rUmUedndhhUvLGX4fE1E+/P+bF+on7J8vA4mPNgS16JFasml+ZeAX6455+s3sTSdjY9otgNUIttsgSBpAHH7mq+av/YzBlbGG4V'
    'E2dGPrxq/tlLyRtnyQagivPScnnoloBfNc7HtXuszdgCTpNvi1Ne9DIt1YGvwl4X7UFXbNAbqm/fCqcbwDV4h6OoHrATtX2Wi1eN'
    'JAz23Jt9k4AtfIaEcE7/t885OP2hOEPKI/Fu6/I4xHeAxtJmrk8KkW2c9SLXpL1loWq+3ZNzpKkcpzc+JrNVJUGhZ1dh6XBqyhms'
    '+mniVBt2YzXZzbthOHIDMwtHgvnKOunQWJUEEG9YLrssyqknthnoWZzMiiJDwsktZzrVQ6+Z3qWc5YceFjq/uJ4BXvs5ZroXDqYW'
    '4eyMagBMwbnerQL4RiLoMy2cM8I7lKaW0AF/Tjeamvs4BMcyNhK7yeZthcHSf8/3kivu59riN9M113+qXgUDMr7e/qQGVuXqWOmw'
    'paEWIb0WPsEiJKyrqidit7pGs7y0K1aX+6nZsRWvsRA3WT7oZFcKJvj+qmDihANfOHd8JtQ8qoILnnUwFWL7xGwYIrHKNpc5gZ7t'
    '8wt+WpxtOj1byp175f5my6kjlq9mN0oRVR45MHAjpiHQk4MkZg3Xe3EefGxH/KxCnjfgyk77J6Z2358Vr6K7IAp8aNucsIgdaLmw'
    'uTlQRDdJWu2BuknO6kHgwg0WyqgJ8L9iVPUPshYGkbIJXd9D7+XsMs4VleTIFsJMSDae4TYk94GwFSpQc7WzJei27R/XINbGwSMw'
    'CS5lMibTHT7T4FpDVak4/WPyWboxGxDvp+Z1t8lDOPHsXPQU6dxjT5c3pPy0I6RadVfXgVZo2/hu09BKc9KFiigSGJsHuv/VM+dX'
    'qeDB6V8Tm6+Tlhu3op7nuok2DZe6TokPuAxvZ9nLWBvhwhyxM+jUnOtk79vFrZwPC8m9gdZ9Mne+SYoQP+A4CNeRzohO++dsJS1L'
    'UjWzgWOU9sBvjvPgLBUDn+RuW+sPTvZfMsFxDwsZecAAxRsTVyG5l4ouu6u0JBkvNCi+RK1uALMclSvCwU2uCK9wN7+S5c+nYPiy'
    'V647HoREb1D+9CiTcu7WrnbXdSPtlKb0I+Am36f9NmyFK7QZDonlFP0Z0uKQ5DUFaLBNREPlcAZsAklGwMlIghszEGUfAOM8sASQ'
    'vf/83/7vZWkl+mUyGRUdLwdFX+/7UAWSifwaZWWqYpoeXSuQXwbZsEz/ao8p9+xvm43Hkcekr7lha4u3bv1eTb1ya7dobqcfb8C3'
    'YJiOAAjBp5A6qmRn03jFDBB+u+4rnwpoARxy19bWH8CzUqzo90LbOGNgxfxfc7t3Fx2aizvvxGY8rZj/a673moqCno836mZyuIlN'
    '4fZykqlQFskF52r0kh0UxF1XsjIY1gpoUEn35NA3xGph7nykIDyw8aZTTHMA/MCxDXwYajdnqBKmWCdu8E6YHC19N97kNkptzB6E'
    'ofKXXNUFYxTZG/NFHNq1eGVzk+k1u/EGHXghbkx8UBx34MJ8kM2ABZMBMdLKRwfV0+CAjw6Ro4rv8/LIOIm2KneuVRFNJAojRCiH'
    'x8Onzh1UhIJ2dABH1MDRkcOC2lAQDnxhHSNa/aHzSz69s5p3gLFJA4SPBQ1mPqbH8UHSQaKEOB8hK8RfME9Jh10S42w2E/hInDJL'
    '7JcI8ci5JZ6gdDdagqg6mxHnKAoaj4gT3D2I7DVNWXygYot1SG5gvtRLTSpf6KGEtdntdDqie08ZLgBeuU9liXBe7+4le3KfxGH0'
    'Vy2MXbxFDgt2BXSeDxa5IRxn5wJdsMAFYZyeWNF5QZ7ChlDnQVOQ81XX+myHM1IcJwhqhKhmkA65yC8sGIdcyHMiS4OKeAIvuwHk'
    '8RO40g2APpvNphaftlfEUoRZIBc584RKacZcmnLNJxYecb3zoHlwBiVPCi5LvbsCZWRQ9VDiMc0PxxIPGFKPHtlI4rFzGXKJUI0J'
    'jQHvQg9nz39UjJEa2rs9mpAOMETCxzGD1A5zhlZOJQQpG3CUbhpkRulPRrRMAJDmy17JvkerxplR9Hr+CGnM6QCfFomE7xqpoB7C'
    'G7q2NucJqoIhS2woy64NW2i3fwYwMFwxwEvtKR2tJj4UaR9d1K0KfaN8sJK6GOc0HzEdGpAfkvqOiDNIyL70cON7dkHLvw93iklZ'
    '8o3QG6Ik3HphiopW0pkcHNAmtNfycFVtcnhlBwbrHhr3fR8VcWtlN4agxHJQwrV1bttir9a+76cibZ2vV0ssByW8AGKYf+BQO5yA'
    '1beBh0v/Sc/42DvKYSGc0K6gJ4BgJI3yKUkU9M+yFNKrdyqzTKXlt8LTTqIeTEIa78aJbiM6HqjoY20I/+X2u+hJOnmqXdGDbuRF'
    'OrOlgEfL7h9w8xjBY4IGlai5QN6eM0Acv5VF8ywkZyxLgsddE2MbSME6U2d2fWBBshPcXhCv/ZuDtDfYU+K6CG0rFxZilkAktCcC'
    'FmKb4Kc1E41gWrqtzQHStAJXhTF3wyhor/aVodSXt0xYPUzszzkQ1HgjSo4zca6gjd2Tl7jwi8dJ5+CURvUNYhlxrPmtvBVP5kXt'
    '5Ob1bft3EC3stSceL1DPmxrSdyLPx/qbmloDoBpyHdxj3+d641dIFQ2ulc0+lIJwre3QBM/Oxe1hQo10cFXaHU/KeFd8nvcSluaC'
    'a8lA8RFo1MkoezVUN2m7FZzxCe+nCIA5SseDYVbYCGgaW2EHGt6FPO0QT+SbtFbS0KTkzCRioRPuqlbVpZumsqkDMfMjMARusg0g'
    'jqOJXFsZnYrbUcVR+DJPsE0VMGHr4bHva7pI0uIv+EhyI3sp86DkdpCTFdm7wob5pl4qeUpZ4aJj7d3kFLbiIvMjl4Y6nF8WDiUw'
    '2sMowWOA1SK28JtWyjbNnS9sTlpYWLG42TgKUpeeyWzgzysanCxscMLTu7BidrORkI5N8s3HeYmbRB6QPPn04c8NjWvbqwvbrtwX'
    'Lh5e75omwPSuqJ5fU1243eIv2GJjoP5YvmK1GUhyfWE7K9dVXVlcd621WFFhIIMcDlkaXx8EOvrmU7skavlx93PNoxJEN1bprC98'
    'cyZVZaaV/KkMjBowAW8mX2/wr/g4MNWHI7PqTdP49G7bXFGy4bmrwEynM+F3Dp403obVpB293uDQZh4OX5dygjlO5p0Xie86iJfs'
    'UWw+FnCk1bEei82Y/vc0ihsyyErn9J2tVsLpAbpeYFzD2lzlRG8vb43eGJh9b8RsqYltMd3GC+q/lMTQ3kI9T/vHbHK6gn7DPNPN'
    'LeuC669oMc/hEKarPtEFQYQXeYEPmat2oG4hSeAjIhcNesUZuG8sdqy4bBzPs9lscvouOygXn3HpCe1uzsO0uIXP0HSubOK6Fr6b'
    'Xlmd5HfLYhrrwzfhuhbqDVyxfxfyrKEBttHlZncEvZ6WZNoSlEM7ZpHhhQ5D7PA/MYNii7ixeG7xJbhmjxRTKiMZcHKqGgbCDmcp'
    '5WTbpNGOGW7ISFD4hY/MkR0PBlncng/Vp44Nq2PBnexnfDgP9DXqu/w5HgwJcYidvBxmXkAomEaJZ9YL1z6xVqpcUqE7D2h94MXR'
    'dWL5+i8/FZNxcmc1t0F1ajXg5KM2qRM7E3CmpngkUw0e9d2Y+x2Q+l1Mh7QurR+IIIChKGFkzuULrdl0UFukNJmhBW+esNYjjyTr'
    'jdCggDOTjM5MscUcGTA8UpJUhBWG6eCfanzV5vfvXFSa2/Bbu+SmTBkdBeIm2RN036lLxXB+aBWc2C2Lm9Hdv/9w+sNKtLe8eshT'
    'GcQs8jM60ENZk+dQlmHFkBRNGRMZnGcAWaropkgLCbulwBqKS3UXJaP1TvTm4/aOyL50rJ3kKZPbthD3S80LT+qm5J4dpnMg/gB3'
    'THJBCu4pADmibaJJUnj5H6Lf1QhyNqh9ODnk7LK4W+rRzi/gsIreNzrRi6PZZJTPsRtgyo22z0m3GkXP+v2sKKJnn95KyXud6NMQ'
    'NA51azhJkcORtwQrEVH8Op9lB5Mzm7kgGGvXjklu4NkxEykThpN+KtlDZZ0wFcCqIAFkctrZ/vT25avPP+Kh0TCp/qecbw5vc1ni'
    'P63iaHKK9jF8vITgQQOVRkzFKb/YOZ/ytti9iAZZ0Z/lnI2kG7V0us0yIrcisp13iaW1oOrnMs5VbLdWN9ptKfdp7eGU2DO9vH77'
    '7tWP2zsfP7+CU3hIG11MV2uT7YD481PK0dtiAj5NZ7T6L83c1uNd3CXpiTpcgN0O8AQmlE0k2ToFk5Dz2AUK2Me+TVEsDbQPngrr'
    'ASkbLqOsgRmcnRAPhp9FnC023lEDaApee+PRFXgkBTvMtOl9eW0pTnY+kiucDzLO1pgGgIclJ+0mkYcdVtG1OFSXYXF60Nrkx2GF'
    '1j//8d/NC/7qLfehmgOjJY579ImGAbAMRjJBPB61AdEey5w/jXapHU2KZX347YS4DtRpYqLBr4BALey0wqpoaeFptP/D+M6F+X25'
    'z/G7ifqMy5SZZu0o8E1RS0qitQVr+nTRG+HIwPBwjbRC5tMyxwB2XCIAG7xzh9vlZIb7NlyfENOIHfm3q55pF5bm27bvttIvA8xb'
    'oIxLP7AAIhwumMZcfOpvGbF/RNYlw32skoa/y1BTHrwx1aS+734gMTPB9jHcLu4NJ702t1uN51hEzqksXdqhw+BgAdIRWoWc3hm4'
    'nS9jT2FA72t0BM3CTj7KALEmR1gT2ox0RLtsY21tzTMVErPPOe58R+KepYXK8pQTnmbxH5T5XbdmPduCrY176Oc09ng3aD1O9trO'
    'Z7DGN9mYV4FzSad5PGWq6E3Y+nxxWY3eFeyWgwx3llL0IkLqmgmgBz8RTbbafDWRzQrm17rhV8DsW03joMP8rytC4ys7NIfg6KBt'
    'Ot7pB9CuMZaacyUeJkG6h58cskwHLcfmajU2aRcyErRn3eqOYvESAeBwspnN2TupI6c11NNDnLPEMRiBRATflskIwZbHWWdyjE38'
    'U4fbpz1Jh/gpr8orPIj1BcoAYyMtSQniEHsnWv20WcfWgR6d7Uxi2Rr+OpzaL5V3SsnfU4XU4udJgdMONxNbymDNzrxji5+laiY6'
    'bVG2uL+3/RCXbebSLZU6PsidQh1YiU1mHuQjHtwgds2BBhk+B8nC8A+XNMiRI+i2tUr/XS3EweGCeUzXY3PwLOhGlQ3CYEHmy2f6'
    '0bMO6jojTO2bpaC19Rgt4Y2ukwmxlDnWRfQK+EBEuPZPLByRd6/P575DJ8JnKbYTC2tyD0hUyS/EAOUF9xq75YJFeVb8mmVR9jM/'
    'pJO5FJAQw+NpeUgLEgnL+T7YQ+2pK9ll6T/mg81IbeGJJivvaCC6ZrVX0oIX3A7sirX2wcFnHTFZDE2kxwIqaFh+faPY7dct5RVG'
    'QRWgg49uph/5VReuY+/DP7D+7M0DWD9xYV/avkzscMJh89LP5OvVLNGbzErmYK0ksP9fsgykR7HHWNqu74ClhE9lfioiNolO5m+d'
    'ZUdn3SvegYqiHd0GdDikkhFnEp1P5jOj5SGSjhWrDN5Zzfqc0H9N8Bdf6tomEpu+NSPUCPcKkkXVloGSDmgQXeqIiAoF56pGjU1L'
    '9ysozqpqH9VpqKaqLd6Iu0d79rvqTcQXhux+P7WORAQ+0VW/83ay7hV/6mRg+s8RnCyYCBOxaoFKj8LTzaD8/LYNAYWDdcrEyYqN'
    'dKMuWiy1V0d9YMd44M4YW9svL+RxA0FcsU3AEtsR8kDOwiOWwUXFaqcoSKWRTSIpr4z+LyTRARoHFRBVxerFX1593n778cOm39Qo'
    'pxGSyMEFGw47385vSZcIjyQj2guTg+hDdprNME0817rSxCF2PGWNtirMfAPJzijOmDTUExkkXH7CPQ6DCUPDz6cDpARzTpkt7aAb'
    'Le3Az07sKAUsI2lUBCS7FNwaLDwoD4bz4sjcnFZCkeH6+EnQJ7wSgkkFv38R/Hnm1FSrRkPJnN0U/HQFErQ4lz8bDo021YAI3aDV'
    'BSLfEc3Am8ko82OchS5IRf4odjIx+pGoLrM7MAk6lYDMqsRseDKyNG59BJkSorL4JySsZmurxirJO8nbX3XHA03QYJ1nfZdSvXG3'
    'zqTukcE+bLU2jUOi70PJbIYRI8RyNoAfI1vlrEEoZP5QvHEDRO2qzuHYvri7BgoJ6VZtgNhCP3Qgh0VgrIvoaD3JFI6C4Q/THmBn'
    'MM5b4WFzEO7iwCRwWDMJJMmmc8L0VPODjvmx6avw8vgDK8PGzHXQ4b/4ZsaZC/zEWNagSBoWIFTw7at//wMGvxV3lpM7q5qnoja/'
    't2+PrD+DYRm0++lzzo0paLsEkxGm16Klt52BgsfGzSmqHL0reOspCAJI/N3nty8mo+lkDFvBaHd9D9KiuOqyV+4NjuZ2FHjw1lx0'
    'YUhRS2oDkFlG5J/NWepwVMwbmydb1R+RpptudRruaMQ/oBsBM1pwomGe5+uGibgRVO5jFLpnOOntTJ4Tq3x4H36b9NPYGD7BNk2k'
    'hbwo3jabKQo0lu4za/58L9mZGCFKyJ1q0dxJJjBzw9FuJZhslIaj87PCYP2qKeZSLPhirx7rJ4G95IB9TMXQzrKf2NWtwd7sH015'
    'j1zRUWqF1k6TUvSKG/dMS+3omNbrCinvWvVExhtqJ12vbaOpSD1/5mUCrlFZVDN5ZWYlUE4Cb6mrNJXV+fh4jAu3mA4GDsr5IuNm'
    'OS4x2pxP0DiMX6B9sZ+CJ4G2ZhkfqRXhmth9Nk45QA2FdU7gwHKtwNpk7/OsEMGHq7gUYFfU5K/p+JANZZMpp04OrVtTucrAQUPl'
    'GKGFODYfEm2OiQZjQs2O/IADhdSBcAgdgubFYLtEonZ5ijMsm/Mpe03Tpo/1wpWbSsKA6jqG1pT3EVx2vzfOlf0sHyr6FN7ejTYS'
    'cff13x55bz0VntHZ9x8XJ4fR2Wg4LraWjspy2l1dPT097Zze60xmh6uwW65SiaVIcWnuXHx/uaSgrfj1hn7BI/P55Aw/Bd6NOruM'
    '8OPc/fge/6HST+5cyBxcPkbDT7wkuI1Q8g5IvsXbRAIIqOYyDXqTjnw65sqteXmw8qgNCsjGNVZO1T1bWBWAXp4GnI3DYpx9d4YD'
    '2iZc3U4P0llOnwUvaRP5g6u8AmBwrFf+5c/EZkYTzmSYHsDNhTv0/bQF818pSX4QJS2D7PiXo7kbgcqjXQsr/z2Q6dFIAC//xj69'
    'dROQeWY1sRC6zSZQwkvdbA33FCLNUUZ6n2Th4ZzH+XDIuLzUgQIelYJ21DvctCU4Gk3A6HX4bTtk5QYLoe4bKjjTV205ASHPm54W'
    '00eXb+IPnk9dPSqmKuZ7h4ZQkuEuMIQ4Ixc6o56nEu5U67I/mZ7fsEN36Cjlpif5YQqUUxuVo9beXczCC/OQRb8L/+O7bqx0xuyF'
    'Ea4QGGhUecbZQG3TixDjzXu2U6YnaT5kZs8GSlgsYX3hA5zabbkoD7h+nB5NhtYBBDE2Js2NyaQTKQodwGaRCYMvzNom9KHgU2cs'
    'lqAeCYJZWbQ5Ygod0EnQP+aDn5WR9Y1o0uJnneiVS4okPUU92qUjzoWqbZs78Cmu2fWuxiLlOT/3eOwcOEI3hbs/jOk/7KsQ4QZy'
    'ZuCTDJ1yAoCnkcRf873fLi/QHl/9mb/hilES2bAc9BFAUsa1pSthIKwUyLTA88XOHG1PO0+daBuJedJht5LWCaqE/WTMJnqpNVPM'
    'e3bG46ONpBO9dnAkRYQ4YxpFPmO3nUJQ3s0k9zDjpMUUCE4vSh4vOjGVFSuMM1J1oiX4Oo7LJYwLEFnEbxHow21wnA/cJmRNVnxJ'
    'lr0ivmcPDNcw3wgO2XcQdCIOGqcpomnGSDlL7Y8yRPpC9soQ98QOIiE6DwtEBTbcOee9AinFz6J//tf/Fj3vcic0engVzqJnmxFe'
    '/O94IU+eJxyucSS9FfoUT2RI44mOw71AJzHR+lI5WZLe2PFpCX/qA4uflXjOTfjO7Rx4jcPgSpSbJ02sI38Rnb57++HVjy9fvX72'
    '3budbXaZlHeG9WsV9k0eD6ylK9rdHWpi+GEH2eFaNPetvb2GauwGGlZEBVN9cUVMwHUdtqPFzX1lxXzM9S7DWRQ7emEDv7TREPHW'
    'epsmnYNhWiKd4pAVRW8ZcM6RBBDHu7QvJHEw4w8xqFGiSYVJQdGcwhjZXiJesPpSHvHlpeVD8Yd4koi309x6jMHXYKj+rk+j/Si+'
    'c6E/LxN1XAhRGHXfPMfOKgJvlJHnqNaORqSsARd3FLiVIcbttvWUa7OZqeDgQUEV5c/OC3AJRETPS8UWUK/h/rxA2BkbVg3jtWzM'
    'iePzQpIikBbS5lBdoOeQRCIzOS8FyEDMzaYAmEKX/6Z5cHM2ZhfVrtgJsGy2jL/ieMTRm3AjYfcS7i+4ZNZjhjPEDpBj+QTek70U'
    '8J42DsqLGO3DFDkBukM2MLkKedytYU6D6UM31EaE93W5Mc75S0/5glL7jPsd2yUgZrVbNUFbyY2XzOip0hVPLPU2ggGsngTz2B8j'
    'l+kEI4W95JjTq+gI14JhHfOwPPfUALsoHIGYay50nTyPzMv6sCRxXuHyr7nRjGqj8ZNMN31V5Ys2qp+03vxJG0559iy/TO82P5//'
    'nUe1b2x9ZDwbPZZa7YZhe4M+kLSqWVZUCOXAEgpnUGse9gEPe91bCce/aMNo8r9nOhh43HIEEx0370kxg7Yt+AWFbB0xFgnr6YqX'
    'Wyf6jo8qKzS0uQ0nkcl+5gS6miTQNG3LbBqNKdWBk1ChrxSCRjA+pamII+ckxYkPcUwD35mYtuOjcsRzLuO2yXbssOhw+cMf/tAi'
    '0qz5tEzYDQ4C88uP7z9BqSQ1XIyor+mc2GaPk3j/MRxOSIUtUuTQ+UXjpNBvQvosv9ynMwVTtoqnJPPhoeMcz999fPHv1NPq3+NP'
    'X95sfHlz78t37758fPfl3dsv/O5/+e7jzqsvnz6/+rLz7Pk7+u+bV89eftl5/vHl377svP74cefLzmd6+GXn5Zc3n5M7q14GkaL/'
    'XtD3iAXJFECmpDVzEmm8+8MP+3d/3P1h7/GTL3sJC6Y//HBn3fdTPp1xZkZkFi+TEBZaWgXjN2ktHHCxH0dOB1qKeFukp8c1YWnN'
    'vjGJwwmNovhhe+/u04R/qgHYwVIjAhf/nw/0r54NylRLgSRgEuyGwo0RZCQHjUmyUWXCXCEJEoT3O3i4Y5DEEO/d2Xn1150fP3x8'
    '+cpC55E4gSNjbw/xLefYHUyeJBlzIPrHHhFzngIFGtCZRZZ5CHp8iUbDWoayjc7+UkvBYlUEsYmuxj/s/rC7+3f6794P471l+i+t'
    'looLpUnInUd/jDZ0kXn14zIxvtitxGWuryZxvGz++tvm61+9I4X9g5mA5jTHnGIGyJ7iNcj4yNbKK+tDbffhqfmB59y3YZYa18Lh'
    'KPpje+fzR+iGZqZAhnHr7t2WNh4ntgkb+aBV3/rtvHpfa+MGTWxXhvL231/5T16+eldt9b/8lxs0+4JmsOV8lfqCcN33nWA3TbNm'
    'y3KhLv/j8Ndb+y02uO7vs52Ty0Bb3N9nRXHff7jfcnlvqgN61nLEb4HVxBmS7UDPStrXvXmZ0SlGj+EhbLyL9Vs9JTagbDP8WMoz'
    'iGcvk0xk3MNThA6IOArRFM9ELmUfSdsc7mD3d7Ukh7kyZXOhyz2t6AUJxMkPxR62T93yl1D7VZqv0c57j+bMN7R21a7Havj+7V30'
    'W52fYtZv+T1UW37+uaHhH8a8XlFEf9QqEnv87sv2d8/p/z99ef/s878TaxS7O+3ralO6HBjf4zsXZRgHcUlnlBagc6nhdThqbVpr'
    'hKnGndwQsGDWrGm/O5k1qUIA8HEtQr/lzpJeo8qahzlDdw+FX8wQuu1z6GFuGI3E+r1721rElmBbZkZEjZk6vBof37WEAvPl5csO'
    'q0MrgM+c95i08QG8oVogrSwtY2nJKDz1DLSCIgtAHBqe43N7RvPpYzpuN54uPn9lrzladwgBdrktY00caxHhh4VBfAWP+FKM6dkM'
    'xnVlujQus0e9E2YsR/1YHKd6yeV+k7Tcl7Qo3jIYslw0PH9YIIm4z3OaNBGRFJXj6QcNK/Aoir1WeeWqhMRmE5lrWtYAKQBeDa1y'
    '1kr2+Gws2diLguXMfsWe1c7LgWtac51lQ+FtPHflwD+xbmTIs9dyvC8T0yD+8cSuv3+hs5yO8B++cBN31n/44Uur6r+0i0qscT4D'
    '2n/sUo60o3iZxhbyn/5kKOEZYJLrSbRC/2G9e4jTX/fcpY80eRsTWcla79KR6Qk1LPzcMTQYroTJ5bk1OyKxF1J2ymfe2LmdFVe6'
    'Oi4rTdpxhN1Q0/HMyDLRF5rzpEI5Ppcxo2h94dOxXpm39pdWIGbu8pKjW+jDbVPZjd8MemUFcWb11vhzedgSCrcu8hmaJXJcSOds'
    'yCxUeK2SujWTWI45ZFdf90xVxKEaRhL/Er50pMzVLKHKuZQ4gwmuV7yWDSJwk7jsb4lFgnOj6MiKAis1dbZxIb3LYPqSn0zYuT2p'
    '+RPj5Eqxs/TjJ5qkzoadqsfzJ08uO9NcfWamzryZOksWS1NvNnwh8c29BuHKa9q+qXZhjvQzCENGWeXDyvwiRu86gRzxBwkNAt8/'
    '46ik/bt38efdu46xLxq10zNb3iCELGktLOWCdv0oVKFuZ4jEONA+D+WJ7Iuhv00XisWk3l4jFftHl0lPWZ8wFZVJKt6Xo82IwD+M'
    '6VHripX77p2/ch/f+TNhzrHWFV/w5nOrYQFbzpeGJ4U5x6ImWL/3W5GwjX6lU/uamI1do+B4DTZKg8Cmj7QyTB3WPPt8Mhlm6Thc'
    'cxenJFLGO5Xj1N2UuCtvN05u2UgeMD9PORx1CFSskHNXrc/xwaj0TTE+B2Qz20jnazRoNaD8ciK6iiE7qXjliIFrK+oxw3oqaTEE'
    'Pzo0IEkBeQ9DkrNI9Tyo8WGOLcigG+GLow3Zm2xk6hpjU4WDCbo+BsN/uYy9+3ffmWuw7l12n5ACXmz1vpc+VPH1vO7FvOoRVOsP'
    'fKL11Fet1UCLwfCDuujxD1/ZwEZDC1c34UpHTvSmL4eNk8/ZFa+6rbq6inw6x3r1y6uJLEBygSa3kNYyOZkpGTO4uHHSyGfG7GiS'
    'Ccnln95BBismYk7DAAOtoDoZwzzAxyh8dsF7Qz9NXsq5w5/iT6FwNW8bxkqbvAmZ0bWUOQacrrlf/q3Fm7rTtr3maob8r9x5TVOn'
    'ytbTp9FacmNStvSzZVuy6HLyzuYPf7gG2XQhoQWTX6ErGYa/L+urFsm8yj7VRqobFeWSVqVZj/d4rdbW9gp25NngI7gN12cM7Aes'
    'x4615U9F/TLA48z+iXtxr32pCiO/0hTGQm96gbDNuBvqQ5oWEZKjtZk+ACsLTwJx5sa+YzGNkf3/PJkckpb3ctIHGML3k9mgUzsR'
    '0JKXkBV2dLbotsVZfytaWfd8mIYixCI3GQRhcZKOuSTccLEHuYVlauLx6jB/8nh1PnzSEkiulRV2XN68dWPKvupEAVSYfy/gr1/i'
    'Z36+5iB4PH3yOH/iToPHq/kTOhCyoh/XaQ0GnukT/2TwNtNtx4lCMdqkEgHVUM2j9RYn/JQ7saMN/EWC5uWutLNnjzAOFWUMGzOp'
    'bH1KD2FxkgHyjhKrkzzmEZMEy/Nwub9ZMd1ceoMWtvqE1yaprObjyJ4L/pLSYj6mVdUFXV42GEGWE8qYTd3NKjVIXalhXnkfYjg0'
    'LtfNKu8/HuQnT8wHPV7FLw8Z4PKWP1Fuv6F1k+QNlG+ds9OoM5j0z8QP55ec89j99f07iVzrRM/nJKxFvXOOx4hi+L8jro92zWQ0'
    'nWVFAc8oOcbgeYovAUQuLvZo7L1ZOsvRDOIp2HcGfbeDnRjPp+ylTZvo5Sw/yRI+WN9R3ezjwQHpth3nGv7i84sfWXSFRBgndW8o'
    'XKJ9R5v93oao0hsPJO2sTbGLLby2GWFF6R39ITl22RwjCMK26LEURaqTR/QPCqJIP/oT49qsnb16+fzRo3sba9HfafNGT548iRi3'
    'Rv/cjMrd8R5XwO+1IDwWN6FJbCPq+7P+PWDb985L49luRrR29lr/b9NnE2dYJy4uo7Izs0tD+XtEGt6f6AMf7LmxPXLxxFzENZzY'
    'AXoSMpECu+dpBCN7YnuTnY37Ot1wb3jF5m+BJAfeNgvRbcGoTYf6SxJ38TUn4ia8W78yF5SGySnMTG8m8xk8Qh4/jtbXoy/m8Xva'
    'tQIMSS8euOfbGTUywHOedYdsiyCrLcZ+5RA8krj+lqWwWq9E698+WuN2vqV2TIn3xBmO+KRZr/bhBsy3fIxNzNRxq+HuHBNW4dgS'
    'wkJz1pGLAoPK3jYRa5he1O3Ib/FhmnGg/9OwngS/dbVoG6QDGgMBuXg3e7uSSfgDAAbbJKYeJr4NUkHB3aKkDGCLH7x7ns+RFpMr'
    'O73wBFFessVgG6Q2g3xblsJPlMEGpw5gNmhI8T240Z6t3V+7d7/3wEhiQ9Py+sP4PmArbBZD/81DrvlorfntI/aZ8Mbjv1zHq5xN'
    'N/Wa6xu8GA0v6UPX7/NEN7eM949kJa0c2NDGxsY1ZWgQGw8lxqBSRgGFaWOpLG3CQ2oL3jczfF/maWNt3Zvh/sIZ7oczvODNo9rc'
    '9yvTG05+vzK/weQHL+9XJr/vT+7D+uT77zHYpokNyty/pgwm/9Hiyffbuk9fIiwgLCLMTq2KXqxIZBgGHe731jRQxN3teMMKk3oZ'
    'fGRtl87dOUnIMRQwSZ4Ba3MHZ8A7HbABtr5yO29saMaGcCPTwj5cewBisZOThUsvEkFlArMKATQVqnQGShCGVG1DF7s2uZ5jvaDM'
    'dDod3g5sBdcJok+3aDOap1uPytEQyai2Ij5ZC+/69k+Pnyzx9W1f4VlafwJAzJ/S0XQT8u1j/jUs+ccT/nEoP5b4x8/zCf0kSbXP'
    'mE8Vv3qIVTxcxAd/kjtd/wj9/scP29AtNPKl6B9lo7ToQJKkIYsCU3AkzCkJTdPZBAhsdCSMhgiNebgKF0kPiOvzjZubsFj1UuM6'
    'pLFZNuTYxQLZCbxWZ/OxcevZf3zanT2h//CUdhkUdGsJQmA2O8kQXCMzHbMETsWe4L8zP8qGFi3l8wjRGW3grYt/4xYjTWkfU/Qx'
    '/TSDqxNHcTyVxxLScdo9SYcI9+F3l0g9LdZoUgHQFncttWnsZixTfxSjbJCnvkPohbLTWa4Bcd4uRPwHTfpnnodYzly2Bkg6hdrF'
    'M4pxB97tLbeMj5y9HbwdHXKwWNtIBfvsZ08C/WWHP+FSr8elEfUwrY0vtLjapdHR0p/TrjoqDfKi3NlaWlviv57bv97Zvz7jryf7'
    'en4vo7Vpl0YCS0mfQ6v6Z5dL9LH85znmHCWIvj/NonyAp2N6jzFuLSmhR/xMCvY/nPx5lk6P8j5j19PaPE67h96Td3wpNZ684CDq'
    'Z8U065dbS+uovtpY3x+rbcprFcwvms9yG1Z2xW7QKTO7Sp0vlp48pr+6UzSLP8Yn9GEYOX7QgPTL18xna/w5hmxKoDy+wK/uDxzP'
    'e8N8+jofDjF2/B3NugxWigZptbm9tEuiINCu8KeJXELD3ovVoLFqL8VU5vzsYDbCv8QAojMe/Dn+y33ASrJosVdd1emsKP+cTUYR'
    '/thamtFQlvA8PXlX6KBMER2VdL5qZtMf22qwYE+837LwQsHMRixhO5biXWuaHFhNO5SOy0+zJuZC//WYhdvnDZu8zkN6D++rsibB'
    'jE9Y7XzEBy1798dpSayf3lUijfWwwUVhOnsh6Z/WEj8NVV6+Gs3xKaft6IiThnzP/32TeJohpyzjN/1zc2c+Q7a1GE+juxGykpyq'
    'rZWKPNEWLqSqV76P3BZ4SRXoUzelQTyANcO6B0jyGL2sDX144Y3CTKzNaCxjcbxVizhiZsSL11rCJU0kgDAUpRfhPmwQTzqemzta'
    '58g7zEWvxmglYtMYweiX52tAvxb4GHhZcGSiEdbXQfpl+odme/3RxiMWcNfvfbP+0AEjpMiCQPU38jHp3uudB/nYH4uYlbcarmpA'
    'dDmCf7rIcYdNhSu+t1zBGobcMRawdSXr2BBbrAGpSduEpgb5rbwYVY71g0EWf6Dhn6YZggDNlsCocIDDVHra5ThRYrgb4AXWv2e/'
    '6jwAMYSNhlgKmXj43Kml8Wui0OTuiip4uSzMHta6EpChQWjqWhU4gL01cy52OxrSvYdryP1nbfMa1fBIVfplFDDJjeASrH3oXQyX'
    'ZhvVeE4sGMp3h44K2ye75SL4+du1jYdm3KckLdm0mM/uY5yH+bi4hT0iWAhqrkW4FtvdDNZB1RILC4nGCnyYj5zrmiv1mWUIcZj0'
    'sA+sZAGbLSOIBiZdviaSXowwwWIEt3PpbEIzQLt4i03C9kcZTs3Tg3vcoJa98RoNJngmlwwD14ntA5doMPplHKKnaUyUABhPGzwi'
    'S1GlLFhb2JTpm4yH51GZHlP5Tx/+vPpvn179mX2gaWTUVAlIY8ldDgOs4ybogSSvQpUj+GMlTZnVOH7Iz6p2e2xM6KHh2M/12sYR'
    'wJleQxO8qSoO6PAWW30MrkWlt5bi3b8v7S0nS6uHSejZYoYKyBIOH1/kbpiPKhHr9ETD1em/pqwAtJjwcxd97sXR1t1fsB/Eu2X1'
    '746r/AC2om54GJjHX8JixGyeVgsyA9I0R9bs5Y2TJ5uN3lUvlhsFoXsh6PSV45QoKR1yCrIgEN29k9Rinp96LRI9CP2WyG/qR0eO'
    'mG4DFeLHdG/qvPHEVJ1h7NKSeouJgbrKjL1r5Qmx4an0cdqtfgxflFQ/wmoD5o6Ndhf0FVIZp7QncthvFeeIdyf/xbtJxGJOMZXP'
    'ssLtl9knBt0KoxvOvNgGyX3Z56i2M7nRIMHs9QShqnSgFP2chG+azmIyTIslenT0bFxUHvUL7/fqk6Dlntdsr/Iu997llXeF9w4W'
    '1OOsUgCc0CvTnwyR1E6UyrUHD++9WK8OBWePV+OIpnzI0661zrPhcHJarTVnVOVqd3NTCYr8MKtWgkcwVyvmU62Fkxqc7Rn1OXba'
    'r5SlfUX/CMIdH/NUL5vpbxYqAnniTOWRGUu8ZyzV4m8nehjm3C/Pul5sGkQXI+SAknDstU0wGKPXi0+2nrjOdQWh9280uHtj9V7E'
    'SnvBRBpGUv11NNQQKuo6qXjg/svjo/6lEVKeKaWQC4kBduRBW3BNkqpbcBhEdG0Y0c0CibwQB9+Z8eqAoE2vlnPiNFTJJpZPs/iA'
    'pvfXGYUWxQg5jvlr44QWuGwe5yzA+l6aoWfkTYKDsI4xWgL77nQ6tJA94xhh1tS1euN4oYZm85s3+92VDc1v3tDXBCM19FR8RU/f'
    'hdP83acrW96txJHs3bwnhLNc2TZY/M2b08Cqxc3hWLx5c36sTssY8npsOsKP1uKaz1rBhjyiDTLDgRPNumKWU7Uhbg6vShgRqWH8'
    'kksrHD/vXtuDv3+bo5rqHEfkVSMCIfVsY1RTjevkI/uVnpGGhCAWmKAKd1hawtiNSi8aPRR6qw3iIamH3z7YeKDfRL8e3nsACMSH'
    'D76Brp80MSA/SMmbq4Pqwl6G95/qBFu5Af3EYfsIdaqapdgeZUzdNfuUtXFzXd8c1RQTNcimlXNFVZz56O1gYXyS0/hYQV+nGRye'
    'DP1Uqo/4dLb+h9LN5s2OrivCrL4i0Op/VgCUjTT8FDMNcKD6BW0OtQqseCaJGNMGN8D6rQXwFkmASdnKydbxLq3JJ97xPNlWvsOv'
    'S1vi7cC94Z9iljW1971x/raIKv1K44XOKxx4mt6Iyk00FRMjZMcGWrxRXFWo8CLiCJdRHEhlo4TWvT1+XaBSmzZ8UvGJrkYdrbvQ'
    'miuiusxtLJFBKS7pyN2MruISubnXkoZ+LHTewXAymcWxIx6eo1UeCyP2zAT1GMfBH4uKzkA/i1+2lu7zHyJvrbE6BVVma+n5a/zP'
    'aRbWoMqN8py3yskUt5joFv9KQmf8NeMsdIxMA2/lN+7Pv7Qkyo2jhqQtKzO2/ghYiawh/tsxBWyGsjd8Iv8IydMf39PAT/mqAdNz'
    'l2fgEl8DO+rW0uAsZZMkKyBPTSNv2Z7K1fCiVl655b7dFMum5nOZBGpRp0OEUvdCir1LzzFq0+pBfpYNZDPSyxek771P+QN4WDyS'
    'R2vVQeAkVzWx+f1q2NqqmZiGYf95lg9ozPh1SH++mAz9aWNFz3gmMwmZr+J6+w3cuOSc9CDyhpDsTIHnO4Kwx1wzOC9Y62HZrbYv'
    '2KAX6xVHpZKvUIAw5gUbF4GnR5NQBCdHONoBRuv10yRejP2Tym1EDQZEX8bzHCnr1pKoN8vSY1/Y4PEswwmwri0dMeOpfVFQkj9C'
    'ZbGyz9TSV0LvV+l83EDkY82YZ5Z5G/zO8f3grpudddnIcWTPhj4sph4nAAo3fuLOcGvp9Qb+B74gbTCJ9AN6E5rTIy6IRwVMKHV4'
    '4TQdagTnn/kcONU9hP9Jq+lmAfcK4pkuvfpC7WW44puyDI954eQHe17eeHIvGzealp2an74A64nQJQQv3gAyu+XMcqo3DCys9fG4'
    'ZdaCxybz6Sm29ZPSfj+xwRZPNIepLJ6whqPVBnDGAjcFF5Ss4XhlzrTF4poNMOeytFj3Hq4ZCXgrCs6gyomR4gySWjId0+cDn+81'
    'nErrG96x9MgjxmcP8T9dDm6nFQQU2Ys0vtGx3L5ydcbcPrwrq/iWKBjIE/3jKc2yytv4HI5nSYLavtzarkW8Lop5NYAI1KlsF67Y'
    'trN14ZR33SmiLTSHvn5F8OvvEP5a0a+uFZKpLd9SZMB3wiDaG5pzKoG1jXaaRpOMZxxwk94PWNT1c79QZ70ymNYRp+DMNHSNfeZF'
    'z15wx1eZhVS1RYv2uyqNWMKt6xFqUr1zYQ+8e+3gW55GGzSCewzLh2Y5jzu+cC3hy2a+5L3cTzhch2ZTBrJQ/b0igBcDN6GhZgl8'
    'hWFhAO7C6b0uFrcW9wl/WAElinNlVFUbis1l6BsuLwJDzY2smMOKFbMJ8cjTFQPO82tPa+FZN1mb5sBiX6Fbu2oPeHYodzQZli86'
    'QjPTf+jx/PUmVcTj+dWvuSIyGQPRuGRVIzcbrTIV8qvpqhWes0B1rUcqm+m6DK6Ri48HxgfidjUEi+PfKj4gtyR3jL3lqAbW2TuW'
    'uluIvWLxwg098MVHiX/VwoBzRMa3BMbo2v7W2h6an2sGmwF+PMQvmgKM1yOHG+g5MARzUgkp40kJfK+aJJ5H4nvymx1onMnsllOh'
    'uEsV5XJWzYJ7vwff4n9Kp0bia+YELjAuChjBgs5+bTeW4TTH3LmOPUsgBBlNminSzVdFFeIEZgefuJfUQvmCuFjDubkvcxy3dhRf'
    'Mwxorbk+2xjqZ0POhw18ZCjJzvkDcXd0hhQTBj+eMfjxKYPTMII8u48dIMkFO9xM4R/m4d+rA06nIl9Mx4dedJi46YV5ugwc+YUk'
    'ROiC/MQW4kHQdw2sIw+lS4fsZZIAvNh61yc10WZQC7Chrjo9Lm68ywB4LilLo6PJcFCoQ9QZ7XT4vtgW7ZSrY9gUQeYtwXd35u/B'
    'CYxg1qEeUUb+kw2oaQ++ubf+AA77D++vIaJjkea2cX9NbBk/9e3BBS++maegOE5rxuc578Fzb9kwCfmhXNQSWrQwKLNMXJMBWACD'
    'PIDsVBJaZ8prhEQIym1wOZtvS94FVtkWu6XvL7bMVnkx+HCTpXa90UT7a2bIc0ZXNxi2pz0lFmESW1F3nbUlgaGjz9xa+m7n9Qqp'
    'X8hoNkiHk3EGP4Vi6emTW/ASN81w7g1RnRGNQKqzPJnhyWf/yen0V/hSh3ELL+WlaTH9FQ0i5MHUpz3wm9y7IdKwvwD+gewH3Hi1'
    'Ehxu/yImhfX1b9dYujmivx8+uvdIFnp6+D4FWy8nNC3r9++zcW8meUnMTxGY3G85vcwv2e1bS9+ssZJ8QOKG9/NwXlozAGjIDG1V'
    'B80e0bqIvlfywUQSmzf54qQIx819Vxz3JEuL8lmRp8FDds/Rn2pNVju8OHH8NhrURmoU+EToUzNLFXqW6s8n1nkFX8qL9ovZbxsb'
    'sjbFLy+K6rNhyjyNn2XjlT8/9w/h1WoP0+qvRQILVjXHZ208vG9+fJ4PMxXmVe7VPvxWV8NvtPNhLVdTe0lEjwZSTmVrLvh2sLX0'
    'AVQ+5AnjUBL9Pn3M3/3za94JSkSoeF1ftnU+z2uNy1NuG9Dfg4/jpm7H8IG7cjiLp1UPnFVbQgUlt9APGhZannkr+nUfa06R2vea'
    'xBTrv+c3I8neB3ghhRMgKdi2lu5tMGUFTtlUUKW3d+4sap6oXl2+XX997xFR6Go4j/ca5vHe7zKPGwvnceM/cR6J3y9V9IvGaVy/'
    '6TRuvH5w/9uH1WnceNjAdx7+HtN4b+E03vtPnMb1h/40Plw4jRs3ncb7a/hfbRrvN0zj/d80jeFte3Uu8TaqXMZfMaE34V3mq/ri'
    'RjxPh9tSJDwJzFeYPwv/COesYnxJ+89//HcofP/8v/4H//N//n8tLyDgYCQoC61B1s9pkHydC+eodxlEB/vz82SUjv2KWv6dRDts'
    'RV7EEkKLoLN3o29hsox/NGY1SMMiA0MUZvcEOag5+iTYRyzvvh6VnqcqjXQXaOH39lRMpjZ2PPL8IzUHg8Zlx77+N6tsQGpa8ic9'
    'NAVoyEfuRXjw/Q8CCVkGufdwrXIOU/NVu525MvnPmRKJN2mcijsXvPy16fqfMh82DOY3SnqunUZhL+0ha3q//DCHddH79ZbjK1GE'
    'E4owxfIthWGG5ySZDt7jHS+dOgpgEdlE4jUV2Geu7HD9azsM9tOV/Y65v7HfT9B59Vgfe/X9qBqYvPOBIcKgVaLCweXiltd5xF9B'
    '3h9pwWcwrTSTufc6OEm9mj5pXdqvcs/0+1r6SgjFVzZmsid/PQF+9iPbK9kmr9AbiXEfI6qjHh1P3++3GWHiZ28HfEFTLEU7fCKp'
    '+rxamKec8HlrSX4jsAxz1dQOrVi1ETsxrp0gRo2XVeLFQRwjWcFa41Smw0HFleY5fMU1zQ2torAJafbXUCG1HOBmY0fDxo6s+6jr'
    'zN2sdARl37x6PxlQzVdndJiN+QwOCSlY1UAFzkU33WXKksh5ZLPT+6QfMaJiD7PWMslvfz1tcWO/kqb6MqAVSDCgKdUGI3zyWAYC'
    '2l+KdOQylel0OswlzfTqyXhQ6WVFe+gEBLus1NbQA94s7mBxvSloMahnY6AW1ED8V2MVfkF1LDMhmaz8wEH1bEBatbFfVw+2YTYE'
    '6MLWr8JodOwb2JXMLC0ch7d1f9dRSLvXdh/u+N91BLbpqwbBcA+TaUGEO8u+fgyGMlF7xUWmmR5XeSs92adjKNy4P2ITrIKgi99h'
    'w/5nHQbrVdYXYq44/len8AXHwoZp8beMdnWUlSnmcLWyDG5A9WXG6lTYbW2VarV+h7XqT7to7ZMdpMqP/elXT8Liz5YmB86UPJ3P'
    'hmI47q9mEmZarK531lddWTqSRkVjBX5jS54V+YK81uurf33/bpsHv5KP8fF92NoG/S5fsrnrP5efDoeefY+SHAk7mT0Jk51zIfPq'
    'sY5VHmSDiEZkXOP0zff3XrzceY0LRwfM1yknb7c/alhdogkGAInwbXL5H+ggaJSoo7ZSDRRSI3RLIfY2orGK47q2ggkibCoecElb'
    'w6kgjZWEx/iDC/kNy6Bcc69yryoZAiEwJQp95QH2mOZFoILrg4hUptlRx8PyUfeDCuxi63c64QRYvTnZ9EfFQr9B/mdre9As9WoF'
    'IuXW5AyvIadPNDmZy6rqZa0+gZTwH/k0TFgdxTajGRdIOjQrsGjgnyRIZoEEOrYrAG7hxk8udC38FgaKH5/yvpcs3LhJWEwxHxLe'
    'Aol1Ix8CHs4MHD46UpRk9iviJwyPbADXvS/EGINk3CADarON/yzKxv27r4jL2x2sDU+Yu5dH2DgyFEvayCDFtUk6WsxnJ/lJZmGW'
    'a7jKtDUEWFma/DVpwu1ttxeq27BQgtTsrZRXHAjVlWZkgZoWnMH9a+3YBTUNuSzlNk/5C8lRjhzjmJBs4XRYV14fzvza2eHEsT5Z'
    'VvtXOlmcK92AqP/qjOnau8mabqkUNKu9f5yyYBCk8L2KHtu8M2v7FsP1durnySlVOMoHA0bdNm8Q0+0/Rw7gM1OVmUW1BHq5HTAi'
    'U7z3wm21ao2tSg3v0xld+X02nusXV08Dy4zrMU0dej5vJQlxftsb/K2anHWuaGY3neXpylFaTCfT+XQPDfYAKeGFPXEJYu+0d7MB'
    'WCf7rcgpQNscwy8A6XzoEnpLsEo2OMw42ELTFJTlZLwZnR5lgh9RTiZDeDMiDWERxSkRLyfPPs3HxA8ThAmkJZHbGL1w/mQS6QDo'
    'yLXZr1sajwoSH7IxY7eQgDHgVOc9ktlkD53k2akHzo4rio/jba4SYxJl6vGXqE+dmQJ8tHzTEUPxURESbJ8D64o4FpE+TSoQ1Di5'
    'NHsLUbFH5txC0iga5GN9lTT1sX/nQoutaLHL6RmbIKwz40wLqxs6Y3fY0osblR8rfqXloAs6LgaDVyeM2k8MBynzWrMMPkK0yMY3'
    '/WspsktcIN4VitxLQE7hfGPz+8lTyskhMTjeAr1ybLOUsvsVPQSUOP5W6VkJi69IFOoLROWhMY6BdkYtdXBppdAu23lvKCk0SOAR'
    'GzRPmoxy06Ccyz7cNLTg+IJWM8uqPzHWAt/U4u9mkQz1GKOoTmQCiIORXb27VFQ2nfAus5NeX7DpJIcHFQsQDNj6RHNm3EacFdSw'
    'Dn9cUT7t6BKtYMNhZfyv5lW5pThT8n/qTbdKEubsOBoBoct7aXHUd968ev/qx+2dj5+BpN4qWIVYGYgK0WUHuJa34PT1O3iG7K8z'
    '+hfCtLIu2YgkpXIBPMSU2483f+iqssBLrXVKvzRvGG02UcCi4aSfDreJTGEzoBosGnjDZkdDd7JdGp7OwyBuzjsIIgJCQuijjXsx'
    '5qUluCkivY0mE02TFtRnPUsPnqPJKKs+rza3fZpjIAxthxXA1HP77oVdEnsC+Q37A27+EptfHdVeDZXYIVYDaO8NPYwTi6dGCs+Y'
    'jvWCmAHQaYR5o0VWNcYDybV5eYuhqd5DQYlb8XSWHZCevsLXtSusXJM8hHETV2gg5D7jdVoaVh9USL+I4gHS06Yup3kWLOthfVmr'
    'a8rfy5UTR4VZx8C3PTUr4Llr8klnJsL7+uKchj2K5mNSrIrofDJvnTDoHNx56ZC61bCZUA3ZUZhJdKUV5p4Z5wM/5gQ/fLCh0FAv'
    '58tJWFJc/Sr70O4tVBXbiyfuU104GpPgIqme/vQnbClxBd7Vl3tWobqIjun45SkYHyNTSe+nbkN5hHOLw1E3evf2w6sfX756/ey7'
    'dzvbXM7HfmNUS06fa7v/gDH5iirnsLqdF58ndHgUCYfd6DBK4qDIQs/BFYWOp+jwJH35wgE5i0aCqhy1w8RjIZzZr39HkLXGfOnw'
    'z3/8P3cuJPcZi8ljDvBuzce8QYHeZc0W99aSy3/+4//d3wzFVyysJ8Y5L2h/RcxOdc/AA1x4Co4ahKq10FqL850fcwyb+K/Tcqj7'
    '/z6vp0EKvHNhvyj+EJcdmiG+kEuSS1a3mt6Xk0SScO0zSRKV+aVK9vJPBDzYjFhl4XC8pXHJb4kkEKWGQqE/8I5upOm8ZHInDYOE'
    'tHR8LgXoCT6zU3U4h1B4tejBI8QCRMTfD3G2VUVgaqOhnogPLeu+3usM8gLqy4AXQ91s6QRNiwKsqiPiStya4LS9TctFhCtzuose'
    'zJEEq+AeMkPRKaXUWX+f8Mr27MMT66Br5vz5LB33j3x9gk5xpgnWQnhv+Gv0OSuYqGofYQq8pI8PVZqgQSYyv/w75K6+rvhlcLiD'
    'oGJ8XztiFe26HcFcuTT8R/jGaJR7b2vbwMdU5D74nTfVOr0D/tpIloefbYpU7T2hEVnLRqBRB0lZGcxGtgWznnYktbtS2YT93HBA'
    'aEHHY6t97P1EZNk5zs4LSbxq83Z53er06VfYz7PvN21eLHcoh4fDREgqvsmq1Glt0Sp5my3n8Ppi3kMF5SQQiU0KOW+0CR0E9Kaz'
    'YI5pUoPvdIU3F38kgl6EBP8ldOd96DG+c7fFiheUYtZd8QdHZ+IPlnxaVTo8NkDxeD2fQQvuirLKfLGQbPOtwmiAzascfPxv4pRo'
    'jDhTg0AG5ux0CsNLt6KqYuHYqGAi9BLLB6o8rx2yuyalg74sHfExcQS8edYiFsk7XDbT24qbWzh5hp0hCG20GCnl7Ap00Hw8nZci'
    '3FNBORIEviFqyTham/xGGUDkrlvkOYeeIiJH0Fi4bnlE+q1+ZMs0bdSC1itodiALab8dIfUEDlZc8Qw70bsMZrW8jLLRtDzHG/ZJ'
    'zH0FGbfRtCmzVBIx8KdXDEb6kOvENAAd7wFNRGEGLwKoS1s0mPCeZfnY95fAdNNzqL8ORwBLggr+ZotME8Zm5acQstPYiCRoksJb'
    'oWxjbc1GxJxRldHkhGe98rF2sDIiHiMd3yfM4HA7pjMvuNPulXdvxvtAuYRw+yRyFekoCVmWfbXpNqyf080fxu0TI5lzjbCr69sD'
    'WDpIKnZA25iM+ramEyYwFshoOkU5meLOLT3k+6HYi9vLcCopxiAosmX2VexlrLHf45cu+uk0c8VVm8L4ksUD7A3nM2uA8jtKTM45'
    'X6tSG2LIIEChbJ7eyUfZLLA2wWY9Kg6rpwNYAb8EEysrUi4fyqiEV04WpKHHLcy73iMhBhsdTuYkQtveUcn+YF2oNIXkE/0mlXa1'
    'VabsNS/7THEKXfUFzhV2S/r88ePOj6/fvnvHEXufnr17tbPzioQKfI2UzYqKOcBvgv2u+uJ3JSw84qFsLUmpJb5bXOmzL+nlktyV'
    'bi3hsDpkvP+uPGeS1EJPHq9KU6EfaGVENzxt+v5pY86NvuYh4FOGP4TzrgdWRehkO0IagSBQVUafqi5qsaR5ilioP8wmo92CRJc9'
    'MIQRMVAESRaJM+9YYdoTt42yveW03fh2gRbivHifAk2IOQvYMjFXE9iM7bLuNc1ws7hgbFY8JKRvmo1jrw5NxTCdFpUBSee3jwH0'
    'RAqtfJGtwzDvlfJNDYb7oXja6es7xrZ5xdZLVgNtHdvKd+PBpNIFUc5kuyQq8lJVcdnPWa3sLKuX/YrrjY4QnVxrLFTjeMWdZNLn'
    '9Sg6LMA1C7i7rT8cPKeznFNDH7wtUyJf+Xsb+SrEaZ6K5IeH5u/tIzBD/hOJVeQv0djwZ/5sMICweIfF3MYVkR6Txd/xDt/xrnNw'
    'Gj3Zir7RU5Fr6givr5tzQVdRRp1YqYbWvsAjOSVtMf6ioBSgJ8JC/IUN1lSBPGdEjbjg7BsgquizHP3//Mf/YMqKNPQbv+3w8m3c'
    'VgTTxY8/Mx+tUrbN7OFX9YZMb/GQR/3eDrt4NZoeuct+kexgRoaIWXRI9jpKi9wuUvE6HWSLix/QW1v02bycLC6KuL+dXECluTgn'
    'V/aGHJSGXO8G8T2b+JtLwvzvzpQJ56JCFofspB0djPlMEiKscWkt4THacXb6FeI3g2cIlDZQ9p14Q4LHp4zv1OxbGjIkwWE6PsbP'
    'giX2tUD3Qei+vCuJ/rIYHBd5cQE2ODGikF5Tf8hOrTaBW+kX5Wy4/B+QmQ8hLADOfsi2W9bF5HITtEm8OGO1zhxQ7oupjJQAJ/aL'
    'cNJf8xJX3/5LGKCDl8+K6utnhS3wArhA/nuRGWhl+E3cnwMmwBbHCeOXpnJ4ZN4bZccrEahQtp3XYnWt94oXsetPb9YqXepTW0oP'
    'yqBX7M9ttWrbgqB2v1hJv92Y8rI+JHMFR5TQcgRxaSvx6ePVwtFjX/JxE4zKeyk+N9CU/SIsnnh3llmHVgBoDmJacDNjLMK1yhdX'
    'Vd+sWJP9T3knBvnKBHDsBF65VfEsh15x3/zjl7QnkJsF1d79UvUltGlc/EvEcF3D8SuN/eoZlQUJqvKTTx/+7LbLZBoQEByg/Pev'
    'fCe1elP6ImiuobDnVmWKeq4pKGjusuquLVShyd/F9ajyU22mZYrMe28PmkfPRKa4cn1w9TwcmhqkvvSYHjLOenJZaxK8o/j6Rlm4'
    'DVsUEfHXDNFcwbm2PlPzvcnp9cQo5UIqlJvQhXxErqtlGHJB6K6jgztauSGEYMKPgj5Eeq/14Unt1AIPVU87agZnhv4y7VgB07JD'
    'JgE8tUWc5BkWemvEOCnmCaXhmMTfA/ndXa9WZm0s6pW0Em14dyv+pPFY5nWs8qKnyYlUQlIWsrqRjJAhk5Nr1kjHV7fK8uXNG62x'
    'ObUvBK3Wzbs9XYLczrP6x7QK8/EYiGflHbOF1/XMUm+tX5ZAR4fwzGWhnN65hTcvanNg9OID/8PZu3d3DXcb4VywA5M4aUK29/Re'
    'Vp0FL6YA6MyBT74iGF87/0ZYri5B8O0qh18z7WbmWDwPfm1zsi7NnVVyRif5Fx/3dpClLb87kafrs9Zg23c2bHXhjQ5IsvkFTFSt'
    'WmKkZ+tcORmk560iAjYTtQtVc5N9P+Wukz2UxhGMHUjtx+5K44F4rtSl+cCALp2HQq0pyMZ9+2mshDQShBWim7SSpt6a+/r/e3u7'
    '7TaOLE30Xk+RotQNQARBSnZ5akiJHFmWbXXZkpdIl6eahMUEkSRRBJAwEiTFIlmrr3qdtU5fzPSZtbqfoG/mAeZ++k38JGd/394R'
    'GZFIgFR1zfRMWWBmZPzHjv377XIDqARz/7Yg0tzRTlk3BZP71w1ZpWaL3TUClZTu3wyFp6XtoG7ZD7/DfjjLrtTjtTgVpuHoHNA4'
    '+fQMRgtVvJ8XzoBh+snOgyU6CgPrUrVZ22F3qcbd/2nmh46cnNfp0WkT+HhQoc4Lab0YWPrLH/f23r3lnTXKz4vsfMJby0+MsZFV'
    'rWSvAz0sZAsZOPb6e5L/dz2Cyk2t1ESFNmHNpX4y31I3wgyuCE7WanVy/aBZXJzM23osV186FtJUPoY+GWN0rgRH6ZhIZskUDuX6'
    'jcuH106gSWh1Et6dckKzJFUwuElaQD01O53m5yenlWx66ogt9aZw6WG6CzqbTrPe+cBhpllQpXq1FkdTKJJkdElHXdwYo2EvRdqE'
    '6EgluHS3MUuK0TnuYTQjZEGzaBWQsVGjzH1/CPx8uW/AMs/KxpqXpxilUEfZSPJBLztK4UFNL4r0HMzaNHn5wxs4Rk4zmSWoN9CK'
    '+d4OCsLYyYyYvkQnhYmA+zIfaaFZ5358/11Bh1mNcRUx4gpb7ngNHUlxfXZKFz9O9Q9cJlWwjFU/aZrI19HjL3MR4mStoYTng6/z'
    'qXlwWXmnCg8eveK5nFEJYrB4fP6eLiTm/xX2BnyUh1B+WHbQO3Vq2bfv9l5/2Hv5zS4NzOrPlp4ka9sK1ErriwwjdZlC6WQqJeie'
    'spE0z8egQJt2D5SbomDySBhPf2B2ky/f6z/8ryZ54s83/O/r7/nPj/rWlXnzu9f8+dXr7/TRj/b5j1onMg3xB3IE8ccP7/mvtPrt'
    '001i0sn+f8ZX336m/3yO55/h+W/8ry/crx+1oXf6z3fauRKEl3++1H5/r/3/9r01SChVPiJgv/5CqjL9hXRl+uu9FdJ/tOBXb34v'
    'XQDd3/3h5VuChH797u0efjy4dUv11ft3P7ilWv+5qUfmhjaHm8ExknXf6H9zukrccEvfzOSmG6az7Gacuy8uTm7k+JzegHLe0DZx'
    'g5i9G9jwb4DKcgP244YU9Uap7o1S2xuwFnJc0psLOeH5TXreH+Q3mhey9Xh9EFoY5hPDhXYGZs68O8scQg6IMYgKtl3SOfyhqtO7'
    'cs2ZCo+I44sM1/3BRRjodJkOz3BwQC8gLQR472ECU3j7CgeMUrXQ4ZpdlFiwy1LFSQMduQ/kmlB9VaWTcDfDN2VV1QRy5882Nnq0'
    '/DZwFdXkF53vyUIUc7/FFMh8HCSjWJgZFeTiRRIW7czyH2VIljqsnUzPafv1pGZfynWjVKQogcnA3BvWvkx8NBilTefjszHSEclC'
    'KOWZ4ApLT4wAufzXQd3snsvfNZd9g/l9bXrqsna5HMtqUY+x0h/KIUTAabGzKedpMJzlm631gc4c4RXuGFEFzjPqLNJ60egd53oF'
    'BukNYvhvTgbHN5dZb9LawoH94vP2frr2p421/7y6/uKg6K4+dh2pGRkTf9nAFi0qL7IFBwbnEQ6DXFV0tuBpBQfFZ5tYkDh9XART'
    'G68IslQV8zOvHq21a+Iw8bfmP51mFIzHObQFcoWOczpZT2GT31o80635mjBJtX2I06ZFVe1pmpby729jj6hURWaXJQkZgPJL/uzO'
    'b024eZAevhnXrSLS1j7dqOzIC+Y0oV/Gc3m7MT+utJ1czAHJVkiQuR7j/4Ld65/eOvcJvmRiXaGvobey/Bk60jtDishbyoSaW/FD'
    'l+6ZRuD150i4fkMI8pvTaeug57ewSwotc2u/S/r3fP/n7e6T7Zu/HfeKyZbRQZf4nI55oO3ltVSqkZhYm+YBke/hyhMFWSw108xx'
    'U6HzjBpiBhRa6XRiLB5zc0eeaRYgyrZlCoxV7AwKsySjQUyH2xyugHM8CtOdzh9XcoZU85lzEii+1Vw0rS6+drbqwP8kgdVHhTA6'
    'u5jjhYhjrJYGqEoJkbO0yam56VbD+Jwu77pq6Fowo87xqcIjV737nNBJFGey4Pm4NiagWaQXTuyEMDKYNQr4XOMhWNxxX+8PuiqZ'
    'jr0Tu0y89d0MrHkPQ2+DwIPL5RfXvpu/A3wN3vrH3NPNive//vnCj1sqjfaRiw0oMzH5VqIYAv+9M3qabEFg8YrHwliI97yD/4/m'
    '4G8z2GgtcGQvsoxTp1JPuPFheJHNFvugVk/F4h2hqz7oxwPDJzt4uuk3xJK52AmnIvjEH7fA3I5pqE8r77PYuM+O4jNqHzewaak/'
    '0BhQ/8Wc/MYwunR69tPgbKCzFE+SfkUlBFJEXsfuU6WYKAcxkhkDRUU5pe3kczg7JDwtPyHcuTwucgicbM1oULzQpe0ke/JbM05b'
    'rAKySkLzcDEokOK+4EGCzVAE5GwSnJZwOZXvv1/377Gg85tbT2HsqswbB3LCi+qKVtcdUrpqTN0NBUiJnJniWcMttht/bQbKc2vX'
    '7ZBIs66RC2PqY2OC8DDeDbEX49xOUfdTc7vHbvlqMJ1dlXfH2DS+Y3evyt+xh6W945k0AlaeyTlCuhe4FMvi9jLQS7tr+xD2+7la'
    '72nmb22Cu4F7wPlYY86ENVSgAtkNKf2AEFvPR8Hugtgn+ybYLfP+Dfff8Br5Vr0kEnhCrifvXQDlJcPtqaA4nxbAR01VveMcJNEF'
    '+H0qBANVV4xXmxYYTjbVXOw+dJtT0lkWeFq4u7GiSYyd7eJL1K2rMDj4hh5pIWtguqeiyZS+vG5fzpobrQ72UD5+OT4ShimfvjIV'
    '1ZQiSKQnmvsQMECeVfB3HHwDC3WejfwGp6xfT5J9xQHVsCb++tOm60ZRvl46gIWzlRR1fElRsiJlA1VMBbx5Neo3j0Z9i8NJnOkn'
    'vtfrGbLyUNfMSBSUm33MjnCkZVc1NRjip8Hs9NXuroue9EGUi75iF62oRgyVt4q7H2qWzvPdun3xzm45JYvbfg4aWgJv6WAzp7gJ'
    'd8BRKmNnVpM5x9H5vawqzr5uvGBL78ztQ7pp+GUPrmmnvdANdJc+xRpjwTKhZiCblFXN7cV+1mLqoH4WhETOs382v1U4ijsdLdni'
    'GshNkeyr3/Co3y1D65gar5QkLJaXT+JqbV/szoAfFThljvrVgN6loXn5uJLvoke9V7i+O2UEy+mzdnL6WVszNjESsp1MplnpaTjm'
    'N4FLHarbwX8DtVCgEkio8KzB5Cm3Kw2whaIzhXtN5MTCZw0MluCYCjktTcmK6Ul0axU4deZJuc5JtwlGZYojpQAxIjv11fJ73Arn'
    's4ShOR8qlAtKJkQYItAUC7swatbqAtTiA6jviCurnuXw5xQxmnivHflxuxK6hhOvdbL9vAcA4cl2I+YShdKpb9MnUi1zH1chZ/Gq'
    'pw35a6FejMqvzfX1hjvq51OwW5NpPprMkOllfIYOCoWEqdEaKxk2lAbThI+YQcZVF3ZUqwTqW6mCu0v5JqVlgfVL/CGs3tHwvC9b'
    'qfFfNG7lYfwUTcL8p/WQfQ86s4qqlpB6dKciC2PuzT9nbvkPn6fUO2K9s+KIvb0FJpz/4/l6uq36DE1kQ37OE2uV7s3ZDeWjDcGV'
    'fqn9SPmPbo0lfddiugba10acrQpBcy9UrYX9yrSth88fX8uTW9uY9odPjPwZRlEmaDXiOzcT7O328xksEcgTmF/Cw4iYs/rs+cxU'
    '/vqqT0zc8rcUsxQtVlN5UA4r1A15Yxdv9FkfaDow2DlpDuXDAikFYL/98NpjAhhp+OF8FnKY8Haw6ihDhUaG2dSaCG4p5ve1LO1R'
    'mmckkfv47rjJNtthMnfWviyfe3V9EYJZWdwllhFUs1VaPnDEB3Qyln+ehymiXexBMkD64Okyi0ZZuSxg614le1OvcW3enSh7R+e8'
    'M/sy7w/o+KNKWTwzowossLyBotrgeY/9+SVzMTSn7eQ+jTWrrcGzX1abQ6LKkkwl24J4Vvr++njq6iLJNvCLFMauBlnEg/ifBbN2'
    'j67jqBFTDwBmydEnrIUscTRXR+2k3Az72MarydOuH/2WIaPVjlYE1XBXzqZlgOLSj+6epbhLsjBRxTWnQ2rVc041Xc3hKglFy3ZU'
    'WGWFJUcwnruM58VD9VfxfjdVdl59sFjIM7tGnaGho3EoI+/XShxA4q552zTtxdacgoleOov7ROmNDvLO6XOB7uqOeqIIxetKVMMn'
    '9qkmHNOgrPI+HZKOZtPh77IrLFnWgR1b/mgnZ3wnH8dcZ+neNh+EeS0fCEuL5g1SmyEUUeddP9X3R/d1bWQn40DJamSaDxhdlD8j'
    '8an6t9f6vqaWa/3ng+JJc21t7ebgCf7fzYcPH1ry6PG65ZkOvg31uV6kqBsPzagrUumKeuWxp/Da6Q8u6LUDVy+9HxZU74HfkjkJ'
    'Mp8O/gSBaojEXA1/zvwMYc24cecCZusnP7QbbNVWdWYmyHuuX7AYOxZKwosAP+9o4mxhE54JX7wf9tJeo7rcAXcxHKhIUle7m+Oo'
    '6438fIacrKTfmmS24bU1iw9THGhRHiWAZb1Ah+sOU8vJy99LMZHWM3+K8N395t0YJXyAywiTn82+BrnZS0+a7jFWQkGkQCD08aX8'
    'sol1VtQ6hIW05M1S2hMXjGVRdxVTkYi/zZTZEdpJ4wOjq0KLcrtqUV4+3wQqDee7pun5ZArC2KH7DjcUqUx31IsZY9nvtrr4C2AE'
    'x/QVXiLmeiMj4ZKdQDrHjkeS9pz+vNIXCIT4txl63LiG1NGnwujz4bwkE1xn7TsaUYDYlnn8Lp7w/jQ9kft46ua8Jm7/ju/zyfz5'
    'qKwMLtc95KmVjfAfXZiHdSuzVb9TFqEQWNbdvIi4QVCaH/JigHLwqfoBQIg7trOkxH+1OZeff4BUsdiCbF2VBnB6YE6e7WJMeNLJ'
    'j4/lb5Vfyr/dVenUztMKaYy7yVK+j63402VF6wfDDi/a2+anbMHv5lRcJKPzYka31FmWDkMpzkO2quPBg79U5VciadW4JKvnccjn'
    'zC8/lLB/FXVjb8nFUAbi4ITGykXnPG6avhrncX+yNXzBlYOuIHYcv4V4Xrqjj/fIdS8M57io8TxfGMtx0YqUIBdRQ9UYQbu6/Xtu'
    'lvpoFE7om9HJfDiKf7M4HsVRjzgoZWFIytzmLaJRkCnHzRcF3XleSXf4V0IKIysvQXQJOUzEHHirJ4PZFssQk0ldptVglvU7gYfw'
    '7oefaqBLdYspnNPWA1Wnmg+llF6thZ+02kzCuWyFnh+K0atdeSF1rCaNycdGpNP2C6He9rVIGXWIr3dcvZDhsMcuAqmnrk9MR01k'
    'j+bRMB1NmhHgcHZRUqNnv91oh8jCT5KNzn9qtcoxlY2fT7yf9rVpy9Cf+lFZuBD+8eGk9SXPcZGdT0xxsgTo1ZakHbqb1Y2fDmdV'
    'EwPHsXAN4t4uLFZ2FXtcu1pvQDPAOJ9JcjdDNkoZUGlNa0wacSflLLxUgy5udziMpuMrtQcLF+2T2asXMzxL1ZpenELTjzthlJ5p'
    'kR70CnArVBD5DJjyVwpL1nlwNzNybVJBzD8wJdVOoI1GqH4BQl3HAmCC7mBb/kqtYN6cRiE5lXUqNuntcYQ8OQwGUVDmQinI0Wk+'
    'OMrqSci3b97u7dYQENZawT7+Fs+acBFSKZbQvSxXh83hYVZg0uJHW8E3eyxVBfiRUnAfIrLGRzWwJN9iF/hoJUhV+t5FMlmxXV/C'
    'J3qoP1Mccdu11XhKOW2jsjENQCHo6XwsvJ+R+nnw5stgJugZGweJl/oKf758xbVkmv1XLxbpfGQH8x/6wONq1BIgkxFjs4loHmnM'
    'e5SMgQQMDUNvmk6vZHqydKoBOpXopr0wmOdYRLMiCioqqlVBauzDVWMiUqe2OjuF24khD1N46+Ns00/Fgpv60gFUTY8m2doNc/5r'
    '04c8abroxdXEfMDwSZpYVvs1BEQy1J3qR8V8NiToIDRI8aMDcGsX+uO67sJ8+HFhURHfp5N5fOlk9/ffJBOZg4lcQ6uj2WCUWSOz'
    'wZB2b2LKWcU7HbQGWXgSiiD2li9p9fozTJgTA4sL33qhZDOZBGdUaFpzVjX9I5eRsJyXco2tw/N4Q67DGdAkBpo5d/+LDYQEZ/JF'
    'v9FtJ/r3aDA+F/kYfz/7XP4WijvlX/+pjbDxK/7+vPPZb4AamWVn/PvpM3wp+/6Uf74Zwzt3JrupcSXbqdHtOmskuMaiYiLeB9fQ'
    'JgxgFxw0OxjBpSbPE5Qpdexjd++P0o9NRB3h9/Ewz6fCW5aqjbHXr9soMbd/PGeoyCWO/+Hj6/FtIv9Bnkf5h77awEYnbWjcYmIP'
    'nZP6RbL+gv1wrrTK0F3KFsxnOBTuTF3Kmpp4gvTJ5tCVwXgB7d6EJin102swim2mAC6B85XfX5SRwpWl+godx4sOdt3tjf3B3Ye/'
    'XPi/giHTH54buXOaFs0zalyclUyfA2AUz7eCZgCGqHd+OwGuWDtxeFztRP2Bic9x9up8egFvRvwm9G6hDAiR0C9ODLS60YjT8ChS'
    'DgQ5ouCMBjJzs6z5d7vv3mrIkf7UMIbB8VVThyu34iC7ZIDnHNC7bB0FqlRyhAjC84lU22dmmPyBZfj5eqogllm8XgiHtEwT6nc8'
    'BslK/pTnJJIIOkynesemcrbHJQlFLL0FX6Yu8U+pwyMnWRxlY+fK3SYeaa+Xf4SX+2W4k3sdMNg4hl98viEvT+OXp/bycw8dqc0A'
    'AbTX+ShvUcF68kwOOv9tJ1d8dcVXp/aK/+r35focPpffzDryZf6RWUlxLq7wn0v85/R2Bb4ljIt9WUxEqH0PbceLlY/fD/p/kP8l'
    'oyybrSSamYXb48UKXCVhRdd5uH2+Lm2o+Tm4usItwpMmtCMdDnEfNv/C7WdgnqaitD1e6B5vuxYjLHd9VOP5Am5BcZk+ESlqPkFH'
    'lLUgdDl2t5CKj62aEkbUeTUH19YuH6iiT1+WAKj2d4iBSt3Wt+9297x7U3Td6ZbwdQtZOi8ai6wMrtg300EVH+3weX9w4UAZUWaN'
    'UK8r238IuQOoSvQAFXLUMgtfjnP5ISo7aT7vbcc86pqs9fnH5+u9bXAP869H6RF9F+UUo1CrA/+DN2Mluk5eEC6EQdrFDJgcYEbk'
    'XFMiAUfCHOYpr32rtfN8XYYVO0+E0OdL5swN2cHOfz2gV61yS24SABHnFsk+qGS2KLlbv2zqHpVOBs3Guvx33d64wCo9Y81sOnUr'
    'fkdP110sn7RLOdCsWlJDZ5QVBYK0MQzuVJ3PWdojuZxmnMPKAlogQsgXYgqC+urmMx524ElToqTJNFTPkzpmuxF+rdwnJeYIDF7d'
    'tx+45NqAJ2Y2E4Ca+hCm/c6T1Z2fH1/fNls3+wfdg4Muw5gODh7/bSP0vDwdnJwSVaeJiQSTOh0Z74L7zynriyO+r8Iyai4o/cSK'
    '4h/fDYUwOHn9cdJkR5usqCU3Q+NkAMcYS3QN+goyKxSWPw9D2oYazZX8pYpTIiQeZdOJbByqTXjwNKLAKAy6JP3EO3OwdnDPGsoZ'
    'RuCMByK+1wzfUKth5sX84qs5qy+mKMW+WxMebsjl2VgyRY77GzCPitTkvXBmprsaAENyg7amFDmsNmADgF9MSgOsNjbYsrZm3kWm'
    'dBLUzzx/FGbTUqIQ3MhyFadIVvUb3NUZUNft3WDM+bDqWWqVba4mv90I16apdcqJcoiRFGr5sTL/LMDaW7W40sCfRNPPk6DFuMIK'
    '1nx5tEr/xIDgxN6Iv9TcNoZybYDW0aLaDpCPfhHZcCgXI/vaciaYL/N8mKVjv/jOiONEHDW8wA/zuFS9uUhFx/cqmvTtwRi/ybnr'
    'T0zA7eH8LnOw+ehZh3Jok8ddaix1L7I//KKXl6HPL3MsbAMyvG7qAN14ZmZSQofihqOa3bLcKox03WyYBeFqN5/OwjkHepz334Uk'
    'QyxEy6mC0NGeohx2XC+oOshe5SO4GgnTaM/bZSBMmwqDMaxQFyKkyR5BuDIyPVpK0LJafE6pQnZ56n7zhHKhCiT4DEtzjlhWf8np'
    '0yFpoUqIXLzqMazukktKV0CLu+QyKgG5p7cgGhTtjG5BtCNcsb+DCxHumEQpYSKdpXucyXNsbg7vrPYw8OUVeQDbu9zWwtEeI3ap'
    'srlBRSsjgzneaKtubU9dNz0T5vLHzVJ3NIhiZ1Js+eA2QNRP/vf/Sg5VusX7I3DUtxZc5h/Mj4pnjTpYqRh1+Ae3Kj/xd1AxUy+F'
    'hfnglnx6+X5+9kzw5kdQa9ims8Q+/khGTCbmGXVCGmaVmPAfUiWEzsnZRPqVZJoTEJy2vxXwL7xFXqxsGHQ4anGOwFpnK8QL5x0M'
    '3Y57CU9hi80OO0WxA9JPIMszh7VwkVZ8YZ+fIwLdVdRL+yciRhE8RpgzkaLk5bYNxzUcQ6FDeZwObTz6x8IR7UIfKrtD1XXosKpZ'
    '9e81cHX06jWE9JqRwt3XT0FlEtAG6iwZJU+QdDvHMxJ/jZ3tvLDx+96F3froGFpz3z2+5onbibeRnbe4u3hY6ethPPV8FkgHt0Gq'
    'luBAt5QcdM7H9BlqVuHrj5iONrtckXOqctPb7PKVPCyXBJpUWYsAFjgArl/gvaCNMpiijnAuktVEjKWy1iWaI5XE1C6llCSVTlJy'
    'FHNxE6UEqMzmVTbrONGBGeqoGoYUKI1pcl5Ap0mfBkdQEbQh2FFnLFXl0PmMryAPml6aEiJFukWq6SaEE5MUhE3rwSbmut8Kr6Ia'
    'MVcntswW4MQWq65Zx3f5dyGLDCCvF17o2+m4zqn7SskNHUZUof64yu5IoiOAvW/7zIgBDH9rWtrThJAczPKJyQEamD8o5kjDx5Ag'
    'GD2KMicki8SwWE/Q2/4uXpBNLtnja84JwlmiIeOK8QkdjofZx7Ue4AI3sSdWtsf5OHO0Uc+mG7g7Ty/7/a8rI7ETlcgr64PwzTGt'
    'm+/Ctu79rE9BJTKCwL4Mvg9TV5z3bFiVTU1B2ewepd2TfjhQWmLwqrLsuLkNkM/P9nIDmS+RxPqIQMZ8SRkR5EbNBlUtLpTIKSpP'
    '5fZ3UcHqEyE947Xi1NHsTXq1czBu/sH0IwgldpmJedEDnbrTiqRgDGgvP5+GIkXQ0RiCYZinfQe/ziQlmsbkfArXspjZg6BbUShk'
    'H9PRRNhcnfRGiJb+cuzeuhFvmszGfnsWCOBeVMQD/zBREfgIbjGXA5chuqIExPjg30SxidenH+f89Q3/Yi6IlydibPflsxN6bExr'
    'NDzoCjmUBth4tn6LrEHBpE6NXZx2NAHTVG/8GpWQzVyo3dGQ3Mr4dRub8w4qQ94pooJe3+pUlIr9uq6Xn4QC2bSjOaGGGnJfarWm'
    'W5WUrmEO97u6XqHY9/a3VS6p1o91P2CjuqVbpT5Q59V5H8BgzbSgX7BNa8s7clnTIhhyiBiUgmdXR+gtW1teXzHf20cB69AIhNog'
    '6UEsoSwZM7objBilW/FpoMnDZ0vjPqPDyJ3LsDCG4NO7ZL7FVUd/+hj7h8lib+67BmQuxQuutPvvsNHS3RXcy+EmG7Xi4xcpetej'
    'z8IdNgp2F4popwPedMHG8Xek5iNd2LCM2rUaQv4GnCEAqC2epjzNUTmHjO/c8+qL3ZnKAoWWZbNgkun8PEIH572wJ3zDdJAOw5wB'
    'mjz0LpT2mhTFrQR2IX7uXoX+gVRW6+1U7Sf65mHYv82Gkzs7WhqLgpLulomGXQ8c/6k48WGVtvvrpugu1fvDpQW25vjnAJ0eA4um'
    'xcxyUsDMAJ9AYRba0dpLA5iWxiktiu3x153Z41x62ST824yf8aVXNehZ1F3MTNzWRrasWyiannCGMGltiyjgXcbDe8RU+dZeRK3R'
    '5J4rj5klvYxWcbnkAl5BTQ8vIlkrmSP2LmZCylauID6r3kGLpuYlMp5+hW2xpNN1U7S4dzvBGi0KrKrgLLAreWPZhVQCvcBy8w7W'
    'ye9TxHRmmgm0hPGGAEwvtKT56z/9K2USJApCqKww7ZO0Lzx8QVTlVmC4IeC11Kg280giBYhgVhN7sDfNsp/4rowVAFPXJuTH11Rq'
    'd3a/fffTB6B/tO1QpEdH2YTBCJuKMTgOo2D97aNAuO3kkXDlw778G+AyAy+sbOHrN9/tvX7/4f3rv3v9ak+I1Pyrl69evf5hr+11'
    'MT5SWogM8PtthIz9JZKrUDiFbDIsV+hic5mc30E+CZ5XDXgAtlvq8r9PqRo+UUEm1QBghLtz6LJnul9R8/71VvhFUB2/ixO1Rl+H'
    'RZ2FtZo0YlnyXd1bZz1yk8z+GSvksZe/AiFPzqrOAr/+0/9seEedDBvYYWDJmYi7UUzu1w9icwJ+bxJ7kAZ/ekMZNlU+HMIKTT+e'
    '//2/Evj/JmUySLwy3M+JSO6nYVH7OJ/qR6Rfcx/W5vdMT4qK8+QjPvOyPmEIDMCvcOjww8FZlrzrFQORXsebsI8pmvr4HJ678uND'
    'G6YVaXudQONE8xZR9wTuch1z0bxS/1aR9Cd0S4LVZxrgx5kFt22ZnDNaeC3pjAwVhQnYApKsejfIaFuW9T7XMFQZu1eQmj+pAQ+a'
    '61uqEMRN/QpS4EkKvyqZSzgRFUgK3KZzgMhNrcAzc+/lN3BDaP58s39QNLfb3daj5v7B5Pq7W/nP29sP3fCPg/W17pPW+sm5Q+OW'
    'Nl+lR6dZ5LBJx85jC2v0ri4BOMdJ8e64OQ7RWnYcwKDJTvvef3GmoBtshV5zDoswzM4dCsKW92MRRqpPD+xfBKCp8XPhHfXx37oL'
    'cWYBLBjrrvSF6BOwAvOGxaGR6Wx1qUGkp8Bo/1m3AgJchsd9pCpp/ef9g77M66oLaP7YCgiPHzoDVbY11Ws5IUSHc0xPWbacJlnz'
    'VunkoR6I5pvA5AnYNDKrqouyXOPcXzw2m4ZU93E2t2mFIzwbTAh0Bx2wfdrMNZ+0FUUz40w2bU9eyuqaM5/P2DCdXvkUGNKRdAg0'
    'oatkoKB0KU+UuQWOsuGsUPQ8NGDYjNGu0nS10cWqmOfXt3IQxj4h7nUQdjLGg1QWrlW1raYdYTvWkl7HEGtD2HOc2HHRmnebcFu7'
    'JTNhDe7PusnOjp4P7JkWBdimpeH1DhVjyyNaIobpPt74C9oubzoZv7Rfxbc2sX+YMgs3AZiwk4MedzsFRXO8OvIuHt7Xgj/SXiEF'
    '1pKBcPFuNGZJXUsqJVrJc6Su3fIYX0AVpBtKBVnlTJFVzpLn1Trhwo2PnvM9EFYUggajaBIDMllNzlrJ31Q+lLatsSWF/qO9CKaO'
    'Lr9/nf5Q3Wmt+a/4UX15XW0pYy/38YlhzNt2YiWrydMKTZAvY5y3IC595lDePEEnGqP/G8IOPGpmAV5dLbzzHmLbVcd2CBsojv6j'
    'x9fu3e0mDNA8ikYgybz6fV06ePjaWt79wKIUOrjn3DV3WMsq0PUKvdtM1lHyj+cj5G4iFTPCFHMS35tBDrrdwi5qcyPCsQOBpNaX'
    'Gm7/PIWyu29PHRvSKvXg/cI8vR44TOtOsgKmZYXmiCLgIIr4ku8oWgWu9tS4hJNc00sJo9M8H0NLRLTRY/p5Zv3wvtexm/Cnf0AM'
    '119voD6K3r3RhEKuwHeDIn6PBy6WQ598a8EO3bJSoXBKyWL9/kD3yD3cfFmyxks36GMo19ubL3X2wjq0qMfnrIJzl12aa1O9GMNa'
    'SvSTUm0fthpcQ7/QJaXS1wX+XEfumgputCC+HRAADjs+RN1thKzLfXmdOc8tkwzgStSvAxfk7cMzGjNdGvdh+xUgSzivsQQOjO+x'
    'S9ts0UPUeJ0bvnYjuB7Umam8H0hkf2n55xv62Ev+v0T4Ao8aAWLqTH3j6Nv31DSJJU3hNUdG7CPlKngtukY+2yobqP0ibJTubO7L'
    'Zy6CxX+PCQqL/xKU/nyrrqw68wlTfrD2Yb3ZhU8fm75E05eVusJO11TmKecvUSfjktxaEZ0NSwcLoY/AFNjrvno77PMPkZS6nuW0'
    '11W3NcCRiWBlqGTBrkn3n3ZbJRcRvOkFb4IDbdTGtcNV3mgnT5+pGV/XCZ+GNMDToyQga5FwW1auTmQiSQ3mfMhUsnzh1SuKXKRo'
    '6w05pQgpawZDeNt0JVsKHVnufIRaFsyaPKa7N6PqTH7EGfGm1MgPjSLui+CG9OP/TIc/m/dimJ14g34pW28+vj5y/MvtFn/Ko8H4'
    '7N246V/A6+qRuTrAG6HOCaHeW+y4L5V5nzNhxeEURoXegHifUnHUx34+q+/k3revv3+9u++U6N3OUbM4TfuZ8r2oRnsVexCMnJNS'
    'RJ5igvRDQJB+9Mvih0lkx+I2qpfL76rW690Vj3yTggmqXBXZ9Ju8OQgvinG09/YHXR/V4q6meqR30Ey16kTQ+p6hnQTbdEv+cjt1'
    'i2/eNicttzNZOR8cleCd18ZrawutMD+iKpfiD7aCvjjvf5cSRGa8zzztNOXUJLMwW63me3LCFw2PrvUo9eWD8F5dDDAX3Mzwo1j6'
    'TY0ZYynmjAOOas2lh1VtZUBjHBQfNYgLQIlXs9JQPTBPB0+3Wlt11e0HJbo7HdWjvRFZmfkVrxWvWHb2OEsBgdqgB8Ptp8PAxTvx'
    'DhvFQkwst/PjYS2qrLQfLK/QkXUvpAY03F8oT2OmdBUyKdeveVcPfpx8UvsarBC+Wau0dXvnPowABOdSb14730PyqT4EvsTiFzpz'
    '4SArW60FDO2t3JW/2Wj5vnBb3Q9NJHA8WWRjH8CUpFb1O3fD6rTc9YoiPZ8JdH+fTszdLmQnZX1jWe27WKPr8i7s74Po62dzamD1'
    'ix7MkijtRwJ/R6FgRAxtCkFlOKtWdAON75iaRqkT+mF9/qhQ7OOucCrJ3ikitrRy86fMo9Ae+Ju1uSEyQmlD2yZr4sPyFQOuRF3a'
    'dMQWT/yIXMIeNEQ5sJMQUxIqdKSIi5ukqvp8IvNArbKr2qPj6KcQQKmBywYMswa+B69guBTJOaIwIaM6ES4lEC1/evO7N9AlH+wf'
    '7Df3fz5AGNf45lF3tdXc2dx/dNN1z7pPWjvyb3f9xOmRy5u5lG12NIVzVbY5KJ4cjOU/pRBjkNg1Uhi53/lYbvLEddJXECh0p06w'
    'g2ZURbFM7AEFQaC3g4EtHQuB6feWOoUyGYFTLi/PB/lJCSBDC1Gpp8ZaxYrqp12fUg5q2+8d3EsZiKZ7mVBgYwvl0K0YHEqfAKkm'
    'Z5RLuRIZPjXxkulG/ZR4Lb864/oFbUVxQNRDzTrMjKScRcD24nkY/8J+vxDigLSgKoGTWmpchK+YyzDsaGlXa0UKHrqcl8otDdlX'
    'uiFiPFQADmUbtHy2d9/M/lCqqwrVQneQIyZ13NdDptOksGe9kRIUTnM0UqmsIokzoRuKQOH3pr+6uuWi/+0j+YQwAwPk05CGNjlE'
    '2IbaARWyyCm1FLzP5MRQ0++I4/lEaLXs3P39d8gDoKSIPDB09cwpBto7Q8y40BHdOf0cOEK9aZaGwAtTVJ4B6vJ9dlw082F/j+Yy'
    '2RMMGg8RCHUJwW9bsTvJQotGL/3Garz7m9KxHw0SBTnHP35TIB9qNXBv6oxgFj/aOBBih/9fPGF6BKzp/aJdAbKDz5o7L+TzrlDQ'
    'VsMCUJeoYyjsl6kEp1mcN5CghVlHWM5ZKQCHSZMq9jII8o39fXSdKTttKzB2pTzxuH3U0mphq7nGzNC82h8UUtcVraa0JF01ZJLU'
    'GxrmUqqyGKUboqx9QELj3U+6R24+2XopI3lFixXVpgGAiAWrm9G2NLrK7m8nmnQbyfJU3aplhORlQ4CozPJz+qg3mZJVvnigVnjC'
    'WWTKiBVCOPua/MnSRFEjf66Z+wpcgMM8Pwv9RhzobKxS1PgN1bPew33EwD7rHUdilw0REEFB6102gs03ovo7SMfrL5dyGSNjFO6Y'
    'lnZcFUbXzDOzCYwcqrM2k5Hawxh+6/+SLTja3+j64F7cEpvhjWVOJwH3Pm9VHe1/1m3dr3W296xsb1lfmHUXdVeu/duq1ZUNRxqA'
    'CgR4aQ03FN5Xu7s7Hb8BqeS1pLPfelcAyic+zrQxT5Uuh0aV/DfQMY8GRYG9V/PKdEqV53U5ZoJ9eWcyhQBENQmxU487mlf1WPWZ'
    'lqdz9lo4q/IVQrEt8cGx4Sazl5shp3esGMny7hIZ6myEamstvXBkToMppaG8gXGsXcIF9RIg/QuLWJUNP33LCksHGzqZYVY5JZxC'
    'N2UqQTYDZxFin7axAdLxVc3pJ+S0hznQqVGUWXdb3QF6W2rEJ3cj5C6AlHWZpSY7AeLtlvUjfP5JQLfXtfvm3ji3rlPTnUr+rKBj'
    '7t27oHdhLqydcDcrZ2/gxVr5ixc+Z5bVuf3Cbdrg4fMXtl2D3FnkpTU1AW49hCPhGAM/J5JVVx4lKwnSvfCqWVlLVkwOW3nakd/q'
    'kyS3iz3clmfMQAWsA5gRpZ3A+AjP6q3kyZOeMEpPnrSTJ4NZOhwcya/DIxnIIW/uP/8ZaE9n2Z//DN5t7Pum0Eoiyms8okxKJyZb'
    'UZ6Fo9MIB41avvqEfg/lZZgADZwVHkWJgub4KqbzHMaZ0tp+0atr/mBpqnefJI1t16c/qyarPDp18QwM+LK/Ds43NtKNShoZ6tni'
    'zGumgCk1I5M2kgy0E5dLbDiI84m53Bqhot8BYWj9dYnb+IYY9VomTKKwY8823ZOw6sk0u4NcS4mSYBs6BtKo2nPQaiVH0/CMRf0n'
    'bQBHmpsMG8rznEjHgiOcz4zMDx8um0YkCzBHR+PZCt27KRwWj9yxIEqIHLtUxj5eo+yBTZ277A66xZjEPVn/+dH10/az28TxDDNc'
    'J/sVHOfG6bNGV+YSpT9rf3Fn6c9Y2q7q7aRRV6hc/0bXgpzRwP7ak9VuWD9ETJsf1KIIyT+O6ZCV9WmL16493e+07v7yXeW7EoZD'
    'w8XO43RpFh8TrjJQUKqw7aX3KXVbIg4WkPtETFEhAZBQA0OZ+TjbVH6aEY9ZBcktW5bQm61oqE1ChMGyxTbByJxnWZmIijuObWi5'
    'clvXbGBgN3p7Y/DB8v1u5VTu93nGwyA8T5nUv7mapTFOKbQsAVHbMkFW0inR0FJmM9euOvg6CPPnY52v9HhG3kPWA1Ghs2ku9xEi'
    'VtX9AoKMP1mXucLC834ZZ4m5aiQG+gWsbmDHGi6j+sbWqaxr8Yyxz4Sn9tjF/PspvOZc4qRqXqDbVh2IVez/GU1zaRmdXzSjgykN'
    'yddJ40ljUxi1deSaEenziYiZqy388XgdJ1WOK7q6T49ZeXvQbVm5ogvxlB880b9bOy37bCCfPe12kU1Da//wQb75wLo/fAhq7lL9'
    'mzQOtdihlDpkqUMWwt1t5YBZyjJ//rMU+jML/fnPLFVokeR2/+i0q1HtVQRQiPfCgDJ9JTFAMf74Mhs5FCnKdc1p6A//cFTvUzid'
    'S1dQw/4z1e0dRy8QsmBFxy21oyKfPdxMCMPtK1t+LLVY/an0prqFWcSQlMUJmBWH+9G+du2ZdOhpN2zMwdeL5Gyp6n3uFh68eWnd'
    'CdqNX//h//WXG9SAlrY5V4xQ1Ru0I9huvU9wJF032UiT/60jC3zR9i6ZnheOc3d5DeA3ecU6kpayDP3iYMg4sxTXTd63gQsDopC0'
    'pxr0TmWVuqvp3RDnwQ6S35T6+yrUo/MNryr7F7mFm69GmTMd5OUIHlx+bcymfT9lKvZarEzV20x9AT9uskFChD4DguiVPQAw6NNn'
    'G4SZl6XfNNhjmbr+prp9NMwFbDN5/+7d3oev33z3HaLv0km2qcr9hupm76sIrNGph35E89aK8VyWWrgB1aRNV3/4t82BE8/Nt/N7'
    'aLgUytHWf8UAf1fKfJQqJ8w+xRtgpqp4L00vMl05xG2axJTf0G7gcmuakSKFUVc+6w+mKqYAUQ4e8YV6pqIR1ffB+iW7Gra1tpra'
    'GA6G8wB+ky7pTbjnM0TleDBTL09/UpQzUcDiDDY0XJj//i8dtLACGAxKa2e//sO/rbjCvXw2y0emNg9HQD9Vrap3pSslgg2Uz73z'
    'wRAuSQBfAd43CIbLQ09k/ghgNVjKNvbRUWQl6+UfzcmTU8yCQdZPlqeokX+8h+E5lqbgt3LNL0N/KwRj4pmzAB8zh72GaJbh9z4R'
    'a7HUkDNMZwhEUduJPNsdwJlt6E08zX0RX7vkSCCUv4hsR819oawQ0aZaYn9Y/u1KDOMiIZnRtcGpyGUbcJMBd62jv2CsA2oKdUjj'
    'jG8iS5Pn0nYzkcct645f/k1ZfKuTBnmaZMLtZbsEK1xA6vn1H//ZTLayie3J/wDfCOARQAz9jxA8ubjClW99hrSCLxmeLF/BMyp4'
    'xVEo6iFfSZF/jnzTEDvG8dE2tpM0OWC6tsmg1LAQ2E2Vb4TlQ+2I8qclyVJk8Pqv3qqHUPCdtz82Qti2Oqe08bDqdTaYBqBjddNA'
    'R5CinNBFc/I2N/KCLlB1VbjrM1ynBhMey6x7ZzqT/VaRD5uu2Na1Yc9Bi5H2oH+w/d2uJNz+DlVo2FHSpCZz4EeXgYj6jS1GA0dT'
    'aIHOLT9qVBHXuICo6Sf6nWMXkqCOsnQMBJ+VqLsxstZJbt09yVEdB83+bu/vz7ni2dLHDpG33W6JtLWwHWHorKF+NCs2kK+cv4T1'
    'fWX73/8lQFGq4IfN0x93IqvUqrKP1gxzjXRSq2V65hKr6laHsFr9EslgZBfqWgM0aTyUC0EVf/iD93ZlGcsbY9MpPEqHljIQgT5Y'
    'UjdGRHAnrV5rxODteTgPAUMxAEOBcdck1ZLdSKwKB74wcJfyLmLUUrsfcYlYsJYmkrDQsDBullpHgpOFBq+yYsyLXkyjo9lHWRXS'
    'lMMvNjaSp59NPiaPr79+93bPQPfpRVWTqegoGwyb/F62bnE+JaOtdVvQACBr+WcYuGuVCLv2W5+wKDTfYAWomgb/0Rz60Hucch6U'
    'VFmSNc4+rslpLrOSDfPxSUFre2l0tMvdpalC/hjHhgSQqMPN0PYvEqCG6K1WL+poF99uPQgSRrkS94ZQOcmXuHed5F2oIfrZMhQf'
    'eRugq5zkrblcuMoKrp7kvuMn+RxTWM8SFtmw6rgn7ZUmBZk0gtPHi7XaD1ws+6yCfhyKEuGaHTre1F/TLtWUHgdVRVjnl61B2PeY'
    '+XrLAbTpcaE+bx735o7lqiROruDLzCfGqZ5ZV9iUKfdosUyL7LdI1CpkJd6CIGFy+7JKpTcVGDp1rQIrVd4CcxC96noVubHnEx68'
    '6Mqb8SKKfKzvN5z7O/l+knOrn447cyMv97SNptbtJRLW1ny2vJIq1H/S3QkZA4tqqc25V9P9T9keebAnH4TKf1dv28nhyw+My6FS'
    'HbmRWHfFXKaq8+8HfOcwmo/qRLSZD8cFYNXBezu/wCCUZCNQfDEl9QXNKxV2S4mO84u3HIyuyIvkwqbdPMLsRUgaKtnhqydKfd0i'
    '7M9yPiBrY8RtJxYiATAehloYxAPmoSzMiEJqTeZDuebmCD43+zdwt3nMuQo8L13UFj2t6hQyVe2KKmhyp6EpcZUpOVmk5ALlyz3V'
    'L6NY+TL666peEh1roPu4v/YjsdgwLnLuvBc56BJwf27sSz348DEc3YQjZIW3Lv4sjMNVrUu9F/ncabxbrK/eZEtPdHDHGYmueHY7'
    'O7hQd6GAxSbS6gGYncaFEX/Gnt6v+V6T8VGqmXi5qpO8rPp497Kj3HIQ4YHH5CCUAAA3EOCbJitf2u+VB0zWUtBM5d3d2t7TmoU5'
    'TmXWk+YKz/MmNPLvINB0uysVE38DTnKwy8sRyYb9okVNEBqyaMgC3BY81Gez9OiU3mLrHYVp4AjhhE4VMFtXPE7kCMpl6LMrpiam'
    'F4eDGmmrK5liKaAdzq06oGnix0k2LhRo9HzCws5mVlCz9Gakc4zQaP0WAJ7A7TWgOo1B7vxpMDEbDVoBW5sz41Y6K3tnKxDQI6kH'
    't3bWLx1H4SNYKpbliGlSOoqPpZ9574vPe1fqtSg/sYt/FFn1tyKdp1fk05rpLO815R3CaQlh0Dk6TaevhGbQe6Dl3M6v0tFwdwZR'
    'jzlPDxuPr81AfRFYqBugdyuNxkrrtnEY+JlzSv5+MGnWa6idn54hBBXpscq7cqL2IDA2LQrQ8Fadn3WbwKbvjg23AhmRAw/pVrvM'
    'w93Vty9noQv1YhfRZc7sFTcGObZhjyP/9nsFzpV3gosMTmHZOyvDTlVT2cQA6DBdq3W2jw8fX+N7AC2fra46XHp+Cveumk+3bBL3'
    'IcJ3zeU/thPqKUPcVjE9arODc9o86MPkrVnA1n8GRdtk9vKD9eZkfHLzx0l2cnMyOL65zHqT1hYq+eLzdnM/XfvTxtp/Xl1/cVB0'
    'V1uP1wcV29lc3gszQn1Um9LTbh18GRrThHqTE8z3fLm5aXcz1xFuGbk6Fi2B7CG/Cgvn3VVSTj8+cytgjSsWunOwlOfM4KCn4HY9'
    'JG12K0qfOK3+WDfpfBnwZsZutCpm3+SwrrYtl46X2XcoiFPO9jp/pzFVY/agKB1vU0XBKdV0Pu6lFNWjKuRy7QQoquN8vEwvPfI6'
    '6U6gNGQ3sKrXSafTGbobHT7/eqOr6Gm6ZDlkGbIq3sryD1ufFpwfnoi2y2EBLsJFAAjXFKR2Hnc+tsg6Rc+uWp5HMsSaGmsUAc72'
    'G+Cs4N1C9xT8ICuFH0jgR78X2RaELaVzGosgnzWejE527SeuTCJR+tyuXTNy7Z91SzBQDAgP5O99B3qipjCqn+A0pb8emo1LP+l4'
    'vKgZ89EFVFABl/ejuqRfJZfG5Ea6CfVVh6RET4MlN0JptgN6idJbrFhPyOFD6EPT2W23e8g97hIjJaEVr2STHTbNU8dzllWx5F7u'
    'XA1LY58/SA/pNN9shkQMhKq76uhWSbbg8tBaPxm0Efomm1LGFRDHwJQdzADHfmjn0JFqzx2XgVXwQAoHHujpoYrVeQj4ZNtTAyZ2'
    'MVenMjJYZwpvvR9SOSmNR48Sx9LJFpIDxoI4ieQLDhFSqJls5GQc4WSgR2EfQhwpHvFlgUJ0s1Ite9A5+XhB35RTZsdQyFMI6Rd0'
    '2So77jhhsVzKzU3SxE2NFdlEUD0TZASDAQFZMBgwesV9hhPQrOa1ESOQJekugMfG0v2sCf2VPGgOjRzs8HiQQrhHoFbXt76cGSGu'
    'o3AjLSLr37KdEHXMiCrR64ceIGLb+y9QNMew/ETzzFnKGx1x7PWYT8hDNUSc0AVo1sE47B+qdCAEbTNZCabXFcYUrxzCeW6/KwM8'
    'VK4cSEbGW1azqjKrSgu3njXdaHTvc3PaueqM+v7C5CBM83Uw5l7g9iqfBLfo+Pqz9q0GGY35ykInEGs0bszHKwhP/+VQuGhLstAA'
    'eungiGqxdXlXQTPwrOJM44w019p88Ob+wcH65pOdlefbN49+FnKkYU9rjdb9dDHI5cZM24hJS/smewCNiYA1AI7MYP6V37I20wFo'
    'J+3z+wrTTU/bXnLb7VQB98/HUtFc6t/e+bGx1qWE0VSUfWbHTfHgy/PjY8jYLVUuMXxT1oeh91JBp8f3rbYRkRLaUBPYoYiPT39G'
    '1swYM7x30GsX8H9GJz571qQTAcVpbtWNjxtfbPzm895vNlqocm3NKy2ZpQ5wgadgN9Cx18JETJsrexDNzC0TK83RrHi/GgQIVBqE'
    '7uQLJ8SH0UJIDbgBnoBJrMrPnn7hPtvwsj/yArKg/AR02nWcU+uUUNBhDZPw+zZTQVe6hhLPyhI4I98xvL1azbPfBr0P+O1pWlP4'
    's7JGKK6yuaGx0DNfiCnganr2+bOaRjWBBZcDlqivMjj1IdC3z1/cM8V5j3tLa5GJ13+RhF1H2Kr1D9d+oP/yn7C/7sUzt4aL3v/W'
    'jwl5tnV3+s6Y87e2tqoZwgO5BgND9IOhMK2XoLsW/2VL/ILIQbjwjNiVR3OT00LCsy8d6JY8fwjzXNbz24X16CnVeMxiIrOkyT2D'
    'qkGUMyRn6EwGk2xPzsj5ySkLYUlGhE0V0rCrpRpGWdbkWxlYq4NmgtAz5VVkmV5E6yS/dJOtup1Uj7xnyUJH8JL24SJAw0SeGzlr'
    'hgBg8SHMvlzM5B86jQPlM1WNypG6QJ7zD7DX68pbr2ukRxvtmAJLTqdTPHWCkE5Z3SuIQmq0pUbGdDf6XYwo0KqJDNnLv52Nhs1R'
    'PySlpvqyxK/hyUeXi4DRJuJreR/QBRYOsLgVmiIIKSd6iLiBjQ0AF/XdtSlv1pKnt/rmMPBRU0uRYywijpgRpt0bDS49uMEfJTyB'
    'NnjMBtcPOk7k3wlkfpHt1cn+uMXsXmDzaffMRr2sDzPVsUtquMI8ZofkIsiZ1XVIO0BGff/nFtUH8q88abnunOv4a1o6py1srtbm'
    'zvOHD1s2UnD2qPx0NpsU8FdmGzejVLit3P3Z0tYaz9PkdJodS93PVrYfP32+nm435ut3ntLmJ32jvs30bHZ99konpKASxp+wX0At'
    'qO2velZfes9q9cBu7jw8eNJCrO/BT63AfRrPL/3sTJ6ytckz3+Lj68lTOHtOnt0+H7Bx+QOND+oaV29q+lLrFBQceLEd8igvXkgh'
    'CEkvXmghzQf81LIBV7CwZnGwy8ZG86AvA+JP1+2BzQ52s0FKHamJowtUKT4258mtIJHZmCdn1A9amB6Md4zPky4rjBx/zzMgA4eC'
    'ZgwH7mfW6bno8Jza+WUBQ6byyWzHoU1qAHOF9w4P5Nn1nw8PDy0mBd+0qgagIw3qkh6yEnu3oHcUtqpVcsJarEhpgj1cXe36i4T9'
    '89fG4XOh9MGUB+wzZh4vD1tbFW/3W69oG5XzACQN9tDrC5sIKPriVs7UarPzRGhFixPk2w4d2p+/SJ6Rgpw+Q7I0kkuqwtALeUba'
    '8fz0s5qXn7GHS6a9eVA82V978qHbghQgfzyurELZpcbz0+l2Y3l128vW8JeAlC9du7geW7hfqqsWGCC3D4qd9XYsUPx8sC+nf/Wg'
    'u7+61t0BloPqCl37wTKXQVbI3B3fVb9UVj0ou2jxdSoAIXHTkf9VJ1VHyNfo1ubOGgWwaMDgbrul+Tg+ChnA5F8kDgFEJaFg3Dc3'
    'BzfeEmtokaD0Bwetg5v1VqnksN1y5E6onxvnGJ+C7WZ72nUw6qteS1xxu73n0i6aF1tmesfpne3btVNat3Tkbrafz9BX+WcK8Bv5'
    'GShy5J08PJKlkx+BPwgeTLfxVD816By2j6+n9jWqnEb19V19/fn6Kg9YqfzLXh6G87t41zQZ3HcjNwFC9UAhlh2qwSwb3Xv279EA'
    'l4GGHJS9fiZEYXfutVTFdj1wdWtO/zcaBTdCSfak+dZ8+0YCS40gmXmA6LAVY+L72QT5tKh1Ph7mIq6OSCbLG26m+gGESXlV0Hry'
    'DBecagc3hVnrO9wHUknnHjAiVENIPfaTj/9VeD2lHKNnxEJ6VkKgNpIus6E0fv3X/6Zatl//9b8jC/xtMA6VTDCI/XDCwIx2Vb+8'
    'qvHDq+Vchb4T7lJyOtBo6eHYjwPaVDMAp6dWFzsjNrd2A2W7HZsOdD8fKtbusFE2ietLgadkvxPh8hYIUn+ErQDebr6g7bU/yl6L'
    'xuc2yP4fux32C+oK62DZO13nakFfznq/L1JmmyjlXYqdMujmH9uV+oU0WYfxT4B3fLA+FNZOVlBqgUrrOf7GLfZHQ0yfv8r0/1jd'
    'KiYAFbib1bdKdJpb1nYolZVrlAS1uJwVWpdUtR5Mpj+w3nME0/7HEsN44fQGc4Oa7zM5nmTig2j0t0toklNLUBXiKMwS+lLZw8aH'
    'Ga9zUNwIR3azfVNLgm6ie6E1fzGgFwsYN9MxyPtyfuqL27hCFk/WlmVB4XWRHQlHRmOS8cn2YWteOI/QWyE9fz2VKUSwHdS8PvC4'
    'GDAN6spZdrWpHoorxp7T+xw47CGIwnFZSXNWQbmqxF2u/7y2tnYwbgIJerf7ZKd1MOaDnfUyIqe0KO/DZ4DAhEFoqym7Ne8Fth+U'
    'B79TKDyzQIfoZuDz82M1LwfyQwVnTPZeld2VNV2r0nl39nXjsFkuHPq0bw+6ukwoVoL6BFR6f6XRvcF/HL/Tmj/O80PylqOLObZ8'
    '/+AyWRPxbRObtNrbh2cX1eBWe8xkLl7MKVuUN2W3Y4N8ZaAm3Mx1XtbkQit6Fl8Nyi80Ok8ajou6kMYvqGs0TPN2svY09FYxd5WV'
    'KibS+s8rnScrYTWa+haV0UhBoEF5seVTv17XtOT6rANbPPQunR7j87TPj3SDWqVBoG+ryzNW0cyr99fv6Rjrlfp019U/oN7RX85i'
    'lGleHSgK1lvNg05uDlg3B9LRtDhtHazbJGSavC5w13FwaHVVrh90Rn2v7wm/tcD+WSA5O9lfMyW/zR0omlShlh7DotI42MY9EhUr'
    'rEnZhtyhn2/QOPDQZaE+3AOxUVctOHg+vg4/uE0sJVCRR6CgoxQqvqQY5ped5BWS8iT5eOcwzpKszo3vVf9YX/Gv//Bvh8FUIq25'
    'gZBgjakdLvmqdbJV8VsjNvIKyPDOLKy1cVAOIJRtM8hTVyaz7wM4/hwac9VBw3FW/tzhf6XW2NcwaKN35RqwXFZuF+DWYEP7WbWn'
    'nUk+mU/ikHXDTdW7+qHU+S+td2k18Kz9ekCokuY0O24bBKVnBeUZvEZpRfjx/ZtXuZycMeLX5YXr8SPObWQ86A+mxvGFw/I2NxAX'
    'vQPXK3otHRaTcjWbqGWHdXHauXqwMkjbldmh3BF9W67OPb/FMvHbYGQL1qKqMzOVN9wWSGe4FlfmC6sE0Tkq0IIAHfwbOEtoQar9'
    'IwoZunLBe6NsKhbaQlhwB59WQVxw5BEY3V1dE88laG8ytk+21AeuUwul3jzl1acjscdqKFbTtEx0QOzDNx60qhxceTuZMwx6Fhme'
    'NHa65C68pSctc5GeTxlnm5nH7gSmddCfE0QO0Fjrq6EvqnBdgXsLGF5YtUt24NGjpOm8Om7oQiE8UbO5s7mWCGc53mkB5HGketVT'
    'tZTY+rp29k+75AkAvW4m5pLPqUaiuBhkBkiUYp8bp7oE1fU0BAP9+aHCgUIGdF99Ehxol/+/eNJY5CBjglFFsaUIwCWsqS/t3FIX'
    'Icz0BxeuFS0bhfCgsTm3LxgkZGNb8fnAQXm/XxosuvM6LyVgmBnnOs6SQuiIzkSvB7u5QRoSxYcxHEBQRiWLdjO3cdZxinAB6PGx'
    'w988jlZRnlJtrf5bmiQLv7YSXSSEfL2cyST2zmeZzIwfQqNMElyWbNasjXngLbo8StWGMhhzHjvqhEKfYIOAVO6r4b1TGl3nTghH'
    'E/gTzpdYFssRoT8BXwEAi2ciVjpgV3ObN3/uQelT7+FfXaRnGFI+MThJ9c0eFOpBoVSH4Iiuox1DdAyHp8/qhsU30XBugrAUlzqn'
    'DVPWeou+OZW0Kd+pLYPdCyGj50SPR6ZPngtP8x/JlQqMXHdJJo04eyNbAo9mv93qQ3elHAxrsUMTYnV7XomphfwhBKrMy/4fpXvj'
    'GU5js9EjVlRGZ0sVdWnv1PZCyTaJNW0aKwNq1PY7rO1pZNvZnIt0PJgN/pSpa3uVGCBQZwQMVKlmh06OyA3nzqMjdf5QBo5Gssu+'
    'pG4r4EU3K7dFYZA3p5kwFjPEDtBsbYEOxZY56kZBHmGIQSdg7NXKDPnYuYXh96D/7jjOXlqmX3zTd76WDpOMubfUZ3bD6RQ9Z0oP'
    'Wg03WhRlhBpqooxCroGQFLZQBGoZcIMMZsyKHsgJl2MFDwP/TMI/CFATpYUiCoDmr+KX6awZ63SrwFBnUCsREUrLGavarIMZjwOz'
    'MJNEQJWuzrvkY6YjmjbiKDkoMHVYi3ElmGvkMwBYlZzh1VHnI1XXZ8nfcJyt5Eny2bONZE1H/SR5akFfUpIJ5ZuBMvksWbePkPxD'
    'Cj97tuEXZGQOi/JNZW1i/2aR+v+veDiP9s+gNPA+zmP9GyEC+BEoJ9z2cJ6SaVEMTsZAd7muRLhV4tkiNU2JGiTSo573a0cG/Nvb'
    'VivADXePo2oiL2m9heML2Mpslffv2Byk5Q+nYfAOmS4EfNz5gMMgbVpOyyAIsIICN+h/TQgHshTbujchMFh4Dx5XfRNrAhzdTXLz'
    'qLsOualW0RFIaLLYpBnKC1dd8+PIAHbewzXJwHY6RkP75YKzwn2+7igt1cEaMMX9WojVdvz8g5tC2zx1Ci9p0vMd0PRjRsOHLdfN'
    'hW/NixievuVSzpf0WaTGHWzVudx5jkrgFtUiLSuKqGWS1Lkj6pSY8q270DqKEEU4vLnI0zld5loiAkWz82SntQktYWvH+wqpB41s'
    'CEstMBqVE6DWppC5ZOoGnSYAeOelc3Vlyks3i5C0agwfJH63A4bBKBSpmCZi3Sn0+g5yRThndKWw3gKhCBJlHOkmWp1PBwGvaBrf'
    '6K2tAY7JKAJeDzy7A5dwDTukt7f8rHEML596x++Sa7699872+8b2cxhl3BdG8QdhiuS4B0F5Iu5QgTQdCT3+UwbyxpkG30P8PKF0'
    'jMTpayx+gZvLJRzb5OV8q8CbhfERbUWbCfgAI6p3w7PVwKop9x2lVCmz9Czxw/OIaiNG7ZJY1UOr0QH3d4N+0azwEsP0CnHB5qur'
    '4IOTqbpZa64GVSxKoTaFeCgC0RdLXwRQEyGxwo9FAG7HGhCPjMLgCA3R83TQz74Fd9MKtIvvJhnCQR9fhyyKKRcVDGvl8bWfZo2n'
    'vn2QC9f96FTqoo6Y96hhmWiIM+KS+dFXgykim/HSZbkBjBw+naQnSEF+lhXcN5PMlLTI0bQp49eRw9m8rTGvNu2dB/j69bAGEKE/'
    'TU9EHJxWQTogPu4J6SuOs+lOB/JOsRPoRTFJBUTjOlQIbKwlDeaTefSFY8qdcaMc2k5H9kiJ6RYqe2uatnIiococlD6PHQsYNPd5'
    'uRlPs3EzUNnLfJOgZlN6WuhCr7zKz4d9eJ9zezFQmDO8mazAYXY6FVJXFLImernyJtCUwUMV3h0oRbCuNZA2BLKcn5LScIB0Sx7y'
    'grOiKZGOLeQFIstmcty5zHpng9n7bJgiBp7KXKSDMZ5UHY6PwRjp7M0Da3iPfNX7OiNBnW3jPz5hNeH1jIMkAQ8zpiGkWv2OgeVu'
    'oBr52OClkuYKwr1xFPLpSjtZUQ1RfwXO4eiGwdNllhO7hCikQVRoFcIjpf6v8nN5saapqlPDqZBTVFA5BJYEQp16lRtmIcCi6ICt'
    'OFZ61SKjUKZYoXZVosNferBC/oms0fm0EeYDA1ixAUr1gS8usmM6DC2uMWaIJWhSz8aqAWZhjmrfOFmckPCWKEJ12dFLYQits5vK'
    '0uLGhrjTfNvUsKwWAS3eamqpzscWfF4o5gQlroISVyyhF2ssFbh5U7QsiAjD7HjGcKOLQXbJdiBkPUn459nt5OMhVmBSFrlikauo'
    'iN17vna3/23G4XbrY9p27FT4wvPJvf0rn647eFYECQYUXThu1idoqX08l4pVllJ3CNQNZSqWYFEdR15NTxDvHf+BIc1UWv8kwJlw'
    'R7mdMz9dTONo3aWuBHb2vzZIzW20aW8f+G78X8NVCtfIIYn8ZchKYU3cax7laMmoolScc32Rb4uLk7oruTdcgKs2PFsCmUb8i9Ik'
    'PDxbiDblKdvq8KyEOpLP/aAqF4EwJAUhQoRLnKXKw4H6uoRuc5cDnY06kyvQ59GkMGBOBtURnGMqW0Va3VKin58DGvYoR3kgjjb6'
    '2UWDDYwJ8KGhp+CMrUFHyl/+8MOH379+v/vm3VvcmM82nn3RebrRefa08/Q3nz2T+UOBH3/46uXe6w8/vidkLCMYNtfXp+ll52Qw'
    'Oz3vnRfZ9Mi0p7LL179MoaX8+2x69vkX62rkWjPGbR188npfVmpd6BAUfmlPGNuXkwlFIpumzbBfbdfnTQdUf5SO3+g0+kc2rfBB'
    '5BOQXx3hm7e7ey+/++7D7t6796/R/7hDm+N8zT5eyxEwKN2qeEIM87T/Er0MkkV9+253zzlyBCNQbUs6GTQb6/Lfdb5qtCqmPZ4e'
    '91XHbQFk3qjMtpCTcIFAWLiy2KFkw3S6IMmAoEUI6b5+K6SHlPtCLoGvZFsM8wlD7LBtaPz9vZWEYr36uWuy9+o0Ozr7kX2WNj09'
    'fFgdDz4AVpGt1DsN1nRnq1q6NQ+RdFQ2ZASjnTz7zcaGQ718m11mUHMJk6NpE/wZQ9wWBH+inSv0OQAnkOwtR+hORj5HHUCAVATa'
    'MDY06rkI1bE0M7WZmdsAYQql6trryNY5jEZpzZx20ot0MITPsizE1C+PNwJHGXgs6DUDa1rZHKtJw77t/LHIxzuzF1i3r6RNkXIv'
    'IT9L74RUQOkom5yxuk7xaL4d0G+YuZ11iHgWrrf1+CLZjrbhjjwp8yxVpitctVE6PnccH49KoBC78IOLJ7jUg10o1pXW9WU6hYdU'
    'rKBy9Ruz/geF3zYBfazbw4ajXlml90DN557X5xAiYpm8nBLdGykVB+NsZ8USM0bY3mFHOVQcF60B8aZzB7TxktYPt/75cWKIRF+Z'
    'f5BsWfD7Vx1/3uPaoP5APeGxvYiLfpPPNYuNCwqg3ZXdr3DJyPQNQockojV1CMXGjo2y3JdFZNAhLVhYwt2UniShv3NbaHo+tg0U'
    'CgsXJm0sqa+tsKlx1++UIKr4URRA3PH20LKqiaEZntes3EEUC8lYWi5K4MTaLNoOVGCbHKA9vKJkOUs3kdjdHAHy7kg0lx/7+AZb'
    'OzoVGSTLiw68A3YuSAYuFp1+F0AbKz/TJR4JacMXTjun6isgHbFiKuHI30GYL1roogPQsmyGqZEpq0s1fp5eLB9NA4VNc+Q6cdex'
    'cjs563cSaLb8WixrSIXqK1hB3feFZgwIkn/nwz7FYO/Lf5LPCwQhlalSlmh76BgW0Jb5LDuA6S0PoWvtrsngQZJt/+s//Bt7bRxL'
    '/VUFrImrhrWvY4A+pOVHEio8tu5se88PMukP+uODhuLYyfRVBqP0Iko5IKfuD1iMfkkLQ68IS5DkEvud5HSuZP7jYjaQq584ey7T'
    'UoZE8PShgp9i5x7T9l7LBhMXAy8opsJvNyJAhTL0XWSu0aDINMopYGymbbiOOo8gXYv6u76x3lh4f1s6sJwZ6fz9bb5ppUoTqHoX'
    'tw34kzL/WoUJxf8APwCSKwIytmWz1Ot6+hmodT1dlmJBoe/SmRphY/Xv9eL7gZuXnAiriVjKmnoopX2fjc8heoX8RQBtyZVRTpP9'
    'KXcV99IKknXIVbeyKVvmLBF5eDCmBSKZDQyfEltEN0h8rcf8a5AJtGxCF5JPHj4kpMOuLJYcEpg+38yyUTMSQqrigLn0nTJlhWeM'
    'SyGHBiX/3Es6apfLLcVcMHR6vZzPHHmA4tpqihh2NOjuO/xuVUvXHg3fj+KqYCgCpIqfmDm3aHBbC2/hOh4zNDvJG03nglNMUstM'
    'VIlcM+ftxPlJqv6f+awNQE7p8GBmGJwu77Pn5jva7ub925W1Lv4KzUZWEGv7y9k43MPm7Oq9hcuLv0qDB26JlDjUrLc7OPVSlbPm'
    'LF2gYHGy/kMRoewEtHXkFQbUK5rLdWoE03zfGuIpb0SceHy/lDflwMn3VT27069U530hFapQhYVTmNTV+javq1LPe3TQi7qDLp8+'
    'jYX/hQ1X1EVyfPMpdLd1RoNZNlnrXa3hXyFFRQHhAcaDyRRYwUfeNmkYtiwnVM9y4MrmzQ1vkenMLMu1ZUK3fAkFmuJlljk+SGo+'
    '86cgPz7WJBID+CJnrFqkUal6zJSScJ4ipS5CY6lWNKSaTrVRKdo5lhszNUfkmcLBoFJKo7L1cPiY3lGYLyLRy7QIcWToxNmANkMH'
    'fXucZWYdPcvQPlmfDi+H2Xmpz1WCu/fj3kKlkJv/RmDOYJeyC+7W89lOB38ThTNj6I7V+tXr7z787vUfoH4vvk+PGML6T/9TRSxy'
    'kg3X/vnAobIcPu+53CTnA+SmmSlEhysJcxedE1BYARPDGEAn2uAP++kwzA2uL/RmpaZJdzJA+ZqR4dr7W7JJtdXqChyfT+nyR40I'
    'XMdzwAERtzgnW8dFIG+SpdPhgEWlrUswYrZOxNBlNtLUIHeyjyni94IIPZna3QwpHiqReWU320lvAy7fNho+2wqMjNw/CjXZb444'
    'RaMSgbLxPa5+WeyUyO5lLT66B3gQ8Fw27F6A7zKwaVC8z/NZc8waOXXj+RkLaylFT/bp3iat0JuCegrDyqz0HpmUR+FmaLlxSrkf'
    'TvNZLncP1MaDIoi1YdZAIvAxv5A74yBz7sEI9nh9wFSBiGmaALJaEfMsQnV+5p4nn7WSt018/uoUobIjQhx7pE+0vD/3mQIxvMGQ'
    'gsgdLPAGg07CZdY4Y3T+O1At9tHR/VfptCf7pz/IP8r8RF3lYvUWL9ZzWauo472o49Lm/h1VVAZhLiHmLWYOHq2tOe8M74LReClc'
    'GRw+QAvtUDhfWhwwJe2wxo81IjYkYa9/2MWcSGXXziem8VM2VOT1vHIlNzTRqTp6Ng39ZrLNADZ/61ymQ3ddGD2my7Sdd2OWQYP7'
    'IniB5OtpnpG3hjbBOILaWwl+0SY/S8PlFRVfRJotSjtBglN7B+Xjo6xy93QgOLJzJznjWtTmLRQIeOo6BFSaDqlcS85ELIj75Gjx'
    'bDBZ2X4zM/8U8lXJ0w1kkDunUtC1o4mUMe7xlcoTHrb48fW58Hf//i+N1q1efiaE4lANyZF4HkuL7khJG7tDO57lE/bvMLltR2tM'
    'nycyVyNPFYBIBtOWvH4kVBlOsLXr/ZqZGosIAt3EH+1Smjzvbft6cR052XskEgTA/t9A2nazWFhqHiKXJT0YoPsptfIyaxr2Ha/7'
    '3yGCW5oI3Q/YiuzYQKtm+QKK9MrNxeDI5VmcZheDgjwMM2+p38Lzs15/mzbN5+v4qbkhQWCXLPIrc5EoXSm8j0RHa9w9HRzPVsN6'
    'bbJ8DpDMJ2O2arYSpJxSPLfLaSp3aO/K9q6uZ9uSmo6zzVLWrbnwvOng7iuNkXDxLtG8ZUpGo+3RI61bsD9+cjvYbwG/xO1wpvfS'
    'ns0HTCrqaqI7WSPFZDu3mD0z6AUuOCaDP6afaLwv9pjbc6Y51TTqoHZdF01h7YX+tG5SRvk088XjmbG83svmxg+mdlrCjYKJ0Slx'
    '1YZzYllFmU6DslQ+Pye/g3/BSY45Q6a+YeXQM+RYjpLQ6qwcEQ7Tki3/FnlSHEMolFLx1o+Av3Q5gEWVVmbnBomeaXIL5o+XR1Np'
    'vWeU877L8Fl1Gb4RYUTGxgv8nhvTBSCS8p6C8PpRaM8GjGMRwUFPcK7+yJyxMuNIvK3KTexXRSf2HNf1/Hpg92C+L3MW41RbWQ9q'
    'r20tWYAv3e0OrmvxQJJUdml/msqvHkOAfBi5D950wwvI+Jh09x6LQ/6254WB3h0cbXUBv89x8+neQaPgaRHrkMEQD1H7vvfRj4Vq'
    '4bgev/7jf/v1H//7r//4//36j/9sC6PI/cChxhoh3s/mwHyR9NIq6bdlpJmjLaQ7lD/chWXf2J1TlOF0yV6OVVZvRr2acAPhKJgp'
    'p433/cDLzpdyeWO5Lkfn00JowFAmqAhSGGDdLmXxg1uUJukqgwRPpGgX28ZZzrcoGSqObP7ktBzBCTFVt7xwZ/Ai2zR8UMTiyQiD'
    'RL+Y2NcWjFRmkKNItK8u6yqRImRet4fbbKyxKkYRrh1kxdphdi3+tJwhccKA+Xe8A5EOpbIVVbo2XkD2Y75wH/Zc0Ue9H1mudkca'
    '/fBMQYVmPL42Sf82IPNcehmcMnAt8EhFRGVNtVhZ4rc5aLFlcWcoNsuxnVez6XD17yttYHh6JKSN1yVrDr5W3ph2BKXGmfKdZV3K'
    'ybgap1mfitEaWmGhmVRzIEdJQy1hDQV2CJ5zsufXY5qeqI6pMArxFxEGVhMtAs7cNJ8kPBZhYm4WKXnINcs0M5jpuYIytry2SWPT'
    'mU9dhZUCufWrRfEpJQtXu2pzt6mRX6EeAz3KI6ExF8AeeSly1RqeWk4oNxosF5GMSM9OhsiXretPPy8SJCFDYP18Fco1BdcyZacB'
    'aUND5IuUc4G8to5OiDh5NBteabYntnmZAgqcB6VkbnVDrMJ9nv3BXIG79oKo17KFybuWzEnkfsxksyJvgK2vsoO2OhhYSdM9ZV5G'
    'qjS46ROJlSUQ+FRy5doifQoyFvg3SqPmzgECWESoXUyNUAC0yAR0GLoWnIVol5FlkLPgdwZ3PnzniB2N/T+d4uoKt+I4S7EVKM2r'
    'qEpRuC8Twz1IJH/au71+r5RzC9kAep6gcZ6GO1H5W6diEBEWmv4KlftJTxE+awcfYfiB0CsjQYzA+YT6ZTovsovFWWDNr23OJD01'
    'rmtfKfqHQok1tmTXwmjtrBesldnflAmQSRdKfQkhzx2uk0y96KWzPHiKPQaeTW79C82NUMyEWT45vQ+JnbF/jFgLnqIfm/1ge8xt'
    'slfkzYuFm6y4hAECYs4dd52eyJSigMrExvbbQk9S2R3wWsA8XZ7mw8wLdTZFdxPLbwYXWSBswz6QTs8oz6yR7bYmm2WMQw5kVzXH'
    'Vci06g9UCjeZpA29HzYqDslYTh8sDSdyBU24nW2ukmPk4wMtkr1+DBw+oaRDeXCZTvuFY9LIXVMU0haFbBJeClfHnfsfx/O99snG'
    'VISKFMoJ3GNCrgs7lDabdgu4ISnC5j02EIP75vfH1wi8Y5zdwi1y/KWIF0KHjt8wZBq/dqHVg8QhLwcnJ/prF3HM+PG1hlpLEebH'
    'enT8Piuy2UL9Ig1O0z4gaJ0MOcvzYS8l0L70rqij/pvhNjofbgMuEnJQ0iw5mi/16nIbBL0PX7+x10STdFURdRJr9vLX/+efsWD2'
    '1yp+Y78UOnac3x7HziFV66DI0ttmbDeXtjkZAHagl38UCXo4HEwgSksdClhIxMHUSJR8B3MIPmO1z9dlfIGwQjgwkmQRNDvWQZ1j'
    '6SO3jD9E3C6z3AIsF8l985cbp/JhGScrV5jOH38z74f+wgD1J/o8t78sG2GVADl73fxuGyC1brB5BojJl101eE8wl0XCv1Fdyv7o'
    'euoi2yN5vyRfOmnWO7jyQA8rMypzz/Oua1buld+7raRlwAyxCBQCAKPytFxZz3ntFSEp/2THulToqE1FKagBYdmuKrfaMvYy959J'
    'dSBqOwkVqFRrOx/n+y87cQKq2mR4QC7mUux17bIg5N/r1uVQq+KT9l3boO1K0Fm4OlqzbOlgHQL9WatmijUydYKk8qadn0vQ0SM1'
    'c5HCzNJRSb3xE8PaPJ9jkiOdjeyqk+qXLIpPF8LkrM4VDS6PMpLe9iNuHOsXNQVrfIL+8c8nT9DHJ0/wtOW6I8/396HY73adJMOY'
    'wDk5p+1kIeIAubIzlbm4HTYT4vjQr8h8oqNPMbnrJgaCbypov3AExdJZg/qkJ4t2lmIvgi1TU/T8TvPAFvYzwA7e/3m7+2Q7zmld'
    'c3HJKS/1dpfp1eIt+spgPO4p0JvirYjVguHO9BXGm3PdbUz4FSFPWKHyWkVeaisrJO2lfVAOWQecDyzHCDNN1SFZxdn5EbwbMLrK'
    'ZlfDhN0WrMet9PkYLfM8wZktXKFJDseZWRn8PL8sHvEEaKQd5jor/YtuazgMK0JPtCW1VZdvF4GO7D8Z48VrB/yCJZJPde0AyCl/'
    'eRV4y05vHksIqDUUD4qoOzDc9c2DYSDN4SLPCcjgTFciDeXC7fYx6bacUoiKl0Kf6WU+GLft6uWBEe7zbAnhMFYDzrZ0ngi4aHT2'
    'ZABJTblBsyuZqsKLy8o6Es3h3jR/aIBYYUo/fdrycdGV1WMgLY2al06junwJzxYsnyKAAKirWl0bA6X/Un8AfyhI1e48MviY5Av/'
    '0+NikTqVY1LZHrYZ+qqBctZpWTmSUlyfpifKFT2tJ4ucj9YQjCsNTMe0x8xRXJE/Y2GSAwZDYReHO6rRR0u0Fw4OK1yRIG+tLkrd'
    'cVz6QbLtq649jBoIfvdJFGasIjVa/52pUpEqzAOLZyotVB21Q3bHhbPH7gsBRMvSYYTeMgFSJyDTupH3T1sxsVBBjIsVONLEUeYe'
    '7UpxV1LDXdkMTCD7G10CAiFjEf693YqCxxO3KNWNrvS6DOWPLcl7VE0be1FPoXD4SdRJYxzmhTsZFjeOIP1IOAerNceL6qGj4ia9'
    'oqXBefhZrJsIyG0F2qgzYzgwgjnAAIoyodm+FXXc4Azogvd8sF1CGSDx010GizmtumqjitBgg24tInsLk0CTElpOF70FRJhxCaH5'
    '83LQV3iJYQlGZoHYNWavKfmHMcWNeu+L3vfEnKvdJu/GGR2OS0GmAL2X68PXJUuDVXW+QKaxo/sD/efOx9hRrwJyVHoBkCaBD03v'
    'ZUVfoqUZBEohFURN1cz17STlHiNxd1oxtYWW+7Yc1TJ6SI+H0vNhCQF0JeoNlb6qKi8ZABTGS/U1Idpql+ol5fTyS56N42EOfYVd'
    'HyIDtANNk1zLhRNRcC55b0E7L3dQAbwP6NDp/BOvHzshpACr5U5TQR8uWCMXL5S/lSo6dju1uMNK8SY85mZuTL6CNSUN8Rvrrj+K'
    'IM6icl+2Y1BgVOYzudB0Rya/9DCL1+ZutfgdauGSq5eVZFPldqSThLpJl+4UytJTtJupq3QoN1G7PlF9i8Iu6YE8lYJXcuP05uXV'
    'cdn+648TVJKq3mdeE4gGMZzA3466nfPJMtJp4wpdPyxqoUyU4bwFTA4JlKQned43af2Xc95f0jjhRe7WN2KuNnna5u2CfMcQmXmF'
    '5N/n8DEDXUrHlbM4WKRDfHztXaplxD8MZKxOGvpTno+8RFwcTXObX3DwjgvEPJ6oIRLe2FJwtyxodXAp1XmiXRob5yrAJ41b74mg'
    '5s3F627nezCrCJIbTtsEh4Wp861UecA5c5TmQL8i9ZvAYFnGgbXUuyEG3hM6ObD4lrWCCVhGmFnmheKz8fdtvZAYLD3GqvsBM9Rf'
    'IJgSHzTtFU0Fs0nWrTH5uQaU0O1ko7PxG9zELHl6NclnTYPKWXNlP7YTg8bxj65aTNLQcs2Xom2tD2UQohDtReEfQLMay3g92mF5'
    'yXpvTaL6MASCWByyhX4cFym6YY3oHcLsspcl80S9jY93NDsH+7nUwXHJlvjJDLapqyYN4yk1qkBjJNEcGBLylvij/saOdD8PwV5p'
    'EHpV0EgvlIwv1v/2pAw9MABGFyqC+eJlsZAE0I9OilSO0q47Skr2In8omv1lFSzUS2efg1USeGX2TRJeDQ1U31wQAGL7uKiKYKof'
    'X1sgvbNuaNcQO1TrwqubAsQX7j7DqIcWYeP6UWTpVOX8EfRwtnaOtyKoC1Vp6hSM7JTxsjNwliEZg0LNl2Xo7KBYEDubquazD11p'
    'Ap8QRGFRF4pIOBmObOYLpS7kXKUiJJ83m9Rt/Qb8A/1RUBOt1WBKUrfTq37h7IWfAqfXvscVVHA3VPfga+JYz3ET+vj+zISWj3RI'
    'WabClOsrZV3zmXbxQzVWK27BH95+4zTQpj+aWUTh5//+L7QcAMpGXeF5eaXTs/IYwYlDVYozYAqaE0J4LcXWKemctGkO2CrU4Sj8'
    'lE/7PtpfBDyEdqDVb/Ic2suv8iPiL4pk7VXckDgJgKDu2OwFd7CyuRrWBVHAoo/7NRat2OMaGApq9hx4B1jTUsulOenl6bSveHdU'
    'ktFac4/NQFN5Vi7yvFsSTc15P1tOnuRELyT8/rSnkwnLGbSO1MwAy+J8TA5jlCNaw9MCdUkgnOjsUjpsq0yMAdepTgKzn4s9NYcL'
    'ZQFU7JI74PhehuAZB1AdvsNIAQUqstnKogHSK7HkQR8mLxmZYu5cdK8aIRXDtG6nV3xq036/9Ltqz/tH2/tCnaNLUqisK8RYOnZo'
    '8hJwaHVGWLsYgKd4JLtqngSrjk+pME1EJlILU8S9pliM8u3i2utjM1wgwCyKoOE1UmfWdc40hq9fTwgDnwZ68MHZhpfT2CsEqBHW'
    '62SYz+imcJylNG15wSTcJlDO6T7HluiGcY1obc86HiAcLc+IdT84Fb1Uyr9KhdwSlODeMB2fKXbtUMEW5tF0y0iqxQC3ZZAV5klG'
    'iEjG5kYMQhi+GoRBh/Sre1GGWFnqbWJLI/wT3lPTVgL05anDd5AX9pyhXQw5FU63zcqocR1vclV3sxk0l3p2DcKMHyqukoJHLgkz'
    '9rGr7cSQ1QetKqwA4/qlXRCFfqsMrOSE8DkWfqeDXofZrkbo9alK7ypuzXL593dQ054iq8epQxaYAdtsAeyPvHsFxOM5AAE2TVWx'
    'kEq37bAzJvQuBT+DxQAaMVIF3GJnP772yxDkeL09lAI6RB8YLHXiRtO/WpbSKuiTIlFQA2gavxdJ8+nGRvIkGYj40axrp8VUQH/T'
    'CKrZAzmtHxopbVhUURTCLD4yxdrtIJ+Ulf4qH2dzUBlh94ElVr4e8OrZCEq8/ii8QaW9cMoPnxsF03Q64/6LFSMpK8r72F/CLrDc'
    '9nx52cCRx6sveljJHTfW+Enr2VtOxJaCu7zPfjkfIEduwehiRVMqI7o3FVggHwvLcz5GUEqhsX5UZdDjteDpgVOgLT3DjdX1GRAv'
    'YwbGLt56v/MEGFMuPZ/bSLvSF7ywSZZHK99luBhP8hWMlAPack0FeDYPH7IuBiTCYhrV7D9w+F3x18Dmy8thpr1cGecjyw/Y8HPM'
    '78hTfceEWvmJcG/NxmQ6GKVTmMnLXlRx0QE3fFwCPs2njOrIeq2diEhGROxh0IwlW2qUBbZCWqMsFEYd/skoNXPzbn1KR4JKqh1B'
    '5H2lF/LXd7JV+FVM5XlkASJV3m6gzvCzFJLNhUI4Nf4oJy1Mw+heQIURkExXU/kVX1U/ZQPlYbb8f+XR0FPPGzCeA5FuoCCrEpr9'
    'xlthGB4i7Bmf8sc3OSw0/PlDNj2Wzx82uvtofZD8TfJ5V2tfSKzf1uIg+S0el5rHbqrU4qDpar6trKDbrv/Ht6jl4cAyYE7c0vDW'
    'BW2owk9el1e9EoBBK2YWmMgGijDkvVGuAtczONsLYaRsyxGzUoEUfmI0eurpl9fEOuOOekMaBAc0dE4OJ3yc0J1pdqURtarUdkST'
    'WkZEIBb5A4Or84yoL3SZjjUrOdxMNO1k0vyRgSSMS8aP4SUUVgTpagUh5q/evd17/+67XaK/ikRGmwAofjuxP9XW4P8cjCdQoDoF'
    'WmhK3ooOZXlcA86LeTf2g6Ov/FOHOqI2pDN0G8qj99LrRteZgVQGotYxpjiWIqydfPIuC0dfyehCfcAL3XmGItwxfJsSNdBCgpGF'
    'Qj9QXzHv2k7vA7tfZa2D6jlYnrDy1hISFTSXn9FRvMl6EREMl2NgFQ/y88LQ+yzidEfTqwibLR95FM2aywNHJj8+xuVhHbC0YQEt'
    'FR6gRlr4JJ7YcfHBoasC47ST325s/GVEAQNYRhP4fgEP60j0/0lKVMPXa8GYtY/5eUOacnQ0QCWyLBdZ5+h8CoXQnmJbAzrbgY37'
    'GwrbyOdIjhZyKyJuem0YgXO4SI7/vH/b81WuzVX5Ctu5BmWp3Fed6AS4nMvCi6UWBeqI3c7B+GBMWAI8pS0LELCgd/CjlE05dugV'
    'QVSLw2NQza/HcPDADDs1eAwrWOlo+h6EY1ImfG6eIniTRSDkUm2AQf6wFyUIiZvUIr0ya+dYUX8axsMLrwW1wV6uq0HcXGHezUDa'
    'rE9ZofMxhzv1NeMwpudjzQNNy6QaNap65Suo0Mw/JLyJLGiWxHBsxmqfzgUQTQz1eH8ecCd6UoLn9eh6VfQmyNlqfqov745XrWhd'
    'W9k8ktcDZsiCgNxKiJspvzSLBOY1hHYs4jzvS3pkp5X+skVHky3NZU4q4m7g9c5OqTRhv2CZcXmVOi6LUosW/j9loFkGwA+GhRpM'
    'r8psJw6b3+UPkiMMI1nTQBanWSF0cC8g4y55c/m8dogL6Bq66xeYK5aew4jdh/EKip1WVUG19cADQJeNBinR5mrAw1KNs+o/6sYM'
    'XfnC3eBO5gpCJ6k/lAuk7APNQAs6LrU7XZR6y2EkAV6Z2lI2hT07GYyd+tvlRXoQ4M5vPXi+XhxNB5PZtvxCcmH8C+Da7Qf/P/6x'
    'CPs='
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.10.21.1532'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = 'https://raw.githubusercontent.com/BannerZerk46/spider-diagram/main/dist/'        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
    'zip': ([('Zip archives', ['*.zip'])], '.zip'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def do_POST(self):
        global last_seen
        if not self.host_ok() or self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': VERSION, 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        while True:
            time.sleep(15)
            if time.time() - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. Everything stops by itself about '
          f'{IDLE_EXIT // 60} minutes after you close the browser tab.')
    if browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
