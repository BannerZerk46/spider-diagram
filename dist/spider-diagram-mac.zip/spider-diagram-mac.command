#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrsvdmy40iWGPheX4G+ZaWMaF6S2JfIzJC483K/3ElJDyABkiBB7OBWkpme2vSo6Rmz+QP9wrzP/El9yRx3ACTA5S6RUd0tM0Vm'
    'BAGHw/24+9nPccdv/6CYc+9oqcTK2+rf//Qb+iF02Vj+/qQaT6hAlRX42aqeTMxXsuOq3u9PvrdIi09RsSFv1d+fdpq6t0zHeyLm'
    'puGpBlTba4q3+l1Rd9pcTeObZ0IzNE+T9bQ7l3X1dwo14mmern7vWZqiOkRRk5eOvP0tG5T+6bd/SKeJvjwjNGj2G/434+6Wz4S3'
    'UgkXeiZkx9ubzoaQXVwmW1ZQi0in4XVdMzaEo+q/P6HCJwINFq638lLNQjupw1Z/IlaOuvj9SZE9+VviyfNfmAJcEnBpuL//haZX'
    'nmd9y2b3+31mz2RMZ5mlSZJE1eEhgaYgbx5QRZIgCZ6F/+H6L0wJ2lHUhRtcAUiq7FQcWdFgmghNQS94mq6iNg4Ufh1dHi+XB/pS'
    'ii+pc7uuZ1qEuVighYnqoLL03NRNBxX9hWbYuagsFnCdvfsSdfclmuMZdXZ5KZsEPCy8jMtR5x6BR09jQM9XAR7AFY+hW6nacuVd'
    '7h38DoWmilhouo7ufEf/AiCgWfl6gWBJeI5suAvT2eI5Qze67KlfKJqg6Az3lcBo9YXK8DwvfI03aJiGGozSMTdqOMIFnpOwLH0G'
    'k85QsWI06rlsoQeO6RvK1aO1qRnxZwGkc82Z6yoxD4aGZ2F+vFzjKWYuA3tYnclw5/owqgdvBKsevCF9oD4lBM2GIEkf6oT/gXfY'
    'd+GyZG9FYApowiJKQy5DNSk2IxIUmZF0JiOkqQzTpBhUwmZYnYYLuGnCYzooSUdFEiqBtwguwxFSvJPsMvxFhMqUngK24mKOk16Z'
    'rodZhTt3NMv7/ieCyGaJnGXpR8xQ4C9wmZkKWKcCOjmuR1iyZnjfgK1s1e1MdVQFWKMJTO6ZUHVXDVjT0fXULQEE5mnGMgONes6R'
    '+CsB/NbfAvVkoouSrgb3wH2gdibo7ndCNwGVe57pAD/KLFXvBZr78ksIsxJwyW+48i9foXWC+C//hfiylb35qqnC4y+/fLGAq6mO'
    'G9A0MFxU9xuhyM7m6y9fM7iq6hL/nvgFFf1CfCN+0RFh/vL1V+K/QotzVOEzEIevo7d/y0aT+ZvrHREfJ4hvjml6xF8xrOn0bPmN'
    '+POCXTDq4le4tWRD1VEJ/oNKgG/DPbUAPiSi+63vqQqU8DOBFslfw2YQBUKhyqiUIqNq8nyuorX5c8C9UNHK3KkOaptakOoclTjm'
    'nkYFs4W8EKOmXA9mOioVUDXFRA0pksLP8WumEYCtimoIJJSEEMyk+Tx4C8pC2BVWVc7Nw6LAYiaGGBTdjNQzZde7LQnrha+Hra4C'
    'RFzO5C80xz1HfzPSVzxnquGn3ZWsmPtvIJAo0joQDPoHv0A+o/8yFPc1aC2JJ3gx0YP/Gq3df0QLnsarjYSls3n6z8nlpCgK2Hh8'
    'OSmZmtPkZTlVVuVUKb6cEi2JMnO1nLTKUIyYWM5AgsWXk+ZokVZjy0nxlEjNrpeTYimOEi/LSc+gdS6+nJRCyyybXE6G5UhhkVhO'
    'WGDyMvHn5YQ14un5zXJeRhot51VJtOzBnN1ZTv6ZFp8ZGtaS/vhicvcXE61WtJb/CDQ9Mw9pVzsBZ/oG1w5iKVAU0P1/XGmKohr/'
    'GZG+5lq6fPxGIOlJ/IO2RQqebHhBxYw2hzpYan4jKN6C9wPRHt0tdPUQvPsrlsPRdSA9vxFz33FgdQsI1F8TUvgbQf96JX9hWpCE'
    '/fVa9p7LASs8DXhmWgbUheI0Y4UjmvmeZxrx8WgGej2NAPyVwPXTGvBXF2ACgFSAZu27nrY4pkNl9vJgiUDhrpqGqcjAVO9i88Em'
    '5gPfbWVniQAmMWzoh47aQXr3MyyFgmTEuV6sAZL8S9gjroPXeCbPN0s8+m/ETna+IDIEVMFLH5UAlkERIpmFjhAnWNwARxamEcKW'
    'pTIskQbVWVfTgeR6JvJIdW7K8x6+L0PdZ+Kppy5NlRi8PD0TXXNmeiaUVVV9p6KpJ1qqr8KTnAMa/jNo54abdlVHC4nmPPvBtKN/'
    'QZAhrVFDqj2A7W+NCEuR3QHmwF/vDBIzFxjUGXFhCbYwDphS19Q1JayGVjgUZRngEPHljwGwd9B6on8fIAJeb5giAi+hJSsKphrA'
    'AEyCsQ5SUT8hYKBPP4TqdlSIiYXghmNfUdAWWiNEqkAuFJdEIhHjEEYhXGsf4opAAuLsVzAOUHHkuYrILhggavzPIMaRxfaQHLaa'
    'EREheYVMmGl//TUBFJ0EisVA8UHh4UzNJJ6qu0ABF3BRF5568M6LimwM3w0J7TzpdLQM8YE84ldXw80YW6hxQwi42/SlWNV1zXI1'
    '93oekm0pSJNJ8LcQxrSuLrxvIZCA89l/xNqgb7jyTlXSYEEbS1C60PsgoI4u2IyuNgN9eWXuVQAC1D5jiV/BHf1jNtbtNyz5oN87'
    'BH6LT7hyiFCaYfleBnhtsO4B3WvGCmjTu7OayUW7u7aJJcElwcLdInwgwb/eX9nHxH2PifleIJ0vq5tBL1tXS3FF5o+pmomNJO0E'
    'xMNfhhwVUZfhxYoe8hoM0jcdifj5StOVC0MIXw6xKYPpwDkDT4XFoLdcr/FDukvQPY/oHqPz2Ur+RviWpTpz0NN/JXSwRQAK1C1e'
    'ugzJqtvrwdJJyQZcXNWRXf/XmMQ4Y86HEDHJrh/NXSDQkigiJDANYZ+ESiKGYYH0x4t5l63E5wotdChXgmEFpPTNML0v3wBdZKBA'
    '5etdYRMno/Dd6IVobs4FiL+gyfUA9zLsBVBFXci+7sUbyWB95LY7rJNeiCUxwaF2ek0cgYKaADFjORos6/FuF2eCDFv5M7ZG7nV4'
    'rnmLZrd9nblTvMfIBorXR344pORc2CtD3iy0cJas7j60QyOuRMcVq+Du/Cp5y2aQ3hShHn2FehfUPMQ0a/QfQtJb0g5gCdfu5h36'
    '/M5lPXR5pupINZxvbhWQx5yJOxN3DIM/iPiXbt2trOsf5iVYwmGrKSR2y3S1QDVzVF32tJ3664VVJaXjrViNYF06cmiSXfAiiWW4'
    'y683dbAjFrqGdQSdfhk6Hb8E74D8/IrW6DlwCFoysiNQwW07wRARngTIEvKBYKQZwAADMAdNUgzgGRTFJySjOKZlBfXOUgip8Irs'
    'rtQbSRdWSQcOVrBE+PP8zmVjJ7sxMwHr9Ukt/4wlM92cb4Clm/58Ba0HaxHION9FnDxgP3FtJ2w/Y5iKGhvUGWNwpcBQvVlleQa0'
    'AdjxK6x3MGtBww90ptDMCvE2xr9v6eyRDhAo0Em5/sCyCWC+5n0Xk/uGinm04OwjXwfG/oW81fRjTJ4l6Mly1HRAUdEEhMaCbBz3'
    '8ALMzAl6VhBB0Ge0Qha8+8bUBvphQHFnywXfRapFwNGCBUuDTgjtxafmPSMG8w+McB8i+wTcGXhFly0XUBomwXigUQdDPBvV16DK'
    'vmfGWDIiE/GandEP4bsjgTWMOrGuQ9geVn1b07hGwqQ+y8SFz2amnNVlEHsEhVr0tfTWNEyMJc/E+fKuNoSBxu6eN1AisBOxyRBg'
    'B5ZZMR3uEudIw6NnIi0iRnfRNchHRIN7vqaZs/fpa2zYAjJn2biiG86OeE8S4e4wVOFgQlCIDO0+XyBHtw9Q+UI6zBkFPf92lhba'
    'QVXOtEGTcbIJ7s4NseTZcmF5MjJAI9Y6l/X5F+CvuxWRJhg6mMAzY8M4+wknRUBlVFJvoTDLQR45Sowm6VMGzufwNuIhF6YXUtLF'
    'T3hF71wG6xVYNp1FToaLFuA/bFHgAAURznY7j0xApBgHixNxLzLOrxJrEtyFbwecIL4KLL9bxWeMPqNdHM7QekZ99lEU+MoNIgaP'
    'A2PJ99LIXfJB5epdlsjct6qSfV1YX8wKviwfmeRiAb7f7fnc7ExGmnM0S/wdOqTvm8uReXIroxNta/H5CdWKpNLxhp0QJ3S8skDX'
    'nPvrmWijNYocBTR2E5CJiaWpswqE3gD9gbDink74T7ip4ev3qiQ9LTR585qunV87OweZm1oZT7M+ohuzN29epEICay5Y/Z5LJEnP'
    'AYhnT9mdtefeXvvzShvy7oKbN47DJK/n48NqwbAeWLHcRZUHaxmUPkAyxJHPnYKSm3iDScQJ7jH/RIWFpntqoHYfw+D916v5nmV8'
    'LRpQgiofT8nnOGlyesjg/rEDFeAqomF8wp6L62N/pniZYeVHbOZhqC3Wb9QSKyuqSF5hwGfBisZUOgCh376drIh7WerYzX3W2x+o'
    '+4l1vraJMJ7LBlh5AWOBdiuoWSrDuoQquyrIxDS8BMr5AuUMhcrnf9iox4Ujb1X3/MZfkb50AScyLmOGYSQt/ozN4tJ71k9Mq39T'
    'C4N/v147SxNOjEAYPjKWYmolUjqT7tgb0+QNs+ehrfRDNpkkSbdG2XtqRqTC+RYgrpqXnXfVXfoD6u74SzjHFx3v1x8L4rwdzTtr'
    'awkWKQaWwH21ONR6fp52F67Vx5U5JqZoIRUrHFoi7BIpvX8BnRfZwueFyqzMLaIw1ws8RJGQxQoZVmHJuEDDOi0dYnQ4IR9mMpGC'
    'eDt/DzTkpA/0dsIe+EGDWU5MUeYcp00OOBG5DjSIs0ORvDFNz5RypyGAfP9MZPAyoeAfLrh26QcWYMZdBWwzEpXUm+yFjMTgVtaM'
    'eItXE48ccRHwUZwKJLXqvuHFi8ykYLAxVx4tkleRO4Hc7X/9eOiWeD9eG9oQj6jgMoAu9kJhD8MjP0oaoyLmKOTFCLkYgmLcbQpQ'
    'pgPPVoyjcOGy4h4/Y0qcOccdOvlMbDoY69nOiVb5NqL7idDlQ90lHKZnmrr7gYB4FPuOjVH85BDfDHQnwLm1qtjIdXQTK7h5OYpS'
    'JV++6De4bj5IrzjP8ZX9H1tINjLir+XgjVZ9bUxzb7gLk5D8x5BjI2mNFO/fnxay7qooqeqxtXh5/Zu6tYCLfAsTE/9KnGWb7HnO'
    'F6xAwuLO1ZWpK+qN5zRq9L535mrOrk018c68ruik0UEngsfYN0LeXZAVc2WtCIkXg6Aze+dFX3+O35r6PSivrMV77Wjb5R3zOMYD'
    'k076yKsRdCQGsvKeT/GqG7zIl2Bw5GrFfAlf/ZoMCiR6iMdoYk2uEjPgXWLND+nxjON8RFzXeVPATRMUx5J3e77rgA1pO67yoom/'
    'eR3Pse3DfWzNxCu1g71mNcEaMo8U2Q8QDXLqv9GjeFba763nw+E+CBuE6VUMTq/iHvuNr0CUr+k/oX/ECceJLfcFB99KO0pSVYKP'
    'LnB2bhI/YkkG7zvu3+89cOGb26RMD128oFKpgQpzcQ2TH9U8HqXCXTS2wMP24xlgV5I+0pN//Tn5aWcQb3K+hGQKDlYxsHPtroz/'
    'nOJy03VSL74TaH9DL44pUN/Dhh4TJOq0p8oODuzfiynTweS+kanEva2WnM3ZjzjiPp5HeZuCFBvLt4U5990Ei78zW7eJA4ijBfm6'
    'W+3wBbR911nOnq+cKTT3l0S0O4E6Cyzj3Tj9vomiIeP6GIZ+SEvECHUX326M1luwM8HF5zJ0L46pa50v5nz5nCMw9H08JunHoN9q'
    'r2TSCfzJqECyEyOQlPed1Wg9ZjIo/vE04aABsFI9P4kWZMzC/1g4JG5hUleMY+loysdVatwvnXQfoBYiTwF/QaKzNgtDcLzAtERV'
    '04AEFjKT0wHrd5Fda6my9wV1mEZp5s8IYlDfvtAciVJEqIXzNZrWuewoCelzMYo/KGkep7qckyxu1J8PGcafi/vFU57ezcq7idde'
    'eBCRobhkzJaKYjt4soK0rufwBjO4dJSz+td3HVb3/BuTL+kw/HonnxP1kgn3BXyekV6ytpKyCa96xlv52xk0KrsWLCrMJ8wFQjoi'
    'C1Tx63v5ST8jN+k2LymwNNnPuQwS40H7U2+tlzfSi2IthPsN7jn66Ds+vjeD4Yx1uJczHcEaj+Mm3Bo3Mv2n+DmCXvH25I/mv/3E'
    'fl1DsyzVu4QhsVaclFVn++tTpsYN1Ff+B5a7SmOAyZ5tNC/Y3hPdBHESXd6idfs1XidtOhpmu5FV+DC0HGKQrCwfuejwoMWLn1+8'
    'SRy/N/5QBscHSt3f4vDR1NYYuI66U2X9LXj5WGrDg8ygGwEZS8S5nxVzj6VGwCRZ617zVqAAXgCNe4svHNJQkSf5c6GOuBgPo1Xh'
    '1OMtmt/CZMYPaAXc/SSJq0jhGdCEVcEk9kUFd8mdX1SGj2sY2M0F72PhH3AcqAM8O03FNT/yrO3eibc91rOAPjfXOcuLhUryfCxe'
    'G+7DvJeREdP2zhkOQTQAMYUHmkaQS6wivn3xsEaFaRykvEyYQH44l+/S8H1f6mVtdCO2Ismde4HJ/9ndepnH+/WiDjOoUSQCcNv3'
    'WkuYVUHiLdqDBvA/X90/THSdO6YLOoHmxJbirUTXc9wEE/8lXpZCkxWPPFKXoALDnYNXfyRbjH4/R+yTiiH5gYSwKACICt/eORWg'
    'savOH/hNHo1TTNIBaiCVaOwDnqLIaxvUIZMtfkyXYJIvGUlfI/kpkjqH9z6bW3FjKyebi0j9c/sCfgTwO3HJ37Lh1vzfsuEhL0gd'
    'RDv2QaMMzsJ4Ip+i0zrQJa7/+9OZkCI6eiJkR5PTATb9/uQ5vvqEdvz/5h63M1NHJ5w8aWndXJpP5zNSnvCOCRb+f/r+2+XMiCeK'
    'fkIHRuBf5/cn5il79zGT4fBzEBZXNWgyqCE9eI7Ovgi7kB42wn+gDnunn/A0i6effpYFajwbTOftzCI5+WBmLwBxBE3t0qJMgfDE'
    '1lKaSlOrNBsvIKidmBgGA0DINEEH1hWBR8DpQpqPFdIZniB1geBzsTJoitxJl1ppuKpy8fs0fXpzUMAOzfcGJcGsESwh6VyaS8AN'
    'ZSuYPk5G04f+BmChDO4qRb3Zr6O+2+8WJhM6hk7T1x3TJCFVpauOybBj5s2O0f5xBx1R9HbfPCERPPov/TZSWLrvvjd/MAx6RbEI'
    'W7kdxb7Z3uFdDBMxXJTYhB8dn8jzZoOub3yaHbDXREbv8LkxNAm/bEZiCPSPDnYQhYwhID8hwwNM6N9YKYJtRaPFwr98hmHDOunY'
    'q1KGFIL2LqVvjmhrvrt8CFhGRvMUoIUU/oewk0pLaWn6Zg/Yyf4RUq9eKJREtLejYgXwC8tOxwvS9FCYJicXmt2xVy8BqsBsMlUR'
    '/wroFyG8+CbQ2FvyAOjwzCjg88QR/xsKHkq8SB507SDOfsWApTgDpuPAbxH/4dJMhkJ/4zMB7JVs8MCf3uYBsmbMzP17E00DHgky'
    'haIyUfvwDyIEKD6vcRqWnETTCYUXSFiCfBOEwPX7LgRQRl6toxgfb5pepYVMnBGDpJLSGakBQgUkjZS7vCwg+mGq7DXmMEkkmH4A'
    '7rRpqR/gZGhSMhysihSTHSD6oJis0nHJQ2UkeB1kDxJALMEnBiRxqJkY4Fi8DLm4kIKJYOLzgMxMCaRyRkSXcVqABzATVUqMv44Y'
    'zZvj3qjHmQkW7zt4TmM8Z894Tsc0LIqP4fl5iXlCXGVIChFaeMFGF2J4ISI2hkvo8xUfXQkExYMsfBN4ZFW9y1VQnqoMQu2MLRwL'
    '/+tMOlYKuEYK+B+0UAKAkxGoa7ZCUYkXODaN2kkD7iWaB+aLG0JNpKN23lAXPjCILSVmRBYdFUcjlBFo3O474DdBjYNJhEuMfQJF'
    'JF+6ByosCb1jQM6IKwavhQR3lISWgnlnJVzvvZVgCB6vLBMtMVxEiABLzQT4EPyKK+r9DtPYIFOVD6AAtI9REXUQXIjogkUPdmwT'
    'ES4SqFBcZedIo6QRD0kzLtI2Eamn315GRdtpH+B7eOigaQAF6Gwa6YCBZAIBDpdp+O9tVUtXZSeN4hLyu7PNEsKQXVE8LCDIVXLF'
    'gwIP/cECk0jSUpwOmIBVCUAPuHyzY7h6d5Yx5UoyGlSktYpV4aymU2gmgbed71HJSkjWf1see2Bgzt9dbIlgV2kJ6wFklUNjBa0a'
    'rt/T2lUHGfHvj5Ld8TFFCAnJIUIgmGKKf09Rnm8+IBmRpkwBJYc6+mPzSdWtT2uiAUe9WCIZEtQ4GXhYuAhcRgQknSORDIXoL+bO'
    'AqLTN6HxHNldfYQFAPrDGvGgt1+ZWcKVHOQRXxiyV9KQvRZvmJqpHR+w6B3/nsRQ36ccSpqzwAO4NAixtOAC/aDf+3Y0FRnS3AOD'
    'nos/f2xVeI62ed8aBvSrXpYLK4YM4iFIOFyRHo8GQl8j5W/oLMnwfFzVwXAA7yLmuuy6vz85oDx+x869eCk+GSYshyehkxbBPati'
    'Ez6sF55Ui9xcvz/ldJ04mr5DhGc+ujAO5KE5173rffnNd9XwWNs/hw4CDD3A/Fs26PgMB95OjaAIzxk6d10I47ALTUdNZlHFcFRZ'
    'GNanBthS9+d24ToazdN3uLmBKP5iG2uS4ZvohpDR0Tn4sGAEGPGl4Dl6qv2V+Nt/+78IE+bJkZcE2idlGp6Jj1IKfMVP39Hbf/tv'
    '//PN7nry7jIB6CZsv/f16Tu6ffflnJt8HWCQCRQGiQHbW2kL79wkIbs3UD2Y4ODIILQWj+efOIcf7q9EeMJyE2pFqCO7lmn5Vog8'
    'QaF6gNVWVCVKSz4PKjjR1CVAfOLZ3a9MGNh5PcPmiSSSEsi78QFMjZwgD5EVjRbjanwUYTdbfBM0H72QnKDIC/10eXynAh7p0/eG'
    'DHTnxaY6rB54bcMXQmEUTk5XTcuOg874wlMTAolzYdBGt7ms60dCXniAu9A2ISvKM4Hyv1E+6E59PqcCYzxWddUD5CBm/myGCRAf'
    '4xWeYI37nZmHJzwbbg56ePpOoB8AXzn+lsVQJuC2EoNEroSn73VVtdywB5dASeAAIMYygGyOcgn2GoCjGXg8WE/EkG+B6+GTcTO/'
    'Za03J/PCCs9V4thYCEfcBJP7Qjll0JMQNM6RwNtfgNplQjH3BiInzXMJdBnNC658ruZeo8wbnQJvvdflDFZwvnomQEvcoWATCqkG'
    'h/oGAQ837DOop36kxxKmpnh/A2Nx3ePT96AaAWhyr80rVLy+/VE87yG3/qfQPB/ii7eSPWKFWFg0FUDhcAMDe4a6aG8DgcYTZvrA'
    'KqGtCis0rfrxbYQubS2YD6IKpjE+ifY89/cw+w1QS/J8FUL3i4tDJyBKF4C9bsCZXXOBznN2PWjAM/dgwbsYwVRDcd+GsAyNAITo'
    'J2wXRo+P77vgxS2oHyCP4KVojn8Lt7bgPkeIq0dDq5p75EZQz+S7VL3onGoUBMchJzcQg4EIwlrb999MC80ksZN1H5oxgGMhIFr4'
    '97ds8PS6Fjobwgf23sS/j2ohcJ6+j+DfRzXMxQK6MjFs6ESlS71sMNDvd2btPCkNGMDVlOCii8piGgY8AvaJg1U3g537zg4M3e8F'
    '/PsISFAiZYR0iDaCqw+BeUtDn2SG3cjvGI6mou0CQYK525nGQvdkhHXoowoBa/4B1TBydUYCl+gmG/8AH3ogWrpqRBV3RgC84G//'
    '9M+Ehb7OEEEfFzgLx9wGp6+bVoYYGIpJACEGTSG2GTWNYudJEfSHuSJeo0Apvh4UgaKoAfkD23YBH1p4qKFqnJQxiFsM8H7os06C'
    'y7DiFGyUvszuW6w9ruz9Ab0PZIvpeAmFKTy670fUwKA19NENZDwgDz/SWeSA8YT8HsszVOvvrAuqtyP7yargCx7gl06r8vWHiDxg'
    'FT20nTXBvNCBF9dT6qg4qg7IdcO9qKfv1P/3fz/iWvRTuA1SVb7Tj6sxT9+Zx0/BTGbjTz/ClQshMcaHZhnLPjq+4mYMwPZBiuAz'
    'HeHyERh6wH4bSd6brIPPxfhehH9/kDvfURvekvhoSJeMXhD9sbtYEs+HpX6CxyyDonuMxLSOMflmHQlAQ6S8zHXNCmIO31HxhZfc'
    'Uv0txUftIXO0FNqh0G7cEP07qZvtgDkQX6LvSXz9mDwpYU0ZWwLAdVBaFtYvZ74OdlKQfO9iH0CkKYIuNEebzZCLBlmsGeLFmOs+'
    'Uv0u59xFIulH7JgYuoccr7y9THUgK8J5HoGEO39JA3Qy5McAuYeKn4mKaS7BhC6acxeryw1t5qjtxUKbq1ddQqdXNGDOD6Bwodaz'
    'iXa+oM91HL4+VOcURITOBttUXzJb5WFN7wCo3tGR+Ma8/UsGSi61kzMSkd8fVYoeUsZbNp11DFErSS3h0nySYs5NvUU4gR8nIp+w'
    'ozsepg+zn8gNd+ho8y4e9mN2FFZ7InAx8PwIvUEKW9rc88EMMBdxP8QHnQLn1gPlBk8itpCwz2cre4jsIqLCCBvQICJKmOQ4FoJK'
    'gHDzDQ3tg8rNA68p9tzf85r2fbABNFlHG3Bkx0DHqyMEQPpF8kNjz2AoqBYxO+LfH/GtIhgeqihxaAN5eBfc3l5DAnGmensVOENg'
    '8aKZRTIOrGZkVX0aMpyOch+y81RfLv6I97qAzjm/eKwVBXmtMGMlQhdspJgE/PtLX559/YER4Zyms6WSxz287ZDVZkCSyyRooTvJ'
    'QNzsGjzkN/5SQhmXfxy+sPM3AURuryvoTADIibm9MIiae/Gw/kGwmlHLbwJWdlT1akUXUJRe6KaM/L+h04H4gjyVpg+XaeCuYN0E'
    '+frYhUig3Qzo2LgVeiGa4z8+sQi2N4EvYtfpfVILniVXPRwLIjjk+4l0gmcidHGfK+KvCX4JmviRcQTBvQ9xi8hHmXRQYkwISQtz'
    'W4SwAfgYWj/wKmpeGGnIfkUMPGjpQxGGN6h8gDMy780pts+DDqc/Mi041/NDs9JVH8GAniTCKz8ECc7+/Bg315SLNoBuCB3HC74R'
    'UQTgyn/9ywWxgPfInn58xhgHlLK5uEiwCxtofqkiNvD0vY+d+W8RquZdUATWPYo5AG64cwdJk2BSSJgOeP53lQOtID0xCvOZocoQ'
    'Ym1AZEhDR15S4HFIn3yOdBW0CRWdkAK/iMrcEOwf5sVBquSZZ2Bg3prIRR7nZtxDLfQkBCf/I6DgrI+PINXiJUzNuAdF8CyE4+VH'
    '4AgTPz4ESQ99OwAl4txVV4KHoUGAAUoDQLm//fd/fnuKteXyUZvBs3iTv6MmU7fh6ovVteitZEu9CksQLi6M6ZtJgwYa9RFxoFqP'
    'jB5L03WwejQUh7lfA6nh3/Pm4dYQuqoY7BpF9mtw8dDOUpGhhQ88NQ39eN3utWmVmIayFgsshbOwwEN4ZxIWb4wQb8sB0wb9PARa'
    'M97z0uC9smCiop93BxVHlq7qqhfWVkB6fJyR/HK2RpCC9x3X/oSEC/xv++AjmDGDEceHQrPpoh+E4blPy0wNNKeEFgXM0FHxsVxX'
    'Y4ksNsQeUYB1DmqqrLtmYHmFFDH8GiQ4oI/3Gj9iEgSp2Gem2Ak6vZcTEUMvDfktz6MI3yHQXqMb514P8GUrP8ap5nsBpAYKuzvL'
    'h1Qyhgrj9FWVN7BI66oosv5IZUDPoqn/gek8vGde/YCbvoHTWEMI0c1dVRWF9IwjEdgKcVUcJb+gF7CmugL9QkeJMFitnZuO8WOy'
    'FKfWnrEGAfWmSoJCcj+cXoLCds8EjkUGzgWgk/nGUF33hizDcOYPjEZNjEb9ewco9POE/F3CE+c++oguMEM21A/53WAuwTgOzgoE'
    'roIin0HUNO6AO29KPqcKPHbF4aZ2kfA4L2ogSuKzrF9vD2BQ3uv9SY+nPVYZ5uF83wcl2NZ+sf+C258GTLTtGXWDNP/j7088wX4W'
    'RhM51S4wBrd/TxjJDEkRbJRMGQf0xxAnTCJ4hDg5TM8fwRy0ATlmQoSc4F8LeVQjJr8RJEGgAfkz5L18vMSp0TZdkIpfFjgKquOP'
    '+0b5JGHqkGlE7PvrTxoOfdmtGTaFtb7gOUvwelpIszvx9MlB4yOXHg0bBbp+AvjieTXug08D9D8E/AxkYhJ2ECMeOht4FSX1/AzY'
    'PzP1nx/hj9Eg3lP0mAb7kSD9CBkin93FvYFufiY3wvvIE0dIUJ9cZgPp/nqMUeDbfyUugVWU+Gz9FBJ5a7p+nHO/kX+EVIjAqZ7M'
    'QAocWTiIhhNBLy5IzNnQR2V104Qh5yxLPyLdNMgJnt110N/vN2nt5bFPLPDNByuNeyC+BKw1sIyWphokAEVJoRjPz1l+X+8ahY/6'
    'b2AaOYdrHQ2n3rorlJERBOrMcOgIgGdCzSwzxL9DR9j+ujedDWijwPmD+1ufeKSQf0XWDbT1IER4C1XkyL72XYdg/DxXNBE2rd/R'
    '7T+c8nUGO8qK+kzQ73IRD3nirQeBPwBfoROeLO/3p3AHwHNm7ZrGM/pwuTbHXxLJooKLav24PW27TDaJbePsP17eDc7FQJs7zop8'
    'cNLCRW+PE1h0kGrkMl1RP2CaoDMyLgGkRKQS2DY0GbQdDCmCKDh99CkcohvexQ7/Rln7+LBVjEfu8zljFNlX2FEKGAntfiGyxNcn'
    'nK4+N7cWwoggY5NwLVXXcaA5MthCSGJ+AgyKGdMc0M05MTFpxzvqHOfQdPEvMI3gy9gPHU14X8r3Fvz7wOyPUw4CpA8c4KIG4OBu'
    'enZM42CvFwaHg/xlT5WxTx55XTCnC8JViGYBr7AjRjH/aGCYiALSV46CK6hLBxlN+9V+F4NQg/KLcx8Bjr4ngYziRQQrcompMnam'
    'P/1R3AsheRvccnA+6cV9tjJNF+0I0QDXosNLUUZ4gJMBk/wjG5nCXfGXSGDQx9tQvruDCCvx0TH95/1EwX4hXON2e85VF3h304NM'
    'kR7SpsME7J8Vw43toHobsH9LOQdXoBV0030AWiT+4/veiC8ld/71pznpkgGvK4TuoPO3nhKMfRGhesj877//EnwXJvmqFhXG/T1/'
    'jDz/dD9L6hqOPo4pJDbuXS1CWDHvGTf4+z189vYqhpVaD6KyRdP4BWUJg8q2lK+NiJ++fD183HFy9oMjkJ8eLFjF0ZRkfXTO4Ll2'
    '9BO9ssVjuNzjQ+nCs65gXKgo2mz4W3ALyqGO21tGJejwR10+hmXRcv6G4j/AKuUgoxl/wSvCmDvSNynd+yD4o7wW4FWo6ai5mEaF'
    'tbPLF9Dean0rH3TVWOKTWND+20RvWIW9KKG4w8S8okzM86SeUy2f7iAQ1Oyby2VM4vVQphYIiRXa2BIdqhHo4XPf+xGZcT6Z46JX'
    'Ra1doXaQe7uZKd/78uy3LLpAW/TOdkyMjC5VcYA6VtmNsn6ua+NFurEMTLz/j/h//x8iaM2dh20BHs1V3T0/CXMNY71FO3oeAAYa'
    'fVgx2En4oFqQJhJ1Gu0/zBKBg/7tsV8i9BFIQZT9buW//dP/+Ns//R9/+6f/82//9M9hdRx+CbQ40Ohu3+vg2FcU8rpsNAh2NAVK'
    '7O1bRRwDMYPWv1wmL+j0G6yQgRIUEbF8RdMbxtNwSCUIqER5V46alj1Pvjf+4oNAi3wTqkHWIAYip4cgpFCU5isR6/AS1dHDiM/2'
    'TpdxxAkNYdR4pIIH0hsZAbjtwGpFGR9vNhTP10IQJZL3AoXoOoPrW5gMFnkz0SS6cwdwB7VwMkGbwtMqL2Np8egRdH6B5pYh48+k'
    '3ePU588KXsTvedN68Cwh6eIsJnhcMW/FW7A3Bx3ffDcPOHixAX8dZLVjHE/6WaIf2UW8Cr0THs8V8lXMmfAqhLkwSTYZ+8bZRVyG'
    'qBt8pux6KsIRXL608fSDukQyN+Yyl5dPkT3WGnCdN3Q3/ChgBH80hecjoj8xJ/hbYHcsUyOPNpZdQtiyg1RKaxVtEvzT3RwJC21U'
    'RL6nR0bpin76Xg3yoB9WYZ6+9/zZ6qrW/Q4vX0V6+v6Kfh6mpzg4L1u5Sqi4bxFjJ+V8iwKzZixL9++Y1HTbc3TkzL9MKtNt/7Fj'
    'aS4pi0FJCMXgB/MWw2Y/CkhwPEl/BSxxuYqZiKjUC0s/D0d46MmHV8NwVccbGOGxTw185tQ5ewhvp0HHQuE0bdAEAs0DXSM/K953'
    '82NJBNDN50Bs3wGw5W9nqBCD+INgnA+8et9SNRL5GGEKT+CsOstgjED1P5xY8T4S63FYwuwVXPYjqPuBvvEEvATHN0akixfmnLT5'
    'KF8p0tmQJkP8kN13P1XpWmOP8fg+yh69BGFwLukj1v70HT/Hfp37LDZAQGwEo/Hi1NR32DcOriAMQbE5kPqPN9ODmh3UDA7ODo4h'
    'f6d1UOJxB6Gj/o2t+lATdxDWDPp4ozIe27n6nZG+J1eCuaqajnYCNVrWu35sIYrBiW4/mqwTHQj3USJxMFWUw6PdEsmD8XTBT8OR'
    'ODLuYx6J85f6noibT30GmVBxyzsouf5s51tZ1PsgSOUSWx9tpg082DoIggyRNJwuGdZIuw+yrLGtgBOtM2+qmeizgE+BoZcwPNDW'
    'A7yJEduuYLYmw3GJXWdvB3ZwPy/b5Z1IzNbXPQ35vS8hGaxsn3XvP/32D+k00YfOlj6UIyPDd4gvobvczQZe3nQISRo9jSJHMJBw'
    'Dz/BYCfv12c8IrwJCAocEICOb+B5Omd5IA+Rhb5DQKTTCc3f8727en/k9g8xTNd2+AB1HefEXk04tBFq9ReNHMoKYD3FbJtEcP98'
    'HNR9XR29/VhTb6hyeLzEOSDyJWLlgC3YbQ3Lex78vw8/K/GTVPm7SIfmAMfQftOiEeTxbVaLvbBioodnY2XFJE1JeBSahDdWpu8V'
    'cY7R2ZT8LCvAWzXPkil0cYTL82hQhrx7+n61NnmcSoP+vUzKG8ubwIrSwXPkuxYvPGzhoaN/b23WiIDAYNesiBpvA6iBPe47RWBI'
    'T9//+ifiKeR934inJFU9PcPDkJTgKYNu3fCQMLhHH994UrfWCn2h7gl9B8xXn1GZjg9ugebCM1lwIc6LhbLwuBlchsKReLdN8PKf'
    'iP+KukDb914U1CGLbsOIZtQhGV4QTxqqQz7ja5xjD61TiGcFcRnk4XgKnh4uFY+Xy3C3/zfCAM04KNqAEoyBRN7goAh/kwGV/Zme'
    '0QpLh8VB8PPcVmB3Q63/5JMkM1/R30dIVm+x5yUZ7Q1qZKFKcGWh9B03TKzAUSu4kzG/Q+FcTfeC3XZR2FLzQGYvngnQyGJBTUTe'
    'rorfdaHbS2EQ5cyEvVphp74eXuja+Twi3ItMBOWz74gbEoithK/OvkeHhQXpxsHxUHjg34hLNgR6A29YCzU4VBbbhQcGruue+7h4'
    'Ec6dRJACYGcI+9hbhcKN0YsLJA0u26oub4eLH86Yhg5JUp8REAaIMbQYUQv0ZVjyDKnboZdtLjvOEQmKwLcVVT8fYPMmoKWDpTra'
    'Fh+t6KiqfvyWHOr00inaGYeFdbCAwY6xqHJZ8y41o11eYVg4tug48nIDRxYW9wl9DQbTGJWkFypJL8j2A9XBPXsGYxSTpjOsRAsC'
    'zdAsx1E0T3JqmmIvdJSmOC5DUhTDUKTAkLx0RVfkNQWpJEMx1IcoyIwhaCFUTy6+1LNj9N4idBIoBiO8TOW1GxQoFM0jirSjo/oA'
    'a6PXkkgZvYj2ZEa7i+93jmIBIb4lUf22wYVmaO4qc64RiwNc6mFh7cZO+bpd7vNUAScJgw7yeedo0oWMz7sL5D+IB4x213ELGNYF'
    'Znd+gSQMW1w4yQXH6CSO0UkcS3jt8TaZ0PcewzWGFDIiz1MUKVKSQFPMBcsYJsORpMSIlCBJDE8y72KZyEnk/ArLqLtYFmeD0aAR'
    'uDHeEMO6bcAmfk1sJSZCLm9eL6SSaAe960bnDcpoJ5h6D32KOBwS9Rk1iEIYMZDC0MIFosCdf6+9EeKDUTPnMyQvbQGf+xKd64nS'
    'vUBVjvEXwJTjp8+ORISEkw1g/EvMpaLhRAkJ3t4M9re4ob8lOJgPG0fvcDMmiWlMEtPwRmqcva2onqzpCWbGZSRSoHiWZ1iJE3kx'
    'hmIUT2eAf5Es8DmaBkYnvIdjC1Kck+QVjtF3ccxKHimJJuoXBwtOAuUXYv5jxCVotFyp1mWd8NcYn4OsTLQN61zpb//9nxOreROl'
    'whR+R+pmYzJzhHWP2C5lvNUccPoZW52gICHPHMFeUDzCGXTU29UpnRdwUCtu4ChCIGvRcYXoaEnA/yNQzizGTs5zHEaVI6UwXHo2'
    'ufRscumrgYUGBpWGT1W+7Jf/aUjAfAgJyDPAXBJg7hZXz4sESpuHvqEXnHf2LwwxdYaYT0LMJyGu38bs44CKbAYA4iiJY1iB4/i4'
    'ngCPRElgQVPgQZ/gePo9+uJ5WSQXV4Ayd+kLez1CZuHh752F1865EOTi3/7b/wwxDW7P5VhVuC7Pnt/MJtrDH1G7blv5njgUJXvh'
    'dhc9IWpMubwU007gnaTMv65+gSfebSku59/ooYZFDtZK4nL+mSjTiDP0EFf/ZNetUBVBAuADENzTaz7WUeC4fKPpRIWPtto0d/FT'
    'QrSzhXOvh2CPzEY9up/sBXPF87kdb/RwxY0/uASIBt5r9EemHAcPs0QQhXuvgzzUDCJ9n+0lOBIgGwiz8HCA93r7Peot/cne8CEm'
    'WXQ0qfleH9Ooj/CkkU/2hE8Lg1EFZ7+/11kv2Vnvk52hJNb3umh/lqsEJ1VGe9az55Pt3sW15FhKn6UWzbuca/JeX+QHGs/G2XU2'
    'LiOQv0WN6eqhLIvpWqHHLdBug6+2p9GHriPHR2CHnw92MdHJxfsV8twgxQMpdfeMJCEpXIWkcKWR46opb7A6j3fELE1TiQlYPsOA'
    'UEUmErLEJZa5tsVJRshIYPmwHEVJEiuKP9HL9XHrKTxnITp/4TKrTnho8FlWZgh8gvfdU3SWZuh+QZMcHmSc9JDEFdCrg40vfeKD'
    'hWP2DI5hRIcS3zOXotZvDyc/NxptsQi+8xW4jLCbE/u8wkOlsXgMEuRDNLqCO2YYgtX1wOdFuL6RRXnXEUq6OLFbde+ldL9jOIlJ'
    '7BOT2IdPW4mrcwIobBzDswwlgMpJC+w1tlECk2HfwDbhY76fM3xSEj4pCR86ryWhbNLoszwCR5EkJ5IiwyRAk6QMT5OiwPICz3Hi'
    'tcNA/IxbKjhyBmrhg2MuXrUrNzR15YfOm4c4vIKUYSmSZ0VWpDhBkIQ4vLQgZjiRZUSKZgSJF34IXOoKXHSKzQXaayfglRcwPMAm'
    'BrFIZ0iRpCmWYkmBZCQpAbDIZ3iB4RiB4UVB4H4MYvoK4ug4nQvUV24l6sqvdD5RJwY3TQsZXmRpgWFZkREoOom0kgiYwfC0BKBT'
    'AvtDcDNXcGNwLkBfeSioaxcFoJFL/Dus8MTgpiQyA0vPgRVFk6zACnHzSWSlDIyH5nmJBjuQFt6ltbsesAuMV6Y0dWVLB4c6XIBj'
    'KSlDCZSIEAFsUS6BDCQtghEq0CzFMYzIstfURjEfgi6kH7yJGgWiMAgXiK9saerKmMZnEMXdichpSHEiQM1K8FfkYiALQG8ijQxm'
    'iePBfhZ/DGIqCXFwGtIF4itbmuKvGQT6kkagZgM6zILzs2LinsywLCAqRzO0yADJxQYAfCQD5CeCLU2SrMT84ABCcsLpfpfoHRGl'
    '9MWLcM4qvHEZ3pU2QwnXDDtITIgzQYqjMjAgWBUJeDdLc3HahKXKACcHfsJTHE9J0ns4/pYHTtsuI/AAdgeN5QnlX3wL8g/Wlrr8'
    'dSa7Ks8+Z6V1ls3lXnubaa27zOVzrzm4g99cMcsuq5PeoFUcU/len5zW+qUBPCtBhepLDv953edyeW9mdI+DjVJ4Ka+mIy1Xhfbg'
    '/VJQJZdfTZjWPveRP9C35E3wL/Tfb7zmfsIffTMdt9boSkT/FLrHUVmXEWBlDF7XiO7rwb0W3XeCe0ap5kl0NQjuj8NyrYiupri9'
    'lXF1r13dr+fVGn4fA1E8eLPqcH2BD89TczrihgM8S0v0zzxXbeYGy3w1V6pNRkNzGdWe8TD1xTWFWtoE8x3Ns7aF+fLYAepJRmN4'
    'iR4Veuj9zgr+8Vwp0V5ivsf51XxbuiwGvDndwvNO3YDr1giKShIqtmYX+PNvj6eQC8ZTmudm+/wuV4HfXF5H5b3XvJ+rNHONJQy6'
    '+JJr5nKHXHGWpfd5mL9BMY+QbT8owW85/zqo5Pf7l/x+Xs3vxUZhv2mWXsVeaVXqlLqlfnm1H5cOr3K5W+pWCqVJZUUq1YO4KB3m'
    'Wq3wotbye7V6EIK2XwfQ3hzaY18KOVYt50uD6opV/9hfIQvD7RZyxX1utCzmejD7KwD9UMpnxddcZY9pC/qGssSfZin/OqnmltXs'
    'IZdLlRDt7F+h7ivAN3jJRZTTLa9yy2aptBxUXvrl7nxQLixlQMxuU2vSteNmVhrUirXecjkfvZCt0savHgZMZ4/6BiRC9FgOaDf+'
    'p1SAvsr55fwF1Wut4PmyBDC+whw3S+e+8/D+EsPZg77zg1H5sJxWVvkD9O1Uu2yvkxfzr6MmWeu7u2qWXsJS7kto/MXSay6ba1tU'
    'xeouD3z9dLJKUtceTJqVUh8X7ifdzkDWK8X86t/2k9fBpNR8sexWb+sWR4WV3qvx64Hl5Khl88UIi3N7TTWpurxvTYqF//WfL+Fx'
    'sdbtmsXXAcxI7+iV6GUr3x/Iq9W/iausXK/b/MayrJE1FDbd6uCY6uwdf7boUXJPtnXBHrR9Vli7s7wpU68aldp6A2HY7tBb+nho'
    'FdbM/LBjptzgQCruiVyM+qrcNVvZwZTZ6ebaSjGjOaWJeWO86dn+dns0QHFeHJtHw1JGKW/7oh1mC9bo5cTtcSd3HJ23aJ4117a2'
    'rWX3hVObcoW6rMxWw8FpyJw6wgunSuRpMzAl58Wj9najL56GnFHlRi+7VGdqW/3UtE11Tm2xc4T+fF2W+YFtjXfdgXBqkgy95a2J'
    's07ZWkPv9PfMVKytV3x53aC7e0Hv8M1Tt2NUnYPUP3mwbEr5NC7Uuv3hZqJ0JsZsOBNrr2TbEhqm70+2LiuORdlZkYdOu8Zb61S3'
    'tlcXFpXN+Slh12X6ZJ+JJnzLTpfmlsybdXk9aL7Er3KWXaiUBgGVvwKW/MvTKyzoSrYBE7rUcNQtChO60/dWjd2LNbAV3WvtZnwx'
    'R40HdaWzF/zh8GhqUyFldypqfsOqrfZwYbqHrFdvSYdRtbuaeC2v1FdU2luU+/VcRx83joI/XTg7xlKGA3/amTbKW1h8jZmtulVg'
    'kocjj6SonjLdfHPx0pNmlswoUkFd9e1iidP2enbteI22XXON7YpqH2hvyA9t3bey+XFzQHXpPpkqiQsxR5Ipny23ZyvqdadZ7IE5'
    'SKe1gke66Bc7tcF97pRflVu40qDp/Cvwx76iNEjL2wxV3R5kB1SjQvFzu2e8+GSDpxpZPUvPLe/QH47NdrfcaXU7q/Kg3zFnxpSf'
    'gICgmtKO3DDLXGe7l0ah5LG7dXvYVbnBpHrYDK3ZQdDllNOz9eOpO5z7A3Iw57Yv6119pg8G5AmWdckyGKQqRZ4OtXsAlyu5ScDS'
    'Jq38a8jS0D3UknNkubJsQYUWqgC3+dW/6PMCXVbG1aPc2JldlTl2dCgfzQHPjrPWcMsVLVubGL6xHDeGR5sal5WmONGNAWnrw/rw'
    'xTF38rI1PLQner22ZobTznDMVqjOtjP2Sju+pVMTiW5XU65UOlDZhb2RZFLoeBy1bXjVjrW2N7kceUDKXo5i2ozUVBqtenbkCNlc'
    'ocnUduREsmSeEjdS3ehMy0c/q9r+UOJTrFSg87TiT/1pf8tMsn3vyAqyyTV87sRVm0JPtvprunbga6m2Q67FbRtxj1ZOLjK6YdRr'
    'Xk4urF8ry5CtwAOQRLNXKINf9ADLKRPU3Vl0E3GgQFShBkIB9q9bI79lt4u596KXD2XHlPhKC1WiUpY81mRjKp30QXfY5w9M/7Q8'
    'zseN3URXs1N7sOW9qdqZC472slsN6TI5LHfhb1ullvJeVadjd3eweWOyO/Wrw2Z3mJJqpOTItNAv+CN2qx6HKXKbdXyaL6m+vzVO'
    'g7243syUQkvuyvyu6r9SCPJik8zSMr9YU4fxhjrNx13RVevzlDU5Kra75SqCbGkGZaTU3I5p6PxOZW17xwOO4sFKRZd2FE1rKP72'
    'xVrrpfnLktv6ts0NW4grnmeowB5DST3KOxG6o6FgIoCr/MY09xP0P1rUvLbOL/f/9n9z5r5YwGtdb1bqleGLgfFyP9GBA04qbjng'
    'hf+LX+W7y9eA7GyE2pVxqYcY1wgzrhqs5DBgXFtY3yFmXOh5aX7aNIvFhWQdhZY1kIYySWcbu1ZHl8ZiXxYa9bG7Wvhk09hNDjN6'
    'sR51xFxtXFI71WOhJUJP7eZR9dzVMKuIFaqbFeq6ne2ux1x1uGgy6nErzVxLOtLGYU4pJ7lfMFOjqeGvBXNm8RV4v9NsGC1xN86W'
    'j+1Xg5Xp7OtB2C6McccD7uVky4o9Zre1oTecrrnZPDUvKp0hQlKu7g839rqxGetZZzDg2v2eQ3JlqiwOnIGX3ecpMivmynx2CT2R'
    'qKc63+5z9XWquGlanbo0FE81V3oVT3J2dRK07Lpb31GvPjkbjmopWZuIu32LlBowS9Uc3XbbQ3PG94yqb0n8akcOaLVGefJwcxQr'
    'tnGwveHLzh9zW0WmV/uZUZCt9W4tNGcWhbgO1a5RnT39emxsnKk9JsfysM9IzK51mPojhyqMG62jxr3unMHwxVZZWjfqLsMqvl8T'
    'rAIWKGj5ytz1+r23vn/wOZRVSgs0ACfi5X18k7fbE37FOuu67jEOQ+pcO0XJKW9gGHwJ5M1uWvZP/d24rlfl0qxmNscdrpjf11vu'
    'ruaN/ANpjRz+mOopvFGcH6jFsTKxyYkhGHKKdyhHWHSFolG34Y8Of0e2pVLDoUr1jeZOlpluW5hYi1mn0GkYUk5xjuMRZetlk82W'
    'bWecUgW6Bk1nOXMuHKuDToNzrPmRd5QCcPSUafjCULLs/Zzb8J7OVU/U0bfbpRx058B/Zq41v/ZHDQ4i4Acl0A3qSA1ZcljXUuy2'
    'MLG323GuvWSztqDPp/bsSE6HBVXzKna21dE4cldRxvOx3nAWzKGe3Uleh7PEUae9nM0q1Kl5SFWkXZfqHyR1ArrpUPGFWY+THcsf'
    'NJjhwOYbQl+Qi8cG6PineYHVT6XjTLcWPa0hDRetNte3UzWe6fKzRY1lpmC7jChRXmws0q951TWjlhl2KrLiXtkg/F/nj2K/7Vrq'
    'oSGV+fXBGvsiKVW95npUXJAUSXV3gyNbqIEkL/hIHowCHFGAzYSYMQ4kA8aXQDJ8tka1rQyUAd3uMIdmdSTpNRoW1pmNWaeafW11'
    'NrykTaQTMz81T9VB0aZbs9O4NVcO5SI3FLKlYdXyBoonp06kKht16VWajWc2NcmWBo5sCvqOsqTpotbpcg6d6h5gaX1hbvvjOm/z'
    'vK7aYJUNh3p/zKVAUHvkJFtRd2a21jwq+dNuuHuZL/WhUc0qTUU92OXUbrChFrWdPOd3smPn5vpm2mJqNiN4/c0yl3Pf8WN6K27U'
    'XzGb3cRL+ad5n7LLE6G4Uv1ytz4b1+nWriu15L4HiHHMvrCbylSbprpaTxj2hPb6mBc6y6lfM+jBbqJ2Z7uBqstDYSCSAilZm6Za'
    'Z+nuZuJRDb+l+iOZlGTNGoyZal/sUweD5Qe0yFNdnazxx8XQmUnltnVoWY3hopCtCJ3xaQ06Yrmm9cnW8mD5Td5hxy3ZkKzs1NFS'
    '1qI/xiyKe/VaSn04qIO6avJ1Q9a2KZdr2dmiR3U782F1v58gF4uIZe7WpEClciuhmYkfvaIn6wrX0dtt9qgDa6t7tD72rbFnj+ka'
    'bVTFEwV2njd0NFepl4RBauubfEoeZFvZl/3cGYiz8lrqOWuqe3oxlsrq2FZWojJJbU9zTTt1+apArUoC1c7xa94/zoVZdd9yZ5Wx'
    'O7KyDmWJpVXRgF6PTebFPjZtaaz4lCINe9lsc1Pqb7xXipc2h1Z5x8qL0YKjy81jLicHrreUzPMNpU0pSquu1u19XsrtG9nmXJn2'
    'eXrYHexWXWkmFfM7pcd6jewr3fAOi12rZxxqzDS/e507Kr892jvXValuqja0U90V48+4Ope1h1Z/D+ZvQTm+Km7fZ5yhI/SEbjdV'
    't0rtoj9Vh/MUeZxRY2NkbwoLZSnYO5hEUxCP5E4fZPlSPaWyR8PfUUN1WMiW2H1J2OT4I0fVlla2KO+oBWlqC7sHeqibcrRxWeQ3'
    'r9wS12o7trIY7jf9k78QS7ZvuWtqLpPG1rblUklwc4wm9TjDdEclScs2U0N+c6KyR1fp8MPU1Hpt0bmZrpqp16zuLoRhapLd1Yzs'
    'cQJy1wNRuM0xk7y/gZfI7FFUFuglqUY1trBsa4d72Z1alby/B94j9adVZ0JZi9rwNUXyhiO1q72dPs+ybQU1QlLVgeQtWLHndepe'
    'djm0eB1sc81lSHHTXWhzs9A65pR1l8ofvPFiPLdEvrMZe+Lh4C0UIIBUrdyX+qs9qpWdnZo9lt4Op/Zi77zuevbwRaqbtlqvGrUU'
    'SQHjlVo90ilsVCHPN6ftssH55aGnTRX+wIL5rzWE4mlLHSvKLJt7afripjGyzenQMfyeKQhUS16oZp8tbOt2TWnar6o3WYyrrVGp'
    '29gJnY1pTLPaiB6L/KjlrRf0akR3m8a6vhmTzszfCXqfNdYtx5699IVxxRvWJGpopabbkWrNwawbV31ysRrWd5tZgbF9ReaGp87i'
    'kLLaUk0YyrzAjmyDl5yG57CNWXdBDnZ9yiJTtuJ3FUsUWl2WmnK79WyXMnurRcErv54a7e5kt5gwjnISW736dDDrTvVO+0XcHfu7'
    'nuoOFVnMGYq6AySz+uWdmBszJdLXnfJR0Cx+aAEOL1R1lrNsWjvVuHonNyONGbeQzBY3HDb7a0epq6uZJ1MqV8kOyPGLMhC5re3T'
    's/HUGlOzDlXq0xadEkmzWZfs7Vhlh0xNbFfJl7khDOEPcIeeA2sDhstOtg02Nwmd8nmnaRjttpvljsxQbMgdIcVSfp9qDWlrPTnW'
    '2OG4vlsap7aSBysoN6u+cM5mdtptGrP+3rMcISXuZ/qRm49lbjwc7dYDx9gXrJdcrrT8VNTq6FRfpt4alGaftNhZ2+DqU2ptNzb1'
    '9nHH14VUXdelU8XIF7RXpTXht559HIsjeyvXDQn4dbYlztSZxKbW473THUjZ+XxQ2Moveb4280eC3qbASPQ6FX3ccUXedByPmg2G'
    '1MBhTaeirMXTsWX4R9kmxTpo8WOvPjXzNNueHnzLJrulY1PeOgJV7qtcf8oy7bmiCmXfkcd7/4XZCdpWni4rp7wIPflc35s5ltM/'
    'WMP9a/Hk5ip/NK5X5D2mLigjGIO9WlT0UV5cLqtZ+vX334OAKPG0R1FwngzvVig2yqJsmyB+i0OkvSCo+9R7erBvIchsjnIBz5sQ'
    'o1SmMMZ7nTj3jD65ic6KQBlXXxKJe8Nz3a94WwJURNvYLbxL5O4ZYBl0PMSGwJ+eQQmC4RdiEp94DLq9l3JHXWU9UVdpT8EO/FXw'
    '+T0Vf7yMcD1/sYiHrRlWyHACxYgUR0sSx8SzHySBy6Bcd4klGZKBCu9FrT+R176igw8jh1v9orSzuYzOXVxdcopjG0mD8aAdnzN8'
    'fAAeUOz4gOdgEaM1mV0aQXltwaX2PZH7q50f+N/Ph+JECWbfYyl57nc3ftZNWMX9/vbO0/ORNO45QT9eAQoN1UWbWTDgl718iSy3'
    'x2XxXYSJ42XcOxl3ZZzAp1ru4x12H9lrgKnm/naDqrn/g5sN8OEmd/Jjo0NPcD5k/GSTj6XfJkk53nD0UaiIthOHwHyscXTOzp2W'
    '8ReQwsRGaC84audHEnqBlRGuM//9P/3vHI//nePxv3M8/iVyPEqlnJq7yfGoYpqC7vbXOR7zl/zrBOdQFBbZUq5Eolkuwj2M320W'
    'Xl/z+YAOojyLaqn7smq+Lvuvw9KgfFhqwy3OuRiYfaUwLA+pDT86uFK1Rx4G66Ze60+2co89tY6m3Vu/Mu2C1ymifJIZpuVlM6D5'
    '2J98bpDP7SeFfBbgKZpdgBvuS8UCwIrr5y7wlF4HvddpqQJzv2oOyweyO+xPYPbdeWn0sn45veqNlVgcH+ZmXXvNZoGu9jD/uULp'
    'tdnNFcWcX8kV9+oy96/3Z1FczHazWXVWm+mKfaxvrJeNwHf51KHUV22pV7Ntgyn3XUEcnybWYd0plus2fWR2Sr7n8uVh62SkhkeL'
    'L72ux8O9XWoKR4GsdkHPmc8ZozSkvGxXpTb6eK3nRmphOhrZe0qXD2WS5rjt/sXPatrLWidF39g0F8xrVnpZ9Mapl+Wy3BZSvpTd'
    'd6X66tglt/U9ry5S5M4k+7tLPYXsZHtVEqzUl5f82qIWErMH6I/qRrWyUk88Kim+ms3VX1MbsKdKbbixinwvewBEVdpO1k8VqnSf'
    'XFOdrD3e4pb3xaDB5kpuD/JTjl85DWsi+5o2XteKzQ194gbkzBcNsy6CNZLyPQCSMxCMvb2tdgBGmx4v3Rbr6ZK3UY5eeVodkput'
    '3dpMnUNf00xfKos9NK/iWhwPK5X5dEB1ak1BqjCFrlvuVx3Grvucky3ZdVudDbzluOzM67tiW0zJvGSSXt1XZ6dtgyezZlZeAo8b'
    '/BwsqjfHlYq89cv9PtXedQ49f1pzDvRmOBjTOnf0s/XckXfqPX5YaTQ6OZcqDxoetRnM1NRqQe7IPmOLw7E5Ho+1IW2SVn9pNeaK'
    'c6xTBX02bvJgF9PiRBwatpTqgbkzmEqDc+cdlen2+0xhu7TI4dSqjdx1t0SBYWm/GF7jpCupvqQzo2GLscQhs9UXxe7gaNW63WOL'
    'HKl9xpHKjNBQ6w3SsSy/2zvkQW/q6YXiRuJEh5P5Vc+fbcuVrShU5jt6Vx0Kbi5X1uaDn0NM9otd1yxbE6G9Vn9XGaXygtd0qdnq'
    'uBl1h9SQrPur4ZHneeckW/YiT5tNf5dnsrmG1001GbdikfU+z5TnhUVxOOML9ISyagsxV0tNTUNeHnmxukgJg8X6RTxJ++qqX0gV'
    '7R47qlOKNmzq+2mBy05LjjRqVF9sy5SO1kE2zFrqZcsNGH8xqILxLOnNrmCv++vuhoKOWLI6EGjHblVKPLndpg7H2fjUko8F1Hy5'
    'UrR9dkxTik41lf2iQKHmW5VatWLXzMOxdpjvrFpRGFTG46WQZeS1OF2qvZNgUAvRPi6mrxtXo0ySG0y8wzgnS7Yi9KiKVyjLvd5i'
    'YrUa3FZT7GLD2SvZfQGNrLmain6zSG8VVyqvjutedyc0LM+edVWv5Q3J8WFLLTf1VX88Mp3lgJSGO8uZ6qMNlT0utsDXe4WfyyEL'
    'NX/YggHlRfuQnfZL7qY/t2dMxy5yw3XquH2hmFT/xVf7wF82fEdrJ4cPtXUDame54SZ1XNWmZSvVL83NnWiMQDIC4e4/BU6n4tv8'
    'aGnV6r5nT2TZWPflRaMuVTzZGNm2YttqRbcseWtueu1KTTv2OuMlZQMfTy3t8lZfb1mW3LmuC6Ap7kq1B0rDMSlHLbSHbf2IiJci'
    '2fLKShnHXc2rsT1h1J9VjrrSk0+rhjedVPzT+pi1puNuTa2ebEopjyrbzdywSHJ8qp4k/5Tr7HlHGqjDUZ6skwVaYA7jzVgjR4wA'
    'uF5lyrbKTJdVVhmm7E515u6LYtvODqv6cDmVcqOdmuqAtioV6Cy6eqN257XsMLt1Fqbl1duhq7xsePQkn6oOF/b6NGm2pku2cyi3'
    'acNTRIuhitJpMh2MaoLOb7p8zd5tqPosXx6Wu4Nxd8DW1ZpoCIojuNutOuVrXTnF09vxIV/M5gqKq1JK1rLENrM1lc54sFm09/1j'
    'm1o0qo5pt8fW0LaZo7nTasv22HdkxRsq7YW8NhxtVV8N5rUZaHqv8rVi320drd08ZXb0UUeoT/SNNtP7Kie9Lurugh4cKj4oV9vu'
    'XDQWotEVQYVfzFNOVh/1hXoJ1d64KU4aZ+uuQQ9qjRevc5ys9XJ2wzOgH/d622scypuqTNdrzjh3JGl+OOFtxacaL5SaWk/33RKv'
    'jxc7viRaeaqStUblXX03FMrimCltT14dMeB6VT5NnIO2K0r2dlRw/UF/uhUn9IvDvOwG/lHjG1y/orjjYnW/XXCrQ0FGYT8fhtSW'
    'dw0tpdd8o1Af7xaH426j6H2uQdtrie/PpGNq1TJm5f1BrBmpybxNN1Zrtg/40Gy/9PNOiqZNiVSL4omRtrPOTgfM6k/pw7y5KEyz'
    '22rR09hJqnTKouq5c+3D3cpVq89m917rZQ1o1AWBW96sVE01+vNXtVjnZvzSoA7r/WI7WdS004E+ss6xUSdJsdwv0LKxXQPzSh2l'
    '9WZYFvmq+dpY7krecMWznkoJBjnXzI3YKZf7Tt8eFtSXaaXfberafM0yXvc0ru2HZbauUObIH0gjq90bneodeWfvJnPP3uont671'
    '1cnOndK5vKqPzqsnW0YupWxH7ZfqIEV5TtfvKoZEKSUlexj2jJqq8eSgfPR0kCCWT+UH+91q03dkrtxdOPUJS+2ZebPOruxGd/7C'
    'vPAtBRhxq6Svx0sO5lnyx8P2kl9vpNHaPVlCiuSr3bqrbIedBb0t5/KktTjrGhVpWuj1m6eJa7+K47Yuc21v1+pQjZneFKqrU0Vs'
    '1fJa5TjyxSZYhqO6bVU6XdrID7sjQepMprZ+6pxe3M2uNWyR9nDYyeZKPA8mdVbc0Dt5nrVV4EOybfQ2vjXZD7bmaOD4ljfgGvao'
    'QL/WuZGj58apcsXzh7onja2DUuLInsMrVmcyAzs/67b69nq2lmd61971TlMdWER3MRl4/a7gV/l5Kj84kT63ShmdZT9X7DnDrbOs'
    's63+Vnx9fW2PGa93IEeGMd8aXsv2pJPn7WfeoLy36l677ZZO42yuXH+V9YLTz1bLzqFbMrr2AGh2MFrz+5y8HuXk8vaw3a36DW07'
    'oYXTcdg66FNvP0ptSaXJtfgXjrbN9Ug2bdmhGqbGy+WZ2JsDv9NV6TTrvI62pz3Pe8MX3dC7bWvcHk/HKao4Lej18Wh95Grl0+ug'
    'OdbznG/b9rYx6B9qM3usZNkV8zqaMStFqg52XNflWy8Hz9xtwXJX8tOdWmZIpZfVi/7SZXYFgW9bi+OKlF9pYOZXasNQF8xGS9j7'
    'qbU9Fs1Dpe4y7qE5GKXaDMOUOlOlVa1vTiNlNRBaVVODYbgTTaw2+H5/7HLAaLWt77qt+k5WDHXAiyRt7jpDWnevVAaD49nhST2V'
    '9rsZ11hM3FdJG5Ab+9Se0uX+jlLtF82xJc3Zg3bT3MUH+GqO5rzS6s7Gg9YQ+uHUYV0skVanA/qruB80E0NQyPJWYseLLtVIDWb+'
    'ulfPzrqLZrnY5gsnVWzsTF7P1tujudlpUc5mOB+9cG1rpvR49dhUKpuWVxZBB9k7R9Od0SmltKPysxnVt7myYp5cdVjiB92TKkmN'
    'YaPK9TmHHZyqFuO5oqh35pPRS0pd2oOu65T4cYtkOjPHp/oH2dzaFV+pD1QStNttKpejDDMn1m3X5Ict4KTLZd/ZbLo7alty5rPJ'
    'xBqMZd8d2NKgMVxIPbkk79SRBPrIlipXD3LXt0aU7KTG+d2+6762Cs6cbHQrttUbtMaDBuXTo5okO0IxT/kyGCrdgdVQentZLKuO'
    'YRtUuTXmhvK4m01tx0KJyVYPjYputqRBtrs+yGMRNIkyZ3Q2i7XGzlnfPzoVT+zNikpx11p3yt5h4b5S7nFxHJC9l53bHxyog9d+'
    'sV6mDWsu13dzZu5wFv3/s/dmS4pkSaLge36FpVd2OiTugLHjkREhvoHj4ICz41FxKwwzAwwM21mjQqTfZh7maWRE7h2RmeeR+Y77'
    'J/Ulo6rn2ALuEZnV1f020V3phtnZjx7dj+paTBdEMVt4qMHGKHO77NoDr6drjX12YReWiWJbVe6sqr5PJwCYrN1eXFSn0roEwnzr'
    'oWWG1K2duc7uu+OWN7EGg5Gy8HpT8XHdy0j3tZziVUbThlN57i8GGQOAKLEqNDfd/PSxqN6Mu5oFdHwxt2rV4lP/aTLOPIo1TapN'
    'n1vPntPP7x25XWo9qY2DkZv28w96bzR3n62pfTCy00P5Try+KddazXAo89JwPHZX9Ynk3aj2o96pwpkARrq6GYr7Sfppeyfeymaz'
    'q5WeDtWeVtqp1efDsGRkdt1evbDceLvZYjAYVLtPLzVbbYxk9UEuDw9bHRigVUrtSbeqN9xUEpu82mkOrVE3NSpp9+t8wTPmjUHC'
    'aSZKykGctG+HIBRMyvmm+WCppdS0VMnfpQ1lijzrs55tD9zSo7QRXzbZxVp1XnJdEeY0Bf7vutzIGsXUbFNTl0WnnNrXukXDzqj3'
    '3qjgZouHVk7at7dzEK30zqgxGEkdrWDuTXkx3lRsYDudfAVER/vx+SZv2Hq2OZazpcWh0W+ArJx3c2PRqTbHO7spic2q12ned1pm'
    'qWDrlr1urwq2MTdeEsXa7uGxUGn37+8ao+FzaWWPRo3FdfmQ0W252b8btXLr2ditp0rXN/1mb71+ztzX9cpQsx39eV24n9SXi+lz'
    'vjmVuuvbQW/jrIxEdZJbapX8yErNV/uNLubbynbs6J5as4cvbdWzaw8dpzC0i4XFYDJflld3E1j4Xqas91xnPe0OGkq/pNXtRvFW'
    'NB/F9qhht3NuezfSZ6tnUc0vMrnpuqSZqULv0Ntusu4y8Vh/XCiJ5eHloZOYSJ2hYQ1L5t1DZek51qM1mY669dUO2OcnreFJsloa'
    'bO60Ybo+LHnVgmvL6XGjfdfbPe+GGe3Fq4t2zck/tlJyXmnnlXkz1d8MJyN70Mr1FnXNLafKI/FpUO7O+5bXWrrl/F2ztPZ2Gz1r'
    'TzzF3g9dx7Y7L4+WVRHl8j7VN561x3XnvnOffdhd34+t59suSNtS6T633DX7ud5u2qktxcwMZM3RzWO+2rIko6PoTd1ZSkVJzE66'
    'jexhaKVX+7G8T3utu6dqzt29rObSwF5vX7LDfbp/Z+VrS9u2KqPyWHNlce9mJ7qYHtjtUU+e5+W0MTvM5tf37rBdG1UHB08BJhr4'
    'OcUtiemXg373PIKDU7fsqrPpvbzgFEy7YTn2ap163qoPsEyDkZrLGZ6zNIvKcCxZ2UFlejfstjqZvVgZdVZbcd8a9HsDILlre3Jo'
    'ZR821bvn7WTyIl9nteKLPHIelGY/fdeYvOQzqGNcZK2n/EEfa/XdveQMeuWxUdkrj65+2Ld3g4n86O46w1HvrtT0ll53VG+W9GF+'
    'Yd0Pmy/3c2mxevS6tjZ1LRgknNimdXdT2TZ3+6EnbteZF8/wyrY5qYzE5cHqa1Yxe18YalPrvjzI75z+YJDuVAbN9rQ2XxUH+kQz'
    'quqTPOykncmdZE7aw4Ml1+dpLV3eWFmrlq+8PGRte3GfGUmP1lrSpMJkln9sO9Xbp22vuGrP1OV2sx87zcd+JnPYj6xJ0W2tlWqm'
    'NRA7t3n3sCo+HfqiuutnlMyms81WHW9f3a29JiaH3DWBv21khvvden37KFe0QmICgytd67m1u7XMcc2+2VSvXffpObfxKtsN0GDJ'
    '6UiNaW056I2ykg084cvjungYdQZiMb/pFPMtd7cer2+KxVmr7HqD8mI2SKcbLwVVNZb5fVVtKkBBH4DfEjtqvbaxng9eo3UzE0GY'
    'PoxaG7ectorGpG4Pdbugdh5r1jhbFw+DjqLOEk/V3s0ke7NSWjV3kFMWTrVlFrrWGJjNu7HpKQ+mUWk6I9mWGvlyawbMx6o5OWSd'
    'lwmMfGQuOodh4tC5fWx1Rmo1vZIqvRdrVZQHe3NUvK2v7MdG1W53suV1xjAa5sNNYb5/cbKVQ6tftIfbrN4pJCwlO1nkHrrDjNe3'
    'K/X64nnhNbwpnM5ax5Kvc5ZTye+H+uTOKRbUl+b0xbZWhUZ9bct2Y5iVqs2WXjNFpThIP/ZucoBXlaZVltN5tVFyq9Km3iobiYrd'
    'nm3aj1alouvjcV+0X+y9NdptOra6A6z3ste2+ny9SA+r6f7eNm5eqqXcBuRZ8SlzmzOl5rjf3heeBkV3o+3XdmGhiNOd+LBrLe+f'
    'nu6aWrXeetz0d3bNcFuHjKfuhm0A63Wv0x80+4O7ZWW5XLq1+ctE7fUmon4Y24mXF3tiSDcF4Fjng8rYTm1vRfVh2evcVRUAz0Qz'
    'n1r1E6Vlv9IY5FvSywC22nQaRdfJNyt6T1wlrF1mLD4ssu38UolWOa5e3RQbhUFBl0d5Y5POTxNu4raktdbioJOqllKH+lRtRZ67'
    '9ZuyXq6Xu+tGaVeQYQ0qxna07IgZG9B31ki89IqHtFVyGmOx0GjLhXVn011UPclOQOVbEAmfpL5hrAa76erBURLiAkSGTW1XXrii'
    '53p1rz2xX9zGID0orhvAOXVtZ/c0ux4N6vqtfvNsObdDOKEt2V4a9ck+c309udv/sf5Jy9aL1qM0bXeLh26tXBX7lWbjwdkO7Gfv'
    'ZV0aOpVSwlKXDrQo3+8Hnu0lWvX646jbrz92B3azNz1014Nhu3TQB3BW82ot238cr9QX4NO31/clEcTgQzdd7jz0n7ttbUUCqjsC'
    'CRVQZF0r35rWeKqvRkP4ZdzcD3qtgnQjOl1nem8XmtN6vp8x6ppSN1eGli3I3fWs3Vjo1krWHXnvNgerl/VLovK0dR+z3WwvJ82t'
    'wkAESc8BUdRsTVaD4lLeDTJLxSzONLk/qKSfFvNDZfjgjvKFl0WmcBhV9VH5afhYr86NQaG2t/WXB7c1sMutcqbY0xZKP1t5flZb'
    'k4L78pQHCb1aaViz4tLJzzJSQlnsYAcKhm5YYyvTa/S8YfemapYPlYENYtRAQRTTF3Oru3zfXYjbgT64d/TM/bYk7ptiVnIebuyN'
    '+zwbVwd3zn6870736Ie/3aWKeidVVvu6tNs+7UbzdqvXyIgDvVkBzmDX6A+U9l2jvpQOO8+u2nYN5DLgt6xWR3Wk3ki2BuZt/2lT'
    '6zVa46WZzT3nn9Z3dbXYfR48ec5u9PA43D13vdXk3m4baqEhSbYn27W1VqjbIARIq2Jut67WpM1Dv9p074dGo+u4B7vzuBob64ne'
    '7a4GNVHKLxcZgJpKWgTibtwolVy9794sVinAC8PhPuUq3iYxEEu7kVS8G8u9nGlP8k8F26rv3Wml03cnRqE4GWfbL9mVZtr1vOJ0'
    '1LZaeNiVnLWuyE/NcQVEzaUpaemmqW7Xe+mx0LherrX6ogpTLr6kx6newrI2o75j39Xn8zysIYL+TcN4vLesl1Kp2Gs8eJNmsyc+'
    'uStNKhfcxmqScNTybflxmFp2x/WVCcdRnojp7m6zritav96amPYWOJlyYtPPF2qa3C431ZZdWd7ejPTVi6etQSJIG+Z/WO/7sBim'
    'veYwLYsPw+cOCEGt3Tg/tqpm3snYuBSNXaffHoPoXyrJs4k4b7mrdaYyrmvFzGNhPT3IkwoIopaT2IOAv5E0+eExny4MZuX+wLZx'
    'KUG67qf6z+IIyHX15qnba7RVt55Z24ayHk5W/ZfaRleznX1JdZfbdXVtd3JyK5dqPVey7jD/nK+MX7xJ0VDl1pOVA95sCNKUIy1H'
    'ZdFRlaw9yG90bXuYys+eVarnusrzdt/K1NXVwn6xrMcWCEcH1F3LQ12XBpNdczu894rF2/WmkVhITcBQ2TXw863bnDrMPq63u8qz'
    'NRwfzAqMfoALo/TqO7c7PbQkYPKzy1Fvv8qVD0X9LldLdZuDhPRcEIeVFjAtRrWsGOlH5XFt3XQlqbwodufjRkGJFm7ly/t56X5q'
    'oVt/c9odr7Ljl2e3Uj768CAn8s+J23Z6MZiuFtZTx30yh7cJI/p6Zb/MZOPu9smreqN5PdPo9XZWVqwnbF3OdNr3wM0NAGfO87rS'
    '0dzcpKkM1sDTdQ/FSkZvznqjl1Jj3HW9snKjjW57dqbezOzavY1t5ayqIpnOyIJz3Fg/ZrbesrycaLdZd900t+k9cCuHlSPXHWkM'
    'UGnvi3pz0OhLg5E9lJfd9MYepDNm+26YL1ud8j3etIUTss7fPxvt2qF2Wx5bzrix0wq63RiMhy0ptXrpD1uq2+sN7iWj4lSy0hpY'
    'p45aLqS99txoGNfran54GI5uQYp4ybQ6h5f1uFMCNnVmtxU7336yvE7RkJvOfXfbb5VKUl23CvXFzLS7lWWl2dt5mqaNV4vhkwT/'
    'MUEKqGk1dXtTBcj+V/61HtbSTtuoeaCeK9u24YRePzyaK6n6oq+2o97aSgM7qxhNcWENW6mXgq5uNv3SqNLruhm3UAOU5zTntwPX'
    '62xeGqOC5C1GVscYbha5qvYivbyMDg+DSUIveo1mb7greuuupYvDrjmyX5xdyS4uAGN0x1vgjcvq4W6d3SRKXW1d7uut6dNQy1hK'
    'Ij/Nzsbr27vqcFKte95g2t+rCXWjbvuHtt1pV3Z9d6QbuvgiV/pSaybpA9nw0ivnwcruy1Kzl3V6Y7k5rIpjGS9LuOXqfmXl0rlm'
    'bj1y5E1lUHpZ7tsgq3TXlcPgEfDbZJ3alRbKWBpVs9OWOPJ6ampf2l7fGo3wMoz48NS4Hpi7abdeeLH74nac7dbt8Sq1vV5sssta'
    'ZTXfvei6BkdzlC4ZGwDGuV2d9m21oc2l2S5RazQmjfLkpTFVpIHeuS63boFJEL2R2dfE4ktPFR/s5WBQtkBwy+9X5ZWUTUzhP/ph'
    '9SC5o+fmbDBMKwcpO+yu5GLZcQZaua6ms89Ob1XR8+pTdTAt9L0lbM0k08qYBa09eKxVUqt0Th3NJpY+X2UfBrIoyf19UzOyTc1R'
    'mtXNyOyAkArbt9Zlrz22y71mxbFls5fXisNDY5MF3mRzvao93D00YYhNebGyV8B/FEz74bHV2P5HoLDQ0jVpvS90tLrx7Cxbrek8'
    'teiksrWnp53+YN4d8omHRPMhdf1Qi3x66RSuSwn/t2StHlZAGauZ8kt9rXid4aZX7nU7IBRsSlJqbeXEpldf9J1eH1b+xbFFs2+u'
    '5ey8lrlNjbRMpp7pZusFUVYavc5jFsSL3cjutPTp/cA6dA+DdeapPi8b7uSx0BU3ivtYPYwMyYAxScotNJ8/3GaHhfHuMNx198Z4'
    'ly6KSsKyTDE9tzJlqTwsanZxP32yS86kNytU9Enf3K83d8tiwZQNdac+asqDnjM6W6846dZsa5Qo97ONdWoz3bamxmjd7C8Lyl3R'
    'a6uJ1PZuo+yaj/vVftDZNEdG9WnoeAfTUTedXL69TSwNtd5c9ifj3ArVNrXF0Ot17nt258691TaNgqf2MoVFOZOviNJQqafnblos'
    'lovX17V54xRDuItqt7NeLMdiETBD3lmKnX5Bf55Pn4r1xwc5r8j1TqGxURrPVjrRapfa5qN9Y9vpsTjQOpW109KV54ykldKDzT57'
    'aKxXlZdMxi41V7YjiZm9OymripUqrzfPRtHWZ8VHZTJVHeVBbrwMgJ63a6v8YZBriPB/uUVf3stecaStH8VRz8xoa/sx6xb7xUwP'
    'ML9V2tzPW5lRo6IOV48P2/a4UCm0UsN0SSvsel4hXShnb/o1yeh7hnso5Mr53rOTra6AA89mbTVfzpaL6xtJrjrj+93hRR72691+'
    '+jCue9rUsYedfa28WfSc3s6cNA9pOAeVl5Q8by9aT7r+tCkow8oQOO98r5VrGe3n1G44zdZa6jyluan1c/kBpMDIB9lbLuT14qVa'
    '3/S12Utre32z/DNnJVFNZaW5q8DybWRrLVn1YXO0bxWm95oi2WutBuKMOegebg7dXVOzPXWpjJqTibTwxnbXWA7W+dbtRl5p61FG'
    '6d5bsp3I97Zj2S27CzXvKqP+Zql3WnfLRad5PzpskOOsFdvLslVur9RlbwiidmbcehYLKVsuHu4f5g2vvH6+vrPvVtzcpCHX1DBt'
    'udIsbu9Wuja99UZVURw1ZEfWrIP+2N/X800j0dkX7N30RTQtc9YcSPOes8vUl7KZSUvl7qIhWZu7xmGsbCo302Kjm1Uz3VKxKzaa'
    'ngaMnZWu0/8K5mb5NHvW972J3m6PnaxkrDtjqWtqq0UhPew81Gy1Vx4aVn+VTkijspce5ozusJiS2qa+kJVHLycChrguX1/fP+uz'
    '16u9vcmYzsMLsMij286wLz4dJBXt9MXyfacN8oL2mBPb69o03/OmzcpLsT0Z1u3O4Km0dMotfZyWNIyj0pk+S7bYWxUmS0DHuUL7'
    'WR/AIDoPw5a8c59zhv0yVPRuv7keZAtrfa64lpWewBLIGz2rdGvS+Lp/D2SgtH8ppWzR1qWh2FeH19fqXZ+idlQGFbGjVJ5z1zfr'
    'zE1p73bGEyBHXbHvbb19I1tutFIjJVXLK4NJeaQ1GsNWoa8UvGZTaUwbB6/ZdzO5rCQ1xGBdF8/Wqpffv0zmzfa4YU2sBxswtQ3o'
    'wLRTblFq2MZSfHHyYqO6c/YZb16ep9V5VuwZ6nhVsgBZPsrXN5OH4R8C9f2gZC3u3HJuC5xjYaBtVl7fPrQlo1TZS+1RbycBjNes'
    'AbBmZTgyrXHZBm62+dBE1UbL6t7JW3meK9i27pRqA7nZ8ByvZUqLQS1TVrfl5qCXuq7ahgEw3bLS7UFhcGscKi+5YT71nDeGXt0e'
    'WKVyZzjajID/vF62eo/Tp6bjVTNSpaBMpH2jl1m3NtLLoZKo5VKj2nRn9NTlpCe6ar2lFG7Qr3778rB9vCn2WuPN7uGhkL9LPCmW'
    '8TTKLRZleZ6qtrtNq5BpV6qt2Whk5+Vqp3T7rKYPq0aps0usn1OLh2gHi/RCUr3F7jnS+t3LcrOq5QvN4X731JlOG8PnwmPhoZoY'
    '3+wrQ8Op2cVK+eWmtdPMfL26GgykvGoVxU67pT1uCofeUFQP5i5j9HullpvtK/V1wfX0Z6mkmofN43xbbEtuddDM2aa40NdpZ7Tz'
    'Bs1KXgchEeALiGO5X0inR9aj1HIn1U7HWyzGIsiPQF+kFbCk8j1QmGnbWed1WbQGL5PDujjMDjadRXeYu75eLE/P1/24ZK52h1H7'
    '9qmyB2KpJjJ7OwEi8GC0yta01uhQXwxGu5r1uNvVdsvlxMxXm+puX0fN1qDSUev1uWOnxf4st1E7RXvmaHp9Wc53Z/e5XG4/6Jog'
    'IWdvxUHleiEODnbXHPQlcZp/qGmFx5xefrQaJetJ8RRTtzTVGOqjilUcVR5bor1Tnx7uB15jbQO5GE9gwdLP1VLZHj0Yu6eDuG6U'
    'nov9dbutvRiODJu8O1RGZSdXdczmobAe3awW11nD6+ZKiceV6u2m2oOk7/Kl3lN5oqXuW2M75U2vlZv1dLDPPaXHx013Mov9cpeB'
    'nVak8Qq2Nduyc959+c7rtZ8G08xm1ppl2whEUm3YyrebC91T7x6yt+bE3Y/qI2NY2zysMpaZTZdLm+Xg7iZX2Q+LVYCQFIgTN/3m'
    'eJ3WK3e2M2pY60y2YTkmMPa9jrrpyb26eC+JVQ/NDOnOfa7WK7Yy+k1RPpjNanoP/P1BHIzV/LSfv755eehe////fqCfSKVe/nrm'
    'B6YO0ogHV34omzimD8GbOObaO71uk3qjzlCdsAShFKsc87z4acoklgvxr2dzz7Pcq1RKNZJbbalZqqJJSdOZpfBX6kkzlL+tJAsG'
    '5qiSggnU1p6wgrcCvPXvz0h+6jKe2oblFY2fjnDunNxfYlGzZX2N+VG2mEkL7y+x1CjYytB0KNj2k+QsFXP79s2vk3jS4klA6SyG'
    'W29QkO5f2VpEgx8X0sl0OlNMF8vpdLpwFF06lysn85lyplTKFcW0WMr9J0ZZz3zvHhgN9PV1ry7L7SVF8+tR6tboLb1GeF+LRxvH'
    'NeR5runWG2by0Fkae5avJExaR2F4LwRFcucswLliep76+tLY5IOEeTIiodclT1A1SlOlGspx6HZvDuBghIlXMAPRP/79/7q2LH2P'
    'A2CZEFks+H/8+/8tsDx5R68FyqAVZosKYInWavnGWtFrYWFqRjhkY0+pqHgKnsikMOOVQLfdBEWbgjiBCf3CDEdJ4WTlecI3v2GF'
    'Ep6xpV0KsNKKrh4lUaT8Ya/zCrCbjzy713ezN0WuU03YBbwwdVS0alK4PUnri6lf97rqp7o7bvYklQorz/OLvZnz7SQCeuYkAvod'
    'gxlKDv3njla+LCYL6Wy2iDEZSqVXYcX9M/znArdTx2EQYJw4CwOMwzqjm7DhXE7io2dO4qPfEdSfzgWT1SUz6Xw6my+XMvlsNERz'
    'Pl9IlnP5fE7EGPq5vPjHc/lBjOnvzYWGdTqX02R8J1HTKaFNFNuJMP5kKZvP5cRsUcwVjkJNY1anXDZTzGAg7XTxT8zjR3GZj+dB'
    'KIMivxuvJnESRT1zEkW9hyjkdD+K5VyyUAa4KaUL6VLGDxfP5lEoJdOlXBmQdiabyYuZP5zHj27qHs+DEkFQJHgc1elMTmKtZ05i'
    'rTO8BFQUkBo7vSGeicwtn8smS2KhhBnA0mKhfHRu0jjvQrGYzRay6ewfTy0zLau53MnUcuGQT4KtZ06Crecox660AeQ0RZL/q+DO'
    'paNcu4V8LlnOpEtiXixkYLCRdAcZUUyW0nnYgnwmC5/E/0T6+Z171FlMywPEzScK2YAo8GQcrp+wJ0CGPJV4JJWdpmOaW8z/SSl6'
    '55TaLkwtchGkYieMTEMImBgfE0dSp5+7giGtVKRjlKbbtASiBIR16Yv2ipWDgY8xgYquARF09q+nE81rg/nMX6W0oZvPbNT+QIi3'
    'mtNm0hVrIAobTd0SjZMcAErcYmIUFZdymWBabvciyFvnXxqHWQc3xtn03xh+F+DkjY14K4+Mf+841m5W4xHSzDKfICcC3B/yFXsB'
    'g9P/KJkL8YuxpGLKu2hLWzitc+KXaGI+V1k1zRls8J0pw35HUiLitgb5aSYqZf2cM67JvYhsOj4x5pqKSHgH/0ej87nYSBbHMAut'
    'peMAIsmx8PPao+wyx0zVrWnto5kXnSAEA6VdjMzq7UQxf5B8MXOSziBzks6A57PCc+T+5yACH+v86QwymZOUBJmTlAQPsB1XJ8Cf'
    'EFyC8v+yIf84EUfmJD5F5iQ+xX0g88ApuGAg+quwMv+zkO3rAb9NvcMBn4hVmROxqqUjz0zIUlhbsMQKyRgrV9X/CwHjbVId5ow9'
    '4VSzJ5xq7R///n+ugE3GjN0cr0XZo0w2/T0u71QYzP8hMcM+XhGztAxgUv5eFJZKOCwXZCGM/jFRKbIHSQv7EEkxjIAJfvHcg0iH'
    'KYcp/eqWEqgjqrfWRHFWSeGa57N+FdcFO3wd1OU0T7S6sjyeFJg1gXILJQ3m+WeTAiUzxi6OQrpQ3mKe6MzCTNTmlKVE5mnBjmWN'
    'n2gTz5iIzrbxLHvCrvsgMnXMVZTFMkPO85TX5JBxwiv7vBNvKAAUM8JGvcF988ZOcxNnjxoLYs9gYwU+tZ++/Z5yZUezvA8//e4/'
    'yKbhesIvwnvBFd5/CDLwJe01oC4meZpOzI2/4yXdzQzK/hI7/4ssGRvJPY9fIL3WFf6WnvGl62F8HfaSnvEl5guHvWVv2Y/zoOlK'
    'q9mDT+eXEgjn6qW7dz11dSHc4HY8SXKXfldgey+AXZiZqtCvXQgdE2Rb80J4wEPvabIkNNU18BfXjibpMArJcC9d1dGm5+9+SqWE'
    'Gz8VOyVvQ1LME76xNG1XmLcRwQ8VFgDhGMQF2YAV/JhhtkAQvlVsd6JjJ3DOtBl0bq0dC8VnC0aa5LNpXzfue717mNCnc05Nzi+E'
    'c46l6ZHhP3pkWIUeGcNMj+ys0qNYLopyhh7z06wiswJlOVuY5OlRzmTyefn8s7+anVar97dKrdHAJeUs7Ln/sdtrdXBo54z1vOQk'
    '6mojBkVqT9W/dWsv910o9lXogsSTvhCeEEXB3waK4PB31EDATQvfwj3sPF33XrccNAsjuv/b4L7TrbWaUCz3DsAU9mWyXllwMDVX'
    'iCFakSgYFMbHwQP8VKt2rntQoRsnFR2SVZZTVcJUeC4wD4x/4wm+f/oJA/0AaqCoL+8JM/J+IhmrSVER02BQqFUEvODjjPhPLE6Q'
    'sbzFXHsubuFnXt9XtLjnmDMQm5FZGTx47KsEKNXDhORbikmF3BEmnMRpcbXiFBYEvoX9NCRAstjP12+8HxqcpgiXHzg6RS2OjsWE'
    'LfCH2LohxL4KuwthDwfwQpgL3+B8YWe8ddYhHDF4Zh1hbUrkG6xIZEKo8XJV3oWGTCe2sXU0wDsG1QfUcIGrB9Vh55FvJ8jYoRJE'
    '2NN/lwAegKCEmQqLgbOBV5pya64Nj/+cs8zZMAKo3lW9GJx+bHxtKGbXw4yJuNgXlD41+hsDAPUwGJc/+gtK+R784BMNfuvAj94B'
    'o0tD9GBwCKLYEbILD6QkC8riqyZKQUHLmgPU5r0wlXRXRUwGPNBQcgxV8V+++4mDs6JOpbXu4d7F4ohAYU+AWM0lV3N5Tiuooaj+'
    'MzHTV8I5y+IIB3frSBb8XsEE1iv4La09swdElVWATfUPzrBz3abZGEReYErJ4oXA6qHuBlNEQjdiMg/4azq9EmoGSFMaTCQ4nBNd'
    'ovMQjBQDm9UUqu2qHi4gjM2fUix+wUD9inbOMBUc+Vchjf/RFNpw5Gpg9E9BWs2LI3hgvAlnTQRkS3CqUBjKEUdyFUFT3/D/YLqp'
    '34TL4B/BJxeQmTAMIL6SPMZ9MK6PktpHeMGwNtLAgeq4GoijgFtgH/dCjLQfhFpg0CFqEQCDgHCGHMSGVyFhBgeA6wRLxDggDOBG'
    'I2Ghz7CPCUUh8yjxPJbfSnsYG6IuBbABGyuwfGtCUn7rmEwQWlYV1ikeCBxV/IoUPXCQBJAWoAjXBvi7FW4V3xNYNs4SAfmnxTlL'
    'nfFOzlhbGQFQJQA4pRGEbdHXLl/Hq1eImgbLqzNuHP5lhYAp1LWNytXVZ/zdmRADfgy5SRjOWfwdLZNBEdAQr0bk2hiDiAhAsPbh'
    'H4OLOHWPjOvlVDclOtN+z68rC+dYEjgIn2eD/fC2QKYFrm4PWudtvBMsmCoZIZh2mtKd8uaZpo2NgPQX0CLOBcR2zMoq6cBPoUIC'
    'pnukXAk6QXyD6pQLplzbai7iba59AQiYerAgiMjDFYknhQ6qYHCefP0AigDSVqqE0IhgHbQvm5YGAyUWFoR9ywI0OV1DJ5ssB/0I'
    'NUNdAxlZkCUnPYHpEkqfMzXQnrP3S8PcJlkXOcFXJsCkZUAze4DaMyIJMGd3TuIhxkLEnMQIwAH1gGl0AwALZ/+OCnBgCqYxM0lg'
    'w/PEZ0QceTgcbuLTGVWUXLInTADqLDxOSnSWQURHEjOwi5rhakwQpBWSAvEbiJqkw8l0v3+UOMIDjAk9VmBFU0jW8QGwMewH0vak'
    '8FvqJxnoiwuc5lZ18Os9YGQHqDuQSjjN7NfXbxzrRlDMe2LZRcCxHAEnk0nlIjiKjHm6iJw+JOpQIxPUoEX8bvnsRYDSleTpHPFd'
    'ON8Qs1OTwAmgQg9xG0IJYjc4aqgS43JUOs71UCwX9VRz3IiVigEQP0lXQmuyAB4riYt3D63AFsf4K5X/hOER7vr732EI8eRKsmKx'
    'T0sY/mekTRxU8EXXQyVebAmv3wNXmT4XPgq0bsaPyAvgxCtsi1aPrWH2dNWDVctRCaCS07VB+ZfpMHG6EVPi0J+jInUQWFTHpObW'
    'DE+dqU5M+ZjkzcRhXIr/AzqHL2yGHwGTAzF8B/JX0P5KA4j01BiGEIwTTCBrskHuItozfn0HH7WpENsIH45457iAsS+3RDaO4TB2'
    'buDv80jV3wUxWt4vZnrh8WDFWWJxqnHc2VekZBIMMITmT5vPfIg0cnz05/+ObBLY98/02kexsNve3lLx3EZf/4w7axKAnP+5cfL9'
    'wFbe/eQftOCsvueDRd0wnBRdO6gRZoe6fuNw4OsTfHB1NM7g0NBLer5gKmr+ip4jLBvDITgcDnjfPbjRxb5A+IQDwlpDaPf78DsQ'
    '8NzGv3eyX2OA4FzyUxdOJMnxXTxgaBu15v3fur1xgwS/T+dklEcBk9ky6Yl0EefAlV93Oq0hK2cAD4MfAQPiH5D4HQ8fQDqfY9Fh'
    '7a73wIqi5gY/sc3BJ7JloeganBBZB/qH3gQxHYGPy25IoM9dylh/xfkn07jkDKuwkUAoZx4dS9XyfkKCiVOSmWDFIVIXfv01Ossk'
    'N5y4MT1JPEE8LsjsCerxd0eV2ayj9Ygjp3r0RPXo6ageW4JoPTLmUT2W3x3r0VMExmUEcJh9R52sNV2JELQYyZwS4QwmOJBlCWgP'
    'SlOCa0gWEGovDquhEo2kFduqun6JgAiElK1YUqgQ8wBUHzsiSwJr2tiT8MkYWK4zAbQLjASlqafXgSlKJYYcibNPf7kMfI4Mj7Nc'
    'W8RCc80d9gQUGYQcirgruZcaDCT0ycEdRCMZ8RskAWNnrgQSDTAWypEeYH/uqD5P4nAhW1WSITSFaEBh6JbrsvBofgyODiNGFxje'
    'lX2IkCif1/YhiTUAPC6KUxuU8XR9wsTVNElXAamooBCmxhKbOMLAhpAdEqzw1znStMQGTrXfStjDXN1BkzK2mPpvf/mUvixLl9PP'
    'XwvffklpSVQ0xGRCiCj4x1iVT0t1j4QU2aMTqgszi8e5JZkV1lCkZWONQT1qi2PuV8ROg8WDxYAqv4M8DU8/GxGMbpygcWgfVnWt'
    'vov0hpbH98Lrlo0kI+XxaGGZs0s0IMWXNf3ekgQYxBO4xCLgIvK3wAUwQRT2B9rexUkeZT/28Qveps894KA+si2BQnwkfiEupcI2'
    'QF36Ead+6FFglWEjjSSJI7QCJJJAoVCyvfKVgZ9g7f7N/5HUVWPmzT+zrr6FKw9tIkqgFt/7Tb+PNs0ffG4nrGokSY0JAwlg7BUg'
    '8jKEdljp94L/MtpSYJ6jvlEbgTUib+ldZNj+zmCkbzbeiWkiHkdo4G/552g/PC15tBP/1UkPb0wFzbF0sIJnmf7iodGllRV7krx5'
    'EsRzQwmKXwiXwCgXIrD+6dzSdJ2Rqx1RMV3XYJJEmwCizj+HWBsaQSGHUQkSd3BS9BRtMKCbcAiIEFLK9uOGMJs7tYMP1Aw+HK3N'
    'aoaTS/23MNj0X1Mxy5j9HUNO/32mTf++VSdW3A8+/Um6PACOSKTef04EGIKaSeLZ5wuFP7fAT6Yjv+f4Ox4cOJm6RnUT1MNjwZu4'
    'ELZXQRMXwvwqrM8hmA090B5/os8Y/f9znLXaZdsTvGfVvr2GI2biPjridNToPTbGC/ivosiDRPz3ETbCQFZHjeI3fnQ5igTkBxQZ'
    'i/BziR3wVvAPq0hEAE7xZ2z7HbOrIGtCsfN9k9NqjQNAAZXpgCTEEpc6UCvdL4IKGxRxZybSZQJP1EZJyNpY70gfxGVi1QWpmHUS'
    'A4zDtLRcEQL0c6W5KK+FwtmRZVEAKWNONJJUVWSoM10veUwwjAilYBxBjOZ5Qipc9UhxixurfOYLSq2hDGPRdrDxvYNfPrV7x77Q'
    '8lmffXQf4nfcEP8rEhXsLDmX3JiFowiaDFTXPlbkqPCdoJBHocC2+Z0wcVRp+Y5DlcCakxQFmgvBLZBR3pp70oXljBkkRASdR0h3'
    'FC0zzVXIpzItg0RA4Hq0m4GkfEp7CT+tpF3sUiTGPwqOfCQoHDPUB30kBPE1KH6NEMj/JGWsD9zBcVqGzM8rZkN/i9kABopVYzL+'
    'v8x3/KwznoPmrZNy4fPRG8+k3+wT7Qy+e5sTYXaO9z47oSf5i2N+gr9OOqqlS7IaS/3VTaRmgMyF83gSSq1iACdAqdQYrK+YAfyJ'
    'rAfrh+Z+tD84rCs+PNgt84rGR7seFXeY/Icchx5yHF/9LeLvQiEQC7PBYyn2xD+e7iKAWe0I5v4Q3l6BJM3qGCRDZpWJp8GiAgDw'
    'N8eryuXYP7eqmXRkVblIxAAJJ34iIwerwk4IF4SD6SIHiGw9F4tFmB5bkgQ+/8QQhS9S+6gptOa4Sf+Z0BqzDvFSzMbjJvHv66/c'
    '6uMScgpJmoTuZcTPhT8itiFemVmIQMImiRJZicBYdI42H/xrTqdR1sJNYiWEG/YkRCxMvNXQzuQm/eeAB+Ms6UWIaLjKgNRpocYF'
    'Lbiawv0GkgFG8vUfEnE1zNp0jGOD4oGuZKkpbtAaVAQYAGbIQ+HgFQ4GhOBX09yOaRJZeBNT+1Zb8ngE+nsF9DFAxSgsHpHLoE1C'
    'od9r801+PxwPedD8ibrvX9XFgYWGxKM1YENCouR4sZh0IUyYCU/iHPzHj4KURDx5KcQm4bsJvotH1CqwEK1pzEBSxVV9wRB9Sh3H'
    'oQvNiEzmHztS63FFcXAJRJBYy+izQap8QGtkmiczu8aded5QGbPLNr4fD5ypwJWHLwccg2Ax0OwclWli8ILAW0WhjRYuFv+UhiOg'
    'RGarqJY3Z7MlAzYK5+9+MPGvr6euJBIw60DfeKTFddcTD/aP6NNXjgKRqXsv0CEImSKNdayB3IyXphh/Cb8TiXiUlspIRPEcxKDU'
    'J+0zkEwsbq3deUzGnQx2Al7jSPgpM2Z32nSKaxUARjhhQn7SxI1JABvw8d+EWEb4jb1u18ImFeD/+UtY10gRqKagPvtdaEcmyYor'
    'PoIuGZbVjNjkIsS48HWDAAhQ8yTJroDGqn/8b/+D+zQwF3Tm58O+oWcns64BteGXWRy02+DNrz3AmoxqIXbXJ56MnFcUFlPw5+9a'
    'ew78FvyRlBQXf6SNNpM800kCufFQ84VcQvgW+nWuZ0z74KspoKU6kDukZTg3L6RVOMK/sktmRLNgNsxHDWjXSaHuXJt6f2Wk7R//'
    'y/8DJV+X8dsIvaCWkX7ZzD6GA4p5SAw9WtBrJuRoMhosfO8T13JAzIx6enNroQWi4zv0gvOkJbfhMIWeX8BdOySHkDENKGSwutj+'
    'e+ZADkP68jt6gJH96/2ZJp8JkqNJl8yt4/0ZEo+zD7/jVtLdvrO/aJe/fMW6385SH35PQd0PX979dGLjZ2pxsvX+ioZPGAo+R0qg'
    'yY3hSNlDhVjgpiYDYHjqva7ir9i575OWnKneLbB9MI/YeUYJV5e0uRVyQWN0i/BwmliIqUvufMJ0i85OyDHvyC1PsPboUUfMBSsv'
    'BuXFIitf8MuLJV5eZMwIK8VbzQelcqxUCQ8V7OXtHFW7MjrKuMxl6Mxl6POMhkwiHvlbEmolN0ZmUecONVzrGmpnfO/xJPeFku9U'
    '1eJOOOxb8CKqdscR1BEFMXb9yHvn3ZveO69FSaJcPrvP9BivUK3f8Cf/G7LJsTfewlFNR6SePyloNkHQC4RMUh3hi2B1EF+zuZBQ'
    'aDDkGpEZuViPlE6BZVJJoEf5naRy4AEFvj2oDsdLcLSiPuXj5AFBjSmz4VSSvXqNEv3WYBcfUQqP7su71/vyz6zt+2Bt35J3JtAi'
    'a57o/wXRhoA+XvLHSWSlw8F8Qjbic1RuePUNdgnEVyXuyxt/OOyfI1vNG/jDmeC24zwMNno+Tk7Om8D38A1/i7BPCCgmp4Sd8/zy'
    '29M8/nA8x5ATYh6lvp3cJNcS2EF0m96espsRZjPOYMng/tXIOUUsFpG9+gGvxngh4/sT/yErx/Zno7nahMS2N/hO4mJ/5kcF1THG'
    'KUc51XZdVUd0QfsaYdTi/rAj1ZFti3MnQsbEBUeYFvQW74+T34xETghE18SMYJ7L+AUOE6nK8JiF6xp7vbDowMj2483VpcausQda'
    '30CARbLgs8jA2gTskycZGbQdwEFxkmhcSe7ocYfnxeeTUkImIqMCl37Ka2Hh6O9XvBgDqiGzdvkTcNFhSA7XZYXO+PgOt42JqpFV'
    '4V4beP5ogXwyEHFJwj4cFVghdOTiDm6K5nCshS1zMLJMjcgR+r2BPGswgEVRVVEQs0X2xfVQg43SCd5EcrAxfR+PrLi7hYP0xopb'
    'JwDKVXJMrCPln28GjW5ZqHKYMWTv1//Oplnhplm4aZfRIhYVmWERi4rMoEhkJyNF6dEFHleKcyZXNoGzjsdDkXiy724ZAg+58cjk'
    'Jew88nsScCaTfYsbY/5J+Y4YiC4DBrzbyfwhqQiCgS7tke7wiA2kgEgKQ3QYRLH/Ei9wCLTv54wrJG9XhTcQI/4KnbegD3pF4pxE'
    'l0gd8pJXWGJdaTZDJuXdqetbBHJdFOlwm/Q9c2D2WUxqmCxKTPwnGQhmxsRd1BX4aplQVfExWLArf82DpUQFT7CYFqre1B0KDhE5'
    'JVS4UmcW9sZx3pKGACtLeJTXJI0X/xIs/5KQISOZuAe4cuwUsnlGJ88WC7lUsmqjrxVbYdwjJBrc7kgWbLIm+Eg9gmsByR1UmhmN'
    'GHBuOHpaK38lktDqvSTPY7HlhaBxkXAZmPu0d+jyEZVlWdPXgPuhpqyyIxqh4laEiuMBpVJIEtkAkmwEK/V4jXw6FD8eOoPabz8x'
    'twbXxOtaAcIDmFGnU8RGG5V7eqDPpk9eYWkcDS3xW82I+lkSAwNbEfLNvh9zZAGxuWP8Q0BHOpsYuXChr5bPFqGDjcyEjRAAAxUg'
    'kF7Ft6HFXnMzwLTCx3eMj7whXsALuIVzjMiwuwiYSGIS0QTJXSFJi0i0j6ymdE93ttYlh+Z/3BBFqmDdsDWIIbee9kVApnXBthkH'
    'ewFT5J98ztZnWOl7nPk500eft6E8xcS5sn7Q6XoNwLCPemKCYKsyf12EZlzpd3iNg6WTpq4czkM76iVjiH2Eg61LEx79IdwahkZh'
    'kVHgglX+ObpRAW8WMkoBlwZ7KEa00n4jGWwEt/SjEKPGP8ArfAasmokD/WZv6ceVQGpnkihCK4jqHCN2CQAuNoEagNZ/Q7E8ym5H'
    'tH4fA7kTHVB8qRCbi4l52JFcnMmHEWM1fQThMhfHpkVfcDyugyIkvSlfCCWu7ue+cK5PB1lzkyS84ayGZW5jYhIbYQZxBq4Rojrd'
    'Bob6QCUMcwCZmDwkgvek44YPOfoQYUuRMkEjV3y1WUV8FfZxYjrHMcRC4Zrs8Ki1Jrt8dGhRS3mkUpq06GRzj0jpZEjEETArPDbI'
    'zPCRFtFlB9YmheNzo0YGgdwDZdgZF3cH8Ch5JVwJP//sOy1c+B71OBoACslVaZ4u05x7cBKujuEAYZPtIWxhEvfQ3Z4U4Z4oVCqT'
    'hJ3NcNsE7j9fNtQdk2MClC8IV8c7be1gp5ccPN6okH9VYU8VmGY/dFIlRcwJv4a3yTgWxbVCdQzQGlIQfPnla8P33IAV50+06Off'
    '8Nt0+02gv+43GOIvX/G+37cv76LmqSEer0Yy3NNMAUHHf4OgkcniGzIL/YZlae8aSVx7eoP3ZD4doWy0gDDEENl2bokRAh+Ln7nz'
    '0Efh02foACv1UH3EX0N1dCrCMUZbmR8fswY7ZmIyU4raxbbcicDlul/oJGqDY5+Qw9ARq9Ci8tWnIRCgk3XMdxi8YqSFlMtbdiFL'
    'm5OW+aeI60iolsaZvuGSQe0+nX8WUhEjme/bwf06gE+gLiKz9D1IfhNc/Dp/6+ucfw2tjzMJkSe09euvp4tR8ifE9cvYoobUHOsk'
    'jkv/Bovuzz0Yl6xqeiyYgoeHFf4XAhLMs5F84yggKOVIv9RgxwbOmoC9y3P2Dk9Gxl/UsD10IeXt/Ry0Fw/Hg6OAAYj5dJyzAB1c'
    'G+Bx6YaADAx5cLmIxWNy+Q1EEqdQJYtAF1uZrsc5L3bJx0XeUNI5+JLLCKJIotqsIzQJsosZnGUCtkTTOU/px35iKl/qQ4t4KjwB'
    'jok6cHKBIaTJTzBBoBv7+Q8AGpYOROGL0PJwyd7Agvp7GidBBg7PpYAnJk6fr0LoPWr6zbV+9db32Dp2M+jgVtKcOyAXrd3YV4YQ'
    'r/zKF4JC6AV2nY4QWtSJx3qPk4RBsqFfCh344Jh0rTHWQQESkM1v9IWK/8bBhI2fXnHekCqRb9UpdISQCwiCqQZY0yRl2sDOY914'
    'PB6o1RgQRuD4dNbHB2LLUFEGjuH86MOcPmTzR/6Wy+/s6XxvgSiOY2Sb+ESsEv2CNYnt58E7WqsQO7HxLmHyIimxXo1t+ebAlvFQ'
    'Bxt1G+VgdESiAXk2+KVK+ANbiEd/yzYTkQD+Xc3G5KcJH/fMYTPxQ+TCoNebX73x6RvX0VSBDwUhFAPVEKVgYQaAfFnaDu8sxchO'
    'QY5gvu0Kw95EjuU53sBD8Q5mbwAzjSp1dqh97+eI3BIQI48uIhIRihBlbnT8jHyIFxiPXpERj9MP4ff31MSJfhnkTcnHPEnX0jUv'
    'dv5X5tcUqF+5Q5zv4xKpTUsBtbEVXjslJFLxiEthwI1TKx/ZnwQSNvgv1b+iP1E/QpwQDJxMuKxv712oFg78u3ykEbGYRtz9BL9u'
    'tHWunCT8xrf4A5czqFOqH7l7wK9F0ThRpei71YVbesUsCMAnBlfdfOtvtJdLX3MdGYX2uu/QBUaLo9B9eRnWOprkUcF3QsRnkX/R'
    'gmX4FnG1fL1Q38KThQbmQKWlurIfHsIN7Zeffv39w9lntF/K/HbL+a/nwOv9Kq2sd+iT8jv90j368YF+zNiPM/qBYULfnQvfPsmf'
    '44Hqxpmh6ERe7x8C7gWvFwFcuWrN8NAxis8L/XfEQqjU/rQRPsAyFi4EeigJvwqZfB5/0cNnsmBH7mDtsC046fD/dLM8eqRQjQhj'
    'wRLQy4T/4uXgnCGDEmiTGN8jfdI+kzyIf0EkRAs+SoVRXeIXbOWXr9NYOv7tAv+K/G8m/i3+hSOXa6DleFUUXfZACggvDCODwIy2'
    'JDIAfZlpm2NjLkCPqk9RyCfhH0UJDM2k6hFswl7wyYfXzz5Bh7Cbk8+RqRNTusGJbhAt5vMRrna1i9IzXhldqozgvWZE3pMvEFRK'
    'QIk4Q7IKql9WqHNdGT5PN2fsrCuR3K6gv5iCxEUMtLbAUiCt1PEkhdQGUYAC0vWcNYnk0UHpPjZjjg8pAb/+G4lL/PsMv6P47rDP'
    'RISvhJiDSuDgVS4itGbwIMDIfmPjSSczedpimB1+0nH/08liHr7pJyoBPENvTCLDZwHcMiwIu+zx20lBIIv/RqQ3E6cHqgELjT3i'
    'L9mni9wn0wHhcgb/m4i4l58+gZwKW50G+vAJ/sr8MU2PO/6IH3iBNH+U6XH3+fOnGOOtpyD5ObE5rSLyzAV6+hyB7/O/IC6PDiCE'
    'oMhRCaBDjPiKYFAJBA5aDAS1pGfy259wypOWpHTxUlkMluk8DWQpifFVY+fnvt2kwjTfFAMNOWlukiWD3Mo0AfNSsACybAQm2wtu'
    'MVEEbvv4vlkpieY+dkGKjpqiWsTM060qfhda0TA2sqz6DhkAKqz9q2OlHRqBffeLtcfswS7X1fFYrNjTNIiTe3KakWWnGrAgczWo'
    'lGRRhi8CTT+7TU+KRYkqg9QRcRaRVjQhf11I9UdXw7kL80rygOlizjr0fqWqXpLUk01zi6IDxnRWmWUbmQGKreCHPoGFdGH2aizO'
    'nBD8aswJATvtqjZzjQrUirQ96AoI67gH0UWz16ogyY7pBqEEeet8xdGvBT2G1quJIWmoQDXNeESvDX32jlUY04jnwJEl1b/Vg+9C'
    'T2j4wAf+iRozLa5q9JHOz1MUL6dJB88s/Emz67a+pZVrEKPGpDcgPxZhtZmhapqUdyiE79nzPs5bJ0470ls87h+AXqDu9ZXlTMzz'
    'Ixxxba6B+4aXTknCg9OBQXMolhZ3QsXwIXCA5utJ8mQhae6hPfpnzX1YT2IR+138D0zOoT1wDu355u2QM/S3K6h1rBkLrl1xEsZf'
    'IBkLDdqasWwZr5mIt8hb0A0g8nIZ0I4DCCidzJeK8DyjZ1HMwfME+bMCKRn/IhbEojghvdZfpvTv/B134+EhPoPwUhZT1q/gYMqx'
    'uCApkuW5AW7yMUCMhRiRnMuJjlcIz0Ds8878rywsCYtEqRkUiVJYmYoauL/1Hu6f7v3YAlQOFcyTWWR8yElYGN0q8gaWCX9nlKyY'
    'LZ1TZB/6nS9k1ck5i7iDL5SJWqQKuGUYdyYpZpg3MH4tTIqZUpp7FctXjBeU8Vo0XjWI4RO6apC2HDkueJEslmBlk+kS0seLcEjo'
    'lKKqFq8VrUGl0vQPJF1yS8ZlCKcp5sS8WIpOU5xmMpliOE01p+bVcjjNgiqVpmpkmqKalQpqdJq5fDhNqSRNJ9LpNAk2Q0yBwCFP'
    'layaRuD4g0UoID1Piv4acKD6gzXwVwrXgMczkiyrhxAWdYrzH7hbXBIvj7mAuD1WEBUHuH7kec4eYI4EOSxI2i3TEjmkMolGxkLK'
    'xSgLhgORnMD4u/UDTsFP+oxu/BTjKvDmjWhhBGS9YGqz76nkjj6QKQAYtVlECSwin1aM+4psRKiociSmcpbUUHeRyVBDTCdB03oA'
    'HAgEU4hh0Kw4YcG1R7quyPwk2UNpnE/zgt3NwjBfXEtHUbWY1iWMuYutxwx1xnwq3nMVWpyTY5LoUeWn7iT0iwgIKoyAKBsUOahO'
    '1EGFd3+nof8qMWf7KAlDrweMscXMjQAzu6inL1IPdusVXfrD93t6vw+cLGZva5J8B5YIRYL2U1jeV/pAu/TbV/ggQ+pbl9hebHEf'
    '5vFjxtQ51cbNoC2b/DmZ34WvYgJUbePQFeaZ4asPnVNCykYX0FEbmdd4hLDae3wROOng0I4K2/s4FkAJgNPQ2/VEk4Wb//n/HjQ4'
    'ATy2m+QKnyigwQWpHhxTR08w/xFADvjAzz6gR42E/hmOUZg0Kbkj+ZDIu4R+KHT49/hlz77s6cuevlBUhtAhTD1ce7F2ILGFYioZ'
    'itqfkKdvfxI/X5A4Mgk/iPQhwz/I4YcMfcjSh8jK0lf6jz+FC/ZuQgID/vTiR5YiUvfcqIf/2uGFBvuTwan+q3CAK/8V+n6czO/T'
    'JzYaaAC+rlDSWVEpmfX3+XOo+nDXE5gXbidODQOeMSwezPho6uk4myBxgIiyPGTSPMay+Y9oWYb+mceILBlGKLRw15GNLz4gQ0QP'
    '5lbCiNgeuaddcPwx9Zk9fvPzAyoEYpQbwlGngD2UqO8IIRqUpWCgU3YXDe+gheI/xuLmHQaKQV99JdLlhfdCrsRvLUR17MEwE3h1'
    'HblS+IEQrMG0oUagCZ7GIkAcp/GG2kHSLpqo6IFxYJxAUvX5t6v8wSyZuLDEBYaxLGksvj6C7hTGoJEEVGeo57TfFTnssJ6pC3jx'
    'DvA5Rj40/Z++UpHDy1yL3lDmy+SdKMw8M1DeIM+AhMSRg2hkmPiDyYEYzNzcYtBKIBAkYwHF/AKvvgj/87+zII9MSxhztZmBwTWW'
    '3EuCCEoEH5hbik7JzwH8PHJrQaQaIBpOCAL0guc5UNL4GB4LxbmTq0nXSbi328yIUeu/nSBRJCn8g46BUXOZdFQ75AeHjDG0N0F8'
    'x0wpRD1wBL9hR4QAYwwDThD1MVxPJCcoxFwb/AMsXQQoAIA4AwWzERwVeTX57ItGFMqMXLCIn3FkRskxMkogB5G47qwNDH4517hD'
    '5VTdonwdzXUSVnXpgrlvT/uJx+0M76uQqlQRYl/w0oXx5cp3qQyO+wp4hCGeWN+uh6yCajPnGmobPRpZ5DVsmhgNfxSyjnfBPXOm'
    '0nUYEpndQIrzow5yXTVNkK5+SAJedtE5qvFD0zN/HABYT3XI2Q9NWFKg0IhAHsU9xciqMetC8H2wMBISzpHsEKckgODAQjjc4989'
    'hgid+O8N/h4l3YgDC6pg9GMYjcBzhFL+LmQzac43griW8/WIE9w2P6KnK6Nr3vsgJuaJ6YPi/05JD4ZNXAiX7E86maXnLD7m6TGP'
    'jyV6LH0+RoQYnvONYxk6r8+ZdSZ9QdKeb64/wbUZdlEsmz5CtX4fqC8JsBki2KwYP8KS3CJEEQBpY8IWXnGPpq/GCI0owcm2abFN'
    'PLW/RzgzkWyakVJ7KrVnpeZHpaJMLFAtGzfOZkVL7AaG56IX/sldff8vACHLV+KyRA6hSzTCpi5ZLAolLCWgS8wyxMiiYU5MOHqu'
    'ysORXx1FUmA3XJJHa8r80+8pnEB0zNbxmAuIHE8Y86PvUbvVz2GjsBJ0NJh/pBeoQnH9PFplm62ymDtaW4/Wljcuoh8YQg0sWIQa'
    'hd4dBFvkKJaGDSD4+k3IpX3WFxs8xtqX7Igx7zLiPuEQ/E5ON+lkmmLWRW7lu/CJDhFunH+a3Hf+KWuHJluOpPFDyEdRvK27+8p1'
    'v9FjAaXx5iQK8OQYdyUE8VJ4cFs/nhgZLK+CWGGIOZhMHtYMApP9UdXwAiNF4vpb5fq21+qw0QC+R/SB5iJWnoLiUlwyjKlbCOuu'
    'DYqgzIXIiILpBFux70hP34X2asB3RNcI4xEZxFiTTHnUMnh6NOb4yUCdLMv8GeANJJHuoMrDaeFlZlxGVivWvWS8I2CBkAZwDZQf'
    'Mwz74X5RcXI1JqeSL7ikX/DDhZ/AKxY2gf7eBrEzPOI1v25wRBKBjt2zDGwg1ALZMwwmFfP7CJ7P/5CKGaNhMwXznKhOoHgknxjS'
    'IR+lOiNlAov5RZGwSQ3tUkEiVb5Kgicw8ZeEBG8887w+aTw1h7ngIKHl19lYMNvQjutS4DPp6P4C6jgoPgOjeUw3wJWP6Hp2gUFi'
    '3Sjh+8oWMogizTbHJ0gMN3Or/VoLi80Jus6ZpooFKg8DUav6LQ/+8J76C8klatVxHHCao8D9iczAdBJQ4vEYkqOXPFIdyf6Gck6R'
    'M07eU+w+rEaGlzcqsih/36367l/gApActiP+QMs40Ve2itDh21wIYSxi58kcGPUCfCv0Amszyk9O0HQa4SfZqyg/GWk/RKihSP8h'
    'onAJuZSIlLIj5cART/wuGAatxWoXKAW+Hb+a8FX7zNAtDSRoeM8ajvLRJw1LfJFXYcOTo1d+w1ywg2NzzXZ9iUvuwwE8EvuAfvyf'
    'P77S4V1QxZujigh3fjXje9WYgyBV+ihk0ckz4kKZpmhgOKCPR7KsjSj4u1T7EhslM6YYP/YxBNH8PR/oHzRovNGgeMH8w0UfQrmk'
    'jwQUiGegRDs/j+QN8LGLZ67RMOmHPsAo4YBdOMzfIl0lrUNE5RCNByjhCS6gxww5cQErOpd0FNeyyXzwVuReh22UNxj6hqNJlWOe'
    'ZtENALSg1eMR1QPGzEdcrKLRD4Pi0PVyj91Aw0AORJhQkKDWLpmkyjqi2IfcTgkdIBX1Qn0GiMPhDTN++4CMeVAULbRIyIgAsOPN'
    '7KYUskpYwVqxLlyPXSIIvG5ofJhmhulsdWL6fBsmGyP5KgOBWYIUp4RujGzOcFzqzP3DZIQ8qtTQrIDTrjOdkh19EUAMPDsBS8co'
    'v0PYAFpAqHEIB+APgh7cAr9Pzl5xUEG+IkaVGEdIoRX5z/onWNrfhOxnbJHaYpyhX2Z/VIZpeCOylK+7fk+bT/kNaMKf6BfhAb8n'
    '+JREP1gCFfYTXWARxAhP+L0FH7BcIqyGoMjjxny/3cSfbPfypN3PHKr9G5IEAIwXCNPSIrFxgQFBzsVQTzxew2OA4OWtAWhPqb8Q'
    'I4GY9aT5qTZY7BRUUM55wHGNsysoYVuonVF811JXDwKQB93R+YgcNRw5Oeb+xEOG6XSln9xxozoF37Af7iV+bFG0D/h0wRLevgHA'
    'joplbj9hVFaEihNJE+V6pkujJ9Tt+c+J9+hn8tprjz5GcOUtx5URyGdCI3TN8SX/QZCP1SPDvcLHqMTEgZTr6m7ZmaMVox/sxCTJ'
    'ByD2CkfTUoRY+gOmwQjvjnpRkYm/470HYYGJRsWj6PeWecKw9UYqQEg/HlYganhaxS/vU52Lo1sHAOaMBbtlim3N8lmrW9JJA7yz'
    '78HERWbSgA9+yeBT2m+b3T20QsharMkOTrYtYqcDQOT8N4vW68vElrlUKez2ejb3MXjyj9blD8GAzTWEBP47QIMAlugq9WfX9c/0'
    'RzWPemRvXvf5xt7gsn95+uUr7kRyh2559LT/Jtzioxi8FOklPmWCd5ngXTZ4h6g4er8FBdXAM5PFl2amWJJf4Wh9QeoLe3GJr/DG'
    '6P792S9fkaJnkxlsHR8zydy3sy/C1et2WFju77RDMv1JC+dRDh0h5IFxFwGVgGWPs6AvFipZlPdnsD6E0nGGhLO/CQ3+6sfUI6jw'
    'Y+Lx/eYSf665Y5rx7eWM3J9wHeVvZ3xdjn9dknj0/kwMXuDKonPZ+zOSdM9SH6K7SOHGbLYssubIqEndYZMAhtCovGfPe3h2/P0T'
    'kxnyJil9i4wHRblv1HgkvjmaDpgcq2KARoxq7YaCr+R5El7nDz0St29BVAAJW+7oj57VvBf4yCKoM18Rn6ECookaGC7Zcj8wjKvN'
    '6B/QV+h+os1mlI8ESQjzOg+k1I8RKPnlqxJMFLUx0YX3hdhX648rlRDK3462QZYsfxdA4pVkzYPlTWZx1QIAxoEA0fpz3cvf6dvd'
    'frdjaA7O0TcOBbw3JtN8DM9NjOE3H4dz7UCcHVSUaGDheZn46dB9yeqkuS6zOfu4/7tNcoTpN4pYdK3F/5l1oewmPJPkq6UJTOao'
    'Et+SejcO7fzyda5535ga7v0ZcO6u6VyRgUN1/CNz7E4emMdYMknmZsnJlAS8ia4EgYsCSA+cH/lXntWRJATT8Chknha9K8HjmQAJ'
    'ZjfkXwchIRsgC0BKUQb8CCR8sMwESMkCMeC+G9Wfcc0bOmKxpIeyaTqKZmDOt6Sw1t6zK7ERt2wM7OnnfeOO3NGwGOQfudYuBO6b'
    'E/jzRFVJmE+PeXl9omKfGTYKQjVFN92Px4LvgjRskYj1KAXwJXo7epPhxiNyOtpEg3ugVDzixBm4XUf1LFgg/marPwhaxOL/MO++'
    'I6eq70czCh0SSQI7iu4TKTrlRdF/k8Xx+fgRdU4yCCcOsgry/ooFdXHSV6+tTU5obXIwdrzgiDyZHLHT6IYZcYLH3xfCK1dOaiQI'
    'HxNe5wIQI49c9IJkIGNgxAzy+yO9KzJqgc+w7x77jiltJbpefMGZPhSez9DfjJ3v6J2B6J16bCOM40uCgEpXxaOsAPMSBjYAs12a'
    'hq+0fCViEBF5z4uEXprcN447yfWSOCryYDOP4m8HnrlhuCffAQXvF/eSchBxP/6jvX+1wRcUO5DuI+Pvb3//5StvCB9xFIwp44Ya'
    'WhIMY/z5VOghFBF+xiaxo1++ctflRMJviC2lCzy4G7kd9abfwnuhwP0WWHFC0C4L1DeFQ4QIN0ZexIljN1+8GSek0Oc+RXBH5Mq0'
    'LmlmWCtYtlPnWFYtHv/mY2X8R/tOnSNYSXo1dL7GxjSkFD7E9Q0AxPdnGCixiyl4W0bfBeLBuB70Uw7YHnRU9vkeNsgPQFpxot9+'
    'Tx135A/lSCr7snb02F/YCrNVp2sxQqgTVpWZ6nINORn6/PX+McbhAYWM+NsIRTlyqEtywZT1BYsUaP8jjs2kdWY3EKPGrSSaHyiw'
    'DAtFjmpV/5BfRMIHFoIwBRiDAnV3fvpgUp0gSQDyeiV8QefNSxwJrikOD3n3b/HjyM6h7Z3W6TR16WmOUa5GYWgEP4aU1efn/FRo'
    'kdRspLdELpTCk6BGI5Am2X0Gw/DjmaDTAN0KCFHP1JTJ83OtsTAcRwFdg1ytb8R4DQk6vQiDcqCBGCel82Su3NGS0CfzTGX2HoqJ'
    'fcXvJmjTqUqkh0XKDqNhYtCgwFXex8Eaj3gSxuthilJaSuZ+BQRblShrMKwFu6JwdktRKYFlJWaHblEgf3Dt+3SjWw8bIYY4xVA2'
    'brhQ1Dqz87wRBVB/HawfyS+Py30SHxhjRuHtJxanKIq7GYrk8c0/Jj2zYW5V51ZyOVfA7+5CKbyUSA/A84RDg+bCHz569LOcHAUM'
    'D6v4FyBfZUA5hmUCFJbLlcFMBE5+MPGVyqInhODCIq0zAsNaAi4j+pnUZv7HuI9hdP+gHNFE5snD7HUTc8diR7CgDUbUCnzsmnts'
    '+o0YuSiPhp9Cg2XP4IeaO3BwF4fAkdSSlOPwVemL0B+LmZMk5qVxQY5faARi7rr+TTKKx8sNVZGCl2HBBPVCu//b9zraU0dzvz6z'
    'Ns3f6IiZviIFL8OCrKNjba7ux7WjMyPx84m5ItlNlZWGUecQLBElnbu+e1QYAsq/RkExjSzTC/WtP4U5lU+cQcjLyWCmbOrxIlAl'
    'c8v3nhu6mYnZH5ereTzWEd7J5Lop1s2cwlMRxggr4jFfEa7R0IWAqXiZ5xVL9exFIhXGk8IXssijLT3qMUboJZgMjztDCTFhILIa'
    '5J8NsSEz2YfIhZmkP32O3GmElWIBcWO+QxjdnweUHuH4XnlU4Y9bk15Enaq+w/OEzpqv1MppMlvFlnSzkQXIuQy9ySkqwJJBDeru'
    '0rmoIYYP2OMiAB0ymx8yOxkkxo4yaX7cl/QbXlMU5IxMzYj8LMItdBsMyVvUNccK4z/+LviuUdmTIj67D0V8v6hsnPXvO/GEBhpa'
    'SIZkkkBM1rIaQ56Z6fVlqMoRAt6nNTF5ESoFL1hoXEJHf6ZWLs5rsEX4TSgc+Qd5dKM1Hz/WyqN1INhtCqUa7jx+DXyAnOPr+Lwm'
    'bCXz74r60LJ50u1zrHxsCGOeQ0cGrIU5cQOw/bPEMLi7z07DzAyDp4UuIhevvT8iVFIKheWQnjCvhRM6EtJMiUjK5G0+M3D7ANLB'
    'ww2aZMvwww1K5Djn/8Jr077fSOjw0KTwkyDvxk+cL+NvuBOmuet24E/IfNH42kcOETkToh6eL5rkMdyF5lNPxcsQoVmKLhCqQZoT'
    'xmvyQPX4fCSwYcjGkNeg6D8h5+BnWDliQD4fZWqhKwFcN/BRQAEnyItyxRpnb/ERX/Vo/1FttvJZCIos/iss7s8BKwA/J+HPcPug'
    'Vjxk/M9/n0XUjmL+7MP590WDcFfeEAvYmE5SvZA7GxzYTDIfsv7Mv42li+d74+/yiVSAJUnyY1JB6DJ0FXLZnK3GJdSU0IUIlwl5'
    '8G/x7089Nftw/gOIKvgQBT2wvadpvwKqQjruO+3hGIIu8VD79fRgqrgcuHPfolqSXujSRWov9INjakQTDhy30V4JRz5reKK5S1w8'
    '+a/Khydhai/+Aw5NUS/hP3RMwihkEkuuQFdWr4Q/72vEAelj6Pdz4m70yrvore+BqxH0/cqB6NRd/9Sb6I3vk89/Bjm9BUrtADf5'
    'YETSwLe3go2/CUm42whs/n7zq9IBI+f6d//ZGSWWTgf+DvXM0oyHfA+YOmLn+AUBrMRyJQRBaEIs93OMHUJ6ca9oXnAMXwXFIRUc'
    'XatFA6GY9ynwUXi9Qjot/PL1dfC846R32FIQLoiP5kIQi7h63vYk+VMYeO7HEYPi8eOOjkM5eVuKgVtgkdNeB01KCCV2I4uzmsd8'
    'Ji0Ii3yxItDmssmeXiBQB2GffHrDVBmf9KSfXQs95HxHtjfYPibQkbJrJryBOb9jw/jlK4LPR+H8mATwiIYffkeHJoF0YKgAI/0X'
    'Kr9Ccxb8mKt4nvHXHPViu9CeAtIUF46YOcU3C/aSk9mRpfJtVE5Ej6W/0eU37FnfrYXXYsVkhpSBgeu/HwaL8rB7fsjgL79ThDga'
    '9CoZThKDomAV3N+Yxq7M4xSw9CVqq1EhyeS1M8B1MFXJ8C7RPRV7gXVGV2BJP6MIWJdTaaXp1DDBNH+LgUlJi+j6b7Z8KeEchKuF'
    'c//wy1fVlQFYv/2ewiF8+BLGBsH4UhFC9i103vRPKsYQ/cFBfRPeTskczp8k+jTJ8+kw8VpAThkQ4mtg/U7UNKQvmDDNI3oY4k+J'
    '/Yz/WLX59nXgHUW4iFypZafJSEau07Krlsg3haEYIldVWEBTBlQUfcnXYLpbulMfcg0znr2U6Bc58SPjzeO0+vXehU0x9/x3zHKN'
    'eJ8kUgragLmMuYgQbFO0eQri+rp1vGrMjAus0VkS/nw8uTGeYRrWuN9hL4kX7ekqfi5/3G3Qfi9J8QROmhWTBb8ReEXhZY8bIx4U'
    '1yiS1PT1VffIPM4j5tfzN5bK7yxcCRbFlnrGj1fREWTj0Y4ZaGOUgx4Fr2LmFoolH8wSv0ZZFGf3+qJ29DtN5ZpMROzeIF0pdQnv'
    'wtQciZRn8VdX/P075gGH8uV3/orbEgziQ5TQnmAQH6HsA9zJARp/79nvOf/tY4TpEfJ033Iz+Ab/oXF+C3HgFVpCQoTuDyNAeMoR'
    'aodhHCF3GEYwRGf3L4zmyHTJTN7vhWguZtjM42Dj735i6VrQFhIlccyOwwwGfr4mTLl39iFi/QqV8SFYhC1F1+NSKITLwX5EVwMZ'
    'gAyZrNigP+KlIrxCdLpMPyp4Qh4d3AXgKmJ+NWIm49917SB6+GqFM2dveEMVhFxoDGPx7Gk0sBizN+K6fg2vpF2/yrHEfYx1bamG'
    'jKPrSSyOq0w3tyMXSkOHzsiBQq7NP/bv/YNPx3syE674J0S+7lF+GgwxG1HY+DvHz2dMRC+3tB+d2nWpgYsjfiYP/AwSSb9K/gLj'
    'u/6gQunsPH6asXkWjYv71vqdDgzGlOUxXTAeIL+wBW+/hD3RflIsFhBteZdvtBNOL1ij+EkG7Vd23Sh91DiB1HwKmcCXq9n4dFG/'
    '/C4DqmrTZUM4WvjDP15RVlALsIZ2gjG0U5Sh+TijQLnR/OaP2LIvv1PSb55NjTpkibih6n+oP+zlEh2C3p+RrTUyj/gZ3m53VWBp'
    'rl0LZtTB1B/vz3ZPmjKG/wkUdjE8N9EriPt0ZPk8xBAAFUeiAI8RAm8j/LxfJkhXoQfpKl4tf8iLGhFeFDWYGm/3v4gFnSVfM6H0'
    'llD3LBLznNdj0gR77YsLAUUAeh2wrHrIsvIljb/7AcvAjld0VU9Be70/3gb642ufM69BmoTZnejTXjwQnk9g9/R6jVC1y4TUOVoi'
    'E5T4kWMlrhHySXgBCDDF78zijdzYd13uTmAMfbEkBe/uGywE5jECjp0l8mdBJjxMiwcskCS4K7SHnP3jf/3fz/xocYG3ommpfnKk'
    'pHCDwQE9czbz8TL3NEE8waa8haXJXaDB9r2wD5cypBynG+Hnlz5PYEDEmJ8qlChs9ERAm8hbiiRPkSY0kJyLr7eLk3Y21Ah5f1t+'
    'jaKlCRn6go2jV3hKRTGKNCZRlJHJMOwkit/zoT0SVUN6mzrBYOHBnezCzv9LDquYOTmnxaiw6AsZdP5otf3jhyLil1ci4mvu6DX7'
    'FX8DU/2z20S5qz/ccrDmYAkjo9fHPsaTkDeecE8bMR1VHpDE8keezsnCq02KYAKClVwyH+CASYgDJnge+LdM8O1HnWW+f8ajq/4D'
    'lpSUaSrI5ZQF8+txeACeJBavr3ueubrU1akXv6KEVOy+muYxb9PodWVSEFPWVnKqZpyZEbHZvsWkzX10AKzL3EcEyJpeCtnvHlUy'
    'oKB77nfBgIzHc0kLAeEOx/5qzPiGW7DVlQ8cx3t4BCnzEFLmfxJS3mag34KWowSvOCrOjcyPBIX5iaSAp9PHLnRS/xk2Ppn7rmP4'
    'd9323wSwueQ2TU91Sdl/xNlz3p1CilLaW42H92ag5bAriiQXXx0lGcSEoAa2KcR4FcmyLkIIg60jgsMivhxBlXFMZAC2jD8LW9Tj'
    'n0YvLYul21bdt4EnpBUGbmLJ30SDyEQ6souFyC6WGY3I/uso6NMlBlgRL/AGI6khUa3g6yGjfAphpwA3GYFwzpkUirGmBZ516E+Q'
    'iwfoKiz+49Hlf8CZhNrFyPCPtIxHwkr4JRIeI0b+l6gBwQcgR/gHqBH9YlcbUCzj6kNqizKmBZ7jmG99P9DUbSzqKU6GAtImof02'
    '9svXDZRgt3Xoaf8tLriypAeflty/krzZ0SZ17XmONllDZaaVwtzM5yzA6i+x878wh4L9efzHZaFFy3Q1HCkqVE0ndhwxzlHR6s6H'
    'zvrWDDhWD70nzDDE3OLRBEpNReaKP929IfdMU59ITviCjnRbMnzfd/LtxRHj/j2pxhqGzDjEOJVv8NestOfs0XZkwtJgFj9AADi/'
    'mqeuYt1eq3N/ITx2W82kS+Goteke3QzifnYbCpLM0p/+TNkTh5JjsCTDkZ8Cy6P1DpCB5Hqxc5gB3qchRL/2TBfTQ/j4xjG3IIYJ'
    '//j3/4OyoncllqmTolXhhWxpiimsMKIJZdE7SqYNaAk63Z9kz45keF6tNC/GtI+G5s6vDW0Fi4B+EGYXtRbMAPf2fIlABwXDtAn5'
    'dDzSgIuJz2MUXZe/4n6oeHviTnO8few4+yC6bMFCxRauabweGaon2yplJmeIGxW9vmGDJ32G8eEzhW4BTpANn3IGsEb52E/cTn9u'
    'HmWkxdjf0Dre+sNLIEej9SH2aNw4ZVpKV1UBIeDPc97Tz6fL5Lu3R1blRyvtL0lkW0wrFj9dN94/9Ri2e9rjn9pbv8fI8IIeT2CM'
    'M2NI1ByJefwegxuR07P5eoJoVMKssL6XMPewveKusmG4dYpUHoZb5+HLAF9zGosXJIzjzL/nLnZEQZNTpBEPIir/f8S9y3obSbIm'
    'uNdThFRZBUAEwZukUoIiObpQJXXpNiJVWacpVioABMlIAggkIsBLkuzvrGY1q1nMzGJm04tezGPVk4z9Zua3iADIzMpzuvIrERHh'
    'dzd3NzM3+w1M4SXfmxzTtg1/7XaUdI47gnc96zEuziRLRmr+Awe4HFB3Iwm5qYoiwFuDrHAIWQuBub4qm9JtxEZXwdQCaXt2xqGJ'
    'cRQj0oPcPsdsCWasl1W0xe8jNWdgg2PwrqhIMpI0PKNpM5DTNFls5owqGcnO9+o1NecJgrQUyfDS80SC+TNbhtiAqUC29c+WPGUj'
    'LA3WujhkKvKyrFQHqY57/JhNxlDkAf7xRGI/nIAxKG42OcOONRxOadYuYHtFr50xEOwGl6BmqrEwlrA9gOflCWnkNjRyaUY4qpaG'
    'umUaFZQOoRPBJpKpMeC/m0KBKJXp8Wg2ZbadI70bgMF0aiecyJrXhL72FoUPsidvXpME06SC3w4cUGdqrBe9a0FWNZuZkfS+dctp'
    'vWvVVVANR7OtBtdx0SvMbKRLS/U23GUHIonme+U39BgNNfF9W6rnqm2c37RjaZreztkMUX9T7wA1wY259D+tJpHuudjtnxOdENmI'
    '7KRachB7fwW7MquqOkXKxMgJwLU2LANihVY50MAKNdXIW07h0jQWNsquWVmy67TC4ShMV+yh5PNWUI/BWoURyIiFPh4LWpvBZdS1'
    'ZZ0AxXZ+7JSubA/FuTpK4ybuu8nLXo6bc2+gsUOGXoOlYNoeSHX0TIClcb+zasA/S0h4Brha0uIuaOOpTcqquBsbBCRl0Es+SNgG'
    'HKMb857cP0mHEqKqG8Xn8aWoByYajcOEX1YWDFH0JGahQNmoIe1EcM5lT/BD6sCi9QMxqJOaAdcoShD0vGjJ/tZ5vzzcElnaBZ32'
    'YpCfuojmpzaiuXVeYAywrWjZC0rfjiTarrk5+vTW8sdemPWyPYEXVF3vXqTkWwOnV2pju+1HajZ5oZanKGzJpCg5M00sNU3K1DTx'
    'XCQkbjAN8ypxlg7YBBEKiR8Uq3NgmkAGe9yS5FI7nW/LFcuK6Spbf5sRgf3c+gYuqhB6d+Mp/fPoz6tsDbf2Z3oIvh225prJo4XL'
    'NRbyJsYxb4jctrIKeYBrdCR4GLnZRJfu1cB1DmKgnsjQl00YfWtmHfhBHH7CTikuhxOH9fl41ZrhW/hIjXfPc/pU058Y8/wwaQ5/'
    'EU36OKwOS2HCtwlTa+jPBYuhyoQvMOwnKSi0Sq/Z4lrz+s3AR0R5pVCVVGqn06H3WGUJu0uNj1+lR0cwzElaLRtdgAjUj8Y0iKVP'
    'zkxPADK3Mdm0ISXL37OZfB4gZF4xiD+7+ZT0UWwBXzF+96Mcipkprh1Ab2psugR0z4f+jqL9K0XxJcbzJXY+4eviwploXN34+5OY'
    'uE70ZBEHCHvTgg4NEqLuJPLebt4iutN5LMAWAxPGqOzlPxvjOZeQeZ7XLQxkwZG+HSwttaFKgGc8I8+5nZbbyQkzIoUDY5uFXkKn'
    '32UXUQxdlhsbXfqFzYq3NXpMDUpDV1h9WfYBJwwimBhHWuYIupxAI9mz6SJTEYaUmQ8RJdOBx8biwZsSGo5gRmQW7swveMNUmdxW'
    'rUs+9Av7KeC9rzw51rxtuok6ZuSqEI4Tokk+zIA+gdi07GklsofFjBNfADS+yaMvepuwx3vEbAC+J5AomOT6s2lTDjA7MLoL5xzo'
    'HWJFl/7Y0+jGyVlWFOwaDz3x+oyKFPDbxJaD8M6h3Ed3l/l1Kmh2nuOYQExMNfiRx/Z3gj68p9qav2m2IEX2etlFk8ilQuCe1x+z'
    'nJ6FB/ShRF6qmOCdasSWuh1JurNDP5kzWxIswjusB+cduITw2mI16zQf3gKRI4yGcECZkaRh14tl1HVVVGn/t1BhLRXxZIOhWz4a'
    'ZjHrHWy8TesyR0yaIwbRHWCukXiYxGfidycwOkAMnCAAcxHO7mtc0P7q1ch8FOeSJWSDqxWioSTKJfZaak5Gk+JSsJk9j0YFesv7'
    'VP+4JHKJeX5+RiLPEE7zP3D8VoHRF9Uu+GDR5IrlvUv7hnX0fuJLl9gIShxlsV8yzRdocvrzDCcOW/XYEzdmfK0YmFpIsbTF8bPj'
    'wjS2L8c6N6YvPnDiAuC5c+yJSig2SEcSh7qi3LFe2Ma0KgPePa4wRFkFvKO00K9WUdSZf5LccYFIFy/5x7zVAHqsXQ2KAagGG5VV'
    'sWCTnCYjkjL21EIhECvl6HVypdF+3jfIGVeOJs05bR3hDjT1YVVr6pah0RTeBJtzSV0q2lJL9blVMN4zTjS8Q9J7Smz2LOVK2A7X'
    'IfKJDvy5xdUZJ8nAC0QONZ2jhDmb6rFik9A5sJcU1sYi5w2xxN2nLPkhR8sfIEsJpeQHmKLhoedeCBOEtORfyNoLKpJRhYy3Oaxc'
    '3DuAFlZnRCsUwjAnWyDQ+/tiEGonUd6kv0DtsJg8KnTh60puowj/uC5vg3b6SdjyyvQRk/tVFVQeVO9pOXKj0xGAWY1yw9q7roeM'
    'k7Brp2Y0dU1ZuTPlMgBiV1aWcJAzUcdZ4FBoecr6vpTZ5X4yKTwlX6DhM/EzPEWftiX3dUXaHmkNz5xgTwXDVFbohXqyel2qLfrU'
    'dtUjF9zIxUXzaHynU23hJEdHmNrN20l0mgg9yzZXiaw8NrhbEhXvgwuqnDI0kVnGKog4qCgtizdxWVDjDnZji57n7hLCyK18gTTh'
    'EK9VqwpDVxNoZBktKWf3YK7a8GOO45c2oK0GvuC5UoaWx9hMljIlJItcATT5U+keBMOo6iShXFwtG0ASc49gsDjvN2vvHdQoiUnF'
    'XP20ApIT6aYIpRuvK8RfGzW6B3nBUpeVtzhl3tJgcyxUiQpPowuxcCWKuvLey+M6gIIDM98Ch4CQb5vyxJfkg8tNvcxciT4zThCJ'
    'FsSpFd1A534sWL/nyeDYMk5q9TKhSc6moEDKq3KLsn5NaPMs/DZ7kLKinpo4guKgE+26mAPiEcgIqggWmIz5/kSj9IoPNBIoVaYm'
    '7q9Bt04LhWxgJlSC+NpS2JUQuaUDiJ/LEK36NYtOSBqmBEwUYAiISPieTbSPAunApkrQYyEUA8jW22cKXo7eyYAX1fNThtZdsLs1'
    'bdFuwCYq+YJZ5hilGsxhjG0yArOC/eB1Ch7zZTEdLq1SQctHdJwn7FI5TX6eEZtmttsRlaN3YCKdqYEAX7gwmUVN4uL1/hpqVxNZ'
    '0g/EoE2f0LkGht0ERzA7TICJV/absirvhQh3CqdP3FgAlIagrHbJV0xQU9zfpRIIOQaJwud8aIhukyfdN1Dl4VNUD90XRKrmSG8+'
    'apL6gDh1vSqOWWHveYa0HBYNd6wta5OW42GrKmHK1Yw9g7QzO9EBNJzmIkk3Oc15Prb5HCIkvDMwlHBWg0C5wTr8tad+KDCxxbSZ'
    'MbIHBoivyXV5O5dVz1Hp7psBt6BVdSoB+AB1z+WKrlxQkqmNcl527U+dsjfx8IhtRP1wpmbiBzoRbhWPRITkENtgfjmnhqEWBBmT'
    'tAZU/rgdjVpBmB+r4ZTg5k7FWtWYmhQnYehMrXt+6X7e80rJft24P1n3gtq/fv6hpKznmH3h3QYfI/Eq/Z+mfDrxXKmfmyVwFI85'
    'oiqWM7HCY3ucmgt92TfkPs2EtJNYaoyO7vnI2JPcVCKY7NEJwLbGEglmHJz4J/HABGLnCDiIuGdOYUHmwg5/nBUCJe+dG/YQcJCA'
    'qn76ILQE4Aig8MWr0TYGqxJxMIbiPF7TiBvxqsQRpBwYWXm3pu+W3Dv/dvXUXqwrY8QYw6f5Xen+eGJuTGxAL44NDK3pauXSQXjL'
    'yn1DPonH3B3pLIjFr4laXUALCEfuGB5DSC4Bd03lp348MaNImE4wOoxZfjxh2rWP+tQMx3snegqPsMfOrylQiSEiHi8GzU/Ese7f'
    'FFjlPhrYdhp8jlRri8TV2Rbv6dVriBGdarhl0++Vu4iRLUWWhnDe0DrpsNAKsUli9leil840sIRZINiPc659Vat0i7EMTkVde8pe'
    'KgsbcRcYpDPw8PQIjr6Y62Ql/1PnXVKHhSGwd7CufOjtGoZUcrGewnh79FsY+i1q6HfTgQJpa9rBBSYQMLlO8ZbvPPYqDj6t2otE'
    'aH7fiwLC3mYoxwDOeBhfsLZPmZ88G54lH5XHqrAOrAu4gJ50lRUCocOHF29TTlNwxUjNTLG8Alt8WV2HzBd74k6H/auaa63bGWVr'
    'xfB8KkEtg11TnRH7LEoop2jCRGq0lZj1p7wpckAXF03SWRoxygpzygiWAd9hcCqGyhhDyb8Wt9bzuX9V4OlDJ53otbAzTcQog3dO'
    'y2s0GzVNBcQs7jHDjUOCuEk+fi0oOQcwg+pPom+wfRNt/CfJRXzMzP8J9eiS2F3fWMMjCE8WHeXO6s/QycgaIz3DrabTcOlNqYlg'
    'PgoYoU6nY2Zy5F/vC8tzv4Q+zayaWsd4VOSJxseVDb0a91o8tkYOXHgEDe+Sn6QSiPuGrwoee4GQxP/Gwmjw+lUoDf7NMDAO/pDB'
    'DyQPbXNdHY8mp21piBYTqcTQwBYuFx1EYlxnRiBFOlsCfb5oOTMBOTeNAXUzjv7obf20xSOp/1z+vhkZ5FOJK4kdwV80Zol460KC'
    '2fW92HO5wUXNTNzYSrhXImKNWIS4rQlM9mKIfKDrunXGlK0orNISBOeYTZhBwoWWAKSPDcqpsIIkynpywiDUhR6MdB/2eX/k3h2z'
    'kmUujiYIk2E0Dz40K8hnjG9VAj5rHZb3yxG2NVpF3m52r2RpoDTT4qh5LAIacDe7MlPuj2ly52gYF+/hFQAsot6hnCXZhFoRC4bn'
    'iGEOjOJVPvVafBKRVCO5INuYL3MzxS5TjyaOMx0cBvgHTDh0frI0g9gLlk2bkeBwwFpB3gmlnfQ2XJWUgLmOzCxgxFBFeiw8fLzk'
    'j7qk7UcNVu/ZU5SxC4UAW/XxstdtvGwR8oHmKxCWiaFcYYlpgVfsRoLzeIkK9I1SbORTnU0D4WTtFmiNT8FFtSrWHsaWoZJCjD6s'
    'Q+zNPPAoAyYoe7bCSNl0P0Hq5LtR+llJ+5M3HNRpykSruQCgphe4OxiKiUVpPEgPBYlSH386ZHTnaliaiYtHMxEE+ZhNXKZyTTbF'
    '1fDP8uTbkxiP+utrKnYbmZaQlh+fOemO3i/T+7m2L1YopYQPI02NXz1YAdGPgeWgceyc2LDfP0+Lpg8B6/JLkQ/lbxkZauRMe1z/'
    'WyY1VUW81MjZ+DTdwPhp5tPTCCUz7pCXk0uVIIbL5qOtmj56YRRdgrrcS/W5Axq8U2zpmmDM0hUndDFPKvTIBpiTUlCjzFFP5hr7'
    'zFCOYnXOtXnqm5lkebtZKdicr6Z0c/4yOC/1q5nxeWoPcXpGLJlkeSOweurXxgXuW7OnLLR34rcSgAEXrdoGVBlCnxLXMuG981zP'
    'dOq1iLqXNlsJV09C3lP5jiuSqPd4pVtplQUf+Dy4mlJ48ZtdvJAry947lnzg8+R6/S8Mrhzj9DBEDEJAaVaATxVFCsf/1JIYn0Xx'
    'YCBN8ayVcc9Cwl5RIKbDeEij4Il/edRkjoUViecnVB0ULScxTCPggpAWrWgwTY8ga7J+MQxHKYF+TPR6lhXE+cIaydorCk47AAdy'
    'PrD38r2MyuTjB/IGLjDEDieBcVDa70TvAx4fSmXolE2Ael+ONQKGMDo94qSIs2dNcyd6bg14VK0fjAD2Dicj3ONAR4B4Po/FcF/D'
    'TUKYoNUmveljiJLwns6Khp6YgNCMbIFWI6I79DyfywmvsorbJQKntLlY9faStgBruMeLNd+elD6vLbQvFfrWu5fFQoZUbLUnEGED'
    'DDFiny+CYCcXa5JiyUtxGZRxudoOQceQIijjcq1t4SpMiiAgBMwz8jZPNYz0eGpwV4jwLdRGynixpqCVCOTSZDyQS/NqGkR0uVhT'
    '0fxyjQVyTTS4YNy2waUDbnM2Djz1skHPMG+zDprSqsqFSMhhGeXGQPJZWJOZcWWdESm498ZBQjKrRUoKJHifbf/dGXYeYEOPPket'
    '7WDsOb5n1hcSOId45Sb368BPd8gjAsYk+NZz31xsv/vDvOyb5rkX/ZIYXytfgnVROSDKuicn01ZQMtfWSxCZKnpkHA5pqDCHXr+N'
    'li02cOy0a8DsEcFOeDmJfxYgPTxJjrUa51kNbvRw0YzRUh2IVf/BKU8TDPmLTLye7WRpLAf1NRZxhQe8HQlSYPiZfa24haG/BUYV'
    'fPSS/OoJUidbeg99S2i2aa/gfypGokEBZQtkButyq8RM3miGY45hrDhMZbgf4hTa0kXBg28XhJyDnIlYakP5PquvcUpToIlvrPKv'
    'KpL8a/AaR0dSeOYVzvZzWroIWsKPIh6iWsyZryxpCSfK0RJvLBh2rBGWipQldxuOj7MmA6Px9ha8EJfRel5ZR3HdLOJoK1hs7Ygd'
    'Df21s1nKc8b8jciNR0cHs96hAQJGs/EmZsXNGTM9IkJqOkUG9tJdVoSVM87K5ktr5ao52iwuNLCCDk4PDRS/S/daagczRO1cYcni'
    'aFNfM49EzfJfS+srqaWxQWqt46ZVCarkCYFCWXeSAcOkP/mkZPr73NAqC3kv7BNkPJ6GF52+mYefZBqe442Mb+qmgdJdunSXku7S'
    'pft10yDx0Z8z//+C/11bW0XAS5eQLdIo2TYUBVc0oml5nPEVs7exKV/D4Q6+/lSe0fLXcGK9ryYOgPk77zS8Chp+Xw9X72gIRMtw'
    'pF7rQEsvWm3WdYyo5+uPAff5mFo1MhHaVZrUyUGrdWQeRqebdjLs+0t+XyK8gC2hLDZEgdUnmjAgqj5kbTtMPHBfLLE/DK98gn9o'
    'I4HasMvgA8QGi73FlA2cxzMGfmjGQ+LBcxeDiLXh2VjvNFkocLEG+eM0yWfDQpoAdrfFXLaxTkN8SfC8cHMWcYGqhUxm2u6pFPv9'
    'cy/8jOynHvj4w8hobiW8rodALt9MSj8OuciEOAzC8yFPjutP5gODO262s4DzuLBQ5nVfL31c8jBFz8/fK+fvefm9I9dj0u1wYQsi'
    'QUhtXKPVuSDn6GK4QV3Zi1LOvBRQN6UmSuSgwzSM+iSaeffpMvh0Wd0hS1uf34Taje9AJjulP2nvkA2Aj3kPPJi0o5/pJdwbfzYf'
    'fjoMN55UQl+kE+xe5uFnfuj5X/Th56ruQr27+ueO6h5G7vFn6D/EHL3PrpbUpNgkkcceJ2m5CXKhVm6qy9hN48PoESzdl+xsMDdh'
    '1BEjE1OlrMhV/YmvmFWOgcNrQwBlQx+WN3OeGJgfSqwga1p0l8A6dk6LKYzjmKzk57Nozfx2c2pcJCVkeB3j5euh7ktJNDmlPViW'
    'j/iIrDpEdXNzxJrFlENKb3z/PY2NlIOYw3+uXL9IjJ71xxjl7+G61pTUf4weuZt+r1anKIa16kP1KXDKYX1rWnUTqOiF4TRsqfB4'
    'LcG8xi7UpO/elXd/QYgbp8qiPd/e38890UjCs5ooPmM28ebSe3NpIn15cvoMYjqXKeonMwsVUZ7lx5I2CjUG+ihUuGlviI3apKvu'
    'XZ6Rs5pJBuZ4neiTmsKykcyJXi/HTHkI/wz1VqGR/1ifc4KQWxqSl5M3ckYcYbfWzj22RBlzMBaJ3OecbqwBsbVOvl/rMsRq72l8'
    '7LMGAUaMs5ebsoyHezBcF4nGpmwYd2At4w5bvj2kVw6HrPmVpZRtBg5wvByKzQC7BrhZ24q8GduKLn0z+wI6lEkyZdvtcT/pjAEy'
    'QJzijNfP09XQBZphb87LB2rh62FgpYc0y1Q2q7RnUyovEYfuNePbOqFq8EBzu9GqaJK0R5CZ1qRPiLYTCmFWtaQQOON52ukDY06x'
    'xSPTOU6KprVBiVirtBWxdscobbDU0eBNVhdtRaznaVpFjn4Mdnhj7W8WuUajAil22EgVN5FiogoqYhyb13jfxLBqRrbJDqhX9219'
    'd0XDAPUUZesuKq3klesTr6N9lBkoRjD9w1Jxrv23ER2nxCyh8A9lNXY9CZa6WgswIbiWBq6SlViROAy4rpTt0UueQndyrStbp24B'
    'ryl8xVqnQXIElXPV+bbeUUG19OrSmDcicUEum1gxfEvhwpsaK8aGMSu0GcFq+25r1u5QrL9BQcbPudazFEhqw6EZzwEjyvo23Nxa'
    'wMjyh9+KLTK2RmYt5z/hXLnvOTRbQRyWwWlVb/bFXEZ9UjDNo44/0aNgxhjyrFK2HcIFxdc6w3g3NPx8GlR9OrfqOY6o/r7vyOVI'
    'Ro8p5cOMPQ08Myd74cAeI2rBDetUvnSJL0jiE2c2Fslg5KTG8ptRvQ19cP0QmqKJxL/2NPCfqY/gXlGVPS6rypACFQ6Mzfx8WWV8'
    'R13KeI4ixdkNjEWH0pOfUKAcx+bWQTVfxz3zItB7+bd6RpY0V3pG0gzTZhdsHx2z/fNxr3NuMGIwjD6AwwUMTy418YkkPpmX+DJA'
    'nqA6num1PJWAn9UzzgyyIcDS7TiKQOYdRM9ggWYnWgZMJeOjowbGsGK2m6/KXQYoX6lFNZkuOVPpDhgjrba1cUuz63OvpdiYJLIQ'
    'L9dTRiC3uCCx6I1G0JHQW9EfbqFB8twT3lO+9zZFiDbfe2XM1fs8Jv4pUINcyEj3NUhyr2j7ZdBKvpgEEVPnnq6uTi7EaW/Ug9EV'
    'tCuARY2+fH4XNT99+IvYg6fCxwqK/jSh5XgJTEXYL5qYK/3LVudeDFDIyFuJ8eAt8jSP0mEAgzab4oihSjp9jvIsen56lpQWTdK/'
    'DRwdKzcpRRqmRJD8IZ9Nh+qOfR6nnL4zSPrZwCbVpQ+FDD6OYxrGeCje4ESKjEMzPgm/qv+3+ZyXOEIaQKJ4exM3PkcJraC+IFzY'
    'Wtu3J6Cm0Dy3fJORmkQnkmiz5NVOu/EMGigdwd0h66OaDeJ3zuIcCIp9uXFALDM8nBgPkpOgqILj1IB7fElLEBcWjfWBCU+Buwz4'
    'D8mQ07hwrIhVCQ4WmnNxMZScCuLUr4iMml7iDujKM6sfTk5iu4mGG+iGGiVduA2UfeQ1pOwF7jieQQgGK2YKElxQCZNavv4kAulq'
    'wh3qa5GhcaC2BpP0ymR83MBmUfPpp0lyjLAanaccncrGREMsgjEvhCum42lylp16dEzU2BLxsbQoch0fdgZx66Ke3IWUS+vIceNz'
    '2Rff5VTYPSmP/t10/N0c7s7uNzbnXvoLNVP9zbklwHqgDQPgqirdMsQJrh/Vm0+SKYCD0NONhXnVol5mM+JmAA3GaFfi2Yd8jfqx'
    'o9XPxX7AqrZQPP8Zg1iDAHTFxd+05g/jr+9veTMfM2YzQzskDAE8D5HWQiKk+Yfk3KwrILFR5+KhDI9BHDWADdk0Pe4qfaAOzU3b'
    '3DiedOvQeoX2WU8pBesFt0oPLa8wjkfGaQxkQzaVi1xr0o9k3kd17fMYK1/+pAVGBw/PvEq5mo1jzzb9N7TEBAGCRuYziLPpV6+b'
    'SjuqeWnuKq2qX4ZF0MBxbOIdNcqX5MoYzU5+s5RVvqYXGV8/d0IzkhrwP7mWEcwRT7sSHBoIUdLmAC7YpsIvbP/1qC0Iww+jUzlv'
    'mqyhXfej1B93JpeIi90ydzd6RriAKOWANDsSIqVrTE/YTGUi1ipDNUahcvQeX+BhzWww+EjbMtZHCMlrwLapqrFcLZlgljeTi29w'
    '6pq4VGhQ/1ITndhEXB4ffZz0XHLK8cdvTuQNrB2ws/E7xKdBSe7TD5oBMWo0MRqMFy5Yjfzi8DSCm9xom4jOyRtXIw+GLX0iWF78'
    'pTL22h10JXqq3blp1Sg+eKMS7UbowLuY9rD89OOmtyMYZUV5LRr+OyBcIVld5dqEnSjpYEOhoQgW1jQRp6SVr/nSdyttYLIblb2c'
    'HIEoJYp0RIOlfWckNhn3gwBUvGV3eKOydsdxj3jYDBZz4A8Fygp4BRDimgYCOWfFLTu8iKO0sz1oecKJ6I+ubtcbBWoee0srh6sB'
    'XFiIqV1GpQ7uSFlnNjY7qQytnCkC4HpPdHz63R+xHZkYIPHoKWaHWcdNwJc5FUMN28IN7WgyGvtKshZbWgVI2EkH58XtSOUGkM/t'
    '6XxtIK1rlRRMSkO0UnbPaCDfpXmRjClfIx1PZgVxZE29Kgj2UTteHgUGsONU9tySe8PZ1BbsMwOLMp0ml1ByUb7EqI9pPGib+kT0'
    'Fx8z7bjOJh1KL+qbXZLGJglHsEw6E5xu4+JVchTPhgIU4uo3OIA+BoxfECJUNCS+i6DG/zW5vEOxC4rcj3tzG+bBQrmBLxfsKUsd'
    'Ht1AmBwajBKbwzAJJ8lwkkzzeQxOkf0AmMRmIEZClw+sLpI5XkBYosa8ZNiuz3TaGLbBXYZRFwXV6+8ww+ngyJkLAWaS/hsnhXtp'
    'Pf6Xty0LNp2FmP5XbVAXAC9c/SrU4N/BJpXL+R3sUquOuz0PHkrN/Fy0YNvVahdEndVb0AUH0TfPrFZUYL0Fze9pCPa5zf+E5qPB'
    'LxHEOG+FguyaCLLrJjL7lbOEG59GveycXYdmhSCYpA5AB2zmJO0T6bII5U33z3wJ6oV0X1+dO83igvGkdnR+5tF5Ujsu4tfxpHZE'
    'fuYRedKqw1e9kDtuFHHejaylMLFhesckCwajM5FQFK9Z26qnv8ffFIHpuA/8+IMueQ/Krx29CV6qzmY5esS3fEFVP1jN4xv+pfw+'
    'RDILPXJJ7WtyoANAKhwr1kLca+FyCiKmKJnpNDde0bYGn93SPcJXGHUetd1oAvy27T7+ABeingXxRqf4xYm+UP5A2WP0RNjtZkjn'
    'xD46QUG55C0ua93YFzmCDhIHAWK8bQ3wbkRuExvPoAqDbmz6oa4KIdA1y2/EQA+scI8DOPNJx4Gfb3lgII9KqRzs+ZaVUSiVwzsv'
    'nUXqNKGua+AbPevk0uEEQkb69xkPijCCTE9XkdgkcwS1G1xtIKTYSZblxsm7HI8s866ywJTCGq6pF/HEU0pRx8Krl3h9SWVg6kJw'
    'QJGD62rkXOw6eweofa+Xfte6rlUC0lgg6A/HSQaHxE44DeRNoWCz/L3JZFVKLznGV+2wRE1ilBg1ivnxVqOE089vebD05C3NR02r'
    'BCOy1LAwLpMPxgw22hf3iSOiRcJVTvxdKmbZyNQvvgOLS/72DDFko8HWg/ffXcUSYSruXN5E7767msgjEfD8UM1vdt/v7h3Qut0/'
    'SUbJ4ZyQb4/rYjf/OXq8MGxoRdrk/hprhcBMJOixu3GXOTFzDlMQxcCkvZefttSgw+2YcNHyFhsAE3qJ8acCvgw0ZnDdAsqVjUQj'
    'Xlsx8VBsizlIj44ShhUbCg8hV4a6rhndEEcwn7QGDEGMzPK04BCnAiXi7E8787Gj64BRLTql1bPJgqFOGyRTxQ8F36zyYsVUIDJr'
    '4x13vxN9yQWgAjG3iMUbz3hRiO71JDtnEFfE0G7U7WqjDCGwwt0LB2ZVntGId2WZRgQE9Z2DNLh6d2sE+Oq7KGEVk6M6OXsSyw9L'
    'P4bILA8VbKZiJgyHfwamghIAGUqmPElH0Po63CKM7YEGeT809x0+rZMgvVTwrUWeFIKfzTusfyiFMRfYyWheLTaI5aHbCYe5xDcz'
    '+/3SMLcV2vQG5pY5HPrySWboZTwBe0izolP2dlALODpe1HUOZeg1aFxIIC7Q5NLY9Z7TVaFvEY9Rookxpm1N7cPTW4bEH41TrVzr'
    'WBqeBqMRLJaFIKuq7KivFaiBh/6Z53WZFpqpEcnuBPZreHrGcsFe2tUIyf6BljIoLwwaMqfAPV7QSrEP8tpZsOqlZDa0VBzbBsun'
    '2vG4lfrb7JTvZOy2mMNFr+JCTedKG9+81eGSDXpDtapbZoB7XEB32P3oMVsf23ep2LNIiFrPLtgX1m3iC4Qgc5K5fc9e3U/EDFFe'
    'iV1Zl9sht/bUljbvxySq2MJZYnFF2vsNyuZrHDkql3JYetdiYimVQuJ5Gg/m2yYmnUFHn7Sc0MEGpCaedjf0463ZZsKWYLySTjw0'
    '+h5BkhsWSy5ub+wxVAazFWemwq8Q23DPKS31OKqnd0lndyoPfZs/3L413dodM9xzG1NxDXbqLiCN4MTtlpFvI2HBmRYuGVMc4kxD'
    '6IC7040m5iYMXqUMKsQGqmlb8aP07+Vha8HNWFssVrrm4k0Fn6BBxsraH9RAn1tuKx2D1NQ8pNfcJ1j4UnVVKITTU9fIfDd2xqoc'
    'ORU7towvJuIu0wdpaSHLgP6XWQZ3bPtss9tnQpmgzFLgXQdDIVpJjIYhEisGc5ozSMD+fsFv84tNJwFLuksv3b/ZdGoC5QvAted7'
    'eY8cGJwOUxDoyWH5suzpfbgMOtsRC6dwzxtwZieX06b2yB8VL6O7mgmsV9scIodNVzmx0dkrFJqESfbQ0CRK8iAwnsYWynADsHxi'
    'OPIPMhcGyrEOlt6DveV4Js4IlDi8BvwziGud4h4i9RGkFWNPo4Ozjua+rR8XEFb7wC0wIRVlMLLJPp9pMGqhrJSc/pgIiq7NBv16'
    'x3zu1tnmtjwNFL1FAPGmJ2UbUt7pCKmWDcW1oSXaNlbT1LTCnHShiIiQueaFrn+1iflNwnFw+lcY2tv42NqlqOe5LqJNs0vdJl4H'
    'uwwvZ1nLmBvZhdlXZtCpmLXJ2reTWzof5pJ7Da37ZO6sghRafcAeCK4iHREd9s/JclwUJAQmA7dR2gO/3sOCwzsMfJK7b/UyONl/'
    'SQQAPUxk+AGDsG6UT7lE+8m7bCjSkPCvkG34+rK8AMx0lC7nBne5nFtg6L1wy59NsOHLWrnteBASvUP685NE0rn7tMot1J3kRhrS'
    'j8BpfB/329DiLdNiOKYtJ+9PEYiFOK8J0HZt6BNKhzNgExAsgupFHNyYERz7QObmhrWAdfvP//3/XpJSol+ybJR3vOANfb2JQxZw'
    'JvI0SopY2TQ9upbBvwySYRH/3R5T7t2/bdYeR94mfcvdV1vsZKs3XmoPW7nfciv9dB23+sN4BCQFPoXURCS5mDSXTQNhMet6uSPe'
    '/jCFXV1dewybRtFvb4RaawaPavK/5t7tISo0V2reic1AVE3+11y81SUFPZ+uVxXYMNCawODkLFGmLJKrx5XoFZsGiKGshDMwWysw'
    'NSXAkIOtEH2CuY2RhLB9xpdOPkmBjAOTMuzDEIg5JpJsilXixt4JZaCl79o71lqujbcH2VC5J4uqYHAfe5c9b4d2JS4sLpvcshrv'
    'UIHnXMbEB8Fxn8PdJ1OAqCSAWrT80VH5NDjio0P4qPyHtDgx5pmN0m1omUUTjsIwEbrD4+WOM8QUpqAdHcEENDAxZIecNgSEI59Z'
    'xyy/pjY3j5RvsLa4NbsfHSYVtniucQ4G56DT6YjwO2FHdxik7sgY4cA8OGwdylULO4AvGhk7evPu8u0QaEeP5t3QnyaX4nQ/53Z+'
    'HJ9Z3nVOaLoaJ91BnXvuohtvVlEZNopD29SCKzO8hNxx5xZGQu6qOXahwfM7g4HZAAzxGazIBsBNTaYTi6zay5uShPcgTnLhcXVS'
    'jLlP5JzbFthvrfO4vnEG300SLkm+hwLCY/DgkOIZjQ+70Q4YDI5eWSfasbOmcbEvjQ6LodpC417PdFL0dOrVujfKiAkfIsbfmOFV'
    'hymDAsfifZMM2EE1DmJ69LMRTROgj/keVAKu0axxTA+9uT5B5Go6QSd5SzxXzbFc9V4NrTrrI9yUYXzFLZKZx5oldNC/AIwVtO8w'
    '0Nqhs824RiLSn3M4Va5rlA6WY+feG6cjpkMDT0Ns10kSD8TZXGq48xW04Lw/gqVBVhR8WfKGKAkXQhiivNHqZEdHtAjtjTWsNOts'
    'Pflu31pGNvu++YZYdPINf5BiKUjhyrq0ZbFBZ9834ZCyLtfKKZaCFJ7vLPQvsCUdZthr20BypX/iCz53TlKo6DJaFfQG4IEk0u3Q'
    'kU5/liSR3kpTmiVKLc8KrJpFPehk1NWLY5tGtD9T0mdaEP7l8ruoSSrZ0aroRTfynHxZVOfWsmUELCBGMCagRrVUXpevlwxtxl9l'
    '0jwVxQUzc9jjbnEvDdhQHakLOz9Q4dgBbs9xVf6X/ZPX2YjgNudky5jloheAE7DHg+WiHOC3FR2JoDG6pc2+wTQDizx4u6EDsJd7'
    'oRfxzT3jUQ4d9wv2gTSGehKdS+wOaGH35CPuwprjVufonFr1Z7jx4VjzS3krRrzzyknN5/v2d+Ao65UnxiCQj+sK0m/CUDf1mYpa'
    'BRQYUPo32Oy3WvgCrqLG6rDevFCwmbUcGuDppVgEZFRIB7eI3XFWNA/E3PewxexUcGMXSB4C6pmNkt2hWgjbpeC0P/g+ge/HSTwe'
    'DJPcOv9S23Lb0PAyYqdDeyJfMjVaNUXyFxALnXCLSlVrZhrKugpEzw6fCFiQ1sAPjjK5NzJCDZejkpvsyzzAFuQ+Y/XdqW+GOY/T'
    '4h58JL6RDXS5UXJxxmF27DVazXhTLSGLy1dqALt7l51DWZsnvtPOUJvzy9ymBFpzaAW4DVAbNC1wpNVzmOIu5xYnJczNmN+tHTnJ'
    'K89lNPBzQYHZ3AIzHt65GZO7tYSEXOJvPs4KXOVxg+TNpw9/qSlcy16ZW3bpwm5+83q3FIFNb0H29JbsstvN78EWa+P0YWnBbDME'
    '4trccpZvy7o8P+9qY76gwj78KWyV1LU88PHz9ZelwJ26A5bCdTIOZ7Byve6/Xuen5mmg4FZNjt63WZmkrrl6I2wu9lhd21UgofOp'
    'bFIODbO5B11DO3q9zq643By+ZOR4Zhx0Oc1bvikcPrKFrOks0C/LbT0VTSv9txM1awKWSuXUz0ajxWj0Xc+Ryx/Q09uNwu2VpxH2'
    'AmXpnXZIP7x5ff5XEsDXm6gXcf+UFTULiC6MB1xfsk64PkXzNwp2uVnURWfUH15/BTZReuUXmDPMNzS4qa3p+XSanb9Ljor5Rw7J'
    '5Ah9vjqnrVzCZwgeC4u4rYQvk4XZiZ22K742P+7qbyuhWsCClTl3CxkaiBWdSL6e1+taicos7iO0FubpQehswtr9E581rCE2GsAt'
    'vhTWMISiWmSfeo5yVPHG3+dwlxy1mQTMMQPfGIYGT+hkijBrUFDiNnmo1l+saBwLgGE/4bNyoJ+R3wVi8QAxaO3vp8Uw8VwTsR0U'
    'eGftRe0bqzSimj5AhrG2uvrC8+jqNKX31z/l2bj13Upq3btUiOcoljY6EF+uc8if5kiGGrvPlzHXOyBpOJ8MaV4aX4kgAMYnDk3O'
    'OAml2bhCWyTDmKYFX7ZZCJFXEj5FaFBQfoll5u2uwXstAGEkJXHsywwYwY+qjNTiv313VSpu3S/thosyabQV8OBjm8VvTnrJh7Nj'
    'K2803bS4ET34x9fzr8vR4dLKMQ9l4D3H7+h8DVk/HkOZhmVDUjRkTGQwJgH2pcJkIr4g1IiCjyfGv12kjNY60ZuPe/vCitKBdZbG'
    'TG57QtyvNMA4SX8SxHQYz4A9AwQsCSooAJqAhoj2iCZJ/uQ/RL8rEdheUPswO+YwpRxmnlZ+DtNK1L7eiV6eTLNROsNqgGY12rsk'
    'UWcUPe/3kzyPnn96Kyk3OtEnjnYP6WeYxQgGyEuCefqo+TqdJkfZhYXAD9ratW2SG2k2IQT2/jDrxxKGUuYJQwHUhJR44vPO3qe3'
    'r3Y//4iXRuCj/J9Svkm7z2lp/2nkJ9k5ykfz8REsBTVUCjEZJ/xh/3LCy+LgKhokeX+acliLbtTQ4TbTiCB9CJvdpS2tAck7lXau'
    'YLk1utFBQ3efxiFOiUNTy+u373Z/3Nv/+HkX5sshbXQxXI1NVsvh56eY/YhFI3seT2n2X5mxrXpmuEvDMzVAwHY7wBtoNDYRrekc'
    'm4SctM6k3b72VXwi+NM62JGtB6RsdhndGniDswPi4bkz87LFujQqAEXBim08WoCMkbMBSZu+F7em4qjZI7nS+CDtbIypAXhZcPRn'
    'YmbYtBJVi+lvESanF41Nfh1maPzz3/+7+cC93nId1WAKDTFkoy6aDYC5K+IJmuNRG1jfTRnzneiAytHoStba3A6Iq0CNCLAN8LAX'
    'J2luhxVKPksLO9G3r+PvrszzzTf2JG2pdbMMmSnWtgJ9ihqSEqXNmdOdeV9kRwaahCukEW4+DXMMYMW1BOqBV+5wr8imuH/CbQZt'
    'Gk1H/u2ypdaVpfm2rbut9MtI5Ray4cY3gaeS+b5nzMkn/pIRdURkTRRcZ5U0/FWGnPLijckm+f3rePHuCJaP2e2avWHWa3O5Zc+D'
    'eeQcy9TFHToMjuZg7qBUcOCdgVv50vYY+uy+2vHTKOynowRgX3KE1eGeSEW0ytZXV1c9zR1t9il7QO+Lh66UUJqeIuNhFns6Gd81'
    'q2WzJdjcuJd9QW1vHgSlN1uHbWdDV9k3WbdWAhaJJ2lzwlTRy1gZfHVT9jMVFJGjhKhDk15FiIGSAQTvE9Fko803Bck05/1aF/wy'
    'NvtGXTvoMP/7stD48j6NIXZ00DYd7/QA2GS0pWJsiJetIG7ATw7jpIOSiaFgItZZIqJPiNGedssritlLuCrD6GQ6Y2udjpzWEDyP'
    'cc7SjsFYGML4NkxoAVYETjvZKRbxTx0un9YkHeLnPCu7eNHUD0gDtIe4mOWYH98v96fNKsoLJORkP2vK0vDn4dz2VL4pJf9AGWKL'
    '5CYJzjtcTNNSBsts5hsr4CxVM9FpibLE/bXtO2Ps8S7dUK7jg6j4qxA/rMHywAfx4g5eVg6+xuxz4CzM/uGizzhyBN02VujflVwu'
    '/K94j+l62xxu2rtRaYEwbI3p+VQ7Pe0gr1VBVvssCa3qxUgJb3SejDOgjLFOopfAh8RpEmW0LDAOPXSId86hNca573By0C1FGWJm'
    'Ta7liCr5g+iDPDdUo0acMynP898yLbr9zI7pZC4ErsLs8TQ9JAUJh0XiTweBKj3Jacel7DL33+SDzXBt4YkmM+9oILpltpfjnCfc'
    'NmzBXPsw1dOOKCOGxvNhDhXUTL9+URDw26ZygY5OGeig0/X0I09V5rrpdfwDy8/eOGDrp13Y57ZvWrY5YbN56qfSe1VL9LJpwTtY'
    'oxWo42+YB9Kj2NtY2q7uYEsJ38r4lFhsYp3Mbx1lR2fdBd9ARdG+LgM6HGIJrZJFl9lsaqQ8+HyxYCXR3GvlOaH/CuMvtsWVRSQq'
    'dqtGqBDuApJF1oYBNQ5oEFVqi4gKBXGpQo11U/cbKM6Kah/Vhqciqs1fiAcnh7Zf1SKaV4bsfj+xjlgEPtFVvvNWsq4Vf+ikYfrn'
    'BDYPTIQt0WqBSk/C083gzfxrCwICB8uULccr1tKNWkwx115u9ZFt45E7Y2xuP72Qxx0YcUXhwJbYjhBQcBoesQxzKVo7xeMpDG8S'
    'SXrd6P9GHB1AXJABXkYsXvxt9/Pe248fNv2iRim1kFgOTlhz2PkafEu6RHjEGdFayI6iD8l5MsUw8VjrTNMOse8Ja7RUoeYbSJg/'
    'MU6kpp5JI2GBE65xKEwYpHw2GSC2lDNSbGgF3ejBPoDoRI+SQzMSR3lAsg+C+4C5B+XRcJafmIvMktMsTAE/CU6Cl0LQkWAHL4w/'
    'j5yqalVpKCGY65yBFmASi7H18+HQSFM12MQ1Ul3A8p3QCLzJRonvjSt0QSLyR9GTidKPWHUZ3YGJ9KgEZGalyYonw0vjPkcwEsEq'
    'i7lAi8VsLdVoJXkleeuragegoQKsMalvYqkX4Na40r0yKHyNxqaxD/RNGnmbYWwD0ZwNYFbIWjmrEAo3fwjeuNuhclXmcNu+mH8G'
    'AgnJVm3AqUI+dHB7eaCsi+hoPUsUOIGB+OIeAFLQznvhYXMUruJAJXBcUQm0WpvOJtITzY865mHTF+Hl9QcWho2a66jDv/hmxqkL'
    '/AhLVqFIEhbAPtD3lX/8AY3fanaWWt+taMSEyvjevz+y5gVmy6DVT925NKqgvQKbjGx6DZp6WxkoeGysjqLS0buMr56AINC4Xz6/'
    'fZmNJtkYuoLRwRqiz9N5cUKn/BRTdYejuQ3pUiKJl09jG3tVNak1kFsJkX8yY67DUTEvbB5sFX+Em6671am5o5Hr+m4E9GJBLIZ6'
    'nq8bMrnVL93HKMjMMOvtZy9oq3zyCGaU9Gh0DJ+gmybSQoQOb5lNFY8YU/eZJX++cexkhokScqdcNHYSUsrccLQbLQw2UgMJ9Hlu'
    'UGdVFXMjGnzRV4+1S9heUgAQxqJoZ95P9OpWYW/Wj8ZOR9DhKLZMa6dOKNrlwj3VUjs6pflawOXdKp5Ie0PppOuVbSQVyeePvAzA'
    'LSKLSia7ZlQC4SQwXlokqazMxqdjXLg16WBgJ5VraTfzcS0jzfkEjcP4JcoX/Sn2JNDWNOEjtcRc03afjGN22EJiHRPYk9zKsNbp'
    '+zwtRNBxZZcClIUK/zUZH7OiLJtwDN5QuzWRqwwcNJSOsURox+ZDos0+wtiYkLMjDzCNkDxgDiFD0LgYFJJIxC5PcIZmczZhI2Za'
    '9E29cOWiWqGDcRXtacLrCBa0Pxhbx36SDhUnCV8fRustsb71v554Xz0RnnHCvz3Lz46ji9FwnG89OCmKSXdl5fz8vHO+0cmmxyvQ'
    'W65QigeRIqh8d/XDzQOFD8XTG3qCgeSL7AKPAkRGld1EeLh0Dz/gH0q9/d2VjMHNMxS87UVTrQU1d5DmDV4mYs9POZeo0Zt05NMx'
    'V2zNiqPlp21QQDKubOWU3dOFlaHQ5W2ws7GbiNPvTnFA28ide/FRPE2pWzBaNp4wuMrLAVvGcuXf/kLbzCjjkHjxEQxYuELfbFrQ'
    '55WS5IEoaQlkx0+O5u4Eb45yLcD5D8BIRyEB0Pkb+/beXeDOeatpCqFbXHtEWrdLw70FS3OSkNwn8WA4eG46HDJCLFWg0DyF4PL0'
    'jjdtCvbOElh0bX7bNll3g7mg6zUZnOqrMp0AM+dFT5Pp45zX7Q+eiVvVSaXM5nuHhlCS2V2gCHFKLlRGNU/E/adSZT+bXN6xQnfo'
    'KOXGZ+lxDDxO6ySj2t4DjMJL85JZvyu/813XVjpjDkOPTzAM1KpUgrfboudhl5vvrKeMz+J0yJs9KyihsYT2hQ9wKrfhnC5g+nF+'
    'kg2tAQhcXkzAFRPTJVK8NMCiIiYDX5i1jSdCzqfOWDRBPWIEkyJvM6Q4KqCToH/KBz8LI2vrUdbgd51o14XnkZqiHq3SEQfV1LLN'
    'HfgE1+x6V2Mx3ZzZeXPsDDhCM4WHX8f0D9sqRLiBnBqgH0OnDEW/E4k/Mt/7HfAEHfLVn/kNU4yCyIb5oI+APDKmLV3xymChQIYF'
    'li925Gh52nHqRHsIERMPu6UAQxAlbJcxmqilUkw+69kRb56stzrRawfPkUfwu6VWpFM228kFb9wMcg8jTlJMDmftvOD2ohKTWVGt'
    'ODZSJ3pATBHtKg/QLoA50X4Lvxsug91uYDYhc7Lsc7KelY8UCE45t640OuTzo2gP4+K9iX0u4c4NFstOdHCAUOckXxzifhm/w2+C'
    'aiVfD0w8dAk9yrnk8snSUfNDM2uJtcrMWvxwCG21RCSpOmp+d6WPNy29eA7x3rTfLzAyeWBNMPIMjdrRiJhtIHCOArMguAzdt5ZO'
    'bVYT5OyLJfiFHMs9zTHL8PCcFeorrfac/VkOLx5WjJmFY8nQsVOzXODViYtss+sh0EDoROEBoULFMVvUhSYBJrXLv2kc3JiN2Xiw'
    'K3Ie5sym8acbr9gZDhPB5gFcX3BJqNsEx5ocINjqGazfejGABK1bieeA14cqKYO3ejIwUc+43Y1hSo3pg7fXQoR2u1wYB/+kt3zB'
    'pHU2+x1bJcAstVpVIdqTl6fMyBlSFQ8s1TaCAqMaTu/UbyOn6QQthbx7yoEatIWrQbNOuVmeeWGAxRK2QMTtK50nz6LuptosCcGV'
    'u0hOrjWjSmv8aLN1vSr1aL3cpbX6Lq074cfT3DG920hffj9PKn1sfGR8Dt2vGu2aZnuNPpIAjUmSlwjlyBIKx2Kqb/YRN3vNmwm3'
    'edGC0TBiz7UxsJhkhxA6Gt8TYw1pSfyxc1k6IuzL1tMVK6VO9AVyhtv021yGO1FlPXMoTg03Zoq2aTYNxxtrw+lQ0E8KqSFoglJU'
    'xI5IEizBB1Olhu9npuzmSTHiMZd227AdtlkkA/zhD39oEGlWbBIyNmMCw/Pq4/tPEApIjBIl2GvamvfYYqD57RkMBkgEyWNE4/hF'
    '3U5Qb4vkEf74jc5qDNkK3tKZjZdu53jx7uPLv1JNK/9ofrp+s379ZuP6y7vrj++u37295m//65eP+7vXnz7vXu8/f/GO/n2z+/zV'
    '9f6Lj6/+7Xr/9ceP+9f7n+nl9f6r6zefW9+teLEI8v57QROjLUiGADwBzZnjKJoHX79+e/jjwdfDZ9vXhy1mLL5+/W7NtzM9n3KM'
    'N4QYLlohAK2Uio3fAOQ7iFTfLfegHcVwX0ScalzzFFZt1yR2pkWtyL/uHT7cafGjKvAcAC4cGvH/dKC/etbHTSU9CeUivui5ayPI'
    'SA4aA9df3oQ5QysINdzv4OW+QUaC+2xnf/fv+z9++PhqFwsQJS5tyfhq6r9VojEYHk1A3cVR2cYxKFVz31Sz+44kmw+mpvrIpBwV'
    'olPEx2JexZCnVh0mA0Fl92HS9oE75yt7CjXtZ4t8fdjb//wRTLTpF+a72Xj4sKGFN1u2CGsirlnf+uXsvq+UcYci9kpNefvXXf/N'
    'q9135VL/23+7Q7EvaQQbzqijL6C1fd9acNMUa9YGJ+ryHwep3PjWYM3Ut2+sEOI0YKu/fWOO+pv/8lvDTXG5Qc8b1WDmajXGAvPz'
    'ghZQb0ZiVgOvYUppzDC1rx63L/8rNb8p6Rn9r5dI8CCuYQc21sL3gQfEO2EA2ZjMFofLqm8HmpLd85jAOdHNoWb0rKmbra/5Ici8'
    'qiJpUflhUPMa2nnv0ZzpQ+NAFSAsr3y7f4B6y+OTT/sNv4ZyyS8+1xT8dczzFUX0o5KR9qEv13tfXtD/P12/f/75r7QHiYKyaFWK'
    '0ulA+559d1WEBuM3dBhoAjoAaj6HrdaiNcdmNf47H9DBXgeBB+vdMYetsusyn4vCXdttUBDzy3vgMGU03qHsF1O4nPpb4TA1G424'
    'O71725i3LUEJxxsRFWby8Gx8fNcQCkyXlm46LHcsA3dv1mPSRgd4QTVAWklcNKWkjg1zXw4aKfCTAPKg5rl97tCIGH0Mx/3abdzf'
    'X9m8iOYdp62dbruxttzWIlwGc13oBbf4RrSOyRRaSN10qV1mjXonwVjO1LFYmPRaN9/q2NK+RDrwpsGQ5bzm+c0CSTT7PKatOiKS'
    'pOJT8VXtrz2KYvM+nrkyIcGPQMeapjXwcMb1b6OYNlqHLJYWrBVDwmJqe3FoZeBi4IrW8ETJUPY2Hrti4J9Yd9J42PsLXpctUyD+'
    'ePzNP64P/vH162Hr6zUX8d3a16/XjbKhxwEysWj3HADeTRdFoB01l6ht4f7Tz4Zix45Ncq0VLdM/LODSiNB46AT4EHX3MZClQNMu'
    'gpCeUMPcDwdBjeFMGFweW7MiWlZzb4d86rWdy1l2qcvtsmybbUdYDRXdnBoHnOgaHEyJcvxdxrSicc2nYzUzL+3rRsDPHfCUo1oI'
    'nm2T2bXfNHp5GQ451dK4u9xs8RlaE+cnFEvkOJfOWeOTK5dYJnWrj7A75pBtIt07lcWGqoFo+beVhSNlzmYJVc6lltNMQA/tlWyg'
    'ROv4Un9JzONQa1lH5shZeqhuG1dSuzSmX8udchebrYVsZ+EbmtdxnTUrVY/nTx5fdqHhtcxIXXgjddGaz029WfeZxDcbNcyVV7T9'
    'Uq7CHOkXYIaMVMiHlXmijd5VAj7iD+JDgX3/gt03vj18iJ8PH7qNfV6rnUDX8BohZElzYSkXtOu76wl1O40f2oHyuSnbsi6G/jKd'
    'yxaTHHkLV+wfXSaiXHXAlFUmrvibHG2GBf46pleNBTP35Z0/cx/f+SNhzrHGgh68+dyomcCGMzrgQeGdY14RLEj7pYh9e79Uqf1M'
    'm42do+B4DRZKDcOmrzQzdApWD/oiy4ZJPA7n3Dl0CJfxTvk4tcuj3ZWXG8ejqyUP6Hkn7Lc3hFY53LnLat7m0ajwdR7+Dsj6rJGO'
    '12jQqIEH5dhSJY1xOb66aJIQDn3M4K7yzMCzoaZGEsh3aGyc6qfnYRQPUyxBxh0IP5ysy9pkbU7XaHVKO5jAcqMx/MsF2fz28J25'
    'L+g+5HtmSeA5oX7zIv4pLphXvegxPYJq/IFPtJ4a9TRqaDFofpAXNf7hVxawXlPC4iJc6six3tRzKBP5nF32stusKysIkXGqd2Q8'
    'mwjsMWP1n1zXWBVgNlUyZlRic5udTo1+z8QHIWkTYG1yWRPMmLA5NQ0MpILyYAzTACIg97cLXhvaNfko5w53xR9C2dW8ZdhU2uRF'
    'yBtdQzfHYKerr5efNXlddVq2V1xFY/4rV17d0KmwtbMTrbbuTMqWfrZsSRYVS77ZkL9PVsGbziW0YPBLdCXN8NdlddYiGVdZp1pI'
    'eaEiXatRKtbbe7xSK3O7YDvylN0R7CurI4btB1uPbWvDH4qq1t3bmf0T92qjfaMCI3/SqKNCb6qp32OAAjW2i/MI8Y7aTB+Aw8SV'
    'q1i9Yt0xm8aQ4H/JsmOS8l5lfXiN/5BNB53KiYCSvBiLUFiz6rQtVs1b0fKaZ+wxFCYWN5dghMWatMkpYa+INcglLFERz1aG6faz'
    'ldlwuyFQQsvLbOG5ee/OlL3oRAHEka+A9+ev5QdrveUgeDbZfpZuu9Pg2Uq6TQdCkvebVVqDgmey7Z8M3mK673aikI02MQhANZTz'
    'ZK3BMfzk8ulkHb+I0bw5kHIO7RHGPnUM9mEGlbVP8TE0TtJAXlGidZLX3GLiYHkcbr5tllQ3N16jZVvd5rlplWbzWWTPBX9KaTKf'
    '0azqhC4tGTAVuxNKm03ezTI1SF7JYT55HTE7NG6xzSx/ezZIz7ZNh56t4Mlzob655w+UW28o3cRtAuVbK9Y46gyy/oUYLPyScmiq'
    'v79/Jy4+nejFjJi1qHfJhutRE4bCcICiVZONJtMkz2FCIscYTPTQE0B74gaN2t6bxtMUxcDwnI0MUHc7WInN2YTNWWkRvZqmZ0mL'
    'D9Z3lDf5eHREsm3H2dC+/PzyR2ZdwRE2W1WzEdxWfaHFvrEuovT6Y4kkaaNmYgmvbkaYUfpGPyRsJqtjBPnUJj2VpIiR8JT+ICGS'
    '9KM/MQDI6sXuqxdPn26sr0b/oMUbbW9vRwzwoT83o+JgfMgZ8Lwa+BHiyrHVtK7H/Wl/A6DYvcvCmACbFq1evNb/bfrbxAXmiZNL'
    'q+zIHFBT/hGRhPcn6uDjQ9e2p87xkpO4glu2gR6HTKTAdkzq6sUmq95gJ+O+DjfsCHZZ/S1YxsAJZia6Ldia8VCfJOIP3yfCwNy7'
    'XitScWfPzqFmepPNpjC9ePYsWluLrs3r97RqBdCOPjx27/cSKmSA9zzqDpET3ihbjFnJvkrEcf1bEkNrvRytff90lcv5nsoxKd7T'
    'znDCJ81auQ7XYL5OY0xVpo57NZfUGLDSji22/jRmHbkoaKoXUtu49mB4kbcjzwxsx/erOFWDfOIl1NWkbZAOaAwE5ByD7O1KInbi'
    'AEZrE5t63PJ1kApm7CYlZuBNPPDqeTFDpDvO7OTCM7jDyBKDbpDKDAL1WAo/0w02OHWAR0BNam7A3vBi9dHqxqPeY8OJDU3Ja0+a'
    'j+DfbwOT+V+ecM6nq/Vfn7Jxgtce/+MaPqWsuqnmXFvnyaj5SB1de8QDXV8yvj+VmbR8YE0Z6+u3pKFGrD8RY+xSGgVCpYWlvLSx'
    'o69MeN+M8CMZp/XVNW+E+3NHuB+O8JwvTytj3y8Nbzj4/dL4BoMffHxUGvy+P7hPqoPvf0dj6wY2SPPoljQY/KfzB98v6xH1RLaA'
    'MIlsdqpV9IzqI7Nh0OG+saoW9e5ux2tWGA3I4LpquXTuzohDbkIAE9R9aJs7OAPeaYMNIO/C5by+Los5CRcyTeyT1ccgFjs4STj1'
    'whGUBjApEUBdolJloATZkMpl6GRXBtezQBY4jk6nw8uBteA6QNR1C8uhoXf1qBwNEcVmK+KTNfeub//0bPsBX9/2Fcei8Scgafwp'
    'Hk02wd8+46dhwQ/b/HAsDw/44edZRo/EqfYZHKdkgAy2ipsLR8pPcqfrH6E//PhhD7KFugjk/ZNkFOcdcJLUZBFgcnYZOCemaTLN'
    'AFVFR8JoCB+CJyuwRfQQiz7fubiM2apXagAvhU2TITt55UBV90qdzsbGfubbs/PudJv+4SHtMi7i1gMwgcn0LIEXgox0kzlwSraN'
    'f6e+OwJNWsznEczY28CJFkPCLYbk0TomqGPyaQqbIjZ335HXYvt+3j2Lh/CL4G83iCYr2mgSAVAWVy25qe2mLRO/FaNkkMa+5eWV'
    'bqfTVD2HvFUIQ3ka9M88Dk05c1kbIDDwlYtnJOMKvNtbLhmdnL4dvB0ds1dN23AF39ggmRj6mw534Uavx6UQNeWstC/UuNqp0dbS'
    'z0lXLYIGaV7sbz1YfcC/Xthf7+yvz/i1/U3P7yWUNulSS6Ap6bMPSv/i5gF1ln9eYsyRguj70zRKB3g7pu9o49YDJfSI30nC/oez'
    'v0zjyUnaZ8xtmptncffYe/OOL6XG2Uv2Nn2eT5J+sfVgDdlXavP7bbVFeaVi84tm09T63yxYDTpkZlWp8cWD7Wf0qztBsfgxPqOO'
    'oeV4oAZpz1dNt9VRF002KZAePfCz+w3H+94wnbxOh0O0Hb+jaZdRHVEgzTaXF3eJFQQsEH4aFw8U7H1YCQor15JPZMwvjqYj/KUN'
    'ILrgxl/iX64DWpJ5k73isk6mefGXJBtF+LH1YEpNeYD38dm7XBtlkmirpPIVM5p+21aCCdv2nmXihYJ5G7GE7bYU71rTBM+pW6F0'
    'XH6a1m0u9K+3Wbh1XrPIq3tI78kjFdbE62ubxc6nfNCy5XozLmjrp28ll0w9bHBRGE9fStyY1ZYfvyYtdkczdOW8HZ1wsIMf+N83'
    'LU8y5FhH/KV/ae7MObx2E2+jhxGiKZyrrpWSbGsJV5LVS98HJj8+Ugbq6qYUiBfQZljzAAl6oZe1obEsrFF4E2szbMVYLFxVIw7n'
    'AjGXtZpwiS8HxACFM4VfBCvEWx3Pnhyls4sSxqJX2WjFtc0owejJszWgpzk2Bl70Dhlo+D91ELeV/tBorz1df8oM7trGn9eeOA/y'
    'GOjtlH89HZPsvdZ5nI79tohaeavmqgZER5/p3EJwLCwqXPG95QxWMeSOsWBbV7JuGmJrqudeq218+IK4PJ4zHztFQSGLHyj4p0kC'
    'bymzJNAqHOBQlZ532aGONtx17AXWvudb2XgAbAgrDTEVMvCwuVNN469x15G7K8rgYfCbNax5xfNBvXXUtCowAHtrxlz0dtSkjSer'
    'CBpmdfPqPvBURfolJDBBWWB7q3XoXQynZh3VeEZbMITvDh0Vtk62f4WX6Per609Mu8+JW7Lx9J4/QjuP03F+D2tEnMZVXfvP/+3/'
    'EL2bcQova2KhIVGj/A+zkTNdc6k+Mw8hBpOek7jlLKCzZajFQKXL10RSi2EmmI3gcm6cTmgKDAxvsonZ/ijNqVh6cI3rVLLXXiPB'
    'BO/kksGFDY9sHbhEg9IvYV8mDb+gBMDAw9gjkhhZipylhU0Zvmw8vIyK+JTSf/rwl5X/8mn3LxxEiFpGRRXAfpWgx1DAut0ENRDn'
    'latwBHusVl1EKHbU8aNB3R8bFXqoOPaDRLZxBHCIyFAFb7KKpTesxVaeYdei1FsPmgf/eHC41HqwctwKLVtMU4HtwH6288wN01HJ'
    'tZfeqF8v/WvSCpKF8dN1brqew2HV/AXrQaxbVv7hdpWv2FbUDA8N8/aXMBltNjvlhLwBaXgWq/by2smDzUrvshXLnbx1PV9d6uU4'
    'JkqKhxw6KfDYdd8kJJKzi6m67AY+suIiS/Voy+H8ajAVfOfXTR03HpiyMYydWhJvMTAQV3lj71p+QnR4yn2cd8ud4YuSciesNGDu'
    '2Gh1QV4hkXFCayKF/lYBYXh18i9eTcIWc2icdJrkbr1MPzE6UehGcOE5EUjQvD67j13IjQYxZq8zOHDTgZL3U2K+aTjzbBjnD+jV'
    'yfNxXnrVz73nle2g5J5XbK/0LfW+paVvufcNGtTTpJQAO6GXpp8NEYxLhMrVx082Xq6Vm4Kzx8txQkM+5GHXXJfJcJidl3PNGH62'
    'XN3MZIIgP0zKmWARzNny2URz4aTGzvac6hw76VfS0rqiPwIFxsc85Uum+sxMRcBPXCg/MmWO94K5Wvx2rIfZnPvFRddzAgPrYpgc'
    'UBKOvbbxumKYb7HJ1hPXma7AR/mNesGur2xELLTnTKShy9LfR0P1VaKqWyUL3P9wR6T/UFckT5WSy4XEACvyqC0AEK2yWXDorXOr'
    'v87dPHY8FwffmHGx486ml8sZcRqqZBXLp2nziIb3tymFvBYF55vbMX+rn9Ack83TlBlY30oztIy8i3MQ5rGJkrB9dzodmsieMYww'
    'c+pKvbO/UE2x6d2L/bKwoNndC/o1zkg1NeW/oqYv4TB/+bSw5IOSH8nh3WuCO8vCsrHF3704dayaXxyOxbsX5/vqNIwir8eqIzw0'
    '5ud83ggW5AktkClHbp92RS2nYkOz3r2qxdAxNe2XcEJh+3n12hr89Vvv1VTdcYRfNSwQQmbWejVVdp10ZHvpKWmICWKGCaJwh7kl'
    'tN2I9CLRQ6C30iBeknj4/eP1x9onenqy8RhYcU8e/xmyfqtuA/KdlLyxOipP7E14/6lGsKUb0E/sHw9Xp7JaivVRRtVd0U9ZHTfn'
    '9dVRdT5Rg2RSOldUxJmN3g7m+ic5iY8F9DUaweHZ0A8B+ZRPZ2t/KNVs3u3oWuBm9Sscrf5nOUBZT8NPTaYB9gi/osWhWoFlTyXR'
    'xLDBDLB6awFgOmJgYtZysna8S3PyiVc8D7bl7/B0Y1O8Hbgv/ChqWZP7m9fOf82jSntprNB5hgNL0ztRufGmYmIE71hDi3fyqwoF'
    'Xngc4TKKHamsl9Cat8Zvc1Rq04JvlWyiy15Ha861ZoFXl7mNJTIoxCQdMWdRVbNATOHVVk09FmPsaJhl02bTEQ+P0Qq3BbaVIqbJ'
    'cfDHvCQz0GP+y9aDR/xD+K1VFqcgymw9ePEa/znJwipUuVAe80bBIdcbqBZ/JRAtfk05XBfwnNha+Y37+beGeLmx15CUZXnGxh+B'
    '35BYN6lGzaaAxVD0htvyR0iefvxADT/nqwYMz0MegRv0BnrUrQeDi5hVkiyA7JhC3rI+lbPhQyW97pbf7KJYMjlfyCBQiTocwpS6'
    'D5LsXXyJVptSj9KLZCCLkT6+JHnvfcwd4GZxS56ulhuBk1zFxPrvK2FpK2Zgapr9l2k6oDbj6Zh+vsyG/rCxoGcsk5mETK8437ea'
    '3bjgWNog8hqX7EQRujsCRca7ZnBesNTDvFtlXbBCr6lXHKVMvkABwpjlrFwE8BgNQh6cHGFrBxz5e1p7dvgXr3YjcAtRnQFRl7E8'
    '55Dqrag3TeJTn9ng9izBCLAqLZ3wxlPpUZCSO6G8WNFnaukroffLdD6uIfKxhhYz07yH/c7t+8FdNxvrspLjxJ4NHCPd2wkAV4xH'
    '3BluPXi9jv+wL0gZTCL9gN6E5vSIC/xRgadIFV45SYcKwflnugOjuiewP2nU3SzgXkEs06VWn6m9CWd8U6bhGU+cPLDl5Z0H96Z2'
    'oWnaiXn0GViPhS7AePECkNEtpnanesMIrJofrxtmLrhtMp6eYFs9KW3/aRts8ECzm8r8Aas5Wq0DZ1NwnWCCktQcr7wzbTG7Zh3M'
    'OS1N1saTVcMBb0XBGVQ6MWKcQZJLhmPyYuDvezWn0tq6dyw99Yjx+RP8p9PB5TQChyJ7kcY3Ona3L12d8W4f3pWVbEsUDGRbf+zQ'
    'KCu/je6wP0sryO3zre2Kx+s8n1cDiECVynLhjG07WldOeNeVItJCvevrr3B+/R3cX0vy1a1MMpXla4oMyk3oRHtHdU7JsbZWT1Or'
    'kvGUA27Q+8EWdfvYz5VZFzrTOuIUnJmaqrHOPO/ZK654kVpIRVuUaPtVKsQSblWOUJXqd1f2wNtoB33ZidapBRuMf4diOf60BIXn'
    'y2a+5L351mJ3HRpNachc8XeBAy8ablxDzRT4AsNcB9y5w3ubL27F7xP2sKmgAaa6UZV1KDbom6+4vAoUNXfSYg5LWswqxxvIisHO'
    '81tPa9mz7jI39Y7FvkC3umgNeHoodzSZLV9khPpN/4m356/ViSLenl/uzQLPZDRE/ZJVjNys1cqUyK8iq5b2nDmia9VT2QzXTXCN'
    'nH88MjYQ98suWOz/VrIBuSdBNuwtR9mxzt6xVM1C7BWL527ooRw+bflXLYzsRmR8T2CMbq1vte3B5rlisBhgx0P7RZ2D8VrkAPo8'
    'A4ZgTEouZTwoge1VHcfzVGxP/mUDGqcyu+dEKK5SWbmURbPg3u/x9/hP6dRwfPU7gXOMi4KNYE5lv7Uau+HU+9y5ij1NIBgZjS4o'
    '3M2v8irECcwGPs1eq+LKF/jFmp2b6zLHcWNfgSxDh9aK6bP1oX4+5MDBcSR3qc74A353dIbk8IWOJlOGBD9ncBqG2mbzsSNEA2CD'
    'mwnswzygcDXA6ZT4i8n42PMOEzO9MKCRwW2+EuT4LshPdCEeVnfX4CdyU7p0yN60Wp3Ys65vVVibQcXBhqrq9Di5sS4DMrTEdoxO'
    'suEgV4OoC1rpsH2xJdohV8OwCZzMGwKE7dTfgzMowaxBPbyM/DfrENMe/3lj7TEM9p88WoVHxzzJbf3RqugyfurbgwtWfFNPQHE7'
    'rWmfZ7wHy70ls0nIg+6iltCiuU6ZRcsVGYAFMMgDyE45oTWmvFpIhCDdOqezgYnkW6CVbbBZ+rf5mtnyXox9uE5Tu1arov0tI+QZ'
    'o6sZDOvTdmiLMBGAqLrO6gOBoaNubj34sv96mcQvhH4axMNsnMBOIX+ws30PVuKmGA5SIKIzvBFIdJY3U7z57L85n/wGW+rQb+GV'
    'fDQlxr+hQLg8mPy0Bv4l826wNGwvgD/g/QCwrVqC471fRKWwtvb9KnM3J/T7ydONpzLRk+P3Mbb1IqNhWXv0iJV7UwngYB6FYXLP'
    'cnqZJ1ntWw/+vMpC8hGxG97j8aywagDQkGnaijaaLaJ1En2r5KNMIkDX2eLEcMdNfVMc9yaJ8+J5nsbBSzbP0UfVJqseXow4/jUa'
    '1EIqFLgt9KkheHI9S/Vx2xqvoKc8ab+Y9ba+LnOT//IyL78bxryn8btkvPyXF/4hvFKuYVJ+msewYFZTdGv9ySPz8Hk2TJSZV75X'
    '6/BLXQn7aMfDaq4m9pKIXg0knfLWnPDtYOvBB1D5kAeMXUm0f/qa+/3za14JSkTIeFtdtnQ+zyuFy1suGxjbg4/jumrHsIFb2Jz5'
    'w6oHzopNoYySm+jHNRMt77wZ/XWdNadIpb8GwX/t9+wzopF9gBVSOAASq2rrwcY6U1ZglE0JlXt7586i+oHqVfnbtdcbT4lCV8Jx'
    '3KgZx43fZRzX547j+n/iONJ+/6AkX9QO49pdh3H99eNH3z8pD+P6k5p958nvMYwbc4dx4z9xGNee+MP4ZO4wrt91GB+t4r/KMD6q'
    'GcZH/9Iwhrft5bHE16h0Gb9gQO+yd5le9cWMeBYP9yRJeBKYXpifuX+Ec/glvqT957//dwh8//y//gf/+T//v4bnEHA0EpSFxiDp'
    'p9RIvs6FcdS7BKyDffycjeKxn1HTvxNvh63I81iCaxFk9m70PVSWzR+NWg3csPDAYIXZPEEOavY+CdYR87uvR4VnqUotPUijP0Yb'
    'h8omUxn7Hnn+kYqDQuOmYz//FytsgGt64A96qApQl4/U8/Dg+x84EjIPsvFktXQOU/FlvZ25MvnPGRLxN6kdiu+uePorw/U/ZTys'
    'G8y/yOm5cmqZvbiH8NL94sMM2kXv6S37VyIJR+5giuVbCrMZXhJnOniPbzx1aiiASWQViVdUoJ9ZWOHar60wWE8L6x1zfWO/nqDy'
    '8rE+9vL7XjVQeacDQ4RBqUSFg5v5Ja9xi38FeX+kCZ9CtVJP5t7n4CT1cvqkdWN75d5p/xr6SQjFFzamsiZ/OwF+9j3bS2H5FsiN'
    'tHGfwquj6h1P/ffLjDDw07cDvqDJH0T7fCKp+LySm7ccGXfrgTzDsQxjVVcOzVi5EDswrpzAR42nVfzFQRwjmcFK4ZSmw07FpeLZ'
    'fcUVzQWtILFxafbnUCG1HOBmbUXD2oqs+airzN2sdARl33x6nw0o5+4FHWZjPoNDQgpmNRCBU5FND5iyxHMeYb/0PulHtCg/xKg1'
    'TJTQ305bXNhvpKm+NGiZg7oTTak0GKHLY2kIaP9BpC2XofTDuZ+NB6ValrWGTkCwS0ptNTXgy/wK5uebgBaDfNYHak4O+H/VZuEP'
    'lMduJsSTFR/YqZ4VSCvW92txY2tGQ4AubP4yjEbHfoFeyYzS3HZ4S/d3bYWUe2v14Yr/XVtgi17UCIZ7yCY5Ee40+fVtMJSJ3MvO'
    'M83UuMJLafsbHUPhwv0Ri2AFBJ3/Dgv2P+swWCtvfSHmitv/qhQ+51hYNyX+K61dGSVFjDFcKU2Da1B1mjE7pe22MkuVXL/DXPUn'
    'XZT2yTZS+cf+5FcPwvxuS5EDp0qezKZDURz3VxJxM81X1jprKy4tHUmjvDYDf7EpL/J0TgDgtZW/v3+3x41fTsfofB+6tkG/y5ds'
    '7vrPBYLDoWe/IyV7wmbT7TAqNCcyn55pW+VFMoioRcY0Tr/8sPHy1f5rXDg6YL5Okb3d+6hudS0NMABIhO9bN/8VFQSFEnVUZqqG'
    'QiqEbinE3kbUZnG7rs1gnAjrkge7pM3hRJDaTLLH+I0L9xvmQTnnYeleVULxgWFqKfSVB9hjiheGCqYPo47DbevSk4flo+YHJdjF'
    'xu90wgmwen1U3o+KhX6HQLlW96DhvFULRMKtCa4chJpAeBsLoQ44LA7kzdetFhwLxeDhU9r3Yh4bIwaL+OUDtluYr27kA7TD1ICd'
    'O0eKYcxWP/yGwYsNHHolJr0XUxiTRGW28c+8oMK/+3i58MMB5jwPmLs1h1N32j/R6IlBpF4TezOfTc/Ss8SCIFdQj4lwBfZYivwt'
    '0Y7tXbTnSFszUYKj7M2Ulxz40aViZILqJpyh9yvl2Ak1Bblgyzbc8ksJtYxQyRiQZO5wWENbH2z81tHh+Kk+WZbrVzqZH/LZQJz/'
    '5sDPWrsJ/mypFDSrtX+c8LEdRLJlvN95BOnRHtroLc/P2TklOkkHAwbCNl/gZu2/R/zbiyCmLuMRv0/GM21Fef+021fVC6hD72eN'
    'Vov2SlsBLJTqzFsWFHMQT9N4+STOJ9lkNjlEgT2AMHiOQpyCNkRaT8kA6lO29GiE0YGL7JiIh7vSKxgk2sLXoKEAUcZv5Rsi8f+Q'
    'cPUCclQU2djDoRsD54lK6kBdr6AWe2lvKMEDaKsX7RsSav83Db6zjCceva8Yfs1mQljoYyvKk4SEZyTu8lGEXKlY4qEFi0dDmQFT'
    'GI+KHe94MNg9YyB5WmWI4taYkKBOneZNmCEptzUqwH14koDR7HAn8mKno5O8jMiGmBi/d7xj31MkHfmf2gut0Bk6PY1GwCDyPlqk'
    '6P03u+93f9zb//gZWNGNnJmkZY2I3mUTn4aHdky938e7ZoE45yNgsE2V1IRm6RzmBHiJIbOdNz909vhIp9I6hZ8aXTfFthSSZZj1'
    '4+EeUSikIsrB26vXbDalcrvDjS7GHjeDFhzblmKbhdE7ddoYUGJcGoIMISfgKMs0EFSQnzlJXccn2Sgpvy8Xt3eeoiEM3oUZwNBz'
    '+e6DnRK7dfgF+w2u74kN1Yxsu0MlaiB5AUrsDb1stixiFLF0Y9oac9oHgL8hgbJRIjNT44FEE7y5x+A778GCNRvNyTQ5IklkmS+k'
    'lll8oDMF7W5RQ6qE3GdEQkvDamUHDgJ+CsCy2dTpNO+CaT2uTmt5Trm/nLnlqDDpGICqHTMDnkEa70xmILze55fU7FE0GxPrmEeX'
    '2axxxrBaMFgkyepezWJCNsR/4O2gK6XwxplwaOFTDmGCt3ySDfX6scjClGLMVFqHfuD4RKRLj2WivDCljO7LKMIR18aNP9CPhxbD'
    '7So6TccDHoLxKWIx9H7q1qSHw6qYVHSjd28/7P74avf18y/v9vc4nY9uxbh9HCDUVv8BbfJZcY7Scz/NP2dZ0cxb7FigzSimCQft'
    'ZvPxXNuTd3iQrq/Z5WBeS5CV/RKYeCxILVsu7wt20JjVqv/89//nuysvvP24HNveCWYbq62bf/77//ttM2QBMLHesevsPP0ZMSvV'
    'vcMe4AzwcaTAGaeB0hocOvmUvXTEQpemQw2cv/F8Giy0765sj5ofmkWHRoivHEiOZZa17nuRtSTM0DcmSaIyP1XBdswtgUc1LVbm'
    'I2xvYYyOG8IEcDxtplDwYLyia2k6LZjciUvrnwJITBLQG3SzUzapndKqW8x1cAsxARHt78c428osC5VRk0/YhIY10O11BmkOFnDA'
    'k6GGhHSCxnmOraojbEmzkeG0vU/TRYQrY3qAGsyRBL3HIWLf0Cml1Fn93uKZ7dmXZ9YE0Yz5i2k87p/4LB+d4kwT7LfPa8Ofo89J'
    'zkRV6YRJ8Io6H/KQQYFMZH76d4jOe1vym+BwB0E10b92xFzubSuCd+XC7D+yb4xGqfe1sgx81DjHSXtDrcM74N5GMj38blPkDu8N'
    'tchKh4FUEoSdZLgOWRa89bQjyd2VzMax4Y4NQgnaHpvtY+8nIsvOaXKZS2hJG5nIq1aHT3thu2e/b9rIP+5QDg+HTEiqeZdZqdLa'
    'vFnyFlvKDsT5rIcMupOA+TVBsrzWtuggoC+dOWNMgxr00yXenN9JmPULCf6H0J3X0VP086DBGjIIMfGUFjh+sP8ZfjDn0yjT4amB'
    'wsbnGR35WdaNejHtg7wv5hJPu5HfixbNctD5f2mnRGG0M9UwZNicnUxh9tKtqCxYuG1UvL57LbsPlPe8drjd1Qkd1LN4xMfECRC1'
    'WYqYx+9w2kT1sXfXEplQ5ypXo4wGY0FcLMA/TMeTWSHMPSWUI0Ec1KOGtKOxyV90A4icQlnes3MdfA4Eb4LzFickx2onG6ZoIxY0'
    'diHZgSyk/HYEcH0crFBiDzvRuwSqibSIktGkuMQXtrpKfUEY9220KJNYoOa56yUBX19yniY1QNt7RAORm8YLA+oCswwyXrPMH/s3'
    'whhueg9DN+cpjSlBBn+xRaYIo2Pwg6TYYazFSjNhry1Ttr66am3+LyjLKDvjUS911jZWWsRtpOP7jDc46P915AVZ133ybgZ4Hegu'
    'Ibt9K3IZ6SgJtyz7adMtWD9qld+M+2eGM+ccYVW3lwc4aJBU00EJYzCqy5pOmEBZIK3p5EU2wa1CfMwa8KbnmZTgVFIUNVBkw6yr'
    'pheTw/bHT53340nikqs0hfa15jewN5zBqE7cv/2KWiaqli9VZdkQPp/hBgEKZRXffjpKppu+Vgl6v1F+XD4dsBXwR2xiRYnL5UMZ'
    'mfDJ8YLU9GYD466mXPAyRYXZjFhoWzsy2QeWhQqTSLroF6m0q6UyZa968TXyc8iqL3GusOHF548f9398/fbdO/ZJ+vT83e7+/i4x'
    'FeiNpE3ykjrAL4ItS/piWSJbeMRN2XogqR7w7clyn63lbh7IbdDWAxxWx4xo3pX3TJKaaPvZihQVWrqVWnTH06bvnzbm3Ogr0jqf'
    'MtwRjix90yrJZPtCGgEjUBZGd1QWtWi5PETM1B8n2eggJ9blEBvCiDZQuIHlLafescy0x24bYXvLSbvN+zlKaKb5+xh4KbyzYFum'
    'zdW4bmK5rHlFM6AmLmnqBQ9xWpok46aXh4ZiGE/yUoOk8vungLIhgVZ6ZPMwkHUpfV2B4XrIdzp9/cboHbusvWQx0OaxpXwZD7JS'
    'FUQ52V5BVOQF4+G0n5NK2mlSTfsr1NEdITpRQ88V43jGHWfS5/nIO8zA1TO4B40/HL2gs5yD3x69LWIiX/m9B0R+MQumJOnxsfm9'
    'd4LNkH8idIT8EokNP9PngwGYxe+Yza2dEamxNb8f79CPd52j82h7K/qznoqcU1t4e96UE7qM0mp7Y4G5z/FKTkmbjHsUpIJzfZiI'
    'e1ijTRVQZ8YMaOYcX4BDjn+Wo/+f//4/mLIidW7Fs21eupf+UiJ4fv2Z99EyZdvYBX5Wr8n0FS+51e9ts/Pd0eTEXZgKZwc1MljM'
    'vEO810mcp3aS8tfxIJmf/Ii+2qTPZ0U2Pyk8m/ZTgc3l5Bw+1mtykBp8vWvED6zir08J9b87UzKOtgOc+uSsHR2N+UwSIqzs0prC'
    '22jHyfmvYL8ZHkDAgoEj7tgbYjw+EUNDmexXajI4wWE8PsVjzhz7aiD7wDlZvhVEf0kTOy4ifwJOLTOskF71fUjOrTSBm72XxXS4'
    '9F/BMx+DWQBg95B1tyyLyWUUaJP24oTFOnNAuR5TGkmBndhPwmFNzUdcH/ofoYAOPj7Py5+f5zbBSyCf+N+FZ6CZ4S/N/gyO0DY5'
    'Thg/NaXDK/PdCDteikCEsuW8Fq1rtVZ8aLr69AatVKW+tan0oAxqxfrcU622TQhq95MV9OzalBbVJl3pZRtRQsMRxI3NxKePlwtH'
    'j/3Ix03QKu+j2C1AUvaTMHvi3U0mHZoB+KuLasGNjNEIVzJfLcq+WdIm+115Jwr50gCwdTg+uVnxNIdecl/946e0J5AbBZXe/VTV'
    'KbSBKvxLxHBew/Yrjf3mEZUJCbLym08f/uKWSzYJCAhGJP73Xd8Mp1qUfgiKq0nsmaaYpN7tPhKau6yqeQBlqLMZcDUq/1QZaRki'
    '891bg+bVc+EpFs4Prp6HQ5ODxJce00PCcR1uKkVi78h/faHM3IYlCov4W5poruBcWZ+p+F52fjsxSrqQCuUmdO4+ItfV0gy5IHTX'
    '0cEdrdwQgjHhV0Edwr1X6vC4diqBm6qnHRWDM0OfTDmWwbTbIZMA3tokjvMME701bJwk85jSsE202InjQQRrV6vlWWuTeiktRxve'
    '3YrFXHMs4zpWftGT5IQrIS4LcauIR0gQq8YVa7jjxaUyf3n3QivbnOoXglKr6t2eTkFqxxmDwH9N59EQT8s7Zg2vq5m53kq9zIGO'
    'jmF7yEw5fXMTbz5UxsDIxUd+x9l+8WAVdxvhWDA4jRi6gbf35F4WnQURIwesxpFPvsIY3zr+hlkuT0HQd+XDbxl2M3LMngdPexyO'
    'SKMDSaB2+YvOvR0kccOvTvjp6qjV6PadDlvNIKMj4mx+wSaqWi1R0rN2rsgG8WUjj4A+Q+VC1Nxk+zm562RLpHEEZQeCl7FZ0ngg'
    'litVbj5QoEvlIVNrErJy33aNhZBagrBMdJ1UUldbfV2OAESCuXtdEGluqceVzYLJ3cuGrFJDYrf1QCSlu1fDwtPCelA20cNfQQ+n'
    'yaVYDeYnxDT0ZwD/yKanuLQQxfssNxcYqp/s3Fugo1A4IlGbtQ06kWjc7aNeP3Ro5ezG/ZMmEMCgQq0Kab0QOvfFl/39jx/4zBpl'
    'szyZTfjUsgOjbGRZK9nrQA8L2YI6Dlr/zNv/xx7DZk011USENmLNqXxmvqlsGFJfMvxSq9XJJEMzPzuu3vVoNLJ4TFuTew19Mvpo'
    'TAn68ZixmqIpjHIlj4n41Y6gSWh1Ij47aYUmUSxwV5M4h3qqOJlms+OTUrwwMWalcmOY9DCgf3ESwwWyN0sNKpS6jUUwpojy/hSK'
    'JOpd1BETN7ZC148kbUJ0ZCU4NbdRRPlohnMY1dC2IHGCcsjYKJHGfjAEQjidN2CZC1dZ8/wEvaTdkQiJMvSSfgwrVLaiiGdg1qbR'
    '809vYQA5TWiUoN5ALdwQvk8CUBeNiOpLZFA41OmAxiPOJa7Wl8/vcg7nJl58JEZcguSOltGQGMdnx5n48VB/4mkSBctY9JOqidwN'
    'Xr/ISIijuYYSnl+8zqZqwaXpjSrce/WS12XBShAF/uL3n9mERO2//NaAj7IgsfddA63xpqT98HF/98f953/Z4wtmsWeLj6PlbYGi'
    '5NsX6kZsYiGyMSmlYPOU1ag5G2MH6uo54Igi5/B4uDz9xPEbXnyWP/yvhLHhn2/53933/OeLfDVp3v51l3++2n0nr75o9i9SJmKp'
    '8A9EQeEfnz7zX6r1zVqXUbeI/tf505sN+fMI7zfw/rH99cT8+iIVfZQ/76RxDmaUH59Lu99L+9981goZLJJfMSS5/EIwJvmFgEzy'
    '67Mmkj+S8NXbv1ETsO/vfXr+gWEQX3/8sI8f927MVL36/PGTmaqVfzRlyVzzncN1eoRwxNfyb8amEtdM0tcFnXTDuEiux5nJcXZ8'
    'Tcvn5Bo75zXfTVzDK+kad/jXwJ24BvtxzTvqtey617LbXoO1oOUSX5/RCs+u49kgza4l8l3ru5XUv2Gohr7y7xk4NuDtcbRgwc0o'
    'aihg24TVwoOoTm+LpqUqPMZUnndxPUjPfKyB83h4ioWD/QLSgodo7YdohLUvccBIVQuOLPETGe1yUTAsqqBD5wEdE6KvKjUS5mbI'
    '44pi4OMWawfLoRKrVc4FZLa0JJjMYw9Xf26QR+wLW5GftFNkX6jtGgWpHU1nfMlr95QDSncYRFVECvQag6yw4TTCQWdkE5qNT8eI'
    'rEIjLlvMBGdVfKw7jQnl65XNzTOhiCqBBDhUqQ5PXQAiEy5Wrs5D2Of7tNrgO5fvdGnhpMMi67ZWUhk59hS/pUclZMKgsYhQxLfb'
    'YdhKwClewx35+jg9uj5PepPWJlbmk0ftg3j5l9Xl75dWtr7mh0vfmYbU9IxjGGnH5k0qn1hzVgYWHiwDeVbR2JyXJVglftfFhISR'
    'sALEzXBGEHAnr468mK7WzomB996sZp0mLAGPM6gF6KwcZ2xNPcXl++b8kW5VS8Ig1bYhjAAVFLUvESfc85vQ9CkW2dgEfEEwk+yc'
    'fx5WSRP2HLzxvR3XzSIicK6tlijyjMMzsAHGM/q6Wu1X3I7OKpiYpb1GbYzxP4967dsbYyfBHzlGKG2kvlkyPfoW8+bGhAQr4TbV'
    'fvi+iVzLt70rzxA7+prRlK9Ppq2vPUvCJr4tja3+dvYtzw7+sX34cPv6T+NePtlkUxcXw5kt8LCJu/PH6Ys4RjDfA5AgD5udwJti'
    '4X1MhW3yrWTkxiVl6ZStS5SXa6orizNBU286rpuGQHnCTprrlTEqxHAY4jAJjIWRH7mxulyZBWR9nlohYcfXkvOmlsWfzaW0Z2gS'
    '4XpHpC22alELC5K7uFi+aSqlIIFKqpyqPW7Zv8oo7a7KN1pzRtRYOJWY4bIZn5EuGZCWee1sXGv838zjMyNfQupIi0YO42q8BC87'
    'Hsj5wTZJqkzvhLYRH2wzvWu7+75ZgWeqZUIlS9vVsAFGBR/sa6bpZsnMXx63bL+p0ICOjBOACypjawmcBWx+c7upQgRjJJdME8YI'
    'k16x5P+ilvw6go3WHIv1PEl46ES8CS2bSytg/uzLDKeDsBPIsoO3XTv5C/q943fby2KXlneHji7XR8O2wTdMtn64HjVzAwTKSgFx'
    'xLM5KkJZMCKShNUICGN3FRpAOUGPVlgg9XmqBjd+7egRzBUiXgY/wOnTrQOibiMds1+pRJLHnHWiffotUXHV2wCR76A7OEtzhOHO'
    'eYXg1o9E3GTiLQN/7oRzv1vz7zB7VaqV5RUaG/NRAk5/qzx95UmGnC06T3P0wO0942jWXMINaIt/dT31t9ZryCHQjYvvwZg1quFK'
    'vx9OfWiHWCELMSBVw3l4g79Kp8WlOxTGqrMdmwOTnkMbSf1WsxvuewbANJG9BJueHpgDiOaDTO7a+VK+1QWLgsv82Vg8xIi/E9ds'
    'mvmYrXbgTcyvPEqCkEY04lFG1Rrh7sQtfmrlnT6C3eJK9Nm4O56zgzGrE2bTHHiNsShjjDkjmgArTXE6Z0UTe5dNc3QnmRYmyrj4'
    'vfKQdBa5iebmgCvp/ULTuPAkNHNIXArysP2Yf76rpihvcohRPjOfF83VVgf0ko2fj/vE9WTTl6pQmrIcEWh1KhkBS2LPe3tQwZIv'
    'F1PXwMpvyuXLqtFc3KEa/sKeYVJ1XS/c54UdmDtaUV7HXOSOn3AVlL3I8eXlaNDsjwbqNROZi5rwcK7nqtwCrhmRwIU2uUj6WL5E'
    'VU1xXfghLU5e7u0ZX0fr8jgvFzdRk4p/jzsuzFlQM3WWeRbyxTc9vmQL3LZj0JAU+MrmMBU1i08B/Zj6zlEWKmaeVVoWheRACM8j'
    '6Z0KHbJRhZ127/w1KgghoNu0H1oZJ3QB/jwBwxVVocVB0uJQJoPEc2Cs8nA6vmVn/1vNIrnGZWw3eXQgVr6jwaFzhONQXU4cUM9b'
    'fhMWq3SxVwDPxjOhHA3K7rcLHemycQl/v8daKn9+d5y/ycl6OzrZaEsEGfZbbEeTaeLsAsecxzOAQ3E7+NfT7XhyfcTqyRoUEkeu'
    'fF2aC1qMT2sk7OU2ipk3BUesPpPULB5xuAQhrRyrTu0eV3jQdYBRmODaCCQGCUADuac9avnj6YA3ZkMBr0DKiDFVGPiGExunZy7V'
    'uJOFC1C+Mc6l2IHD+pJkYcaf7NCPmwe+ITfjR062n/UAaDrZLmE20E4nlki/ctdSY2+RVObPetygp7nKLdZgdVdWGmapz6ZgrSbT'
    'bDQpEHlifIoG0g6Ji0GtzDFnSA0GCZk4ooUpzm+oFAkUKqdHu02DRqlpgiUnHoit6w9nAyKlxv8iXib3w7eoEpd1Ug7z5V5jllDU'
    'gq0ezSkJtBh7taapTP+3ZzErDzHfSf7/1/Z1220cSZr3eooS27MAWhBI+aenD0mRR5JlW92ypCPSrfXIGqtAFMkagig0CiDFVnMv'
    '++zFXOzOXsy+wz7A3M+8iZ9k4/siMiuzfkCqZ/ocWwRQWfkbGRkRGfHFEXvLXOX+y+5muqdGCU2sQdnNM2tV0c01DeVjEA+s9CPt'
    'R8o/Shpr+q7FdA20r704ew5C3B6qbQr0yjSS73c/+yi/XBth2hefqPULjKJKGGnMtzET7O3e7hL3BshbVlzCH4gYmPrb7tIM9Ppo'
    'QozO6rMUs5QRVlO1Ud7XuBvyWHYT+nKCJKC4XnNqGsqHBVJqsZ788NhH8BtreLVahhImfBOsOupL4ZXAcmFNBKcU841a1ugo7SyS'
    'Wn14edxnm8MwuTRrX5dfur6+CJisLe6aewxUs1PdU2CL53QJlj+7YcpaFymQ5Ehnulh3/1BVLgs4uFXJ8cKbTfs3J+7d1zkfLR8X'
    'k5xuOmpZxW92BYL7Up5AUW3wkwd9PiY2fH8xTG7TWL/eGvzwZbU5JNodKVSyLahilaeuj36uL5KQgV+kMNI0yGocROt0zNotuo6t'
    'RhQxQDYlR5+wFrLE0VwdDZOKGN6CjO8lD9750e8YFlTraEUpDalyuajCCde+dPMsxV2ShYkqbtkdUqvuc9raWjZXxSgGRlFhlTWR'
    'HKFz7jBuqofqXTKMXoLfR+cLVK3oa+78JzssRnSc6a7Hgv0qY8za0i2xi4bvVEzovXO0XEx/n11hxrIRLn3lyzA54zN5ORb6Kl+w'
    'ZsTiR3lBJEo0bwi7jDeI4hdcP9VRRsnK0wd6JGd7S+xke9WhZbm9qjO7pLpl7zLNRIrZ2LeoAnIZfLyhibPOJryEV3s/GOZhOuaN'
    'X8fZNs1V3m2r3UkVUdd7xWqJBIRkDppRsedNAd2kEvvce0JJW+PX0+osTXmJ005JnR2/lH4Vl0SM7KdE1x4mvZ8ZuxJe4w3r13jr'
    'h0AovXAILU03wbjlIEb3HbIdUuHtq48os8i/G7zDN4R6H9MTc41a4m92CLfpFIiG+BRpRg3bZq0vEODxtx/6M7iG1I2iJpjxx6bk'
    'qaVg5ccUrW1EIQwH5k/ZPeGTRXoi/HPh5rwlKvqG94t5k+RqKwMN+RB5DoUQ/rMLc7dtZXbaKaUrxtuyNhZldHpj874qyhzl4LHy'
    'CjBz+0ZZUuK/25zLxx8hBXZf21lXpQHsHtzhLQ8wJvwyKo6P5bvKm9V3x1udmXBR4zZxN1nK93EQv7quaPtg2OEu2jYvUAstNpfN'
    'MjlflUs6/S2zdBpK3eaUp2Rbju78tSaaCqeoxeFT/TrDg7G5/DCa/ZeYh8ZreG0V5oAdGhuDnGuuWWZaXHP9zlbncFcOul3slnsN'
    'dapy9p0dUkrqdJa/aPHr7fSUvxhESutF1FA9AstOQ/+cxNLu688JfXZ+0nT290+6vf0d94hd/jsd/hvEW0ajoJyGky8KafLih1L4'
    '18IKoxs4pL1JsslJpngk8AVO8uUOyxDxRh1S9YIjm4wC/8uDn9+0AEMqiSlYzs4dNX+Zh5qUvtcK7me1GfbG5SC8bqc1e6RdeSh1'
    '3Et68w+9yAbpF0J9mVtxCNrwNG84eiFzg8YuAkG4rU9MZ0rchP7RND2fa87yN3x6X16vuNHnv90aJsHTXydbo78fDKoxVY2v5t4L'
    '9qNZN9Cf9lFZMAb++GC99pIrHGSruSm6a2A0bUmGoY9P2/jp5VM3CXMcnWsQ97azWNVV0Lh2tf3Cw+C4fCaygwzZzGRA1e1Hb96L'
    'O4n8yXoBh9MdXnrp7Erv70Qw9cmQ1UcU7nx601mewjKLM+E8PdMiY+iB8OVSmOMMqMdXCvo0unOzMPLRBO1YfmBKk/3AeohA6BKM'
    'uk0EwATdILb8F7WCeTuw6IjkFJmlt3kTf4Q8C3S1V8jbUjnI0WmRH2XtLOS7Zy8OD1oYCGutIct+h9/68NVQZZzAqCzXhnzgQSxw'
    'BcGXdoJ3DlmqDp8ipeDHQdyCD2oQT74DFfhYECgq+tzFiVixA1/CQ5G37ymOeOja6j2g6rNVI0wLTw962ow09jPSPg/+uimYCboj'
    'xiG4lYLr95evuJVNs//qYSCdj+4t/Is+rLMeEwJAWkQwbCNWQhrzHgAz4KwCIXK8SBei1ZdZutDwh1rsyGEYKnEsqlkZhWyU9aoA'
    '7DrB1fpcFGhtdXkKNwHDdaXyNsHepl+BhY5MpAOomt4mQto987ga0nE36bvYMEsxPeArqcsnfh/hZgwkprlIEXUNZzcIvFB03gA6'
    '2AVWuK67IAq+XJrP+ffpvInemxz84dtkLnMwl2Po3vkyP8+skWU+5T0lEbus4v0RWoMuPA9VEHvKh7yl+B+4cpobFFf41Csl28k8'
    '2KPC05BqPL6qRS4METkv5RjbhLvnlhyHS8Tq55p58e1vthBwmckbk967YaLfz/PZSvRjfP/8S/kuHHfBb38/RFDuFT9/OfriK2Dy'
    'ZdkZvz/4HG8K3Z/y67MZXCKXQk29KyGn3rt37vYIUmNZu9J7C6lhSJC1d5Cg2cEIjDLZZRb5yiY6c+f+efqhj5gOfD6eFsVCZEue'
    'wXoR7O2hNkrM7T+t6Ih/ie3//rOPs+tE/kGeMPlDB1kgT5M39K4xse+dZ/BFsvmQ/XD+iyrQXQoJFktsCrenLmVNTT1B+k1zwMlg'
    'bEZE45xXCOpD1WOM0FLhMQJnGU9f1JHClaVFCB3HgxGo7vrP9oXUh28uuFqhZumETEIenaZl/4wWF3erob8DvhG/7wTNAGpOz/xh'
    'AtSmYeLQjoaJOmES/eDsyWpxAU8zfCawaakCCHGmL04MErjXixNFKA4JFDlijJznMnPLrP+7g5cvNKBDP6rveH581dfhyqmYZ5cM'
    'n2vAaAvpKAygsiPEZ63mUu2EuQuKO5aD4puFQgRm8Xoh2AyuVif5TJ09Z2BZyZ+KgkwSIV3pQs/YVPb2rGKhiFS20LbUpaYwETZd'
    'nFGSLI+ymfOfHRLtcTwuPsC1+DKk5PEIAja24W++3JKHp/HDU3v4pQfm02aArzgefZCnqGAz+Vw2Ov8Okys+uuKjU3vEv/p+tT7v'
    'd+Vzgsl9XHxgVjvsiyv8c4l/Tq834AvAqMNH5VyU2tewdjzc+PB9PvlR/k/Os2y5kWieApLHww24seHWU+fhendT2tDrwuDoCkmE'
    'O014Rzqd4jzs/5XkZ1CJZk41Gi+VxoeuxQgpW39q8VSAtKCoN5+Iw9NMcxBhwocu4e4UUvVx0FLCmDqP5uDYOuAPaujThxW8pH0P'
    'ESZp2/ru5cGhd0eJjjslCV+3sKVV2fAE1n1cFft2kdfRp97vTvILB3mHMvcJpLmx92MoHcBUohuolK2WWXBonAsKMa9Jf3e8F8uo'
    '92WtVx92N8d7kB6aj8/TI/qayS5GocEI98XPZsp0nb4gUghDYMslEA8gjMi+pkYCiYQ5cFMe+1braHdThhVfdofA0mvmzA3ZgXp/'
    'k9MLUqUlNwkA4HKLZC/U8gZU0q1fNnVnSed5v7cp/27aExfNonusny0WbsVv6OmmC6CSdqkHbqq3hdQwOs/KEiGwGAYpVedzmY7J'
    'LhcZ57C2gOb9HcqFmIKgvrb5jIcdeD5UGFQyDfX9pE6zboTfqPRJjTmC2lbX2jsuOSvAX5krApCRPm7k7ejX9/b/8bOP1/3Bn9/+'
    '9O6nn94xduSnnz77b73QU+40PzklZkkfEwkhdXFusgvOP2esL4/4vA56t8QusFesKP74bmiA+MnTD/M+O9pnRQM5GXonORwZLFEq'
    '+CvYrHBYfnwf8jbUaK6/j1SdEiXxKFvMhXBoNuHGU29v4zDokvQTz8wh1oHpavxcGPYwy0V9bxm+YQLjXhDzi7ca14SYohR0d19k'
    'uCmXZ2vNFDnpL2eWCqnJe00szXaVA6Fvi3dNUu+ufPzzn+nHkC55y8TG8h1ra+ldGiqnLn3Ny0e9IJGvMoXgRJajWIrfT77CWZ0B'
    '09qe5TPOh1XPUvfY5r3kt1vh2vS1TtlRDo+PSi1fVuGfBVj7oBW1F+h+aHo3CVqMK6wheVdbq/InCxhO7D32x5bTxjCEDS44WlSj'
    'AHnpj6IbTuVgZF8H7grmcVFMs3TmF99d4jgVRy9e4Dd3XJneXHiYk3sVq/f6pxk+U3LXj5iA6/dNKnOg5OjZiHpon9tdaqxsL0If'
    'ftGrw9Bn7zgWsQEZArd1gG48S7tSQofihqOa3bJcK0hv22zYDcLVQbFYhnMObK4osRWR5ixjBeL1xoohN3K9oOkge1KcwzVEhEb7'
    'fVgFKQxpMJjhFupClDShEcSIIheZJa2rqsXr1CqEylP3mTuUC1UiBV1YmnPEsvpJdp8OSQvV4pLiVY9BS9ccUroCWtyl7lANyP16'
    'DaZB1c74FlQ7gsH6M7gU5Y4pahKmKVlL40xNYnPz/sZqg1TO0AdA3hVZi0R7jLiSGnGDi9ZGBvcC461K2p67bnshzGXhWqZuaxAj'
    'zLTY6ofrAK88+fd/S96rdovnR5Cory3wx//QHBX3Gm2wUjHq8D9cq/7Ez0HFTGwTFuYP15TTq+fN2TPFmy/BrGFEZ2lT/JaMhEzM'
    'M+qENswqMeGvUmWEzinVVPqNZFEQbpl3fxuQX3iKIG29AjOjFue4qXUOQjRmnsGw7biH8Oy0gNiwU1Q7oP0EujxzoIoUacU7+7yL'
    'sF9X0TidnIgaRWgOEc5Ei5KHezYc13AMNA3jcTq18eiXzhEdwB4q1KHmOnRYzaz6/T6kOnphGv50y0jhnumnoDYJaAN1VoKSZ0hK'
    'zvGMxG+Dsp3XLD7furBbHx3DoPHeZx+54/ZjMrL9FncXP9b6+j6eev4WaAfXQSKMYEMPlB2MVjO64fTr4OBHTJiYXW7IPlW96UV2'
    '+UR+rJYEllRZiwB0NYAF7/Be0Ebp/N7GOLt0NVFjaax1abzIJTG1azklWaXTlBzH7G6i0gBV2LzKliOnOjD/F03D0AKlMU0fCWAq'
    '6VN+BBPBEIodbcZSVQGbz+wK+qDZpakhUqXrMk33oZyYpiBi2hh3Yq77g/AoalFzdWIrLHantlh1/Ta5yz8LRWTAJD30St/+yHVO'
    '3Vcqaeh9xBXat6tQRxJtAdC+0ZkxA1z83dfSnieE7GBZzE0P0GjovGywhg8hQzB+FOHSJ11qWGwnGO89jxdkm0v22UfOCcIPoiHj'
    'iPFw+cfT7MP9McDYtkETG3uzYpY53qh70w3c7adHk8k3tZHYjkrkkfVB5OaY1zW7sKe0n02oqESXILhfhtyHqStXYxtWjaipKNu9'
    'R3XvST8cGC0xeDVZjtzcBrjSZ4eFQXhXOE0TRIdivqSMKHLn/R5NLS70wxkqT+X0d1Gc6hMhPeOx4szR7E16tf/TrP+j2UcQ+pkv'
    'NZUOD3pg/44GkRaMAR0Wq0WoUgQdjePep0U6ceDWTAGhSSJWC7iWxcIeFN2aQSH7kJ7PRczVSe+FWNSPZu6pG/G26WzstxeBAJ1E'
    'QzzQ5RJVgY/gFnOZu3ypNSMgxgf/JqpNPD79OJvHN0JPuCBen4iRs9fPTuixsWix8KArlFB6EOPZ+jVysgSTujBxcWG5uhd64reY'
    'hGzmQuuOhlDWxq9kbM47qAxZfYi5+PFap6Iy7Ld1vXolVMgWI824M9Vw6MqqtdipJcwMswzf1PUax761C6tKSa1+rG8DMepd5Vap'
    'P6jzatMHMFgzLegXbNva8o5c1rQohhwiBqXQxPUR+putHW+vaPb2V4Ho0AuU2gBSPtZQ1owZ3Q1GjNKDeDfwysPnoiKd0WHkxmXo'
    'dDr/9C6Zb3HNJVx9jP2PSbeD9E0DMpfijiPt9hR2vpa6gnM5JLLzQbz9IkPvZvRaSGHnAXWhiHY6kE07CMefkZrtsbNhGbVrNQRU'
    'DSRDwPta/EO1m6NyDnfcuee1F7sxUQAKrcsVwBS+xSrCXua5cChywyJPpyEiu6ZmvAkDuyUB7CDBvRBfd49C/0Aaq/V0qvcTffMg'
    '199l0/mNHa0ui4KS7pSJht0Oy/2pKNxhlUb9bVN0k+n97toCOw35OcD+xsCiabFrOSlg1wCfwGE679GGayNe1ga2WL6vNndGly+Y'
    '93EueWcSfrfLz/jQq1/oWZRULExctwaLbPY0SEZ3ONGCtLYuDnjT5WFnWIqx2rC1h1FrvHIvVMbMknHGW3E55AJZQa8eHka6VtJg'
    '9i5mQsrWjiD+Vj+DuqbmEfJJfg2yWNPptinq7t1+sEZdsUq1uHh2peitO5AqYA7c3LzE7eT3KWLwMs2zWIEkQwGmF1rS/+Wf/y91'
    'EqRhQWijCO3zdCIyfEnM2kFwcUM4YalR78wjjRTIbVlL7MHhIsve8FkVKwChbkiIhm9o1B4dfPfyzc9AaxjapkiPjrI5gxG2Fdht'
    'FkYt+tNHYUaHya9EKp9O5G+AegvgpqqFb549P3z6+ufXT3/39MmhMKnmo0dPnjx9dTj0thgf2SpMBujoNkLGahInUzicwukYUiZs'
    'sYVMzu+hnwS/1y/wgCa21uX/LbVq+EQFeSoDQAhS59TlJnSfoub9453wjaA6vhenwYzeDou6G9Y6JP+61KZKW2djSpPMrRgb5EHL'
    'X4ORJ2d1Z4Ff/vn/9byjTgYCdvhEsifibpTz2/WDgIjAPJvHHqTBV39RBqIqplPcQtOP59//LYH/b1Kl2sMjA1uci+Z+Gha1l4uF'
    'vkT+1XixLXsic7VP1RclzqAY3MHqLsZG1PL9DaijalPYGCYbuuUmGwgDAgiFj3lRdlmhqymWHdzbRvRIK1by4L7lAGfdRF1WXs4s'
    'pjCYUS82KKe+PIZvT5mQneMWryCoU6YQTkF618dM5so81vgK35diEdkCKikIya/gBpinEYivQYfqBcBbS5unt5B10KxOTxvfuEIp'
    'VvkB3bdWMEB/YaJ5i81d6K3lIvyYfNhO+i/6U03zTn8qfFsW8nlg7lRRiaugxBVL6A2fJZ1OyzI/mfXdvKnbPkR0BH3wJgnuVmzn'
    'XP79Nb2vRmfX8w/vsQLzqsgVi1xFRYy1+dqdIGEzjizp05ES2f6+3Rj5wk0PI/8oQHeqeh4gX2gAWtysv+hu/Tk2hOpSKoXQScub'
    'UoJFdSJ1/To6ph3/gvBXOJbWWr9VktsHn281KMpRTnO6HOZkmGF2GmS7dTPu0HNb8tq6Io2stvagmYXbd+NWIm5HPGJHxtmOkOdg'
    'jSxtR6cAeENod1BT5ZsO0l0zqpZUtUFfkOrp4qQtTnQ87dC8p2drNG/QUqBwT8+6xlJxtnvTMy9vTk3Ru9OSdPtC9JgcyScAlpdO'
    'p0xlIdx3NZe3s5bDgWkSRvMr8OfzOV3iMOUA1aNDvAh/WUrgKDB90RuPzNu9RG6G3iS76AW+q9OiOCt5xlqDjpU/evXq5z88fX3w'
    '7OULnNKfb33+m9GDrdHn8t+DL76S+UOBH159/ejw6c8/vH5ubn/01hkXq+WjuboG2/C2w/qGrq1tF/tzlM6e6fD9TzYd2cR+STxa'
    '/bMXB4ePnj//+eDw5eunreFt9+3l+8XxsZDwTt1WCUvoI/QyMEarz6OaVoMR1G2rfNSrR1OpXd7eGrmlE232bm2WhA2EE3tX0SYu'
    'fMZLmy44iDZ8Gnz9VshhVVxQH/9alnNazJlFActN1fwPVhKhAvXXq2SzSBrzA/scaeL18Tg0Ylupl5jbAD2oVnrQTGxyVDXk/Zw/'
    '/8rSLAtlv8guofvNRTiR7Sxijt8bCO4CvKc05K8h5M8KCYJwZ5VRPoGDPbzlZwX29EzPItFnaqs/k2YWNjMNAlhnV9eRbXIYvSqC'
    'YDFKL9J8ynCYffnmlmfbI1A2Ld7HGYy4NeK4l/Ts3dE/lcVsf/kQ61aFaEAuOJItLkpST4icQE49O+OrgFuHX8Y6kAcmWG/rMUC+'
    'QzLcl18qqLvadIWrdp7OVk5Sq5vzL/zg4gmuVJILRSHWuh6niMOoZTB39atZe+PHYtVDtN/MwYWCPGw4G4PYR7zl9ScuEJBDiJhc'
    '8miR6T3bDBa9/Y06LmS9oz6mTWsg+EHD7/kRnYHd+ouqUruY0sQxk6uR3+9xbabXRdv2Ii76bdFoFoQLDqDddWErPRgwwOgAUt1S'
    'R5CeN3IyX7lBtzqZ10u4E86zJPS3QUKL1cwIKBTyL0xLWFPfMDkpolLo+s6n+tiHPu2VokloCuYw0uNRkweZQAgs6mx6vJ1M3CwG'
    'gLVgOiueuYS3reJ0o/wH42kx9luiv37b15zTj04XSGtUjuCXu39BNnDRtfsHI7RUZZao0Fa6sJvSni+skClSVjpixVQzke90LX6M'
    'ut+ihXfoAMJRt8OEKMwBJ9X4eXq4fjQ9FLY4fNeJm7aVo2QkRnrpzITo3LqGVBmmR4d7v9SgHZOlg8TDo57ryknRFOSTBvhjxVki'
    '8tAxdPCWpge7tBVsQtfaTZPBjSRk72IBTGJpP6powOvd+lr3prYP/SCTST6Z/SQTAIOETF9tMAZAFV5Eyq77MYhlAC88y+YeTdmF'
    'XKTq/nBSEJSZ+PoafaGePczxhvKI+gCWIeIjR7eYttdaNpi4Nii7324ZdJ2ZJd1xloiudJ6XWX9Ry9i20EirKFi//azvbfY6z2+9'
    'xRsVZ+qVbuc3RoDz23sJv++Jrn/dew8sENmqZ/WQfjpOHFGhE8UWZNmvkml7/hnmG3Z82d2haKHn6bItC+nH7vPBAiaC3NmVSHnT'
    'PVkoXzhFMjQWNUVOHzoxK+owufzl7t3W2OhIb6hL8GZgPCXEpZdlK72ELhv+d6+c8OdZEXoz2QuRKI16PaY3Q+RrpVuJ1jdXXslB'
    'c67y/hsCXpXOvbsHr6RmQA35HsF+EuH5K24mF83Em5YcTmVndOZJNDIVO4rsMTQOxtHbUrG7pjkf9cx3b10PpM7yb9cBT9vBRD5e'
    'xlnYKYhUIB3VMV3nmLlbNt3KLUvtyLxdB3IuRmsXDQv2zFV4VxSeD4gBhwNOW2CUN+dWC0nJ7hNriFeiF8nN8WlQnWu508Y3RPRo'
    'ONCEd73WmRdF20Zfg7QQ7cZhHa3gum2WkxbzydKuvVuN6Mtsfn98dR9/hV+UJYRyGNPnC6A9HnkfsJEmvWS5tDzTIwiaZaHiHrwc'
    'ET16crpUpdOyES6KaYmmeEhkTr6QmqUKFSBFCThGzgHSe5llpUM2mGj6mKSfm3pShjFUWhGd/GZqnUnRzrGcRIpTWVbZNTMmjRkJ'
    'kWRY4pQXBAWzm8u0YL+Ns6Q8y4mgAi835Kw7zjJamrgFpX2KFCOab5arZS3r4+EPh53GFjf/MRqIdCm7IF2tlvsjfIctDr9VYXVf'
    'P33+8++f/ghzdIlLn329CqLqoinvXfur3EXfvd8dOy/LVU6/efiYwvfRIkbSc25Uu0PUiDJN5ARG7VQGXrnqxxFyOMGWPGJuJRPd'
    'LTW79548yydln2ES/cHbrXco6wJ02KQiN+kKHK8WZGe0NGQTBo2rnzRuTOBOiEXgmZ+li2nOotLWJQQcW6chA8YVObhEAnHv0xiE'
    '/6+WB5nmf4luLapuDpPxFmK7bTT8rbIVZDPSz0OdtP45p+hcUzzTLvW9c4bkNXhViws+2XuYfI4n0j1Yy3HNrkm58vJ1UTADEIAt'
    'MXWz5oyFtVQqHft06yueempp6/3DWu8B4noeEsPAjVPKvTotloWcEjCj5mUQyoduEgOj9wYB/W6Pg825HwAwZD9g8XJEoAE7t+xx'
    'ni9P4Vfeb87cbvLFIHnRx+uKsnuO+Rm4PrHlt43XeANlqberaDAsMEMYo2UewrOYnX9OPx300Ul1T9LFGK7eefFB5ifqKhdr3L1Y'
    'u7JWUcfHUcelzbc3VFEbhF7DYfh6mXJFo2yY/fnYLbDz4NVcuuSFzpXXJwMvjLWXMBr1gtwXysKevgKa0Vup7KO6sguveQME4XPq'
    '9PHh2RvqqS5D2zY28H53vnfIgGZ36sBJwI4L48cBiI3TU8CDmTBHWL7u5qWcMomhRPDsbj2VAF/uAkjme9URFR9EDgkRnSDDaT2D'
    'itlRVjt7Ron33y54a613wMKBIJR5HB7Z3zRaJYj6jvtURfDMN/aeIY/nGQIsIAElD7YShYkpq3aQKS3juEXoY8igh0H57ONKJLH/'
    '+Nfe4HposeJ6/ww5EZRbSUNadB8u+ea8b6nfl8Wc/XufXA+jNSbmNcUg7+DdA8I7rnrksbqTdKz3U0IhmRTqlFfVO7VLKaJJfL0M'
    'TjCd9lzkf2TKegYt1s2iTynX5+LhQnaS0totswZ7waC27r8DFg0ADILreLZCNEBvrUrUobsEsJnORX7EBRfGBESUkjKMgsvwHn/3'
    'bDzZ4x3f7iY+oj5lsGsW+Ym5DISJ28xnYKQ1HiBw6V5Yr02WIiVghJAugdvlqoFrOrYLmAgSspbJ+MpoV9dzaHAws2y70iFbDrwI'
    '1Gf9kcZ47phKoMekxkYj8hiT13XQxxtHwVXsgFviYTjTh+nY5gNXFarcKCU/1hYH1zBcA2zP9wIHHHYhNrBMcEwXzH3DlHmgbmyZ'
    '9nXtmsLWA/1B26ScI0zXFY9nxlDs182NH0zrtISEgonRKXHVhnNiAErgXUzJpvB98Zwwi+NJgTlbzZb5tLbpGd0iW0l4dVaNCJtp'
    'Dckjks4LhMIpa8EgQ711zZ1V8gOu36ZoFqAEyBMmrY+Nc952Gb6oL8O3oozI2HiA35IwH7s+g/OegvH6UWjPcuni5UwUB93BmFh5'
    'wBnzJWtkVRGxXxWdWASOL5rrAerBfF8WGlhMvqVleTsNytW21izAY3e6Q+rqHgjjoiaLVD6N6cimad3U80l1Jje8gI3PyHdvsTiU'
    'b8deGRjfINHWF/B7IJUalgYahUwLH+UMF9ywK9z2PPqhVNM11+OXv/yvX/7yv3/5y//55S//YguTwnkVrnMUhwiQWmUypXMNDq2K'
    'f1s6xwZvId+h/lHLgWpnTukPnVFyWGCV1UdfjyacQNgKdkUyxPPQruNLaaXbui4G3TwFOqU71AFcgfyBsvjBKcqr3rqABM+ciIqN'
    'cNbLLcqGyiObP403AuVzjULK4EG2rZqorCzPFWgI5suFiRV2tsiFXlQnQlgmVaK3UICGppG+IxhrSGyssa5G4RWyFWtHjjL7yNre'
    'MXtZdbY1n/EMnA0apKjatckCSOXYSYdjV/RX4x9YrpUi69lcazzjs4+m6V8HbJ5LL4NTAW4AGamMuCwFwwY/eVGAF1seySrckO3A'
    'n/neP9TaYPpRbglp42mELwnrjllHUGqWqdxZ1aWSjKtxkTF6OG/hFQYMRDMH0PN6esOkKabC3znZzfVQz1HpVmkc4q9iDKwmWgTs'
    'uUWBlPayLcCw7QjVIpUMeT9dLnmGLXVfwWxaHdvksenS533FSoHd+tWi+pRShGtdtcZp6iO6l7lu5XPhMRdSU/+R6FX38euAzNuP'
    'BstFTEbys5OpHCalrj/9njQJZ3II0c9XoVJTcCxTd8rJG3qiX6ScCwAtOj4h6uTRcnplOULR5mU6U6DtWSDcKkHco8Mv+oO5gnTt'
    'FVFvZcsDol4zJ5E7LgPf4cF8lDXEQVsdDKwlO/U6VqXe9J/IrPSlT2ZXri3yJ/1iHMqeKI9q7INDLBohpTu4EQqAF5mCjgukjr0Q'
    'URlFBtkLnjIUFW62jUm8Iv0vmJMyJMVZloIUFAiXqipV4clEUbHp8a33yN6+V+m5pRCA7qeCQdwBJap860wMosLCJl/jcm90F+G1'
    'YfAShh8ovTISWTxYAWBfpjMfu1ieBbfkrc2ZpqeX1tpXqv6hUmKNraFaXAa7ewbWmk5ly1rMeIKLtEsoeW5zIYIGTEk6y40HRVAB'
    'OI+Azqggv0sRlk9Ob8Nil+wfM3oFv6If25OAPBpE9oSyedlJZOWlglnceNbpjkypCqhObGK/LfQ8FepYWp7sy9NimnmlzqboZmb5'
    'bX6RBco27gfSxRn1mfsUu63JfuXzL7M18HnoIzYd4hWaTjKE3e+I+QOkTxMFREbswpzkbHOVHKcT5UVC68fLhMlxEDBxSegiE9JK'
    'n/9bWxS2qeCx6fJm+sf2fK19sjGVoSGFegJpbI5gJt2UNpt2CrghCRmJ6H8LAkIziyZ9fMMMGEvqtB0kcvy4YPDR8bNlKkuPTwew'
    '6kHjkIf5yYl+OjhN55Cdjr/JpwgXlSLFJSt4nZXZstO+yAunxYTpFk2HdMmpNT9H2cb9t0MyWk33dqf5HvSgpF9JNI/16HIEgt6H'
    'j5/Z491NeddVJR91zR798j//RaFD+O0ePoNeSh079u+YY+eQ6nVQZRnvlZgTLm1/ngM9e1x8EA16Os3nUKWlDh7zBEJUQ6a+h+sQ'
    'vMZqdzdlfIGyAqTQGVmyKJoj66DOsfSRJOM3EclFaFlhl7v0vubhxql0WeaRz25k88fPzMmhnzBA/Yg+N+jrlYKQ1xmQu69rUlsu'
    'OnRIPPkBkbB/lb/ONEtDu/JvXJe6P7ru4c8jfb9iXzpp1ju4yMAOq8ip3O+6ZhWt/MGRkpaBMMQiMAgg94nn5Sp6Nq1XoGDMGrd1'
    'ZdDROxXloNoZR1UVqa0TLwv/mlQHpraf0IBKs7bzHb79sufnJ40lpGdht5Rij1uXBYnpvW1dNrUaPnm/awQ6rAVhhaujNQtJB+sQ'
    '2M8GLVOscGzMJGPWeaRThaox5PVyOaSxRKGRS8t6amYfo9RR8oZhXl7OMc3xyPBdLVHNLQw4FQacSgN2GaK/AGtnlHCIlArM62mi'
    't+eQbLIP84In2Bvh8SCH7+UwhAOes5x3LaumQn7JgNm2C8uZodZRYNV0UT4uaPftP+69+/UeY4N8aFDLqSFbrDKaXaZX3fThMgLf'
    'Ups2q1cZ2+RCsvAVxpSx6ahCNDaiNJSqLNWUlaEui7QHCDm6XYA4Ib+d45pGAQGxIsvVEVwLMLoapemtgLFq1uOUy9UMLZOYT+SA'
    'DldoXsC/ZFmlPmkui8+NgTSbinlVueFctxzvVoS+Wmtqqy/fAaLu2H9Kpd1r91wer1E76muHhDzyzdufB7Z1ilg8R62hbF5G3cGt'
    '2cTcB3JpDqdoMYWG5u6NRBUpkPkTk27LKYVo9Sj1Nz1JgVpv6QZoHpFFW7Nr7ZyHByk9FwIRFp09yaEmqShmlzpmJ/C6qsptiDC6'
    'PcNlVbJ+pqaeaXC13os5uLra6ml+cdwoXjpz5volPOtYvueEmwRCWb26IQZK56FJDmckqLRuPzISlo6DBEnkdrHwk9o2qZGHEYMP'
    'HFZuKCvHWF+cXWakATwZLAmyyMX5faYDOyoWM16GNMw6ovzFmhwHjNPcuLbbqtFLa0wHBsIZrYiPrxxU8MiN7bj2hWTPV926GTUq'
    '+eadKJJQTWWz/rt7QnoeO/cn7qm0VFvQviaIstjq2HfAFg1sae0wQleVyvn+LZBs30WuN8MEjkYMTIWw82xy7171jgv/jEKeGT6H'
    'bQ5TzXaS0iizLLaD+wdmmZZ69/cTfE+ud6JI5sQtSp3QlV9XceXxNe4h7cJ2trdzKGx+MnXymITyS7UzLIgZEeORZgw5pyEI6qaj'
    '1SS9opnfuddZAJdopxh3sd16h+Ai4xvR69QjwjvzQdRxi62n/9tuvlfF1e9u5ns33RY0TNpqCirD2xJ0q4vtGUkxBDkiKnLCKZMB'
    'aSg4NInpSO90+FEz2vEjNVj9yMG03DktKD/MKOu3uz6McSXewQ9fzjKFxvRaRAl+L8dHBRU85Ko6Rxwzl9H3gM5ryNMzSp4E7Ki6'
    'gidPwiV2eqsr7DUmkjywyKgWaHZeru8oqWiMzN2ZpPQisqLbalTr+KHCJ3u3gzUM0JVovyX0VdVlSd5N+2MsWCo86ViqR1SSqzcV'
    '1nRawFhgx4cIysPAzCPHcun0A+xLnlswjcsZBMxuCNXqeROvHzshrACr5XYT8+LwKrB7ofypVDNw266dFaFuEbmA611f8jWuMtIk'
    'GGTb8Uc7lbvOuK3YkZcYlTksdt6bUciv3LvitbnZJn2DTbaS6mUl2VRFjvRQUB/lypdBRXrqP0v1U3ZihdlNrkQxo7HjRC2u3JCn'
    'UvBKTpxxU1mcVe0/ZYZAzFO7Gc754QfObjSsrObrWKeNK/S7YA6e0ow+4VW96SGBhfKkKCamKv9xxfNLGifWxc3GPszVNndb81KO'
    'zxhE0rQG/gNgXsiXiP8S7sW8y4D32UfvzywjfgXEGKcNATVm6K7mFDrGZahpgY+hK7QUPKgKOuQZSqj0XBhWN32NCvBK79q7Aejd'
    'Yve62/7OlzVFcsuZeuAtsHCOjaoPOE+K6i7Or0g7ERhGyCy4qvQ+gIHrgk4OrlurWg3ttpMxswyEptFIP1+3K4nB0mOsSg+YoUmH'
    'YsqEHem47CuySrJpjcnH+8mDgbDyrdHWVziJWfL0al4s+4bbct+V/TBMDKfF/3SFV7/cGrjmK9W21YExzLES0qLID0z4sE7W4yUo'
    'D1nvKql5hRF/QGAIIaEfDPe3wg3f44abIWDJCU+0ofkgPrtkcGjt3d6Fa0jijd2Wpq6aNAwSVJd+DfxDcxBIKFviS/uJHdl+7kK8'
    '0sjquqKRXigb7za+jqUM3R8MW9BbYfngUdnJAujEJkVqW+nAbSVle5EzEu/cW4DJHQuMoqdoTTHHWDAAAs24kIZgqj/7aNHh7mpB'
    'u6b5LFv8Z5UowHzhazON008pr/FJsSwP0Gl2Dn9NWzsnWxFhhKY09cgFxnu87IwGZTxEXurdYRUPGuTgigNCUzU7TphSCg4ZCFai'
    'ITJfonEQ84VyFwV1F1aSHrsLoet2AvyRziCoiVfFEEpSR+l1p+wokM0blW9xBJWkhjoNPqVNsyFN6M+3Fya0fGRDyjJVplxfqeua'
    'w7IL3mm5MiIJvnrxrTP/mv1oaVgbX/7HvyaaihPkp/b9BW8lq20EDwo1KS6Rxtg8AMJjKb4aks5Jm2bDVaWudFZeF8IuCh7iKtDq'
    't0UB6+XXxRE83IrBMLADLyyqX32h2QtSsIq5GlMFVcAZl1uuk2J3ZwAD6J1j7r1PDY5CDs05cwwr+NqVor2Vy+wWxMB76qxa5KZP'
    'EO95i0m2nj0ZdmvnRSKpowPAtVzNKGGcFwiV8LxA/QHgXpMtL6XDtsoMzHSdGiW4c8tN+DBvBxUBVO2SM+D4VrewSw6gPnwH/AEO'
    'VGbLja4B0iWwkkHvIl845AT1paJvk6a0bqP0mkNrOplUTk/DpnOyPS/VM7lihSq6Qo2lVwWCO8AR81nbDagdDD4bdYMFq41PuTDv'
    'Z0yldvmsPaRnd+3tgRHOC38Zha/wGGm7U3WeLDxXuhhh4FBA9zl4uvBwqkD2aRHW42RaLOkjcJylvFfyiklIJjDOKZ2DJN6FQYUh'
    'yPGtkgjcHiNED5XqW2WQE53zVcZMjAGeiOalHU/T2ZkC4U4VQaBCGGzgCoKMmcSWmHU7IUJvFeGEeZIRIoywvxUj4oWP8iiJ85I5'
    'eH1809vcYyUy9hKuS4uBDFBOawdaIA/sd8ZVMd5TJN0hK6PFdbbNVT3IlrBc6t41XC6+qGBBimS4JsbXB44OkwMm6ZW+1wPvGRIv'
    '7YIpTAZVVCMnhL9j4fdH6HWAdHR8jl6fqvau6lYFaMrc1z5N2BKAXR1YNvKM+WIbsfdsmqZiYZWO7EAZc7p2Qp7BYsiey5N7yQPL'
    'JuaXwVl5RD+4fo/8e6zPR+Ui5VTffRv4HHy+TwqvQAugWfweJv0HW1vJr5Nc1I9+WzsDprr/u15QzSHYafvQyGnDogpAEMKlyhRr'
    'tw2IIij9NdJSD5pQKb77AMiqHuc8eraCEk8/iGxQay+c8vdRQhrZRQ83jKVYkiv7VmWYaZRHmqS91jRIPjuaBXpq8KL17AUnYkcR'
    'S15nf1zlCwTxMrRXIYKqcOptjb8vZiLyrGaICCk10I6mDLqbltw98MizpWesr/odA7dkxqjUbtL7vWfAmPJkO2kQ0oH0BQ9skuWn'
    'jecZDsaTYgMj5YB2XFMBSMvdu6yL0YC4MY1q9i84UKr4bQDOFdUwmRUJB+CR6PDwxun5OeZ7lKmAwjgSpi/SW783X+TnSPQ6TKpe'
    'fDJy8kjW6/6JqGTA0cymQTOa0EDkC19gJ+Q1hugtow6/MkTMfKwHn9KRoJJ6RxD2XuuFfHsupMK3Yi7PLQtkpOp0A3eGk6OwbC4U'
    'YpnxpZq0MDGMewATRsAyXU3VW3xUf5UNVJtZxz6ptobuep6A8RyIdkOc4xohv+29EIHhLmKO8So/fFvghoYfX2WLY3n9bu/dW7Se'
    'J3+XfPlOa+9k1i9awX08icelmoBEtVoc3lrLu7UVdOT6NyfRKnst58QtDU9d8IY6puLH6qhXBpAPYmEBpxMduJMHvzGoRRzPkGwv'
    'RJAykiMQo6IYvGEoeOr5l7fEussddUU0/AtY6JweTkw04TuL7ErDWdWo7ZgmrYwI/yuLO4bB5gVRX+gyhcRkbibUV0dJ/wdGcTAo'
    'GB+mlzBYEXlqEMR3P3n54vD1y+cI8e7By4l3AuD4w8S+6l2D/8rUI8PEGdDCq+SdaFNW2zWQvAoIem+Dra/y04g2oiG0M3QbxqPX'
    '0uveuygfLHlPjeNYbjR59VOpLBy9h413iT9nKwDbTitI25HBwFRQeBaPK22k+gLmtqz8yul9YOerrHVQPQfLHVadWsiHUTVXnNFL'
    'u896EY4Lf18A5+bFqjRIOgv33B9ZJkG85KEhWw4PbJni+BiHh3XAQOsDXioyQIu28EkysZPiP3m/o2/rtjufd4injvv+LZlMi8iu'
    'BWOpPRbVDWvJscgA7UeRlJERRZPJHSqGMiCaHai1P3xAIT7fVLRGOxHf0hPBeJfDG3Ki5e3bblZ5v1FlI0tOBRfV6HqYQE/ErNSi'
    'Kx0f2/9p9tOM4f74lddUGZNl0DoEeps5VIggWsThHKhR12MjeMCD/Racgw2sdDR9d8IxqXzdmKcINqQL7FqqDbCu745DMaHWpBYZ'
    'e9hOJjgHTzPxvDcI8v4ZlHmcZKwF0knno4Hn9A3jGxYrbBK7LU70vqJuMr6CdcxcP8JDxoJRyedmdg/tsDbuaKpxaeL1KhA8dKcE'
    'v7dDy9VRkaBC681Se3m3vVq15tbKmghZd5jMHrrvoJGoxXXcbATS798dvHyB+Ksy66/pkUtbRcmYKU3KgZk71HEw/1PWL+Nu4PH+'
    'fmUPYb9w6SLjge2lHCH3JuKJBry8/1MGnmVA73caaaaGicOAV7sItzDuv1A1FmmRlcIHDwMOrWMNf28dYgdf8ymDsMBcsXSF++kJ'
    '7qVgsxnUbU87dzxgcdWoiw1oqwE/Vhaae/6ld7GsVj1wh7NTp4KQRJoG5QCp+sAbno6OWwqsvquQIwlwwPSaZFskr5N85izbuB2a'
    'y8zdCXDSd+7sbmr6nT35hIw++Aug1b07/x/vqV56'
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.10.20.2135'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = ''        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def do_POST(self):
        global last_seen
        if not self.host_ok() or self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': VERSION, 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        while True:
            time.sleep(15)
            if time.time() - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. Everything stops by itself about '
          f'{IDLE_EXIT // 60} minutes after you close the browser tab.')
    if browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
