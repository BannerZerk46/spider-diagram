#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrsvdmy40iWGPheX4G+ZaWMaF6S2JfIzJC483K/3ElJDyABkiBB7OBWkpme2vSo6Rmz+QP9wrzP/El9yRx3ACTA5S6RUd0tM0Vm'
    'BAGHw/24+9nPccdv/6CYc+9oqcTK2+rf//Qb+iF02Vj+/qQaT6hAlRX42aqeTMxXsuOq3u9PvrdIi09RsSFv1d+fdpq6t0zHeyLm'
    'puGpBlTba4q3+l1Rd9pcTeObZ0IzNE+T9bQ7l3X1dwo14mmern7vWZqiOkRRk5eOvP0tG5T+6bd/SKeJvjwjNGj2G/434+6Wz4S3'
    'UgkXeiZkx9ubzoaQXVwmW1ZQi0in4XVdMzaEo+q/P6HCJwINFq638lLNQjupw1Z/IlaOuvj9SZE9+VviyfNfmAJcEnBpuL//haZX'
    'nmd9y2b3+31mz2RMZ5mlSZJE1eEhgaYgbx5QRZIgCZ6F/+H6L0wJ2lHUhRtcAUiq7FQcWdFgmghNQS94mq6iNg4Ufh1dHi+XB/pS'
    'ii+pc7uuZ1qEuVighYnqoLL03NRNBxX9hWbYuagsFnCdvfsSdfclmuMZdXZ5KZsEPCy8jMtR5x6BR09jQM9XAR7AFY+hW6nacuVd'
    '7h38DoWmilhouo7ufEf/AiCgWfl6gWBJeI5suAvT2eI5Qze67KlfKJqg6Az3lcBo9YXK8DwvfI03aJiGGozSMTdqOMIFnpOwLH0G'
    'k85QsWI06rlsoQeO6RvK1aO1qRnxZwGkc82Z6yoxD4aGZ2F+vFzjKWYuA3tYnclw5/owqgdvBKsevCF9oD4lBM2GIEkf6oT/gXfY'
    'd+GyZG9FYApowiJKQy5DNSk2IxIUmZF0JiOkqQzTpBhUwmZYnYYLuGnCYzooSUdFEiqBtwguwxFSvJPsMvxFhMqUngK24mKOk16Z'
    'rodZhTt3NMv7/ieCyGaJnGXpR8xQ4C9wmZkKWKcCOjmuR1iyZnjfgK1s1e1MdVQFWKMJTO6ZUHVXDVjT0fXULQEE5mnGMgONes6R'
    '+CsB/NbfAvVkoouSrgb3wH2gdibo7ndCNwGVe57pAD/KLFXvBZr78ksIsxJwyW+48i9foXWC+C//hfiylb35qqnC4y+/fLGAq6mO'
    'G9A0MFxU9xuhyM7m6y9fM7iq6hL/nvgFFf1CfCN+0RFh/vL1V+K/QotzVOEzEIevo7d/y0aT+ZvrHREfJ4hvjml6xF8xrOn0bPmN'
    '+POCXTDq4le4tWRD1VEJ/oNKgG/DPbUAPiSi+63vqQqU8DOBFslfw2YQBUKhyqiUIqNq8nyuorX5c8C9UNHK3KkOaptakOoclTjm'
    'nkYFs4W8EKOmXA9mOioVUDXFRA0pksLP8WumEYCtimoIJJSEEMyk+Tx4C8pC2BVWVc7Nw6LAYiaGGBTdjNQzZde7LQnrha+Hra4C'
    'RFzO5C80xz1HfzPSVzxnquGn3ZWsmPtvIJAo0joQDPoHv0A+o/8yFPc1aC2JJ3gx0YP/Gq3df0QLnsarjYSls3n6z8nlpCgK2Hh8'
    'OSmZmtPkZTlVVuVUKb6cEi2JMnO1nLTKUIyYWM5AgsWXk+ZokVZjy0nxlEjNrpeTYimOEi/LSc+gdS6+nJRCyyybXE6G5UhhkVhO'
    'WGDyMvHn5YQ14un5zXJeRhot51VJtOzBnN1ZTv6ZFp8ZGtaS/vhicvcXE61WtJb/CDQ9Mw9pVzsBZ/oG1w5iKVAU0P1/XGmKohr/'
    'GZG+5lq6fPxGIOlJ/IO2RQqebHhBxYw2hzpYan4jKN6C9wPRHt0tdPUQvPsrlsPRdSA9vxFz33FgdQsI1F8TUvgbQf96JX9hWpCE'
    '/fVa9p7LASs8DXhmWgbUheI0Y4UjmvmeZxrx8WgGej2NAPyVwPXTGvBXF2ACgFSAZu27nrY4pkNl9vJgiUDhrpqGqcjAVO9i88Em'
    '5gPfbWVniQAmMWzoh47aQXr3MyyFgmTEuV6sAZL8S9gjroPXeCbPN0s8+m/ETna+IDIEVMFLH5UAlkERIpmFjhAnWNwARxamEcKW'
    'pTIskQbVWVfTgeR6JvJIdW7K8x6+L0PdZ+Kppy5NlRi8PD0TXXNmeiaUVVV9p6KpJ1qqr8KTnAMa/jNo54abdlVHC4nmPPvBtKN/'
    'QZAhrVFDqj2A7W+NCEuR3QHmwF/vDBIzFxjUGXFhCbYwDphS19Q1JayGVjgUZRngEPHljwGwd9B6on8fIAJeb5giAi+hJSsKphrA'
    'AEyCsQ5SUT8hYKBPP4TqdlSIiYXghmNfUdAWWiNEqkAuFJdEIhHjEEYhXGsf4opAAuLsVzAOUHHkuYrILhggavzPIMaRxfaQHLaa'
    'EREheYVMmGl//TUBFJ0EisVA8UHh4UzNJJ6qu0ABF3BRF5568M6LimwM3w0J7TzpdLQM8YE84ldXw80YW6hxQwi42/SlWNV1zXI1'
    '93oekm0pSJNJ8LcQxrSuLrxvIZCA89l/xNqgb7jyTlXSYEEbS1C60PsgoI4u2IyuNgN9eWXuVQAC1D5jiV/BHf1jNtbtNyz5oN87'
    'BH6LT7hyiFCaYfleBnhtsO4B3WvGCmjTu7OayUW7u7aJJcElwcLdInwgwb/eX9nHxH2PifleIJ0vq5tBL1tXS3FF5o+pmomNJO0E'
    'xMNfhhwVUZfhxYoe8hoM0jcdifj5StOVC0MIXw6xKYPpwDkDT4XFoLdcr/FDukvQPY/oHqPz2Ur+RviWpTpz0NN/JXSwRQAK1C1e'
    'ugzJqtvrwdJJyQZcXNWRXf/XmMQ4Y86HEDHJrh/NXSDQkigiJDANYZ+ESiKGYYH0x4t5l63E5wotdChXgmEFpPTNML0v3wBdZKBA'
    '5etdYRMno/Dd6IVobs4FiL+gyfUA9zLsBVBFXci+7sUbyWB95LY7rJNeiCUxwaF2ek0cgYKaADFjORos6/FuF2eCDFv5M7ZG7nV4'
    'rnmLZrd9nblTvMfIBorXR344pORc2CtD3iy0cJas7j60QyOuRMcVq+Du/Cp5y2aQ3hShHn2FehfUPMQ0a/QfQtJb0g5gCdfu5h36'
    '/M5lPXR5pupINZxvbhWQx5yJOxN3DIM/iPiXbt2trOsf5iVYwmGrKSR2y3S1QDVzVF32tJ3664VVJaXjrViNYF06cmiSXfAiiWW4'
    'y683dbAjFrqGdQSdfhk6Hb8E74D8/IrW6DlwCFoysiNQwW07wRARngTIEvKBYKQZwAADMAdNUgzgGRTFJySjOKZlBfXOUgip8Irs'
    'rtQbSRdWSQcOVrBE+PP8zmVjJ7sxMwHr9Ukt/4wlM92cb4Clm/58Ba0HaxHION9FnDxgP3FtJ2w/Y5iKGhvUGWNwpcBQvVlleQa0'
    'AdjxK6x3MGtBww90ptDMCvE2xr9v6eyRDhAo0Em5/sCyCWC+5n0Xk/uGinm04OwjXwfG/oW81fRjTJ4l6Mly1HRAUdEEhMaCbBz3'
    '8ALMzAl6VhBB0Ge0Qha8+8bUBvphQHFnywXfRapFwNGCBUuDTgjtxafmPSMG8w+McB8i+wTcGXhFly0XUBomwXigUQdDPBvV16DK'
    'vmfGWDIiE/GandEP4bsjgTWMOrGuQ9geVn1b07hGwqQ+y8SFz2amnNVlEHsEhVr0tfTWNEyMJc/E+fKuNoSBxu6eN1AisBOxyRBg'
    'B5ZZMR3uEudIw6NnIi0iRnfRNchHRIN7vqaZs/fpa2zYAjJn2biiG86OeE8S4e4wVOFgQlCIDO0+XyBHtw9Q+UI6zBkFPf92lhba'
    'QVXOtEGTcbIJ7s4NseTZcmF5MjJAI9Y6l/X5F+CvuxWRJhg6mMAzY8M4+wknRUBlVFJvoTDLQR45Sowm6VMGzufwNuIhF6YXUtLF'
    'T3hF71wG6xVYNp1FToaLFuA/bFHgAAURznY7j0xApBgHixNxLzLOrxJrEtyFbwecIL4KLL9bxWeMPqNdHM7QekZ99lEU+MoNIgaP'
    'A2PJ99LIXfJB5epdlsjct6qSfV1YX8wKviwfmeRiAb7f7fnc7ExGmnM0S/wdOqTvm8uReXIroxNta/H5CdWKpNLxhp0QJ3S8skDX'
    'nPvrmWijNYocBTR2E5CJiaWpswqE3gD9gbDink74T7ip4ev3qiQ9LTR585qunV87OweZm1oZT7M+ohuzN29epEICay5Y/Z5LJEnP'
    'AYhnT9mdtefeXvvzShvy7oKbN47DJK/n48NqwbAeWLHcRZUHaxmUPkAyxJHPnYKSm3iDScQJ7jH/RIWFpntqoHYfw+D916v5nmV8'
    'LRpQgiofT8nnOGlyesjg/rEDFeAqomF8wp6L62N/pniZYeVHbOZhqC3Wb9QSKyuqSF5hwGfBisZUOgCh376drIh7WerYzX3W2x+o'
    '+4l1vraJMJ7LBlh5AWOBdiuoWSrDuoQquyrIxDS8BMr5AuUMhcrnf9iox4Ujb1X3/MZfkb50AScyLmOGYSQt/ozN4tJ71k9Mq39T'
    'C4N/v147SxNOjEAYPjKWYmolUjqT7tgb0+QNs+ehrfRDNpkkSbdG2XtqRqTC+RYgrpqXnXfVXfoD6u74SzjHFx3v1x8L4rwdzTtr'
    'awkWKQaWwH21ONR6fp52F67Vx5U5JqZoIRUrHFoi7BIpvX8BnRfZwueFyqzMLaIw1ws8RJGQxQoZVmHJuEDDOi0dYnQ4IR9mMpGC'
    'eDt/DzTkpA/0dsIe+EGDWU5MUeYcp00OOBG5DjSIs0ORvDFNz5RypyGAfP9MZPAyoeAfLrh26QcWYMZdBWwzEpXUm+yFjMTgVtaM'
    'eItXE48ccRHwUZwKJLXqvuHFi8ykYLAxVx4tkleRO4Hc7X/9eOiWeD9eG9oQj6jgMoAu9kJhD8MjP0oaoyLmKOTFCLkYgmLcbQpQ'
    'pgPPVoyjcOGy4h4/Y0qcOccdOvlMbDoY69nOiVb5NqL7idDlQ90lHKZnmrr7gYB4FPuOjVH85BDfDHQnwLm1qtjIdXQTK7h5OYpS'
    'JV++6De4bj5IrzjP8ZX9H1tINjLir+XgjVZ9bUxzb7gLk5D8x5BjI2mNFO/fnxay7qooqeqxtXh5/Zu6tYCLfAsTE/9KnGWb7HnO'
    'F6xAwuLO1ZWpK+qN5zRq9L535mrOrk018c68ruik0UEngsfYN0LeXZAVc2WtCIkXg6Aze+dFX3+O35r6PSivrMV77Wjb5R3zOMYD'
    'k076yKsRdCQGsvKeT/GqG7zIl2Bw5GrFfAlf/ZoMCiR6iMdoYk2uEjPgXWLND+nxjON8RFzXeVPATRMUx5J3e77rgA1pO67yoom/'
    'eR3Pse3DfWzNxCu1g71mNcEaMo8U2Q8QDXLqv9GjeFba763nw+E+CBuE6VUMTq/iHvuNr0CUr+k/oX/ECceJLfcFB99KO0pSVYKP'
    'LnB2bhI/YkkG7zvu3+89cOGb26RMD128oFKpgQpzcQ2TH9U8HqXCXTS2wMP24xlgV5I+0pN//Tn5aWcQb3K+hGQKDlYxsHPtroz/'
    'nOJy03VSL74TaH9DL44pUN/Dhh4TJOq0p8oODuzfiynTweS+kanEva2WnM3ZjzjiPp5HeZuCFBvLt4U5990Ei78zW7eJA4ijBfm6'
    'W+3wBbR911nOnq+cKTT3l0S0O4E6Cyzj3Tj9vomiIeP6GIZ+SEvECHUX326M1luwM8HF5zJ0L46pa50v5nz5nCMw9H08JunHoN9q'
    'r2TSCfzJqECyEyOQlPed1Wg9ZjIo/vE04aABsFI9P4kWZMzC/1g4JG5hUleMY+loysdVatwvnXQfoBYiTwF/QaKzNgtDcLzAtERV'
    '04AEFjKT0wHrd5Fda6my9wV1mEZp5s8IYlDfvtAciVJEqIXzNZrWuewoCelzMYo/KGkep7qckyxu1J8PGcafi/vFU57ezcq7idde'
    'eBCRobhkzJaKYjt4soK0rufwBjO4dJSz+td3HVb3/BuTL+kw/HonnxP1kgn3BXyekV6ytpKyCa96xlv52xk0KrsWLCrMJ8wFQjoi'
    'C1Tx63v5ST8jN+k2LymwNNnPuQwS40H7U2+tlzfSi2IthPsN7jn66Ds+vjeD4Yx1uJczHcEaj+Mm3Bo3Mv2n+DmCXvH25I/mv/3E'
    'fl1DsyzVu4QhsVaclFVn++tTpsYN1Ff+B5a7SmOAyZ5tNC/Y3hPdBHESXd6idfs1XidtOhpmu5FV+DC0HGKQrCwfuejwoMWLn1+8'
    'SRy/N/5QBscHSt3f4vDR1NYYuI66U2X9LXj5WGrDg8ygGwEZS8S5nxVzj6VGwCRZ617zVqAAXgCNe4svHNJQkSf5c6GOuBgPo1Xh'
    '1OMtmt/CZMYPaAXc/SSJq0jhGdCEVcEk9kUFd8mdX1SGj2sY2M0F72PhH3AcqAM8O03FNT/yrO3eibc91rOAPjfXOcuLhUryfCxe'
    'G+7DvJeREdP2zhkOQTQAMYUHmkaQS6wivn3xsEaFaRykvEyYQH44l+/S8H1f6mVtdCO2Ismde4HJ/9ndepnH+/WiDjOoUSQCcNv3'
    'WkuYVUHiLdqDBvA/X90/THSdO6YLOoHmxJbirUTXc9wEE/8lXpZCkxWPPFKXoALDnYNXfyRbjH4/R+yTiiH5gYSwKACICt/eORWg'
    'savOH/hNHo1TTNIBaiCVaOwDnqLIaxvUIZMtfkyXYJIvGUlfI/kpkjqH9z6bW3FjKyebi0j9c/sCfgTwO3HJ37Lh1vzfsuEhL0gd'
    'RDv2QaMMzsJ4Ip+i0zrQJa7/+9OZkCI6eiJkR5PTATb9/uQ5vvqEdvz/5h63M1NHJ5w8aWndXJpP5zNSnvCOCRb+f/r+2+XMiCeK'
    'fkIHRuBf5/cn5il79zGT4fBzEBZXNWgyqCE9eI7Ovgi7kB42wn+gDnunn/A0i6effpYFajwbTOftzCI5+WBmLwBxBE3t0qJMgfDE'
    '1lKaSlOrNBsvIKidmBgGA0DINEEH1hWBR8DpQpqPFdIZniB1geBzsTJoitxJl1ppuKpy8fs0fXpzUMAOzfcGJcGsESwh6VyaS8AN'
    'ZSuYPk5G04f+BmChDO4qRb3Zr6O+2+8WJhM6hk7T1x3TJCFVpauOybBj5s2O0f5xBx1R9HbfPCERPPov/TZSWLrvvjd/MAx6RbEI'
    'W7kdxb7Z3uFdDBMxXJTYhB8dn8jzZoOub3yaHbDXREbv8LkxNAm/bEZiCPSPDnYQhYwhID8hwwNM6N9YKYJtRaPFwr98hmHDOunY'
    'q1KGFIL2LqVvjmhrvrt8CFhGRvMUoIUU/oewk0pLaWn6Zg/Yyf4RUq9eKJREtLejYgXwC8tOxwvS9FCYJicXmt2xVy8BqsBsMlUR'
    '/wroFyG8+CbQ2FvyAOjwzCjg88QR/xsKHkq8SB507SDOfsWApTgDpuPAbxH/4dJMhkJ/4zMB7JVs8MCf3uYBsmbMzP17E00DHgky'
    'haIyUfvwDyIEKD6vcRqWnETTCYUXSFiCfBOEwPX7LgRQRl6toxgfb5pepYVMnBGDpJLSGakBQgUkjZS7vCwg+mGq7DXmMEkkmH4A'
    '7rRpqR/gZGhSMhysihSTHSD6oJis0nHJQ2UkeB1kDxJALMEnBiRxqJkY4Fi8DLm4kIKJYOLzgMxMCaRyRkSXcVqABzATVUqMv44Y'
    'zZvj3qjHmQkW7zt4TmM8Z894Tsc0LIqP4fl5iXlCXGVIChFaeMFGF2J4ISI2hkvo8xUfXQkExYMsfBN4ZFW9y1VQnqoMQu2MLRwL'
    '/+tMOlYKuEYK+B+0UAKAkxGoa7ZCUYkXODaN2kkD7iWaB+aLG0JNpKN23lAXPjCILSVmRBYdFUcjlBFo3O474DdBjYNJhEuMfQJF'
    'JF+6ByosCb1jQM6IKwavhQR3lISWgnlnJVzvvZVgCB6vLBMtMVxEiABLzQT4EPyKK+r9DtPYIFOVD6AAtI9REXUQXIjogkUPdmwT'
    'ES4SqFBcZedIo6QRD0kzLtI2Eamn315GRdtpH+B7eOigaQAF6Gwa6YCBZAIBDpdp+O9tVUtXZSeN4hLyu7PNEsKQXVE8LCDIVXLF'
    'gwIP/cECk0jSUpwOmIBVCUAPuHyzY7h6d5Yx5UoyGlSktYpV4aymU2gmgbed71HJSkjWf1see2Bgzt9dbIlgV2kJ6wFklUNjBa0a'
    'rt/T2lUHGfHvj5Ld8TFFCAnJIUIgmGKKf09Rnm8+IBmRpkwBJYc6+mPzSdWtT2uiAUe9WCIZEtQ4GXhYuAhcRgQknSORDIXoL+bO'
    'AqLTN6HxHNldfYQFAPrDGvGgt1+ZWcKVHOQRXxiyV9KQvRZvmJqpHR+w6B3/nsRQ36ccSpqzwAO4NAixtOAC/aDf+3Y0FRnS3AOD'
    'nos/f2xVeI62ed8aBvSrXpYLK4YM4iFIOFyRHo8GQl8j5W/oLMnwfFzVwXAA7yLmuuy6vz85oDx+x869eCk+GSYshyehkxbBPati'
    'Ez6sF55Ui9xcvz/ldJ04mr5DhGc+ujAO5KE5173rffnNd9XwWNs/hw4CDD3A/Fs26PgMB95OjaAIzxk6d10I47ALTUdNZlHFcFRZ'
    'GNanBthS9+d24ToazdN3uLmBKP5iG2uS4ZvohpDR0Tn4sGAEGPGl4Dl6qv2V+Nt/+78IE+bJkZcE2idlGp6Jj1IKfMVP39Hbf/tv'
    '//PN7nry7jIB6CZsv/f16Tu6ffflnJt8HWCQCRQGiQHbW2kL79wkIbs3UD2Y4ODIILQWj+efOIcf7q9EeMJyE2pFqCO7lmn5Vog8'
    'QaF6gNVWVCVKSz4PKjjR1CVAfOLZ3a9MGNh5PcPmiSSSEsi78QFMjZwgD5EVjRbjanwUYTdbfBM0H72QnKDIC/10eXynAh7p0/eG'
    'DHTnxaY6rB54bcMXQmEUTk5XTcuOg874wlMTAolzYdBGt7ms60dCXniAu9A2ISvKM4Hyv1E+6E59PqcCYzxWddUD5CBm/myGCRAf'
    '4xWeYI37nZmHJzwbbg56ePpOoB8AXzn+lsVQJuC2EoNEroSn73VVtdywB5dASeAAIMYygGyOcgn2GoCjGXg8WE/EkG+B6+GTcTO/'
    'Za03J/PCCs9V4thYCEfcBJP7Qjll0JMQNM6RwNtfgNplQjH3BiInzXMJdBnNC658ruZeo8wbnQJvvdflDFZwvnomQEvcoWATCqkG'
    'h/oGAQ837DOop36kxxKmpnh/A2Nx3ePT96AaAWhyr80rVLy+/VE87yG3/qfQPB/ii7eSPWKFWFg0FUDhcAMDe4a6aG8DgcYTZvrA'
    'KqGtCis0rfrxbYQubS2YD6IKpjE+ifY89/cw+w1QS/J8FUL3i4tDJyBKF4C9bsCZXXOBznN2PWjAM/dgwbsYwVRDcd+GsAyNAITo'
    'J2wXRo+P77vgxS2oHyCP4KVojn8Lt7bgPkeIq0dDq5p75EZQz+S7VL3onGoUBMchJzcQg4EIwlrb999MC80ksZN1H5oxgGMhIFr4'
    '97ds8PS6Fjobwgf23sS/j2ohcJ6+j+DfRzXMxQK6MjFs6ESlS71sMNDvd2btPCkNGMDVlOCii8piGgY8AvaJg1U3g537zg4M3e8F'
    '/PsISFAiZYR0iDaCqw+BeUtDn2SG3cjvGI6mou0CQYK525nGQvdkhHXoowoBa/4B1TBydUYCl+gmG/8AH3ogWrpqRBV3RgC84G//'
    '9M+Ehb7OEEEfFzgLx9wGp6+bVoYYGIpJACEGTSG2GTWNYudJEfSHuSJeo0Apvh4UgaKoAfkD23YBH1p4qKFqnJQxiFsM8H7os06C'
    'y7DiFGyUvszuW6w9ruz9Ab0PZIvpeAmFKTy670fUwKA19NENZDwgDz/SWeSA8YT8HsszVOvvrAuqtyP7yargCx7gl06r8vWHiDxg'
    'FT20nTXBvNCBF9dT6qg4qg7IdcO9qKfv1P/3fz/iWvRTuA1SVb7Tj6sxT9+Zx0/BTGbjTz/ClQshMcaHZhnLPjq+4mYMwPZBiuAz'
    'HeHyERh6wH4bSd6brIPPxfhehH9/kDvfURvekvhoSJeMXhD9sbtYEs+HpX6CxyyDonuMxLSOMflmHQlAQ6S8zHXNCmIO31HxhZfc'
    'Uv0txUftIXO0FNqh0G7cEP07qZvtgDkQX6LvSXz9mDwpYU0ZWwLAdVBaFtYvZ74OdlKQfO9iH0CkKYIuNEebzZCLBlmsGeLFmOs+'
    'Uv0u59xFIulH7JgYuoccr7y9THUgK8J5HoGEO39JA3Qy5McAuYeKn4mKaS7BhC6acxeryw1t5qjtxUKbq1ddQqdXNGDOD6Bwodaz'
    'iXa+oM91HL4+VOcURITOBttUXzJb5WFN7wCo3tGR+Ma8/UsGSi61kzMSkd8fVYoeUsZbNp11DFErSS3h0nySYs5NvUU4gR8nIp+w'
    'ozsepg+zn8gNd+ho8y4e9mN2FFZ7InAx8PwIvUEKW9rc88EMMBdxP8QHnQLn1gPlBk8itpCwz2cre4jsIqLCCBvQICJKmOQ4FoJK'
    'gHDzDQ3tg8rNA68p9tzf85r2fbABNFlHG3Bkx0DHqyMEQPpF8kNjz2AoqBYxO+LfH/GtIhgeqihxaAN5eBfc3l5DAnGmensVOENg'
    '8aKZRTIOrGZkVX0aMpyOch+y81RfLv6I97qAzjm/eKwVBXmtMGMlQhdspJgE/PtLX559/YER4Zyms6WSxz287ZDVZkCSyyRooTvJ'
    'QNzsGjzkN/5SQhmXfxy+sPM3AURuryvoTADIibm9MIiae/Gw/kGwmlHLbwJWdlT1akUXUJRe6KaM/L+h04H4gjyVpg+XaeCuYN0E'
    '+frYhUig3Qzo2LgVeiGa4z8+sQi2N4EvYtfpfVILniVXPRwLIjjk+4l0gmcidHGfK+KvCX4JmviRcQTBvQ9xi8hHmXRQYkwISQtz'
    'W4SwAfgYWj/wKmpeGGnIfkUMPGjpQxGGN6h8gDMy780pts+DDqc/Mi041/NDs9JVH8GAniTCKz8ECc7+/Bg315SLNoBuCB3HC74R'
    'UQTgyn/9ywWxgPfInn58xhgHlLK5uEiwCxtofqkiNvD0vY+d+W8RquZdUATWPYo5AG64cwdJk2BSSJgOeP53lQOtID0xCvOZocoQ'
    'Ym1AZEhDR15S4HFIn3yOdBW0CRWdkAK/iMrcEOwf5sVBquSZZ2Bg3prIRR7nZtxDLfQkBCf/I6DgrI+PINXiJUzNuAdF8CyE4+VH'
    '4AgTPz4ESQ99OwAl4txVV4KHoUGAAUoDQLm//fd/fnuKteXyUZvBs3iTv6MmU7fh6ovVteitZEu9CksQLi6M6ZtJgwYa9RFxoFqP'
    'jB5L03WwejQUh7lfA6nh3/Pm4dYQuqoY7BpF9mtw8dDOUpGhhQ88NQ39eN3utWmVmIayFgsshbOwwEN4ZxIWb4wQb8sB0wb9PARa'
    'M97z0uC9smCiop93BxVHlq7qqhfWVkB6fJyR/HK2RpCC9x3X/oSEC/xv++AjmDGDEceHQrPpoh+E4blPy0wNNKeEFgXM0FHxsVxX'
    'Y4ksNsQeUYB1DmqqrLtmYHmFFDH8GiQ4oI/3Gj9iEgSp2Gem2Ak6vZcTEUMvDfktz6MI3yHQXqMb514P8GUrP8ap5nsBpAYKuzvL'
    'h1Qyhgrj9FWVN7BI66oosv5IZUDPoqn/gek8vGde/YCbvoHTWEMI0c1dVRWF9IwjEdgKcVUcJb+gF7CmugL9QkeJMFitnZuO8WOy'
    'FKfWnrEGAfWmSoJCcj+cXoLCds8EjkUGzgWgk/nGUF33hizDcOYPjEZNjEb9ewco9POE/F3CE+c++oguMEM21A/53WAuwTgOzgoE'
    'roIin0HUNO6AO29KPqcKPHbF4aZ2kfA4L2ogSuKzrF9vD2BQ3uv9SY+nPVYZ5uF83wcl2NZ+sf+C258GTLTtGXWDNP/j7088wX4W'
    'RhM51S4wBrd/TxjJDEkRbJRMGQf0xxAnTCJ4hDg5TM8fwRy0ATlmQoSc4F8LeVQjJr8RJEGgAfkz5L18vMSp0TZdkIpfFjgKquOP'
    '+0b5JGHqkGlE7PvrTxoOfdmtGTaFtb7gOUvwelpIszvx9MlB4yOXHg0bBbp+AvjieTXug08D9D8E/AxkYhJ2ECMeOht4FSX1/AzY'
    'PzP1nx/hj9Eg3lP0mAb7kSD9CBkin93FvYFufiY3wvvIE0dIUJ9cZgPp/nqMUeDbfyUugVWU+Gz9FBJ5a7p+nHO/kX+EVIjAqZ7M'
    'QAocWTiIhhNBLy5IzNnQR2V104Qh5yxLPyLdNMgJnt110N/vN2nt5bFPLPDNByuNeyC+BKw1sIyWphokAEVJoRjPz1l+X+8ahY/6'
    'b2AaOYdrHQ2n3rorlJERBOrMcOgIgGdCzSwzxL9DR9j+ujedDWijwPmD+1ufeKSQf0XWDbT1IER4C1XkyL72XYdg/DxXNBE2rd/R'
    '7T+c8nUGO8qK+kzQ73IRD3nirQeBPwBfoROeLO/3p3AHwHNm7ZrGM/pwuTbHXxLJooKLav24PW27TDaJbePsP17eDc7FQJs7zop8'
    'cNLCRW+PE1h0kGrkMl1RP2CaoDMyLgGkRKQS2DY0GbQdDCmCKDh99CkcohvexQ7/Rln7+LBVjEfu8zljFNlX2FEKGAntfiGyxNcn'
    'nK4+N7cWwoggY5NwLVXXcaA5MthCSGJ+AgyKGdMc0M05MTFpxzvqHOfQdPEvMI3gy9gPHU14X8r3Fvz7wOyPUw4CpA8c4KIG4OBu'
    'enZM42CvFwaHg/xlT5WxTx55XTCnC8JViGYBr7AjRjH/aGCYiALSV46CK6hLBxlN+9V+F4NQg/KLcx8Bjr4ngYziRQQrcompMnam'
    'P/1R3AsheRvccnA+6cV9tjJNF+0I0QDXosNLUUZ4gJMBk/wjG5nCXfGXSGDQx9tQvruDCCvx0TH95/1EwX4hXON2e85VF3h304NM'
    'kR7SpsME7J8Vw43toHobsH9LOQdXoBV0030AWiT+4/veiC8ld/71pznpkgGvK4TuoPO3nhKMfRGhesj877//EnwXJvmqFhXG/T1/'
    'jDz/dD9L6hqOPo4pJDbuXS1CWDHvGTf4+z189vYqhpVaD6KyRdP4BWUJg8q2lK+NiJ++fD183HFy9oMjkJ8eLFjF0ZRkfXTO4Ll2'
    '9BO9ssVjuNzjQ+nCs65gXKgo2mz4W3ALyqGO21tGJejwR10+hmXRcv6G4j/AKuUgoxl/wSvCmDvSNynd+yD4o7wW4FWo6ai5mEaF'
    'tbPLF9Dean0rH3TVWOKTWND+20RvWIW9KKG4w8S8okzM86SeUy2f7iAQ1Oyby2VM4vVQphYIiRXa2BIdqhHo4XPf+xGZcT6Z46JX'
    'Ra1doXaQe7uZKd/78uy3LLpAW/TOdkyMjC5VcYA6VtmNsn6ua+NFurEMTLz/j/h//x8iaM2dh20BHs1V3T0/CXMNY71FO3oeAAYa'
    'fVgx2En4oFqQJhJ1Gu0/zBKBg/7tsV8i9BFIQZT9buW//dP/+Ns//R9/+6f/82//9M9hdRx+CbQ40Ohu3+vg2FcU8rpsNAh2NAVK'
    '7O1bRRwDMYPWv1wmL+j0G6yQgRIUEbF8RdMbxtNwSCUIqER5V46alj1Pvjf+4oNAi3wTqkHWIAYip4cgpFCU5isR6/AS1dHDiM/2'
    'TpdxxAkNYdR4pIIH0hsZAbjtwGpFGR9vNhTP10IQJZL3AoXoOoPrW5gMFnkz0SS6cwdwB7VwMkGbwtMqL2Np8egRdH6B5pYh48+k'
    '3ePU588KXsTvedN68Cwh6eIsJnhcMW/FW7A3Bx3ffDcPOHixAX8dZLVjHE/6WaIf2UW8Cr0THs8V8lXMmfAqhLkwSTYZ+8bZRVyG'
    'qBt8pux6KsIRXL608fSDukQyN+Yyl5dPkT3WGnCdN3Q3/ChgBH80hecjoj8xJ/hbYHcsUyOPNpZdQtiyg1RKaxVtEvzT3RwJC21U'
    'RL6nR0bpin76Xg3yoB9WYZ6+9/zZ6qrW/Q4vX0V6+v6Kfh6mpzg4L1u5Sqi4bxFjJ+V8iwKzZixL9++Y1HTbc3TkzL9MKtNt/7Fj'
    'aS4pi0FJCMXgB/MWw2Y/CkhwPEl/BSxxuYqZiKjUC0s/D0d46MmHV8NwVccbGOGxTw185tQ5ewhvp0HHQuE0bdAEAs0DXSM/K953'
    '82NJBNDN50Bs3wGw5W9nqBCD+INgnA+8et9SNRL5GGEKT+CsOstgjED1P5xY8T4S63FYwuwVXPYjqPuBvvEEvATHN0akixfmnLT5'
    'KF8p0tmQJkP8kN13P1XpWmOP8fg+yh69BGFwLukj1v70HT/Hfp37LDZAQGwEo/Hi1NR32DcOriAMQbE5kPqPN9ODmh3UDA7ODo4h'
    'f6d1UOJxB6Gj/o2t+lATdxDWDPp4ozIe27n6nZG+J1eCuaqajnYCNVrWu35sIYrBiW4/mqwTHQj3USJxMFWUw6PdEsmD8XTBT8OR'
    'ODLuYx6J85f6noibT30GmVBxyzsouf5s51tZ1PsgSOUSWx9tpg082DoIggyRNJwuGdZIuw+yrLGtgBOtM2+qmeizgE+BoZcwPNDW'
    'A7yJEduuYLYmw3GJXWdvB3ZwPy/b5Z1IzNbXPQ35vS8hGaxsn3XvP/32D+k00YfOlj6UIyPDd4gvobvczQZe3nQISRo9jSJHMJBw'
    'Dz/BYCfv12c8IrwJCAocEICOb+B5Omd5IA+Rhb5DQKTTCc3f8727en/k9g8xTNd2+AB1HefEXk04tBFq9ReNHMoKYD3FbJtEcP98'
    'HNR9XR29/VhTb6hyeLzEOSDyJWLlgC3YbQ3Lex78vw8/K/GTVPm7SIfmAMfQftOiEeTxbVaLvbBioodnY2XFJE1JeBSahDdWpu8V'
    'cY7R2ZT8LCvAWzXPkil0cYTL82hQhrx7+n61NnmcSoP+vUzKG8ubwIrSwXPkuxYvPGzhoaN/b23WiIDAYNesiBpvA6iBPe47RWBI'
    'T9//+ifiKeR934inJFU9PcPDkJTgKYNu3fCQMLhHH994UrfWCn2h7gl9B8xXn1GZjg9ugebCM1lwIc6LhbLwuBlchsKReLdN8PKf'
    'iP+KukDb914U1CGLbsOIZtQhGV4QTxqqQz7ja5xjD61TiGcFcRnk4XgKnh4uFY+Xy3C3/zfCAM04KNqAEoyBRN7goAh/kwGV/Zme'
    '0QpLh8VB8PPcVmB3Q63/5JMkM1/R30dIVm+x5yUZ7Q1qZKFKcGWh9B03TKzAUSu4kzG/Q+FcTfeC3XZR2FLzQGYvngnQyGJBTUTe'
    'rorfdaHbS2EQ5cyEvVphp74eXuja+Twi3ItMBOWz74gbEoithK/OvkeHhQXpxsHxUHjg34hLNgR6A29YCzU4VBbbhQcGruue+7h4'
    'Ec6dRJACYGcI+9hbhcKN0YsLJA0u26oub4eLH86Yhg5JUp8REAaIMbQYUQv0ZVjyDKnboZdtLjvOEQmKwLcVVT8fYPMmoKWDpTra'
    'Fh+t6KiqfvyWHOr00inaGYeFdbCAwY6xqHJZ8y41o11eYVg4tug48nIDRxYW9wl9DQbTGJWkFypJL8j2A9XBPXsGYxSTpjOsRAsC'
    'zdAsx1E0T3JqmmIvdJSmOC5DUhTDUKTAkLx0RVfkNQWpJEMx1IcoyIwhaCFUTy6+1LNj9N4idBIoBiO8TOW1GxQoFM0jirSjo/oA'
    'a6PXkkgZvYj2ZEa7i+93jmIBIb4lUf22wYVmaO4qc64RiwNc6mFh7cZO+bpd7vNUAScJgw7yeedo0oWMz7sL5D+IB4x213ELGNYF'
    'Znd+gSQMW1w4yQXH6CSO0UkcS3jt8TaZ0PcewzWGFDIiz1MUKVKSQFPMBcsYJsORpMSIlCBJDE8y72KZyEnk/ArLqLtYFmeD0aAR'
    'uDHeEMO6bcAmfk1sJSZCLm9eL6SSaAe960bnDcpoJ5h6D32KOBwS9Rk1iEIYMZDC0MIFosCdf6+9EeKDUTPnMyQvbQGf+xKd64nS'
    'vUBVjvEXwJTjp8+ORISEkw1g/EvMpaLhRAkJ3t4M9re4ob8lOJgPG0fvcDMmiWlMEtPwRmqcva2onqzpCWbGZSRSoHiWZ1iJE3kx'
    'hmIUT2eAf5Es8DmaBkYnvIdjC1Kck+QVjtF3ccxKHimJJuoXBwtOAuUXYv5jxCVotFyp1mWd8NcYn4OsTLQN61zpb//9nxOreROl'
    'whR+R+pmYzJzhHWP2C5lvNUccPoZW52gICHPHMFeUDzCGXTU29UpnRdwUCtu4ChCIGvRcYXoaEnA/yNQzizGTs5zHEaVI6UwXHo2'
    'ufRscumrgYUGBpWGT1W+7Jf/aUjAfAgJyDPAXBJg7hZXz4sESpuHvqEXnHf2LwwxdYaYT0LMJyGu38bs44CKbAYA4iiJY1iB4/i4'
    'ngCPRElgQVPgQZ/gePo9+uJ5WSQXV4Ayd+kLez1CZuHh752F1865EOTi3/7b/wwxDW7P5VhVuC7Pnt/MJtrDH1G7blv5njgUJXvh'
    'dhc9IWpMubwU007gnaTMv65+gSfebSku59/ooYZFDtZK4nL+mSjTiDP0EFf/ZNetUBVBAuADENzTaz7WUeC4fKPpRIWPtto0d/FT'
    'QrSzhXOvh2CPzEY9up/sBXPF87kdb/RwxY0/uASIBt5r9EemHAcPs0QQhXuvgzzUDCJ9n+0lOBIgGwiz8HCA93r7Peot/cne8CEm'
    'WXQ0qfleH9Ooj/CkkU/2hE8Lg1EFZ7+/11kv2Vnvk52hJNb3umh/lqsEJ1VGe9az55Pt3sW15FhKn6UWzbuca/JeX+QHGs/G2XU2'
    'LiOQv0WN6eqhLIvpWqHHLdBug6+2p9GHriPHR2CHnw92MdHJxfsV8twgxQMpdfeMJCEpXIWkcKWR46opb7A6j3fELE1TiQlYPsOA'
    'UEUmErLEJZa5tsVJRshIYPmwHEVJEiuKP9HL9XHrKTxnITp/4TKrTnho8FlWZgh8gvfdU3SWZuh+QZMcHmSc9JDEFdCrg40vfeKD'
    'hWP2DI5hRIcS3zOXotZvDyc/NxptsQi+8xW4jLCbE/u8wkOlsXgMEuRDNLqCO2YYgtX1wOdFuL6RRXnXEUq6OLFbde+ldL9jOIlJ'
    '7BOT2IdPW4mrcwIobBzDswwlgMpJC+w1tlECk2HfwDbhY76fM3xSEj4pCR86ryWhbNLoszwCR5EkJ5IiwyRAk6QMT5OiwPICz3Hi'
    'tcNA/IxbKjhyBmrhg2MuXrUrNzR15YfOm4c4vIKUYSmSZ0VWpDhBkIQ4vLQgZjiRZUSKZgSJF34IXOoKXHSKzQXaayfglRcwPMAm'
    'BrFIZ0iRpCmWYkmBZCQpAbDIZ3iB4RiB4UVB4H4MYvoK4ug4nQvUV24l6sqvdD5RJwY3TQsZXmRpgWFZkREoOom0kgiYwfC0BKBT'
    'AvtDcDNXcGNwLkBfeSioaxcFoJFL/Dus8MTgpiQyA0vPgRVFk6zACnHzSWSlDIyH5nmJBjuQFt6ltbsesAuMV6Y0dWVLB4c6XIBj'
    'KSlDCZSIEAFsUS6BDCQtghEq0CzFMYzIstfURjEfgi6kH7yJGgWiMAgXiK9saerKmMZnEMXdichpSHEiQM1K8FfkYiALQG8ijQxm'
    'iePBfhZ/DGIqCXFwGtIF4itbmuKvGQT6kkagZgM6zILzs2LinsywLCAqRzO0yADJxQYAfCQD5CeCLU2SrMT84ABCcsLpfpfoHRGl'
    '9MWLcM4qvHEZ3pU2QwnXDDtITIgzQYqjMjAgWBUJeDdLc3HahKXKACcHfsJTHE9J0ns4/pYHTtsuI/AAdgeN5QnlX3wL8g/Wlrr8'
    'dSa7Ks8+Z6V1ls3lXnubaa27zOVzrzm4g99cMcsuq5PeoFUcU/len5zW+qUBPCtBhepLDv953edyeW9mdI+DjVJ4Ka+mIy1Xhfbg'
    '/VJQJZdfTZjWPveRP9C35E3wL/Tfb7zmfsIffTMdt9boSkT/FLrHUVmXEWBlDF7XiO7rwb0W3XeCe0ap5kl0NQjuj8NyrYiupri9'
    'lXF1r13dr+fVGn4fA1E8eLPqcH2BD89TczrihgM8S0v0zzxXbeYGy3w1V6pNRkNzGdWe8TD1xTWFWtoE8x3Ns7aF+fLYAepJRmN4'
    'iR4Veuj9zgr+8Vwp0V5ivsf51XxbuiwGvDndwvNO3YDr1giKShIqtmYX+PNvj6eQC8ZTmudm+/wuV4HfXF5H5b3XvJ+rNHONJQy6'
    '+JJr5nKHXHGWpfd5mL9BMY+QbT8owW85/zqo5Pf7l/x+Xs3vxUZhv2mWXsVeaVXqlLqlfnm1H5cOr3K5W+pWCqVJZUUq1YO4KB3m'
    'Wq3wotbye7V6EIK2XwfQ3hzaY18KOVYt50uD6opV/9hfIQvD7RZyxX1utCzmejD7KwD9UMpnxddcZY9pC/qGssSfZin/OqnmltXs'
    'IZdLlRDt7F+h7ivAN3jJRZTTLa9yy2aptBxUXvrl7nxQLixlQMxuU2vSteNmVhrUirXecjkfvZCt0savHgZMZ4/6BiRC9FgOaDf+'
    'p1SAvsr55fwF1Wut4PmyBDC+whw3S+e+8/D+EsPZg77zg1H5sJxWVvkD9O1Uu2yvkxfzr6MmWeu7u2qWXsJS7kto/MXSay6ba1tU'
    'xeouD3z9dLJKUtceTJqVUh8X7ifdzkDWK8X86t/2k9fBpNR8sexWb+sWR4WV3qvx64Hl5Khl88UIi3N7TTWpurxvTYqF//WfL+Fx'
    'sdbtmsXXAcxI7+iV6GUr3x/Iq9W/iausXK/b/MayrJE1FDbd6uCY6uwdf7boUXJPtnXBHrR9Vli7s7wpU68aldp6A2HY7tBb+nho'
    'FdbM/LBjptzgQCruiVyM+qrcNVvZwZTZ6ebaSjGjOaWJeWO86dn+dns0QHFeHJtHw1JGKW/7oh1mC9bo5cTtcSd3HJ23aJ4117a2'
    'rWX3hVObcoW6rMxWw8FpyJw6wgunSuRpMzAl58Wj9najL56GnFHlRi+7VGdqW/3UtE11Tm2xc4T+fF2W+YFtjXfdgXBqkgy95a2J'
    's07ZWkPv9PfMVKytV3x53aC7e0Hv8M1Tt2NUnYPUP3mwbEr5NC7Uuv3hZqJ0JsZsOBNrr2TbEhqm70+2LiuORdlZkYdOu8Zb61S3'
    'tlcXFpXN+Slh12X6ZJ+JJnzLTpfmlsybdXk9aL7Er3KWXaiUBgGVvwKW/MvTKyzoSrYBE7rUcNQtChO60/dWjd2LNbAV3WvtZnwx'
    'R40HdaWzF/zh8GhqUyFldypqfsOqrfZwYbqHrFdvSYdRtbuaeC2v1FdU2luU+/VcRx83joI/XTg7xlKGA3/amTbKW1h8jZmtulVg'
    'kocjj6SonjLdfHPx0pNmlswoUkFd9e1iidP2enbteI22XXON7YpqH2hvyA9t3bey+XFzQHXpPpkqiQsxR5Ipny23ZyvqdadZ7IE5'
    'SKe1gke66Bc7tcF97pRflVu40qDp/Cvwx76iNEjL2wxV3R5kB1SjQvFzu2e8+GSDpxpZPUvPLe/QH47NdrfcaXU7q/Kg3zFnxpSf'
    'gICgmtKO3DDLXGe7l0ah5LG7dXvYVbnBpHrYDK3ZQdDllNOz9eOpO5z7A3Iw57Yv6119pg8G5AmWdckyGKQqRZ4OtXsAlyu5ScDS'
    'Jq38a8jS0D3UknNkubJsQYUWqgC3+dW/6PMCXVbG1aPc2JldlTl2dCgfzQHPjrPWcMsVLVubGL6xHDeGR5sal5WmONGNAWnrw/rw'
    'xTF38rI1PLQner22ZobTznDMVqjOtjP2Sju+pVMTiW5XU65UOlDZhb2RZFLoeBy1bXjVjrW2N7kceUDKXo5i2ozUVBqtenbkCNlc'
    'ocnUduREsmSeEjdS3ehMy0c/q9r+UOJTrFSg87TiT/1pf8tMsn3vyAqyyTV87sRVm0JPtvprunbga6m2Q67FbRtxj1ZOLjK6YdRr'
    'Xk4urF8ry5CtwAOQRLNXKINf9ADLKRPU3Vl0E3GgQFShBkIB9q9bI79lt4u596KXD2XHlPhKC1WiUpY81mRjKp30QXfY5w9M/7Q8'
    'zseN3URXs1N7sOW9qdqZC472slsN6TI5LHfhb1ullvJeVadjd3eweWOyO/Wrw2Z3mJJqpOTItNAv+CN2qx6HKXKbdXyaL6m+vzVO'
    'g7243syUQkvuyvyu6r9SCPJik8zSMr9YU4fxhjrNx13RVevzlDU5Kra75SqCbGkGZaTU3I5p6PxOZW17xwOO4sFKRZd2FE1rKP72'
    'xVrrpfnLktv6ts0NW4grnmeowB5DST3KOxG6o6FgIoCr/MY09xP0P1rUvLbOL/f/9n9z5r5YwGtdb1bqleGLgfFyP9GBA04qbjng'
    'hf+LX+W7y9eA7GyE2pVxqYcY1wgzrhqs5DBgXFtY3yFmXOh5aX7aNIvFhWQdhZY1kIYySWcbu1ZHl8ZiXxYa9bG7Wvhk09hNDjN6'
    'sR51xFxtXFI71WOhJUJP7eZR9dzVMKuIFaqbFeq6ne2ux1x1uGgy6nErzVxLOtLGYU4pJ7lfMFOjqeGvBXNm8RV4v9NsGC1xN86W'
    'j+1Xg5Xp7OtB2C6McccD7uVky4o9Zre1oTecrrnZPDUvKp0hQlKu7g839rqxGetZZzDg2v2eQ3JlqiwOnIGX3ecpMivmynx2CT2R'
    'qKc63+5z9XWquGlanbo0FE81V3oVT3J2dRK07Lpb31GvPjkbjmopWZuIu32LlBowS9Uc3XbbQ3PG94yqb0n8akcOaLVGefJwcxQr'
    'tnGwveHLzh9zW0WmV/uZUZCt9W4tNGcWhbgO1a5RnT39emxsnKk9JsfysM9IzK51mPojhyqMG62jxr3unMHwxVZZWjfqLsMqvl8T'
    'rAIWKGj5ytz1+r23vn/wOZRVSgs0ACfi5X18k7fbE37FOuu67jEOQ+pcO0XJKW9gGHwJ5M1uWvZP/d24rlfl0qxmNscdrpjf11vu'
    'ruaN/ANpjRz+mOopvFGcH6jFsTKxyYkhGHKKdyhHWHSFolG34Y8Of0e2pVLDoUr1jeZOlpluW5hYi1mn0GkYUk5xjuMRZetlk82W'
    'bWecUgW6Bk1nOXMuHKuDToNzrPmRd5QCcPSUafjCULLs/Zzb8J7OVU/U0bfbpRx058B/Zq41v/ZHDQ4i4Acl0A3qSA1ZcljXUuy2'
    'MLG323GuvWSztqDPp/bsSE6HBVXzKna21dE4cldRxvOx3nAWzKGe3Uleh7PEUae9nM0q1Kl5SFWkXZfqHyR1ArrpUPGFWY+THcsf'
    'NJjhwOYbQl+Qi8cG6PineYHVT6XjTLcWPa0hDRetNte3UzWe6fKzRY1lpmC7jChRXmws0q951TWjlhl2KrLiXtkg/F/nj2K/7Vrq'
    'oSGV+fXBGvsiKVW95npUXJAUSXV3gyNbqIEkL/hIHowCHFGAzYSYMQ4kA8aXQDJ8tka1rQyUAd3uMIdmdSTpNRoW1pmNWaeafW11'
    'NrykTaQTMz81T9VB0aZbs9O4NVcO5SI3FLKlYdXyBoonp06kKht16VWajWc2NcmWBo5sCvqOsqTpotbpcg6d6h5gaX1hbvvjOm/z'
    'vK7aYJUNh3p/zKVAUHvkJFtRd2a21jwq+dNuuHuZL/WhUc0qTUU92OXUbrChFrWdPOd3smPn5vpm2mJqNiN4/c0yl3Pf8WN6K27U'
    'XzGb3cRL+ad5n7LLE6G4Uv1ytz4b1+nWriu15L4HiHHMvrCbylSbprpaTxj2hPb6mBc6y6lfM+jBbqJ2Z7uBqstDYSCSAilZm6Za'
    'Z+nuZuJRDb+l+iOZlGTNGoyZal/sUweD5Qe0yFNdnazxx8XQmUnltnVoWY3hopCtCJ3xaQ06Yrmm9cnW8mD5Td5hxy3ZkKzs1NFS'
    '1qI/xiyKe/VaSn04qIO6avJ1Q9a2KZdr2dmiR3U782F1v58gF4uIZe7WpEClciuhmYkfvaIn6wrX0dtt9qgDa6t7tD72rbFnj+ka'
    'bVTFEwV2njd0NFepl4RBauubfEoeZFvZl/3cGYiz8lrqOWuqe3oxlsrq2FZWojJJbU9zTTt1+apArUoC1c7xa94/zoVZdd9yZ5Wx'
    'O7KyDmWJpVXRgF6PTebFPjZtaaz4lCINe9lsc1Pqb7xXipc2h1Z5x8qL0YKjy81jLicHrreUzPMNpU0pSquu1u19XsrtG9nmXJn2'
    'eXrYHexWXWkmFfM7pcd6jewr3fAOi12rZxxqzDS/e507Kr892jvXValuqja0U90V48+4Ope1h1Z/D+ZvQTm+Km7fZ5yhI/SEbjdV'
    't0rtoj9Vh/MUeZxRY2NkbwoLZSnYO5hEUxCP5E4fZPlSPaWyR8PfUUN1WMiW2H1J2OT4I0fVlla2KO+oBWlqC7sHeqibcrRxWeQ3'
    'r9wS12o7trIY7jf9k78QS7ZvuWtqLpPG1rblUklwc4wm9TjDdEclScs2U0N+c6KyR1fp8MPU1Hpt0bmZrpqp16zuLoRhapLd1Yzs'
    'cQJy1wNRuM0xk7y/gZfI7FFUFuglqUY1trBsa4d72Z1alby/B94j9adVZ0JZi9rwNUXyhiO1q72dPs+ybQU1QlLVgeQtWLHndepe'
    'djm0eB1sc81lSHHTXWhzs9A65pR1l8ofvPFiPLdEvrMZe+Lh4C0UIIBUrdyX+qs9qpWdnZo9lt4Op/Zi77zuevbwRaqbtlqvGrUU'
    'SQHjlVo90ilsVCHPN6ftssH55aGnTRX+wIL5rzWE4mlLHSvKLJt7afripjGyzenQMfyeKQhUS16oZp8tbOt2TWnar6o3WYyrrVGp'
    '29gJnY1pTLPaiB6L/KjlrRf0akR3m8a6vhmTzszfCXqfNdYtx5699IVxxRvWJGpopabbkWrNwawbV31ysRrWd5tZgbF9ReaGp87i'
    'kLLaUk0YyrzAjmyDl5yG57CNWXdBDnZ9yiJTtuJ3FUsUWl2WmnK79WyXMnurRcErv54a7e5kt5gwjnISW736dDDrTvVO+0XcHfu7'
    'nuoOFVnMGYq6AySz+uWdmBszJdLXnfJR0Cx+aAEOL1R1lrNsWjvVuHonNyONGbeQzBY3HDb7a0epq6uZJ1MqV8kOyPGLMhC5re3T'
    's/HUGlOzDlXq0xadEkmzWZfs7Vhlh0xNbFfJl7khDOEPcIeeA2sDhstOtg02Nwmd8nmnaRjttpvljsxQbMgdIcVSfp9qDWlrPTnW'
    '2OG4vlsap7aSBysoN6u+cM5mdtptGrP+3rMcISXuZ/qRm49lbjwc7dYDx9gXrJdcrrT8VNTq6FRfpt4alGaftNhZ2+DqU2ptNzb1'
    '9nHH14VUXdelU8XIF7RXpTXht559HIsjeyvXDQn4dbYlztSZxKbW473THUjZ+XxQ2Moveb4280eC3qbASPQ6FX3ccUXedByPmg2G'
    '1MBhTaeirMXTsWX4R9kmxTpo8WOvPjXzNNueHnzLJrulY1PeOgJV7qtcf8oy7bmiCmXfkcd7/4XZCdpWni4rp7wIPflc35s5ltM/'
    'WMP9a/Hk5ip/NK5X5D2mLigjGIO9WlT0UV5cLqtZ+vX334OAKPG0R1FwngzvVig2yqJsmyB+i0OkvSCo+9R7erBvIchsjnIBz5sQ'
    'o1SmMMZ7nTj3jD65ic6KQBlXXxKJe8Nz3a94WwJURNvYLbxL5O4ZYBl0PMSGwJ+eQQmC4RdiEp94DLq9l3JHXWU9UVdpT8EO/FXw'
    '+T0Vf7yMcD1/sYiHrRlWyHACxYgUR0sSx8SzHySBy6Bcd4klGZKBCu9FrT+R176igw8jh1v9orSzuYzOXVxdcopjG0mD8aAdnzN8'
    'fAAeUOz4gOdgEaM1mV0aQXltwaX2PZH7q50f+N/Ph+JECWbfYyl57nc3ftZNWMX9/vbO0/ORNO45QT9eAQoN1UWbWTDgl718iSy3'
    'x2XxXYSJ42XcOxl3ZZzAp1ru4x12H9lrgKnm/naDqrn/g5sN8OEmd/Jjo0NPcD5k/GSTj6XfJkk53nD0UaiIthOHwHyscXTOzp2W'
    '8ReQwsRGaC84audHEnqBlRGuM//9P/3vHI//nePxv3M8/iVyPEqlnJq7yfGoYpqC7vbXOR7zl/zrBOdQFBbZUq5Eolkuwj2M320W'
    'Xl/z+YAOojyLaqn7smq+Lvuvw9KgfFhqwy3OuRiYfaUwLA+pDT86uFK1Rx4G66Ze60+2co89tY6m3Vu/Mu2C1ymifJIZpuVlM6D5'
    '2J98bpDP7SeFfBbgKZpdgBvuS8UCwIrr5y7wlF4HvddpqQJzv2oOyweyO+xPYPbdeWn0sn45veqNlVgcH+ZmXXvNZoGu9jD/uULp'
    'tdnNFcWcX8kV9+oy96/3Z1FczHazWXVWm+mKfaxvrJeNwHf51KHUV22pV7Ntgyn3XUEcnybWYd0plus2fWR2Sr7n8uVh62SkhkeL'
    'L72ux8O9XWoKR4GsdkHPmc8ZozSkvGxXpTb6eK3nRmphOhrZe0qXD2WS5rjt/sXPatrLWidF39g0F8xrVnpZ9Mapl+Wy3BZSvpTd'
    'd6X66tglt/U9ry5S5M4k+7tLPYXsZHtVEqzUl5f82qIWErMH6I/qRrWyUk88Kim+ms3VX1MbsKdKbbixinwvewBEVdpO1k8VqnSf'
    'XFOdrD3e4pb3xaDB5kpuD/JTjl85DWsi+5o2XteKzQ194gbkzBcNsy6CNZLyPQCSMxCMvb2tdgBGmx4v3Rbr6ZK3UY5eeVodkput'
    '3dpMnUNf00xfKos9NK/iWhwPK5X5dEB1ak1BqjCFrlvuVx3Grvucky3ZdVudDbzluOzM67tiW0zJvGSSXt1XZ6dtgyezZlZeAo8b'
    '/BwsqjfHlYq89cv9PtXedQ49f1pzDvRmOBjTOnf0s/XckXfqPX5YaTQ6OZcqDxoetRnM1NRqQe7IPmOLw7E5Ho+1IW2SVn9pNeaK'
    'c6xTBX02bvJgF9PiRBwatpTqgbkzmEqDc+cdlen2+0xhu7TI4dSqjdx1t0SBYWm/GF7jpCupvqQzo2GLscQhs9UXxe7gaNW63WOL'
    'HKl9xpHKjNBQ6w3SsSy/2zvkQW/q6YXiRuJEh5P5Vc+fbcuVrShU5jt6Vx0Kbi5X1uaDn0NM9otd1yxbE6G9Vn9XGaXygtd0qdnq'
    'uBl1h9SQrPur4ZHneeckW/YiT5tNf5dnsrmG1001GbdikfU+z5TnhUVxOOML9ISyagsxV0tNTUNeHnmxukgJg8X6RTxJ++qqX0gV'
    '7R47qlOKNmzq+2mBy05LjjRqVF9sy5SO1kE2zFrqZcsNGH8xqILxLOnNrmCv++vuhoKOWLI6EGjHblVKPLndpg7H2fjUko8F1Hy5'
    'UrR9dkxTik41lf2iQKHmW5VatWLXzMOxdpjvrFpRGFTG46WQZeS1OF2qvZNgUAvRPi6mrxtXo0ySG0y8wzgnS7Yi9KiKVyjLvd5i'
    'YrUa3FZT7GLD2SvZfQGNrLmain6zSG8VVyqvjutedyc0LM+edVWv5Q3J8WFLLTf1VX88Mp3lgJSGO8uZ6qMNlT0utsDXe4WfyyEL'
    'NX/YggHlRfuQnfZL7qY/t2dMxy5yw3XquH2hmFT/xVf7wF82fEdrJ4cPtXUDame54SZ1XNWmZSvVL83NnWiMQDIC4e4/BU6n4tv8'
    'aGnV6r5nT2TZWPflRaMuVTzZGNm2YttqRbcseWtueu1KTTv2OuMlZQMfTy3t8lZfb1mW3LmuC6Ap7kq1B0rDMSlHLbSHbf2IiJci'
    '2fLKShnHXc2rsT1h1J9VjrrSk0+rhjedVPzT+pi1puNuTa2ebEopjyrbzdywSHJ8qp4k/5Tr7HlHGqjDUZ6skwVaYA7jzVgjR4wA'
    'uF5lyrbKTJdVVhmm7E515u6LYtvODqv6cDmVcqOdmuqAtioV6Cy6eqN257XsMLt1Fqbl1duhq7xsePQkn6oOF/b6NGm2pku2cyi3'
    'acNTRIuhitJpMh2MaoLOb7p8zd5tqPosXx6Wu4Nxd8DW1ZpoCIojuNutOuVrXTnF09vxIV/M5gqKq1JK1rLENrM1lc54sFm09/1j'
    'm1o0qo5pt8fW0LaZo7nTasv22HdkxRsq7YW8NhxtVV8N5rUZaHqv8rVi320drd08ZXb0UUeoT/SNNtP7Kie9Lurugh4cKj4oV9vu'
    'XDQWotEVQYVfzFNOVh/1hXoJ1d64KU4aZ+uuQQ9qjRevc5ys9XJ2wzOgH/d622scypuqTNdrzjh3JGl+OOFtxacaL5SaWk/33RKv'
    'jxc7viRaeaqStUblXX03FMrimCltT14dMeB6VT5NnIO2K0r2dlRw/UF/uhUn9IvDvOwG/lHjG1y/orjjYnW/XXCrQ0FGYT8fhtSW'
    'dw0tpdd8o1Af7xaH426j6H2uQdtrie/PpGNq1TJm5f1BrBmpybxNN1Zrtg/40Gy/9PNOiqZNiVSL4omRtrPOTgfM6k/pw7y5KEyz'
    '22rR09hJqnTKouq5c+3D3cpVq89m917rZQ1o1AWBW96sVE01+vNXtVjnZvzSoA7r/WI7WdS004E+ss6xUSdJsdwv0LKxXQPzSh2l'
    '9WZYFvmq+dpY7krecMWznkoJBjnXzI3YKZf7Tt8eFtSXaaXfberafM0yXvc0ru2HZbauUObIH0gjq90bneodeWfvJnPP3uont671'
    '1cnOndK5vKqPzqsnW0YupWxH7ZfqIEV5TtfvKoZEKSUlexj2jJqq8eSgfPR0kCCWT+UH+91q03dkrtxdOPUJS+2ZebPOruxGd/7C'
    'vPAtBRhxq6Svx0sO5lnyx8P2kl9vpNHaPVlCiuSr3bqrbIedBb0t5/KktTjrGhVpWuj1m6eJa7+K47Yuc21v1+pQjZneFKqrU0Vs'
    '1fJa5TjyxSZYhqO6bVU6XdrID7sjQepMprZ+6pxe3M2uNWyR9nDYyeZKPA8mdVbc0Dt5nrVV4EOybfQ2vjXZD7bmaOD4ljfgGvao'
    'QL/WuZGj58apcsXzh7onja2DUuLInsMrVmcyAzs/67b69nq2lmd61971TlMdWER3MRl4/a7gV/l5Kj84kT63ShmdZT9X7DnDrbOs'
    's63+Vnx9fW2PGa93IEeGMd8aXsv2pJPn7WfeoLy36l677ZZO42yuXH+V9YLTz1bLzqFbMrr2AGh2MFrz+5y8HuXk8vaw3a36DW07'
    'oYXTcdg66FNvP0ptSaXJtfgXjrbN9Ug2bdmhGqbGy+WZ2JsDv9NV6TTrvI62pz3Pe8MX3dC7bWvcHk/HKao4Lej18Wh95Grl0+ug'
    'OdbznG/b9rYx6B9qM3usZNkV8zqaMStFqg52XNflWy8Hz9xtwXJX8tOdWmZIpZfVi/7SZXYFgW9bi+OKlF9pYOZXasNQF8xGS9j7'
    'qbU9Fs1Dpe4y7qE5GKXaDMOUOlOlVa1vTiNlNRBaVVODYbgTTaw2+H5/7HLAaLWt77qt+k5WDHXAiyRt7jpDWnevVAaD49nhST2V'
    '9rsZ11hM3FdJG5Ab+9Se0uX+jlLtF82xJc3Zg3bT3MUH+GqO5rzS6s7Gg9YQ+uHUYV0skVanA/qruB80E0NQyPJWYseLLtVIDWb+'
    'ulfPzrqLZrnY5gsnVWzsTF7P1tujudlpUc5mOB+9cG1rpvR49dhUKpuWVxZBB9k7R9Od0SmltKPysxnVt7myYp5cdVjiB92TKkmN'
    'YaPK9TmHHZyqFuO5oqh35pPRS0pd2oOu65T4cYtkOjPHp/oH2dzaFV+pD1QStNttKpejDDMn1m3X5Ict4KTLZd/ZbLo7alty5rPJ'
    'xBqMZd8d2NKgMVxIPbkk79SRBPrIlipXD3LXt0aU7KTG+d2+6762Cs6cbHQrttUbtMaDBuXTo5okO0IxT/kyGCrdgdVQentZLKuO'
    'YRtUuTXmhvK4m01tx0KJyVYPjYputqRBtrs+yGMRNIkyZ3Q2i7XGzlnfPzoVT+zNikpx11p3yt5h4b5S7nFxHJC9l53bHxyog9d+'
    'sV6mDWsu13dzZu5wFv3/s/dmzYkky8Lge/+KbJ2+LWgkINmRuqpMGwiBALGjOvXdTjITSEhyZ61TZvdt5mGexsZsZsxmnsfmd3z/'
    '5PyScfeIXECq6r7fvfdt6pwWmZGxh4dv4eG+FtMFUcwWHmuwMMrcLrv2wOvpWmOfXdiFZaLYVpV7q6rv0wkAJmu3FxfVqbQugTDf'
    'emyZIXVrZ26y++645U2swWCkLLzeVHxa9zLSQy2neJXRtOFUXvqLQcYAIEqsCs1NNz99Kqq3465mAR1fzK1atfjcf56MM09iTZNq'
    '05fWi+f083tHbpdaz2rjYOSm/fyj3hvN3Rdrah+M7PRQvhdvbsu1VjPsyrw0HI/dVX0iebeq/aR3qrAngJGubobifpJ+3t6Ld7LZ'
    '7Gql50O1p5V2avXlMCwZmV23Vy8sN95uthgMBtXu82vNVhsjWX2Uy8PDVgcGaJVSe9Kd6g03lcQmr3aaQ2vUTY1K2sM6X/CMeWOQ'
    'cJqJknIQJ+27IQgFk3K+aT5aaik1LVXy92lDmSLP+qJn2wO39CRtxNdNdrFWnddcV4QxTYH/uyk3skYxNdvU1GXRKaf2tW7RsDPq'
    'gzcquNnioZWT9u3tHEQrvTNqDEZSRyuYe1NejDcVG9hOJ18B0dF+ernNG7aebY7lbGlxaPQbICvn3dxYdKrN8c5uSmKz6nWaD52W'
    'WSrYumWv26uCbcyN10Sxtnt8KlTa/Yf7xmj4UlrZo1FjcVM+ZHRbbvbvR63cejZ266nSzW2/2VuvXzIPdb0y1GxHf1kXHib15WL6'
    'km9Ope76btDbOCsjUZ3kllolP7JS89V+o4v5trIdO7qn1uzha1v17NpjxykM7WJhMZjMl+XV/QQmvpcp6z3XWU+7g4bSL2l1u1G8'
    'E80nsT1q2O2c296N9NnqRVTzi0xuui5pZqrQO/S2m6y7TDzVnxZKYnl4fewkJlJnaFjDknn/WFl6jvVkTaajbn21A/b5WWt4kqyW'
    'Bpt7bZiuD0teteDacnrcaN/3di+7YUZ79eqiXXPyT62UnFfaeWXeTPU3w8nIHrRyvUVdc8up8kh8HpS7877ltZZuOX/fLK293UbP'
    '2hNPsfdD17HtzuuTZVVEubxP9Y0X7Wndeeg8ZB93Nw9j6+WuC9K2VHrILXfNfq63m3ZqSzEzA1lzdPuUr7YsyegoelN3llJRErOT'
    'biN7GFrp1X4s79Ne6/65mnN3r6u5NLDX29fscJ/u31v52tK2rcqoPNZcWdy72Ykupgd2e9ST53k5bcwOs/nNgzts10bVwcFTgIkG'
    'fk5xS2L69aDfv4xg49Qtu+pseq+vOATTbliOvVqnXrbqI0zTYKTmcobnLM2iMhxLVnZQmd4Pu61OZi9WRp3VVty3Bv3eAEju2p4c'
    'WtnHTfX+ZTuZvMo3Wa34Ko+cR6XZT983Jq/5DOoYF1nrOX/Qx1p99yA5g155bFT2ypOrH/bt3WAiP7m7znDUuy81vaXXHdWbJX2Y'
    'X1gPw+brw1xarJ68rq1NXQs6CTu2ad3fVrbN3X7oidt15tUzvLJtTiojcXmw+ppVzD4UhtrUeigP8junPxikO5VBsz2tzVfFgT7R'
    'jKr6LA87aWdyL5mT9vBgyfV5WkuXN1bWquUrr49Z2148ZEbSk7WWNKkwmeWf2k717nnbK67aM3W53ezHTvOpn8kc9iNrUnRba6Wa'
    'aQ3Ezl3ePayKz4e+qO76GSWz6WyzVcfbV3drr4nBIXdN4G8bmeF+t17fPckVrZCYQOdKN3pu7W4tc1yzbzfVG9d9fsltvMp2AzRY'
    'cjpSY1pbDnqjrGQDT/j6tC4eRp2BWMxvOsV8y92tx+vbYnHWKrveoLyYDdLpxmtBVY1lfl9VmwpQ0Efgt8SOWq9trJeD12jdzkQQ'
    'pg+j1sYtp62iManbQ90uqJ2nmjXO1sXDoKOos8RztXc7yd6ulFbNHeSUhVNtmYWuNQZm835sesqjaVSazki2pUa+3JoB87FqTg5Z'
    '53UCPR+Zi85hmDh07p5anZFaTa+kSu/VWhXlwd4cFe/qK/upUbXbnWx5nTGMhvl4W5jvX51s5dDqF+3hNqt3CglLyU4WucfuMOP1'
    '7Uq9vnhZeA1vCruz1rHkm5zlVPL7oT65d4oF9bU5fbWtVaFRX9uy3RhmpWqzpddMUSkO0k+92xzgVaVpleV0Xm2U3Kq0qbfKRqJi'
    't2eb9pNVqej6eNwX7Vd7b412m46t7gDrve61rT5fL9LDarq/t43b12optwF5VnzO3OVMqTnut/eF50HR3Wj7tV1YKOJ0Jz7uWsuH'
    '5+f7platt542/Z1dM9zWIeOpu2EbwHrd6/QHzf7gfllZLpdubf46UXu9iagfxnbi9dWeGNJtATjW+aAytlPbO1F9XPY691UFwDPR'
    'zKdW/URp2a80BvmW9DqApTadRtF18s2K3hNXCWuXGYuPi2w7v1SiRY6LVzfFRmFQ0OVR3tik89OEm7graa21OOikqqXUoT5VW5Hn'
    'bv22rJfr5e66UdoVZJiDirEdLTtixgb0nTUSr73iIW2VnMZYLDTacmHd2XQXVU+yE1D4DkTCZ6lvGKvBbrp6dJSEuACRYVPblReu'
    '6Lle3WtP7Fe3MUgPiusGcE5d29k9z25Gg7p+p9++WM7dEHZoS7aXRn2yz9zcTO73f65/0rL1ovUkTdvd4qFbK1fFfqXZeHS2A/vF'
    'e12Xhk6llLDUpQM1yg/7gWd7iVa9/jTq9utP3YHd7E0P3fVg2C4d9AHs1bxay/afxiv1Ffj07c1DSQQx+NBNlzuP/ZduW1uRgOqO'
    'QEIFFFnXynemNZ7qq9EQ3ozbh0GvVZBuRafrTB/sQnNaz/czRl1T6ubK0LIFubuetRsL3VrJuiPv3eZg9bp+TVSet+5Ttpvt5aS5'
    'VRiIIOk5IIqarclqUFzKu0FmqZjFmSb3B5X082J+qAwf3VG+8LrIFA6jqj4qPw+f6tW5MSjU9rb++ui2Bna5Vc4Ue9pC6WcrLy9q'
    'a1JwX5/zIKFXKw1rVlw6+VlGSiiLHaxAwdANa2xleo2eN+zeVs3yoTKwQYwaKIhi+mJudZ/vuwtxO9AHD46eediWxH1TzErO4629'
    'cV9m4+rg3tmP993pHu3wt7tUUe+kympfl3bb591o3m71GhlxoDcrwBnsGv2B0r5v1JfSYefZVduugVwG/JbV6qiO1BvJ1sC86z9v'
    'ar1Ga7w0s7mX/PP6vq4Wuy+DZ8/ZjR6fhruXrreaPNhtQy00JMn2ZLu21gp1G4QAaVXM7dbVmrR57Feb7sPQaHQd92B3nlZjYz3R'
    'u93VoCZK+eUiA1BTSYtA3I1bpZKr993bxSoFeGE43KdcxdskBmJpN5KK92O5lzPtSf65YFv1vTutdPruxCgUJ+Ns+zW70ky7nlec'
    'jtpWC4+7krPWFfm5Oa6AqLk0JS3dNNXtei89FRo3y7VWX1RhyMXX9DjVW1jWZtR37Pv6fJ6HOUTQv20YTw+W9VoqFXuNR2/SbPbE'
    'Z3elSeWC21hNEo5avis/DVPL7ri+MmE7yhMx3d1t1nVF69dbE9PeAidTTmz6+UJNk9vlptqyK8u725G+evW0NUgEacP8H9b7Pi6G'
    'aa85TMvi4/ClA0JQazfOj62qmXcyNk5FY9fpt8cg+pdK8mwizlvuap2pjOtaMfNUWE8P8qQCgqjlJPYg4G8kTX58yqcLg1m5P7Bt'
    'nEqQrvup/os4AnJdvX3u9hpt1a1n1rahrIeTVf+1ttHVbGdfUt3ldl1d252c3MqlWi+VrDvMv+Qr41dvUjRUufVs5YA3G4I05UjL'
    'UVl0VCVrD/IbXdsepvKLZ5Xqua7yst23MnV1tbBfLeupBcLRAXXX8lDXpcFk19wOH7xi8W69aSQWUhMwVHYN/HzrLqcOs0/r7a7y'
    'Yg3HB7MCvR/gxCi9+s7tTg8tCZj87HLU269y5UNRv8/VUt3mICG9FMRhpQVMi1EtK0b6SXlaW7ddSSovit35uFFQoplb+fJ+XnqY'
    'WmjW35x2x6vs+PXFrZSPPjzKifxL4q6dXgymq4X13HGfzeFdwogmr+zXmWzc3z17VW80r2cavd7Oyor1hK3LmU77Abi5AeDMeV5X'
    'OpqbmzSVwRp4uu6hWMnozVlv9FpqjLuuV1ZutdFdz87Um5ldu7exrZxVVSTTGVmwjxvrp8zWW5aXE+0u666b5ja9B27lsHLkuiON'
    'ASrtfVFvDhp9aTCyh/Kym97Yg3TGbN8P82WrU37Am7awQ9b5hxejXTvU7spjyxk3dlpBtxuD8bAlpVav/WFLdXu9wYNkVJxKVloD'
    '69RRy4W0154bDeNmXc0PD8PRHUgRr5lW5/C6HndKwKbO7LZi59vPltcpGnLTeehu+61SSarrVqG+mJl2t7KsNHs7T9O08WoxfJbg'
    'jwlSQE2rqdvbKkD2f+Rf63Et7bSNmgfqubJtG3bozeOTuZKqr/pqO+qtrTSws4rRFBfWsJV6LejqZtMvjSq9rptxCzVAeU5zfjdw'
    'vc7mtTEqSN5iZHWM4WaRq2qv0uvr6PA4mCT0otdo9oa7orfuWro47Joj+9XZleziAjBGd7wF3risHu7X2U2i1NXW5b7emj4PtYyl'
    'JPLT7Gy8vruvDifVuucNpv29mlA36rZ/aNuddmXXd0e6oYuvcqUvtWaSPpANL71yHq3sviw1e1mnN5abw6o4lvGyhFuu7ldWLp1r'
    '5tYjR95UBqXX5b4Nskp3XTkMngC/TdapXWmhjKVRNTttiSOvp6b2pe3NndEIL8OIj8+Nm4G5m3brhVe7L27H2W7dHq9S25vFJrus'
    'VVbz3auua7A1R+mSsQFgnNvVad9WG9pcmu0StUZj0ihPXhtTRRronZty6w6YBNEbmX1NLL72VPHRXg4GZQsEt/x+VV5J2cQU/uiH'
    '1aPkjl6as8EwrRyk7LC7kotlxxlo5bqazr44vVVFz6vP1cG00PeWsDSTTCtjFrT24KlWSa3SOXU0m1j6fJV9HMiiJPf3Tc3INjVH'
    'aVY3I7MDQios31qXvfbYLveaFceWzV5eKw4PjU0WeJPNzar2eP/YhC425cXKXgH/UTDtx6dWY/s/AoWFlq5J632ho9WNF2fZak3n'
    'qUUnla09P+/0R/P+kE88JpqPqZvHWuTTa6dwU0r475K1elwBZaxmyq/1teJ1hpteudftgFCwKUmptZUTm1590Xd6fZj5V8cWzb65'
    'lrPzWuYuNdIymXqmm60XRFlp9DpPWRAvdiO709KnDwPr0D0M1pnn+rxsuJOnQlfcKO5T9TAyJAP6JCl3UH3+cJcdFsa7w3DX3Rvj'
    'XbooKgnLMsX03MqUpfKwqNnF/fTZLjmT3qxQ0Sd9c7/e3C+LBVM21J36pCmPes7obL3ipFuzrVGi3M821qnNdNuaGqN1s78sKPdF'
    'r60mUtv7jbJrPu1X+0Fn0xwZ1eeh4x1MR910cvn2NrE01Hpz2Z+McytU29QWQ6/XeejZnXv3Tts0Cp7ayxQW5Uy+IkpDpZ6eu2mx'
    'WC7e3NTmjVMM4S6q3c56sRyLRcAMeWcpdvoF/WU+fS7Wnx7lvCLXO4XGRmm8WOlEq11qm0/2rW2nx+JA61TWTktXXjKSVkoPNvvs'
    'obFeVV4zGbvUXNmOJGb27qSsKlaqvN68GEVbnxWflMlUdZRHufE6AHrerq3yh0GuIcL/cou+vJe94khbP4mjnpnR1vZT1i32i5ke'
    'YH6rtHmYtzKjRkUdrp4et+1xoVJopYbpklbY9bxCulDO3vZrktH3DPdQyJXzvRcnW10BB57N2mq+nC0X17eSXHXGD7vDqzzs17v9'
    '9GFc97SpYw87+1p5s+g5vZ05aR7SsA8qryl53l60nnX9eVNQhpUhcN75XivXMtovqd1wmq211HlKc1Prl/IjSIGRD7K3XMjrxWu1'
    'vulrs9fW9uZ2+Vf2SqKaykpzV4Hp28jWWrLqw+Zo3ypMHzRFstdaDcQZc9A93B66u6Zme+pSGTUnE2nhje2usRys8627jbzS1qOM'
    '0n2wZDuR723Hslt2F2reVUb9zVLvtO6Xi07zYXTYIMdZK7aXZavcXqnL3hBE7cy49SIWUrZcPDw8zhteef1yc2/fr/hxk4ZcU8O0'
    '5UqzuL1f6dr0zhtVRXHUkB1Zsw76U39fzzeNRGdfsHfTV9G0zFlzIM17zi5TX8pmJi2Vu4uGZG3uG4exsqncTouNblbNdEvFrtho'
    'ehowdla6Tv8VzM3yefai73sTvd0eO1nJWHfGUtfUVotCeth5rNlqrzw0rP4qnZBGZS89zBndYTEltU19IStPXk4EDHFTvrl5eNFn'
    'b2d7e5sxncdXYJFHd51hX3w+SCqe0xfLD502yAvaU05sr2vTfM+bNiuvxfZkWLc7g+fS0im39HFa0tCPSmf6Itlib1WYLAEd5wrt'
    'F30Aneg8Dlvyzn3JGfbrUNG7/eZ6kC2s9bniWlZ6AlMgb/Ss0q1J45v+A5CB0v61lLJFW5eGYl8d3tyo933y2lEZVMSOUnnJ3dyu'
    'M7elvdsZT4AcdcW+t/X2jWy50UqNlFQtrwwm5ZHWaAxbhb5S8JpNpTFtHLxm383kspLUEIN5XbxYq15+/zqZN9vjhjWxHm3A1Dag'
    'A9NOuUWpYRtL8dXJi43qztlnvHl5nlbnWbFnqONVyQJk+STf3E4eh38K1A+DkrW4d8u5LXCOhYG2WXl9+9CWjFJlL7VHvZ0EMF6z'
    'BsCalWHLtMZlG7jZ5mMTVRstq3svb+V5rmDbulOqDeRmw3O8liktBrVMWd2Wm4Ne6qZqGwbAdMtKtweFwZ1xqLzmhvnUS94YenV7'
    'YJXKneFoMwL+82bZ6j1Nn5uOV81IlYIykfaNXmbd2kivh0qilkuNatOd0VOXk57oqvWWUrhFu/rt6+P26bbYa403u8fHQv4+8axY'
    'xvMot1iU5Xmq2u42rUKmXam2ZqORnZerndLdi5o+rBqlzi6xfkktHqMNLNILSfUWu5dI7fevy82qli80h/vdc2c6bQxfCk+Fx2pi'
    'fLuvDA2nZhcr5dfb1k4z8/XqajCQ8qpVFDvtlva0KRx6Q1E9mLuM0e+VWm62r9TXBdfTX6SSah42T/NtsS251UEzZ5viQl+nndHO'
    'GzQreR2ERIAvII7lfiGdHllPUsudVDsdb7EYiyA/An2RVsCSyg9AYaZtZ53XZdEavE4O6+IwO9h0Ft1h7uZmsTzdXw/jkrnaHUbt'
    'u+fKHoilmsjs7QSIwIPRKlvTWqNDfTEY7WrW025X2y2XEzNfbaq7fR01W4NKR63X546dFvuz3EbtFO2Zo+n1ZTnfnT3kcrn9oGuC'
    'hJy9EweVm4U4ONhdc9CXxGn+saYVnnJ6+clqlKxnxVNM3dJUY6iPKlZxVHlqifZOfX58GHiNtQ3kYjyBCUu/VEtle/Ro7J4P4rpR'
    'ein21+229mo4Mizy7lAZlZ1c1TGbh8J6dLta3GQNr5srJZ5Wqrebao+SvsuXes/liZZ6aI3tlDe9UW7X08E+95weH1fdySz2y10G'
    'VlqRxitY1mzLznkP5Xuv134eTDObWWuWbSMQSbVhK99uLnRPvX/M3pkTdz+qj4xhbfO4ylhmNl0ubZaD+9tcZT8sVgFCUiBO3Pab'
    '43Var9zbzqhhrTPZhuWYwNj3OuqmJ/fq4oMkVj08Zkh3HnK1XrGV0W+L8sFsVtN74O8P4mCs5qf9/M3t62P35v//9wP9RCr1+vcz'
    '3zF1EEY8uPJD0cQxfAjexDHX3ul1m9Q7ZYbqhAUIJV/lGOfFD1MmsViIfz+be57lXqVSqpHcakvNUhVNSprOLIVvqWfNUP51JVnQ'
    'MUeVFAygtvaEFaQKkOrfn5H80GU8tA2LKxo/7eHcObm/xLxmy/oa46NsMZIW3l9ioVGwlqHpkLPtZ8lZKub2/ZtfJ/6kxROH0ll0'
    't94gJ92/srmIOj8upJPpdKaYLpbT6XThyLt0LldO5jPlTKmUK4ppsZT7T/SynvnePTDq6NvrXl0W20uKxtej0K3RW3qN8L4W9zaO'
    'c8jjXNOtN4zkobMw9ixeSRi0jtzwXgiK5M6Zg3PF9Dz17aWxyUcJ42REXK9LnqBqFKZKNZRj1+3eHMDBCAOvYASif/7b/3VjWfoe'
    'O8AiITJf8P/8t/9bYHHyjpIFiqAVRosKYInmavnOXFGysDA1I+yysadQVDwET2RQGPFKoNtugqJNQZzAgH5hhKOkcDLzPOCbX7FC'
    'Ac/Y1C4FmGlFV4+CKFL8sLdxBdjNRx7d67vRmyLXqSbsAl4YOipaNCncnYT1xdCve131Q90dV3sSSoXl5/HF3o35duIBPXPiAf2e'
    'wQwFh/5rWytfFpOFdDZbRJ8MpdIbt+L+Hv5rjtup4dAJMA6cuQHGbp3RTdhwLCf+0TMn/tHvCepPx4LB6pKZdD6dzZdLmXw26qI5'
    'ny8ky7l8PieiD/1cXvzzsfzAx/T3xkLdOh3LaTC+E6/pFNAmiu1E6H+ylM3ncmK2KOYKR66mMapTLpspZtCRdrr4F8bxI7/Mx+Mg'
    'lEGe3403gzjxop458aLeQxRyuh7Fci5ZKAPclNKFdCnju4tn4yiUkulSrgxIO5PN5MXMn47jRzd1j8dBgSDIEzz26nQkJ77WMye+'
    '1hleAioKSI3t3hDPRMaWz2WTJbFQwghgabFQPto3aRx3oVjMZgvZdPbPh5aZltVc7mRoubDLJ87WMyfO1nMUY1faAHKaIsn/VXDn'
    '0lGs3UI+lyxn0iUxLxYy0NlIuIOMKCZL6TwsQT6ThU/ifyL9/M496iyG5QHi5hOFbEAUeDAO1w/YEyBDHko8EspO0zHMLcb/pBC9'
    'cwptF4YWuQhCsRNGpi4ETIyPiSOh089dwZBWKtIxCtNtWgJRAsK69EV7w8pBx8cYQEXXgAg6+7fDica1wXjmb0La0M1n1mu/I8Rb'
    'zWkx6Yo1EIWNpm6JxkkOACUuMTGKikuxTDAst3sRxK3zL43DqIMb42z473S/C3DyzkK8F0fGv3ccazer8QhpZpFPkBMB7g/5ir2A'
    'zul/FMyF+MVYUjHlXbSmLezWOfFLNDCfq6ya5gwW+N6UYb0jIRFxWYP4NBOVon7OGdfkXkQWHZ8Yc01ZJLyD/6Pe+VxsJIpjGIXW'
    '0rEDkeBY+HntUXSZY6bqzrT20ciLTuCCgcIuRkb1fqCYPwm+mDkJZ5A5CWfA41nhPnL/cxCBj3X+cgSZzElIgsxJSIJHWI6rE+BP'
    'CC5B+X9Zl38ciCNz4p8ic+Kf4iGQeWAXXDAQ/VVYmf9ZyPZth9+n3mGHT8SqzIlY1dKRZyZkKawtmGKFZIyVq+r/hYDxPqkOY8ae'
    'cKrZE0619s9/+z9XwCZjxG6O16LsUSab/h6XdyoM5v+UmGEbb4hZWgYwKX/PC0sl7JYLshB6/5io5NmDpIV9iKQYRsAAv7jvQaTD'
    'kMMUfnVLAdQR1VtrojirpHDD41m/8euCDb516nIaJ1pdWR4PCsyqQLmFggbz+LNJgYIZYxNHLl0objEPdGZhJGpzykIi87Bgx7LG'
    'T7SIZ0xEZ8t4lj1h130QmTrmKspimSHnecprcsg44ZV93olXFACKGWGj3uG+eWWnsYmzR5UFvmewsgIf2k/ffk+5sqNZ3seffvcf'
    'ZNNwPeEX4YPgCh8+BhH4kvYaUBeTPE0n5saveU53M4O8v8TO/yZLxkZyz+MXSK91hafSMya6HvrXYYn0jIkYLxzWlqWyl/Og6kqr'
    '2YNP55cSCOfqpbt3PXV1IdzicjxLcpfeK7C8F8AuzExV6NcuhI4Jsq15ITzipvc0WRKa6hr4ixtHk3TohWS4l67qaNPz659SKeHW'
    'D8VOwduQFPOAbyxM2xXGbUTwQ4UFQDg6cUE2YAUvM4wWCMK3ivVOdGwE9pk2g8attWOh+GxBT5N8NO2bxkOv9wAD+nzOqcn5hXDO'
    'sTQ9MvxHjwyr0CNjmOmR7VV6FMtFUc7QY36aVWSWoSxnC5M8PcqZTD4vn3/xZ7PTavX+tVJrNHBKOQt77n/s9lod7No5Yz0vOYm6'
    '2ohBltpz9V+7tdeHLmT7KnRB4klfCM+IouC3gSI4/I4aCLhp4Vu4hp3nm97bmoNqoUcP/zp46HRrrSZky10DmMK6TNYrCzam5gox'
    'RCsSOYNC/zi4gZ9r1c5NDwp046SiQ7LKYqpKGArPBeaB8W88wPdPP6GjH0AN5PXlA2FG3k4kYjUpKmIadAq1ioAXfJwR/4n5CTKW'
    'dxhrz8Ul/MLL+4oW9xxjBmI1MsuDG499lQClehiQfEs+qZA7woCTOCyuVpzChMC3sJ2GBEgW2/n6jbdDndMU4fIjR6eoxdExm7AF'
    '/hBrN4TYV2F3IexhA14Ic+Eb7C9sjNfOGoQtBs+sISxNgXyDGYkMCDVersqb0JDpxDq2jgZ4x6DygBoucPagOKw88u0EGTtUggh7'
    '+rsE8AAEJcxUmAwcDSRpyp25Njz+OmeRs6EHULyrejHY/Vj52lDMrocRE3GyLyh8avQdHQD10BmX3/sLCvkevPCBBu868KP3wOhS'
    'Fz3oHIIoNoTswiMpyYK8mNREKSioWXOA2nwQppLuqojJgAcaSo6hKn7i9U8cnBV1Kq11D9cuFkcECmsCxGouuZrLY1pBCUX1n4mZ'
    'vhLOWRRH2LhbR7LgfQUDWK/gXVp7Zg+IKisAi+pvnGHnpk2jMYi8wJCSxQuBlUPdDYaIhGbEZB7w13R6JdQMkKY0GEiwOSe6RPsh'
    '6Ck6NqspVNpVPZxA6Js/pFj8goH6Fa2cYSrY869CGv9oCi04cjXQ++cgrObFETww3oSzJgKyJThUyAz5iCO5iqCpb/g/GG7qN+Ey'
    '+EfwyQVkJgwDiK8kj3EfjOujoPYRXjAsjTRwoDquBuIo4BZYx70QI+0HoRbodIhaBMAgIJwhB7HhRUiYwQ7gPMEUMQ4IHbhRT5jr'
    'M2xjQl7IPAo8j/m30h76hqhLAWzA+gos35qQlF87BhOEmlWFNYobAnsVvyJFD2wkAaQFyMK1Af5qhUvF1wSmjbNEQP5pcs5SZ7yR'
    'M1ZXRgBUCQBOYQRhWfS1y+fx6g2ips7y4owbh39ZIWAKdW2jcnX1GU87E2LAjyE3Cd05i1/TNBnkAQ3xakSujTGIiAAEqx/+MbiI'
    'U/PIuF5OdVOiPe23/LawcI45gYPweTZYD28LZFrg6vagdl7HtWDBUOkQgmmnKdwpr55p2lgPSH8BNeJYQGzHqKySDvwUKiRguEfK'
    'laARxDeoTrlgyrWt5iLe5toXgICpBxOCiDyckXhS6KAKBsfJ5w+gCCBtpUoIjQjWQf2yaWnQUWJhQdi3LECT0zU0ssly0I9QM9Q1'
    '0CELsuSkJzBdQulzpgbac/Z+aZjbJGsiJ/jKBBi0DGhmD1B7RiQBxuzOSTxEX4gYkxgBOKAeMIxuAGDh6K8pAwemYBgzkwQ23E98'
    'RMSRh93hR3w6o4qSS+cJE4A6C7eTEh1l4NGRxAxsoma4GhMEaYakQPwGoibpsDPd728ljvAAY0KLFZjRFJJ1fABsDOuBtD0p/Jb6'
    'SQb64gKnuVUd/PoAGNkB6g6kEnYze/v6jWPdCIr5QCy7CDiWI+BkMqlcBFuRMU8Xkd2HRB1KZIISNInfzZ+9CFC6kjwdI6aF4w0x'
    'O1UJnAAq9BC3IZQgdoOthioxLkel41wPxWJRTzXHjZxSMQDiO+lKaE0WwGMlcfIeoBZY4hhPUvkrdI9w1z/+AV2IJ1eSFYt9XkL3'
    'vyBt4qCCCV0PlXixJSR/AK4yfS58EmjejB+RF8CJV1gXzR6bw+zprAezlqMcQCWna4PiL9Nm4nQjpsShPUdF6iAwr45Jza0ZnjpT'
    'nZjyKcmriUO/FP8FGocvbISfAJMDMbwG+Suof6UBRHpqDF0IxgkmkDXZIHcRbRm/XsNHbSrENsLHI945LqDvyy2RjWM4jJ0b+H4e'
    'Kfq7IEbz+9lML9weLDsLLE4ljhv7ipRMgg6G0Px584V3kXqOj/74r+lMAtv+mZJ9FAur7e0tFfdtNPlnXFmTAOT8r/WTrwfWcv2T'
    'v9GCvfqBdxZ1w7BTdO2gRpgdavqdzYHJJ/jg6qifwaahRHq+YCpqnkTPEZaN4RDsDge8727c6GRfIHzCBmG1IbT7bfgNCLhv49/b'
    '2W8xQLAv+a4LB5Lk+C4eMLSNWvPhX7u9cYMEv8/ndCiPAiY7y6Qn0kWcA1d+0+m0hiyfATwMfgQMiD8g8TsePoB0Psesw9p975Fl'
    'Rc0NfmKLg090loWia7BDZB3oH1oTxHQEPi67IYE+dyli/RXnn0zjkjOswkYCoZxZdCxVy/sJCSYOSWaCFYdIXfj11+gok/zgxI3p'
    'SeIJ4nFBZk9QjqcdFWajjpYjjpzK0ROVo6ejcmwKouXoMI/KsfjuWI6eIjAuI4DD6DvqZK3pSoSgxUjmlAhnMMGBTpaA9qA0JbiG'
    'ZAGh9uIwGyrRSJqxrarrlwiIQEjZjCWFCjEPQPWxITpJYFUbexI+GQPLdSaAdoGRoDD1lBwcRanEkCNx9ukvl4HPkeFxlmuLWGiu'
    'ucOWgCKDkEMedyX3UoOOhDY5uIJ4SEb8BknA2JgrgUQDjIVypAfYnzuqz5M4XMhWlWQITSEaUBi65bos3Jqfgq3DiNEFundlHyIk'
    'yue1fUhiFQCPi+LUBmU8XZ8wcTVN0lVAKioohKmxxCaOMLAhZIcEK3w7R5qW2MCu9msJW5irO6hSxhpT/+1vn9OXZely+uVr4dsv'
    'KS2JioaYTAgRBf8YK/J5qe6RkCJ7dEJ1YWTxOD9JZpk1FGlZX2NQjurimPsNsdNg8mAyoMjvIE/D089GBKMbJ2gc6odZXavXkdbw'
    '5PGD8LZmI8lIeTyaWebsEnVI8WVNv7UkAQbxBC6xCDiJPBW4ACaIwvpA3bs4yaPsZR+/4HX63AN26hNbEsjEe+Jn4lIqLAOUpZc4'
    'tUOPAisMC2kkSRyhGSCRBDKFku2Vrwz8DHP3L/5LUleNmTf/wpr6Fs481IkogWr84Ff9IVo1f/C5nbCokSQ1JnQkgLE3gMjzENph'
    'uT8IfmK0puB4jtpGbQSWiKRSWqTb/sqgp2/W34lpIh5HaOCp/HO0HR6WPNqIn3TSwjtDweNY2ljBs0y/uGl0aWXFniVvngTx3FCC'
    '7BfCJTDKhQisfz63NF1n5GpHVEzXNRgk0SaAqPMvIdaGSlDIYVSCxB0cFD1FKwzoJmwCIoQUsv24IozmTvXgA1WDD0dzs5rh4FL/'
    'LXQ2/fdUzDJm/0CX0/+YadN/bNWJFfedT3+WLg+AIxKpD18SAYagapK49/lE4esW+Ml05H2O7/Fgw8nUNKqboBxuC17FhbC9Cqq4'
    'EOZXYXkOwazrgfb4M31G7/9f4qzWLlueIJ0V+/YWjtgR99EWp61G6VgZz+AnRZEHifgfImyEgayOGsVvfOtyFAnIDygyZuH7Ehvg'
    'teAPK0hEAHbxF6z7mp2rIGtCvvP9I6fVGjuAAirTAUmIJS51oFa6nwUVNijizkykywSeqI2SkLWxrkkfxGVi1QWpmDUSA4zDtLRc'
    'EQL0c6W5KK+FwtnRyaIAUsacaCSpquigznS95DHBMCKUgnEEMRrnCalw1SPFLS6s8oVPKNWGMoxFy8H6dw1vPrW7Zl9o+qwvProP'
    '8TsuiP8ViQo2lpxLbszCXgRVBqprHytyVHgtKGRRKLBlvhYmjiotrzlUCaw6SVGguhDcAhnlvbEnXZjOmEFCRNB4hHRH0TLTXIV8'
    'KtMySAQErkerGUjKp7SX8NNK2sUuRWL8o+DIe4LCMUN90EZCEN+C4tcIgfxPUsb6wB1sp2XI/LxhNvT3mA1goFgxJuP/h/mOn3XG'
    'c9C4dVIufDlK8Ux6Z59oZTDtfU6EnXN88NkJPckTjvkJnpx0VEuXZDWW+rubSM0AmQvn8STkWsUAToBSqTGYXzED+BNZD9YOjf1o'
    'fbBbV7x7sFrmFfWPVj0q7jD5DzkOPeQ4vvpLxNNCIRAzs85jLvbEP56uIoBZ7Qjm/hTe3oAkjeoYJENmlYmnwaQCAPCU41nlcuxf'
    'm9VMOjKrXCRigIQDP5GRg1lhO4QLwsFwkQNEtp6LxSIMj01JAp9/YojCF6l91BSe5rhJ/5nQGjsd4rnYGY+bxN+3X/mpj0vIKSRp'
    'EpqXET8XvkTOhnhhdkIEEjZJlMhKBIdF53jmg7/mdBplLdwkFkK4YU9C5ISJ1xqeM7lJ/zngwThLehEiGq4yIHVaqHHBE1xN4XYD'
    'yQAj+foPibgadtp0jGOD7IGuZKkpblAbFAQYAGbIQ+HgDQ4GhOAX09yOaRJZeBdT+6e2ZPEI9PcK6GOAilFYPCKXQZ2EQr9X57v8'
    'ftgfsqD5C2U/vCmLHQsPEo/mgHUJiZLjxWLShTBhR3gS5+A/fRKkJOLJSyE2CdMmmBaPqFVgIlrTmIGkiqv6gi76lDqOXReaEZnM'
    '33ak1uOK4uASiCCxmtFmg1T5gNboaJ6O2TVuzPOOyphdtvHteGBPBaY8fDpgGwSTgcfOUZkmBgkE3ioKbTRxsfjnNGwBJTJaRbW8'
    'ORstHWCjcH79g4F/fTt0JZGAUQf6xiMtrrueeLB+RJ++chSITN0HgTZByBRprGEN5Ga8NMX4S3hPJOJRWiojEcV9EINcn7UvQDIx'
    'u7V25zEZVzJYCUjGnvBdZszutekU5yoAjHDAhPykiRuTADbg478IsYzwG0tu18IqFeD/eSLMayQLFFNQn30dniOTZMUVH0GTDMtq'
    'RmxyEWJc+LpBAASoeZZkV8DDqn/+L/8Ht2lgJujMzod9Q8tOdroG1IZfZnHw3AZvfu0B1mRUC7G7PvFkZL+isJiCn39o7TnwW/Aj'
    'KSku/kgbbSZ5ppMEcuOh5gu5hDAV2nVuZkz74KspoKY6kDukZTg2L6RV2MO/s0tmRLNgNMxGDWjXSabuXJt6f2ek7Z//0/8DOd/m'
    '8esIraCWkXbZyD6FHYp5SAw9mtAbJuRoMh5Y+NYnruWAmBm19OanhRaIjtdoBedJS36GwxR6fgZ37ZAcQodpQCGD2cX6PzADcujS'
    'H7+jBRidf3040+QzQXI06ZKZdXw4Q+Jx9vF3XEq623f2N+3yl69Y9ttZ6uPvKSj78Y/rn07O+JlanM56f8WDT+gKPkdy4JEbw5Gy'
    'hwqxwExNBsDw1AddxbfYuW+Tlpyp3h2wfTCO2HlGCWeXtLkVMkFjdIvwcJpYiKlL5nzCdIvGTsgx78gsT7D2aFFHzAXLLwb5xSLL'
    'X/DziyWeX2TMCMvFa80HuXIsVwk3Fazl3RxVuzIayrjMZOjMZejzjLpMIh7ZWxJqJTNGdqLODWq41jXUzvjW40luCyXfq6rFjXDY'
    'tyAhqnbHHtQRBTF2/ch65/pd6523oiRRLp/dZ3qMN6jWr/iz/w3Z5Ng7qbBV0xGp5y8Kmk0Q9AIhk1RHmBDMDuJrNhYSCg2GXCMy'
    'IxfrkdIpME0qCfQov5NUDjygwJcH1eF4CY5m1Kd8nDwgqDFlNuxKOq9eo0S/NdjFR5TCo+ty/XZd/j1z+yGY2/fknQnUyKon+n9B'
    'tCGgj5f8cRKZ6bAzn5GN+BKVG958g1UC8VWJ+/LGn3b758hS8wr+dCS47DgOg/We95OT8ybwPXzB3yPsEwKKySlh5zy//P4wjz8c'
    'jzHkhJhFqX9ObpJpCawgmk1vT9nNCLMZZ7BkcPtq5JwiJxaRtfoBr8Z4IeP7A/8hK8fWZ6O52oTEtnf4TuJif+ZbBdUxxilHOdV2'
    'XVVHdEHrGmHU4n63I8WRbYtzI0LGxAVbmCb0Du+Pk92MREYIRNfEjGCey/gFNhOpynCbhfMaezuxaMDI1uPd2aXKbrAFmt9AgEWy'
    '4LPIwNoE7JMnGRk8O4CN4iTxcCW5o8cd7hefT0oJmYiMClz6Ka+FmaPvb3gxBlRDdtrlD8BFgyE5nJcVGuNjGi4bE1Ujs8KtNnD/'
    '0QT5ZCBikoRtOCqwQmjIxQ3cFM3hWAtr5mBkmRqRI7R7A3nWYACLoqqiIGaLrIvroQYbpRO8ieRgZfo+Hplxdwsb6Z0Zt04AlKvk'
    'mFhHyj//GDS6ZKHKYcaQvV/+O4tmhYtm4aJdRrNYlGWGWSzKMoMskZWMZKVHF3hcKc6ZXNkEzjoeD0Xiyb67ZQg85MYjg5ew8cj7'
    'JOBMJvsWP4z5d8p3xEB0GTDg3U5mD0lZEAx0aY90h3tsIAVEUhiiwSCK/Zd4gUOgdT9nXCFZuyq8ghjxV2i8BW1QEolzEl0idchK'
    'XmGBdaXZDJmU61PTtwjkuijS4TLpe2bA7LOYVDGdKDHxn2QgGBkTd1FX4KtlQlXFp2DCrvw5D6YSFTzBZFqoelN3KDhE5JRQ4UqN'
    'Wdgax3lL6gLMLOFRXpI0XvxLMP1LQoaMZOIa4MyxXcjGGR08myzkUulUG22t2AzjGiHR4OeOdIJNpwk+Uo/gWkByB5VGRj0GnBv2'
    'nubKn4kk1PogyfNYbHkhaFwkXAbHfdo1mnxEZVlW9Q3gfigpq2yLRqi4FaHiuEEpF5JE1oEk68FKPZ4jnw7Fj7vOoPbbT8yswTXx'
    'ulaA8ABm1OkUsdFG5ZYeaLPpk1eYGkfDk/itZkTtLImBgaUI+WbfjjkygVjdMf4hoCOdTYxMuNBWy2eL0MBGZsJGCICBChBIr+Kf'
    'ocXecjPAtMLHa8ZH3hIv4AXcwjl6ZNhdBEwkMYl4BMlNIUmLSLSPTk3pnu5srUsOjf+4IvJUwZphcxBDbj3ti4BM64J1Mw72AobI'
    'P/mcrc+w0vc4s3Omjz5vQ3GKiXNl7aDR9RqAYR+1xATBVmX2ugjNONPXeI2DhZOmphzOQzvqJWOIfYSDtUsT7v0hXBqGRmGSUeCC'
    'Wf45ulABbxYySgGXBmsoRrTSfiUZrASX9JMQo8o/QhI+A1bNxIF+s1R6uRJI7UwSRXgKojrHiF0CgItNoASg9d9QLI+y2xGt36dA'
    '7kQDFF8qxOpiYh5WJBdn8mHksJo+gnCZi2PVoi84HpdBEZJSyhdCiav7uS2c69NBVt0kCSmc1bDMbUxMYiXsQJyBa4SoTrfBQX2g'
    'EoYxgExMFhJBOum44UOOPkTYUqRMUMkVn21WEJPCNk6OzrEPsVC4pnN41FrTuXy0a9GT8kihNGnR6cw9IqXTQSL2gJ3CY4XsGD5S'
    'I5rswNyksH9u9JBBIPNAGVbGxdUBPEpWCVfCzz/7RgsXvkU99gaAQnJVGqfLNOce7ISrYzhA2GRrCEuYxDV0tydZuCUK5cokYWUz'
    '/GwC159PG+qOyTAB8heEq+OVtnaw0ksOHu8UyL8psKcCTLMfGqmSIuaEX8PbZByL4lyhOgZoDSkI/vjla8O33IAZ50806eff8Nt0'
    '+02gX/cbdPGXr3jf79sf19HjqSFur0YyXNNMAUHHT0HQyGQxhY6FfsO8tHaNJM49peA9mc9HKBtPQBhiiCw7P4kRAhuLn7nx0Cfh'
    '8xdoAAv1UH3Ek6E4GhVhH6O1zI+3WYNtMzGZKUXPxbbciMDlul9oJHoGxz4hh6EjVqFJ5bNPXSBAp9Mx32DwipEWUi5v2YUsbU5a'
    '5p8ipiOhWhpH+o5JBtX7fP5FSEUOyXzbDm7XAXwCNREZpW9B8pvg4tf5e1/n/Gt4+jiTEHlCXb/+ejoZJX9AXL+MNWpIzbFM4jj3'
    'bzDp/tiDfsmqpseCIXi4WeG/EJBgnI3kO1sBQSlH+qUG2zaw1wRsXZ6zNNwZGX9Sw/rQhJTX93NQXzzsD/YCOiDm03HOAnRwboDH'
    'pRsCMjDkweUi5o/J5TcQSZxClSwCXWxluh7nvNglHxd5Q0nn4EsmI4giiWqzhvBIkF3M4CwTsCWaznlK3/cTU/lSG1rEUuEZcEzU'
    'gJMLDCFNfoYBAt3Yz38A0DB1IApfhCcPlywFJtRf0zgJMrB5LgXcMXH6fBVC71HV7871m1TfYuvYzKCDS0lj7oBctHZjXxlCvPIL'
    'XwgKoRdYddpCeKJOPNYHHCR0knX9UujAB8eka42xDgqQgGx+oy+U/TcOJqz/lMR5QypEtlWn0BFCLiAIphpgVZOUaQM7j2Xj8Xig'
    'VmNAGIHj01Efb4gtQ0UZ2Ibzow9z+pDNH9lbLr+zpvO9BaI49pEt4jOxSvQGcxLbz4M0mqsQO7H+LmHwIimx3vRt+W7HlvFQBxs1'
    'G+VgdESiAXk2+KVK+IElxK2/ZYuJSAB/V7Mx2WnCxz0z2Ez8ELkw6PXmV+98+sZ1NFXgQ0EIRUc1RCmYmwEgX5a2wztLMTqnIEMw'
    '/+wK3d5EtuU53sBD8Q5GbwAzjSp1tql96+eI3BIQI48uIhIRihBlfuj4BfkQLzg8ekNGPE4/hN8/UBUn+mWQNyUf8yRdS9e82Pnf'
    'mV1ToH7lBnG+jUukNE0FlMZaeOmUkEjFIyaFATdOtXxiPwkkbPCXyl/RT9SOEAcEHacjXNa2dx2qhQP7Lh9pRE5MI+Z+gl82WjtX'
    'ThJ+40v8kcsZ1CiVj9w94NeiqJ+oUvTN6sIlvWInCMAnBlfd/NPfaCuXvuY60gvtbduhCYwWR6H78jIsdTTIo4zXQsRmkX/Rgmn4'
    'FjG1fDtR38KdhQfMgUpLdWXfPYQbnl9+/vX3j2df8PxS5rdbzn89B17vV2llXaNNyu/0pnv08pFeZuzljF7QTej1ufDts/wlHqhu'
    'nBmKTmT1/jHgXvB6EcCVq9YMDw2j+LjQfkcshErtzxvhI0xj4UKgh5Lwq5DJ5/GNHr7QCXbkDtYO64KdDv+nm+XRLYVqROgL5oBW'
    'JvyN54N9hgxKoE1ifI/0WftC8iD+gkiIJ/goFUZ1iX9gLb98ncbS8W8X+Cvy30z8W/wPjlxugJbjVVE02QMpILwwjAwCO7QlkQHo'
    'y0zbHB/mAvSo+hSFfBL+UZRA10yqHsEmLIEPPrx+9hkahNWcfIkMnZjSDQ50g2gxn49wtatdlJ7xwmhSZQTpmhFJJ1sgKJSAHHGG'
    'ZBVUv6xQ57oyfJ5uzthZVyK5XUF7MQWJixhobYGlQFqp404KqQ2iAAWk6zmrEsmjg9J9bMYMH1ICfv0XEpf49xl+R/HdYZ+JCF8J'
    'MQeVwEFSLiK0ZnAjQM9+Y/1JJzN5WmIYHX7Scf3TyWIevuknKgHcQ+8MIsNHAdwyTAi77PHbSUYgi/9CpDcTpwcqARONLeKb7NNF'
    'bpPpgHA5g/8mIq7l588gp8JSp4E+fIZfmT+m6XHHH/EDz5DmjzI97r58+RxjvPUUJD8nNqdZRJ65QE9fIvB9/jfE5dEOhBAU2SoB'
    'dIgRWxF0KoHAQZOBoJb0TH77E3Z50pKULl4qi8E0naeBLCXRv2rs/Nw/N6kwzTf5QENOmh/J0oHcyjQB85KzADrZCI5sL/iJiSLw'
    's4/vHysl8biPXZCiraaoFjHzdKuK34VWNPSNLKu+QQaACqv/6lhph4fAvvnF2mPnwS7X1XFfrNjSNPCTe7KbkWWnEjAhczUolGRe'
    'hi8CTT+7TU+KRYkKg9QRMRaRVjQgf15I9UdXw7kJ80rygOlixjqUvlJVL0nqyaa5RdEBfTqr7GQbmQHyreC7PoGJdGH0aizOjBD8'
    'YswIARvtqjYzjQrUirQ8aAoI87gH0UWz16ogyY7pBq4Eee18xtGuBS2G1quJIWmoQDXNeESvDW32jlUY04jlwNFJqn+rB9NCS2j4'
    'wDv+mSozLa5q9JHOz1MUL6dJB/cs/KTZdVv/pJVrEKOHSe9AfizCarODqmlS3qEQvmfP+zivnTjtSGvxuL8BeoG611eWMzHP93DE'
    'tbkGrhteOiUJD3YHOs0hX1rcCBXdh8AGmq8nyZOJpLGH59E/a+7jehKLnN/F/+TIOTwPnEN9/vF2yBn6yxWUOtaMBdeuOAnjCUjG'
    'wgNtzVi2jLdMxHvkLWgGEHm5DGjHAQSUTuZLRXie0bMo5uB5gvxZgZSMfxMLYlGckF7rb1P6d37NzXi4i8/AvZTFlPUr2JhyLC5I'
    'imR5boCbfAwQYy5GJOdyouMVwjMQ+7wz/ytzS8I8UWoGeaIUVqaiBuZvvceH5wfftwDlQwXzZBbpH3ISFnq3iqTANOF7RsmK2dI5'
    'efah93whq07OmccdTFAmapEK4JKh35mkmGHWwPi1MClmSmluVSxfMV5QxmvReNUghk9oqkHacuS4ICFZLMHMJtMlpI8XYZfQKEVV'
    'LV4qWoJypekfSLpklozTEA5TzIl5sRQdpjjNZDLFcJhqTs2r5XCYBVUqTdXIMEU1KxXU6DBz+XCYUkmaTqTTYRJshpgCgUOeKlk1'
    'jcDxJ5NQQHqeFP054ED1J3PgzxTOAfdnJFlWDyEsahTnP3CzuCReHnMBcXssIyoOcP7I8pw9wBgJcpiTtDumJXJIZRL1jIWUi1EW'
    'dAciOcHh79Z3OAWv9BnN+MnHVWDNG9HCCMh6wdBm31PJHX2gowBg1GYRJbCIfFox7iuyEaGiypGYyllSQ91FJkMVMZ0EDesRcCAQ'
    'TCGGTrPihAXXHum6IuOTZA+lcT7MC3Y3C918cS0dedViWpfQ5y7WHjPUGbOp+MBVaHFOjkmiR5WfupPQLiIgqNADomyQ5aA6UQMV'
    '3vy9hvarxJztoyQMrR7QxxY7bgSY2UUtfZF6sFuvaNIfpu8pfR8YWcze1yT5BiwRigT1pzC/r/SBeundV/ggQ+qfLrG12OI6zOPH'
    'jKlzqo2bQV022XMyuwtfxQSo2sauK8wyw1cfOqeElPUuoKM2Mq/xCGG195gQGOlg144y2/s4ZkAJgNPQu/VEk4Xb//7/HjTYAdy3'
    'm+QKn8mhwQWpHhxTR0sw/xFADvjALz6gRw8J/T0cIzdpUnJH8iGRdwntUGjz7/HLnn3Z05c9fSGvDKFBmHq48WLtQGILxVQ6KGp/'
    'Rp6+/Vn8ckHiyCT8INKHDP8ghx8y9CFLHyIzS1/pjz+EC5Y2IYEBX7340UkRqXtu1cN/bffCA/uTzql+UtjBlZ+Eth8n4/v8mfUG'
    'KoCvK5R0VpRLZu19+RKqPtz1BMaFy4lDQ4dnDIsHIz4aejrOBkgcIKIsD5k0j7Fs/iOeLEP7zGJElgwjFFq46cjGFx+QIaIHcyuh'
    'R2yPzNMuOP6Y+swev/n5ERUCMYoN4ahTwB5K1HaEEA3KUtDRKbuLhnfQQvEffXHzBgPFoK++EunywgchV+K3FqI69qCbCby6jlwp'
    'vCAEazBsKBFogqexCBDHqb+hdpC0iyYqeqAf6CeQVH3+7Sq/M0smLixxgqEvS+qLr4+gO4UxqCQBxRnqOW13RQY7rGVqAhKuAZ+j'
    '50PTf/WVihxe5lr0hjKfJu9EYeaZgfIGeQYkJI4ceCPDwB9MDkRn5uYWnVYCgSAZCyjmH5D0h/Df/3fm5JFpCWOuNjPQucaSW0kQ'
    'QYngA3NL3in5PoDXI7MWRKoBouGEIEAvuJ8DJY2P4TFTnBu5mnSdhFu7zYwY1f7bCRJFksI/6OgYNZdJR7VDvnPIGEN7E8R37CiF'
    'qAf24DdsiBBgjGHACaI+huuJ5ASZmGmDv4GliwAFABBnIGM2gqMiSZMvvmhErszIBIv4GUdmlBw9owRyEInrztpA55dzjRtUTtUt'
    'ytfRWCdhUZcumPvnaT9xv53hfRVSlSpC7A+8dGH8ceWbVAbbfQU8whB3rH+uh6yCajPjGqobLRqZ5zWsmhgNvxeyjnfBPXOm0nUY'
    'EpndQIrzvQ5yXTUNkK5+SAJedtE5qvFd0zN7HABYT3XI2A+PsKRAoRGBPPJ7ip5VY9aF4NtgoSckHCOdQ5ySAIIDC+Fwj797dBE6'
    '8dMNno6SbsSABVUw+jGMRuA5Qil/F7KZNOcbQVzL+XrECS6b79HTldE070PgE/Pk6IP8/05JD4ZVXAiX7CedzNJzFh/z9JjHxxI9'
    'lr4cI0J0z/nOtgyN1+fsdCZ9QdKef1x/gmsz7KJYNn2Eav02UF8SYDNEsFkxfoQl+YkQeQCkhQlreMM9mr4aIzxECXa2TZNt4q79'
    'PcKZiXSmGcm1p1x7lmt+lCvKxALVsnHhbJa1xG5geC5a4Z/c1fd/AQhZvBKXBXIITaIRNnXJYl4oYSoBXWKUIUYWDXNiwtZzVe6O'
    '/OrIkwK74ZI8mlNmn/5A7gSifbaO+1xA5HjCmB99j55b/RxWCjNBW4PZR3qBKhTnz6NZttksi7mjufVobnnlItqBIdTAhEWoUWjd'
    'QbBFhmJpWACCr9+EXNpnfbHCY6x9ybYYsy4j7hM2we9kdJNOpslnXeRWvgufaBPhwvm7yb32d1k7PLLlSBo/hHwU+du6f6jc9Bs9'
    '5lAab06iAE+GcVdC4C+FO7f1/YnRgeVV4CsMMQeTycOSgWOyPysaXmAkT1z/Wrm567U6rDeA7xF94HERy09OcckvGfrULYRl1wZ5'
    'UOZCZETBdIKt2Hekp9fheTXgO6JrhPGIDKKvSaY8ahk8PBoz/GSgTifL/BngDSSR7qDK3WnhZWacRlYq1r1kvCNggZAGcA2U7zMM'
    '2+F2UXEyNSajkj9wSv/ADxd+AK9YWAXaexvEznCP1/y6wRFJBDr2wCKwgVALZM8wmFTM7yN4Pv9DKmb0hs0UzHOiOoHikWxiSId8'
    'FOqMlAnM5xd5wiY1tEsZiVT5KgkewMSfEhK8cc/z8qTx1BxmgoOEll9nY85sw3NclxyfSUf3F1DHQf4ZGM1jugGufETTswt0EutG'
    'Cd9XNpGBF2m2OD5BYriZn9qvtTDbnKDrnGmqmKPy0BG1qt9x5w8fqL2QXKJWHfsBuzkK3J/pGJh2Ako8HkNylMg91ZHsbyjn5Dnj'
    'JJ1892ExOnh5pyDz8vfdotf/AS4AyWE7Yg+0jBN9ZbMIDb7PhRDGInaejgOjVoDvuV5gdUb5yQkenUb4SZYU5Scj9YcINRTpP0YU'
    'LiGXEpFSdqQcOOKJr4Nu0FysdoFS4Ntx0oTP2heGbqkjQcV7VnGUjz6pWOKTvAornhwl+RVzwQ62zQ1b9SVOuQ8H8EjsA9rxf/n0'
    'Rod3QQVvjwoi3PnFjO8VYwaCVOiTkEUjz4gJZZq8gWGHPh3Jsjai4O9S7UuslI4xxfixjSGI5h94R/+kQuOdCsULZh8u+hDKJX0k'
    'oEA8AyXa+XkkboCPXTxzjQeTvusD9BIO2IXD/B3SVdI6RFQOUX+AEu7gAlrMkBEXsKJzSUdxLZvMB6kitzpso7zB0DdsTSoc8zSL'
    'bgDgCVo9HlE9oM98xMUqHvqhUxy6Xu6xG2joyIEIEwoSVNslk1RZQ+T7kJ9TQgNIRb1QnwHicHjDjN8+oMM8yIontEjIiACw7c3O'
    'TclllbCCuWJNuB67RBBY3VD/MMwM09nqxPT5Z5isj2SrDARmCVKcEpoxsjHDdqkz8w+TEfKoUkOzAk67znRKdjQhgBh4dgKWjlF+'
    'h7AB1IBQ4xAOwBeCHlwCv03OXnFQQb4iRoUYR0iuFflr/TNM7W9C9gvWSHUxztDPsz/KwzS8EVnK111/oMWn+AY04M/0RnjAbwk+'
    'JdEOlkCFvaIJLIIY4Qm/teAD5kuExRAUud+Y79eb+Iv1Xp7U+4VDtX9DkgCA8QJhWFokNi4wIMi5GOqJxWu4DRC8vDUA7Sn1F2Ik'
    'ELOWND/UBvOdggrKOXc4rnF2BSVsC7Uzim9a6uqBA/KgOdofka2GPSfD3J+4yzCdrvSTOW5Up+Af7IdriR9b5O0DPl2wgLfvALCj'
    'Yp67z+iVFaHiRNJEuZ7p0ugJdXv+c+ID2pm8tdqjjxFcecdxZQTymdAITXN8yV8I8rF4pLtX+BiVmDiQcl3dHdtzNGP0wnZMkmwA'
    'Ym9wNE1FiKU/YhiM8O6oFxWZeBpvPXALTDQqHkW/d8wShs03UgFC+vGwAFHD0yJ+fp/qXBzdOgAwZyzYHVNsa5bPWt2RThrgnX0P'
    'Bi6yIw344OcMPqX9utndQyuErMWazsHpbIvY6QAQOf/NvPX6MrFlLlVyu72ezX0MnvyzeflTMGBjDSGBvwdoEMASTaX+6rz+lfao'
    '5FGLLOVtm++sDU77H8+/fMWVSO7QLI+e9t+EO3wUg0SREvEpE6RlgrRskIaoOHq/BQXVwDKT+ZdmR7Ekv8LW+gOpL6zFJSbhjdH9'
    'h7NfviJFzyYzWDs+ZpK5b2d/CFdv62Fuub9TD8n0JzWcRzl0hJBHxl0EVAKmPc6cvlioZFE+nMH8EErHERLO/iY0eNKPqUdQ4MfE'
    '4/vVJf5adcc049vrGZk/4TzK3874vBy/XZJ49OFMDBJwZtG47MMZSbpnqY/RVSR3YzabFllzZNSk7rBKAEOoVN6z5z08O/76ickM'
    'WZOUvkX6g6LcN6o84t8cjw6YHKuig0b0au2Ggq/keRJe5w8tErfvQVQACVtu6I+W1bwV+Mg8qDNbEZ+hAqKJGhgu2XI7MPSrzegf'
    '0FdofqLNZhSPBEkIszoPpNRPESj55asSDBS1MdGJ94XYN/OPM5UQyt+OlkGWLH8VQOKVZM2D6U1mcdYCAMaOANH6a83L32nb3X63'
    'YagO9tE3DgW8NSbTfAr3TYzhNx+Hc+1AnG1UlGhg4nme+GnXfcnqpLouO3P2cf93q+QI068Usehai/975oWim/BIkm+mJjgyR5X4'
    'ltS7cajnl69zzfvG1HAfzoBzd03nig44VMffMsfm5MHxGAsmycwsOZmSgDfRlcBxUQDpgfEj/8qjOpKEYBoeuczToncluD8TIMHs'
    'hvxbJyR0BsgckJKXAd8DCe8sOwKkYIHocN+N6s+45g0NsVjQQ9k0HUUzMOZbUlhrH9iV2IhZNjr29OO+cUPuqFsMso9caxcCt80J'
    '7HmiqiSMp8esvD5Tti8MGwWumqKL7vtjwbQgDFvEYz1KAXyK3vfeZLjxiJyOZ6LBPVDKHjHiDMyuo3oWzBB/t9YfOC1i/n+Ydd+R'
    'UdX3vRmFBokkgR1594lknfKsaL/J/Ph8+oQ6JxmEEwdZBXl/xZy6OOmrt6dNTnja5KDveMEReTA5YqfRDDNiBI/vF8IbU06qJHAf'
    'E17nAhAji1y0gmQgY6DHDLL7I70rMmqBzbBvHnvNlLYSXS++4EwfCs9naG/G9nf0zkD0Tj3WEfrxJUFApaviUVaAWQkDG4DRLk3D'
    'V1q+ETGIiHzgWUIrTW4bx43keknsFVmwmUf+twPL3NDdk2+AgveLe0k58Lgf/9Hav1ngC/IdSPeR8f3bP375yivCR+wFY8r4QQ1N'
    'Cbox/nIq9BCKCD9jldjQL1+56XIi4VfEptIFHtyN3I56127hg1DgdgssOyFolznqm8ImQoQbIyvixLGZL96ME1Joc58iuCNyZVqX'
    'NDIsFUzbqXEsKxaPf/OxMv6jdafGEawkvRoaX2NlGlIKH+L6BgDihzN0lNjFELwto+8C8WBcD9opB2wPGir7fA/r5EcgrTjQb7+n'
    'jhvyu3Iklf2xdvTY39gMs1mnazFCqBNWlZnqcg05HfT58/1jjMMdChnx9xGKcmRQl+SCKWsLJinQ/kcMm0nrzG4gRg+3knj8QI5l'
    'mCtyVKv6m/wi4j6wELgpQB8UqLvzwweT6gRJApDXK+EPNN68xJ7gnGL3kHf/Fj/27ByevdM8nYYuPY0xytUoDI3gx5Cy+vycHwot'
    'EpqN9JbIhZJ7EtRoBNIku89gGL4/EzQaoFsBIeqZmjJZfq415objyKFrEKv1HR+vIUGnhNApBx4Q46B0HsyVG1oS+mSWqey8h3xi'
    'X/G7Cdp0qhLpYZ6yQ2+Y6DQoMJX3cbDGPZ6E/nqYopSmkplfAcFWJYoaDHPBriic3ZFXSmBZidmhWxTIH9z4Nt1o1sN6iC5O0ZWN'
    'G04U1c7Oed7xAqi/ddaP5Jf75T7xD4w+o/D2E/NTFMXdDEVy/+afkp7ZMLeqcye5nCvgd3chF15KpAfgecKuQXXhi48e/SgnRw7D'
    'wyL+Bcg3EVCOYZkAhcVyZTATgZMfDHylMu8JIbgwT+uMwLCagMuIfia1mf8x7mMY3d8oRzSRWfKw87qJuWO+I5jTBiN6Cnxsmnt8'
    '9Bs55KI4Gn4IDRY9g29qbsDBTRwCQ1JLUo7dV6UvQnssdpwkMSuNCzL8wkMgZq7r3yQjf7z8oCqS8TLMmKBWaPV/+15De2po7pdn'
    'p03zdxpiR1+RjJdhRtbQsTZX9/3a0Z6R+P7EWJHspspKQ69zCJaIks5d3zwqdAHlX6Mgn0aW6YX61p/CmMonxiBk5WSwo2zWIjkF'
    '91XB8EJ5GIogJwnxcKdiI8yXbMy3pYL1jPBJb+yQ8OXOpISoKdLRDveYKRKzNMplyPSoRLZIZJFUKODfDP0tUopIX0uZL983FuLd'
    '8zivTNBoc2i0k0EE6euj4jLrKAP9JKC4tazGkJNj2mYZlpGDKd7yNDGkDqqqLpjDVtokf6VULs5LhJYvdLUyHz9WD6OaOphA8ukZ'
    'TiZ+DYxRnON74bykGOeGRlFjTjY0ugaNhY9PZJgJC+c9/ioKDm6MM4o0M0OXXaFhwsVbm4MIbpZCES3EYuys/AR7hZhaIkQ2eZ+7'
    'CYwNAGFxJ3cmadB9J3cSmWv5b3hZ17dWCI/Zm+T0EKSs+InJX/wdI7Y0NxgOrNiYBRSf6AhEkgkban/5pEmokGJTh+d9TvQwhK6t'
    'qUFwDcbhcPfo+HwkJqCjwJDCkc+ZkF75cT2OyN6Xo/ggZIjOJdJPArLVQTSOK1Y5S8VHTOrR+qOyZuUTLvJn/StM7s8BAYLXSfga'
    'Lh+Uiofs5vnvs4iyS8yffTz/PkMarso7zCjr00mAETKigg2ZARQTMJzMqooFKedr46/yCS+KOUneYLxoaKhyFfJ2nJnDKdSU0HAF'
    'pwk5v2/x7w89NfNHy680sgXkh9BRUsBPyNgY6RBZ1zw0bPWkGXfUTJ4Cg2MRbtaLNTEP54HriBBKfo6xQVDCg6J5wTDeuLIgwZku'
    'w6FaX8z76OrIKVYhnRZAFnrj8uo4VBXWFDj54L25EMQiHv1425OQLaG7qB/7+YjHjxs6dsDibclzZYH5O3rr6iQhlNg9Ck7ljkgc'
    'u6m+IvaB8xJ7SkAyH7hp8XcqEz0+60k/Gg5atPiGJ2+pD2fASDidCe/A3Hd0jr98xc33STg/3jzcA9nH39EAQSCZFQVWkldRWA3V'
    'z/ACAsNsTkL4HOXYXaj/BO6HMzNM/emr8XvJyezoZOH9TUDogoWr0OV39M/fLYXX2MRkhoT3wFTXd1tDcZM938XnH7+TRyfq9CoZ'
    'DhKdGGARXNmYxq644hAw9yVql1CBwDbVGfBGMFTJ8C7RnAxbgXlG0z1JPyOPNZdTaaXpVDFBM09FR4Ik9bt+ypZPJeyAcLZw7B9/'
    '+aq6MoDpt99T2IWPf4R3+dEfTAQFfAuNrfw9ij7/frBF34U32DRHVAfHTxx4mvjvdBgoKUBEDAgxGYjmiVhF/P2EaQrQIghfJfYa'
    '/7Eq4v3rezu6kR65Asd2k5GMXH9jV6OQ4oRXpyOm5cwBIQMq8pbiaxzcLd2BDfHtjEcbJEM4MrpFloX7VfTLXYdVMXPaa3bShOSc'
    'jBrpkjXGHuWcVLBM0erJ6eLb2vFqIFMGskpnSfj5dHLDM8M0InG/wV4SL8bS1dlc/rjZoP5eku7/nlQrJgt+JZBE7iCPKyPqjXMU'
    'CUL49mpqZBznkeOS83emym8snAnmdZJaxo9X0R5k49GGGWjjreQeOZth6lHy/RyMEr9GmRVn9/ZiZfQ7DeWGVLrsng9dAXMJ78LQ'
    'HImE3fibK7n+nVCOdvCEjydx3Z9BgqYS6v8MEgiVfYA7OUDj+569z/m7jxGmR8jTfe9Y8Bv8oX5+C3HgFWouQ4TudyNAeMoRaodu'
    'HCF36EbQRWf3H+jN0VEDO6L6IERjp8JiHjsHvv6JhVdA3WWUxDG9K1Pw+fFVMETW2ceItjpUnoVgEdYUnY9LoRBOB3uJzgaS/gyp'
    'mFmnP+ElADT5P52mH2U8IY8OrgLwEzG/GNmgxr97FEv08M0MZ87esV4oCLlQec38T1NvYDJm7/hh/BpeIbl5ExOF2wTq2lINWUbX'
    'k5jfRZluWkYugIUGWJENhfyav+0/+Buftvdkhm5v6RMiX/congS6hIzItf7K8f0ZE9EqJe17k3VdquDiiJ/JAz+DRNIvkr9Af4w/'
    'KFA6O4+fRlidRf1Yvjd/px2DPmW5DwYWuJ0uWEDqH2FLtJ7kOwGEAt7kO/WEwwvmKH4S8fbNOUyUPmqcQGo+hUxg4mo2Pp3UP36X'
    'AVW16XIQbC188bdXlBXUAqyhnWAM7RRlaD7OKFAsI7/6I7bsj98pSC+PfkQNssC5UPR/qD1s5RIP8D+c0dlIZBzxM7yN6qrA0ty4'
    'Foyog676P5ztnjVlDP8J5CYt3DfRK0P7dGT6PMQQABVHQgC/0w+pEX7ezxO4l9cD9/Jvpj/kRY0IL4rnWhqv97+IBZ0l3zKhlEqo'
    'exbxUczLMWmCJfviQkARgF4HLKsesqx8SuPXP2AZ2PaKzuopaK/3x8tAP/4tusxbkCYxdif6tBc3hOcT2D0lrxGqdpmQOkdzZIIc'
    'PzKEwjlCPgkN9pMY7D3j2+N/10TmBMbQdkJS8K6twVzWHSPg2FkifxZErsIwVsACSYK7QjPYs3/+z//rmS/pB9ZFpqX6wUySwi06'
    '8/LM2czHy/xkGPEEG/IWpiZ3gQcsH4R9OJUh5ThdCD8e7HkCHZjF/NB+RGGjOwLqRN5SJHmKdEiBzFx8u1yctLOuRsj7+/JrFC1N'
    'SDEfLBwl4S4VxSjSmERRRibDsJMofs/m7UhUDelt6gSDhRt3sgsb/y/ZrGLmZJ8Wo8KiL2TQ/qPZ9rcfioh/vBER33JHb9mv+DuY'
    '6t+7TBRr9uMdB2sOltAzSj62CZyEvPGEn4yL6ajygCSWP7NMTBbeLFIEExCs5JL5AAdMQhwwwf3Av2WCbz9qLPP9PR6d9R+wpKRG'
    'U0Eup6h1X4+v8/Kgjnjd1PPM1aWuTr34FQWQYfdLNI9Zh0WvF5IxDEVZJCNIxpkxDBHNdnKt10cHwLrMfUSArOmlkP3uViXVM5rT'
    'fRcMyBB5LmkhINxj39/0GVP4iZO68oHjeA2PIGUeQsr8L0LK+wz0e9ByFJARe8W5kfmRoDA/kRRwd/rYhXbqv4eNT+a+a8j5XTPb'
    'dwFsLrlN08PA7PETzp7z7uQCkMJUatwdLwMth10pIrn46igoGAbwM7BOIcaLSJZ1EUIYLB0RHOah4QiqjGMiA7Bl/FXYohb/Mnpp'
    'WSw8ruq+DzwhrTBwEUv+IhpEJtKRVSxEVrHMaET2P46CPl+iQwTxAm8ckRoS1Qq+HjLKpxB2CnCTEQjnnEkhn0haYAmDF89z8QBd'
    'hdl/3Lv8DziTULsY6f6RlvFIWAm/RK6zx8heCjUg+ADkCH+AGtEbM0VGsYyrD6kuinAUWHpifOT9QFO3sahlJx0RkDYJT75iv3zd'
    'QA5mXU9P+29xwZUlPfi05PZQZH2KRpc3nudokzUUZlopjKV6zhwi/hI7/xs7at2fx3+cF2q0TFfDnqJC1XRixx6eHBXPK3nXWdua'
    'AdvqsfeMEUGYGSseHlFVkbHiq7s35J5p6hPJCRNoS7clw7dVJVs87DGu37NqrKHLjEOMU/4GT2a5PWePZ1YmTA1G3QIEgOOreeoq'
    '1u21Og8XwlO31UyymPPadI8HtHE/GgU5NWXhCn+maGdDyTFYUNDIq8Di3lwDMpBcL3YOI0D7d0L0a8900Z27j28ccwtimPDPf/vf'
    'KIpxV2KR9ci7DF6glKYYcgY9EFDUq6Pgt4CWoNH9SbTbSETW1UrzYkz7aGju/MbQVjAJeIJsdlFrwU5A3x8vEeggY+jmPJ+ORypw'
    'MVBxjLxh8iRuN4bWzvea4+1jx9HC0MQCJiq2cE3jbc9QPdlWKZIwQ9yo6PUPNniQVugfPpOrBeAEWffJxzerlPf9xEzs5+ZRBMnj'
    'uN/HvfUh9qjfOGSaSldVASHg6zlv6efTafLNUSOz8qOZ9qcksiymFYufzhtvn1oM6z1t8S+trd9ipHtBiycwxpkxJGqOxCz0jsGN'
    'yOnZfD1BNCphFEffqo9bxF1x07bQPTJ5Fg7dI3N3Q4CvOY1Fg2bjOFLnuYsNkZPTFGnEAw+oyBTu6dxkBmgb71deCGpylmT+adcT'
    '8mNhmeqKG07ghRUXXVOtWIg8PxD445oCxLLY2dzi87u25TyKNsYy5oJp4Pg2Yhd4bBIoSOiZndkpSWQj41sbctEWn6fRiPfIu2JD'
    'rCBIw2tYNt9FLCwWmSVik+R5KnoLz2/ZVTGogqfq+8jNATRXpDP1IMAheqKM0hZXm6D2kQdX/HGIQyxLstJ7LpDRF4JEljVY5Wf8'
    'ExGJo+6/fQPAWIwKfAoM/TRYtR1arUByaEZxKdIRdPw9i0AWZgPdadKCnLtBKNOTFaEoODw0JcEou1XP4IT5EmFL4zvrvGYQiLUS'
    'PE7XDrHtFJnZdwimOcGCA1jTnuDJkU0RdYrFUiogwcSg4poSOtbTfEdPkWNBUjX7K/P/Efcm/W1jyb7g3p8CdmUVSYuiBg/lpCyp'
    'Pchpv/LUllxZ98nKNEhCElIkwSRADSnp/e6qV73qRXcvujdv8Rb9seqTdPwj4kwASMlZee+r/JVFAGeMEydORJwYpLxvrXxS7wpx'
    'GXRzIlmry8kwXLR5sxrp0lK9zWXZ4F+yb176Az3CQE0+zpbquWoH5w/tSIamt3O2QtTf0DtALXBtLv1PqkVkei7X8qdEF0QIkV1U'
    'iw5in6vBacyuqi6RMjFyAnCvDcuAWKFVDjSwQk01ypRTuLSMhc2KaXaWUJ1WCI7CTMUeSj5vBfUY7FQ4YhCx0Edjia5k4qjp3rJO'
    'O2LrOnZKV7Zv51odxXGTp9nUZa+kjbk30KCQoZdPKfmtF1Q2eiqBYHG/s2qC9ZUiV5lAs1IWd0EPntiirIq7tkH7Uw5SxwcJ22we'
    'sv0laHL/OB1KSpluFJ/FF6IemGj0fJMuVVkwZL2SHGMSekJNDCcSl1hogp8CA4Z/74lBndQAXLOeQNDzspv6pPNuGdySCdYlifVy'
    'Bp+4DMQnNgOxNTbmmD2b0bKXRLpt0sVvmszQlj/20iKX7Qm8JMh69yIt35jouNIb+0g/VIOzc7XZQ2NLXqZq32B7YrFpUsamiWfS'
    'LHk+CcyrxFm6QATIKEb8IKwF154gBgFksEctKS690/m2XLGsmK6yc5OBCPL2rT/ARRVSZT54Qv88/OsqMvntr/2VHoJvB625BroY'
    '4fJc29xBwgSRx1ZWIQ9wjY4C972U4JjSnZrweoMYUQoE9GWjTd8OVAE/iMNPoJTiIjRxsfkerdognTbcm+an5jV9ouXVCLtcVPJa'
    'S9FHYXfYChO+TZiaatKwGKpM+ALDfpKGQuPdGhLXmjdvDlRCmFdKLUetdjodeo9dlrB7w/joZXp4CMOcpNWy0cCRWt3LnjKIZU7O'
    'QE8C2m1hsYkgJcvfszVxHkS0u+Sg22yWX9JHsaFwxUbYz0omca5w7QB802hXS4jGd9+nKDq/UtZNYjxfgPIJXxcXzkTj8rqaOX2i'
    'JwsGNnFmB5jQICHsTiLv7cYNojudx+KIPjBpR8peubMxnnNJceV5ycH+GRzpm8HSUhuqBHiycqQoR2l5nFwwI1TYN7ZZmCV0+l12'
    '6QLostwECaNfIFZM1ugxNV7VXWH1ZdsHnDCQYGIc35gj6Lp04FyAzWEFpMx8iCiZDjw2Fg/ekhA4ghWRVbg1v+CBqbK4rVoXWpPk'
    'nDk+K8eat023UEccaSYMnwfRJB9m8BZ32ccPC+u6BHtwtqLG4JsMfdHbhDPWhPKBtipnlOvPpk05wCxglArnnJgZYkWX/tjT6NrJ'
    'WVYU7BqPGvHSijgN/YTYciDeGZT7Ljt9KtGnPEcPcQmfarISj+3vBHN4R701f9dqQYrs9bLzJqFLBcE9Lx3Np17OKa+KCaZUI7bR'
    'dUnjR17S+FvtB+fNs4R0uGI16zQf3gaRI4xAOKDKKNKw+8Uy6rorqrj/e7CwFot4scHQLR8OM8kIbvPjJfDIYZ/+ceaQQXQHWGsU'
    'HiYxPBfTQsNeIMLXBAlTi3B1ORf4N+9G5qO4lmwhmwypEA0lYS6x19JzMpoUFxJLtWp2nvep/3FJ5JKI1/kpiTxDOLn+yPkWJey1'
    'qHbBB4smVwJfu7KvWUfvF75whY2gxFnR+iWPCwklTH+e4sRhqx574sYcDydGDByUWNrkfLdxYQbbl2OdB9MXF3UewrXnpL4rKqHY'
    'RCaRvLEV5Y71mjSmVRniU+MKQ5RViE+SFvrVKoo680+SW24QmeIF/5i3G4CPtbtBY3apwUZlVywgktNkRFLGrlooBGKlHL1OrjTa'
    'z7vG0/3S4aQ5p60L0b6WPqhqTd02NJrC64A4l9Sloi21WJ9bBeMd4xTNFJLeU2FDs5QrYTtcF0FLdODPbByMcZIMvMTBUNM5TJhD'
    'VI80lgCdA7tJYW0sciaIJe4+ZckPNVo+gCwmlIrvY4mGB55jFkwQ0pJnFmsvqEmOAmK8Q2Hl4t4hyFh1RbRDQQxzsgUCvU8Xg9QY'
    'ifIm/QVqh8XoUcELX1dyE0b4x3WZDNrlJ2HLa9OPcNqvqqDyoHtPy5EbnY4EhNSsFKy963qRLBJ2itOKpq8pK3em3AaCTpWVJZyU'
    'SNRxNtAftDxlfV/K7HI/mRSeki/Q8Jl4956iT8eS+7oiHY+MhldOYsUEYCor9EI9Wb0u1TZ9YqfqoQtu5OKieTi+1am2cJGjQyzt'
    'xs0oOk0En4XMVTKhjk2cHMli9d4lQU05lIjZxiqIuNAu2hYTcdlQ4w6osY125e4SwkyLfIE04ZSMVasKg1cTaGQ5uknOjpXcteHH'
    'HMcvY8BYjbvxM8UMbY9jqVjMlBQKcgXQ5E+lexCAUdVJgrm4WjYBBMw9gomdd7dZe++gRkmMKubqpxWgnEg3RSjdeFMh/tqo0T0X'
    'dZa6rLzFJfOWJodioUpUeJoNhIUrUdSVaS/DdQAFB1a+BQ4BKZo25IkvyQcXG3qZuRJ94rgeJFoQp1Z0A537kcTmPEsGR5ZxUquX'
    'CS1yNgUGUl2VW5T1a0KbZ8PlcqAjVtTTEEdQHHSiHRcjXDwDOeIhknslY74/0aya4j2KAoqVqcnTaaLRpoUm5WAmVJJu2lbYiRC1'
    'ZQLId8khFfVrFh2TNEwFGCnAEBCS8D2baB8lIAWbKkGPhdDpQFuPzhS8Hb2TAS+q56eA1l2wuz1to1OATVT0BbPMOQU1+PoYZDIC'
    'swJ68CoFj/mimA6XVqmh5UM6zhN2rZwmv86ITTPkdkTt6B2YSGdqIMAXLoxmUZO4eL2/htrVZILzA6fr0Cd0roFhN8HMDYUJYliV'
    '/aasynthRCoNf03cWBDYCEkU7ZavmKCmuL9LJXFpnLv03oJTG7zovoEqg08DCihdEKmaMzP5UU7UB8Sp61VxzAp7zzOk5WJH8MTa'
    'sjdpOx60qhKmXM3YM0gnsx3tQ8NpLpKUyGnNs7Gt5yK4wTsDoISzGgTKB6zDX3vip+4RW0xbGZDdN4GzmtyXR7mseo5ad9+M2z/t'
    'qhNJmIXQ1Nyu6MolqimNUc7Lrv2pS/Y6Hh6yjaifftAs/EAXwu3ikYiQnBIXzC/X1LSxEvHBFK0JAn3UjkatIC2H1XBKMmKnYq1q'
    'TE2J4zDVnfY9v3W/7lmlZb9v3J+se0moXz17X1LWc46t8G6Dj5F4lf5PSz6dGF21nH+yBQ7jMWdAxHYmVnhsj1NzoS90Q+7TTAoq'
    'yX3E0Yw9Hxl7kptOJIZydIzgOGPJ3DAOTvzjeGASJ3PGCmTIMqewRNIBhT/KCgn97J0b9hBwIbxU/fRecAku94iaFa9GWwBWJUNY'
    'DMV5vKYR8uNVyftFNQBZebem75bcO/929cRerCtjxDFBT/Lb4v3RxNyY2AQ8nMsTWtPVyqWD8JaV+4Z8Eo95OjJZIIvfE426gBYQ'
    'LtwxPIZQXBJkms5P/Pw/RpEwnQA6HGP4aMK4ax/1qRnCezt6Ao+wR86vaVpKDC+bQesTcqz7NwVWuY8Btp0GnzNL2iZxdbbJNL16'
    'DTGiUw23bPq9chcxsq3I1hDOG1onBQvtEFskZn8leulMA69Ll74cq23Ota9qlW4wlsGpqHtP2UtlYSOeAgfVCzw8PYSjL+Y6WdH/'
    'xHmX1EX/kDBVsK6871ENgyq5WE8B3h7+FgZ/ixr83XCxU3Q07eACExHruE/xlu888joOPq3ai0Roft+JAsLeZijHAM54GJ+ztk+Z'
    'nzwbniYflMeqsA6sCziHnnSVFQKhw4eXH09OU3DFKM1MsbwCW3xR3YfMF3viTof9q5prrZsZZWvF8GwqSegCqqnOiH0WJZRTNGnd'
    'NDtCzPpTJoqcgMFlf3OWRnibMqeM4PbwHQanYrCMo8/41+LWej73rwo8feikE70SdgZxkNg7p+UNmo2aOHLTMIp7zHBrTnk+fl0y'
    'eWiUofqTaPls30SE/zg5j4+Y+T+mGV0Qu+sba3gI4cmio9xZ/Rk8GVljpKe41XQaLr0pNRmHRwEj1Ol0zEqO/Ot9YXnulqLFMqum'
    '1jEeFnmi8VGFoFfz1IrH1sgFAx1Bw7vkF6kkzr3mq4JHXuIS8b+xYTR4/2ooDf7NiVxcuDIOfiB1iMx1FR5NLtvSlAoms4DBgU1c'
    'LrqQZnGdGYE06WwJ9Pm85cwE5Nw0BtTNOPqzR/qJxKOo/1z+vhGZSIWSBw4Uwd80Zot4+0KST/W9XFG5iWOYmTyPlfSMhMSaYQR5'
    'FhOY7MUQ+YDXdfuMMVujJspIEEx/NmEGCRdaEtB4bKISCitIoqwnJwxCXej+SOmwz/uj9s6YlSxz494BMTns3f77ZiVmFEcGKoWM'
    'ah2U6eUIZI12kUfN7pQsDRRnWpzlikVAE2rS7syU52OG3DkcxsU7eAUg+VDvQM6SbEKjiCXm3ojDHBjFq3zqtfgkIqlGakG2MV/m'
    'VopdpR4tHFfaPwjiHzDi0Pkp6dSptmXTZiQ47LNWkCmhjJPehruSCjDXkZkNjJyHKI+Nh48X/FG3tP2oyaU9ewoP6sxDCAK26vPb'
    'rtv8tiLkI/omKxcI0oq5whLTBq/YjQTn8RI16Bul2EyFuppiZePZLdAen4KLalWsPYwtQ6WEGH1Yh9jreTHBTMw1odkaHcyW+wVS'
    'J9+N0s9K2V88cNCkqRLt5gLhP71EuwEoJjZ+3X56ICl89PGXA47GWk0jMXH5IyYS8TlmE5epXJNNcTX8qzz59iTGo/7qiprdQqUl'
    'lOXHp066o/fL9H6u7YsVSqng/UhL41cPVkD0Y2A5aBw7xzZN769TLxH6Ko9a60uT9+VvOSbUyJn2uPm3TGnqCimynY1P0wHGLzMf'
    'n0ZomeMOeTW5VUk6tmw+2q7po5f2zBWoq71UXzvAwVvlgq1JnipTcUIX86SCj2yAOSklIckc9mRusE8N5mhIw7k2T32zkixvNysN'
    'm/PVtG7OXw6mSfNqZnye2kOcnpH7IVl+EFg99WvzePat2VMW2jvxWwmYjotWHQO6DINCEtcyYdp5pmc6zVpE3Qtb7cLcYfspqql9'
    'xxVJlmq8UlJaZcEHPg+uphRevlUX3//SsveOJR/4PLle/wuDK8c4PQyRMwxBCCvxITWKFI7/qUUxPoviwUCG4lkr456FhL2iQAz2'
    '8ZCg4Il/edRkjoUViWfH1B0ULccxTCPggpAWrWgwTQ8Ll/ndTx8niTlMtmmWFcT5whrJ2isKLjsAB3I2sPfyvYza5OMH8gYuMMQO'
    'J4FxUNrvRO8CHh9KZeiUTUJpX441AoYwOj3ipIizZ01zJ3pmDXhUrR9AALTDyQh3ODEJQrKexWK4r+nhIEzQbpPZ9AGiJLyns6Kh'
    'JyYglRpboNWI6C5uns/lhFdZxc0SgVPanK96tKQtgTXc4/mab09Kn9cW2pcKfuvdy2IhQzq22hOIsEEMMWKfz4PkBOdrUmLJK3ER'
    'tHGx2g6DjqFE0MbFWtuGqzAlggDuMM/I27zUMNLjpcFdIdIt0Bip4rko3iTxQpPjgVyYV9MgA8P5mormF2sskGuhwTnHbRtcuMBt'
    'zsaBl14I9AzrNutgKK2qXIiCnEZNbgykng1rMjOurDNCBffeOEhIZbVISRG52Wfb/3CGnQFs8NHnqHUcHHuO75n1hSS6IF65yfPa'
    '98sdMETAmATfeu6by8V1d5iXfdM896LfEuNr5UuwLoo+RFn35GTaSnzMtfVScEwVPTJOXzLUMIfevI2WDUSUfeyJasDsEckJeDuJ'
    'fxZCeniSHGs1zrKaiLvDRStGW3UgVv37J7xMMOQvMvF6toulsdfV11jEFQZ4O5JIgeFn9rXiEYb+FoAq+Ogl+dWTGJ1s6T30LaHZ'
    'pr0S+VNjJJr4n2yBbBN5++HF83Q0wzHHYaw4rVxID3EKbeqmYODbDSHnIFciltpgvs/qa17BtOAs9vyrmsf+FXiNw0NpPPMaZ/s5'
    'bd2loL/PaVXVYs58tann5SuPxWXSwhVWkbLkbtNncdVkYDTe3oYX5DJaz0vrKK7EIo42g83WjtjR0N87G6U6p8zfiNx4eLg/6x2Y'
    'JMEYNt7ErLg5ZaZHREgtp1mDvXIXFWHllKtqgvFS15wdEhca2EH7JwcKoYeu3CvpHczQ6Tkzzfejww19zTzS6UXwWkZfKS2DDUpr'
    'H9etShIUTwgUzLqVDBgW/cVHJTPfZwZXWch7bp8g4/EyPO/0zTr8IsvwDG8EvqlbBip34cpdSLkLV+7blkHyGT9j/v85/7u2tooE'
    'da4gW6RRsS0oCi4JomkZzviK1XuwIV9DcAdffymvaPlruLDeVxMu3fyddxpeBgO/q4erdzQEomUIqVcKaJlFq826jhHNfP0Rwn0+'
    'olGNTEZllSZ1cTBqhcz96GTDLoZ9f8HvS4gXsCVUxUZyt/pEk1JS1Ycmez0YcrbUzy2vfIx/iJBAbdjl4APEBou9xZQNnMczDvzQ'
    'lLT2LmcIa8Ozsd5pslDgcoPxx2mSz4aFDAHsbou5bGOdhnxw4Hnh5iziAnULmcyM3VMp9vtnXroIoadeYvL7kdHcSjpMLzu5fDMl'
    '/bzBIhPiMAjPhzw5qj+Z902icUPOAs7DJTav+xpkJQ9L9Pz6vXL9nlffO3I9Jt2CCyQIqd3FxjVanRu7HlMMCdSlvSjlyksBdlNp'
    'wkROEkpg1CfRzLtPF8GniyqFLJE+fwi1hG9fFjulP2nvgA2Aj5gG7iMLOr2Ee+Ov5sMvByHhSSVpQDoB9TIPv/JDz/+iD79WdRfq'
    '3dU/c1h3P3KPv0L/IebofXa1pCHFpog89rhIyy2QWH27DRxsY7eM96OHsHRfsqvB3IRRR4xMtomyIlf1J75iVjkGTocLAZQNfVje'
    'zHlhNE27n4PqNik97JoWUxjHMVrJz6fRmvnt1tS4SEqK3zrGy9dD3ZWWaHFKNFi2j/iIrJbzecSiWUw5BeyD778n2Eg7yBH618r1'
    'i6QKWX8EKH8P17WmlP5z9NDd9Hu9OkUxrFXvq0+BUw7rWzOq60BFLwynYUuFx2tJzGtQoSZ99668+wsygThVFtF8e38/90QjCc9q'
    'oviM2cCbC+/NhcnM48npM4jp3Kaon8wqVER5lh9L2ij0GOij0OGGvSE2apOuund5Rs5qJhmY43Wij2oKy0Yyx3q9HDPmIV0r1FuF'
    'Zupifc4xUuRoCk0u3sg54gi7tXbusCXKmNNYSKYt53RjDYitdfLdWpchVntP4yOfNQhixDh7uSnLeLgHw3WRaGzKhnH71jLuoOXb'
    'Q/qJtbNvb6VsM7CP4+VAbAbYNcCt2mbkrdhmdOGb2RfQoUySKdtuj/tJZ4wgA8Qpznj/PFkNXaA57M1Z+UAtfD0MrPRQZpnaZpX2'
    'bErtJeLQvWZ8WyfUDR5obR+0KpoknRFkpjWZE/KUhEKYVS1pCJzxPO30vjGn2GTIdI6SomltUCLWKm1GrN0xShtsdQx4g9VFmxHr'
    'eZpWkaMfAwpvrP3NJtekPUDFDhup4iZSTFSBRRzH5hXeNwFWrcg22QH2Kt3Wd5cEBqinqFp3UWslr1wfeR3uo81AMYLlH5aac+O/'
    'Cem4JFYJjb8vq7HrUbA01doAExLX0oSrZCVWJA4Dbiple/SSp9CtXOvK1qmbiNcUvmKt0yA5hMq56nxb76igWnp1acwbkbggl02s'
    'OHxL4dIRGivGhjErtBXBavtua9buUKy/gUHGz7nWsxSR1IZDA88BR5T1bbh5tAgjyx9+b2yRsTUyazn/CefKfcdFs5WIwwKcVvVm'
    'X8xl1CcFyzzq+As9ClaMQ55V2rYgXNB8rTOMd0PDzydB1ydzu57jiOrTfYcuhwI9xpT3M/Y08Myc7IUDe4yoBTesU/nSJT4niU+c'
    '2Vgkg5GTGstvRPU29MH1Q2iKJhL/2pPAf6Y+43JFVfaorCpDCXQ4MDbz82WV8S11KeM5ihRnNzAWHUpPfkKBchSbWwfVfB31zItA'
    '7+Xf6hlZ0lzpGUkzLJuds310zPbPR73OmYkRAzD6ARzOYXhyoYWPpfDxvMIXQeQJ6uOpXstTC/hZPeMMkA0Clm7H0QQqbyN7Bgs0'
    '29EywlRyfHT0wDGsmO3mq3JXAcpXGlFNpQuuVLoDBqTVtjZuaXV97rU0NibnBcx7ygjkNi5ILHqjEXQk9Fb0h5sYkDz3hPeU770N'
    'EaLN91455updhol/CtRELuRI9zWR5F4S+eWglXwxCSSmyT1ZXZ2ci9PeqAejK2hXEBY1+vzpbdT8+P4HsQdPhY+VKPrThLbjBWIq'
    'wn7R5FzpX7Q6d2IEhYy8nRgP3qBO8zAdBmHQZlMcMdRJp89ZWUXPT89S0kaT9G8DR0fKTUqThimRSP6Qz6ZDdcc+i1Mu3xkk/Wxg'
    'i+rWh0IGH8cxgTEeijc4oSLHoRkfh1/V/9t8zkscIQGQMN7exI3P0EKYGjtIFGYSkYs9AQ2F1rnlm4zUFDqWQhslr3aixjNooBSC'
    'O0PWRzUbxO+cxjkiKPblxgFZzPBwbDxIjoOmCs5TA+7xBW1BXFg01gcmPQXuMuA/JCAnuHCuiFVNOBaYc3EzVJwa4tIvCY2aXuEO'
    '8Mozqx9OjmNLREMC+kCNks4dAWUfeTmzJue443gKIRismGlI4oJKNsny9SchSFcLbtNciwyDA7Y1GKVXJuOjBohFzadfJslRg1N5'
    'cnYqmxMNuQjGvBEuGY+nyWl24uExYWNLxMfSpsgVPuwM4vZFPboLKpf2kePG57IvvsupsHvSHv274fi7OdydpTe25m76Gw1T/c15'
    'JIj1QAQDwVVVuuUQJ7h+VG8+KaYBHASfrm2YV23qRTYjbgahwTjalXj2oV6jHna0+7nZ99jVNhTPfwYQayIAXXLz1635YPz2+ZaJ'
    '+ZhjNnNoh4RDAM+LSGtDIqT5++TM7CtEYqPJxUMBj4k4agI2ZNP0qKv4gT60NpG5cTzp1kXrFdxnPaU0rBfcKj20vMY4HxmXMSEb'
    'sqlc5FqTfhTzPqprn8dY+fInbTA6eHjlVcrVapy1s+m/oS0mESAIMp+AnE2/eyUq7ajmpbmrtKp+AYtEA8exiXc0KF+SK8dodvKb'
    'xazyNb3I+Pq5E5qR1AT/k2sZiTniaVeCQwMpStqcwAVkKvzC9l8P2xJh+H50IudNkzW0635W6aPO5AIZg1vm7kbPCJcQpZyQZltS'
    'pHSN6QmbqUzEWmWoxijUjt7jS3hYsxocfKRtGetDJDM1wbapq7FcLZlklteT869w6pq4UhhQ/0ILHdtC3B4ffVz0TGrK8cdvjuUN'
    'rB1A2fgd8tOgJffpR62AHDVaGAPGC5esRn5xehqJm9xom1y4yWvXIwPDtj6RWF78pQJ7nQ6mEj3R6Vy3ahQfTKhEuxE68C7GPWw/'
    '/bjhUQSjrCjvRcN/B4grKKu7XIewHSUdEBQCRbCxpok4Ja18yZe+W2kjJrtR2cvJEYhSokhHHliiOyOxybgbJKBikt1hQmXtjuMe'
    '8bAZLObAH0ooK8QrgBDXNCGQc1bcssOLOEo724OWJ5yI/ujyZr1RoOaxt7RyuJqACwtjapejUgd3pKwzGxtKKqCVM0UCuN4RHZ9+'
    '9yG2LQuDSDx6ilkwK9wk+DKX4lDDtnGDO1qMYF8p1mJLqyASdtLBeXFzpHITkM/RdL42kNG1SgomxSHaKTunBMi3aV4kY6rXSMeT'
    'WUEcWVOvCgI6auHlYWAQdpzanttybzib2oZ9ZmBRpZPkAkouqpcY9THBg8jUR8K/+Ihxx0026VB5Ud/skDQ2STiDZdKZ4HQbFy+T'
    'w3g2lEAhrn8TB9CPAeM3hAwVDcnvIlHj/5Zc3KLZBU3uxb25A/PCQjnAlxv2lKUuHt1AmBwCRonN4TAJx8lwgoTocxicIvsRYRKb'
    'gRgJXT5idZHM8RzCEg3mBYft+kSnjWEb3GUYTVGiev0DZjgdHDlzQ4CZov/GReFeWh//yyPLEpvOhpj+V21QFwReuPymqMF/gE0q'
    't/MH2KVWHXd7XngoNfNz2YLtVKtTEHVWb8EUXIi+eWa1ogLrLRi+WDX05g//I4bvEt+3QkF2TQTZ9VVjreAs4cYnUS87Y9ehWSER'
    'TFIXQAds5iTtE+qyCOUt9698CYq0yR+JXcewVucus7hgPK6Fzq8Mnce1cBG/jse1EPmVIfK4VRdf9VzuuNHEWTeylsLEhukdk2wY'
    'QGciqShesbZVT3+PvykC03E/8OOPuuW9UH7t6HXwUnU2y9FDvuULuvrRah5f8y/l9yGS2dAjFzS+Jic6QEiFI421EPdauJyCiClK'
    'ZjrNjVe07cFnt5RG+AqjzsO2gyaC37bdxx/hQtSzQbwxKX5xrC+UP1D2GDMRdrsZ4jmxj05QUC55k9taN/ZFDqGDwkGCGI+sIbwb'
    'odvE5jOohkE3Nv1QV4Uh0LXK74yBHljhHgXhzCcdF/x80wsG8rBUyoU937QyCpVy8c5LZ5E6TajrGvhGzzq5dDgBkVH+XcZAEUaQ'
    '8ekyEptkzqB2jasNpBQ7zrLcOHmX85Fl3lUWmFJYwzX1Ip54SmnqSHj1Eq8vpUyYujA4oMjBdT1yLXadvUWofW+W/tS6blQSpLFA'
    '0h/OkwwOiZ1wGqibQsFm+XtTyaqUXnCOr1qwRE1ilDhqFPPjrUYpTj+/ZWDpyVtaj5pRSYzI0sDCvEx+MGaw0b64TxwRbRLucuJT'
    'qZhlI9O/+A4sbvnrU+SQjQab9959dxlLhqm4c3Edvf3uciKPhMDzUzW/3nm3s7tP+3bvOBklB3NSvj2qy9381+jRwrShFWmT52us'
    'FQIzkWDG7sZd1sSsOUxBNAYm0V5+2lSDDkcx4aLlbTYETOglxp8K8WWgMYPrFqJc2Uw04rUVEw/FtpiD9PAw4bBiQ+Eh5MpQ9zVH'
    'N8QRzCetCYYgRmZ5WnCKUwkl4uxPO/NjR9cFRrXRKa2eTTYMTdpEMtX4oeCbVV6smApEZm+85el3os+5BKhAzi1i8cYz3hSiez3O'
    'zjiIK3JoN+qo2ihDCqyQeuHArMozmvGuLNOIgKC+c5AGV29vjQBffZclrGJyVCdnT2L5YfHHIJnloQJiKmbCcPjnwFRQAqBCyZQn'
    '6Ui0vg6PCLDd1yTvB+a+w8d1EqSXCr61yJNC4mczhfUPpTDnAjsZzevFJrE8cJRwmEt+M0Pvl4a57dCWN2FumcOhLx9lhV7EE7CH'
    'tCq6ZG8GtQFHx4umzqkMvQGNC0nEBZxcGrvZc7lq6FvkY5RsYhzTtqb34ckNIPGhcaKdax9Lw5MAGsFmWRhkVZUd9b0iauCBf+Z5'
    'U6aNZnpEsVsF+zU8PcdyAS3taoZk/0BLOSgvDBoyp8A9WjBKsQ/yxlmw6qVkNrRUHNkBy6daeNyI/W12yncydlvM4aKXcaGmcyXC'
    'N293uGKD3lCt6pY5wD0uoDvsfvSIrY/tu1TsWSRFrWcX7AvrtvA5UpA5ydy+Z6/ux2KGKK/ErqzL45BbexpLm+kxiSq2cZZYXJP2'
    'foOq+RpHzsqlHJbetZhcSqWUeJ7Gg/m2iSlnoqNPWk7oYANSk0+7G/rx1pCZcCSAV9KJh0bfI5HkhsWSy9sbewyVidmKM1PDrxDb'
    'cMcpLfU4qsd3KWcplRd9mz/cTJpunI4B99zBVFyDnboLkUZw4nbLkW8jYcEZFy44pjjEmYbgAU+nG03MTRi8SjmoEBuopm2NH6V/'
    'Lw5aC27G2mKx0jUXbyr4BAMyVtY+UAN9bnmsdAzSUPMQX3MfYeFL1VWhEE5PXSPzXdsVq3Lk1OzYMr5YiNssH6SlhSwD5l9mGdyx'
    '7bPNjs6EMkGZpcC7DkAhWklAwyCJFYO5zCkkYJ9e8Nv8fMNJwFLuwiv3b7acmkD5AnDt+V6mkQMTp8M0BHxysXxZ9vQ+XAST7YiF'
    'U0jzBlzZyeVE1B76UPEququZwHq1zSly2HSVCxudvYZCkzTJXjQ0yZI8CIynQUI53AAsnzgc+XtZCxPKsS4svRf2lvOZOCNQ4vAa'
    '8M8grnWKe4jUjyCtMfY0OzjraO7a/nEBYbUPPAKTUlGAkU32+EyDUQtVpeL0x2RQdGM20a+3zedunW1uy9NA0VskEG96UrZB5e2O'
    'oGrZUFwHWsJtYzVNQyvMSReKiEiZa17o/lebmN8lHAenf4WhvYmPrd2Kep7rJtowVOom8TqgMrydZS9jbYQKs6/MoFMxa5O9bxe3'
    'dD7MRfcaXPfR3FkFaWj1AXsguI4UIgr2T8lyXBQkBCYDRyjtgV/vYcHpHQY+yt21ehmc7L8lEgA9LGT4ARNh3Sifcsn2k3fZUKQh'
    '6V8h2/D1ZXkDmOUoXc4NbnM5t8DQeyHJn01A8GWv3HQ8CIreovzZcSLl3H1a5RbqVnIjgfQD4jS+i/ttaPGWaTMcEcnJ+1MkYiHO'
    'a4Jouzb1CZXDGbCBECwS1Ys4uDFHcOwjMjcPrIVYt//83//vJWkl+i3LRnnHS97Q15s4VAFnIk+jpIiVTdOjaxn8yyAZFvE/7DHl'
    '3v3bRu1x5BHpG+6+2mInW73xUnvYyv2W2+kn67jVH8YjRFLgU0hNRJLzSXPZDBAWs26W2+LtD1PY1dW1R7BpFP32g1BrzcGjmvyv'
    'uXe7jw7NlZp3YnMgqib/ay7e6ooCn0/WqwpsGGhNYHBymihTFsnV40r0kk0DxFBW0hkY0oqYmpJgyIWtEH2CuY2RgrB9xpdOPkkR'
    'GQcmZaDDEIg5J5IQxSpyg3ZCGWjxu/aOtZZrY/IgBJVnsqgLDu5j77LnUWjX4sLmsskNu/EWHXjOZYx8EBz3ON19MkUQlQShFi1/'
    'dFg+DQ756BA+Kv8xLY6NeWajdBtaZtGEozBMhFJ4vNx2hpjCFLSjQ5iABiaG7JDThoBw6DPrWOVXNObmofIN1ha3hvrRYVJhi+ca'
    '5wA4+51OR4TfCTu6wyB1W2CEA3P/oHUgVy3sAL4IMhZ68+7yLQh0oofzbuhPkgtxup9zOz+OTy3vOic1XY2T7qDOPXfRjTerqAwb'
    'xaltaoMrc3gJuePObRgJuavm3IUmnt8pDMwGYIhPYUU2QNzUZDqxkVV7eVOKMA3iIuceVyfNmPtErrllA/utdR7VD87Ed5OCS1Lv'
    'vgThMfHgUOIpwYfdaAccDI5eWSfasbOmcbkvjQ6LQ7WFxr2e6aTo6dSrdXeUERM+RI6/MYdXHaYcFDgW75tkwA6qcZDTo5+NaJkQ'
    '+pjvQSXhGq0a5/TQm+tjZK6mE3SSt8Rz1RzLVe/V0KqzPsNNOYyvuEUy81izhfb75whjBe07DLS26WwzrpHI9OccTpXrGqWD5di5'
    '98bpiPHQhKchtus4iQfibC493PoKWuK8P4SlQVYUfFnymjAJF0IAUd5odbLDQ9qE9sYaVpp1tp58t28tI5t933xDLDr5hj8osRSU'
    'cG1d2LbYoLPvm3BIWxdr5RJLQQnPdxb6F9iSDjPQ2jYiudI/8TmfO8cpVHQZ7Qp6g+CBJNJt05FOf5akkN5KU5klKi3PGlg1i3rQ'
    'yairF+c2jYg+U9Gn2hD+5fa76Ek62dau6EU38px8WVTn0bJlBCwgRjAmoEG1VF6Xrxcc2oy/yqJ5KopzZuZA425wLw3YUIXUuV0f'
    'qHAsgNtzXJX/Zf/kdTYiuMk52TJmuegF4ATs8WC5KAf4bUVHItEY3dZm32BagUUevN3QAdirvdCL+PqO8SiHjvs5+0AaQz3JziV2'
    'B7Sxe/IRd2HNcatzeEaj+ivc+HCs+a28ESPeee2k5vNd+ztwlPXaE2MQyMd1Dek3Yaib+kxNrSIUGKL0P2Cz32rjC7iKGqvDevNC'
    'ic2s7RCApxdiEZBRIx3cInbHWdHcF3PfgxazU8GNXSB5SFDPbJTsDNVC2G4Fp/3B9wl8P47j8WCY5Nb5l8aW24GGlxHbHaKJfMnU'
    'aNU0yV+ALHTCLWpVrZkJlHUdiJ4dPhGwIK0JPzjK5N7ICDXcjkpuQpcZwDbIfcbquxPfDHMep8Uz+EB8Ixvo8qDk4ozT7NhrtBp4'
    'Uy8hi8tXagh29zY7g7I2T3ynnaEO57e5Qwm05tAK8BigNmjawJFWz2Gau5jbnLQwt2J+u3HkJK88E2jg54IGs7kNZgzeuRWT242E'
    'hFzibz7MClzl8YDkzcf3P9Q0rm2vzG27dGE3f3i9G5oA0VtQPb2hulC7+TPYZG2cPiwtWG0Ogbg2t53lm6ouz6+72pgvqLAPfwpb'
    'JXUtD3z8fP1lKXGnUsBSuk6OwxnsXG/6r9b5qXkSKLhlr7P2MjLm1nr5ZgWUurHr9bC55WPdbVejCp1NhWLZ0Ji+wRvIGdvBmikh'
    'xmUwou2oWZOJVGJs0gQajRaHme96Hlo+pE5utva2d5lGigu0oLcifX7e8vr6LyUzr7cCz+P+CWtgFmBTmOi3vmVdSX2K5lMA9qVZ'
    'NEVnrR/eawXGTnqXF9gpzLcguK7t6dl0mp29TQ6L+WcJCdvIab46Z6zcwidIFAubuKmFz5OF1YlPtlu5tj4u4W9qodpAZcvd9a+4'
    '62nD0MRO0YXke3e9h5V0y+IXQnthnoKDDh3sw7/wIcKqX6Pa2+TbXs0vKDpDdpbn9EUVN/s9zmPJ6ZhJchxzRBvDqeAJk0yRPw2a'
    'R1wTD9WsizWIY4lM2E/4EBzoZ9R3GVa8SBe09/fSYph4PocgBwXeWUNQ+8Zqg6in9xBOrBGuvvBctTpNmf3VL3k2bn23klq/LZXO'
    'OT2lTfvDt+acy6c5ElCD+nwec78DEnPzyZDWpfGFEAJR9sRTyVkdoTWbMGiThBMztODLFlM8eSV5UQQHJXwv8cJM7hoczwCRXqQk'
    'seLLHAmCH1XLqM1//e6y1Ny639o1N2XK6CjgmsfGiF+dWJIPZ0dWkGi6ZXEQ3f/py9mX5ehgaeWIQRm4xfE7OjhDno5hKMuwbFCK'
    'QMZIBisRBLXU+JdIHAj9oAS+E6veLkpGa53o9YfdPeEx6fA5TWNGt11B7peaOZzEOslOOoxnCCqD0FaSLVAiYyLmQ7RLOEmCJf8h'
    '/F2JwM8C24fZEecf5fzxtPNz2Eyi9/VO9OJ4mo3SGXYDVKbR7gXJMKPoWb+f5Hn07OMbKfmgE33kNPYQa4ZZjCx/vCWYWY+ar9Jp'
    'cpid29j2wVi7dkxy1cy2gZLsvh9LfklZJ4AC4RBSYnbPOrsf37zc+fQzXhpJjup/TPmK7C6XJfrTyI+zM7SP4eMjeAUaqDRiKk74'
    'w97FhLfF/mU0SPL+NOV8Fd2ooeA2y4jse8iH3SWS1oBInco4V7DdGt1ov6HUp3GAU+LA9PLqzdudn3f3PnzagV1yiBtdgKuxwfo2'
    '/PwYs4OwqFrP4imt/ksD26rLhbsNPFXLApDbAd5AVbGBNExnIBJy0jpbdfva192JRE/7YFtID1DZUBklDUzgLEC8QO3MvGyykowa'
    'QFMwTxuPFoS8yNkypE3fixtLcTrskdxVvJdxNsY0ALwsOK0zMTNsM4muxaa3CIvTi8YGvw4rNP757//dfOBZb7qJapaEhlio0RQN'
    'AWDuiniC5njURhDvpsB8O9qndjRtkjUjtwBxHah1AMgAg704TnMLVmjvLC5sR1+/jL+7NM/XX9lFtKVmywIy06wdBeYUNaQkWpuz'
    'ptvzvghFRpgI10gjJD4Ncwxgx7UkhgPv3OFukU1xsYRrCiIaTYf+7bIJ1qXF+bbtu634yyHIbSyGa9+2nVrmi5wxF5/4W0b0DJG1'
    'PXCTVdTwdxlqyovXpprU9+/ZxW0j2D6G2jV7w6zX5nbLLgXz0DmWpYs7dBgczgmmg1bBgXcGbufL2GMoqvtqoE9Q2EtHCaJ4yRFW'
    'F9BEOqJdtr66uuqp5IjYp+zavCeut9JCaXmKjMEshnIC3zWrPrMt2Nq4cH1OY2/uB603WwdtZxxXoZusNCtFDIknaXPCWNHLWMt7'
    'eV12IJXwIIcJYYcWvYyQ3CRDdLuPhJONNl8BJNOc6bVu+GUQ+0bdOOgw/8ey4PjyHsEQFB24Tcc7PSAeMsZSsSLEy1aQEOAXF7yk'
    'g5aJoWAk1lUipE+I0Z52yzuK2Uv4IMOaZDpjM5yOnNbIkH2Ec5YoBge5EMa3YXIGsIZv2slOsIl/6XD7tCfpED/jVdnBi6Z+QBmE'
    'cYiLWY718R1uf9mohm+BtJvsZU3ZGv46nNmZyjfF5B+pQmxDtEmBsw4307SYwTKb+caaNYvVjHTaomxxf2/7Xha7TKUbynW8F919'
    'NXYPq6a8qIJ4cQv3KReXxtA5cBaGfri0Mg4dgbeNFfp3JZeb/EumMV2PzOEKvRuVNgjHozEzn+qkpx3UtbrF6pyloNWpGCnhta6T'
    '8fITGOsiegX8WDdNwoyWjXhDDx3inXOog3HuuwA4mJaGD2JmTe7bCCv5gyh6PP9Sox+csyjP8t+zLEp+Zkd0MhcSh8LQeFoekoKE'
    'wyLxp4MMlJ7ktO1Kdpn7b/LBZri28ESTlXc4EN2w2stxzgtuB7Zgrf3409OOKCOGxqVhDhbULL9+0ejeNy3lAuWbMtDBpOvxR56q'
    'zHXTm/h7lp89OID0ExX2ue3rlh1OOGxe+qnMXtUSvWxaMAVrtAI9+zXzQHoUe4Sl7foOSEr4VuBTYrGJdTK/FcoOz7oLvgGLoj3d'
    'BnQ4xJIzJYsustnUSHlw5mLBStK018pzgv8Vxl+MhiubSHTnVo1QQdwFKIuqDROtOMBBdKkjIiyUUEoVbKxbut+BcVZU+6DGORVR'
    'bf5G3D8+sPOqNtG8NGj3x4l1xCLwia7ynbeTda/4oJOB6Z9jGDMwErZEqwUsPQ5PNxNI5l/bEBA4WKZsOV6xFm/UFIq59vKoD+0Y'
    'D90ZY2v75QU9bsGIa3gNkMR2hEyB0/CI5fiVorXTQDuF4U0iKa+E/u/E0SE6CyrAfYjFi7/vfNp98+H9ht/UKKUREsvBBWsOO19p'
    'b1GXEI84I9oL2WH0PjlLpgATw1pXmijEnies0VaFmm8g+fvE6pCGeiqDhGlNuMehMOHo47PJAEmjnPVhQzvoRvf2EGFO9Cg5NCNx'
    'lAcoey+4D5h7UB4OZ/mxuaEsecPCxu+jBEDwSkjYIxi4C+PPkFNVrSoNJbdynZfPgmDDYkX9bDg00lRN0OEaqS5g+Y4JAq+zUeK7'
    '2QpekIj8QfRkovQjVl2gOzApHBWBzKo0WfFkeGlEHZXgh2CVxQ6gxWK2tmq0kryTvP1VveDXHADWStS3ndSbbWs16V6Z8HqNxoYx'
    '/PNtFZnMcNAC0ZwNYC/IWjmrEAqJPwRv3O1QuypzOLIvdp2BQEKyVRtxUiEfujh6eaCsi+hoPU00IgJH2It7iHyCcd4JD5vDcBcH'
    'KoGjikqg1dpwxo6eaH7YMQ8bvggvr9+zMGzUXIcd/sU3M05d4KdOsgpFkrAQxQNzX/npTxj8ZrOz1PpuRVMhVOB79+7I2g0YkkG7'
    'n6ZzYVRBuwWIjBC9Bi297QwYPDbmRFHp6F3GV09AkJi3nz+9eZGNJtkYuoLR/hrSytN5cUyn/BRLdYujuQ3pUlKEl09jm1RVNak1'
    'sbQSQv9kxlyHw2Le2AxsFX+Em6671am5o5F7+G6EsMQSihjqeb5uyOS6vnQfo9FjhllvL3tOpPLxQ9hH0qPRMXyEbppQC6k3vG02'
    '1UDDWLpPLPnzjWMnM0yUoDvVIthJrihzw9FutABslEaIz2e5CSerqphr0eCLvnqsUwJ5SRFZMBZFO/N+ole3CnuzfzQpOrIJR7Fl'
    'Wjt1QtEON+6pltrRCa3XAi7vRvFExhtKJ12vbSOpSD0f8gKAG0QWlUx2DFQC4SSwSlokqazMxidjXLg16WBg75MrGTfzcS0jzfkI'
    'jcP4BdoX/SloEnBrmvCRWmKuidwn45g9sVBYYQJDkRsZ1jp9n6eFCCau7FIQPqHCf03GR6woyyacXDfUbk3kKgMHDZXjICFEsfmQ'
    'aLPzLwgTanbkATYPUgfMIWQIgosJLxKJ2OUJztBsziZsnUybvqkXrtxUK/QcroZxmvA+gmnsj8aIsZ+kQw2AhK/3o/WWmNX6X4+9'
    'r54IzwHAvz7NT4+i89FwnG/eOy6KSXdl5ezsrHP2oJNNj1agt1yhEvciDY3y3eWP1/c0LiieXtMTLB+fZ+d4lAhj1Nl1hIcL9/Aj'
    '/qHSW99dCgyun6LhLS9Nam20chervMHbRAz1qeYSDXqDjnw65orNWXG4/KQNDEjGFVJO1T1dWDnGubwNKBv7fzj97hQHtE3JuRsf'
    'xtOUpgVrZOPigqu8HPHIWK78+w9EZkYZ57qLDwuwjujQt4eWsPKKSfJAmLQEtOMnh3O3iluOdm3k8h8R/ByNBBHMX9u3d24Tx5xJ'
    'TVMQ3QasRwp1uzXcW7A0xwnJfZLohbPipsMhh36lDjTmTiEBd3pHG7YEu11JvHMdftsOWanB3GjqNRWc6quynIhSzpueFtMPYF5H'
    'Hzzbtar3SZnN9w4NwSRDXaAIcUoudEY9T8Svp9JlP5tc3LJDd+go5san6VGMQJvW+0W1vfuAwgvzklm/S3/yXTdWOmMOQldOMAw0'
    'qlSystum5wUlN99ZTxmfxumQiT0rKKGxhPaFD3Bqt+G8KWD6cXacDa0BCHxZTCYVk6wl0kBoiHeKZAt8YdY2LgY5nzpj0QT1iBFM'
    'irzNscLRAZ0E/RM++FkYWVuPsga/60Q7Lu+O9BT1aJeOOFumtm3uwCe4Zte7GhuszdmTN8fOgCM0U7j/ZUz/sK1ChBvIqYngY/CU'
    'Y8xvR+JozPd++7xAB3z1Z37DFKMgtGE+6ANiGRnTlq64W7BQIGCB5YuFHG1PC6dOtIvcL/GwW8ocBFHCThnQRC+VZvJZz0K8ebze'
    '6kSvXNyNPIJDLY0inbLZTi6BxA2Qe4A4STE5vLDzgseLTkxlDVfFSY860T1iioiq3MO4EKWJ6C0cargN9qeB2YSsybLPyXpWPtIg'
    'OOXc+sgoyOenxx7GxTuT1FzymJsgK9vR/j5ymJN8cYD7ZfwOv0m4Kvm6bxKdS05RriWXTxaPmu+bWUusVWbW4odzY6slIknVUfO7'
    'S328bunFcxjITef9HJDJA2uCkWdo1I5GxGwjtOYoMAuCL9Bda+kkqe5zdrKSwIScpF0y38N1c1aoE7TaZvZnOdxzWDFmNo5FQ8dO'
    'zXKJm05cZJt9ChHmg04UBgg1Kh7Xoi40BbCoXf5NcHAwG7PxYFfkPKyZLeMvN16xlxsWgs0DuL/gklDJBCeRHCCL6ims33oxIgRa'
    'fxHPs64PVVIGN/RkYNKZ8bgbw5QG0wdvr40I7na5Mc7qSW/5gkn7bPY7tktEqdRuVYVoT15eMiNnSFcMWOptBAVGNU/eiT9GLtMJ'
    'Rgp594QzMOgIV4NhnfCwPPPCIMhKOAIRty91nTyLuuvqsCS3Vu5SNLnRjCqj8dPI1s2qNKP18pTW6qe07oQfT3PH+G5TePnzPK7M'
    'sfGBA28ovWq0a4btDfpQMi8mSV5ClEOLKJxkqX7YhzzsNW8lHPGiDaP5wZ7pYGAxyZ4edDS+I8Ya0pI4WueydUTYF9LTFSulTvQZ'
    'coYj+m1uw52osp85x6bmETNN2zIbhuONdeB0KOgnjZUhYQKlqYg9jCQLgh8llQa+l5m2m8fFiGEu47b5OOywSAb405/+1CDUrNgk'
    'ZGzGBIbn5Yd3HyEUkBglSrBXRJp32WKg+fUpDAZIBMljpNn4Tf1J0G+L5BH++JXOaoBsBW/pzMZLRzmev/3w4m/U08pPzY9Xr9ev'
    'Xj+4+vz26sPbq7dvrvjb//r5w97O1cdPO1d7z56/pX9f7zx7ebX3/MPLf7vae/Xhw97V3id6ebX38ur1p9Z3K16Sgbz/TsKEEQkS'
    'EIAnoDVzHEVz/8uXr/d/3v9y8HTr6qDFjMWXL9+t+XamZ1NO3obcwUUrjCwrrYLwm8j3Lvap72+7345i+CUiATWueQqrtmsSO9Oi'
    'UeRfdg/ub7f4URV4LrItPBXx/3Sgv3rWeU0lPcnRIk7muRsj0EgOGhOHv0yEuUIryCHc7+Dlngl5BL/Yzt7OP/Z+fv/h5Q42IFpc'
    '2hT4aum/V9IsGB5NorWLB7JNUFDq5q7pZuctSTbvTU/1KUc53UOniI/EvIpjmVp1mACC2u7DpO09T85X9hRq2s8W+fqwu/fpA5ho'
    'My+sd7Nx/35DG2+2bBPWRFyrvvHb2XlXaeMWTeyWhvLmbzv+m5c7b8ut/rf/dotmXxAEG86ooy/RaPu+teCGadbsDS7U5T8uVnLj'
    'a4M1U1+/skKIy4Ct/vqVOeqv/suvDbfE5QE9a1SzlKvVGAvMzwraQL0ZiVkNvIYppTHD1Ll63L78rzT8ppTnsH69RLICcQ/bsLEW'
    'vg88IN4JA8jGZLY5XFZ93deS7HfHCM6Frg+0omdN3Wx9yQ+A5lUVSYvaD7OV1+DOOw/nzBwa+6oAYXnl69199FuGTz7tN/weyi0/'
    '/1TT8Jcxr1cU0Y9KRaJDn692Pz+n/3+8evfs09+IBomCsmhVmtLlwPiefndZhAbj13QYaAE6AGo+h6PWprXGRjWxOx/QAa2DwIP9'
    '7pjDVtknmc9F4a4tGZRQ+GUaOEw5zO5Q6MUUvqQ+KRymhtCIz9XbN415ZAlKOCZE1Jipw6vx4W1DMDBdWrrusNyxjIB6sx6jNibA'
    'G6oB1ErioiktdWz++nI2SIkriQgdNDxH5w6MiNEHOO7WknGfvrJ5Ea07Tlu73JawthxpES6DuS7Mgkd8LVrHZAotpBJdGpfZo95J'
    'MJYzdSwWJr3W9dc6trQvKQy8ZTBoOW94/rCAEs0+w7RVh0RSVHwqvqj9tYdRbN7HK1dGJPgRKKxpWQPXZVz/Noppo3XAYmnBWjEU'
    'LKZ2FgdWBi4GrmnNO5QMhbYx7IqBf2LdSuNh7y94X7ZMg/jj8Tc/Xe3/9OXLQevLFTfx3dqXL1eNsqHHPiqxaPcMkbmbLj1AO2ou'
    '0dhC+tPPhmLHDiK51oqW6R8WcAkiBA9dAD/23F0AspRB2qUG0hNqmPt5HmgwXAnAZdiaHdGymnsL8qk3dm5n2ZUuj8uybXYcYTfU'
    'dHNqHHCiK3AwJczxqYwZReOKT8dqZd7aV42An9vnJUe3EDzbprIbvxn08jIccqqt8XR52OIztCbOT2iW0HEunrPGJ1cusYzqVh9h'
    'KeaQbSLdO5XFhqqBaPm3lYVDZa5mEVXOpZbTTEAP7bVsYoTW8aX+lpjHodayjsyRs/RQJRuX0rsMpl/LnfIUm62FbGfhG5rXcZ01'
    'O1WP548eX3auebMMpM49SJ235nNTr9d9JvH1gxrmymvafil3YY70czBDRirkw8o8EaF3nYCP+JP4UIDun7P7xtf79/Hz/n1H2OeN'
    '2gl0DW8Qgpa0FhZzgbu+u55gt9P4YRxon4eyJfti6G/TuWwxyZE3cMX+0WVSxVUBpqwyccVf5WgzLPCXMb1qLFi5z2/9lfvw1oeE'
    'OccaC2bw+lOjZgEbzuiAgcKUY14TLEj7rYh9e7/Uqf1MxMauUXC8BhulhmHTV1oZOgWrB32eZcMkHodr7hw6hMt4q3yc2uURdeXt'
    'xonmatEDet4J++0NoVUOKXdZzds8HBW+zsOngKzPGim8RoNGTdxPThpV0hiXE6eLJgl5zscctVWeOaJsqKmRAvIdGhun+ul5wYeH'
    'KbYgBxQIPxyvy95kbU7XaHVKFEzibWMw/Mtlz/x6/625L+je53tmKeA5oX71UvlpwC+ve9FjegjV+BOfaD016mnU4GIw/KAuevzT'
    'NzawXtPC4iZc6cix3jRzKBP5nF32qtuqKyvIfXGid2S8msjYMWP1n1zXWBVgNlU05nDD5jY7nRr9nkn8QdImorDJZU2wYsLm1Aww'
    'kArKwBimQYiA3CcXvDd0avJRzh2eig9CoWreNmwqbvImZELXUOIYULr6fvlZi9d1p217zVU05t+48+pAp8LW9na02ro1Klv82bQt'
    '2XBX8s3m8n28Ct50LqIFwC/hlQzD35fVVYsErrJPtZHyRkW5VqPUrEd7vFYra7uAHHnK7gj2lVWIgfyA9NixNnxQVLXuHmX2T9zL'
    'B+1rFRj5k6YTFXxTTf0uByhQY7s4j5DIqM34gTiXuHIVq1fsO2bTONb3D1l2RFLey6wPr/Efs+mgUzkR0JKXPBEKa1adtsWqeTNa'
    'XvOMPYbCxOLmEoywWJM2uSTsFbEHuYUlauLpyjDderoyG241JEbQ8jJbeG7cuTVmLzpRELvIV8D769fys7DecBA8nWw9TbfcafB0'
    'Jd2iAyHJ+80qrkHBM9nyTwZvM911lChko01yAWAN1Txea3ByPrl8Ol7HL2I0r/elnQN7hLFPHQf7MEBl7VN8BI2TDJB3lGid5DWP'
    'mDhYhsP1142S6ubaG7SQ1S1em1ZpNZ9G9lzwl5QW8ymtqi7o0pIJpmIpoYzZ1N0oY4PUlRrmkzcRQ6Fxi21W+evTQXq6ZSb0dAVP'
    'ngv19R0fUG6/oXWTkAmYb61Y46gzyPrnYrDwW8o5p/7x7q24+HSi5zNi1qLeBRuuR00YCsMBinZNNppMkzyHCYkcYzDRw0wQsxM3'
    'aDT23jSepmgGhudsZIC+28FObM4mbM5Km+jlND1NWnywvqW6yYfDQ5JtO86G9sWnFz8z6wqOsNmqmo3gtuozbfYH6yJKrz+SFJE2'
    'HSa28OpGhBWlb/RD8mGyOkZCmtqiJ1IUyQ+e0B8URJF+9BcOALJ6vvPy+ZMnD9ZXo59o80ZbW1sRB/jQnxtRsT8+4Ap4Xg38CHHl'
    '2Gpa1+P+tP8A0a57F4UxATYjWj1/pf/b8MnEOdaJi8uoLGT2aSg/RSTh/YUm+OjAje2Jc7zkIq7hlh2gxyETKrAdk7p6scmqB+xk'
    '3Fdww45gh9XfEqQYAYCZiW5L0Mx4qE+SyofvE2Fg7l2vFam4s2dnUDO9zmZTmF48fRqtrUVX5vU72rUSqY4+PHLvdxNqZID3DHUX'
    'ahPeKJscjJJ9lYjj+rckhtZ6OVr7/skqt/M9tWNKvCPKcMwnzVq5Dzdgvk7jYKmMHXdqLqkBsBLFFlt/gllHLgqa6oXUNq49AC/q'
    'duSZI9bx/SpO1aCeeAl1tWgbqAMcAwI5xyB7u5KInTginrWJTT1q+TpIjVLsFiXmiJp44N3zfIYUdlzZyYWncIeRLQbdILUZZOCx'
    'GH6qBDY4dRCPgIbUfAB7w/PVh6sPHvYeGU5saFpee9x8CP9+m3HM//KYaz5Zrf/6hI0TvPH4H9fwKWXVTbXm2jovRs1HmujaQwZ0'
    'fcv4/kRW0vKBNW2sr99Qhgax/liMsUtlNMIpbSzlpY0dfWXB+wbCDwVO66trHoT7cyHcDyE858uTCuz7JfCGwO+X4BsAP/j4sAT8'
    'vg/cx1Xg+98x2DrABmUe3lAGwH8yH/h+Ww9pJkICwiJC7FSr6BnVR4Zg0OH+YFUt6t3djjesMM2PCdiq7dK5OyMOuQkBTMLpQ9vc'
    'wRnwVgdsIu0u3M7r67KZk3Aj08I+Xn0EZLHAScKlF46gBMCkhAB1hUqdAROEIJXb0MWuANezQJZwHJ1Oh7cDa8EVQDR1G5ZDc+rq'
    'UTkaIj3NZsQna+5d3/7l6dY9vr7taxyLxl8QSeMv8WiyAf72KT8NC37Y4ocjebjHD7/OMnokTrXPwXFKBshgq3i4cKT8KHe6/hH6'
    '48/vdyFbqItA3j9ORnHeASdJQxYBJmeXgTNimibTDKGq6EgYDeFD8HgFtohexKJPt24uY7bqpRrAS2PTZMhOXjnCpXutTmdjYz/z'
    '9elZd7pF/zBIuxwXcfMemMBkeprAC0Eg3WQOnIpt4d+p745AixbzeQQz9jYCQIsh4SaH5NE+Juhj8nEKmyI2d9+W12L7ftY9jYfw'
    'i+Bv10gTK9poEgHQFncttWnsZiwTfxSjZJDGvuXlpZLTaaqeQ94uhKE8Af0Tw6EpZy5rAyS+e+XiGcW4A+/2llvGJKdvBm9GR+xV'
    '0zZcwVc2SCaG/rrDU7jW63FpRE05K+MLNa52aXS09HPSVYugQZoXe5v3Vu/xr+f211v76xN+bX3V83sJrU26NBJoSvrsg9I/v75H'
    'k+WfF4A5ShB+f5xG6QBvx/QdY9y8p4ge8Tsp2H9/+sM0nhynfQ6mTWvzNO4eeW/e8qXUOHvB3qbP8knSLzbvraH6Sm19f6y2Ka9V'
    'EL9oNk2t/82C3aAgM7tKjS/ubT2lX90JmsWP8SlNDCPHAw1IZ75qpq2OuhiyKYHymIFf3R843veG6eRVOhxi7PgdTbsc1REN0mpz'
    'e3GXWEGEBcJP4+KBhr0PK0Fj5V7yicD8/HA6wl8iANE5D/4C/3If0JLMW+wVV3UyzYsfkmwU4cfmvSkN5R7ex6dvcx2UKaKjks5X'
    'DDT9sa0EC7blPcvCCwYzGbGI7UiKd61psuLU7VA6Lj9O64gL/esRC7fPazZ5lYb0Hj9UYU28vrZY7HzCBy1brjfjgkg/fSu5ZOph'
    'g4vCePpCEsKstvzENGmxM5phKmft6JizGPzI/75ueZIhJzHiL/0Lc2fOebObeBvdj5Am4Ux1rVRkS1u4lKpe+T6C7eMjVaCpbkiD'
    'eAFthjUPkGwWelkbGsvCGoWJWJvDVozFwlU14nAuEHNZqwmXxHGIGKDhTOEXwQrxVsezJ0fr7KIEWPQqhFZc24wSjJ48WwN6mmNj'
    '4KXlEEDD/6mDhKz0h6C99mT9CTO4aw/+uvbYeZDHCMtO9dfTMcnea51H6dgfi6iVN2uuaoB09JnOLWS9wqbCFd8brmAVQ+4YC8i6'
    'onXTIFtTPfdabePDFyTc8Zz52CkKCln8QMO/TBJ4S5ktgVHhAIeq9KzLDnVEcNdBC6x9z9ey8QDYEFYaYikE8LC5U03jt7jryN0V'
    'VfCC65s9rHXF80G9ddS0KjAAe2NgLno7GtKDx6vIBmZ18+o+8ERF+iUUMNlWYHurfehdDJdmHdV4RiQYwneHjgrbJ9u/wkv0+9X1'
    'x2bcZ8Qt2UR5zx5inEfpOL+DPSJO46qu/ef/9n+I3s04hZc1sdCQqFH++9nIma65Up+YhxCDSc9J3HIW0NlyqMVApcvXRNKLYSaY'
    'jeB2rp1OaIoYGN5iE7P9QYZTsfTgHtepZW+8RoIJ3sklg8sHHtk+cIkGpV/CvkyaV0ERgAMPg0YkMaoUOUsLGwK+bDy8iIr4hMp/'
    'fP/Dyn/5uPMDZweikVFTBWK/SjZjKGAdNUEPxHnlKhzBHqtVl+qJHXX8NE93x0aFHiqO/eyPbRwBnPsxVMGbqmLpDWuxlaegWlR6'
    '815z/6d7B0uteytHrdCyxQwVsR3Yz3aeuWE6Krn20hv166V/TVmJZGH8dJ2brudwWDV/wX4Q65aVnxxV+QKyomZ4GJhHX8JiRGy2'
    'ywWZAGneFav28sbJwGald9mK5Vbeup6vLs1yHBMmxUPOiRR47LpvkuvI2cVUXXYDH1lxkaV+dORwfjUxFXzn1w2FGwOmbAxjl5bE'
    'WwAG4ioT9q7lJ0SHp9zHWbc8Gb4oKU/CSgPmjo12F+QVEhkntCdS6G81IAzvTv7Fu0nYYs55k06T3O2X6UeOThS6EZx7TgSSDa/P'
    '7mPncqNBjNmrDA7cdKDk/ZSYbwJnng3j/B69On42zkuv+rn3vLIVtNzzmu2VvqXet7T0Lfe+QYN6kpQKgBJ6ZfrZEFm2RKhcffT4'
    'wYu18lBw9ng1jgnkQwa71rpIhsPsrFxrxuFny93NTCUI8sOkXAkWwVwtn020Fk5qULZn1OfYSb9SlvYV/ZFQYHzMU71kqs/MVAT8'
    'xLnyI1PmeM+Zq8Vvx3oY4twvzrueExhYF8PkAJNw7LWN1xWH+RabbD1xnekKfJRfqxfs+sqDiIX2nJE0dFn6x2iovkrUdatkgfsf'
    '7oj0H+qK5KlScrmQGGBHHrYlAESrbBYceuvc6K9zO48dz8XBN2Zc7Liz4dVyRpwGK1nF8nHaPCTw/j6lkDei4HxzFPP3+gnNMdk8'
    'SZmB9a00Q8vI2zgHYR2baAnku9Pp0EL2jGGEWVPX6q39hWqaTW/f7OeFDc1u39C3OCPV9JR/Q0+fQzB//riw5f2SH8nB7XuCO8vC'
    'tkHib9+cOlbNbw7H4u2b8311GkaR12PVER4a82s+awQb8pg2yJRTsk+7opZTsaFZ717V4tAxNeOX1EDh+Hn32h78/Vvv1VSlOMKv'
    'GhYIuTBrvZoqVCcd2Vl6ShpigphhgijcYW4JYzcivUj0EOitNIiXJB5+/2j9kc6Jnh4/eIRYcY8f/RWyfquOAPlOSh6sDssLex3e'
    'f6oRbOkG9CP7x8PVqayWYn2UUXVX9FNWx811fXVUnU/UIJmUzhUVcWajN4O5/klO4mMBfY0gODwd+rkdn/DpbO0PpZuN2x1dC9ys'
    'vsHR6n+WA5T1NPzYZBxgj/BL2hyqFVj2VBJNgA1mgNVbCwSmIwYmZi0na8e7tCYfecczsC1/h6drW+LNwH3hR1HLmtpfvXH+ax5V'
    'Oktjhc4rHFia3grLjTcVIyN4xxpcvJVfVSjwwuMIl1HsSGW9hNa8PX6To1KbNnyrZBNd9jpac641C7y6zG0soUEhJulIJouumgWS'
    'Ba+2avqxMcYOh1k2bTYd8jCMVngssK0UMU2Ogz/nJZmBHvPfNu895B/Cb62yOAVRZvPe81f4z0kWVqHKjTLMGwXnUm+gW/yVDLP4'
    'NeV0XYjnxNbKr93PvzfEy429hqQtyzM2/oz4DYl1k2rUEAVshqI33JI/gvL040ca+BlfNQA89xkC15gN9Kib9wbnMaskWQDZNo28'
    'YX0qV8OHSnmlll/tplgyNZ8LEKhFBYcwpe6DFHsbX2DUptXD9DwZyGakjy9I3nsX8wR4WDySJ6vlQeAkVzGx/vtK2NqKAUzNsH+Y'
    'pgMaM56O6OeLbOiDjQU9Y5nMKGRmxfW+1lDjgpNkA8lrXLITjdDdkVBkTDWD84KlHubdKvuCFXpNveIoVfIFCiDGLGflIgKPERDy'
    '4OQIRzvglN7T2rPDv3i1hMBtRHUGRF/G8pxzpbei3jSJT3xmg8ezBCPAqrR0zISnMqOgJE9CebGiz9jSV0Tvl/F8XIPkY00tZpZ5'
    'F/TO0f3grpuNdVnJcWzPBk5+7lEChCvGI+4MN++9Wsd/oAvSBqNIP8A3wTk94gJ/VMRTpA4vnaRDjeD8M9OBUd1j2J806m4WcK8g'
    'lunSq8/UXocrviHL8JQXTh7Y8vLWwL2u3WhadmIefQbWY6ELMF68AQS6xdRSqtccgVXr43XDrAWPTeDpCbbVk9LOn8hggwHNbirz'
    'AVZztFoHzqbEdYIJSlJzvDJl2mR2zTqYc1larAePVw0HvBkFZ1DpxIhxBkktAcfk+cCnezWn0tq6dyw98ZDx2WP8p8vB7TQChyJ7'
    'kcY3Opbal67OmNqHd2Ul2xINBrKlP7YJyspvYzrsz9IKavt8a7vi8TrP59UERKBOZbtwxbaF1qUT3nWniLRQ7/r6Dc6vf4D7a0m+'
    'upFJprZ8TZGJchM60d5SnVNyrK3V09SqZDzlgAN6PyBRN8N+rsy60JnWIafEmanpGvvM85695I4XqYVUtEWLdl6lRiziVuUIVal+'
    'd2kPvAftYC7b0TqN4AHHv0OznFhasr3zZTNf8l5/bbG7DkFTBjJX/F3gwIuBG9dQswS+wDDXAXcueG/yxa34fcIeNpVogKkSqrIO'
    'xSZ98xWXl4Gi5lZazGFJi1nleANZMaA8v/e0Fpp1m7Wpdyz2BbrVRXvA00O5o8mQfJER6on+Y4/mr9WJIh7NL89mgWcyBqJ+ySpG'
    'btRqZUroV5FVSzRnjuha9VQ24LoOrpHzD4fGBuJu2QWL/d9KNiB3JMmGveUoO9bZO5aqWYi9YvHcDb0oh09a/lULR3YjNL4jYYxu'
    '7G+17YXNc81gM8COh+hFnYPxWuQC9HkGDAFMSi5lDJTA9qqO43kitif/sgGNU5ndcSIUd6msXMqiWXDv9+h7/Kd4aji+ekrgHOOi'
    'gBDM6ez3dmMJTr3PnevY0wSCkdHsgsLdfJNXIU5gNvBp9loVV77AL9ZQbu7LHMeNPQ1kGTq0VkyfrQ/1syEnDo4juUt1xh/wu6Mz'
    'JIcvdDSZckjwMw5Ow6G22XzsENkA2OBmAvswL1C4GuB0SvzFZHzkeYeJmV6Y0MjEbb6UyPFdoJ/oQrxY3V0TP5GH0qVD9rrV6sSe'
    'dX2rwtoMKg421FWnx8WNdRkiQ0tux+g4Gw5yNYg6p50O2xfbogW5GoZN4GTekEDYTv09OIUSzBrUw8vIf7MOMe3RXx+sPYLB/uOH'
    'q/DomCe5rT9cFV3GL317cMGKb+oJKI7SmvF5xnuw3FsyREIelIpaRIvmOmUWLddkECyAgzwA7ZQTWmPMqw2JEJRb53I2MZF8C7Sy'
    'DTZL/zpfM1umxaDDdZratVoV7e+BkGeMrmYwrE/bJhJhMgBRd53VexKGjqa5ee/z3qtlEr+Q+mkQD7NxAjuF/N721h1YiZtmOEmB'
    'iM7wRiDRWd5M8eaT/+Zs8jtsqUO/hZfy0bQY/44G4fJg6tMe+JfMu8HSsL0A/oD3Q4Bt1RIc7f4mKoW1te9Xmbs5pt+Pnzx4Igs9'
    'OXoXg6wXGYFl7eFDVu5NJYGDeRSGyT3L6WWeZLdv3vvrKgvJh8RueI9Hs8KqAYBDZmgrOmi2iNZF9K2SDzPJAF1nixPDHTf1TXHc'
    'myTOi2d5Ggcv2TxHH1WbrHp4MeL413BQG6lg4Jbgp6bgyfUs1ccta7yCmfKi/Wb22/q6rE3+24u8/G4YM03jd8l4+Yfn/iG8Uu5h'
    'Un6ax7BgVVNMa/3xQ/PwaTZMlJlXvlf78FtdCedo4WE1VxN7SUSvBlJOeWsu+Gawee89sHzIAGNXEp2fvuZ5//qKd4IiESre1Jdt'
    'nc/zSuPylttGjO3Bh3Fdt2PYwC0cznyw6oGzYksoo+QW+lHNQss7b0W/bbLmFKnM10TwX/sj54xsZO9hhRQCQHJVbd57sM6YFRhl'
    'U0Hl3t66s6geUL0qf7v26sETwtCVEI4PauD44A+B4/pcOK7/J8KR6P29knxRC8a124Jx/dWjh98/LoNx/XEN3Xn8R4DxwVwwPvhP'
    'BOPaYx+Mj+eCcf22YHy4iv8qYHxYA8aH/xIYw9v2MizxNSpdxi8A6G1ol5lVX8yIZ/FwV4qEJ4GZhfmZ+0c4p1/iS9p//vt/h8D3'
    'z//rf/Cf//P/a3gOAYcjibLQGCT9lAbJ17kwjnqbgHWwj5+yUTz2K2r5t+LtsBl5HktwLYLM3o2+h8qy+bNRq4EbFh4YrDCbJ8hB'
    'zd4nwT5ifvfVqPAsVWmk+2n05+jBgbLJ1Maeh55/puag0Lju2M//xQob4Jru+UAPVQHq8pF6Hh58/wNHQuZBHjxeLZ3D1HxZb2eu'
    'TP5zQCL+JrWg+O6Sl78Crv8p8LBuMP8ip+faqWX24h7SS/eL9zNoF72nN+xfiSKcuYMxlm8pDDG8IM508A7feOnUUACLyCoSr6lA'
    'P7Oww7Vv7TDYTwv7HXN/Y7+foPPysT726vteNVB5pwODhEGrhIWD6/ktr/GIvwG9P9CCT6FaqUdz73Nwkno1fdS6trNy73R+Df0k'
    'iOILG1PZk78fAT/5nu2ltHwL5EYi3Cfw6qh6x9P8/TYjAH76ZsAXNPm9aI9PJBWfV3LzljPjbt6TZziWAVZ17dCKlRuxgHHtBD5q'
    'vKziLw7kGMkKVhqnMh12Ki41z+4rrmluaAWFjUuzv4YaUssF3KztaFjbkTUfdZ25m5WORNk3n95lA6q5c06H2ZjP4BCRglUNROBU'
    'ZNN9xizxnEfaL71P+hkjyg8AtYbJEvr7cYsb+5041ZcBLXNSd8IplQYjTHksAwHu34t05AJKP5376XhQ6mVZe+gECLuk2FbTA77M'
    '72B+vQlwMahnfaDm1ID/V20V/kB1LDEhnqx4z071rEBasb5fiwdbAw0JdGHrl8NodOwX6JUMlOaOw9u6f+gopN0buw93/B86Atv0'
    'okFwuIdskhPiTpNvH4PBTNRedp5ppscV3kpbX+kYCjfuz9gEK0Do/A/YsP9Zh8FamfSFMVcc/ati+JxjYd20+K+MdmWUFDFguFJa'
    'Bjeg6jJjdUrktrJKlVp/wFr1J1209tEOUvnH/uSbgTB/2tLkwKmSJ7PpUBTH/ZVE3EzzlbXO2oorS0fSKK+twF9syfM8nZMAeG3l'
    'H+/e7vLgl9MxJt+Hrm3Q7/Ilm7v+c4ngcOjZ7yjJnrDZdCvMCs2FzKenOlZ5kQwiGpExjdMvPz548XLvFS4cXWC+TpG92f2gbnUt'
    'TTCAkAjft67/KzoIGiXsqKxUDYZUEN1iiL2NqK3iqK6tYJwI64oHVNLWcCJIbSWhMf7gQnrDPCjXPCjdq0oqPjBMLQ195QXsMc0L'
    'QwXTh1HHxW3r0pMXy0fND0phFxt/0AkngdXrs/J+0Fjot0iUa3UPms5btUAk3JrkykGqCaS3sSHUEQ6LE3nzdasNjoVm8PAx7Xs5'
    'j40Rg4345Qdst2G+upEfoB2mBuzcOdIYxmz1w284eLEJh17JSe/lFMYiUZtt/DMvqfAfDi+XfjiIOc8Ac7fmcOpO+8eaPTHI1Gty'
    'b+az6Wl6mtggyJWox4S4EvZYmvw92Y7tXbTnSFuzUBJH2VsprzjiR5eakQWqW3AOvV9pxy6oacglW7bpll9IqmWkSgZAkrngsIa2'
    'frDxG6HD+VN9tCz3r3gyP+WzCXH+uxM/a+8m+bPFUuCs9v5hwsd2kMmW4/3OQ0gP9zBGb3t+ys6o0HE6GHAgbPMFbtb+e+S/PQ9y'
    '6nI84nfJeKajKNNPS76qXkAdej9rtFpEK20HsFCqM29Z0Mx+PE3j5eM4n2ST2eQADfYQhMFzFOISRBBpPyUDqE/Z0qMRZgcusiNC'
    'Hp5Kr+Ag0TZ8DQaKIMr4rXxDJP4fkq5eghwVRTb24tCNEeeJWupAXa9BLXbT3lCSBxCpF+0bCur8N0x8Z4EnHr2vAL9WMyks9LEV'
    '5UlCwjMKd/koQq1ULPEwgsXQUGbANMZQsfCOB4OdUw4kT7sMWdwaExLUadJMhDkk5ZZmBbgLTxIwmh2eRF5sd3SRl5HZEAvjz44p'
    '9h2NpCP/U3uhFTpDpyfRCDGIvI82UvTe6513Oz/v7n34hFjRjZyZpGXNiN5lE5+GF+2YZr+Hd80Cec5HiME2VVQTnKVzmAvgJUBm'
    'J29+6OrxkU6tdQq/NKZumm1pSJZh1o+Hu4ShkIqoBpNXb9hsSuWow7Vuxh4PgzYc25aCzMLonSZtDCgBl4ZEhpATcJRlmggqqM+c'
    'pO7j42yUlN+Xm9s9SzEQDt6FFQDouX33wS6JJR1+w/6A62diUzWj2s5QkRqRvBBK7DW9bLZsxChi6cZEGnOiA4i/IYmy0SIzU+OB'
    'ZBO8vsPBd96BBWs2mpNpckiSyDJfSC2z+EBnCsbdooFUEbnPEQktDquVHTgI+Ckgls2GLqd5FyzrUXVZy2vK8+XKLYeFSccEqNo2'
    'K+AZpDFlMoDwZp9f0LBH0WxMrGMeXWSzximH1YLBIklWd2o2E6oh/wOTg660woQz4dTCJ5zCBG/5JBvq9WORhSXFmKm0D/3E8YlI'
    'lx7LRHVhShndFSjCEdfmjd/Xjwc2httldJKOBwyC8QlyMfR+6daUh8OqmFR0o7dv3u/8/HLn1bPPb/d2uZwf3Yrj9nGCUNv9e4zJ'
    'Z8U5S8/dNP+UZUUzb7FjgQ6jmCactJvNx3MdT95hIF1dscvBvJGgKvslMPLYILVsubwnsYPGrFb957//P99deuntx+Xc9k4we7Da'
    'uv7nv/+/XzdCFgAL6x27zs7TXxGzU9070ABngI8jBc44DbTW4NTJJ+ylIxa6tBxq4PyV19PEQvvu0s6o+b5ZdAhCfOVAciyzrHXf'
    'i6wlaYa+MkoSlvmlCrZjbkl4VDNiZT7C8RbG6LghTADn02YMBQ/GO7oWp9OC0Z24tP4JAolJAXqDaXbKJrVT2nWLuQ4eIRYgIvp+'
    'hLOtzLJQGzX1hE1oWAPdXmeQ5mABB7wYakhIJ2ic5yBVHWFLmo0Mp+1dWi5CXIHpPnowRxL0HgfIfUOnlGJn9XuLV7ZnX55aE0QD'
    '8+fTeNw/9lk+OsUZJ9hvn/eGv0afkpyRqjIJU+AlTT7kIYMGGcn88m+Rnfem4tfB4Q6EamJ+7Yi53Jt2BFPlwtAfoRujUep9rWwD'
    'P2qc46Q9UCt4BzzbSJaH322I3OG9oRFZ6TCQSoK0kxyuQ7YFk552JLW7Utk4NtxyQGhBx2Orfej9QmjZOUkuckktaTMTed0q+HQW'
    'dnr2+4bN/OMO5fBwyASlmrdZlSquzVslb7Ol7ECcz3qooJQEzK9JkuWNtkUHAX3pzIExATWYpyu8MX+SMOsXFPwPwTtvoieY536D'
    'NWQQYuIpbXD8YP8z/GDOp1HGwxMTChufZ3TkZ1k36sVEB5ku5pJPu5HfiRatcjD5f4lSojGiTDUMGYizkykMLd2MyoKFI6Pi9d1r'
    'WTpQpnntkNzVCR00s3jEx8QxImqzFDGP3+Gyiepjb68lMqnOVa5GGw2OBXG+IP5hOp7MCmHuqaAcCeKgHjVkHI0N/qIEIHIKZXnP'
    'znXwOZB4E1y3OCY5VifZME0bsaCxA8kOaCHttyME18fBCiX2sBO9TaCaSIsoGU2KC3xhq6vUF4Rx30abMokl1DxPvSTg60uu06QB'
    '6HgPCRC5GbwwoC4xyyDjPcv8sX8jDHDTexi6OU9pLAkq+JstMk0YHYOfJMWCsTZWmkl7bZmy9dVVa/N/TlVG2SlDvTRZO1gZEY+R'
    'ju9TJnDQ/yvkJbKu++TdDPA+UCoh1L4VuYp0lIQky37acBvWz1rlD+PuqeHMuUbY1c3tIRw0UKrpQgkDGNVtTSdMoCyQ0XTyIpvg'
    'ViE+Yg140/NMSnAqaRQ1YGTD7Kuml5PDzscvnffjSeKKqzSF8bXmD7A3nMGoTty//Y5aJquWL1Vl2RA+nyGBAIayim8vHSXTDV+r'
    'BL3fKD8qnw4gBfwRRKwocbl8KKMSPjlekIbebADuasoFL1N0mM2Ihba9o5J9YFmoMIVkin6TirvaKmP2qpdfIz+DrPoC5wobXnz6'
    '8GHv51dv3r5ln6SPz97u7O3tEFOB2UjZJC+pA/wm2LKkL5YlQsIjHsrmPSl1j29PlvtsLXd9T26DNu/hsDriiOZdec8oqYW2nq5I'
    'U6GlW2lEtzxt+v5pY86NvkZa51OGJ8KZpa9bJZlsT1AjYATKwui2yqI2Wi6DiJn6oyQb7efEuhyAIIyIgMINLG859Y5lpj122wjb'
    'm07abd7N0UIzzd/FiJfClAVkmYircd3EdlnzmuaAmrikqRc8xGlpkoybXh0CxTCe5KUBSed3TxDKhgRamZGtw4GsS+XrGgz3Q77d'
    '6es3jt6xw9pLFgNtHdvK5/EgK3VBmJPtFoRFXjIeLvspqZSdJtWy36CO7gjSiRp6rhjHK+44kz6vR95hBq6ewd1v/OnwOZ3lnPz2'
    '8E0RE/rK711E5BezYCqSHh2Z37vHIIb8E6kj5JdIbPiZPhsMwCx+x2xu7YpIj63583iLebztHJ5FW5vRX/VU5Jo6wpvrplzQVZRR'
    '2xsLrH2OV3JK2mI8o6AUnOvDQjzDGm2qBHXmmAHNnPMLcMrxT3L0//Pf/wdjVqTOrXi2w0t3099KCM+vPzEdLWO2zV3gV/WGTF/x'
    'kkf9zg473xlNjt2FqXB2UCODxcw7xHsdx3lqFyl/FQ+S+cUP6ast+mxWZPOLwrNpL5WwuVyc08d6Qw5Kg693g/iRVfz1JaH+d2dK'
    'xtl2EKc+OW1Hh2M+kwQJK1RaS3iEdpycfQP7zeEBJFgw4og79oYYj4/E0FAl+5WGDE5wGI9P8Jgzx74ayD5wTpZvBeFf0gTFReZP'
    'hFPLDCukV33vkzMrTeBm70UxHS79V/DMR2AWELB7yLpblsXkMgq4SbQ4YbHOHFBuxlRGSoAS+0U4ran5iOtD/yMU0MHHZ3n587Pc'
    'FniByCf+d+EZaGX4S7M/gyO0LY4Txi9N5fDKfDfCjlciEKFsO69E61rtFR+arj+9QSt1qW9tKT0og16xP3dVq20LAtv9YgU9uzGl'
    'RXVIl3rZRpjQcAhxbSvx6ePVwtFjP/JxE4zK+yh2C5CU/SLMnnh3k0mHVgD+6qJacJAxGuFK5ctF1TdK2mR/Km9FIV8CAFuH45Nb'
    'FU9z6BX31T9+SXsCOSio9O6Xqi6hTVThXyKG6xqOX3Hsd0NUFiSoym8+vv/BbZdsEiAQjEj87zu+GU61Kf0QNFdT2DNNMUW9230U'
    'NHdZVfMAqlBnM+B6VP6pAmkBkfnu7UHz6pnwFAvXB1fPw6GpQeJLj/Eh4bwO15UmQTvyb2+UmduwRWERf88QzRWca+sTNd/Lzm5G'
    'RikXYqHchM6lI3JdLcOQC0J3HR3c0coNIRgTfhX0Idx7pQ+Pa6cWeKh62lEzODP0ybRjGUxLDhkF8NYWcZxnWOiNYeOkmMeUhmOi'
    'zU4cDzJYu14tz1pb1CtpOdrw7lYs5ppjgetY+UVPkhOuhLgs5K0iHiFBrhrXrOGOF7fK/OXtG62QOdUvBK1W1bs9XYLUwhlA4L9m'
    '8hiIp+Uds4bX9cxcb6Vf5kBHR7A9ZKacvrmFNx8qMDBy8aE/cbZf3F/F3UYICw5OI4Zu4O09uZdFZ4mIkSOsxqGPvsIY3wh/wyyX'
    'lyCYu/LhN4DdQI7Z8+Bpl9MRaXYgSdQufzG5N4MkbvjdCT9dhVqNbt/psNUMMjokzuY3EFHVaomSnrVzRTaILxp5hOgz1C5EzQ22'
    'n5O7TrZEGkdQdiB5GZsljQdiuVLl5gMFunQeMrWmICv37dRYCKlFCMtE10kldb3V9+UQQCSY2/cFkeaGflzbLJjcvm3IKjUodtMM'
    'RFK6fTcsPC3sB20TPvwN+HCSXIjVYH5MTEN/huAf2fQElxaieJ/l5gJD9ZOdOwt0FBqOSNRmbROdSDTu9lGvHzq0c3bi/nETEcCg'
    'Qq0Kab0wdO7zz3t7H97zmTXKZnkym/CpZQGjbGRZK9nrQA8L2YImDlz/xOT/Q4/DZk211ESENmLNqX1mvqltGFJfcPilVquTSYVm'
    'fnpUvevRbGTxmEiTew19MuZoTAn68ZhjNUVTGOVKHZPxqx1Bk9DqRHx20g5NoljCXU3iHOqp4niazY6OS/nCxJiV2o1h0sMB/Yvj'
    'GC6QvVlqokKp21gEY4oo70+hSKLZRR0xcWMrdP1I0iZER1aC03AbRZSPZjiH0Q2RBckTlEPGRosE+8EQEcLpvAHLXLjOmmfHmCVR'
    'R0IkqtBL+jGsUNmKIp6BWZtGzz6+gQHkNCEoQb2BXnggfJ+EQF0EEdWXCFA41emA4BHnklfr86e3OadzEy8+EiMugHKHyxhIjOOz'
    '40z8GNQfeZlEwTIW/aRqIneC188zEuJoraGE5xevsqlacGl5owr3Xr3gfVmwEkQDf/H7T2xCovZf/mjAR9kgsXfdAK3xppR9/2Fv'
    '5+e9Zz/s8gWz2LPFR9HyloSi5NsXmkZsciGyMSmVYPOU1ag5G4MCdfUccEiRc3o8XJ5+5PwNzz/JH/5X0tjwzzf87847/vNZvpoy'
    'b/62wz9f7ryVV5+1+mdpE7lU+AeyoPCPj5/4L/X6eq3LUbcI/9f50+sH8uch3j/A+0f212Pz67N09EH+vJXBuTCj/PhMxv1Oxv/6'
    'k3bIwSL5FYckl19IxiS/kJBJfn3SQvJHCr5883caAuj+7sdn7zkM4qsP7/fw4861WaqXnz58NEu18lNTtswV3zlcpYdIR3wl/2Zs'
    'KnHFKH1V0Ek3jIvkapyZGqdHV7R9jq9AOa/4buIKXklXuMO/QtyJK7AfV0xRr4TqXgm1vQJrQdslvjqlHZ5dxbNBml1J5rvWdyup'
    'f8NQTX3l3zNwbsCb82jBgpujqKGBLZNWCw+iOr0pm5aq8Dim8ryL60F66scaOIuHJ9g4oBeQFryI1n6KRlj7EgeMUrXBkSV/Ike7'
    'XJQMizro0HlAx4Toq0qDhLkZ6rimOPBxi7WD5VSJ1S7nBmS2uCQxmcdeXP25SR5BFzYjv2inyD7T2DULUjuazviS19KUfSp3EGRV'
    'RAnMGkDWsOEE4WAyQoRm45MxMqsQxIXETHBWxUdKaUwqX69tHp5JRVRJJMCpShU8dQmITLpYuToPwz7fpd0G37l8u0sbJx0WWbe1'
    'kgrk2FP8hhmVIhMGg0WGIr7dDtNWIpziFdyRr47Sw6uzpDdpbWBnPn7Y3o+Xf1td/n5pZfNLfrD0nRlIzcw4h5FObN6i8ok1Z2dg'
    '48EykFcVg815W4JV4nddLEiYCSuIuBmuCBLu5FXIi+lq7ZqY8N4b1arThCXgcQa1AJ2V44ytqae4fN+YD+lWtSUAqXYMYQaooKk9'
    'yTjhnl+Hpk+xyMYm4QuSmWRn/POgipqw52DC92Zct4rIwLm2WsLIU07PwAYYT+nranVecTs6rcTELNEatTHG/zzstW+vjZ0Ef+Qc'
    'oURIfbNkevQt5s2NCQlWwm2q/fBdk7mWb3tXniJ39BVHU746nra+9CwKm/y2BFv97exbnu7/tHVwf+vqL+NePtlgUxeXw5kt8EDE'
    '3fnj9EWcI5jvAUiQh81O4E2x8D6mwjb5VjJy45KydMrWJcrLNdWVxZmgqTcd900gUJ6wk+Z6ZYwOAQ6DHKaAsTDyMzdWtyuzgKzP'
    'UyskUHxtOW9qW/zZXEp7hiYRrndE2mKrFrWwILmLm+WbplIJEqiky6na45b9q4zS7rJ8ozUHosbCqcQMl834jHTJAWmZ187Gtcb/'
    'zTw+NfIlpI60aOQwrsZL8LLjgZwfbJOkyvROaBvx3g7Tu7a765sVeKZaJlWyjF0NG2BU8N6+Zpxulsz85XHTzpsaDfDIOAG4pDK2'
    'l8BZwNY3t5sqRHCM5JJpwhhp0iuW/J/Vkl8h2GjNsVjPk4RBJ+JNaNlc2gHzV19WOB2Ek0CVbbzt2sVfMO9tf9peFbu1vDt0TLk+'
    'G7ZNvmGq9cP9qJUbQFBWCogjnq1REcoCiEgRViMgjd1laADlBD3aYYHU56kaHPza0UOYK0S8DX6E06fbB4TdRjpmv1LJJI8160R7'
    '9Fuy4qq3ATLfQXdwmuZIw53zDsGtH4m4ycTbBv7aCed+u+HfYvWqWCvbKzQ25qMEnP5mefnKiww5W3Se5uiB23vG2ay5hWvgFv/q'
    'eupv7degQ6AbF9+DMWtUw51+N1z60A6xghZiQKqG8/AGf5lOiwt3KIxVZzs2ByY9hzaS+q2GGu55BsC0kL0ERE8PzAFE80Emd+18'
    'Kd/qgkXBZf5sLB5ixN+JazatfMxWO/Am5lceJkFIIxzxMKNqjXB75BY/tTKlj2C3uBJ9Mu6OZ+xgzOqE2TRHvMZYlDHGnBFDgJWm'
    'OJ2zoom9y6Y5ppNMC5NlXPxeGSSdRW6iuTngSnq/0DQuPAnNGhKXgjpsP+af76opypucYpTPzGdFc7XVAb5k42fjPnE92fSFKpSm'
    'LEcEWp1KRYQlsee9PahgyZeLqWtg5Tfl9mXXaC2eUA1/Yc8w6bpuFu7zwgnMhVaU1zEXueMnXAdlL3J8eTEaNPujgXrNROaiJjyc'
    '67kqt4FrIBK40CbnSR/bl7CqKa4LP6bF8YvdXePraF0e59XiIWpR8e9xx4U5C2qWzjLPgr74pseXkMAtC4OGlMBXNoepqFl8DOjH'
    'NHfOslAx86zisigkB4J4HkpvV/CQjSrssnvnr1FBCALdpP3QzrigS/DnCRiuqQouDpIWpzIZJJ4DY5WHU/iWnf1vNIvkHpdBbvJo'
    'X6x8R4MD5wjHqbqcOKCet/wmbFbxYrdAPBvPhHI0KLvfLnSky8al+Ps91lL567vt/E2O19vR8YO2ZJBhv8V2NJkmzi5wzHU8Azg0'
    't41/Pd2OJ9dHrJ6siULi0JWvS3OJFuPjGgl7uc1i5i3BIavPpDSLR5wuQVArx65Tu8cVBroCGI1JXBsJiUEC0EDuaQ9bPjxd4I3Z'
    'UIJXoGTEMVU48A0XNk7P3KpxJws3oHzjOJdiBw7rS5KFOf5kh35c3/MNuTl+5GTraQ8BTSdbpZgNROnEEukbqZYae4ukMn/V4wY9'
    'zVVusQaru7LSMFt9NgVrNZlmo0mBzBPjEwyQKCQuBrUzx5yhNBgkVOKMFqY5f6DSJKJQOT3aTRo0Kk0LLDXxQGxdfzgbECo1/hfx'
    'MrkbvkWXuKyTdpgv9wazhKYWkHoMpyTQAvZqTVNZ/q9PY1YeYr2TvM+j5Vzl9uHpSrwlSglJrMG8myXWIqKraRrKh0E8sNLPZBwx'
    '/xHUWDB2KSZrIGNthNlz4OK2Kbop4Cunkfz69LtLenOtiKkPNlHrA8zCJYxU4luBBI9262mBewPkLcvOYA/EMTDl3dNCFfTyacAx'
    'Ot1vKqYpI7Qlt1G+lqgb8ljOR/RigCSguF4zYhrK+wVilmIt+uGz9eBX0vBxVvgcJmwTtDmWl/wrgWKqXXinFOcb1azRQdpZJLU6'
    '/3DY5D7bfnJpbn1Rfuny+sJhsrS4C+4x0MyGu6fAFk/ZJJj+PPVT1hpPgShFOtPpovsH1zgtYOtWJXtTqzZt3py4d1tg3imeZ4OU'
    'zXREs4p3egWC+1I+gYLWYCcP/HzOseGb03Z0m86a5d5gh0+rzVNivSMzldwXRDFnqWu9n8uLRGhgF8n3NPWyGnveOnOgdouhY6tx'
    'FDGEbIr637AWtMQBrPrtyCHDPtB46f+v7eu220iONO/1FCW6ZwFYIETJbY8PSZFHUqu7ZaslHZFtbY9a0yoQRbKGIApGAaRomXvp'
    'sxdzsTt7MfsO+wBzP/Mm/SQb3xeRWZn1A1Ke8TndIoCqysqfyMj4/SJ58N6PfsewoFpHK0ppSJXLRZVOuPahm2cp7pIsTNRwy+6Q'
    'VnWf09bWsrkqRjEwigqbrInkSJ1zh3FTPdTokmH0EOI+Oh+gasVYcxc/2WExYuBMdzuW7FcZY9be3ZK7aPhOxYTRO0fLxfT32RVm'
    'LBvB6StfhskZr8nDsdBXxYI1MxY/yQMiUeL1hrDLfIMof8H1UwNllKw8faBHcra35E62Nx1altubOjMn1S17l2klUszGvmUVkMvg'
    '4w2vOOt8hZfwas8HwzxMx/T4dZxt01zl3bbWnVQRdb1XrJYoQEjmoBUVe94U0E0qccy9J5S0NX89rc7SlE6cdkrq7Pil9Ku4JGJk'
    'PyW69jDp/cTcldCNN6y78dYPgVB64RBaXt0E45aDGN13yHYohbevMaKsIv9+8B7fkOp9zEjMNWqJ9+wQbtMpEA3xKdKMGrbNWl8g'
    'wONvP4xncC/SMIqaYMYfm5Kn3gUrP6Zo7UsUwnBg8ZTdEz5ZpCfCPxduzluyom94vpg3Sa62MtCQD1HnUAjhP7swd9tWZqedUrpy'
    'vK1qY1FGpzc27+uizHEfIlZeA2Zu3yhL7vjvNufy8QdIgd1uO+uqvAC7Bz685QHGhF9GxfGxfFd5s/rueKszEy5q3CbuJu/yfRzE'
    'j667tX0w7HAXbVsUqKUWW8hmmZyvyiWD/pZZOg2lbgvKU7ItR3f+WhNNhVPUEvCpcZ3hwdhcfhjN/kvMQ+M1vLZKc8AOjY1BLjTX'
    'LDMtobl+Z2twuLsPul0clnsNdaoK9p0dUkrqDJa/aInr7YyUvxhESutF9KJ6Bpadhv46iaU91p8T+vz8pBns7690R/s77hGH/HcG'
    '/DeIt4xGQTkNJ1+U0uTFD6Xwr4QVRh44lL1JsslJpngkiAVO8uUO7yHijQakqoMjm4yC+MuDn962AEMqiSlYzs4dNX9ZhJrcfa8V'
    '3M9aM+yNy0Hobqc1e6RdeSRt3Et684+9yAbpF0JjmVtxCNrwNG84eiFzg8YuAkG4rU8sZ0rchP7RND2fa83yt7y6KY9X3Ojhb7eG'
    'SXD1l8nW6O8Hg2pM1ctXcx8F+8msG+hP+6gsGQN/fLJe+50rHGSruSm6a2A0bUmGYYxP2/gZ5VM3CXMcnWsQ97bztqqroHHtarvD'
    'w+C4fCWygwzVzGRAlfejN+/FnUT9ZHXA4XRHlF46u1L/nQimvhiyxoginE89neUpLLM4E87TM71lDD0QsVwKc5wB9fhKQZ9Gd24W'
    'Rj6ZoB3LDyxpsh9YD5EIXYJRt4kAmKAbxJb/ordg3g4sOyI5RWXpbXrij1BngaH2CnlbKgc5Oi3yo6ydhXz7/OXhQQsDYas1ZNlv'
    '8VsfsRqqjBMYlfe1IR94EAu4IPjQTvDMIe+qw6fIXYjjIG7BRzWIJ9+CCnwuCBQVve7yROy2A3+HhyJv31Mc8dC9q/eAqs9WjTAt'
    'PT3oaTPT2M9I+zx4d1MwEwxHjFNwKwXX7y/fcCubZv81wkA6H/kt/IM+rbOeEwJAWmQwbCNXQl7mIwBmwFkFQuR4kS5Eqy+zdKHp'
    'D7XckcMwVeJYVLMyStko600B2HUC1/pcFGh96/IUYQKG60rlbYK9zbgCSx2ZSAfQNKNNhLR7FnE1ZOBu0ne5YVZiesBHUldPfBPp'
    'ZkwkprlIEXUNZzdIvFB03gA62CVWuK67JAo+XFrM+XfpvInemxz84ZtkLnMwl2Po3vkyP8/sJct8Sj8lEbus4f0R3gZdeB6qIHaV'
    'F+ml+B9wOc0Niiu86pWS7WQe7FHhaSg1HrtqUQtDRM5LOcbuI9xzS47DJXL1c628+O43W0i4zOSJSe/9MNHv5/lsJfoxvj/8Ur4L'
    'x13w298PkZR7xc9fjn71a2DyZdkZvz94iCeF7k/59fkMIZFLoabelZBT7/175z2C1FjWXHrvIDUMCbL2HhI0OxiBUSa7rCJf2URn'
    '7tw/Tz/2kdOBz8fToliIbMkzWB3B3h5qo8Tc/tOKgfiX2P4fvvg0u07kH9QJkz8MkAXyNHlD7xoT+8FFBl8k9x+xHy5+UQW6SyHB'
    'YolN4fbUpaypqScov2kBOBmMzchonNOFoDFUPeYILRUeIwiW8fRFHSlcWVqE0HFcGIHqrv9sX0h9+OaSqxVqlkHIJOTRaVr2z2hx'
    'cV4N/R3wjfh9J3gNoOb0zB8mQG0aJg7taJhoECbRD86erhYXiDTDZwKbliqAEGf64sQggXu9uFCE4pBAkSPGyHkuM7fM+r87ePVS'
    'Ezr0o8aO58dXfR2unIp5dsn0uQaMtpCOwgAqO0J+1mouzU5Yu6C4YzUovl4oRGAWrxeSzRBqdZLPNNhzBpaV/KkoyCSR0pUu9IxN'
    'ZW/PKhaKTGVLbUtdaQoTYdPFGSXJ8iibufjZIdEex+PiI0KLL0NKHo8gYGMb/ubLLbl4Gl88tYtfemA+fQ3wFcejj3IVDdxPHspG'
    '599hcsVLV7x0apf4V5+v1ufDrnxOMLlPio+saod9cYV/LvHP6fUGYgGYdfi4nItS+wbWjkcbH7/LJz/I/8l5li03Eq1TQPJ4tIEw'
    'Nng9dR6ud+/LO9RdGBxdIYlwpwnvSKdTnIf9v5L8DCrRzKlG46XS+NC9MULK1p9aIhUgLSjqzWfi8DTLHESY8GFIuDuFVH0ctNxh'
    'TJ1Hc3BsHfAHNfTpxQpe0r6HCJO0bX376uDQh6NEx52ShG9b2NKqbEQC6z6ubvtmkdfRpz7sTvILB3mHezYJpLmx90MoHcBUohuo'
    'lK2WWXJoXAsKOa9Jf3e8F8uom7LWq4+798d7kB6al8/TI8aayS7GTYMR/MXPZ8p0nb4gUghTYMslEA8gjMi+pkYCiYQ1cFMe+9bq'
    'aPe+DCt2dofA0mvmzA3ZgXp/nTMKUqUlNwkA4HKLZA/U6gZU0q1fNg1nSed5v3df/r1vV1w2i+6xfrZYuBW/oaf3XQKVvJd64H2N'
    'tpAWRudZWSIFFsMgpep8LtMx2eUi4xzWFtCiv0O5EFMQtNc2n/Gwg8iHCoNKpqG+nzRo1o3wa5U+qTFHUNsaWnvHFWcF+CtrRQAy'
    '0ueNvBv98t7+P37x6bo/+PO7H9//+ON75o78+OMX/60XRsqd5ienxCzpYyIhpC7OTXbB+eeM9eURr9dB75bYBfaI3Yo/vhuaIH7y'
    '7OO8z4722dBATobeSY5ABiuUCv4KNisclh8/hLwNLVro72NVp0RJPMoWcyEcmk248TTa2zgMuiT9xDULiHVgupo/F6Y9zHJR31uG'
    'b5jA8AtifvFUw02IKUpBd5siw025PFtrpshJfzmrVEhLPmpiabarHAh9W/Q1Sbu78vHPf2YcQ7qkl4kvy3fsXUsf0lAFdeljXj7q'
    'BYV8lSkEJ7IcxXL7ZvJrnNUZMK3tWj7jfFjzvOse33kv+e1WuDZ9bVN2lMPjo1LLh1X45w1sfdCK2gt0P7x6NwneGDdYQ/KutlYV'
    'TxYwnDh67I8tp41hCBtccLSoRgHy0B9FN5zKwci+DpwL5klRTLN05hffOXGciqOOF8TNHVemN5ce5uRexeq9/nGGz5Tc9SMm4PpD'
    'k8ocKDl6NqIe2ud2lxYr24vQh1/06jD01TuORWxAhcBtHaAbz9JcSuhQ/OKoZbcs1wrS2zYb5kG4OigWy3DOgc0VFbYi0pxVrEC+'
    '3lgx5EauFzQdZE+Lc4SGiNBovw+rJIUhDQYzeKEuREkTGkGOKGqRWdG6qlk8Tq1CqDx1n7lDuVAlStCFd3OOeK9+kt2nQ9KbanlJ'
    '8arHoKVrDildAb3dle5QDcj9eg2mQdXO+BZUO4LB+jO4FOWOJWoSlilZS+MsTWJz8+HGZoNSztAHQN4VWYtEe4y8khpxg4vWRobw'
    'AuOtStqeu257IcxV4VqmbmsQI8y02OqH6wCvPPn3f0s+qHaL60eQqK8t8cf/0BwV9xptsNIw2vA/XKv+xM9BwyxsE97MH64pp1fX'
    'm7NnijcfglnDiM7KpvgtGQmZmGe0CW2YTWLCX6fKCF1Qqqn0G8miINwyfX8bkF94iqBsvQIzoxUXuKltDkI0Zp7BsO24i4jstITY'
    'sFNUO6D9BLo8a6CKFGm3d/Z5F2m/rqFxOjkRNYrQHCKciRYlF/dsOO7FMdA0jMfp1MajXzpHdAB7qFCHmuvQYTWz6vdNSHWMwjT8'
    '6ZaRIjzTT0FtEvAOtFkJSp4hKTnHMxI/Dcp2UbP4fOub3froGAaN5774xB23H5OR7be4u/ix1tcP8dTzt0A7uA4KYQQbeqDsYLSa'
    'MQynXwcHP2LBxOxyQ/ap6k0vs8un8mO1JLCkyloEoKsBLHhH9IK+lMHvbYyzS1cTNZbGWlfGi1wSU7uWU5JVOk3JcczuV1QaoAqb'
    'V9ly5FQH1v+iaRhaoLxMy0cCmEr6lB/BRDCEYkebsTRVwOYzu4I+aHZpaohU6bpM030oJ6YpiJg2hk/MdX8QHkUtaq5ObIXF7tQW'
    'a67fJnf5a6GIDJikR17p2x+5zmn4SiUNfYi4Qvt2FepIoi0A2jc6M2YAx9+m3u15QsgOlsXc9ADNhs7LBmv4GDIE40cRLn3SpYbF'
    'doLx3ot4Qba5ZF984pwg/SAaMo4YD5d/PM0+bo4BxrYNmtjYmxWzzPFG3Ztu4G4/PZ5Mvq6NxHZUIpesDyI3x7yu2YU9pf1sQkUl'
    'coLAvwy5D1NXrsY2rBpRU1E2v0fl92QcDoyWGLyaLEdubgNc6bPDwiC8K5ymCbJDMV9yjyhy5/0eTS0u9cMZKk/l9HdZnBoTIT3j'
    'seLM0exNerX/46z/g9lHkPqZL7WUDg96YP+OBpEWjAEdFqtFqFIEHY3z3qdFOnHg1iwBoUUiVguElsXCHhTdmkEh+5iez0XM1Unv'
    'hVjUj2fuqhvxtuls7LcXgQCdREM80OUSVYGPEBZzmbt6qTUjIMaH+CaqTTw+/TibxzdST7ggXp+IkbPXz04YsbFosfCgK5RQehDj'
    '+fZr1GQJJnVh4uLCanUv9MRvMQnZzIXWHU2hrI1fydiCd9AYqvoQc/HTtU5FZdhv63r1SKiQLUZacWeq6dCVVWuxUyuYGVYZvqnr'
    'NY596xBWlZJa41jfBWLU+yqsUn/Q4NVmDGCwZnqjX7Bte5cP5LJXi2LIIWJQCk1cH6H3bO14e0Wzt78IRIdeoNQGkPKxhrJmzOhu'
    'MGLcPYh3A10evhYV6YwBIzcuQ2fQ+ed3yWKLayHhGmPsf0y6A6RvGpCFFHccabensPO11BWcyyGRnQ/i7RcZeu9Hj4UUdh5QF27R'
    'TgeyaQfh+DNSqz12vlhG7d4aAqoGkiHgfS3/odrN0X0Od9yF57XfdmOhANy0rlYAS/gWqwh7mefCocgNizydhojsWprxJgzslgKw'
    'gwR+IT7uLoXxgTRW6+lU7yf65kGuv82m8xs7WjmLgjvdKRMNux2W+3NRuMMmjfrbpugm0/vdtTfsNOTnAPsbA4umxdxycoO5AT6D'
    'w3T60YZrM17WJrZYva+2cEZXL5j+OFe8Mwm/m/MzPvTqDj3LkoqFievWZJH7PU2S0R1OtCBtrYsD3uQ87ExLMVYbvu1R9Da63AuV'
    'MbNknNErLodcICuo6+FRpGslDWbvcibk3toRxN/qZ1DX1DxGPcmvQBZrOt02Rd292w/WqCtXqZYXz64UvXUHUgXMAc/NK3gnv0uR'
    'g5dpncUKJBkKMKPQkv7P//x/qZOgDAtSG0Von6cTkeFLYtYOAscN4YSlRfWZRxopkNuyltyDw0WWveW1KlcAQt2QEA1f06g9Ovj2'
    '1dufgNYwtE2RHh1lcyYjbCuw2yzMWvSnj8KMDpNfiFQ+ncjfAPUWwE3VG75+/uLw2Zuf3jz73bOnh8KkmpceP3367PXh0NtifGar'
    'MBmgo9sImatJnEzhcAqnY0iZsMUWMjm/h34S/F534AFNbG3I/ztq1YiJCupUBoAQpM6pq03oPkWv95d3wieC5vhcXAYzejq81XlY'
    '65D860qbKm2djSlNsrZibJAHLX8FRp6c1YMFfv7n/9fzgToZCNjhE8meiLtRzm/XDwIiAvNsHkeQBl+9owxEVUyn8EIzjuff/y1B'
    '/G9SldrDJQNbnIvmfhreag8XC32I/KvxYFv1RNZqn2osSlxBMfDB6i7GRtT7+xtQR9WmsDFMNnTLTTaQBgQQCp/zouyyQldTLDuE'
    't40YkVas5MKm1QBn20RdVl7OKqYwmFEvNiinvlxGbE+ZkJ3Di1cQ1ClTCKegvOsTFnNlHWt8RexLsYhsAZUUhOJXCAPM0wjE16BD'
    '1QHwzsrmqReyDprVGWnjX65QilV9QPetFQzQO0y0brGFC72zWoSfko/bSf9lf6pl3hlPhW/LQj4PLJwquuMquOOKd6iHz4pOp2WZ'
    'n8z6bt40bB8iOpI+6ElCuBXfcy7//pLRV6Oz6/nHD1iBeXXLFW+5im4x1uZbd4KEzTiqpE9HSmT7++Yx8jc3I4z8pQDdqep5gHyh'
    'CWjxa72ju/Xn2BCqS6kUwiAtb0oJFtWJ1HV3dEw7/gHhrwgsrb39VkVuHzzcalCUo5zmdDnMybDC7DSodutm3KHnttS1dbc0qtra'
    'hWYVbt+NW4m4HfmIHRVnO1KegzWysh2dAuANqd1BS1VsOkh3zahaStUGfUGpp4uTtjzR8bRD856erdG8QUuBwj096xpLxdnuTc+8'
    'vDk1Re9OS9HtC9FjchSfAFheOp2ylIVw39Vcns5aDgeWSRjNr8Cfz+cMicOUA1SPAfEi/GUpgaPA9EVvPLJo9xK1GXqT7KIXxK5O'
    'i+Ks5BlrL3Ss/PHr1z/94dmbg+evXuKUfrj18DejB1ujh/Lfg19tyfzhhu9ff/X48NlP3795YWF/jNYZF6vl47mGBtvwtsP2hu5d'
    '2y735yidPdfh+59sOrKJ/ZJ4tPrnLw8OH7948dPB4as3z1rT2zbt4c3i+FhIeKduq4Ql9DF6GRijNeZRTavBCOq2VV7q1bOp1C5v'
    'T43c0ok2e7c2S8IGwom9q2gTF77ipU0XAkQbMQ2+fbvJYVVcUB//SpZzWsxZRQHLTdX8D3YnUgXqj1fFZlE05nv2OdLE6+NxaMS2'
    'Uq8wtwF6UO3uQbOwyVH1Ih/n/PDXVmZZKPtldgndby7CiWxnEXP83kByF+A95UXeDSF/VigQBJ9VRvkEAfaIlp8V2NMzPYtEn6mt'
    '/kxes7CZaRDAOru6juw+h9GrMggWo/QizadMh9mXb255tj0CZdPifZzBiFsjjntJz54d/VNZzPaXj7BuVYoG5IIj2eKiJPWEyAnk'
    '1LMzvkq4dfhlbAN1YIL1th4D5Dskw335pYK6q01XuGrn6WzlJLW6Of/CDy6e4EoluVAUYm3rSYo8jFoFc9e+mrU3fihWPWT7zRxc'
    'KMjDhrMxiGPEWx5/6hIBOYSIySWPF5n62Waw6O1v1HEh6x31OW3aAsEPGnHPjxkM7NZfVJWaY0oLx0yuRn6/x62ZXhdt24v41m+K'
    'xmtBuOAA2l2XttKDAQOMDiDVLW0E5XmjIPOVG3RrkHn9DnfCeZaE/jZIaLGaGQGFQv6FaQlr2hsmJ0V0F7q+87kx9mFMe6VoEpqC'
    'NYz0eNTiQSYQAos6mx5vJxM3iwFgLZjOimcu4W2rPN2o/sF4Woz9luiv3/a14PSj0wXKGpUjxOXuX5ANXHTt/sEIb6oqS1RoK13Y'
    'TWnP36yQKXKvdMRuU81EvjO0+Anafoc3vEcHkI66HRZEYQ04acbP06P1o+nhZsvDd524aVs5SkZhpFfOTIjOrXuRKsOM6HDPl5q0'
    'Y7J0UHh41HNdOSmagnzSAH+sOEtEHjqGDt7SjGCXdwWb0L3tpsngRhKyd7kAJrG0H1U04PVu7da96d2HfpDJJJ/MfpQJgEFCpq82'
    'GAOgCh2Rsut+CHIZwAvPsrlHU3YpF6mGP5wUBGUmvr5mX2hkD2u84X5kfQDLEPmRo1tM2xu9N5i4Nii7324ZdJ2ZJd1xloiudJ6X'
    'WX9Rq9i20EyrKFm//azv3e91nt/qxRsVZxqVbuc3RoDz20cJf+iJrn/d+wAsENmqZ/WUfgZOHFGhE8UWZNmviml7/hnWG3Z82flQ'
    '9KYX6bKtCumn7vPBEiaC2tmVSHmTnyyUL5wiGRqLmiKnT52YFXWYXP5y925rbnSkN9QleDMwnhLi0suylV7CkA3/u1dO+POsCKOZ'
    '7IFIlEa7HtObKfK1u1uJ1r+uvJKD5lzl/bcEvCpdeHcPUUnNhBryPYL9JMLzV9xMLpuJnpYcQWVnDOZJNDMVO4rsMTQOxtnb0rBz'
    '05yPeha7t64H0mb5t+uAp+1gIp8s4yrsFEQqkI7qmK5zzNwtm27llqV2ZN6uA7kQo7WLhgV77hq8KwrPR+SAIwCnLTHKm3OrhaRk'
    '95ktxCvRi+Tm+DSozrXcaeMbIno0AmhCX6915mXRttHXIC1Eu3FYRyu4bpvlpMV8sjS3d6sRfZnNN8dXm/gr/KIsIZTDmD5fAO3x'
    'yMeAjbToJe9LyzM9gqBZFiruIcoR2aMnp0tVOq0a4aKYlngVD4nMyRfSsjShAqQoAceoOUB6L7OsdMgGEy0fk/RzU0/KMIdKG2KQ'
    '30ytMynecywnkeJUllV1zYxFY0ZCJBmWOKWDoGB1c5kW7LdxlpRnORFUEOWGmnXHWUZLE7egvJ8ixYjmm+VqWav6ePj9Yaexxc1/'
    'jAYiXcouSFer5f4I32GLw29VWt1Xz1789PtnP8AcXcLps6+uIKouWvLevX+Vu+y7D7tjF2W5yhk3jxhTxD5axkh6zo1qPkTNKNNC'
    'TmDUTmWgy1U/jlDDCbbkEWsrmehupdl99ORZPin7TJPoD95tvce9LkGHr1TkJl2B49WC7IyWhmzCpHGNk4bHBOGEWASe+Vm6mOa8'
    'Vd51CQHH1mnIhHFFDi5RQNzHNAbp/6vlQab1XyKvRdXNYTLeQm63jYa/VbaCbEb6eaST1j/nFJ1riWfapb5zwZB0g1etuOSTvUfJ'
    'Q1yR7sFaDje7FuXKyzdFwQpAALbE1M2aMxa2Uql07NOtXTz10tLW+0e13gPE9TwkhoEbp9z3+rRYFnJKwIyal0EqH7pJDIzeWyT0'
    'uz0ONud+AMCQ/YDFy5GBBuzcssd5vjxFXHm/OXO7ya8Gycs+HleU3XPMz8D1iW9+13iMHigrvV1lg2GBmcIYLfMQkcXs/AvG6aCP'
    'Tqp7mi7GCPXOi48yP1FXuVjj7sXalbWKOj6OOi7vfHdDE7VBqBsOw1dnyhWNsmH152O3wC6CV2vpkhe6UF5fDLww1l7CaNQLal8o'
    'C3v2GmhG76SxTxrKLrzmLRCEz6nTx4dnb6inugxt29jAh9353iETmt2pgyABOy6MHwcgNk5PAQ9mwRxh+bqbl3LKJIYSwbO79VQC'
    'fLlLIJnvVUdUfBA5JER0ggyn9QwqZkdZ7ewZJT5+u6DXWn3AwoEglHkcHtnfNFolyPqO+1Rl8Mw39p6jjucZEiwgASUPthKFiSmr'
    '96BSWsZxi9DHlEEPg/LFp5VIYv/xr73B9dByxdX/DDkRlFtJQ3rrPkLyLXjfSr8vizn79yG5HkZrTMxrikE+wLsHhHe4euSyhpN0'
    'rPczQiGZFOqUV9U7tUspskl8u0xOMJ32XOR/VMp6Di3WzaIvKdfn4sEhO0lp7ZZZg71gUFv33wGLBgAGgTuebyEaoLdWJRrQXQLY'
    'TOciP+KCC2MCIkpJGUbBZejH3z0bT/bo49u9j49oTxnsmkV+aiEDYeE2ixkYaYsHSFy6F7Zrk6VICRghpEvgdrlmEJqO7QImgoKs'
    'ZTK+MtrV9RwaHMws2650yJYDLwL1WX+kMZ87phLoMamx0Yg8xuR1HfTx1lFwlTvglngYzvRhOrb5gKtClRul5Cf6xsE1DNcA2/O9'
    'wAGHXYgNLBMc0wVr37BkHqgbW6Z9XbumsPVAf9A2KedI03W3xzNjKPbr5sYPpnVaQkLBxOiUuGbDOTEAJfAulmRT+L54TljF8aTA'
    'nK1my3xa2/TMbpGtJLw6q0aEzbSG5JFJ5wVC4ZS1ZJChel1zZ5X8CPfbFK8FKAHqhMnbx8Y5b7sMv6ovwzeijMjYeIDfkjCfuD6D'
    '856C8fpRaM9y6eLlTBQH3cGYWLnAGfN31siqImK/KjqxSBxfNNcD1IP5viw0sZh8S++ldxqUq+9aswBP3OkOqat7IMyLmixS+TRm'
    'IJuWddPIJ9WZ3PACNj4j373F4lC+HXtlYHyDRFtfwO+AVGpYGngpZFrEKGdwcMOucNvz6PtSTddcj5//8r9+/sv//vkv/+fnv/yL'
    'LUyK4FWEzlEcIkBqVcmUwTU4tCr+beUcG7yFfIf6R60Gqp05pT90RslhgVXWGH09mnACYSuYi2SI66Fdx9+ljW7ruhh08xTolO5Q'
    'B3AF6gfK4genKF29dQEJkTkRFRvhrJdblA2VRzZ/mm8EyucahZTBg2xbNVFZWZ4r0BAslgsTK+xskQu9qE6EtEyqRO+gAA1NI31P'
    'MNaQ2NhiXY3CI2Qr9h45yuwjW3vP6mXV2da8xjNwNmiQomrXJguglGMnHY7drb8Yf8/7WimyXs21xjO++GSa/nXA5rn0MjgV4AaQ'
    'kcqIy1IwbPCTlwV4sdWRrNIN+R7EM9/7h9o7WH6UW0Le8SzCl4R1x6wjuGuWqdxZtaWSjGtxkTF7OG/hFQYMRDMH0PN66mHSElPh'
    '75zs5npo5Kh0qzQO8VcxBjYTLQL23KJASXvZFmDYdoTqLZUMuZkulzzDlrqvYDatjm3y2HTp675ipcBu/WpRfUopwrWuWuM09Rnd'
    'y1y38rnwmAtpqf9Y9KpN/Dog8/ajwXIRk5H87GQqh0mp68+4Jy3CmRxC9PNNqNQUHMvUnXLyhp7oFynnAkCLjk+IOnm0nF5ZjVC8'
    '8zKdKdD2LBBulSDuMeAX/cFcQbr2iqi3suUBUa+Zkygcl4nviGA+yhrioK0OBtZSnXodq9Jo+s9kVvrQZ7Mr9y7yJ/1iHMquKI9q'
    '7INDLBohpTu4EW4ALzIFHQ6kjr0QURlFBtkLnjIUFW62jUm8Iv0vWJMyJMVZloIUFAiXqipV4clEUbEZ8a1+ZG/fq/TcUghA91PB'
    'JO6AElW+dSYGUWFhk69xube6i/DYMHgIww+UXhmJLB6sALAvM5iPXSzPAi956+tM01OntfaVqn+olNjL1lAtnMHOz8BW06lsWcsZ'
    'T+BIu4SS5zYXMmjAlKSz3HhQBBWA8wjojAryuxRh+eT0Nix2yf6xolfwK/qxPQnIo0FkTymbl51EVl4qmMWNZ53uyJSqgOrEJvbb'
    'Qs9ToY6l1cm+PC2mmVfqbIpuZpbf5BdZoGzDP5AuzqjPbFLstlf2q5h/ma2Br0MfsekQr9B0kiHsfkesHyB9miggMnIX5iRnm6vk'
    'OJ0oLxJaP14mLI6DhIlLQheZkFb6+t/6RmGbCh6bLm+mf2zPN9onG1MZGlKoJ5DG5khm0k1ps2mngBuSkJGI/rcgILxm0aSPr1kB'
    'Y0mdtoNEjp8UTD46fr5MZenx6QBWPWgccjE/OdFPB6fpHLLT8df5FOmicktxyQbeZGW27LQv0uG0mLDcoumQrji11uco27j/dkhG'
    'q+ne7jTfgx6U9CuJ5okeXY5A0Pvw8nO7vHtfnnVNyUdds8c//89/UegQfruHz6CXUseO/Tvm2DmkehtUWcZ7JeaES9uf50DPHhcf'
    'RYOeTvM5VGlpg8c8gRDVkKnPwR2Cx9js7n0ZX6CsACl0RpYsiubIOqhzLH0kyfhNRHIRWlbY5S69r3m4cSpdlXnUsxvZ/PEza3Lo'
    'JwxQP6LPDfp6rSDkdQbk/HVNastFhw6JJz8gEvYv8jeZVmloV/6N61L3R9c9/Hmk71fsSyfNeocQGdhhFTmV+13XrKKVPzhS0nsg'
    'DPEWGARQ+8TzchU9m9YrUDBmjdu6MuioT0U5qHbGUVVFauvEy8I/Js2Bqe0nNKDSrO1ih2+/7Pn5SWMJGVnYLaXY5dZlQWF6b1uX'
    'Ta2GT/p3jUCHtSSscHW0ZSHpYB0C+9mgZYoVjo2VZMw6j3KqUDWGdC+XQxpLFBq5tKqnZvYxSh0lb5nm5eUc0xyPDN/VCtXcwoBT'
    'YcCpNGDOEP0FWDujhEOkVGBRTxP1nkOyyT7OC55gb4XHgxy+k8MQAXjOct61rFoK+RUTZtscljNDraPAquWifF7Q7rt/3Hv/yz3m'
    'BvnUoJZTQ7ZYZTS7TK+66cNVBL6lNm1WrzK2yYVk4RuMKeO+owrR2IjSUKqyVFNWhros8j5AyDHsAsQJ+e0cbhoFBMSKLFdHCC3A'
    '6GqUpl4BY9VsxymXqxneTGI+kQM6XKF5gfiSZVX6pLksvjYGymwq5lUVhnPdcrzbLYzVWtNaffkOkHXH/lMq7V67F3J5jdpRXzsU'
    '5JFv3v48sK1TxOI5Wg1l8zLqDrxmEwsfyOV1OEWLKTQ05zcSVaRA5U9Mui2n3ESrR6m/6UkK1HorN0DziCzaml1r5zwiSBm5EIiw'
    '6OxJDjVJRTFz6pidwOuqKrchw+j2DJdNyfqZmnqmydXqF3NwdbXV0/ri8CheOnPm+iU861i+F4SbBEJZvbkhBsrgoUmOYCSotG4/'
    'MhOWgYMESeR2sfST2japkYcRg08cVm4oK8dcX5xdZqQBPBksCbLIxfkmy4EdFYsZnSENs44of7EmxwHjNDeu7bZq9NAa04GBcEYr'
    '4vMrBxU8cmM7rn0g2fNNt25GzUq+eSeKJFRT2az/zk/IyGMX/sQ9lZZqC9rXAlGWWx3HDtiigS2tHUYYqlIF378Dku37KPRmmCDQ'
    'iImpEHaeT+7dq55x6Z9RyjPT57DNYarZTlIaZZbFduB/YJVpaXd/P8H35HonymRO3KLUCV35dZVXHrtxD2kXtrO9nUNh85Opk8ck'
    'lF+qnWFJzMgYjzRjyDkNQVA3Ha0m6RXN/C68zhK4RDvFuIvtVh+Cy4xvZK9Tjwh95oOo45Zbz/i33XyvyqvfvZ/v3eQtaJi01RRU'
    'ht4SdKuL7RlJMQU5IipywimLAWkqODSJ6Uh9OvyoFe34kRqsfuRgWnxOC8oPM8r67aEPY7jEO/jhq1mm0JheiyjB7+X4qKCCh1xV'
    'F4hj5jLGHjB4DXV6RsnTgB1VLnjyJDix01u5sNeYSPLAIqNaoNl5ub6jpKIxMndnklJHZEW31ajW8UOFT/ZhB2sYoLuj3Uvom6rL'
    'kvRN+2MsWCpc6Viqx1SSqycV1nRawFhgx4cIysPAzCPHcun0A+xLnlswjcsZBMxuCNUaeROvHzshrACr5XYT6+LQFdi9UP5Uqhm4'
    'bdfOilC3iELA1deXfAVXRpoEg2w7/mincu6M24odeYlRWcBip9+MQn4V3hWvzc026RtsspVULyvJV1XkyAgFjVGuYhlUpKf+s9Q4'
    'ZSdWmN3kShQzGjtO1OLKDXkqN17JiTNuKouz6v3PWCEQ89RuhnNx+EGwGw0rq/k61mnjCuMuWIOnNKNP6Ko3PSSwUJ4UxcRU5T+u'
    'eH7Jy4l1cbOxD3O1zd3WdMrxGpNImtbAfwDMC/kS8V/CvZh3GfC++OTjmWXEr4EY47QhoMYMnWtOoWNchZoW+BiGQsuNB9WNDnmG'
    'EiojF4aVp6/RAB7pXfswAPUtdq+77e98WVMkt5ypB9ECCxfYqPqAi6SofHF+RdqJwDBCZoGr0scABqELOjlwt1atGtptJ2PmPRCa'
    'RiP9fN2uJAZLj7EqPWCGJh2KKQt2pOOyr8gqyX17mXzcTB4MhJVvjbZ+jZOYd55ezYtl33BbNt29H4eJ4bT4n67w6JdbA/f6SrVt'
    'DWAMa6yEtCjyAws+rJP16ATlIetDJbWuMPIPCAwhJPS94f5WuOF73HAzJCw54Yk2NJ/EZ04Gh9beHV24hiTemrc0dc2kYZKghvRr'
    '4h9eB4GEsiW+tJ/Yke3nLsQrzayuKxrphbLxbuPrWO5h+INhC3orLC88LjtZAIPY5JbaVjpwW0nZXhSMRJ97CzC5Y4FR9hStKRYY'
    'CwZAoBmX0hBM9RefLDvcuRa0a1rPsiV+VokCzBexNtO4/JTyGl8Uy+oAnWbniNe0tXOyFRFGaErTiFxgvMfLzmxQ5kPkpfoOq3zQ'
    'oAZXnBCaqtlxwpJSCMhAshINkfkSLwcxXyh3UVB3YSXpsXMIXbcT4A8MBkFLdBVDKEkdpdeDsqNENm9UvsURVJIa6jT4jDbNhjSh'
    'P99emND7IxtSlqky5fpKXdcCll3yTovLiCT4+uU3zvxr9qOlYW18+R//mmgpTpCf2vcX9EpW2wgRFGpSXKKMsUUAhMdS7BqSzsk7'
    'zYarSl3prLwuhV0UPORV4K3fFAWsl18VR4hwKwbDwA68sKx+jYVmL0jBKuZqThVUAWdcbnEnxeHOAAZQn2Puo08NjkIOzTlrDCv4'
    '2pWivZXL7BbEQD91Vi1yMyaIft5ikq1nT4bd2ulIJHV0ALiWqxkljPMCqRKeF2g8AMJrsuWldNhWmYmZrlOjBD633IQPi3ZQEUDV'
    'LjkDjm/lhV1yAPXhO+APcKAyW250DZAhgZUMehf1wiEnaCwVY5u0pHUbpdcCWtPJpAp6GjaDk+16qZHJFStU0RVqLKMqkNwBjpjP'
    '2jygdjD4atQNFqw2PuXC9M+YSu3qWXtIz+7W2xMjXBT+Mkpf4THS5lN1kSw8V7oYYRBQwPA5RLrwcKpA9mkR1uNkWiwZI3CcpfQr'
    'ecUkJBMY55TOQRLvw6TCEOT4VkUEbo8RoodK9a0yyInO+TpjJcYAT0Tr0o6n6exMgXCniiBQIQw2cAVBxixiS8y6nRCht8pwwjzJ'
    'CJFG2N+KEfHCS3lUxHnJGrw+v+ld7rESmXuJ0KXFQAYop7UDLZAL9jvzqpjvKZLukI3R4jrb5qoeZEtYLnXvGi4XH1SwIEUyXJPj'
    '6xNHh8kBi/RK3+uJ90yJl/eCKUwGVVYjJ4S/Y+H3R+h1gHR0fI5en6r2rupWBWjK2te+TNgSgF0dWDZyjfViG7n3fDVNxcIqHdmB'
    'MuYM7YQ8g8WQPZcn95IHVk3ML4Oz8oh+cP0B9ffYns/KRcmpvvs28DX4fJ8UXoEWQLP4PUr6D7a2kl8muagf/bb3DFjq/u96QTOH'
    'YKftQyOnDW9VAIIQLlWmWLttQBTB3V+hLPWgCZXiuw+ArOpyzqNnK7jj2UeRDWrvC6f8Q1SQRnbRow1jKVbkyr5VFWYa96NM0l5r'
    'GSRfHc0SPTV50Xr2khOxo4glb7I/rvIFkniZ2qsQQVU69bbm3xczEXlWM2SElJpoR1MGw01L7h5E5NnSM9dX446BWzJjVmo36f3e'
    'M2BMebKdNAjpQPqCCzbJ8tPGiwwH40mxgZFyQDvuVQFIy927bIvZgPCYRi37BxwoVfw0AOeKapisioQD8Eh0eETj9Pwc8znKVEBh'
    'HAnTF+mt35sv8nMUeh0mVS8+Gzl5JOu1eSIqGXA0s2nwGi1oIPKFv2En5DWG6C2jDr8yRcxirAef05GgkXpHkPZe64V8eyGkwqdi'
    'Ls8tC2Sk6nQDd0aQo7BsLhRymfGlmrSwMIy7ABNGwDJdS9VTvFR/lC+oNrOOfVJtDd31PAHjORDthjjHNUJ+13spAsNd5BzjUX74'
    'poCHhh9fZ4tjefxu7/07vD1P/i758r223smsX7aC+3gSj+9qAhLVWnF4ay3P1lbQkevfnESr6rWcE7c0PHXBG+qYip+qo14ZQD6I'
    'hQWcTgzgTh78xqAWcTxDsr0QQcpIjkCMimLwlqngqedf3hLrnDsaimj4F7DQOT2cmGjCdxbZlaazqlHbMU1aGZH+VxZ3DIPNC6L+'
    'pssUEpOFmVBfHSX975nFwaRgfJhewmBF5KlBkN/99NXLwzevXiDFu4coJ/oEwPGHiX1VX4P/ytIjw8QZ0EJX8k60KavtGkheBQS9'
    'd8HWV/lpRBvRENoZug3j0Rvpde99VA+WvKfGcaw2mjz6uVQWjt7DxrvCn7MVgG2nFaTtyGBgKig8y8eVd6T6AOa2rOLKGX1g56us'
    'ddA8B8sdVp1aqIdRva44Y5R2n+0iHRfxvgDOzYtVaZB0lu65P7JKgnjIQ0O2HB7YMsXxMQ4P64CB1ge8VGSAFm3hs2RiJ8V/9n5H'
    '39Ztd17vEE8d9/1bMpkWkV1vjKX2WFQ3rCXHIgO0H0VSRkUULSZ3qBjKgGh2oNb+8AGF+HpT0RrtRHxLTwTjXQ5vyImWt393s8nN'
    'RpONKjkVXFSj62EBPRGzUsuudHxs/8fZjzOm++NXuqkyFsugdQj0NnOoEEG2iMM5UKOux0bwgAf7LTgHG1jpaPruhGNS+boxTxFs'
    'SBfYtTQbYF3fHYdiQu2VesvYw3aywDl4monnvUFQ98+gzOMiYy2QTjofDTynr5nfsFhhk5i3OFF/Rd1kfAXrmIV+hIeMJaOSz83M'
    'D+2wNu5oqXF5xZtVIHjoTgl+b4eWq6MiQYVWz1L7/W57tWrNrY01EbLusJg9dN9Bo1CL67jZCKTfvzt49RL5V2XWX9MjV7aKkjFL'
    'mpQDM3do4GD+p6xfxt3A5f39yh7CfsHpIuOB7aUcofYm8okGdN7/KQPPMqD3O40yU8PEYcCrXYRbGP4vNI1FWmSl8MHDgEPrWMPf'
    'W4fYwdd8ySAsMFcsXcE/PYFfCjabQd32tHPHAxZXL3W5AW0t4MfKQnPPP/Q+ltWqC+5wdupUkJJI06AcIFUf6OHp6LiVwOq7BjmS'
    'AAdM3STbInmd5DNn2YZ3aC4zdyfASd+5s3tfy+/sySdU9MFfAK3u3fn/ak8VQw=='
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.10.20.2130'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = ''        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def do_POST(self):
        global last_seen
        if not self.host_ok() or self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': VERSION, 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        while True:
            time.sleep(15)
            if time.time() - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. Everything stops by itself about '
          f'{IDLE_EXIT // 60} minutes after you close the browser tab.')
    if browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
