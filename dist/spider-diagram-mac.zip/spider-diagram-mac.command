#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrsvcly68iSKLjPr0Ap7b48uhJJTATBk5mnmpSoeaRIitKtuwAJkIQIAiAATrqvzGpV9sx60/26zfoP3raXve/+k/sl7R4RGAkO'
    '0jlZVc+sziCRQAweEe4ePoXHb/+gO/1g5RrcKJhY3376DX9xlmYPfz8w7AN8YGg6/JoYgcb1R5rnG8HvB7NgUFAPwse2NjF+P5ib'
    'xsJ1vOCA6zt2YNhQbGHqweh33ZibfaNAvhxzpm0GpmYV/L5mGb8L2EhgBpbx7ck1dcPjTk1t6GmT30r06U+//UOhwLW0HmdCs1/J'
    'z6I/Hx5zwcjgfOiZ07xg4XhjTvPJM811aSmuUIDqlmmPOc+wfj/AhwccDhY+T7ShUYJ2jpYT64Abecbg9wNdC7SvqTfHf5JO4CMH'
    'H23/9z+J4igI3K+l0mKxKC6kouMNSyLP81gcXnI4BXVniQV5jucUGf7B5z9JDWhHNwY+/QQgGZp37mm6CdPEmTpWCEzLwDaWAqmO'
    'H1fxx6UYPyUfhahdP3BczhkMcGHCMvis0Hcsx8NHfxIlua/qgwF8LuVWEnIriWVFMnpxpVIacPYwHpdn9AOOjF4kgEafKB7AJ4VA'
    'NzLM4SiIv3ukjoBTxQ1My8JvM8/6AiDgrBzGEAy5wNNsf+B4EzJn+MXSAuOLIHKCWCwfcgStvghFRVEqh8kGbcc26Cg9Z2ywEQ7I'
    'nLBnhQhMsSgkHuOo+5qLLzxnZuuZV2+OaSffUUj7pte3DK5Ph0Zmob+KP5MpluKBbSwuFctReRjVhhp01WmN6h7lhQptloFU3asT'
    '5RN15J1wuVow4ggF3MIiVjvlonAryEWVE/hi1ZKKlYJQlG4FCZ/IRdkS4QN8uYXXIn1SCB9V8QnU4srFMldNdlIast9IqFLjgLIV'
    'n3CcwsjxA8Iq/L5nusG3nziuVOJqrmutCEOB/8BlegZgnQHo5PkB52qmHXwFtjIxJj3DM3RgjQ4wuWPOsHyDsqaVHxgTDggsMO1h'
    'ERoNvBX3Nw747WwC1FMMPzQsg34H7gOli7S73znLAVR+ChwP+FFxaASX0NyXXxjMOuWSX0nhXw6hdY77r/+V+zLRgv7o1oDXX375'
    '4gJXMzyf0jQwXCz7ldM1b3z4y2GRFDV87h+5X/DRL9xX7hcLCfOXw1+5f4YW+1jgIxCz6lj7t1I4mb/5wQr5OMd99Rwn4P5GYC0U'
    'esOv3M8DeSAZg1/hq6vZhoVPyB98AnwbvgsD4EMqfp/MAkOHJ0qvIqr8r6wZpEB4aEiGoGtYTOv3DVybnyn3wkcjZ2542LYw4I0+'
    'PvGchYgPegNtoIZN+QHMdPi0gsV0BxvSq7rSJ9Ucm4JtqAYDEp4wCHrVfp/WgmcMdl029Kh5WBRYzNQQ6aO1kQaO5gfrT1g5Vp21'
    'OqKIOOxpX8Ry+Tj8X6wekjkz7FnBH2m6s/gKG5LAu0tOwh+kAn+Mf4tC+TBszSGAlFVe0slIxmy8lYFCJw6esPFWB3q1J9KKaQQj'
    'WIAv/jlc9L8gphQImuAu640P/prGA0EQgP8n8UDQhL7Ix3hgyEbZqCbxoCpWVU3K4IFoSIKkpvCAbn1JPBDLoioaCTwQFEEVelk8'
    'EGShLKgxHog9aL2cxANBFzVZTuOBJJf5yiCFB4AZfLxiER7A4ipifw0P4pGGeJB5EuILnbMcPFCORfVYEgEJxP2xoJzBAlnTDZVP'
    'YoEA0yboaSwQB0pPLudhAS5ziAR/Bi7Sc5YF33wHXvgVPnvIxOAR5TR/GZm6bth/RWZj+q6lrb5yuF9z/2BOUKTU7IAWLJp9KEP2'
    '6a+coLhQnwoT4beBZSxp3V/Jzh9+pvv1V64/8zxAixME9dfUvv+VE3/N7Pgwn7in/5rd7aPngE6BCVy6oAHOw+OC5LIR9WZB4NjJ'
    '8Zg2Vi8ggL9ypHzBBI7uA0wAkAHQvM38wBysCkx8jl8MEZRypmmYiiJM9TwxH3JqPsi3ieYNEWCewIa/xLAdlPSPYSl03JWicokG'
    'eP5PrEdShqxxT+uPh2T0X7m55n1B+gUcI0sfPgH0hEdIawMLMY4uLsWRgWMz2EpCUeYKIKxbRoHulcdcHYX1W63/RL6fQdlj7uDJ'
    'GDoG1748OOaaTs8JHHh2YVhzA6eeuzNmBrypeaBTHIM+YPsF3/BMRm3R7NNpx5+wdaKcaqIyAWDPJnaIpajpgALyt5xBEq4Eg4oQ'
    'F5ZgAuOAKfUdy9RZMVxhtnkWgbUklz8BwMLD9cSfGxCBrDdMEUeW0NV0nVANYACh3UQHR2E/DDCQ4DdCtT4q5H4MXDb2kQBt4Roh'
    'qQK5COU0EqkEhwgKkVILhisVHhBnMYJxgFCl9Q0kOzpAbPxnEBxQR9xIDhPTDomQzyAT4faHv6aAEtNAyQQohT5cRtTMk6nKBQq4'
    'gI9dBMYyiBYVtZqZzwgtmnQxXIbkQDbxq8xwi/YESqwRAum2ED82LMt0fdPPzkO6LR1lpxR/YzAWLGMQfGVAAs6X/kzkz5nta3ND'
    'L4DObg9BzMP6sLOtfNBSfbMHEvrIWRgABAia9pBUIR39uZTo9ivZMqHfHAJfxydSmCGUabuzoAi8lq47pXvTHgFtBjmrmV603LVN'
    'LQl5QhduHeHp1n+Yv7KbiTuPic0CutHFq1vEym5mKTJkvpmqpcRICh4lHiUecvhIiIeXeLSR1xCQvlooG/RHpqXHDIFVZthUJHTg'
    'RcAL7DEIPNk13kh3KbpXkO4JOkd6+Vdu5rqG1wfN4FfOAu0HoMBuydIVedmYZAcrpnc24OKGhZaEvyV2jAhz9kLENLveNHd0Q0uj'
    'SCWFaYh9VXwSMgwXdn+ymLlsJTlXuNBsX6HDoqT01XaCL18BXTSgQP0wd7NJkhGrG1YI5yZ6gPwFJzcA3CvKMaC6MdBmVpBspEjk'
    'kfXuiDAbE0tqgplYmyUOKtmmQCy6ngnLusrtIiJI1srPRP/J6zAquY5m631F3CnZY6h1Jcuj5Q+FnJi9SvzaQleinRXl5SJyVajD'
    'cFSbBQ6i8yBBTKSYrXl0Bw45mBLt0D+Tkd1Cqfg1bSfRi+kHicoZsAhnIHxDzACH1b7FUuaa6EgEDWD3XhBTAZ8mldQmQjCfSRcp'
    'NC6WE+w5FglzwMhdjXWMTtQsjnuR6Ml2MTo/+3GiNThGXsT46Gh3C0XhToMIEDX6M+pj6XUT1ZTgVQwcx/Jp70Seg5Ku45tUrPQM'
    'SwvMuZFEg1Mn2K65ZPcqnOlwLGIG+Ji/LRN6Hf7FYe6Q+sL5JLD5C2YFSkgyQ88E3QZ/FmAHc9G+WqCSso9jcw0t+KIcA6a7y0OG'
    'niqOYA0JGf4lN+4UNtItacHMTOFMi8m5od+iFvg/bJ4SsDBGuVZHjOrEzC+sMtFMrEQmjc4VDB+6R6UyRfoZ8AWy06fYYhLPBUp+'
    '+czQ0nqGhTpgf7yuaWwWQcprNL7/Dhd36080y9pbaKC4hnYVtqvnEUskk6TF4HX5OYR16GnMaBNjeXo7IV0erpUhPh7oGhYBlPch'
    '82d8oXVAUD5E/DimvgZXQ4MBPlhvhw4RcZQiKtvw6UiLsPw2YC1OUgLgHjxKTkhR9xzXpeUicRN1dV3zR8aaSMuKFKjv5itXUOLt'
    'RrPnmp/gMoRbp9X5CEt6ltMfg+zmzPojaJ2uBd0SZj6KbFTOSKo1rP2i7ehGYlARxkSs0/HWVlnrAV0CdvwK601njTa8QTli9hSG'
    'twlBbZ3GNwn7dC9LC/AbTBgU5qyQExvl1jiIggsubzKjEuwfaBPTWiUE1xQ9uZ5RoBQVTgCzCmj2agEVYGbeoWcdCUKM0AptfP6W'
    'qaVbqMDYLDNRkG+hDlGh8gVdsQJof9BguBSR5ggQ+dByKF2YPgc/8QVphSqI3E7LBuE1SoK7bWcRqTEWoYqluT6gP2Gi+Wo2nY5I'
    'BsqOivLbaOtAklKzrE/cCF+OEGMSNEt0zWDbWHS7+pFF2LSSKyUl0nFPj3RoYP9k1+BmZmHi2A7BqGMu+pirIhGgifEY2iELPTCX'
    'RJ1wuInh+xpaCPwRCLJsqUfOxHCRXYOgE654jHKkMjIPXGJieKCoRzbjhCYY+2cL8OqYK6hEZIg0Fj6B5mU+Zb7pa1b/C/Cs+YIr'
    'cJJI6m1kDWsLQIaaJejIeH6YFXvlHAFMzdsmSXdkVGwm2FC4ougfxyPHrxvIjOE5rEBrjdSOGdUyQnMGZCkWMEGwMF+Aq7InzPkH'
    'xYGX6tTdCHql4R8eAwPRORNwEyVTZsuBTp6zIipbwZAv5LCMaGHQ5cHsSkTAT6LHMQeTzp4FQG9ohY17rQf2RwSTdSsP/xlqpRxi'
    'XQ0IFza0rFEAqdZyHH79iwZDKBhLoGzd0H8/CLyZgc4qinu60Xc8jc4gGThSMsPL6Hu0NUfOgHAuinP03BJFIMPPGNJXkqJvZZNW'
    'kGiyaPoF21hk5bAdWnSmch5YTDzYosonGxppfmHm6kDoWUic8U4oEpU/BAlpWrNBlqMLAnUfZuh9F4qKzxmabwAGF0AAgD14gFFH'
    'bN/4X8bGagDkAxwvqvI3nNmULQWxPsHJaFhJsYIDp61M0MnORT52z9BnfUMHlhyKtfgdDTzbx5kYANvaoslhGijhsqHyQCk0ZI5/'
    '4o44ylJDs4bKh2bwEI1AmP5SRqPEccxTR8BTseRhyk9D+yCkmFCwEVT0DnyEkhNeiqj6t7TzTlRTap66RtopRIub6eXgxprDIl2F'
    'bdO7xZBiTuVIvMgxU+RUTlmU4mnA5XwKtGDmZ/wr0kaWlqlGIIpobD+/Vh5bJc5fQdxmPmfe3cP8LTGPEDc6AbcMopfLKrZVCFeC'
    '4h0oKIO0nStaOMsZfnCOEqbt5MKkWtTQ12t9dPbX2xnJaX9rjrmNbCOR4kZ4UaoJ8gH0hI9vrzuJQMgQQbo7YxLhL0b1IM/yJpqV'
    'aSLfZJFvQd5pjw6RL+0L5bl1MN30vOYONTOzMptZkG0OnrS5wTFv2T8ecGS8K2cGoi2+0EKpi4k35OmpNcyTqkyb7P9J6VZWf80a'
    '2OBz38iuVHI6ksqlVA6JI+x4uw+yqBPQGLPFPUCW0ntAJFcf/vohhFbT7AQ9wiLhKUooH3/Iw/YxHSlkXLEyzpY3jnA5TEzASNxM'
    'akS82qh9R03sg1TJZiNfMamdHwUQzyPbVMgWr67XRMfeIuut+xkE7TUjQFqeF/mkPE+/xajIR+KCrKyJCykZgeldGRHhA5EVSXEg'
    'xhklwhn1PwzOpGSIXC5cDnW3UPRLaKsK+q2JsEcWJ7TE8EnbS2pN6LeUZTi5CrIyHyVnTIy01HVcI322MFg+I1tQhGIe3lnwESlu'
    'J5pLm83ScV+xaWaTB2Bdb9soC5Fmexq6eMJZyvObiPkySuiBWrc3pto2c6TLtAF1i0aUtAuQleWKYtmPiTZco5CdEA03w5ZEIRIZ'
    'sQYolmkOBH8rayVmVl6RdHiIyK9Vs8xYrA3xUlorVQxMdx/pWV6rGVutUlgTY/WuOI40PVMQo/CePO14+9pHK21r8xg315SHtGlI'
    'SQ7rDoa1wfVejt0StoNWKkAy5MhRp85gkFYwU8GNebaiVIGBaQUGdSGs2BmHw8x894ozMxxQiio3T8nHOGk5TwTbHPUFcJ3iMD4p'
    'o/4sKJoka5vYzMbA4kS/YUthLGsKAz4KVjimxhIIfcOmHhUkvQwtsntHPogNrovUOmf9OwTPE0YCaPccmwXZdU8jR1gjsnGwHtjk'
    'JJxckfGBuPgauzw5CQ/FVqMv/DzMRnjl6MmbrLsJszcaxdMxZGtuli0unI1+n0/5l6rV6rqDaZeYEXo5BiYxm26eWxqzsI9pvfuF'
    'TXC0HMqvSbm/LKbk/j+BWIeuq8PDXYLXHyFl5QUFJybkEoMGsw7MdUvujvDbeIMRUmLThvjD8ppevCusLCcqkA3ghobzJEW5Mo+i'
    'XNbKlqnz1Zi4sCt81QYBC7dkIRS/3DmwVfVgv/E5cmDnl3Ufbsa2I++l58d2icGHTHvq+hYp58YP5CtFA31XGFoIEwt4jVAhFTHD'
    'b7KNJ4Myo5ZIGO7e0QUbo3M37nSkE6I47h0QkdvWRyKFY91DjmKyEIxgmJFpNlhjUlJYnquhuhaYQnAWhBuzT+KF1pTPBKOKKJRs'
    'iPuxLRShPmyIyEXUkPvBHDFC2uxaJLxwk0uczCodccSr85zMn4ry337cI9KMo4VSqQOb/M/1WDKq+BGadBT3ybbG/XVnZsFM6sZE'
    '9WCMPpzNtC8gRdz02xZfAGviW2jYZ5QNfxPBlzQ0b4sRBZ3BReLyTkjlwlZJhg8lbhbtFbWYWX/kMOFo+JhuDH9L8FNIzHT0CR4l'
    'xi6d0EsImPvr/kdbdu/xTEXcGCUdD6BJgndSxJ8NPykQ1CTyCx8zgtjmpCZ3C4CyQAOCkpEA8Tob/od9T+p2d8c+Z3foWCOTSrjK'
    '6ydefsjmQYdJA0r/tl9YTdoWrn5wiFsPAqXAWTfgyGEUzVos9VrlMIo/XTnSkL5+HcFMkrOiX7BaYWEdbvRj51aYmL4P7R5u2nQ3'
    'u+xZbN2GdgNtuBmSTZGGKfGFTgMeZvP3O5uVXks1PxQbH3xkg5Sztl1J/FO+JJoCuGhbhYDh/r7uonXS+PihkDxAfox/a63lCK8T'
    'ukUqxnjNLPnheFnqFkvqtMge80Y5dD4YvpGtHgXeb4tRWa8IaJM9O5qUnnPU8T1nt6gbGyODE9ajNXN2OcNG4ta2HUNbq2AyJXKL'
    'yiftofKl7CLrclLO6w2RfNFxtfXTfetwh+FIOW8GTn+WYCcp8Ddy9ii0Ne8kW2qarZ6VOdSWEjn+tB82wqDjBQg3zi0Qx9ttnR5E'
    'jipl+VS8pcuh5yg7qDVkynpwyjs8fjEkf2FSOc4fWnt/Pxholk9DwTaHa0TVQ32eJQ1JKPRaEHhfiNWS+H9HjqUba6HHEbVs1EoS'
    'c5b1D0R+xEQZ4ghNuhlSxyyJQ45PWDkTFaWMOllJVaTHM+WcijPrOPnVsfKgzLgo8toxJ8Mcn0wCNdNR7qErjXak0hjCPPLMdEMW'
    'OUVcJP6Y7KjkU+YMVKqH5CGHRJOj1AwEemK/2SUGKKGYlc0wAEJEipHIfG7PuRYWJuXl70mJ6mSOpzMnSDqr2FSm7bZJoZOuobTJ'
    'eroH0WBU/JYeY6kobz03DndD3D1LRCCRRATlzcHUGRC1rSJqknA+fxaNUlWKuw5I5pw0fqzHLG2Jj93dO41rdybGnhEtEr+3NLoh'
    'aQQZH/bI3Lqfz5WQ0flEFl/w64/J5BCBuJYdoZI+rE6UTeLRzdX2PqbCrnWdNpnknJLbbjIJVekwDnMzQWKnT4bmkVN5eWZTUeT3'
    'salvVlBTNsZdfob9M47kmOXjsWyVnxJOnuypP+RoNLPNxFx+MW3O94a944wHTyz/KXVcLIU6A7LH+0n63YqijHHth6F72Qs2m0rz'
    'XQIpsIv0w8dy2eREnjLtP+Hx+5iHiTncNpP0ZtDX7Rh8OvLgg6Eo6U5sJ9isK+N69DTf9FOnpyO63usEcVw8lzbR8LlmNhQSplBS'
    'fYOBaVcQd9qSRqK2+PVm6Wc/inAOmUZSqY7rROXyG9/Pd5U0sgoZjokBlvvrEqRfKnxmz0CTeVBi6skcbSbW1e0HpbHDAmaiOkaI'
    'QW79IpaJQ1YYeIchPvU1T9+w/ntusZsPyUYGijW57w/w/ybXe2fijrXDVDHz5YpCOX2gSggjqchkRWoy+UI4eyFMa/O3nf6KPBP/'
    'y5cCC3bMUZSxlyJLHfbxHSQ+a57elMmqF4PRbIKx8JrvwqIWiOkGkY4rAVX8uutk84841bx+opmq2PLHrOap8WDS3HW1bcvB5EQL'
    'LCXZug2fIdmHw+9zDC8M1mTUZMp8uSbM/BBTP+2V5Eze11H8A/v1bdN1jSAO+qPnN7MZR9gxj4/oWGtQr4fZp4OGYbJ7YzOgGQDD'
    'LzQqydImuG6/JssUHM8kbDdUhzcGcjIM0vThJi9VHGtNNVZ1zViXN34mfGx3rFfyg+3ys98kwPWMuaFZ2+BVEoHEG84Jr22QyVO2'
    'uUdW81hqCEyatS7MYASSbwxo0mEac0h6EvFjzu7kNs5iw9jUsxMmoatmJ7lsyJSRicuLAE2pU1IqdSL9lk4OKRSVpIRB7HvZhB8C'
    '8OxCUuqR+UjM/5A5HehznE1rNBgYvKIkoiNZcti8+OeEmCukHeK7JE3fQL4du4/ChwUSEhhPWIXf+2R/3HC+OzFeG8tOrEg6RQ61'
    'dXw0oWdxc0rPsMMiNopbAGk7r7WUPklTdqCxG+A/znzfmCKj7zk+yASml1iKbSkyotABQvzJ0540505khBFiv7pUzsYJpOJcBCVK'
    'YPI9RzfE3Qc2Pig38nvEDYbBI/hwx7knWs/of/CYnpomE2zgKNXY/k5cViYTibKfqCGlK9lpGyz/4cxYhdzzRzs09jUbQrq5kBN8'
    'LOHQZwDPidz5rcTSif9WYhdToLSIWcZB4KT5+w/4g/CGAfxIyv9+ENFZSGYHHDnqT7GJHfTHLOW/+atJz7HwVoYDE88VOgfRvQ4H'
    'JA2UDP8Ovv0W57k/EMQDTHJPfnu/H0gHpdzXUrFM3sNekikh8rREdcN7zNfPuqhubETZo4yc0w/LwH/ww/PvY+MlOp3rM4vb6IaZ'
    'jQEqc6IwL6ga2jiIMlUQCsKoICcfcMJcTQ1DAiA0kROp8sWREZStSkFJPBSLCsdbFU6pJZ5BU/y8GpcqwKeLcvJ7QXzfOihgh86u'
    'QVVh1jiZq1rlQjkFNzwbwfSVNZw+/E/BwnQvF4KwtV/P2NnvBCYTOoZOC9mORZ6rXlQzHfOsY2lrx5iB2sNrVbb3rXBVTsG/he1I'
    '4Vozf9f8wTDEkSAjtpbngry1veVODFMJXIJ6C78scovI1gb9mf1hdiBniUyck7suRB5+y8WqxOEPC9QkAXUlIL9KUQGY8GfiKcI2'
    'EnGxyG+lKMmsTCFRtVrkK7S9+OnWEU2cncuHwEoazhNFiyr7i9gpFKqF6uvWHojzYR9Sv4gplEfamwuJB/Abll1MPiiIncprenKh'
    '2bmcqQSoArMpXajkdwV/I8KrW4EmxpQNQLN7boDPcyvyk208ghrvPPjZQ86eYcDVJAMWk8BPkP+UC1JRwP/JmQD2yt8owJ+28wDN'
    'tHvOYtdEi4BHFU1Ab1XYPvxAQoDH0RoXYMl5nE54GEMic/xWEKhJfCcE8IzPrKOaHG9BHBUqxSQjhp2qWihWb2BTgZ2mWosrV5B+'
    'pAs5izlSGgle94C74LjGHpwMJ6VYhlWpJvYO2PrgMX8hJnceoViF6rD34AYkc0pqQNUyNpMAnGwvnXJyk4KJkJLzgFpoFXblooof'
    'k7QAL2AmLgQ1WR0ZzdZxj41VzwGFeAeeiwTP5QjPxYSEJSgJPI+WWOHUUZEXkNDYBzn8oLIPKrIx8kSMPinhpwroK7AXbgUela6d'
    'XAUPjWmwqUXYUpbhnyUVEk8B1/gK+YELVQFwihUhy1YEIVWhLBewnQLgXqp5YL6kIWyiELazRVzYYxATQS2qMmaYERFlKiJpdwf4'
    'tyDGVTA8s0KwryJw6Up5oMKSiHMJ9hl1JJG1qMI3oYpLIe1YCT/YtRISp5CVlcIlhg8hIsBSSxQf6G91JOzusEAUMkPfAwWgfYKK'
    '2AH9oOIHGV/M5VskXNxQ4fGF3EeJUkQeUpB8lDaR1Avbl1E35+YefI8MHSQNoABLLqAMSHcm2MDhYwH+bhe1LEPzCui20HbOtsxV'
    'OvJIUGABYV/lRwoI8NAfLDCPO61QtgATiCgB6AEft3YMn3bOMqHcqoaDCqVW9aISiekCziTwtug7PhlV0uW378cBKJj9nYtd5eRR'
    'oUrkAP6ijGMFqRo+75LaaZjs7lHKcyUhCOEm2UEEgikWlF2Ccn+8x86IkrIAlMxk9M045wT+bkm0nBJEQZHboJluLlDNK7BZqTMs'
    '98PyMeXzsX5U5EG41ICzMtQoF1UgnT4KCvAQ/5M9o4LcYys0gaf5o30YExAlYI4C2kRG+atkdmcFuVVHzuzRcnbTJTxGmCt045gr'
    'u/YxYzc9C9W+DJypXICttVDxgarxd752L4TqfXmDmaGcfL9Z1wk8c7xbRweiuIiXi4irEnI23LIyDEHBgYhZUvkNb+VjN40aHoED'
    'OCrXtzTf//3AA5H2GzE5Jp+SGy/Yc3gTpqoFgHoXxLDAyrE7P9H49vvBieWQy/lMP0rmhOkyhw4XOByms145My985cMg0agUNZRr'
    'MPptBi3S20N/ZjYNMjQY0G8lClUEJDmuhiCyy1ViuJhneWBa2GQJC7Ihl2DMG0bPRQb9/Hk4g9YwhWAIt+a7jjtzGeRcJtElDW8O'
    'IbozFsccisNkgvAimYNv2B6XnhIO1f895iW0EmycGhwbAj2IYGZ9EEs5Se+P3roD5uwL62VGDFBHI3jCAA1O49DVw1b04Ntd/CUL'
    'Qqape6IKsLbuyUTg7SnkhloEkqRj1T1tyGGmCccGBIpztR4efMMqf/+X/0HXnI1l3Dv4dhJ41tE9W+IdMGBCsng8mIQsiboH3/BR'
    'fgdP+3dQ8zNdOGzSKDKSZ5q/cShPI3MQbOwvib7fgckNdh3DZzD5xHFXx5yr+YFBcFmfuSBH0HyC5Fj9wTds/o9GbCMawmcQGwdR'
    '9zS7P0qNi94zSo7ZGTobDxkkXuu0QpftkOXnNQNYL6iRv4gn+6HLySzYr3vMP9wj4NJ8xJ4xcQCNCBCzIB+G7n4wPOBCRlCQb9xi'
    'pAUkU1/fcU2ARPMBhWn/YcbkDJQH30jNfEg6H4Dk2tT9DDSOza6NDdM22IaPPceJkhmYwDiOkdyGZkjZyEqiW639Wc+nriqfgRu2'
    'xBreRpB7juE0JIZoDDWEbrVh2tYW18a0QzAEXNmorXy4Tv9YFlHT9c9yCKgardUXHPXYWAEGeQY3nZn9Mboy8fpxHHsDvVrA3S9t'
    '3/D+cJ6hhWP6FMvAe8BSY4xogu1VazTxYXGHWOvDYXCUQa2tPszdnruR2QNReJiFmWJeiGkpwIFevhtq1usa2GSp9wP8VjNjWaFm'
    'OwCjx5EUASAuaMccRs8QsnEWNlsDw/9uwG/DDnZAd+YZSfJm84lvKUTfDQh2wJpdm8VTZwaPC33gDOM/lgGcUqnos0zgiV7T7XMD'
    'hzLpxcixjFjWYs3/0SSvJ0eRIvt8ik/MUhircBC/zilAhnvw7UaD/TJIzDcrTn37rAIzWbAZahoFzfMwO27yDgISUI25yfqgP604'
    'mr8I92JgXsccSj14mmoOO114kI5DwRkoGOWxmPXQM6PByjVYvz1neUCmxK9BDwffOPwF4Our30oEyhTcbmqQ6HA6+HZtGK4fcXY8'
    'QgkAkuhIgKyPAakLE8Ax6YUXxJpIIJ9o9EqFSfG3krt1MmPVdIPURkeMlBpLCWeOxQS0mEdwOrIGspEyLsHmhRSOivnrpL6x05pl'
    '5XUZ7tyYRRjFQ4zLY0w1lDVI6ZBN7dFjg5BUsr+2Pcj2CAyVFEM1O6/NDCpmv34Wz58w+ONDaF5n+BKgUDlC7SecCiISoC0UpDYM'
    'qdeJSMDCxWGV8KDvCKfVWm1H6MbEhfngLsKsE9Hc52H2FlAbGmzmFLpffBJgMwPlFLDXp1qc7wwCqvlY8GChebpPEMywdX87hGfQ'
    'CECIv1i7MHpyTWyMF+ug7kEetFI4x7+xFCGkT7yiJBrahbNAZ1MsRA+NgGOHqTGSkgQm+VTvpuoqsaJ9+81xcSa5uWbNoBl6OSPo'
    '/eT3byX6NlsK0/nOgMffkt+bSiE4B9+e4eemEs5gAF05BDa80CsuV6ID/ZYza9Gk3MAAMlNCHiVULtuGV8A+SUjT2mD7M29u6Khi'
    '4e9NQPqBpyHSIW3QT3uBuU5DH2SGzdA7zUZzTrUeg3K3iMaYEzvEumNkz4Q1f0JMCR3ikaTSTDe+Bx/asLU0jZAqckYAvODv//rf'
    'OcCAcQR9csMZeM6EXpjjuEWubesOB4RIm0K2GTaNEZbpLSgF3G65iV72iwbFzWJVvjDVJmFMeSZUAu4XotG9Hn5iTUiA1EYxKIUw'
    'xiYY8A2DgWq7n4KEhEzlQ/JdtqolpnJNCXDsttrPiKW0NWLRgPYxJAXFJ43yQLb1kK3V+ePVUWN9ZBPy5YdJpZdkgF8e7s4PP8Vv'
    'KNd6wgxlKT6K6ZKzU+oZJAwU+N4aIxUOvgn/3/+1iYGKB5EC+k3cXEw6+CZtfisffJOTb/fZIE4YX0gOzbWHLUx+vDYG2IFgQyM3'
    'q8LHTWBYdCe4SW8D6TIkq/K3U/j5yY0iR4LZJnzgkOITaiCFJL4los73FkBSOumQPmKaaNbEmrZuAhqiHAW6q0uDZKgFNSSPHKpf'
    'p/iwPeRVDWZNh3bRnB6188dIvveUOXBfdKc/m+D5o/22tgYR2olSomHmIZ0kwQE5zAKVjR4m9bm//8v/GQmtIJb1MWsEeu9Qgy5y'
    'l3bfmqEUGt/iGO6On1GpEujOON7ZJJ5qsqLhPD/DZsuFA/apAwu2YHx8zJ07zhBU+lOn7xPJ/cbsecb9YGD2jUyX0GmGBpz+EmQ/'
    'bL2UaudLEV8dbpQsdSRCb0zUuy/Fib6xZLAEVH+wUJIgvP1LEZ5sLO30fBMUcGBd9+wTvJlZWO3ddONq6YkMqfZ7xbqNBLVNK3VX'
    'DCPTRMZW9IOEFjW1jd6obBBSHesoSXkf5Vqh73b5YPabZNibuRgrdsCRx7BVhFQBm7dr9oMZKDLp2xz3NGtErd8RciWTSHQ8Yrqa'
    'aAFSa0iLBM8p6SItwyQnkRckCUTpNZrc1CtBMdJtuOXXOJZgAYZConyPiQ/DJSkXUHFjxs9YhQZ4aKYwYC5/+Qv5+Ne/YqI6wFtQ'
    'TqlKjWSLM8MaB5oI0Ty+3xKmzB2R0ARyb6mf8t0DDwpIM1SK5kBsI9mZA8dhEKXpBrAie/Hpd0ne26ITSIRMnljbYvdn4ul8zbM5'
    'TE0LK4bC2hN1PJ+G937Ccrtcb0V+fyZMAWHYSwinwkUuuE8wj2h/MIKFAetFLRnEw4qHFyeO/hnbPAlG3yGUxx/SUSIcSUXxsViR'
    'lqnHXAO/cBaxjH7lQltnxlL3ix8js21ogbWiKOkimkXKIDHWATxDA30BB99axGy5ZZ7PzNi1Cp8j6yqsv9/3cH6pvsMfYhxGsL+6'
    'kj/sOxqRHwZ7OIx7UC8kpVzAQgfG75Ht6DjkWZiTATOlwe+Iesn4fw40YDcUyNBL9uHVpwcFInWdwPWdQx3USfBiHgLjGwZx/TPQ'
    'krDIfahocMliF/OgoO8YHJefgYNFRu4FydNEg83A20DR9CUTQAhABQCo9vf/9t+3Nlo3h8NNbdJ3ySZ/xyaPcrXM5LaT0rCznkK0'
    'f33a0zPSXOrJJid/NwUIkD7+IJU6oVT78VCy7h6OWS/X9Os9tIKNylBKrKHCG52QpJg9II8yJnHYZvFhVhSFxQw9QJukVRfmGYRb'
    'Ey3/+SVQbPpWd5ab3tMcF6id0A8bpWgDxWhyGRKGYWxWWNfkvY9M2BniTWq+8El2ugZk1B+fLXKwGFYFf20cp2nvUttJMhDQWfDX'
    'j5iHvbToQdPwjUSQEAoyyU3ll0hIRd/TF+pMwfO/xxS7jsmsHaKBFdpJlN2kLW93HKW/fITDkAQAnw85I56YNc7CIpI8IgGHU4rd'
    'kbPRp04Qzekfz3f68QA/yncI21qgaSnlnNgy5oNvf8wqgYL16aCfSAtj/t/vj4ahJwYj6eUPX0I3HP2/ycaRmHezpuv59hcM2QH8'
    '9gyS2zhD+eGEfyGheoD6sCAOi8wkwbSOi9rj4fdP/QPtaYuV7YM7ZNaibOKTOO6PDQwZ2RrHf4LqE23z1ne7y+94g9Ea3nDjnteF'
    'At1CpshWe3Kaiswmic5MeFdIsCZbLWTF+P27GfD3+FRuyCE5Bh9+yQ1ORFewveJo+BV7FkVpYwVku9wI2EEc/9R3PPtzugrh4RHG'
    'IVBbFTx05X5aYkUZ8ZgjRE1NKEBY/bFt+P4aw2Vu8E+MxkiN5g+P9LeiCflDfElRHy0kDCIs2cZe1k6Yy+EBRzO0A0tiInpGAooy'
    'IkUhJpsNoKSpeSjYRYtKxbzkLFvZw8cSnqrLn/Tk8aULSdqyX+SBQnNqRbCc0q8/DJgw5xJ2g3aU1e8HCid/FEYHTZkxjPTrHwkj'
    'X+QFTg4PRSUB/RzisOCTTYhTI/S8D+ZgeqOEtYZxgn8v5DHsRFwxQkK9QijRawttFcc3YBIg3O8HxGWNDPNrFIfEQs4cO2Tfhz9o'
    'OGKcC4Y1RRQx+l7mFKtQKchz9f2Dgyb5XjcNG23MPwB8NVqNfPBFgP5TwPdgT0zDDttIgHdzjcJgsB8B+0em/uMj/BwNkowFm2mw'
    'FW6k+5AhHqiJjcX45UdyI5KlKpW/TvjgMtNLhxKMgnz9d+ISRERJztYPIZFt0/V5zr0lbg1FiMzJKxK5Rt0CxHVJFEjTj05XhAd4'
    'LMeBIddcF88DOSygnBbaHVWLLaeNKXXiYaAnIOhKkx64L5S1Um1q6BjM5cWCiQmeR9GhoWVlv/5vCI1EvnXPJCHb/gjDZ6iW5LCh'
    'IwDHnFEcFrn/gheH/LpwvDFIo8D56XcqiCcOA0QC+SGqN9DWBsfsOlSnJHY8lgtoKHkEBveFPvmMTE/Pi0diMGvaypHt9w4VjMCm'
    '7to/yKkYzkmeBT6aoF3HuYj31ltTJ37gjG7VkMLA9XTUepKyiAMb/cuhbxmgndFQczP0LpQO0SdOW9rpP0y678lx1+gMMgyt3zfc'
    '4PcDduj3uPjmO/ax5tJDbqBkl/BBUmHZ0BxxMJ+a3gFH8xnTDJQOOhXhhenCOoRtbG7EnAzTYBGLR+nPcf80HyIen//tHwoF9J2R'
    'a3pJGDu55ZRcczUPT2d4MH2hqxsmloQm6F9ZLDWU8mGEx0zXxEiFATpxHLwHJtAsq8gVCtBRqMuRu1QjI1/0mF0VfBD5aonl0PCg'
    '+boW+4tosQPOc3DVNcvw4pMusY2U1msRA3+O5Zm+TgVxnToL23I0PXPg38+c5A7POJODj+v7RgT4zIWtzcgDfA1WWnQjrPT1ubMW'
    'vvKtTd5g7u7c6Bda8Qb+e8g1yQG1jfDi6l7S5doEMaWLD9sKMCVmSNI/pTMbJDpNDf+nLLknCtYDe30m2LsMCec3wCYEUD41c9uq'
    '3G0ILT517F8w3Ba206FmfuZs3DKX24WkkaEQPIVjnFrDFBtJsHwdX1G6wJz+zpABMHF0zUrZjsh+bBl6b8VabdEwQDoJIzHujr0A'
    'fiGyt+63ywHhCjoZPWZ7OKbhNP0RxkD4nA8cgm4hABctQU7DWI4fxIEya1k7Uls3Garp90mA12nUU4zBe3mYSDMnsB2g9E5/55IK'
    'KUcTKGRR60nLM2duWCFgKvRgSq5PItkjcjXE5I/b9zohu6X0TU18eKj9F4wxyVoQoB9M/hPPTkR88IaKbN9yjlomR7TD7pZcR+wN'
    'N5ZY7vh+dkF7gOX6lo5rAnDTozmbWcnBJKWl9MSf0Pg8NgjyjcSzsAndHkPC2ngil9JsPC2RjK19jtZmQ1s3SKmJGUTK3YhquF1j'
    'i5yB57nY3stIT8cz9gvDx9wwnh+QdO2G5htFd4UnLMmxALSyrOK9mriBtB7a8GlgHDnKSDdsv++ZLnVh0PYJS6HCxppo8+2nv/xE'
    'kpQfMJgOvnIHIi8qRUEo8nKRr5YrB8f43p9NCGnB+xt6vy4LCot0oSgXghOGFY3wdBfqD+j1GdCxE9M9HUkijIqQMnBBZxIezjWp'
    'C9Uv0u5p2BB0/jzCPhcOCzF8c8x1EI5pVzbGi2ljw4+OXBIdE+UbvCQNIEJBE4CMc2gQQYhCSEIIFwR3Na9Pjtv1R44THu5ZjNjY'
    '0RwGskcfuBnQfZHDODBiJ0NdbUzOp5JDOmRgFGhS1wxIQJmfF012zPnhABOzyVK3eDMbJn9kYhRlwg8CM/UT98/HW5ZTKgpyWVlb'
    'zhBgnK6BZvt08iKXHoXMAYFVI0H5HB73BfDCFEpkk5jMoAo5Hdl3JjCsIIwCJSF0KJEi1HSOM0Cnl7eR07fvemS9AAQTc/QM0K9I'
    'YSGiL9N0UuuK545NYGI0L1ZU2kie2adzzA59DjSPqr243qwsvQCCrt4Qw2uB6cEK18PgQJrxxEZ5s0/STmmEEldAyAFFcR+Ebw/F'
    'vcQikzBCWj5cb7zWBcAkE09RJoGx/VGRowcHewbZNEx0wGAlwDxaGsmfI7kDyeiTE0zh0GyWKsYPMLDFTKGuPdOHJKUKwEdmRaNG'
    'j2jhfLZyUaYGjF50DB/3dyTAYsjdAbWxeWKzwEaCgJyvR80CT3aQeF/kcbArToissfoFI3aBApELAgNPZrUBIW7lc0nyjs/XkQN3'
    '+yC8IFXXEZ6FAId3VSDik/VIBxhzX0BGREAwQBNpj4B+GHNh4KYsABkaSaUVg/my0HOHC4F4DFMIDcDaOd44i/GtREAyrka48iwm'
    'NIHVqL7gipAfhFNhEHUUDn3uILBkYGw0ichzFlQ9wKUDwSWCKJT+AHxcChgxgjmiWBkOnKAXGX2RI/wXBckoghum4RibJeZzPxtj'
    'fZyYi2hmsf5IY1HgOeCQI6EE0Tm8Th5bpxNNVV2HC8MLQNIEJduxd6KCWBTKwvpWVov2YrKlMmSjHmO2tcZCGr5O7d8kkB2R2w+l'
    'kBg5CC/p45lPks0FFpZxl7z1DxtkCOmbQYT49FKuArkuJATsS2aOmTBJWIhuorviMBEdr9Gxkf0siDs75tZkKMYruEhuILs2sYKG'
    'MglXG1AOyerA0sDkjMJj7gbeDM71rJkBSwqsJsaUkCOSvS9RHSZYIyDjIgczz8awfyNKSgccgCnMuAesYHuFEcxCFRo1XUK+pCDJ'
    'EUVMp7F9g/ApWuspvSJ0daPcCJgQaB8sksvSBoGInM2GtsdUi2IGLbLDMGmCefcJEhPHEhee1KZ2Lyr2pBh3yGcYRQNiGNaATiKh'
    'AbKNILoEWi+LWRQs3Nx0T1vY+aB9jdnrU4EO4Qs5fk4BO47xJoKVbpo+zaZymBwbahF7jo/hGkpWNJuWQ87/s506LSOQ5cNZIEsN'
    '0iQi9QBPhRDvop9ISZKeEO5yQDkTVqEEouELRDvEymN6RhseEATynePocAph/KxbYifAaJkxGxzWCA+dJMUOVk+j+YH2QSdJXken'
    'E8wd5uPGa1PJ1J31AGVHyB/xziGAlfung1MgTMtx8RQcMWv90wEFvk9ru4aDZsfezCQWVmMCiDOPpDFGQeFOAquStzVlujBDbME5'
    'oeSTBwZdTybj/rJ5HClwQUChVl8A10/C+8UFccCxJfoKdKLD1BCIvEJkLtgOQBzBES2IFwMHhMzI9RxgKD5gUZPysLATcqKRwEoE'
    '+ljr2mfdhPx1W7GDIn6QUEaowZVkIEROjA98c+JiGD5L6MEeI72jLORREssuR7r9rxzN6xfNYCicEXLMyQ7IfWHHt8JzHomTWqF1'
    'GKiZ5scLz5tBNSb72UmapMAmk9GFFQhDRfpLJ7KjcmWqDSpS5+XCK9KWuxxyawbRaZzVkbHG6NwqsnOfTTqVxpOMw6dmLI2KvZm1'
    'oKwlsQpEGtFoXhKSfSs0QsRUTp1zgREtGNGexqlMRCAVpHnYL+GSbkMtvigKIKfk7DC1EDHw/BNeEoxdxyIWWXLM3XrMsbR1+D7M'
    'Z4XjWkOm1ub2vu5oCgRjcglWNFrKC3DRcRcFHGLRbGxeCcqy+EmMAC3gUdlwf1s4EQxkc0xNNAgCdIUiSYfckw5LdB/mrf37//p/'
    'U6iO1yQciqP5Qg5BO3Ry0pxQROKiBpWUIF/kboF1aENi1qCnEGPxOwIKBrDXwkri2sKemUuDQpMWakIYmTOGeWeYrYJp/6mjjJnl'
    'hXa/bmk26+yJR5d1IZF0icBdnRlmjAr9WHkgHNKlSkOMwp3PZEGy17IDkLgDD0yb7AZ0RSjhMQM/R4Nc95pVsbphVjPnpoHlOgyd'
    'aZqL3DnbVYnuK1QiIJkk10+ZUpZxTHDdJfIAawwPbtPBsgQVmEMmXR8mEYnPJ9oNTgQxI/Uo4bgkHyKLD4hXfvccyaK8Nkdhv/QO'
    'Tnq092t84u+YHvc7pgkyca1oLqzoqHuk4GSncUfDyIXJszCpAN2BmEoT694Mu2hRcu8gY/RkLXSS5CoM0BgfMnAJDtucY8fZPmko'
    'gkPPn0eKSnKDhIpDsvWVsAgb6Sra6dZHzERJlDOo4SxiKxnsYShDdqsJRbndiyXySq7JglpOmJiCQzw3g4tZ72vm5HCEOSEhYu+R'
    'sobqwzreb2hYD72rdImQidIp91fApCfHNHSAuKV8pgWEJ5/i5E5YpqAtkJWgpTGj1uyGFSbsp79i/nhi1064bejlcvlONXJ/K+wV'
    'kXNM+PZ9To3MJPu/laBJ2jb15ocQPRmg04xCg7vPvpGzEiNy1B3zUOJD6hnyjyNMxbGTNUEewnFfAB0PD8iMok0VozNo+jHOdw3L'
    'IjkHQi/TBlfGxmh7BBR30M9Gq7Nk6ZFtySEWgTTy0/zof2SIeTZl7vZsueGYt2Z8J5oAED/ZBT/hGU5eMhWhDukIm//OZPE4gg6Z'
    '2jidgGevz3ycU4FkzotYangARyMbUeT/gJEefnqoiVFm98E9k8BmBkjy+29I+ZGb7/87M9tuvC7gY9R063jZ2KyPk1WYHeIYNg4N'
    'ST51hYVl9jyYDba6n0kuTO6T+cEk1QIunzhxh9kqCr1VgWSviIQ9ajRB2yk1Nad238RWoDvfm+mCC+dwNyk16Bxn+IG9NvdReBVV'
    '6xi8eMzV0IgeffC9e0sj3eNu0M8YCkQnM6ljklrMGX4Q4Z3uPzRK83suPckS+00aFz9N7f9hco/kx1axeX5A6fMgJVuERBgFhuUl'
    'LCElWcaSVLssDiFVzk/FJiRPIpIaTuJowlOkuK4dRfSMPsmo1iS/rVUYY7DpZCG5o+bbHfzMO1iYNyfnnqmnIR965JRTfnDNhIRY'
    '/ZRIhoDHOOlFRLB4JEyBXKgOLdCvoGBZpL1h+AQ1bktbsWdhkMlvmAkAkFyLLt9wvHA9cmSktAzWWpEEEcQlC9iLTYfNJeI8SZQR'
    'ireNna1PtKVl2ENyRShewZTqjYTsxPHLpMPUvGLGtWhSo5RqBzlEAyVbznBoJZNdoL7Moi3C2x5jZeUTVBJdGRlLv2FrmT2SSi3j'
    'nk6vAMAPUfh7IigwLsZS7pOCPkvLn1/yCd3urCQu7oZipxgcRgrRhOMbiv39X/+3v//r//73f/0/QOVm5emR19zScYobVtamaWo2'
    'Fy6xgsgXNpSLipi2vq2pE1YuftJhT/rxPTfbGjgNJyS6rWNL4VdWGJO2bivHR9AnVmKdQ+DgDC8TaxYTE319id8zJHJG1O4oMVFA'
    '6JND9nSMJhfdp7I5sSyzLGQe0fk/riLFgNyYiZjmtaAtEhARRjkbEa9PBGOyvEppYiaFm4afPD5+Ss4nO5iRlB4gz9suSMVkJN53'
    'JleK4+zI8ygoND9al5Qht6dtu1iNmmO+MwfUco8tODUnqaxfiZ3RrmNESOJyHk+jOePYed6fcjM9uhhHjIdrNm2KI/Hg2wVNr7ex'
    'iHTw7WnWG2VK5XfYQyjxjAyA9Ii/NmbR8Ui6v0T68Z/WszqmTmH1J3iuwklcA/MHprxa7zm8sfPfJtHVev+JWz3j5NX0CYOi/ckM'
    '1qzZfQGh9yi2Rp4zG44SCis+DdjTj8PBbmfcezWIw6Zts1tzCXeLMxaR5K4k9OEL3nVU4qjnDj8TRwB60z6XJQG6+RiI9zkA3s0m'
    'PXxI9c7PgRHdF7wdHMI6UgknWFITKiyzg8wMga6/O3PEbiS2krCw5BxhAqEPo+4efZMJIJm4Y9Klzr7IN4zpf7ckcSEhYZ86PJGf'
    'xyUrVyZ4fAuTEcY2Eo1e6JfPaclVVNTQtoHFUgSMrvcimQ53sG9yTgExBA8fw66/+ZYJkNxpSfgwm9icl8reld86iK2kA3aGb8sd'
    'FlCSdMBK0j62FCZji4rnjHTXvkLn6sLxzHfHBsbcnCUW4pReiP3ZbCThfdr7Egm9X/CM3YydSj4WpxD7BBypG7f3swwQmaTuYFZR'
    'EJACEoRgkukNrXxJ8ZM+ocfVkwLvhoycNHhF82lItUbNZRi5VeT+8hfU0//6V+aOCZy1oAyUhzniBwvvGjxOO+3QeQni289h9uBj'
    'rkD47TH35z/jxv/nPx8WD75tGDKJJztIS2YElK3y7MDBgywZ2P/f/ycBK3whnJZ66gwzjD0FXcpC31CAJRp+P33yOZVWeftpTwLI'
    '5WSYc7Ry7XzmbyUi9kdaAD27gf634Qye69D1zOO+MCOhX6LegwKDpIBvw+Ok6PdlkQgSsf8f0vt2iRc3dOfNaJhClFAjcuvS0xyx'
    'DhLMglwNJDR4hofEzDkKko5FUgNmVgTaYPpFrBvAsxNnZmcPG63dL5KvNWDtzTrDjcHCh2NTcJQZDDYZYs6H5Y0G/4/Md/6DlIpc'
    'rMQ5IJ7B38xwBHXytWQmKoyk8GV8lk5KkQS+Yscfs9QCr05JOpfo1OhHmRI565RIM0edQ+kzUtlB2do8fRyPjAxTMuDP/DN4meVN'
    'YUVjGXha7gE9eHlHho4/s7MdExA7ibTh6BE7VTzzToE1Hnz720/cAePCX7mDNFWhvzrhLZfwKws/RQc2caYbE3cEHeN3nFHi4SYh'
    'V9gcuzaJPCRuHHjGboQiz9CCQNJE08rUR3+A91Fe6tihjF/Du4RZhzz7wB2YWIY/Jp9JdlJoXUCeRf1VxJVI3y7jgqv4I7sF4ytn'
    'g4xOH41BHCdAovWUPiLZHPHZz2JP1GWRPaZm4KityKn/TzOel/oj8dszSg0TEv2Q9mHTEnhElH5yMVOKz3JYEG+oiRE5uETHJGYy'
    'iCOs0GFDHfQksC/hzkHy9g1S14du44fUv1Nkvbqs05nFPlhmdGUYjSTg6PPeN3owAtgKq9r7lonTJwejWJhJnHgCaxAjEZMl4+t6'
    'aUAaxoRGfcT2jKiTEFIALIKwRTLMo2MlrDgggYPR4Z64Nlt8NmPhZhxgVCy9iz5sQYyHRQPQWIb88GgDRyOiw+LRGZitgDaWruGZ'
    'JCh34BmGtfqaHupr3Cka/mgALlkrKjCEhc/MIC4ZpidnzrDEopNwqDU4SrC4B4CV/0xoTEjTi5CmF3L7LjnsGOYTjSmmIBblqlip'
    'iJIol8uCqPBloyDIMR0VhHK5yAuCJAl8ReKVaoau+CwFGbwkSMJeFOQkEPSEIJeWSEYY6ilB3iI8pFAMRhhPJcpuyet6gUJxHtG/'
    'iAclAGvDammkDCs6tpG4mDkXVVduiG9pVF9vkMbhFaMS7FKNdDl2uie+iG99uaOpAk7iEJt9NFfH8UwR/CJRwnT/h+2BoF02eQwM'
    'K4bZ78eQ9MmJcD/mJDGOiWkcE9M4FhphiXpNUpgWQG3QUrgm8ZWiqiiCwKtCtSIKUoxlklQs83xVUoVKtSopvLQTy9Ryle9nsEzI'
    'xbIkGwwHjeAmeEMC69hN67+mErtwjMs72YXUU+1g3ejYi4Y5tI089DmlgSKsz7BBDD5MgMS0jxgieuAtr71n5INhM9E1r3FbwOe+'
    'JIOMQVReOwr4wetdwxNHOP4hDcNkw4mOLi8cGqXtR+fgcEaJmraDm0lpTJPSmEbS2pBEeboRaKaVYmblYpWvCIqsSHK1rCpqAsUE'
    'RSwC/+Jl4HOiCIyusgvHBrza5/kMjom5OOamb30Nj/xBKaIWEv5jJ3fQcLmO7uJ16mn6kPIVzseUt1Ghv/+3/55aTS2biYhQeM6u'
    'W0rsmc9E9kiclSWJf8iNLuTwkk1shJwco3iIMxhJm7lINwYHW2GHZOkxAHajKN7+Cvi/AsrpJdhJNMfMCxsKhWzp5fTSy+mlv6Aa'
    'Wnz6Lcpe9MOQQNoLCfgI4HIa4PI6rsbnNNgBYRq4+m8MsRBBrKQhVtIQX6/7uJOAqnIRACoL1bIkV8plJSknwCu1WpFBUlBAnigr'
    '4i76UhRN5QcZQKVc+iIWIMYsAtSyw89e9BD2xb//y/9gmAZfo+dEVMg+L0U1S6n2eo6+WmtbJ3bHSKAoxdwulhPCxvS4UkI6gTrp'
    'PT9bPIYn2W0juc9v6eGKbDlEKknu88fcmYicgbj7P9j1HRNF6MGenRDkyTX7dURNqFuaThXYt9VbZ57M2WZGGk5eDzQdKZ6v+WAv'
    'hCtGWdS29JDhxnsuAdLArkY/M+XEjVniqD9wVwd1KEl9jh/thV5dU6KbGbvEZldvv4e9FT7YG7lYt4S3Bzu7+ngN+2C3336wJ5Lu'
    'rMSSOO1cn6d0Z08f7AwDJ3d1cf9RrkJPToTHxkrRjY87cS09lsZHqcUM4gu5dvXF79F4KcmuS8k9Au0tRkJWZ3tZQtYKjx4mEwGQ'
    'yx9SCQqirCYOHsumR1NQ8CAnenOUpEp6c62kN1cRDVe32piI8ySRx9Bx9MQGqxQl2FRRRUJNvCpLWV2clyrFKmg+clkQqlVZVX+g'
    'lWt/7YldVhJeYhLPqmeExxLZXlnkSNKZ3Ovfhg4Xp45hd42nLSRJATRz93jcJ7n7O6HPEB9GeG94nroUtn4RnVcKz8ZGjR7H5311'
    'tJehyYiYObnE8f1EghuGRhm4E4ohHofNt3lx/swuYehslKCCxOYafl5U7g7FSU1jn5rGPnIpVVKcq4DAVpYUWRIqIHKKFTmLbUJF'
    'KspbsK2yn+0ngq+ahq+ahg8vuEoJm2K1yFcrZYHnyyqvSlIKtGq1qIi8WpGVilIuq1mDgfoRsxS9mQtKkZu2YqtaxgwtZOzQdWeZ'
    'hLdSLcoCr8iqrArlSqVaScIrVtRiWZUlVRClSlWpfApcIQMuXvsVQ5s1AmasgOzqrwTEqljkVV4UZEHmK7xUraYAVpWiUpHKUkVS'
    '1Eql/DmIxQzE4UVkMdQZs5KQsStFd5El4BbFSlFRZbEiybIqVQQxjbRVFTBDUsQqgC5U5E/BLWXgJuDEQGcsFELWRAFo5HP/hQg8'
    'CbiFKl+EpS+DFiXyckWuJNUnVa4WYTyiolRF0APFyk5ay7WAxTBmVGkho0vT+zNi4GShWhQqgoqIALpoOYUMvKiCEloRZaEsSaos'
    'Z6lNkPaCjtEPyVePjigCQgxxRpcWMso0uYotaU5Eo6FQVgFquQr/1XIC5ArQmyqiwlwtK6A/q5+DWEhDTC+FiyHO6NKCkmUQeD8b'
    'FbMBHXr0nsfEds8XZRkQtSxKoioBySUGAHykCOSngi7N83JV+uQAGDmRwMPYe8eFwYXJRyR6FmrEw8tIM0Ily7BpPFOSCQploQgD'
    'glWpAu+WxXKSNmGpisDJgZ8oQlkRqtVdOL7NAmdOhiF4ALuHYznASJCvNP7gzTWGv/Y031Dk41L1rSTXao9P49er5rBWrz3W4Bv8'
    'rp2W5OHFy1P77rQr1J9a/OtVq9GGdw0ocHFZI38eF7VaPejZzVV7rJ9cno1en83aBbQH9Ru0SK0+epHuFrV9/kDf1eCF/Ib+WzeP'
    'tR/wxxq/du/e8JOKP06aq+czS0PAzgh4TTv8fk2/m+H3B/pd0i/qPH5q0++rztnVKX56Je2N7Mx3M/P9rX9xReoTIE6XQe+i8xbD'
    'R+bp9vW53GmTWRrij37t4rbWHtYvao2rl+eOMwxL9xSY+tM3AVsa0/kO59mcwHwFcht70nAMl+Grkyes/zCCH4FfTbWXmu9ufdSf'
    'NOLFgJqvE3j/cG3D57tneNSo4mO3F8Nf3z6ekxodT6Nf6y3q89o5/K7VLXz+9Fif1c5vazdDGPTpZe22VlvWTnslcVGH+Wuf1hHZ'
    'Fu0G/D6rP7bP64vFZX3Rv6gv1JuTxfi28ag+NUaNh0az0TobLbqN5aN21mw0z08aL+cjXr9YqoPGsm9enVwaV/WFcbGs0LYf29Be'
    'H9qTL09qsnFWb7QvRrLxff8rJRhu86R2uqg9D09rTzD7IwB92aiX1Mfa+YLQFvQNz1J/bhv1x5eL2vCitKzVjhpIO4tHKPsI8LUv'
    'ayHlNM9GteFtozFsn1+2zpr99tnJUAPEbN6at+LVatxrtK9Or56Gw/7zJX/XGM8ulm3pYYF9AxIhPZ5R2k3+aZxAX2f1Yf8Sy92N'
    '4P2wATA+whzfNqK+61B/SOB8gr7r7eez5fD1fFRfQt/eRVN+eqir9cfnW/6q5c8vSuIQlnLRwPGfNh5rpdq9K5y7zeFSuX5/dxvV'
    '5rT9cnveaJGHi5fmQ1uzzk/ro//Ybx7bL43bS3d69zTxT59PRtbTlfLWdr2aMLy9tNnj2sI0HOFaW9y9nJ78z/9+CK9Pr5pN5/Sx'
    'DTPytAoa4vCu3mpro9F/iE8l7fp6qoxd1312O5Vx86K9OnpYeLPe4EnQnrSpVZm272dy5c3v1R1NeDSFo0nQrnTuH8SJuFrenbxJ'
    '/eVcei23l7zuv/OD55ahNZ27UvtVmlvOm3skPfcFU63b3fHTdDaZrGwQnAer25Xt6s9HweTSXPYGsv1UUyerufbgWYorKrLzNjUn'
    'V6XFyfu94FeuNb036rTfO9L7Q+WybFT593HbqXqXgbCY3rTU907Zvig/X86PHl6nbuvo9V54eL9XH1bQ38zSNKU9dbvzZrvyfstL'
    '4kRxX7y3o6l5Yz20FtKrevU2Us7ebsTmomI9KLfvzQf7wltWW+8BLJt+9t49uWq2OuMX/eHF7nV66tUjf+9WbpzZ7GXiy2pX1bwR'
    'v3y4v1Lct6Pm1cIYuEKpNjuqzJtSi29J4YRP5NehM+HrzrX21r69TH6qudOT80abUvkjYMm/Pb3Cgo60KWBCU+g8N08rL+JDKxjd'
    'zC/d9lS3grt5TzmtCd32tf6wqMw6nZVjvlaOpg/nRn0sG3f3nYHjL0vB9V11+XzRHL0Ed0GjpRtiMDhrXdcerO7NqjJ7HXhzydU7'
    '7dnrw+vN2QQW35R6o+YFMMnlSsFd1Dpy/Prt4PKp2nM1Sa+eGKPW9LRRNhdW6c0Lbu6nV749GQn3SzHoKJ2pNXNL9e5tW2iKLf6o'
    'oQ7UGs8fzeSz+95IeJybrryUltX3N52MdNA6fbhq53On+ujsjhRq33r/Dvyxpes3vBuMO4Y1bZfaws25oPSnT/bljL9RhJuSVRL7'
    'brBsdbrOffPs4a75MDprtx6cnv2qvMAGIdxW5/xYGtYeJovqM9t5ps3raadplNsvF8txx+0tK5Z25D1NrdV7s9Oftfl2vzy5fJtf'
    '96x2m3+HZR3KEgHpQuDfl1d5AJ+d114oS3u5qz8ylobfoZRW48/Oh3dQ4A4LwNf66N/0/Yl4pncvVtrN3Gka0urBgufPfcCzVe+u'
    'MymfulPzxZ7Zw+5NZzUVumf6rfpi2W1+anWuO5eeM9eGd53l/Yt1ffUmdV4fOl35XHiYPHSDxly5s4SXqnh/ceRXG0uhNJiOqxpf'
    'eQjKwuQmuHhw36bjWo1forBXE6R7qXqr39xdl569Sql2citdzfmXqqspgjquXtsPr2erWcmYzjpV5Uiunoh1UZ+9zl5bE+ml1ApW'
    'ckVzyjez8nv54rbypLmtN/FqqVwd3Xv8mzq5R+5xV9NOJcu2r6+Cmnby9ng+ZGwFXsBO1HuEZ/AbX5B9ygFxtxd+CTkQ3aqwAbaB'
    '/fuWqE/kyaAfXFpnyzPPqSrnd1hIOHK1rqnZr9V3q93stJSl1Hofrvrdm/mLZZRep+2JErwaD/2KZ17ORx3xjO+cNeH/vSEMtYVh'
    'vHb9+XKq2C/z99ZF57bZOape8VVPEyutk9mzPDFWnSN+UvJmotIwZrOJ/d5eqG/jnn5ypzU1ZX4xexQQ8tNbviRqyuBNWHbHwnu/'
    '21R947p/5L6s9Kk/KZ9XNNe0BfvIqM2lG0uZG/J0OlcAR8lgq6e+6OmmeaPPJpfum9XoXw7Lk9l0Wu7cIVeMZuhEXrGd+rnuheiO'
    'QyFEAJ/qY8dZvOA/XNS6+VYfLv7j/645i9MTstbXt+fX551Lm+Dl4sUCDvhy7p9RXvg/+ad6c/hIyW6KqH3ebTwh43omjOsKVrJD'
    'GdcE1rdDGBe+b/Tfx7enp4Oqu6rcue1qR+PF0s387sGqdtWWVrm57vqjwYy/tecvy544eHt+UGtX3YbxcLE6uVOhp/vblRH4o05J'
    'V8+FZqlybU1Lzbdu+aIzuJWM1aTa893qSrSXfUF/11onztHzqz17qzg9VzmH+g+3N/adOu+Wzlb3j7asiaXHZWUysLsPAXAvr3Sm'
    'T7vy5KoTdF7fyr3+Uf9Uf+ggkpavZ53x9O1m3LVKXrtdvm89eXz5TDhT2147KC3qAl9Sa2dKaQg98djTtXLfKl+/HZ2Ob92H62pH'
    'fb/yq4/qu1YavVfM0lvzei48zvhe5/nqSDNf1Pnijq/ewCxd1MR7/77j9JQn+2LmVpXRnG+LxpUQaJ3xSj2f2stp0Lmcz7rlia6J'
    'o0XPPtHct/lb5bbnCsh1hPsr4WEhPq5uxt7rtMt3tU5Lqkrzu+Xr7NkTTro3dyuz/Dj32p3LqSGLln3tS7I+m11V3BOyoeDynZWz'
    '67drfb/zPTw7bwxwAF7Iy1vkS316/6KMZO/t2gokT+Kt8v2RoB0FbdtWGrDfzF/PZu+teffautAavSvntvtQPq0vru/8+VXwPFvy'
    '7rOnrI6edMU+7S+Fwer8Zcq/2BVbO1I8wasMmpVT+3oKfyz4/zx1DaHTMYSWfTvXNKl5X3lxB72Hk4cbu1rTvVX3WZhaZ45cOpt6'
    '3SOjIl5B06Wy06+sLtoPN2XP7a8UTz8Bjn7k2LNKp+pOF/3yWAms8sW7sJpN7xs16M6Dv07trp+1R7WXKuCHUBFvhJXQkfnOtXkk'
    'T05eppNJt3Y/lEvTitV/nfZW/GvnxDCD82np7sEs8/NzvdvvWjfeQFpel+bV4KHsqs8P98Ne71x4v10enVfnTaG1rBovIJt29Fml'
    '91TWPHfWvpE67alyU2lVtNPVDcj47/0T2XpvrHqWO3gyb6qdwd19uTU9ulKkptIbXMnSK+guz4KqDcYuP7sKLt4k40ySX1VZXehj'
    'xP+3+kpt3fuusbypnilvS7c7U/nqRXD79nw64AVeaM7bK/nkCnbykxnuB88UR3RgMwwzunRnIPhCd4aPlri419t6W7x/kJa3F89V'
    '60qEhfV6Xdm7KD3ePYyVqvlSfZf677fvF+3TqXjXe+/e9fXl2Wm5Uyk1Ohdu0NYD7eidNzT7uvpY7XV7U+Gl1Gh7mlOx5oJbfR1c'
    'PTTLnnjUXMLSzir96ax7rUwVxTKmoJV1OlarWz6CjTrgX0rnxtwpXd2u9Pr7vDO/7A+tjn1R0m91Yzk9O5q3x8Lgaq71lbnmTWt9'
    'a/x6J11NpUrQGg9rNX+HHTMYlZ9bI2k8fwmOZu/9ljA9e6mcjozZWfO6170W7+bN6p3WCgAxVqVLeXz+ar4eNc2nSuepcv+2qlce'
    'hq+zK1tsz1+MZm/eNiytU2mrfIWvuuNb41oWm+OXQLiZ3RmzZ42vaqbb7koXLbUlLG1ZaYuqIjQt/kpZDTper3p27y7v3JvO4KR0'
    'Xnnovr+BjHh2Zbb4u+HSnd0qnty90+yqW3r1zCN30OoSFlV+DO706077GsRVR7m2NXNy5JfvpqXTQGg+9DsXi8ULmlhUsudOHAFE'
    'Kv+cqZnk1SO+eTsvP1j39/LKAtZ2HYhWd+Z2g2lXvBLtC/VdAD0v6Himr183Ku2jycxRjrR26a50ueh7bbV39lZ98t6E5vulPdRH'
    'q3t9pOovR5P3vmm+N5WLijBqVIT7mvKmzFb9Su9icef3zrv+s1vyBFdtjE5t6HV1K11OV7fTalefCXq181Qq3Y4brXHwKCjV8fLu'
    'bC5rg+dBWTy7XdVqGjW9HWmKcqPfC7p+d21cTxf1am1xU7rt668tRew02/NRs9qrntbn+pMc3JQexZtgOZjfPdnLK+m1Pn/se4Yy'
    'WU3nvm8IzaOrzvSoOZJmvfJ1uTTtuK0FqL8n+upR91szyet4ladKs3l07TbuT2evRqd/xK96Qtd+no5PBvqwMp3DJDoVdcXPrXZJ'
    'aVwfGfLKns2FjtE5KTXkRaMyrimrsnA1dEun2lwY8I45mD6BHOofeWb3TFXGj+UhKXXvTfVBZzFuvc8GamM6c/03oa/x9mQ61RqN'
    'il+TzOpT2Xb850bVLN0edZTxu1Ba+fqD0jl6dR/vxFrPMpyjx5LlDyqdo5fS/MourV5g3w1gK5zUpJf6bAyV+NJK1QdYqXol3Exg'
    '2d688uX8/e68PlsA76m2Xi+8F8EdXHUej3jF9qr3F09zq1+S73VshBcu2tVgIKtPwcN1UBp2XMUC3dz0JV4dNwdm3zm5W9X0t6ZQ'
    'XwbdQbfvqsrDuBuoy2Uw0IEAjq7OWtXWaIGlSr332ydZnHRep4OF9zh/mnYuq9fO1Li+sK+OeAEYb/XuifdOxkalrty+3p/Z5dlZ'
    'JzBfdWUpg/pv3lRO3yfC6lzvlWqXtzN1fPM8dV47nj17cioV4U4bGE5LPplcT6/02+mjEbwMuhd3z43mzbzyMHbs15L5LHZV5fku'
    'eBuIo2exeWu/XY+7vNebzStWS7bf7rxp77JV6Z4Hnauq0HGPXifPhtsHta57MeMHo871fNw7kaYzXSt33h8GyyP3vnpV6WhKRX6e'
    '2krVuwk8+abXHPDteUtw+aOpPmvqrlq5a8rCa3n+1psfOU+jwUlw9vh+c998mQ9eJE9/V++erl/bvear9XB/qc5XrfmT4Xd0Ta3Z'
    'ujEHJHNbZ3O11pUa/MzyzlYV01U6LuDwwDB6NXcqmu9X5euHWo+3e+VB1bkrdzq3rTdPvzZGvUATjPJ5qc13L/W2Wp5MZ2Kv++p2'
    'hd6D0GiJrnik8s7tdXU66RpyR7pS7y/4y75d6cAf4A5PHqwNKC5zbWrLtRdmlK97t7Z9f++Xyiupo95oD5UjWZi1hLuO6L69rK7k'
    'Tvd6PrTf7/U6aEG13sVl2Rv33ufjm15rEbhe5Uhd9KxVud/Vyt3O8/yt7dmLE/eyVmsMP+S1WnkXl6/BGwjNM96Ve/d2+fpVeJve'
    'jK/vV3PlunJ0bVnV93O7fmI+6ncvyiSYrrrq83SiXdtV4NelO7Vn9Kry0Vt34TXb1VK/3z6ZaJd15ao3e65Y9wIoicHDudV98FXF'
    '8bxA6LU7QtuTHe9cf1PfV3f2bKVNefUapPhucP3q1EX5/nU5c6d8s7G61SZeRThrGeXWqyzd93WjcjbztO5idinNK+ZEex2ev9dV'
    '6GlWbgU9z/VaS7ezeDx992vn3+vXO1UC6bqiP8MYpqPBufVcV4fDi5L4+Pvv1CHKHSzQC67w7NsIfaMyRttQ/y1xkT5Rp+7B08GG'
    'cws0sjmMBYwOIYahTMzHmw2cO+Z6K5K1AiOuvqQC9zpR2UNyLAEKxsm6bY54Z2mm7TCsuIiJKsbcEznzAM+7hRvNG8bB1fR0IXab'
    'F3InZKKehEzYE80FMKKXIRvkwjfOD2aDQdJtLcmVYrkiSCqmPK+WpWT0Q7VSLmKse1XmJV6CAru81h+Iax+J3xqJo35h2Bm9b2MU'
    'xxQnDpLS8eCJzx7JZUAGlMhlwHL1h2vSixvBuDb60fyWiv01oxezb1F6njDA7FsiJM//5iez7rAi/rftJ0+j5Dh+FKCfLAAP2X0W'
    'BPD4LF8qym3zs+QpwlSiGz8n4u6MBPAZrr/5hN0+Zw0I1eQfN7hwFt952ICkWcmJjw3Tr5B4yGSOlf3Cb9OknGyYvYloO5WOZr/G'
    'MX9FTsv4OAxshPZo0p/PBPQCK+N8r//7P/1njMd/xnj8Z4zHv0WMR6NRM2prMR4XhKagu0U2xqN/WX98ITEUJ4NSo9bgcZZP4TuM'
    '3789eXys1ykdhHEWF43m5ej2cdh67DTaZ8uh2ZmQmIu209JPOmcdYaw8L/3qxRO/bL/dWletl4n2JL/frZzp09ujdH8SPJxiPEmP'
    '0PLwltJ84k+91q7XFi8n9RLAc+o0AW743jg9AVhJ+VoMT+Ox/fT42jiHuR/dds6WfLPTeoHZ9/uN58u3y/dH62aknnaXfefafCyV'
    'gK4WMP+1k8bjbbN2qtZm57XThTGs/fv9GZwOevNe76J31bP06ep67F6OK0pTOVo2Wsa0+nQ1ndrSWcuvqN33F3f59nB6dj0VV9Jc'
    'rz/5ylnn7t0+6qxcpfH41u0spo3byqrCXzRBzun3JbvREYJS0xDGVvfNqj0bJ6/Pz9OFYGnLM14slyeLy1nJNC/fLF6d2ePbgfRY'
    'ql4OnrpHl8Ph2X3laFYtLZrV69GqyU+uF4oxOOLnDt+ax+V0/qH0dMGDlnp5WX9zhUFVWgD0K2NsuKXqk7rSj5SLUu368WgM+lTj'
    'Hr64p8pTaQmIqt97pdnRyYXY4t+Eh9K0OyEtL05pg7cj7b5dfy0rI+/GfdFmptl9uzq9HYvv5Tbfm6m2c62CNnI0CwDIso0wPi2m'
    'xgPAOBW7Q/9ODqxqMNZXwdnrRYcfT6Z341dv2TJNZ1Y9U59wXtU3tds5P++/toWHq9tK9Vw6afpnrQtPml7Pyl6pMb2eGr12MOye'
    'ef3r+em9eqQpVYcPrmdG731yo/Alp6QNgce1fwwWXd92z8+1yeys1RLu5w/Lp9nrlbcUx512V7TKq1npurZSvOsnpXN+c/NQ84Wz'
    '9k0gjNs942g04Od8S5qqna7T7XbNjujwbmvo3vR1b3UtnFi97q0CerGovqgde1o9egJ1p/1abUedPxhSs9WSTiZDl++8ulfP/luz'
    'IYBiOb20g5t3Sz9qVS3puXMnuWpHmliD02Z75V41m6s7/tloSV71TKrcGNc3vOe6s+bTsg5y05N1cjqullWvrCmjp1lvcnY+USvn'
    '/bk4v+hU/FrtzOy3fwwxTS+n16Y7NVVo7641P38+qleCW1/ojVbj52ZH6PDXs1FnpSiK966500FddG5n87pUqt0EzaNbyT93+euW'
    'Ip31TwannZ5yIr4I7tVArV0dvTq2Nlwp6sXgqNIevF2q79X/n703W3LcSBYF3/UVVHUfJSlmkQBIgmSWSrJcuK/JBVyq67awkQSJ'
    'feGmLrPzNi/zPjNmM89j8x33T86XjHsEAILMlNTn3j5vt2RKAoHYw8O38HA/NDeT5+yLMy7OOqyiCT39sHwu5Zc1tzrrNluObVVP'
    '9lE0rXa2ZZSmhWA1bYLwXNV7o7KznWxHOxYaKjLNaZlznX6jxjOGkT2epPm5L56esfp648UJinOOVXS2pxxWzyxW32+0mw2nbR1P'
    '7aO8t9sv5WljPl+X8wVxW1mu1fG5bLKrinNaLV93nsZaTGm68I/zR7HqKOUx2/Cf6+J4vFrY/W7J0BTnpeselPzhGUfW2ywrQe+F'
    'MxSvWt+ctuPRvty1fUcaqX7fF5j50WDXu85mMp9Z7nrKVIW97S712Y7Nn1YG4PXx878WQz63A6EPA3qqOMf8clLzdhPZkQpD56Uk'
    'bLMno8UWspNWoE4Av+z4oTa4Hj7k1k3InS8Ju+xp017W7eykJlv7ijkDyggb9/Cf6s6wETj8bG23O4HvLETR3E7EVbdTbfiiOXMc'
    'xXHUhm7bomHtxoNGWzuNh/M16wAez66duqFvjWKR2XueB11TvI3qTJWua7Gu+jwQBvoJNy/LFOsbO2ue9m2/XRyXZxOpcdKVsXje'
    'dP3lohGct6e8vZyP2mrz7LBKfdYwdrJpM8z83DxXg/Pj8MC71akqzJ6YDvPMlQvH+W6uMbNCGWC9Wag7amG5bhYVIesMm5J3eKkM'
    'nLzQ1IX1svo426vZIXCr1Wcuj09/kHv4WncL+20epuXV3+PTk2j63OIp2xRWzva86PWX6+LwWB9wpq9U7AL7Uj0vltNZu6zzuxHf'
    'dvY7tiM91YX6aDofTYsdtV0xy4pb9gxDXfLtkZjlOWN+fHrJPz4rnsoqeduuDAqGpQzn091qcJicBuyq23QtZzC3BccpnKy91l4P'
    '5oErKr6gDFbi1nS1TWczldsScHqv4i1jP+qf7L2ctYb6bFjuLPSdJukTtVR9XXW8FTc9NgJgroyRXDFXFXNUARZ+JWfdvD6blDs1'
    'zL3zsqXqPN/xTG7a7rb84Wmx1ev5HV8A/ng8Nm5h6MlSRa7TduePJ4bjhQXvKAHbbbFqdrs8jGq8Pl/t+VrFfmIbeXtW33f2Qrle'
    'mRdqxtnvIALuNMXzwj1q+5eqY8yevWA6WRqVBddyC639NDhpfLc0aSje/KV5MFalzfFZxGO/AIY0EPddLau3A/O5M9+vjqf9TtEn'
    'pS7nbKv8RKqespu+KdUPx0rbzC7kAdfdbIsTgIfeoDV5crMcZ1UZ9aVyLlQNabjXAbImS+4o91bPy7zRfPG14iJbO+cx+2Oc+/hu'
    '5qY9KeYPfr+1BTAaAcGt7zaqppoT+VV96ZQkfm2yx+1hZSxWbe185E5F99TtMEylPnnmRNPYAvLKnqrbnVCv8E3rtbve13xhwxd9'
    'lS2bjKxZu8qwXp+4E0d4VlvLxmTU0zV5Wyz4o/O8fRDqxY7CWrNgWp3Zg/Hs3BmKe2e/kH3H0M9eR5uoi7235B6fVH0Wr55om49Z'
    'xZgNWs1plvXdUTBSzCqr1JT8URibbVXjmWn95OtAQeyAfZoe9pvdxBVL9dHK7SyK7KEg9zrFjdMdya1Ci+8rgIj7NX07X5dgnqvB'
    'XBis+e2uOtt6Z7ucZfjmqOMphjBccUb98YmxVzGv0agun8eT3nnhOa+V+UAXSwN/3x+yXUnvlZubc6PSbz9pjdMsqPRAMpx1HLsx'
    'HHHmkzCalavDxdLRz8Nzy9vt+0KfcQRhmH+s8TyI1PnKjtuLct5RAQ+JjjneBfbiMDWs2dQNbH9a6jqzZ+61U5q5+uM8W2/4gaD7'
    '1bl9VGolZuzyij1cSCDn573+xNlKW1HSR85+fF7qgCJGq8XUn4zKQZOXs0/TMxOUNllzuJ48voxdwXDXnWJ/YlReX18H84I/PjIz'
    '05QN0+87fvXs+wfJn9YPdscfDLzaeZ5/rHdeRf3ZneSbdfc4qpkjZwp7djrb8odHcTt7FOvG0dhvJl3NWHDl80noH/Wlf5hlDUbp'
    'lfp8q8Q51nYmWo7osl1L48W6VBnLgO90tXqWhq8z43zgeV9o6aY+GtjzwXw5z7Ivy2e9M59tT6V2/fw67c31p1LgOI7RnU6ObcmZ'
    'K/nipvA6kwobpdqc7ksjj++3jr61N0ByV56We7VeYJRxXn8J1l5h/1zmB/bqtGHEVw6Q+Q3bIOhlq9svH4Ls1plXrGOj4xW8Y286'
    'yw4KhUJtuFT6zc7uPFM203K/aWkwDG+hVZpdfjKZeyVAtJoReF6/sxcVU53yFYaz9kOB070blsEs8UXhrJ5rh71U6q4W3mtVmzI7'
    '5zxYcvXJnlWdluY6Vc09AHfT2ycH+GrNZF7pj6T5tC9AOyVV6FRqjD0cAv9aOUx7V0NQmLpRLc5XI7abnUrBdtzJS6NVr/4y4J/P'
    'aqW7t3g93xnMZGvYZ92dIM9apYEtKWNePfWUxq7v1yvAgxzck+VJXFap7dknSWInTqmuWGdPFWr8dHRWq9Wu0G2WJiW3OD037YLv'
    'VSr6UF7MWll17UxHnlvj532mMJTcgJ0cRctwGoHSmaoMcLdG9vGRNa3HSsfxLF7oAyZdryfubjfas0bNlaXFwp7OxcCbOtVpV1hV'
    'x2JN3KuzKvAjBltvHsVRYM9Y0c3On/aHkffaf3ZlpjtqOPZ42p9Pu2zAzdpV0S2/PLGBCILKaGp3lfFBrNRV13RMtt6flwRxPspn'
    'jXm5Vsg3j92GbvWr0/xoexTnFeAk6iVzuFtttaJcDIKT2/ArY+lFedn3t8O6f1x5r6x3Wp2mzLi19ybTI3v0By27tezastjZywXZ'
    'LdlcwDI8yxb4ZgsWRtk4Vc8R/ImudU+FrcPvsuWhqrzYDf3EZAGY7OOJ3TZWYlABYX7QHFgX6jbkHgun8WLgS7YgzJWtP1mx7WDC'
    'ibVWUfHr81XXrb9OtwJnAhBlDb6/H5dW7bL6tBhrNtDx7cZuNcq9aU9acG22pYmt1evg1XenpZMrDyuDnto9m8XVtNTUJ/ON92qv'
    'nLNZWJ2rL+zjU7U16F+6sqnMFgvP6Eii/6Q6bX3UgD0BjHRjP2NPEtM7vLDPstUfa5XeuTHRKke18XqeVUzuOJ50+N3eP663giA0'
    'xr1ly1G7c1ltytXZ+aADA2Tk1Yn4rPqzfT27L6mj/syej/PzilYLSrxvbrpC1u1nK8qZlYbPMxAKpGqpbzVttZJfVeqlF8ZUVsiz'
    'vuqFoeBV2uKeXe4L20B1l8UxC2NaAf/3WO0WzHJ+vW+pu7JbzZ9a47LpcGrNn/NeoXweFMXT8LAB0UofzbvCXBxpvHWy5O1iX3eA'
    '7XRLdRAdnfbrU8l09EJ/IRcq23N32gVZueQVF6zb6C+OTl9k+w1/1K+NBlaFd3TbCYYG75gbc5ktt47NNl8fTmsv3fnstWI483l3'
    '+1g9c7oj96cv80ExWC+8Tr7y+DTtT4Lglat19PpMc1z9NeBrUme3Xb2W+itxHDwLk71rmNmGVNxp9dLczm+M015nS0PlsHB1X205'
    's+VQ9Z1Wc+TyM6fMbwVps6saLxJM/ISr6hPPDVZjoatMK1rH6ZafWavNDuddZ1j0hse5vjZeWbW05YqroKJZeX5ynhz2BW+XbXfa'
    'WyW7Oy+bo6wkjmamPatYL836znftti2t5uOOcQT2uad1fVFWK8L+RZsxnVnFb/CeIzOL7vBlcnw9zjht6XdYp+WW2oO8XFKGJWXT'
    'z0/3M2nuCIPiZNvRvGq+Omd7QnW8mdr+YOdVSy/9SuAf93rBkXzFOc0813FGy7Zt11m5espPzVetHYxqo1qheXysLezX5zFI22Kl'
    'Vtwd+9Pi5LgatXYstwZZc/7ULjUGtmiOFL2vuzuxLLIFadwtnGc2Y5wW8onxBy+9RtE7Lo2NKDjBYVmYnZjpi11q7RzHrs+rC82T'
    '2ZNXkHSWEZzhfCJvSjJjrs/rzWPNmw1b84Zw9hVgooGfU7wKyyzP+svrHDZOx3Ya7n6yXOIQLKdru44R5F8PahOmSZirxaLpuzur'
    'rMwWol0Q6quX2Xgw4k5sfT4yDuxpIEwnApDcwJHOg0Jz33h5PUjSUn4saOWlPHebSn/KvHSlZYlDHeO2YPdKZ32hdY410RUm1YVZ'
    'PyltTz+fhkdBktvecTSbT14qfX/nj+edfkWflbZ2bdZf1jbi1mj7Y0dbeTZ0EnZs3355qh/6x9PMZw8Bt/RNv+pYUn3O7s72VLPL'
    'hRo/01Z2rSqUju5UEJhRXegPV62NURZ0STMbak+ejRhXehEtaTg723Jnw2hMdW8X7FapvmwWHGdb4+Zi2w5ETeSldak9dBvPvcOk'
    'bAzX6u6wPy3cfnvKcefT3JbK3iBQGtxAYEfPJe9slHvnKasep5zC7UeHQsP1T41j4PcxJN6xD/xtl5udjkHw3JbrGp+VoHOVR70Y'
    'eAfbWrScp33j0fN6r8W9Xz/sgQaL7kjsrlo7YTIviA7whMt2UD7PRwJbLu1H5dLAOwaL4KlcXg+qni9Ut2uBYbpLXlXNXenUUPsK'
    'UNAm8FvsSO209vbr2e8OntYsCNPn+WDvVRm7bEodZ6Y7vDpqt+xFocOehZGirrO9xuRJKjwZyqDlCUVl6zYGFj+2F8BsviwsX2la'
    'Zr3vzmVH7JaqgzUwH0ZfOhfcpQQ9n1vb0XmWPY+e24PRXG0whlifLG2jLAsna15+7hhOu9twhqNCNeBMs2s1n/jNaekW6ufBtOzM'
    'DgV9xGdtpSBti83xjPOnTr3T2b5u/a6/gt3ZGtnyY9F266XTTJde3DKvLvurpWMbfLcTOLLTnRXERn+gtyxWKQtMe/JUBLyq9O2q'
    'zJTUbsVriPvOoGpm685wvR+27Xpd1xeLKessnZM9P+5HjnoErLc8aQd9E2yZWYOZnhzzadmoFPcgz7I97rloif3FdHjie0LZ22un'
    'wOG3Crs6ss3jYFfr9V76WqMzaO+nR6dleoMz56vH2RDAOpiMpkJ/Krzs6rvdzmttlpI6mUisfl442eXSkUzxiQeOdSPUF07+8Myq'
    'zd1k9NJQADyz/VLemGYru2m9K5QG4lKApbbcbtlzS/26PmGNrH3kFmxzWxiWdkqyyHXxxr7c5QVel+clc8+UVlkv+1zRBgErjPKN'
    'Sv7cWamDxPO481TVq53qOOhWjrwMc1A3D/PdiOUcQN8FM7uclM+MXXG7C5bvDmU+GO3H24YvOlko/AwiYU+cmqYhHFdG01Wy7BZE'
    'hn3rWN16rO/5HX8oOUuvKzBCOegC5zR23GNv/TgXOvqz/vRqu88z2KED2dmZHenEPT5KL6c/1z9phU7Zbour4bh8HreqDXZa73eb'
    '7kFwXv1lUJm59UrWVncu1CjXToLv+NlBp9Oej6ed9lhw+pPVeRwIs2HlrAuwV0tqqzBtLwx1CXz64bFWYUEMPo+Z6qg5fR0PNYMI'
    'qN4cJFRAkR2t+mzZi5VuzGfwZj7VhMmAF59Yd+yuag7fX3VKU87saErHMkytwMvjYD3sbnXbkHVXPnl9wVgGy2y9d/DahXFhUhQ3'
    'Ni+wIOm5IIpaA8kQyjv5KHA7xSqvNXkq1JnednOuz5revMQvtxx/njf0ebU3a3caG1PgWydHXza9geBUB1WuPNG2yrRQf31VBxLv'
    'LXslkNAb9a69Lu/c0poTs8r2CCvAm7ppL2xu0p34s/FTw6qe64IDYpSgIIqZskXjpTT1tuxB0IWaq3O1Q4U99dmC6DafnL33ul40'
    'hBf3tDiNVye0wz8c82V9lK+qU108HnrH+WY4mHQ5VtD7deAMjt2poAxfup2deD76TsNxWiCXAb9lD0aqK07msi1Yz9PevjXpDhY7'
    'q1B8LfWCl45aHr8KPd89zpvt2fF17BtSzRmaKt8VRceXnVag8R0HhADRKBePQaMl7pvTRt+rzczu2PXOzqhtLMxA0sdjQ2ixYmm3'
    '5QBq6gwLxN18UurFztR72hp5wAuz2SnvKf4+K7CV41wsvyzkSdFypFKPd+zOyVvVR1NPMvmytCgMlwVDs5xOSXFH6lDlm8eKG+iK'
    '3Osv6iBq7ixRY/qWeghOYpvvPu4CrbNtwJDLS2aRn2xtez+fus5LZ7MpwRwi6D91zXbNtpeVSnnSbfpSvz9he56hiVXe6xpS1lWr'
    'z9X2LL8bLzqGBdtRllhmfNwHHUWbdgaS5RyAk6lm99MS39LkYbWvDpz67vlprhtLXwtAImBM639Y79vczhi/P2Nktjl7HYEQNDgu'
    'Sgu7YZVczsGp6B5H0+ECRP9KRV5L7GbgGQFXX3S0Mtfmg9VZluogiNpu9gQC/l7U5Ga7xPDCujoVHAenEqTraX76ys6BXDeeeuNJ'
    'd6h6HS5wTCWYScZ02drramF0qqje7hA0AmdUlAfF/OC1XvBmpddSfbH0pbKpyoOeXQTebAbSlCvu5lXWVZWCI5T2unY4r+RX3650'
    'imPl9XAacB3V2DpL224PQDg6o+5anum6KEjH/mFW88vl52DfzW7FPmCoQgD8/OC5qM4K7eBwrL/as8XZqkPvBZwYZdI5euPVeSAC'
    'k1/YzScno1g9l/WXYis/7gtZ8ZVnZ/UBMC1mo6qYTFtpB/bTWBSr2/J4s+jySjLzoFQ9bSq1lY1m/f3VeGEUFstXr169+tCUs6XX'
    '7POQ2QorY2v3Rl7Pmj1nzWSy4SzXsvny3PMb/nzT4bqTydEusJ2so8vcaFgDbk4AnLkp6cpI84pSXxEC4OnG53Kd0/vryXxZ6S7G'
    'nl9VnrT588ThOn3uOJzsHbtoNxTRcuc27ONu0OYO/q66k7Tnghf0rQNzAm7lbLhyxxUXAJXOqaz3he5UFObOTN6Nmb0jMJw1fJmV'
    'qvaoWsObtrBDglLt1Ry2zq3n6sJ2F92jxutOV1jMBmLeWE5nA9WbTISaaNbdekEMgHUaqVWe8Ycbs2s+Bo3S7DybP4MUseQGo/My'
    'WIwqwKaunaHilIY92x+VTbnv1saH6aBSETu6zXe2a8sZ13f1/uToa5q2MLazngh/LJACWlpLPTw1ALL/Z/4NmoF41PZqCain4TgO'
    '7NDHZtsyxMZSNw7zSWAzwM4qZp/d2rNBfsnr6n4/rczrk7HHeXwLUJ7b3zwLnj/aL7tzXvS3c3tkzvbbYkNbisvl/NwUpKxe9rv9'
    'yexY9oOxrbOzsTV3lu6x4pS3gDHGiwPwxlX1/BIU9tnKWAuqU32w6s00zlaypVVhvQieXxozqdHxfWE1PalZda8epuehMxrWj1Nv'
    'rps6u5TrU3GwFnVBNn3GcJt24VQV+5OCO1nI/VmDXch4WcKrNk6GXWSK/WIwd+V9Xagsd6chyCrjoH4W2oDfpCB/rGyVhThvFFYD'
    'du5P1Pypcnh8NruXyzBss9d9FKzjatzhl86UPSwK446zMPKHx+2+sGvVjc1xqesabM05UzH3AIwbp7GaOmpX24jrY7bV7UrdqrTs'
    'rhRR0EeP1cEzMAmsP7emGlteTlS26ewEoWqD4FY6GVVDLGRX8Ec/G03Rm7/218KMUc5iYTY25HLVdQWt2lGZwqs7Mep6Se01hBU/'
    '9XewNBI34CxeGwrtVj1vMEV1vpZsfWMUmoLMivL01NfMQl9zlX5jP7dGIKTC8gW67A8XTnXSr7uObE1KWnl27u4LwJvsH41W86XZ'
    'hy725a3hGMB/8JbTbA+6h/8RKOQHuiYGJ36kdcxXdzcYrDb57ShfaPV6R71pvZxL2Wa238w/NluJT8sR/1jJRu+ibTQNoIwNrrrs'
    'BIo/mu0n1cl4BELBviLmA7vI9v3OdupOpjDzS9dhrakVyIVNi3vOzzWO63DjQodnZaU7GbULIF4c585ooK9qgn0en4WA63U2VdOT'
    '2vyY3Steu3Gem6IJfRKVZ6i+dH4uzPjF8Tw7jk/m4siUWSVr2xbLbGyuKlZnZc0pn1Y9p+JKkzVf16WpdQr2L7syb8mmelTbmtLU'
    'i+bo4Jelccux59nqtNAN8vvVYbAy50F/uuOVl7I/VLP5w8teOfbbJ+MkjPb9udnozVz/bLnqflQsDQ/Znal2+ruptCgaqLZpbWf+'
    'ZFSbOKMX71nbd3lfnXD8tsqV6qw4UzrMxmPYcrX8+NjadG8xhLdtjEfBdrdgy4AZSu6OHU15/XWz6pU77aZcUuTOiO/ule6rzWQH'
    'w8rQajtPjsMsWEEb1QN3oCuvnKhVGGF/Kpy7gVFfcpxT6RuOK7LcyZOqqmLnq8H+1Sw7+rrcVqSV6ipNubsUgJ4PW0bpLBS7LPxX'
    '3E7lk+yX51rQZucTi9MCp13wytMyNwHMb1f2tc2Am3fr6sxoNw/DBV/nB/kZU9H448TnGb5aeJq2RHPqm96ZL1ZLk1e30DCAAy8U'
    'HLVULVTLwZMoN9xF7XheyrNpZzxlzouOr61cZzY6tar77cSdHC2pf2ZgH9SXeXkz3A56ut7b88qsPgPOuzQZFAfm8DV/nK0KrYG6'
    'yWtePnitNkEKTHyQ/d1WDrbLRmc/1dbLweHxaffP7JVsI18QN54C07eX7UC0O7P+/DTgVzVNEZ1Aa4E4Ywnj89N5fOxrjq/ulHlf'
    'ksStv3DG5k4ISoPnvWxowZxTxjVbdrKlyWEhe1Vvq5Y8ZT7d7/TR4GW3HfVr8/MeOc5Webir2tWhoe4mMxC1ucXgleXzjlw+15qb'
    'rl8NXh9fnBcjPG7SkGvqWo5c75cPL4aurZ79eYNl513ZlTX7rLenp06pb2ZHJ945rpasZVvrviBuJu6R6+xki2PE6njbFe39S/e8'
    'UPb1p1W5Oy6o3LhSHrPdvq8BY2czHfI/b+13vfWrfppI+nC4cAuiGYwW4tjSjC3PzEbNlqNOqjPTnhpMVpxXfWZWNMezcl4cWvpW'
    'Vtp+kQUM8Vh9fKy96uu3s3144iy3uQQWef48mk3Z3llU8Zy+XK2NhiAvaO0iOwxaq9LEX/Xry/JQmnWckdCr7NzqQF8wooZ+VEar'
    'V9FhJwYv7QAdF/nhqy5AJ0bN2UA+eq9F01nOFH087QdCgQ/0jeLZNiPBFMh7vaCMW+LicVoDMlA5LSt5h3V0ccZO1dnjo/oyJV47'
    '6kKdHSn11+LjU8A9VU7eaCEBORqzU//gn7qFaneQnyv5VkkRpOpc63ZnA36q8H6/r3RX3bPfn3pcsSCKXTae1+2rbUxKp6W06Q8X'
    'XVuymw5gagfQgeXkvbLYdcwdu3RLbLdxdE+cv6luGHVTYCemujAqNiDLtvz4JDVnfwrUNaFib1+8avEAnCMvaHvDnzrnoWhW6idx'
    'OJ8cRYDxli0Aa1aFLTNYVB3gZvvNPqo2Bvb4RT7ImyLvOLpbaQlyv+u7/sASt0KLq6qHal+Y5B8bjmkCTA9sZijwwrN5ri+Ls1L+'
    'tWTO/I4j2JXqaDbfz4H/fNwNJu1Vr+/6DU6s84oknroTLhjsxeW5nm0V8/PW6mhO1J00YT21M1D4J7SrPyybh/ZTeTJY7I/NJl96'
    'yfYU2+zNi9ttVd7kG8Nx3+a5Yb0xWM/nTklujCrPrypzNrqV0TEbvOa3zWQDW2Yrqv72+Jqo/WW52xutEt+fnY690WrVnb3ybb7Z'
    'yC6eTvWZ6baccr26fBocNavUaRiCIJZUu8yOhgOtvefPkxmrnq0jZ04nlYFXmCqdgPd8/VWsqNZ5394cykPRawj9omOxWz1g3PnR'
    'F/r1kg5CIsAXEMfqlGeYud0WB57UGI387XbBgvwI9EU0gCWVa0BhVkM3KOkyawtL6RyUZwVhP9qOZ8XHx+3udn/VFhXLOJ7nw+de'
    '/QTEUs1yJycLIrAwNwotbTA/d7bC/Niy28dj67jbSVap0VePpw5qtoT6SO10Nq7DsNN1ca+Oys7a1fTOrloar2vFYvEkjC2QkAvP'
    'rFB/3LLC2RlbwlRkV6VmS+PbRb3atrsVu6f4iqXbmmrO9HndLs/r7QHrHNVesyb43cABcrGQYMKY10al6syb5rF3ZoNu5bU8DYZD'
    'bWm6Mizy8VyfV91iw7X6Zz6YPxnbx4Lpj4uVbNtQ/eNKa4r6sVSZ9KqSlq8NFk7eXz0qT8FKOBV7zOK66hG3Pe2OHKy0Ii4MWNbC'
    'wCn6teqLPxn2hBW3Xw/WhSECkdiaDUrD/lb31Zdm4dmSvNO8MzdnrX3T4GyrwFQr+53w8lSsn2blBkBIHsSJp2l/ETB6/cVx5107'
    '4Apd27WAsZ+M1P1EnnTYmsg2fDxmYEa1YmtSHnD6U1k+W/0GcwL+/swKC7W0mpYen5bN8eP/+vcH+ol8fvm3D5Fj6jigeXzlh8Q1'
    'x/AheBPHCvzb6zb5d8rMVCmMB4q+yjHOSxSmTKSxEP/2YeP7tveQz6tm7qDtNFtVNDFnues8vuV7mqn83RBt6JirigoGUAv8lAGp'
    'KUiN7s+IUeiyMLSNRaJwZm57uHFv7i9Rr9myHmB8lANG0sL7SzQ0CtYys1zibDuKrvruza8bf9LsjUPpArpb7xIn3T/QuUg6P+aZ'
    'HMNwZaZcZRiGv/IuXSxWcyWuylUqxTLLsJXiv9DLOvd798BIR99e9xrT2F5iMr4eTvHVLb3u5b5W6G0c5zCMuE1uvWEkD53GpaXx'
    'Si5B64gb3vuUInob6uBcsXxffXtpTPpZxDgZCdfroh9FlFVN5dp1u78BcDAvgVcwAtF//Pv//Wjb+gk7QCMhUl/w//Hv/0+Kxsm7'
    'Sk6RCFqXaFExLJG52r0zVyQ5tbU089Jl80RCUYUheBKDwohXKXLbLaVoKxAnMKDfJcJRLnUz82HAt6hihQQ8o1O7S8FMK7p6FUSR'
    'xA97G1eA3ny8iS38JnpT4jqVRC/gXUJHJYvmUlHcPNINqBpDv550NQp1d13tTSgVmj+ML/ZuzLcbD+jcjQf0FwozJEz1P7e1SlU2'
    'xzOFQhl9MlQqb9yKR3v4n3PcThq+OAHGgVM3wNitD+Qm7GUsN/7RuRv/6C8E6m/HgsHqchxTYgqlaoUrFZIumkslPlctlkpFFn3o'
    'F0vsn4/lD3xM/95YSLdux3IbjO/GazoJaJPEdiz0P1cplIpFtlBmi/yVq2mM6lQscGUOHWkz5X9iHH/kl/l6HARlEM/v5ptB3HhR'
    '5268qE8QhdyuR7lazPFVgJsKwzMVLnIXT8fBV3JMpVgFpM0VuBLL/ek4/uim7vU4SCAI4gkee3U7khtf69yNr3WKl4CKAlKju/eC'
    'ZxJjKxULuQrLVzACGMPy1at9w+C4+XK5UOALTOHPh8atqmqxeDO04qXLN87WuRtn60USY1fcA3JaIcn/IeVtxKtYu3ypmKtyTIUt'
    'sTwHnU2EO+BYNldhSrAEJa4An9h/If38nXvUBQzLA8QtIgqFmCiEwTi8KGBPjAzDUOKJUHaajmFuMf4nCdG7IaHtLqFF7qNr8h7B'
    'yKQLMRMTYeJE6PQ7L2WKhop0jITptuwUoQQE65Iv2htWDjq+wAAqugZE0D29HU4yrg3GM38T0obcfKa9jjpCeKsNWUxyxRqIwl5T'
    'D4TGiS4AJS4xYRQVj8QywbDc3n0cty66NA6jjm+M0+G/0/0xwMk7C/FeHJno3nF62G9kEqSZRj5BTgS4P+QrTil0Tv9HwVwIv5jO'
    'KZZ8TNZ0gN26IfwSGVjEVTYsaw0L/GLJsN6JkIi4rHF8GkklUT83lGvy7hOLjk+UuSZZRLyD/0e9i7jYRBTHSxRaW8cOJIJj4efA'
    'J9FlrpmqZ8s+JSMvurELBhJ2MTGq9wPF/EnwRe4mnAF3E84gjGeF+8j71yCCCOv80xFkuJuQBNxNSIImLMfDDfBnUx6B8v+yLv9x'
    'IA7uxj8Fd+OfohbLPLAL7imI/pAyrH8Vsn3b4fep96XDN2IVdyNWDXTkmQmyTAU2TLFCZAzDU/X/QsB4n1RfYsbecKqFG0619R//'
    '/n8ZwCZjxO4QryXZI67A/B6XdysMlv6UmGEbb4gZIwOYVH/PC0v90i0PZCH0/iGpxLMHkRZOFyRFMQIG+MV9DyIdhhwm4VcPJIA6'
    'ono7IBTHyKUew3jWb/y6YINvnbrcxolWDdsPgwLTKlBuIUGDw/izuRQJZoxNXLl0IXGLw0BnNkaitlY0JHIYFuxa1viOLOIHKqLT'
    'ZfxQuGHXIxBZuZaRZLGsC+d5y2uGkHHDK0e8U1hRDChWgo16h/sOK7uNTVy4qiz2PYOV8eHQvvv2U96TXc32f/7up+hBtkzPT/01'
    '9TnlpT7/HEfgyzkBoC4qeVpu2st8CnN6+zXk/Wv67i+yaO5F7y5zj/RaV8JU8oyJno/+dWgiecZEjBcOa0tT6ctdXHV90J/Ap7uP'
    'Igjn6kfv5PmqcZ96wuXoifKYvNdhee+BXVhbamrauk+NLJBtrftUEze9r8liqq8GwF88upqoQy9E0/voqa62uvv0XT6feopCsZPg'
    'bUiKw4BvNEzbA8ZtRPBDhQVAODpxQTbAgJc1RgsE4VvFeiUdG4F9pq2hcTtwbRSfbehpLhzN8LFbm0xqMKAvdyE1ubtP3YVYmjxS'
    '/EceKVYhj5RhJo90r5JHtlpmZY48llYFRaYZqnKBl0rkUea4Ukm++xrN5mgwmPy93up2cUpDFvYu+jieDEbYtTvKen4MSdTDno2z'
    'tHqNv49by9oYsv2WGoPEw9yneoii4LeLIjj8zrsIuEzq22UNR73Hydua42qhR7W/C7XRuDXoQ7biJwBTWBcpMGzYmJqXSiNaEYkz'
    'KPSPgxu412qMHidQYJwhKjokqzSmqoih8DxgHij/Fgb4/u47dPQDqIF4fflMMGPYTiJiNVFUpDXoFGoVAS9EOCPzHfUTZO6eMdae'
    'h0v4NSwfKVq8O4wZiNXINA9uPPpVBJTqY0DyA/FJhdwRBpzEYYVqxRVMCHy7tNMVAcliO799C9shndOU1MefQ3SKWhwds6UOwB9i'
    '7WYq/VvqeJ86wQa8T21S32B/YWNh7bRB2GLwTBvC0iSQbzwjiQGhxstTwyY0ZDqxjoOrAd4xSXlADfc4e1AcVh75dgIZR1SCpE7k'
    '7w7AAxBUaq3CZOBoIElTnq3A9MPXDY2cDT2A4mPVT8Pux8oDU7HGPkZMxMm+J+FTk+/oAGiCzrii3t+TkO/xSzjQ+F0HfvQFGF3S'
    'RR86hyCKDSG70CRKsjgvJvVRCopr1lygNp9TK1H3VMRkwAPNRNdUlSjx03chOCvqSgx0H9cunUEECmsCxGojepoXxrSCEooaPRNm'
    '+iF1R6M4wsY9uKIN7wYMIDDgXQx8awJElRaARY02zmz0OCSjMQl5gSHlyvcpWg51NxgiEpphcyXAX6vVQ6plgjSlwUDizSnpItkP'
    'cU/RsVlLIaU91ccJhL5FQ0pn7imoP5CVMy0Fe/5bisE/mkIWHLka6H0vDqt5fwUPlDcJWZMUsiU4VMgM+QhH8pBAU9/wPxhu/sfU'
    'x/gfgc9QQKbCMIC4IfqU+6BcHwlqn+AFL6WRBgqq62kgjgJugXU8pdJE+0FQC3T6glpSgEFAOEMOYh8WIcIMdgDnCaaIckDowI30'
    'hLo+wzYk4oXMJ4HnMf9BPEHfEHUpgA1oX4HlCwiSimrHYIJQs6rQRnFDYK8yD0TRAxspBdICZAm1AdFqXZYqXBOYtpAlAvJPJudD'
    '/kPYyAdaF5cCVAkATsIIwrLogRfO48MbRE06Gxan3Dj8K6RiplDX9mqorv4Qpn1IpYEfQ24SuvMh84lMk0k8oCFeTci1aQoRCYCg'
    '9cM/ChcZ0jwyrh9XuiWSPR21/LZw6g5zAgcR8WywHv4ByHQqVLfHtYd1fErZMFRyCEG10yTcaVg91bTRHhD9BdSIYwGxHaOyijrw'
    'U6iQgOFeKVfiRhDfoDrlnirXDpqHeDvUvgAErHyYEETklxnJ5FIjVMHgOMP5AygCSDNUEaERwTquX7ZsDTpKWFgQ9m0b0OQqgEb2'
    'hRD0E9QMdQ3kkAVZcqInsDyC0jdUDXQK2fudaR1ytIliKlImwKBlQDMngNoPhCTAmL0NEQ/RFyLGJEYAjqkHDGMcA9hl9J9IhhCY'
    '4mGsLSKw4X4KR0Q48kt3wiM+nVJF0SPnCRJAnY3bSUmOMvboSMQMbKJlehoVBMkMibH4DURN1GFner+/lUKEBxgTWqzDjOaRrOMD'
    'YGNYD6TtudSP+e9koC8ecJoH1cWvNcDILlB3IJWwm+nbb99CrJtAMZ8Jy84Cjg0RcC6XU+7jrUiZp/vE7kOiDiW4uASZxN/NX7iP'
    'UbqSux0jpl3Ge8HspErgBFChh7gNoQSxG2w1VImFchSTCfVQNBb1SnO9xCkVBaBwJz2kBtIWeKwcTl4NaoElTodJavgK3SO46x//'
    'gC5kcoZop9NfdtD9r0ibQlDBhLGPSrz0DpI/A1fJ3KV+SZF5M/+IvABOfMC6yOzROSzczno8a0WSA6jkKjBJ/GWymUK6kVYy0J6r'
    'InVIUa+OOc1rmb66Vt208ksurCYD/VKiF2gcvtAR/gKYHIjhJ5C/4voNDSDSV9PoQjBDYAJZkz1yF8mW8esn+KitUul96ucr3jmT'
    'Qt+XB0I2ruEwfWfi+12i6E8pNpk/ymb5l+1Bs9PA4qTEdWO/ISUToYMXaP6y/xp2kfQcH6PxfyJnEtj29yQ5QrGw2v7JVnHfJpO/'
    'x5W1CIDc/XP9DNcDa/n0XbTR4r36Oews6oZhp+jaWU0wO6TpdzYHJt/gg4erfsabhiSS53uqog6TyHOCZaM4BLsTAt7vbtzkZN8j'
    'fMIGobUhtEdtRA2kcN9mfm9nv8UA8b4Md91lILkQ32Vihrbb6tf+Pp4sukTw+3JHDuVRwKRnmeSJ6CLugCt/HI0GM5rPBB4GPwIG'
    'xB+Q+F0fH0A632DWWetl0qRZUXODn+ji4BM5y0LRNd4hsg70D60J0joCXyi7IYG+80jE+oeQf7LMjyHDmtqLIJRTi46davvfIcHE'
    'IclUsAohUk/98ENylLnw4MRL6znCE2QyKZk+Qbkw7aowHXWyHOHISTnyRMqRp6tydAqS5chhHilH47tjOfKUgHEZARxGP1KlQNOV'
    'BEFLE5lTJDiDCg7kZAloD0pTKc8UbSDUfgZmQyU0kszYQdX1jwiIQEjpjOVSdcI8ANXHhshJAq3aPBHhkzKwoc4E0C4wEiRMPUmO'
    'j6JUwpAjcY7obygD3yHD4+4Cm7DQoeYOWwKKDEIO8bgreh816MjFJgdXEA/JCL9BJGBszBNBogHGQrnSA5zuXDXiSdxQyFaV3AWa'
    'LmhAoeg21GXh1vwl3jqUGN2je1f6IUGiIl47giRaAfC4KE7tUcbTdYmKqwyRrmJSUUchTE1n9xmEgT1BdkiwLm93SNOye9jVUS2X'
    'FjbqEaqUscb8f/vLF+ZjVfy4+vob/+2veS2Hioa0TBAiCv5pWuTLTj0hIUX26IbqwsgymfAkmWbWUKSlfU1DOVJXiLnfEDsNJg8m'
    'A4r8BPI0PH1vJjC6eYPGoX6Y1UD9lGgNTx4/p97WbOYoKc8kM8shu0Q6pESyZtRajgAG4Qk8wiLgJIapwAVQQRTWB+o+Zog8Sl9O'
    'mfuwzoh7wE79QpcEMoU9iTKFUiosA5QlLxnSDnlM0cKwkGaOiCNkBohIApkuku1DpAz8AnP3b9FLTlfNtb/5Spv6dpl5qBNRAqnx'
    'c1T152TV4UPE7VyKmjmixoSOxDD2BhDDPATt0NyfU1Fisqb4eI60jdoILJFIJWmJbkcrg56+aX8ly0I8jtAQpoafk+2EYcmTjURJ'
    'Ny28MxQ8jiUbK36WyS9uGl007HRP9Dc5EM9NJc5+n/oIjDKfgPUvd7am65RcHQkV03UNBkloE0DU3dcL1oZKUMihVIKIOzgo8pSs'
    'MKabsAkIISQh268rwmjupB58INXgw9XcGGscXP6/XZxN/y2fts31P9Dl9D/W2uofB1WyM5Hz6S/ixzPgiGz+89dsjCFINTnc++FE'
    '4esB+Ekm8b7B90y84WTSNKqboBxui7CK+9ThIa7iPrV5uJQPIZh2PdYefyGf0fv/1wytdUyXJ06nxb69hSN6xH21xclWI+lYWZgh'
    'SkoiDyLif06wESayOmoSv4VbN0SRgPyAImOWcF9iA2Et+EMLEiIAu/gr1v2Jnqsga0J850dHTkaAHUABleqARMQSH3WgVnqUBRU2'
    'KOKuLaTLBDxRGyUia2N/IvqgUCZWPZCKaSNpwDhUSxsqQoB+GpqH8tpFOLs6WUyBlLEhNJKoqshBneX5uWuCYSYoBeUI0mScN6TC'
    'U68Ut7iwytdwQkltKMPYZDlo/z7BW0TtPtEvZPrsrxG6v+B3XJDoKxIVbCy3Eb20jb2Iq4xV1xFWDFHhp5RCLApTdJk/pSRXFXef'
    'QqhK0epERYHqLuAWyyjvjT3nwXSmTSJExI0nSHcSLVPN1YVPpVoGkQCB55PVjCXlW9pL8JMhHtMfWcL4J8Ex7AkKxxT1QRvZFPsW'
    'FH9LEMh/kTI2Au54O+0uzM8bZkN/j9kABooWozL+/zTf8b1OeQ4ybp0oF75epfgWeaefyMpg2vucCD3n+ByxE3ouTLjmJ8LknKva'
    'uiir6fzfvGx+Dcg8dZfJQS4jDXAClEpNw/yyHOBPZD1oO2TsV+uD3XoIuwerZT2Q/pFVT4o7VP5DjkO/cBy/RUsUpl2EQMxMO4+5'
    '6NP1R4IdY/pKsmFKdMJA896uOIBk6wo+/xQ234AvmYFr8L0wtlSUjRcAgCVMuV6BUOb951aAYxIrEIpPFOhwHm7k6XiS6G4KheZ4'
    'uMgtoggQitAsDI9OSRafv6NIJRK/IzR2OfnxctEzQYH0JCnMRc+DvBz+vv0anhB5BJFdyJ+IpmiE97u8JM6RwsL0NAmkcSJ9ItsR'
    'Hyzd4fkQ/lqrVZIN8XJYCGGMPqUSp1FhrZczKS8XPcfwFLKv9xekFKoXiOrtop3B015NCW0McjH2inQlIuGA6MnUNT6Os8d6lZ2m'
    'eHFtUBBgABgnHwWJN/gakEdUTPNGlkVIyLtYPTrhJdaRQKsfgJbGaBsFyyvSGtdJ0O3v1fmubHDpD7G2+SfKfn5TFjt2OXS8mgPa'
    'JSRgrp9Oi/cpiR73iSG3/8svKTGHOPVjKi1d0iRMyyRUMDARg1XaRLIWqgXjLkZUPYNdT/UT8lu07YgKMFQqxxdGUiKtGe07iNof'
    'UCA5xidH8lpo+POOeplezIlsfmBPxWY/4XTANognA4+ok/JPGhIIeKso4JGJS2e+MLAFlMRoFdX2N3S05LAbBflPfzDw394OXclm'
    'YdSxbvJK4+sFkg/rR2jZbyEKRAbwc4psggsDpdGGNZCx8YIV5UXhPZvNJOmujAQX90Eacn3RvgJ5xex24G3SMq5kvBKQjD0Jd5m5'
    'ftFWK5yrGDAuAybIT5S8tAiwAR//LZXmUj/S5GHrUqUCskKYCPOayALFFNR9f7qcORMpLFSSxE1SLKuZaen+gnHh6x4BEKCmJ8pe'
    'Cg+2/uN//z9D+wdqrk5tgug3tAKlJ3FAbcKLLy6e8eAtsRPAmowqJHovKJNL7FcULPPw8w9tuAHeDH5EJR+KSuJeW4u+5eaA3Pio'
    'JUOO4pIK7bqPa6qpiFQaUFMHyB3SMhybf6FV2MO/0QtphGbBaKg9G9Cum0zjjbby/0ZJ23/8b/8v5HybJ6rjYjG1S7RLR/bLpUNp'
    'H4mhTyb0kQpEmoyHG5Glime7IJImrcLDk0UbxMxPaDHni7vwvIcq/6IMXuASmYUcvAGFjGcX6/9Mjc2hS7/+hNZi5Kzs8wdN/pAS'
    'XU38SE1APn9A4vHh559wKck9wA9/0T7+9Tcs++1D/uef8lD2518/fXdjD0BV6ORc+Ac8JIWu4HMiBx7PURwp+6g8i03aZAAMX63p'
    'Kr6l7yL7tdxa9Z+BRYRxpO845TK7RPNbJ+ZqlG4RPMwQFmLlEdO/1OqAhlHIXR+JCV/KPqH1HWEuaH42zs+WaX4+ys9WwvwsZUZo'
    'rrDWUpyrSHNVcFPBWj5vUA0so1GNR82LPngUfX4gXSbiILHNJKiVmDzS0/fQ+CbU0F40OZGleS60m5JfVNUODXbotzghqaLHHnQQ'
    'BVHW/srS59O7lj5vxU5CuSLRgOo83qDaqOIv0TdkqdPvpMJWZRIS0j8plPZBKIwFUqJmwoR4dhBf07EQAdKkyDUhX4YqAKR0CkyT'
    'SoR/lPWJBA88YCpcHlSd44U5MqMR5QvJA4IaVXzDriRn2wFK/weTXpJEiT25Lp/erst/Zm4/x3P7nmwkQY20ekL/7wltiOnjx/BR'
    'Ssz0pTNfkI34mpQb3nyDVQJRV8lE8safdvv7xFKHFfzpSHDZcRwm7X3Yz5Cc94HvCRf8PcIuEaCQbgl7yPPL7w/z+sP1GC+cELU+'
    'jc7ULWKGAiuIJtaHW3YzwWxmKCyZoS02ck6J043EWv0Br0Z5IfP3B/6HrBxdn73maRIR297hOwkX+324VVB1Y95ylCvtOFZ1RBdk'
    'XROMWibqdqI4sm2Z0OCQMnHxFiYT+ox3zYmNjUgMFghdY7mUdSfjF9hMRK2G2+wyr+m3E4vGjnQ93p1dUtkjtkDmNxZgkSxELDKw'
    'NjH75Ismh+cMsFHcHB7E5I7k8Yj7JeKT8ikuIaMCl37La2Hm5PsbXowC1YyejEUD8NC4SL7Mi4GG+5iGy0ZF1cSshBYeuP/IBEVk'
    'IGG+hG24KrBCaPQVGsMpmhtiLaw5BCPb0gg5Qhs5kGdNCrAoqioKYrbEung+artROsFbSy5Wpp8yiRn3DrCR3plx+wZAQ/UdFeuI'
    'ojA6Mk0u2UXlsKbIPir/O4tmXxbNxkX7mMxikyxrzGKTLGvIkljJRFby6AGPK2ZCJle2gLPOZC4isXQaHygCv3DjicGL2HjiXYo5'
    'E+k0CA9u/pPyHWEgxhQY8B4otZ0kWRAMdPGEdCf07kAUELnUDI0LUez/iJc9UmTd7yhXSCxjlbCCNOGv0NAL2iBJRJwTyYVTl1jU'
    'KzQIr7heI5Py6dZMLgG5Hop0uEz6iRo7RywmqZicPlHxn8hAMDIq7qKuIFLLXFQVv8QT9hDNeTyVqOCJJ9NGNZ16RMEhIadclLOk'
    'MRtbC3HejnQBZpbg0bAk0XiFX+Lp3xFkSEkmrgHOHN2FdJzJwdPJQi6VnICjXRadYVwjJBrhGSU57SYnDxFST+BaQHJnlYyM9Bhw'
    '7qX3ZK6imchBrTVR3qTTu/uUFoqEu/hoUPuE5iFJWZZW/Qi4H0rKKt2iCSpuJ6g4blCSC0ki7UCO9sBQr+cookOZ665TqP32HTWB'
    '8Cy82hUjPIAZdbVCbLRXQ6sQtO+MyCtMjavhqf1BM5M2mYSBgaW48M2RzXNiArG6a/xDgI7obNLE3AvtuiK2CI1xZCpsXAAwVgEC'
    '6VWi87b0W24GmFb4+InykU+EF/BjbuEOvTcc72MmkjCJeFwZmk0SLSKhfeSEldzpXQe66JLxX1dEvFrQZugcpJFbZyIRkGpdsG7K'
    'wd7DEMNPEWcbMazke4baRJOPEW9DYhoTzpW2gwbaAQDDKWm1CYKtSm17EZpxpj/hlQ8aepo05YY8tKt+pAxxhHCwdlEKPUVcloai'
    'UZhkFLhglr9PLlTMm10YpZhLgzVkE1rpqBIOK8El/SWVJpX/DEn4DFiVywD9pqnk5SFF1M5EoricmKjuNWIXAeDSEpQAtP4jiuVJ'
    'djuh9fslljvRWCWSCrG6NFuCFSlmqHyYONgmH0G4LGawajYSHK/LoAhJUqr3qUqo7g/t5ryIDtLqpBykhKyGbR3SbA4roYfnFFwT'
    'RHV1iA/1k0cMIBMTa4o4nei44UORfEiwpUiZoJKHcLZpQUy6tHFzzI59SF+Ea3Jmj1prcoaf7FryVD1RiCFadHI+n5DSyaEj9oCe'
    '2GOF9Mg+USOa98Dc5LF/XvKQIUVMCWVYGQ9XB/AosWB4SH3/fWTgcB9Z32NvAChETyXj9Kjm3Ied8HANBwibdA1hCXO4ht7hJkto'
    'tUJycTlYWS48m8D1D6cNdcfEiAHy86mH65W2j7DSuxA83ilQelPgRApQzf7FoJUoYm74Nbx5FmJRnCtUxwCtIQqCX//6Wzey8oAZ'
    'D5/IpN99w2+rw7cU+fW+QRf/+hveDfz266fk8dQMt1c3d1lTjkfQiVIQNLgCppBjoR8xL1m7bg7nnqTgnZovVygbT0AoYkgse3gS'
    'k4rtMb4PDY1+SX35Cg1goQmqj8JkKI4GSNjHZC2b623WpduMzXGV5LnYITQ48ELdLzSSPIOjn5DD0BGrkEkNZ590gQA6OR2LjAsf'
    'KGkhyuUDvbylbYiW+buEmclFLY0jfcd8g9Tbu/uayicOySI7kNAGBPgE0kRilJG1yY8pD79u3vu6Cb9eTh/XIiJPqOuHH24noxIN'
    'KNQvY40aUnMsk73O/SNMejT2uF+yqunpeAg+blb4/wJIMM5u7p2tgKBUJPqlLt02sNdS2Lq8oWm4M7hoUi/1oblpWN/3cX2ZS3+w'
    'F9ABtsRkQhZghHMDPC65TSADQx5fRKK+m7zwtiIRp1Ali0CXNizPDzkveiHIQ95Q1EPwJeYliCIJ1aYN4ZEgvcQRskzAlmh6yFNG'
    'fqKoype0oSWsGnqAY5LGnqHAcKHJPRgg0I3T5g8AGqYOROH7y8nDR5oCExqtaYYIMrB5PqZwx2TI54cL9F5V/e5cv0mNrLuuTRJG'
    'uJRkzCOQiwIv/RtFiA9R4fuUQtALrDrZQnjATniszzhI6CTt+sfUCD64FrkCmR6hAAnI5kfyhWT/MQQT2n+SFPKGpBCxw7qFjgvk'
    'AoKgqgFaNZEyHWDnsWwmk8kkrJIm4toLrYT/4uOzRhc7NKDyNJ9CBZosoxGE5uO5OOUt6Q2vaOVzsY7zlPJkUU9c5I85cQqF9OqO'
    'v0EdixOIrh+CK9VCEOs74Bklbb2OfYd5KbzWGSZhPy8wRHr9mfyEihZq5kuTLif/SBz9Cx+Dk8ay9+9gWyZXLpKti0uFZE9UrjGS'
    'HyJltvSWaPHAm/z1N//3aJK8AajCi/TYRYKi/dDu3ydmc5c1fIO17/5yB6vqR0gbnrFj3zKxkoMMNwTyn8MWYjs1bJce/ZG7rtEN'
    'WAnPsH/NQo8ThT9eFf7265/17M/Kv+ny9XzMCH7E/oHQHsBipb3AuE/JVNcRoFMUGQkIE2vHcO1gRWmhuFE2E3GkyWVigCv6lASW'
    'ZtzcNa65Xlu+RKjiPZZoEEpzVQY2ovxuSSZXKmWSuCdZjJwTpLKfo0qzpD+fQmLw5/ifztaFuKC4cEWHCJtLyRDLA2SkVOSo360m'
    'c7mAc1XFLeK7pokHyo1wUHpz9WFDPhRKV+bZu99B65uTbflpRFMUj/eItHQI91v6tInTCLq8MCi0vzsAb5bosd/0bfdux3aZyzFM'
    '0sr8Y5rQ5avVyNwoXslVsG54Kxt+AK8jP3CgGB45A/w11gti6A0fT9TiO/uHHAclaf7m4e0nypwTsAmXiuAtAolN8ncRtfC292RC'
    'v4Wa3wYgWOVEXGUR/pM6OgGm2NaOeGuS7GRqihqdiKPjrWuUjYgtk4MJNUFEx4M6yipE9y8S2pCYxfXJVWjC2iZY/dCU4StKN358'
    'JP0GmUQILvXTZ1LFzamVLbpixM/kPBvoUfrub9SyMj7UCU1yIyu7RGkyFVAaawlL51PZfCZh1BzL+KSWX+hPFtll+EvKP5CfpCUz'
    'Dgg6TgxDaNv+p8thU2xhGrEiCTuMhMFxKiqbrD088iBcU4zaqfaCNErKJ24/hRczST/xoCIy7L0s6QM9lwRiG1+2jWxKkq18jM7D'
    'Er3Q3rZ9Ia9aBlV5Hz9eSl0N8irjp1TCajr8osXT8C1h7P12or5dtiaarcSKctWTIwc13sUq4ssPP/384StaRcghnb374Q4kyB9E'
    'w/6Elm4/kTfdJy8/k5c1fflAXtBR8ae71Lcv8tdMrBB216iQIfdufo5lIrzgCHDlqS3TR9PMcFxoFQi4OD4q+7JP/QzTyN+nyEMl'
    '9UOKK5XwjTx8JXYxiVugR6zrHtkDn/i2SG4pPJyAvmAOaEUK38J8sM9Q7Il11JRKiV+0r0TLhL8fU/hKdE3JE4pfsZa//rZKM5lv'
    '9/jLhr9c5lvm1xC5PAKPhpfVkT/SAcxilwUodlBTEKKIAGK01vbXJiIAPaq+QtUhUSmiggKdw6l6ApvQhHDwlwuwX6BBWE3pa2Lo'
    'hI/a40D3iP9KpQTBN45J4hcWRkNNM07XzEQ6sTCEQlnIkaFYWkH2z8CTHMOMJMUNFZI9kWgDFbRCVZBesfFZEAgqyIHrhDG54ggU'
    'JUPKY9eA4rqoM0yvqTlVPoVf/40oYcLva/yOSkGXfias/UMq7eLRUpxUTKjCONwI0LMfaX+YHFciSwyjw086rj8wuSX4pt8oGnEP'
    'vTMILhwFyOAwIfS62Y83GYHS/huh5lyGPJASMNHYIr7JEWENrcJdYL7X8L/E4lp++SLfo6caBujDF/iVw0eGPB7DR/wQZmDCR5k8'
    'Hr9+/ZKmEvtKtyw3vSGziBwjT56+JuCbctLJDlwgKLFVYuhg76/Yzj0CB5kMBLWcb4X3z2GX54C/HeO11jRM0x0DZCmHHp7Td3fR'
    'aWydnqcRL4won4eGHuSY37AswLzEXQk5L40NQe7Dc1glFZ6o/v5hdQ4FMHpFk2w1RbWJioDc6wy9MSgaemeX1cjMC0CF1v9wfRSA'
    'UlRk1BX41MrEC08AQm/Q2NIq9tR9s5tREUBKwIRs1LhQjvo5v4/PD6k/DyJSiqSwZvoJEzTRIAOK5oUIh8Q5RXiJwhB9YISoCSBJ'
    'N1TVz5FDjz5IrRr1Kq9SexlkBoh3l8j5EkykB6NX0xlq2hQVo6ZN2OhYdajBZXxYQZYHDYxhHk8gBmtOoKZE2bW82JlpWHs442gt'
    'h3aIgSGZoobHMpaVSZyWQZuTa8XoKmGPdGWfEd0rxLTLXQz4EHb8C6nMssMDjAjpfL9CpdUq5+KehR+GXviP7DfCc4nkEfU7kJ9O'
    'cO/0+HuVk4+o2jvR51MmrJ0w74nWMploA0ziQ6ToCI4qjyIfa+EZkYnrhtfeid4Idge67SLe/ELTdnRgBBtoE0i5m4kkY79YuXyv'
    'ec1ASiesAjJ/YshysTLYQH2R0cyFM4yWKy51rW+PL36GJCxMQDJ2MZPRzN3AfMtEvEfe4mYAkVergHZcQEAgZ1bK8LwmzyyLGgsJ'
    '+TOeHF38heXZMisRbflfVuTf3afQODB0Mhw7uLOpEseAjSmnMylREW3fi3FThAHS1MmR6H6UdLzE/MEFbPUh+kodI1FfuJpJfOGm'
    'DEtRY6PaSbPWq0XeTUg+PLaS1on+ISdho3+9RApME75zSoEtVO6IbzHyXuILqnRHfX5hgiKpZVIAlww9X+VYjt4xwK+8VOYqTHhX'
    'QX6gvKCMjhnwslMan9AAjCgckOOChFy5AjObYypIH+8vXUJTN1W1w1LJEiQXQ/6B8EwuO+A0XIbJFtkSW0kOk11xHFe+DFMtqiW1'
    'ehkmr4qVlZoYJqsWRF5NDrNYugxTrIgrSbwdJoHNC6ZA4JBXSkFlEDj+ZBJ4pOc5NpqDEKj+ZA6imcI5CD2qibY9QQhLmtpGD6Gx'
    'bQ6vr3qAuH2aEXUROH/kPgt9gDESyKFuGp+p7tklitikbz6kXJSyoEMi0Y1NSg6Ryzt4JZ/xchDxshffEUjodlPIesHQ1r+n6F+/'
    'o3lJrxNHSyzyaeVMdDyGCBUPMghTuc5pqA7hOFIRVXOQYTUBBwLBTKXRbV+GYMHAJxr0xPhE2UdpPBzmPb0dio4GQ90/8etHFTkX'
    'r99Ye9pU19RS63OomM+E5JhI9HiQoB5FtLaKCSr0gFA2yHJW3aTZW9j8i4ZW8YQ5OyVJGNpSoZc/asQAMHNM3h9A6kHv3eNFoUv6'
    'iaSfYq3m+n3lVGQWl6BIUH8e80d6JKiXvEc6pKSGkK7FAddhk7lmTN1bHf8a6nKIlTi15oq0VoCqHey6Qu29okMJ95aQ0t7FdNRB'
    '5jWTIKzOCRMuyk3o2lVm55Qhys+PWDU1awwkTU49/ff/76zBDgi9S4pe6gtxqXJPVA+upaN9afQIIAd84NcI0JOmB9EeThNHjWLu'
    'SORDQt5FtG4jm/+EX070y4l8OZEvRJt7MTNVz49+ehhLbBcxlRw/D78gTz/8wn69J+KIdPnAkg9c+EG+fODIhwL5kJhZ8pX8iYZw'
    'T9MkIjDgq5+5On8m6p4n9fxf272LGdBN59Qo6dJBI0pCi7Kb8X35QnsDFcBXAyUdg+SSaXtfv15UH14gwbhwOXFoqLOmWDwe8dXQ'
    'mQwdIOEAEWX5yKT5lGWLHtFeBdqndmiyaJoXoSU0SNtH4gMyROTBOojok98nRq/3If5YRcxeePf8Z1QIpEl0GlddAfZQkhZpBNGg'
    'LAUdXdHbsHgL9iL+YzSAsMFYMRipr1hyJepzqlgJ70IlT+7ibmbReQZypfCCEKzBsKFErFxepRNAnCH9vWgHiXbRQkUP9AM9lRJV'
    'X3RnM+rMjooLO5xg6MuO9CXSR5BbzWmoJAvFKeq5bdcgZoC0ZdIEJISqfNI4eY2UiiG8bLSkj4RwmvwbhZlvxcob5BmQkLhy7A8R'
    'Qw9RORDDKVgHdJsLBILIWEAxf4WkX1P//f+gbmapljDtaWsT3fvsQtsrQlAS+MA6EP+44T6A1ytjOUSqMaIJCUGMXnA/x0qaCMNj'
    'pkxoOm+RS2qhDe3aTJPaf7xBokhSwg86umYuckxSOxS5p01TtCchvqMHtIR6YA9+xIYIAkxTDCgh6qO4npCcOBM1mIo2sHgfowAA'
    'Yg4yFhI4KpEkfb1aFST51Hevru3UhEQeXfsVzdT4I92BRHYP/aoTB6KuS3Rtl51KNAWxOTZhATyU44mQ7FFROLIMx7NYFLZCZ6Rm'
    'itwQxpgSke12LHwRawMNkRgAfZR6H4kS2Mwlrgh1pUmtZ3KpVuhc3Q1M9CC80UhTb0JMRQoSMiPR6QRR6iqp9K946cz89QHbCXsW'
    'j9jI3JNraa4W6hzHiUBU6HSV8EphgCwAfzSdJIzhKnBJHqKMCJ9R/YyN/Cr6v+K6bELmjLaGzaDc8wDCqb6CuknPUUZSqQ0uuruC'
    'ecKja5QFU2jRSu6nJi3ZkxuE6hDuU0StCCIe3S2IHuiXBB7BvfMerRb9T0kQJNBtHGMC/u06SaJJ0tekZY1xInW/pfbv1U12LtRk'
    'XOqWrpIoeMfjJS6x0el22r5PRSa35HRrR7Y7HhCFpwPEA9tLrf447U7GxFHELdkmzdlhc3Y4lijdDNNNmo6GLElGMzFrP18lRwO+'
    'oAnq3NW7td39ndv3X76ImkGjWqVvECDyfXTY5DwDdZxfCcJ+gFJXkIC9zYQ60KsP34dfCl+/3hyNSdRE4wuTw+uAH+kPkyuQ5wI+'
    'lshjCR8r5LGCVoOASj/C36+ZaJz0xOX3R4H49GYcfMS9JvAty1DXL+SeFar/It/ZnoyG7Z9j79O3/kKGyLZ6/lfqopZ0KXm8t6HH'
    'h8w92WqRldoNM8DR+9EF5ooXiBYUFXoxuUUOoMBmrsh4uO6kBwRALzW8EW+sSM92OeWLp8IhQGYhkP2UEB1YYsqTyHUiuU401+Yq'
    'V1LKArbKQah2aNYKvXjoe3j57MadTfQL2IuG9PJorKPLTSC0KtJFm5rxwFQCPcdAfJRvMy3JAozrqWHEjocrZ0P0Ymfuak7ptawa'
    '8biT7LN93WceqfeN5Hj1PXmw+v2lUpgJgiLotQA/1tXj/Plklh06y2zxam59Mrdh5SyaPyPUwIQl2KWQjUa2ngAXMZBmYAUIgP2I'
    'blvwtB1gMlQCA/FKcMQR+aLRFcltAoxZebBcT6XHr0AJz8m5j7lNaPMnuh9wKaON4cmfoh0zvFguhJgXP4QMQ7qeoL6hA57oVm/s'
    'bRBpXC6TegzJOT3vJ1Qz0s9HZDdmAEJNv6qsVUDwmhFZ+BPSFpcOFbexUgLYUkUntJ/qXshFM8JP0qADYujEyjLV6FYAmTESa47O'
    'DsHRIXhS95LEjJ+KDvFAyc0BvEBEO3ofeuNWE2cGWA/hMLRoMO7FYJKckcS8FmEEEucvyBKHxpSij814wHoC0lPDu+zhkUSK0HvC'
    'KMHQAzykCS/iEAqXkokXrrR4tT4qOTG4DCXJK1/Q7fAKuSZJnk+3Fzk2D92IErWIqdwRt0Y36cSxKnIT5EzqnYLUBevvFo0PD2jD'
    'ePIf1hUrYIaJc0ebkm28unofyleo2v7uHZwJWaLrFZFdOCShsSxwUpjpPa1PqHe7OpFAnPox1uKESDw23QEugLr4w94gksF2EVdg'
    'M9FblrxRB5CYcgr9HCWtxpAhCmfxFzpQwr7QyxdveRBfIgVw0qLs6Is6zn7FmoQWvZHiLwahMG5IqFsXkXclAB4DVLh9YfWpE3WE'
    'XPTjSm/95GLSayrXlxhRf0CwIqovUNAiCcco4fZCYyI7c5ud+RpebnzbSny5ET8l7zeS9wR3hab210V9yoT5RAr06Yr5YtgSLRRE'
    'XN6lWqwmmwpbOz2kLh1IfMHV2b9f9uPvlv0YlQ2XKrpSS3Z0GHMv9StIWb9ezLAjjzZ+6leQHSINaoRWL+ar+BZvGp8EFklsm1jh'
    'wITahnRy+/wCwA87iFxeyN5+2hAxmWEy73BHzC13lJCHb3QTSVJN+0iWA7qZQxtE1M+QxcIEtG43MsT16y+hqgIgnqowIs4kuTev'
    'q9poZOqvq4PCt7tRvd6NOIG4Gf1IIvm4D3cXPMD2Ih5O4Jua3JOkEEZqggEFJId0fYUnoXVQKQCqRNJRKWiqIlUCFJJXHQhr/Q6Y'
    'RyKTGvVQpYLbngx7R/qqUnlrTwa9i0WpsO0gmZP2ILjkVKWEMvBKaKKhbVxVRbxD7ow9pGK3o2GMmMgtN7G6e4hdbmPF9GDpUjL2'
    '7/1nRS++fYhD67/XH58ngxHtDZD6B2Imex/6XCaxZYh7bwxNw1/KBiYJRBSehCROSfXrBaLfEdo/XYEXUc6QOSO6HAzZ8C10dYNz'
    'Qrdv6CAbo0cgASeXjKnKElUIykNCuxE6noqUL7+nZEkaMWG4zIvoRGl55CHpnxElE0okCe2lEkokmnRRIuH1uKSU9s8Lusmj+ZuJ'
    'CbGYeRff4oeJMm8mJaGQQl1UdMpGlFHXemOcKKociuYKhJNdiErxanGoHBr/gXoolSYR/FapX03v1z9Q9mA7t/oey4wiidDT/mtV'
    'Tbi+pPRD8riNusbxMNaUSjy2EnYReUxrRZyU+0THQxeR2tPomiFRpU/MOLu0eUldkXvd0AFqf3J/5YJVDqjnIgxxEKw3YdASaGSw'
    'uqjew1bIkR1MuXt/7YkphN8rgY0Yp5DYRDBzHmBzEGp/Da/GRAo2sjRE9XhlfRPbFt36E6HgBgNAvzVhnUSF8wcuGe7/k4qb2Gru'
    'z7ZL5j3N659tmgvS/0+rh+7Daf6cequ4idQeZHEih7Q3Wo6Lro8oOr58wZJES4M6n++v3qKXSvKFu8pXuXrjvn69Pv/AuGChhRJO'
    'Gxkt8PP/P3fvthzHlWUJvusrXCz1IJwIBAHwksoAQRhFSSl1UhQrySp1DhJd8LgAcCFuDA8QiGTCLB/nYZ7G2mbmecasHuZpvmE+'
    'Jb9k9lp7n5u7B0ipsrrbOrtLRLgfP/ezz76uXajrijQj1EbH09+kkowAWPVgQlAhYhE44Tq6DuUG2xMqs/8joc8IxMJP/xEccZ5K'
    'EplN2dHRoT6IBF99Ay8m9NNolqIqB6qleCYuaAi9G3jQ5VIkv+fhVNuh1MON8yv7vVzaKWYbztWMXm5OJaxvV5kHSZm2n4uq49RW'
    'sf87kK5+KBZInDZYv/aAxe5pG0YTquFsGooJ5tp9iyPhz5ZsgF6v51+dR694PUK1Ojtp5AIgosVlxV3oPk43j0FglWCOlT4w3SFL'
    'XFZ1FMnoZi4cRkqX+mQip3jpQosMQpGBL5I3PPc5E5eRAvy1R6BKqBC7l5NttbnB6F4DoYkQIVRtvs4bWhXzJYd71JyWMNsG0SW4'
    'yOwozOE7qbsRsQRHWeetuiNOMgrUckfK3GOzJKq1XuTxVz8GbW4TC3WbuKY47DSHyKx5wScX/kkgYgtqRn8f80ou7KIVP/Iw239U'
    'EwGCavT3qhrdf5QftCk1iXzzLKMEUtNkcpWfZRdRoMO7PMK9VLzJ0O3nsKiuKlmXbvaV/f2PsLMPr4OTgsaDpcaOzjCYJ3Zqxgp5'
    '50puMBVnz1uwM1HkZy3ysxT5yhf5uW5Sxj32/LiEX8mJ3l7y60S9A746/tmej/TXSaCKMqowpPtZ+DlS0QmxZfJsSMt/4YrozwGL'
    'eJrpch9EG9lyT9pWHlemRHhtQZ5+L4PhNeYuB7cVmK11lrBbpEBHsY9Hg/ZHu/dmN/arVwWB0xjIit7sxe74jdfr5tdO34ALd938'
    'Orx2d66egZYbd+6IaatGKtLiM+SW9+KCymr17iSO+Hk7HF56Rp/Uj+iTqF5KfteyijcMI59zkyLTws2e/oYYeCHv17vu906GqJ/1'
    'Xr1tjBQX5fPlslgTMrzzwSzzyPYMnqrzLw6vJzV37Od3qQX27UAoAtv597Ov5jcdaY3bm//COiF/W+/1j239g/3tuoHkv2ivKn6L'
    'qbfkjzE8u4OENgRHXcWsMXBvZCZ7vZs97J5eb70n5PjFpFwsxrS9aiZPcDsIbJZGYyrsx1ZolAECCVhPl7Nd81QY1jwVPO1xO2+1'
    'q4qa1Z6DE0yu2W72zji9nREvRFR3Qwsfft/sae34vTNauxtzrQXW3P1sLrB2WJ+FMnAOMO9dQh90ghuhaMHR7Z1shsVBVBm/Xu3G'
    '5wweRUsXS7rai0/oao+val4mu7hYVnu2sD/OWgTKhP5Qc/7mn39nKaAgegWGruNEyzZHA+dlQDW9CgfqksDQ81MIlad40XW2hk5d'
    'cIXO1LStBnsXEz/k3vyG6MCwFIg0P5upH6Xh4q3m3sKhXhUWknBBNKLUWyJytTBplO6nmqeK2ZsjnwyaN5wTK7UIYUroqgmZzr7v'
    'G+PKOA+IhAarGsLzHTuMZF1FgqMHpuil02arwcEyPSj8TBcG2ISN/aAT6TMf6+I4064aS82Mf1WGYhdU5Wypb7Mm1w7Jk8eTF5aw'
    '4JDtRVIZuBGoYO8nmqRjmiuodoKP3H8Ds8iv8UFwdOJ1hEtxmZOT1VmUBje5Rzi3CB42nsTksxonfHwSx7zLNnmuo7xEWTdu+TPw'
    'mUcNL+cuP/wq+RDz7D6bbfpMgVn40VH2EOA6UV92mbEJHTpKvP3e4Y7aaDbeQaUM9NrLU2wX0iPt6EcqnLVUuNdVXK49j6GgDpAg'
    'g73dEB+ztRXldnenaTW/QuiWg5xHJmc5TbbGL6AXoF9m5JQZ52wjqMQT8gKInP/Sm74eiizunu6ZweG1mmtjj6zOqlzQLosYo9/n'
    'kZJtQlcjuzyJ2TEjdSHyJ7y7SIihwmJtO8oxaEO0GJsFQxqAinYV1E4iNAdkT7MJq/xdLhDDBsJNghd5p2kGbFpItYlqpeBtPi6Z'
    '/VvPr8yrfUKvAyd6m9EaGFFCUC/H1wD098ePYxYJ4fcaIDtvGBwxSZE8A/VTIuD4HSN/L2vC61LtTiXP9lItUqUJsFgC12ZqdITS'
    'usOP1CWB6e/s5++PZWrvZw/J9LIudU1wZdZJGWVpIzHJefcfcvGDqeiYv9SiYi15mwq2SmRNodlz3fet+Rcotx0+w1a0fB2b693+'
    'xHp3avWetJnR9O4rIrtZkVVy4eKmno1rSEPhGGB7ra5k09Zvu6xzfVG6PeddKjVnBUTLC0sKXdr1jLxaCzCKIwfpU018kmjfnHpU'
    'hKOGnhMQ6TNL6zRRIBu06DUEoVNh6/Llj2fe8jemjrq5gZdjlHlxDP00dkWNa0copzLu/Avez+7v7UNE4jZxDfgyopUvjFZGO18F'
    'fGna6KX94M7H51F3+zQ/Ry47tknNm/mFnjnOGH/oiekxSrLToNGcikClnwkJfBxJELHPjj2z1r2amHdUHpPfFxorrPONW4BEPw8f'
    'mEND+okr726dboL2JttcWY4X6vpfLhwr8YJe+7Lf9b0f+J46/8kLV9K/2nV1K+brIuysn68YKUjxheyj34jGb2pGVafjX8zpLxyE'
    'I5zGj83LR7eBjjXsBPvtyaAiJj3+1Hn9lPb4ZdKiPmm22bI2mPbTH7748ILKBQAX8K/1bfYCf+75h3t8iL/2/bN9/+yhfwZSHGM4'
    'wQrqsSs0B7AGq9E4KkfrFLevrMUOHgGpd31474sPuNEf9vZRO/7c7z26vXea9Zv1aOrkDfWALanXsBVzpNgh3yl34W8Jpzw7fbqA'
    'KnJ0eE/mhyQdIyTNvs1e2qO7bw//wd2Xx+bqtj+tuvTOuP2f7zFAHPM4vL1n85L+2qE4cHhvzz/AzCL8/vAeJbt7D57Fq8g0T+90'
    'Woblcoh89jeoUrahVDpc699r+Xvp1m+vt8942y9vo/5AdLll5VEOagRXqNw2RhI9AGJVQdArVqsCMOrBd+q6bUf5nXBt6ErAnrFW'
    '5KVmudZoWsdQyaUJ875JchYpj9zHev/J/Vo6HDXjVFVB7KWyo2iXfPFh5AcKU3888U5oa8w/Zmo7++1tsgzDYuFWQSS8YliuZHp7'
    'DzFrfgOjI3JpfVrzww1tV9cbG5bq5Bzd2i6w1pxDiD83HaVvjoabNJzrQYVEIxNvZfJ614NTSlLdG43Kc7R/Y5VGMF2loKJXZf5L'
    '5mUlYmClFp/m1ATYu0ewKsC/OJd6vvggsvmt+ngc3hPOvZov+/TwHC/dkWkYSSxUBXyTAVHYNVUIbzIZ+YQxfqd7eAh7qzyaSgjz'
    '2YqpysoYTcrySMgVrMjkzeQPjJLSJJFEd3eZH6yzGiSFzn6FpOhVrC8yTRN0gtfzJVPlzJejclasgGZ/VR4qFHEEXIPki5Y23EHd'
    'xEEcRJC4KruZRS/7iOdYdfJWnmsc/DGLmfXZp8iJF93lwcAziNv1rOKQAmyKNlsNg5wODyyPv8viEcxFq4kdBfLWWu9IFqN5VxT/'
    'IAk735xFJkA2UAJLsqpERc+sKBAu1HUUmu8PQrL7SJwhZ2rd12Qay91+0764DPbFJU0Jy71+tuvyEROoItJ44nc3a4BdsBKftiOB'
    '0SRmCXAidMvAX0aREahnpJO1Q1VxACIHqqQsCOvcNaYPwvM9ROTr+Y5RlWIsc9QRcq1SEBgT2jJmBRRHRdgA+LnNZ05J1xAxeIkc'
    'WpGAY2HoAQYj8LaHXjHGf57kSPbYJSHNjgvRBa7z297QZ0XP71r7xgJ3mbONOND4ffuXLz5YRfgTvVCmzFwNOCVINXtSF3pIIsJr'
    'VImGvvhg4C7b264incpKePAqwo9rjew8zJ5YZKcWJ4GuNEHamRwiENwOcVa2UyAUOu09ACrRA+47XlfzxQ5Hhq/8tNXhQ/SzPL91'
    'VBn/47qzcWyrYvK7AE+DykrcFG7H/dNMNuLhPSSoeyN38PjH2T9Vcnko1wMkF8/2AMrF8T3ayWdytWKgt08fpA25riRS2enVctL5'
    'B51hnXUCh2VBBwoHzMo0wow0SfeuyzOTGvnpUrGJ2AWyFPlJtFGdUYJL0BslZEY2xkt1Yz+bD6+qt4WCeXt02ZAU1b3P4wIxykxL'
    'UePdLuSc86xr1IN8yy7onMhidnw3jrKtp+cRx7T35b1nCoEOj1+vvU/8q2ZdA61MwudgPmCCEk1/DS21I1rdKA3dEw93j1wG0EX2'
    's32X5PWDKvb6IRvcublY5ND2U8vfz06B5LGDwWD74C3ElFu6KCcDe3DuxpLmFQ6hgNwtwmjo6psfAx68BHJtoIBQJikxxcvAXziu'
    '1tLNOpc4Gk+gvQUvzuQY0Ot4mVpxr2Yzl00DaFkjjQXVJOs/kRfhwjEq1C3nmH6GaGI81DAgzWfRd82jTb/m51E/VwgmuZZPoRjZ'
    'ipKX5gERCptIRnxVKgRjtD1r6Uzl50vaaFoynAa2ig9CSgrEiWFSJ+ORiyRaOsA+RVAx9yjFDFYMrfLsbEwGQHNKBw9EpMzxkE7u'
    'Jiwt30fIVqPqai6lOp8J2wSvLNVvKJTWvRfMySiCA1lOon2BS3vusIcQfq49RIJPJHKJ0KFZu1qXWnLgTZpp7cEEWVbqml8TMiYh'
    'FECz9MQ3qF5Ulgn8qLeav5xfj5cvisp4M4OtlVJYOf4hnGfomlQXfrhL6vXzl9+8ffvNcZIuO3zigDr/gytoD07Ss8RtUlJLrhso'
    '2id3DHw61twBYbtoTnK95rUm4fXi11ReupfeG2PiDmrCmWgct1oJB/MbzZygKQtmsfNSCiGTendHpjUCVBPO5ULRdG4PEpRpF+no'
    'fYkWxShN3rTbDUZtdc4v1J2jmw0MGUBhZZzzGrPRmkNAVHAnFCTYdc7Vv7+poTUbunDfK7rARUtD6mkQFdwJBbWhVKc+cVndNH7e'
    'zuf5HPgBdMRmrJ7zt96qnBtxSIAUx/shAi5ovbUhlf/SmND3DJ+3YEi02PUKfbO3O98iNWy7flXlyjL9ADvUNISf2VU5MpISfYhj'
    'PiWtKREloIp2qvstqm8V5enLe9kp/QBgwY/BAkhe/GAs64psy3KmHn5Q5psq1qihOgoE4qKG8OOTOAZuvtJ0sB1elQ4oWq6UWlRP'
    'EhGNHy/mfBAHRW/gPAOoSEO5v0vjYeeSCJyaHmYnoB4REPtSdw00qLuPYnOYdXhlghgP2Ts7ZO94yODXdBuzyi7ryW5L8DRTfNHA'
    'Tc8S0haiFuJ6jSN0FyH74dPM+VA9rBVxQpcUcV5VD3Nt38XyBjMZJ1KJjMeUF8lFrStD+dQIAnBf513w4vezhwYwT3L0KV89yu0L'
    'nYT72ZPdOAh+ReTVx3lqG4GNxq82E4mGldf4YtsXyxQ22r6UpdQw7xjrRcdJL0t8nJojNVo4MSP+PB9Uftt+6mXoMab1NJzPQ+qw'
    '4JjSbfqc1PwlG/eJ+krU7pFwZxa8UgbtjLx3NpGrw5LtzWlRcsn2CsbPu1+DRP50fivB4eIV0zC+6iAMNUGlaOWnNWBFHlM1RC5c'
    '+KnbzW51hyHcTgPZbcWio0fXPNhQbKqLlUWVV7SaL2OTIuExNZA8cMiW3B1/J4NFmsPAoTBjTuA37GnKtpzEn08IeGV6naMMwqn9'
    'AgfJyvUp/sSjt5yeROgqGVvo2RHEHnBVlJeQn4Pwk97qnTYBDGv0cRls0Fom2lbSmzyIWzUR67GIWAepQBYJWmGPfPqmEPFDCMl+'
    '73EQpDS0Dj6R5kIV9lxNkEJJ6gVUkAoOVH0TBQK7j0UqR8GhCgsB2eD2jqFDCLtjzz5xe1ZacPlDEGRQ37ZPYN3UQaEPvkkQG/fd'
    'xA8V04EdcZukogkOblSKMhyPSua5EAKz4G+Ox8t7KTl7zXgGJ6gaQcvzjxzNtmG+9ifTDZEc9G1dFdE6QvQCk+Bua4uz84xP5TCd'
    'de+QBbIsOxAvNUG4Z4LI/pinNj5yiXfMnyyc7887ujn44JtRufLbo5HsgIpDwqXCrLn32N1YLXltmmltIiJhvIBPA2G96WZ7v8HM'
    'rZI0JEmasrszQeR52lCa9WN1zYyp5nPdTLSxnX2pSHvGmqV82UR1F3DvnZonNlnsNR+o6/UDl4opi1QPxxNTqyuakkM8amGTVACi'
    'iu48aznRGywvX3zA9jnKtlLSZPnvnj2FG1ZGzR3UdtTaQWUXjHDyQwR2OSj4dQFt3k2wAon0YcKEGoGcMfNtb3Ce2FfbSQzJPSiL'
    'nPZhixVu41eAO93r7VOF6RFzXH4UbIXOyjmsnz5ltih2etoLgwTYPT7B+nZKhULGEFB6B6cdalSVb+6JbCJDLWarHTiRohWZZzjs'
    'FpN7zGyyc1ZMywkr5p62p8hCRd1n5Z5c21TKOQizhbE/++LDuBrKZr19+gBdeHYaMN+RNyQisLfquBmfVNxzdxzU1v1WJ78YPyXg'
    'Xcq/ZtUAUfVkXjchHs8a4VqKGqCqUPhF4mehP9PESU6L4v6sOh/RxbbDwN4Q2TyCUtXTNutFMKoaRAOOIkBwGxUgRjvTY+qmY9YN'
    'p8esromlHG67c03sqV69jHsHI2tZP913B6EqjWg/UHs87gRKeATr7gxzx5P7ZYyrZ0rQZu2AmFWTiVZ63pN/jmpIwfuqZ81dg297'
    'AFgmBPOjx2mzvv63PeJI16rd6z1xlcgjJitNKyN3hjmyShsYu5Z7yrezFRmVt1qmyjUWZkJzorJlvOzHPXiYxw3r1ge69VsmLVEj'
    'EjOT+1HibcxJLm+aAL3xew7lOQ1fihdJKNGKdFmGtiyojMob0M4OZcbIEvwg7JFZSGZUBI2ClWRGhc1o7WmrbWj8XuvvC/vtKMZZ'
    'QlyrNueJW/kP+3kbaGQf9p1A8F03PEEcJaRfupEQf+mG7+Ly5t/Qm8RSoob8Q7X3ilhcjYkQlKauPviMn9DCE1+Bap1S2wAgeqoK'
    'rgyjMTr1yXaX2uX4pb8cI7ugv4mirRV6E8/pTvYkTKn+iGcUTAYTrtnAjwDPBpjc+lTfVbB2BS9vNFqs4z5TEKONTi+8cxurtH+v'
    'xU/sSfYomAk1wzp7I5Nx3pJp7kNAi6Ne3dbTAY/S+3rikBrInBINAfR+SNRf40lTV9foUDLpoZGOQ0c8SCIG51nfXoGAJwkaQc/3'
    'IiWKWzk74509+P/tunzJiM2VCrrJtngsPBMuYvfJ4y4yjt7xgWyjPNavKIGMMrW2zV+9Y9Knh5YPALmkDCdFnp6GlriexPEXsc6a'
    'bKknDM/PUSTOucS8qcU7vmNLu2RLd8tu4+H0/I/1ST19OhRy95rBynI88cMd0ZjdLD3lKWtUp6yTndLRnSeyF58+cNUnrN/p03KK'
    '7CgXy/GZ0YSpzPASbOWvag+t7MBV6vAerdDROPJ7QEauxsI2Pa8WMqI/FKtyfnjv5ody9Ef5v4wpu8K5iaPlGJrqpm8FCiG7IhE3'
    'DF9enkYygysjXNI3xfCi05k4/vZDY/oDvzuL+F1oFUur99+JzT3vNRldPiX5P4+ycNt3KrHoY0d1/a0id75niyeBLbYpzWPmrJ4c'
    '05sHIfoyyWykbB7Gu1pTYUaiWcSG4h0ok9UfpcdbWsYfkimhX+ca8meGRMVOo2UTbdPVXa6dKBeRmWu9AF6DBJV6LFFoD06AjlE+'
    '1icnTMby5ZMvx799skVJ35dF+h537YHO6OOAKRrdn1988PWf6l0qzWDaMd36Kt8oVJ42pceh32l+cxfnf+Qcu4SS8aljC/Vzh4IR'
    'ExR9FznJJryGDD6IkInQGXgPllHOWO6AVGRUyhEOzPCG6TDRN2u5MaR/t7Oz+oiUaNLDXM6COxZ+CTUVmf3s6x8U1vy5gfx4GnYC'
    'BnroRrodpytjR6KEt/VUiu2Mvl5oMR2rXyZX65Tw8R8PPtG8RKiiutlzHDM3kl8UPr4CHb/ZDzx1XGLfl7jLyRvzDukGwYhyNz9V'
    'bxXIUBvdf2tUHX6hBbD31OhYZ3k697Yf33ORtISIEcGlyKoprIL3/va//G/3XG4v7zk9X4wdAEwv+wpQoqv5+bnjhMyvCTRMhwzc'
    'ykeEpznM1mEqA69WXwjVGMjCbWPPdKqrASwv6n4T30FSJyTCPWpJqNn3+rDfNJfLGHLtasSUtxOQmHIMaO5OztsA9+LeXkwwBjGx'
    '2N9XKrG3t8mfv5UW7NfURfHJH9yExv9djvjefu1w/6blcOvR5my3HNxI8dOUR5pCU97CG/zSZVqVwqQ/e2Hb2ral9IyP03iHQZBo'
    'B+b1t7cbqwSpZ/hY1EXvSWORIkrAvfIIVNxowCDQgAHOg73b9+/uamx/8xmPZ/0OIZDC5XhUEjEgln6osIQfEZzNB/PVaj7dmYzP'
    'Vnkf9odzZQXKlXq+N7IWCK85pPuBoTDPIs+FNrHowpEDERYuHCGAMLiTPdx4VGkQRKjAxm1AF4qLogwb4Wv0vdFnPDE/jvHUbY50'
    'DZOdchF2ysUn7pR2kbVtt1xVTgj4h5JjNP7/IhHNL2qyOU6noy48qb9EcO492hiksjGEqHWDXRTVq/kK/ql5TZY2aZkJIMshTD3G'
    'ferWWmq4NLVZfbXq2tJIlQi+HldZxz4pFotu2GGydLxwmPIi3VWz9JKRvTX71L3FFj+ZvPyIDvCT9s0T7ooZFvFLz5bxmtiNVvFJ'
    'tIq/1Tvi4b+dBB3vIOPBHpIlqHEBykBnXYj5FFInT5tmXqVmTAqzbJTeKxZeNY9yT65C8bt79/gOziTYDKLuJ7aDRD0Q3kS4Kx36'
    'gkNviT/kOsI/chvx16l3GjajAOtCNE+EQL5YTNb/XI6vO3HUCs1/1AHDH6HzxYf3UkIjB/nX+jbPqmEx8a8uzdebkTUIKHm+Wi3L'
    'wZV8rLpkEdWmW5oO84vO1j+oW816K7+7rNS4mFclegozyXzZSfN7LcfwPbGua9vlTI7Vd29/eElMfYTowODOqqKx4me1ng3fzueT'
    'QbEMD3ikXxczF4fDOAP0GOv3w3h2JV1WDjFn+Zf2WEuvlmtYhOcyNW+kt0IAML7vV+Np583bH//wTTf7j29+fNWrmDy4PFvD2SY3'
    '7fiQKW0/GIiifD3+qVjOyBJm0U9CXwDWZzUvqlVnS0aA2D4S+qvVvCrejz29AbK8EP6//fW/ZKC0b/BOykHmJThEcTbeIkbbLfbE'
    'g/vZjv+fsMFodB0/uv8gyto1n07LVUdtBrOyung+K6cyCfAGmr+BnlBN6u3j5QXtC4Yk949386iC6qI8W3WYC9UemTc4Irm+Lper'
    'dSdPcrfCcVEmqvNzNZ81ewajwmtF9FfCDfOMM1eqTzQAevE3MYqFE9TuM8O7Vmp9rzlff66u1rmyG0S8ldoRgYyAtKS3bscm/caQ'
    'OZXVeCwEAT+3rKXP69PkQm2iWblrpt2URMsyX3Ty+rxZ+2wx1Ftv8ZPW1rUYdc+3WNtjxozhUlsW6nefbjdep/curgb3FGWx8r76'
    '5mfeN4fxkBybqZxCcmyX18oDgiJYaxYQnPHNVoWGmOL2Ae1YPv8tmMI11UzQGgE7opuNe+c9zU58NSAm1WI+npoTHIJxKyQmQ3ZT'
    'n2GUyYixrXAJ+UCVjXFzBlcNfFATTH3a48jbPnW0z4oz+I3Rp6RQrZT58Jtoi7/PzHnGcE7nhEvWD0UavpJlcwmCgfwFlRiaJCpz'
    'jDDgWq7GcjDkepiso6hIBAFQAdYhxOj4hhac+G6pSroiMhhgPCLCqPPku8QEXTrfPfuWslJbAmx45hQKxitVHuM/kUgcJ393bvWd'
    'Dj848u7zpazaDTwQ5XFwboP37DYUuy1+9oyE/R2SqXJBtqoQtpSuSEWfYgyyq3tUEYN0nygumC6NS9V6oDsQtVYx+CwynyjJ1mAM'
    't+CyrQ15lI+jQxEthz35FjiBUvH3o5BWsXQ+vJEWlcYdtzJaPg6yumwP8/yQNIP1yzfhzw2jIIdye7s9kqEezIhgPsQHRB09JzQs'
    'Img1Ilg1y22di7t2rl0zm7r/IBsemOXeCtw6V57LZhEdHrkw7oU/jG1BlBD5RfXbQaNeDGjOnarmEhkTozcAW93yDIgXWvVCAyvU'
    'MT8NvYVry8g8PcVEWBh3spTq5Ol0rNxQ/KUU81ZQj8EHjVD7wkKfzzRRkUP6trPlA5I1gmQWzBwMy+NXwZA7Ux+XFAtyk99InClm'
    'lro4N1IKZ081LwwsqrsuVWMtLZRLM6xlYX19+KUvSlXcrYPF/5awqHqRMBJCkxmBJg8vysmIIMD9KEHLYkvvJYfKbCwYMLcxrsJg'
    'tcydfKF4+et6YkD6db8SBnXRMuGWCQOCHnf+olcnnZ/Xp5ubNaccdBmyZzHfyqVD7e3KLnfYviF3m+Zn2eEHr79Xa2K1WCrIiD31'
    '/LHdaYu86QX0SrqZhHY3M78szAtIerIw5fENWLNaa6rmNifdG/Ok1iwvVqIWUrhIUZXj3bSIvJyq1Zihv0h9G4EsyZPHwg9q7AXw'
    'lSCDPc61uLYu99vOqH72lruMgXAzgoQO+w9hGt7Ff76U/zz6zS7MQsd7v5EfybuTfGOwCHq40xInYp7WYxJE9q2uQh7B+QUF7mdh'
    'NTGkz1py140KIDDp1Ncd8GOffpv4UZG+AqXU8OdFgMZ9vOuDUdCET5ZS5BqR8qWVv3BBKmlRZORxRR+nzeEoLGhNWPpwF1as7mUL'
    'GjD8K60ojc1oIXH5pnEThE12nvEYRyGoq9fryXOcsjGDBmfnX5dnZ3C3GwPsvu83qE+yZFONMQXnW0oWMv0DiOp7453fMliEXhQ+'
    'RuQDU64z2K2mj2IcSCME5LM0+47O1j72myFXbmePdhGfHiiKje82uQ0QevUClE/5umIVHKs+3DZTPyzsZtEwIG9pwYBGY9nd4yx6'
    'evAR0V3uY7XljkYGulhHHLma4Xel1tkIAQCxLOBIvx9tb3ehSmA6IFCCQGnZTxacy1Y4dh6XGCV0+n2Gq2Pq5pUD/JS/QKxI1uRn'
    '6RBj+srq67FPOGFsgoUL6idH0GeBH/GnoexzF2FKyXyoKFmOIjYWP6IlkelIViQkjv0kfiGapsbi5q3wINAvvC2RjPlDJMe6p52w'
    'UOdE0asnDq6yaoKsesPJfHjJeEOVPTx+pca2oPMdzr7qbdIRvxFmA1BiiUTBLTe8Wnb0AvMTY1S4wnJUECv68o+/jW6DnOVFwb6L'
    'U9XY52xVIgWxsOXYeNdMHyzD3eHjUpE1o/BJhbtR/a6Q48D295Ix/CCtdX7VakGKHAzmN0gl0djgUewrWc7Ipwr6UNleppggpZrS'
    '/76nRY+O5E9yZtuKi/oJ5yHEyApBeaIEJdJ8RAdErzCZwpF8jCJb/rx4Rt1ORXPv/5pd2LqLuNhg6HbOJvOCegdVCfSjwFFh0sJm'
    'UN0B1hqFLeV2uTJIL6CXLq5WKYKRrO63MND+4tNoKRe934p3P1mphrLPRNLa8ni6WK01T2kU12ugk9VQ2p/VRC7Nd169F5FnAgCP'
    'n6CftqTnqtoFH6yaXE17Hsp+Rx19XHgdCjtBicmrh7WYIs3TK/88xY2jSQ7cjVsQ668Avh9KbAPEMtdqNIWjXuvsjIKuL9mF2yh4'
    '6I2qhAqHukYDcdlQ7ngsAufMOEeWTpgwVFkF7LVyZW+9oqi3+Sb5xAOiQ1zzj02nAfux9TQYHqk5bDROxR1EcjmeipTxxjwUErFS'
    'r94gVzrt5+cOxSeBCLJR0/R4bEWjbAmTox7mMDdF9OlbGLJoWdTUrdzBx8dffND5fFVMEUrHWM/89uTELZTau2Tz3muUZLBofnvP'
    'Aa1rvYRjvZpNxlXFM6jjZdDUqXcKt4PlmI2WcTRUv4GWmLozESYqxcuLtb6q9PWHt8qjDxWShoS+YqCiI73GXDEIIICcqir/uYcq'
    'm43HwHVfgejoxRht6A13w7nBPcl19ma88q4iFel6TUgpKcDiizyeIr+h63kMsNMmJ1GsMDwpylqwMJUwUiWB2hx0BJx1wjOsfXNN'
    'rEHd3+6CTvQSMXmP97pcCspiDe/QnjR3ebxBGjsjVvk09kRtR8RcR52a++UXmTGq87MolGTY1KRVSfORsqZyqinF7B7rYaASsh+B'
    'jY0Zp20furaW1FEtWQdwQes6H6nwhWkVPRYzlFV1tWVJrn84XqwiXWWiqOwaJEOkr7S+VLHKy/qjveHKKZxfMk11vWSq7mtXCfuq'
    'L/1Qo+0Cw2Kx6pzNPulyvnORszMs7cHHt+hyrPtZqTUjXmLedeagDLs0ur7qWBHwd5Wi6PIYmzwV0PesLt5FeqBmPVwqHpA0mERk'
    'liKLCO1gyJTCVNo15xC3rxZQLBOArmKsP5t2bGUQXLQP6KvDInluO8PqI9yd35maCFstGR2+qplzMI2mFdOdCwu5Qxdy5hAHb/x5'
    'p9V8Yr5V3CrOgpUnW06FtFUqpEVDQWpYswZE+DUUHr3YyJIVYLSohIBsqJpISxRDGVH1jXXay3kd0UVZVj7v0btzdHOgv2jrH60P'
    'zCb7IMOeEvlIrrpVP17WrdqRp37ZZUb3meuuVnESEp/X8qwgsqd+9RkdsOW2cSazs2JIBaXXbparCJwpzml+AWxMNJgAnyfpVJh5'
    'nQY211s6SfHSLmEvg0AIYZAv1sizp2OQBkfzlJmrQM3HNhtxTpMVD150B+BB86bUD4NHQDi93gsdfK2NDtx9h0igmvllhvGz4zj5'
    '35Zgil+slpPtXalo50wu7jEju5fjd1fCVzrCOpV6zGin4qR5NNBCxA2VdUTsMIM79MQMewdVikZoXV/IDQYJw2VScbQkARSth2d6'
    'Hf2d8KCWDlrYqRhjrSU0CHxeURIdDatWZEB3mDj6csBDHXvR6lorAI+dehX9rxFG1PusEV4WbAqm3aZVIQo6ywNs1LFm+5sZTmec'
    'BMXRK7Uf+RvGBnOUHUMN66xdZRz5Ome6Q/0uQOh2Ld024mQh9T6koWHvy93oS3UY9R9jNo8dcmmHbUV0yesQpfbwzuHQVCIl0G8J'
    '6kCtVxX6CisvfdTbsO//dFnli8kZHVlpBnKk2BZ7ZAsRknpM9bhh1c7A2vJLyxuqYE8hy3EjC8d5F9m/vWkh1u9Ocw2NcXrgplrX'
    'lfCxM1a55SzdWHv87XWj5rhtGHn2H9m8vK3JheFeugDSE0+6uj4GYqoQ/BokxPMql6fQPNIcU2rJdBGGIjHidJByIgWM81ZvvNN1'
    'XBGQ/LL61DU/XziThlZxEuKji5q5xqmaaThxNVXqk4JtK01HVE+R+Ox8e8Xd1aJuaLj0KTlT1fiiwIHZj2wM95Pua4MKylAgMg8f'
    '0KjkjTSXYTyxOSEAojF3wvmCW2LbUimc2y/YVXTb2KMHWWc/Vvx7XT1a7gaFPEwOAWwCljCg4rYYFaZC8mEz09cNw8LU1yFXq3Gf'
    '4VnB+D5pOTj2mQ7j23BRd5vpp5NrmvuxcTU7fHnlo3g3KwtXwjuwXOZdbShoXYNfgpztKUCm9h7t/n//L22V4YR/+/xVYnuTMkrs'
    'utmbt9+8jt55a5Lpm5bz65HB7p0r9N75ID3EhaHmmdm24CE+H/SunTV2PzXcFgZ+t3blL7T8hbfefhnaxxS8Zj7IgHcQJ5Ct52fv'
    'tqVLXWk2UOJv7cu/gInxeU09QgwYgL393IuHjSSnKjZJT94RovU8nYZ3vch6Hejkl8nY3/Uis3VIL8kBB8GmmJGzZXagDUSHRCQS'
    'NwItSZJgfn5Z1f2+YmWiJbcOlPnOY/nosdEYz+KVmh0Kcf9gBTD1DiHVheh8q6igmXoc8QicaVoUUCo9GPCAFoH9PfDHIMWUU6XU'
    '89nYcEo9X6lnR5sW3rJyzQzGlcv1MyfADlK0W5Y+sz2Te34/nk3WspcG+PXwsRyUAtIR4KsjJpuoisK9KtDsWWkIPXG+HpmTKkqi'
    'HPYaM9lTVap/PmVCH/4dI/5NnZU6io+Ufr6PMp9uyu7p19Ql/q0FMQYijHyfMSHWZkC2S+FWppXlvnUJ2RK7MEY5jY9bQr81iRA3'
    'EPaHbFXZINPo8FDvm9BcV4Za1ITcujc0hIaOUO+Su7wBU+lq6PFTT7CghwaR6mD2umHgLKeAJcWqg2bPhY2YgnaD5IVmUCn55wO3'
    'ACyfRuBpb6ToNHFLg0OB0NYE1C9ze6Q2Wb1e77IK3hs2d/6y1PNOTmevt7ffjF++qshON/rQza6L2SpO6ik96obW8Z0wu5f1MOeH'
    'j+U/mIoU1t0ZgkP5Z0Q46bCVHXaDN3KtQr+HiEO8DsKq8We40JQl6eKEI7kr2NFr4CaDYzU/5kqV5UyqZSkvRw6b0JtRUGXeq0OG'
    'VNprxglc1oO0TR5i+izuNq76tg33fob9whGSj9m816P1mtZZjdldjMbsl7IZTrkbK44uYy+hkl5CcT6NOtCWZlKWKnpkeTt78u2k'
    'WCFRPT+227XzqkNthQcgxy/zNGJ+nWO93C5DRqdLJ5xFblwfIHxIYzJ9AJhGs1PX0rEpR6wSU45YPUxJ7E6+iy9XFt/J1HS/uphP'
    'xpGHJq+CKKg7ctHknbGKmGFma0dOK1PCn1bjxalrBzj9tasjj1ixxk5UYO2gI+FtOMEls3YWZ+KNnxnYrkeoBTOnAexAv3YM+vVV'
    'TT1T8QrEnFZOxHZWk2qFuHZDwZUj5oXu4GZJx/pOpYlqZJgtx8AhNh8fg49ZnGhSaINzhodcfLXVMoVEindFWiUXdZwA2JteQn+f'
    'yEZB9VrQYON018WY93keAFOdCMRB+DMWYTA0jrcb2ZvMoDdwvBtXSWEocv56oPQyXqT3I0qEJ3fd7Hv74Wrvqlyw74hq1LXsozdo'
    'RFWKPA8QWxt8oWZ3+UKlxuLwrYz4TQ/3YDVzz/mhf85DLFvnWFGXTjjBHV7kCliERPbI64UcX9WM9/javZBKt/XN0B/hBj/xRkTj'
    'iQIGSltgung4Dz0hQibplXBF0JjDf4jfYO/4b+Ka6csJa22hPkxytoRhPJYtZk7x8herOYnZCq8WumTtIFOazJBM98+aa5072x4f'
    'z2VH62x8rqyG9PHnk67nt4kmDO4C0SPoLZ1nSTkpM0BgqH0i5DXqUKYJAdDp6FvtBH9bH5wENEB5X7U2niuZ6ZBI0JSu8sqs2RDn'
    '5M6G8qTv1kA8hThQ88sa3xOYJV0bO/L4M/pYp9wf5fqkKznBN73anJ3EXYgJCgtPS5/VJot2oN1N7I5dMAnWmOo6jOY9M+qgnY94'
    'rB5Oib7blR/+hnpdMHNBQ+19Pu9H0OyQxaN0ueZGfAbVRSR1BBnDUWDQcjLHMWuym39c4tijewbGxsmv4AYqTGGLGPJ3YFW9x+Mn'
    'dfs2udwxcfOpDGVVDJA2eKGXp+rXISwiiHY5l1uRw71i1vlEbFNtPuxfzDcYw8zNmXQrQFGF6VCWOcIjlDsggKDHrri4xI8fPu5m'
    '+0+62d6XAKs6yb1ItNo02pG7BSzCDE2vckgL7BUdQp9ojBgadsUP/BwCR5xHi/F8G2Y3XmD16R4vbFC6g/0hw093ZfrrcdM5/GDa'
    '9Rs7GHoOe2rTGuXkZqPnsG6FVFpx4AJzKW0IXSABifWnXk8RNK6mbvhIUBiMKZWK7aY3Mxunyv3NeIq7uvWB7pPyY4oedFMVL/gY'
    'YX2+n7W/w/CxOj+od0hkhalCHKFzKJjG4lWenRcgAxAwkX12GjHs3r1PbuLLvrHYfS8RTBOJYNQQCWBTuAVL4c0wXbU1dTO4+Xnj'
    'GX17zRwFXdGkuKHvm1nWqvnk/fhHjXewUVzNVuSqGxNMB5Mb+BDu0sskBUOxg3Xjs/5BKEBpWlrdDtuRjxunkcbWyIbuJ+nj1lcf'
    '4aPpNVbXc8/W06xCCHxVdqrqCcuhKS+Uc08C50JOjOq61JwaciCdZMJAPNrcGyIKL4cBkGXOkRQd/L6m82CHnGQD50TLbK3o0TKB'
    'VJIpi+ZFBTQU97aaN5XO2M6BgkZOIHIbnTNc84xiyhQSCdVzUJABmKBCfWcF4wpllwvlg155XPK+oraNQQpmXYAJ98BJUmDGKE9d'
    'wSXY5ByaWlM1myZXitMw2pGNfSqSRInd7GphflGQYttSzgzr6l9lphG8e+Okl4NM99+NF3qzobITN0GFZcbI4YkncNrAy+9/+P5t'
    'qk7f9ep0gGfTLJIG6ER8ejfm52OAXmO/0eZLwAo18vwl/PwASRCrmJMfrPOPHhklvDWlgZ86UyjnMcbvS/o9enzfl6D3M94NLymg'
    'OKmAQsEBS+HV2l7B9EWpwE5h5INxxSzMd4w30m/70KE4nePLkM7xJVTqf/kLUliTtIQSuBpxvw7WRmI60Rfu1a+et49SHbNW/gCj'
    'uVck8Aob4AJ05EUj2SElmaOyc+HJs1P4D576g0PKQtQp0p4yTunjKQgohr2ZRqqFQCw+iTRpTzqMNL6eWxM6hpzLZ03YOYf2pKlF'
    'J1EpK68gKZQfNh0+Ehr1sj+MTdlxMcbX2pL3HQLhGMGrwivmkQ65nEXZy7BMVZc9ICJ/yGISCDkHOB0jYTJIXLH6rO5b1feXPweu'
    'd71m13TBDcLk570oQScTwVtOKqxTl/PyI21QvFsbZxg6iKsF8+4VagseDsKjgT4qUWpYyL0+G32PsGa72oeDEA7ofARMu1GAu9zF'
    'GWAhDYUeFsdlcZIb9Km8syCKV+7NHeGbL9VbTst15XbwPykSyaOv9NHguKVFFkkkLSy6p1bnsw4oZScikV+5YykVh8O7E1PR56HI'
    'c18k14OfIEwXKbkoArko/OHvZstBWmwQig18sSRfzdUqjXZ8yWKv5F+7RtC1l6wmfnjjWFkquaHSM39pORsxInPJ3fR7IVSJoXPG'
    'NL/1+fp9mIzfx/OFm5h2tDhkhHdWlLnMfqPm7WwU2W3kux08PkjlZMYdSv86z7vZDpfyPvc7DAFLaNGWAzCZo4EV+6qbbSqV5KUZ'
    'nzEsEmUa0XTLInk24LOBfo6+ynawu0PKH+ijr/yjQXQ43JkESj9aJMvN617aeIZ9cJQ915AiXwExw5Iw5ZZasPOavd5u9loKW8Cj'
    'uxFegNkMcSvmpSnS8AL+nxO5P2i8DOznTKltyoEyrwqiWOZXwiMOLEt87nIaQw2kjON83g3Qz7hmslU5BQM7lieOjg9dn4pz0EQl'
    'erw0eF30ss7riOqDN2Q7ILs4GuwELKYX48nCet4PWmvI8rK9lmoVWvWy7zG8M2pFqCdxV8QZgyrQe/YlZHhTwzF7GWWpdE7OMFaT'
    'CSbTLNQUN+2ZcIrsfEWyr1eaE120S4jyGlerKFOnnwc5jREFD8bYlVlj6VKwy79irQqtrLy1DmO62m7OndXMub7Mz7TTIoZL/kzK'
    '/dxm9i2YR0vkes3IJX9SeVY4a3ChqpvzgXswSE3DRuLIPbV7cey0OX3I3bq2T5qOHOknzu8j1ctLi88Ul1sqsr+w9narepI1v0FT'
    'cETYhyHXppfwSS2m2s9ZIPV6qDGgLt9Np5bYr2XlNqfIqCUsTu7YkEl4UxSyxtdGZpCb3diQu1AGF5N8k+Q3j16sa1+syRLjRe0L'
    'e5F2YKYeILX8a43snfMke+ecfvrMAah/LjRNm0Osc54vzzAce+OThQBGTnazjIdvHKZd+Ga96974bCL2zXrvINLscpXRf685Cigl'
    'pBhwhschPmMCd5Keq5mjoMksvE6zVMMMgYpzZxZ7Dkh+xsAgCRZb62f7j5EXrPMvTq+WpJrafxSU1dHmmXPzoOrNXhvzpsfGBQlO'
    'QknaaYm6WomYsjJiol9W4/PvZ1/NZReslEDwX5xQ2C7qq9NtLmW3uR7d5uLVDjbadmd5RivC/q4pn+48wEkichYL+Q+NMEc6J8Ym'
    'UpjR+ET++VT9rnjCGfCDp5iPuAKLIm11IuUd5fKhmvXY+e1lnTvUKF26rAdXBdSOdtRlIVI/zeBQOQC20JbWXzk8ka63RbMDKgLJ'
    'V00FSkfjc2bFEuBwbAaXHmoD9JrcupEfE6/GmVMzqUKLwdz+Ir2YX9Mpngh0NGMsE/yhVDXqHEcZv+O1mU+B+hCIrvlR/2qlSDk7'
    'mwe3jsu6NHWXd0SrLrTF9tPZ4CfSgFehq6gDWKFbaZ6kUp2rX9hFuSGfqsbpabBI7fDHnnwNR75aNceV0P5qTdXq8TGCwXdwjI/9'
    'H3jknuydnLRZokct8oQalSsoazrhUO/t5mHoapKubrTItQfmyf2EwEkrMRRO5vH1NJlDtjnQOfJ300XJpw0r4m2LfwlqkK9vE1ue'
    'L3BpDijqF0zTYIHo/FuHB7SJiXtYZ+LuYgRqRBd7tN0jTyf7ORNQnc1Jeb9yP5j5jLBk0fd1l2k1Yamo/FUPLnDPe/TFjJyzUUUn'
    '/h1fkM97F3B1+Kon62DWp028yE+46LT4cxR/diifha9FQoJ4FPlGqdD8Uy86EN0MP/1hyQ0dPURd7HbptrDb232SbzwiP/VCRNXI'
    '1GuePPyECaDOzhsLtiMlaPTabR+LclUsv85P6KNuC9+D5l0UkFgcI+kt3WZI8KoiTTrhyTlFOrtGPGV3Srsr89F24f2wdwrjsLrG'
    'nYFbwcqXJOaEBuirRCPvI5w5Zzg2nYS5O+gFwZBq6BfmdA7ilRCMZwy5UmtTHJAU27V+AWFX+luPUnYWvTspMSffzF7WbKDxHXeU'
    '+7+EuNcMXUm8EWydKKcJpIQ3mJFzhZkxhZWgppZTTZRI5iA1Cb3TFrBnRiJ1Tgvz7AMiVzSohfVAG6dqtT7NGBWwjHSh3o86iOJI'
    'uX6Wnc6qU7TkFAGmF4igHKfUJ1/QdPSZk8rP1DZVxayvtJV3g/bY2Br1VgDdq1x4PnpNv4ZlH110ygPn992loUuRCwmq4TYyhh3Y'
    'GxPJCWvIGK6gerZQPA3Q44EopuNedopA0fHoVFr9zEn+ZFc8V2UfCvMSVkpWxAJfTDNymbsA5ukVocGKtXntrebzngVr6AkiRKMe'
    'IlUZQDmiDFkXA3bu6MGBj47vqXHNom972e+ev1ar3lLpwyIKzUz664MqT5naUAbMN+pgqDvKNNv8jDVZoJLC0wFkuKNo5DfON34y'
    '4eqf2TLPSVdC0OWW384WAclwP9WLcNP68eiaMZ4+ohR2ZHUFutZhYQ3k/3TZuhh/hoy8aH1SjtLoRgIL8KOIslBq0c+bRKagIua8'
    'xjye20WjHQF3cm43kT2BcGzuLeFbvbPqJfXbuLb81zOvUtnQ8XBWXQzCQEf/ojKPHf4l7If+FXgHd/+rXAOXNp2zk3ryT5kcaVR6'
    'jj+og2VS0SqVaKtOiBoFHEl5ttLUf2ZHTXxunZNr5W0tVCqC/ClJdHo6vTZXsI9Y/uOxd1g9cBSqdmZdO2rYhv8PJCipRt2+S7ar'
    '5xjOSuCIXQRIgbIl9S/mAMu20u3vYjWCiufHM4fW++Fu3QvNkTY3NMbM1BizqLnDRtFHmutJiRE8rhAEGoUkAScSnvG6JKHOhjrQ'
    'WNEVeLT9Rxai5LQw77CWcZTS/qPYo1YahZTN68y6cqThF++UXb8w5Jp3yuBfyD+30ql3kcOtIfDRv8i8LekZ+E5VTC3P103vbykB'
    'BVY/gdK7qai86ieJo/lwXSu55sNaSXlY4/Vl73yNi5KbaxI2szCali4Ulp3otrPrYG4gBV4JTl74KNos7gNhuCdUV9CS7DxTdlvE'
    'xFRnY9o71aeMUqUKGF+q8PzbWL+yt2t6PNWyjFJVC9/uxW9jrctegv046UkrT9GRv/wlkx+7UMLt6Y813qztzRpv1ntt5r92KWdC'
    'P9zgE+nSrROTxdRLLEMxx/4yFdMNR48xYiTB5hjrfpr9uG3oXn9HmXczMQS5FyKIScJfRd5Ile74SjkBh9nv1GU44mAVBYLXeJWo'
    'RUk/PkfplIvszOJzJzPrbrFENcB94fA+banDT+6Lnej1XhMedKMi4SMKhJpCGQuRpG4WGpBqlrFMs1j9JyVSFfN6t5vmekaJpI71'
    'XtfnG3MlUkoDH7wABe2cdDiAAxfwddOIODCfHQ/65/bMDZ17bmUXICy2at5rBh0EZiRvqGN1tZs6mZVGB3fmvXRa7awTvY/tka6v'
    'qPr/QPoXr3Q/Weh+us7Rz9hD3aqtUG3X6vTTP+hhEROlbZ3CSpG9mhK3Tm8HvfVuTalbp75SZK+m5M0j9Xu6oNP1S7OmKMtneAz0'
    'MI1FNhXZ04UlopY7WXEBC0HSL/Uq1/f1OCdyqq0d0MWtIU/U9hUb0ep9vfQU9Py3cDzVPIZBIlO8heA1kyg6KddisWohSZP+lff1'
    'y9CIcUdEnxxTToH9NL6+EvgVZdN1UFtaV+tHjgvyBk0yTp8eRO1Zno+wKJ4JqfMncSBoky8o1MXipr5xo+frtPyaLhn1LeqfJ5Gj'
    'Fsc4G8W7wZRA74vJVYJ0potvIWrGJCOHgOHVIVQtfgrMsxOvWegcY740WqLgRTAAu1dnFUXAfMmlOmSv2r72+58+QazKPxoE3O87'
    'PpENz3dofyD75GTDGbmzG5/XKoVY9rF+dBh/M6C6lfvMNtltnpwmOiiAV+fd3TXhIeHa1P/W+32pNmMcuUBE+5vKDjwyYTi0pGKI'
    'd5Sw2ozTi1xtqpBgvjWUbMCr82ZXI5x2INXKuHhbyn+2lYfTh7wgmeeXrJs9RMn1nj60kmZuPa6FptnNFOvpo1tqQB2U3gm2f80f'
    'EYQeENNqZsXNIIzaQE2rIN94t7Z3a77bxPHVmpx4zRF3TB54S9/aJGltkrQ2iVpr51tQny0RmG1jXXawHDuyHp/USdvvuMLtgKVT'
    'GGNf6sakVFT0NJpN0Tx7mvuL3ENiuMg2Mgp0WtDTjsFGw5jf0fHsjpmwHCmF5TX8VRNzG/3dwl7HBT7OAQUYyg1WaXPdUBZjboLM'
    'U+4NYYOMO3HPn3GX8Play1+48utd93wnPH+mO6dupvhlXPAsYYMTXPyZ7QA4yznYkpk6vMyDwwu0WDF2x8xtFXy1dl9d2ICir2pr'
    'lKwM/RV4Y87zjywNz6DxVfkGJ4LaMaLMSoK2aZ9sOuPj/37OOI0uqS6wtpODv5OiC3st3tr/0APtSlzGR/4yOvIf4X5agoB/IRdU'
    '6/NExc3/WjzRZzWC8Lmxwwz1pKePXx/pGOmXZ+9rMATIBUEfQOfo+ztpeIp7D4pH/FjuElxB5O7f5XcjQdEmrLUlEBM0c6I6vlML'
    'aVJsRw2m8TO6Gk93menJZTIJSFhNJ4tuHMGSpnItP71Xd3UjyqfSkv2joWIxvxXmJvkt/0A8IPzgjuSYSH1PoM7wUOIitT2R84No'
    'xH0Y/Pf/9td/rW0yzRGyKUOIgbDTXVwWYptJK3ig53KcSY7l5bPDjKZf91J+PIMKrEmTg8PElAyQnKHlD6UPMW8BcuucD5XYBlq7'
    'CREORS9U/nRFv2xA1QznIYaVPrf48pHtgpqZy3xQB0uLr5KOCgv6SIOjoGcejc81erARvL40ZncJ9JpttgpyG+hPE/vDwV2MYsLU'
    'AAFRGIwkaj5BXcd0Hvg2ce9wPx1xW/WWskWWdNLYM+z1J7t+t2B45bmmkjE0JGceZiJ0jdqoatf65+COO8Wqs8x7IwK786913n4n'
    '2+5mqQ13NRuF7g4eYI8QQot2EMPKN890kNhovml7F3oQHqAjUaPuRdKn9rj02ENUU6xsYigi1wNO8+gm8TfQZ+sDby+oxgoKzPvG'
    'vuB1YyWxvI0sL5/7r8s/j/MEqlyd05ZLGEfqsKkEtx8STBfXDm0w52P1CoNLNYKpHXIW1Ao+PN2cvQwShRlWAOdVg/ByVuskv5WP'
    'paninB9RYoNFL/tWIT8hmXF35VGnaStewkt7kin6lrP3EnPRGYnX6pA+Vs80gw2brLOL8U1xPp8Vk+xCRrQezqdx1rUo6jaKHLw7'
    '7LbVn2FZjMqryiFfxYaIXxBvGymtNkSzNX284kxocYjbNIS4TXt0fk7MmNddTxrVwylniqbYdjq8IAg39yXDi41R0r/JBRlmjbA8'
    'HyDE6zddEjrOh4YlC0NxEgED+j1AM1hQKBVt+cC0ypAUzH7f5CHfF8fgMyF3irpX00e9nnxkhSo54NESHxp3RKJzUVZu6AHsR3Vq'
    'dlDmtIPWkH2WFmxHuOQxXQaq7HqMfd12zrizUat8qz0ZIwJhofExCONjNJxiC0nTCpeKhAghzmyUZgM4nhr0Z4yPi6+/UZ3X31XX'
    'VQvunlIqqeLQ689qKcNsz8CQslBo5MBMWyXKBrsue1CqWK0kFEV6UWjs2hRXw8ilHtBXg9zpvfQraL7cm40fFeEjKsmoLksD1bhx'
    'DrO517F5ONeraTc7Ji4+KaH2U56mp1IKkBeYuwMMgZGOITfE+SULMHdH2r9cExU2TowWzTrdkHQDRgEil8o6Xhqu5aUajZX5NRhG'
    '7nPbuQqHKwe8kQAugZrdlgpj3vGJu0ZtNVXUiRKQyRkHc7LMG1BFLilZo4T6TXiW53ajb6V2/dMCZGplf46mQwYtH8lplqtlFDvc'
    'NTwCtBLaMN+Fn4ikqYUgv3N5Fh0kmvo7MvTQhmsRhu/0V2yKGoWITPD6FhunP58GTpYRcIiZ25S8zwE3E8LOSmu82TYlgJHHzsW1'
    'c+HjL98tVx1/u+2y1/a9Vnlf/63bWaYhR18Yf+5KI5paZMKQrK8TJiYus3k/TVHzBfj+6EvWigsLT+ylbxoB3LfGdU1vQoG2r7fb'
    'v072YCNXYzXUvJ0bszWqBk2HkgYF2X6ksL2oeSDNw+6Zh84+dTuHktfjzckLPRIApZpOo2J3v7ra3f2LSxT0rTPnfeovcfkNGIPx'
    'zsPEYDqUHnECCFVjM1ENff7CecrSqlhyZMyG6wOa1JlwhFS4FkWlu7Y7XUatkNhr/9m6Fn96kxnT7bkiemXwkZHSZhD/KI7it5xo'
    'jTj+UV7j92usPkP5zVqnDK7BOc8nk/l1JlcXI9YzN0rbzkJyBuQOln6L8S4qRiPtSsTnMyvE4Gq1miv+Rj/Gt6myDjkWeq9cX0hz'
    'cNuD11TFqJNSpJjRUuQI7/Ebovq9C5f5UV5SVtAs6h4VwBtcWHakZhifYGswlzp5/UDeUL0c2JYxsvyVw172Q8Lj08tycWVZH4oE'
    'qMcJGMroDISTmqgTWdXLnvtMfJaaLZkB0I4gI6Adhea9LjQDNxGC4LPJxGo6GnUsSzPVeFSbSEy4mqktqA0QSHHn7o46WX1q1Mnf'
    'xxPkfwg/EG8bZrQGlhrZNrk0BPVCgjta3m72DNpqiDx2NLGt3aNlP6ao0n3FEVrvET3ICkFBs6samN04DIRkgEuvBPqKiHc9dCVv'
    'yoUoSD9CzaSh33norCsXAniVQGo59xb92FLLlTUwmcnfnWHnBLcZd60fjAOmvckeMA6Yzkwc13Fc7oQzAsYkeTcI7/IwnZM2sHGH'
    '/vDnsXPDjCVYn8CEomz4FWTa6XB1I1NKhOPTJ7u7wuoubrIvPnz746u3t6eR6K6xMpOqYaA2HpBElCntgNNWWfCFBociB8pgPIkl'
    'OY/KpCSolktv44oBsUNjGI4vewqicikLc8Je+cXK1XMt74GedlRc4YRDdY/xp6+RBKnHHqaIBJhV8NHb+teAGT+fMGXzJE5pzOTU'
    'nEjLG/J2fLOSDaNV9q6RQJLy9S5gnPNwStziTa9wzTlE1jo9xC10aIeCk+8PhN6D/Ahwy94l4BODsHz6AvAaZ2da+TyqnIkwrfae'
    't+cxvmjPUl+6t95up2/ZF5dda0IIq1VJyd3pAnSs45HT40cHXjeXy+5Rdxy4KrLD5LB1s6tBlh63ug77PfkblRvPzo6vBjocDbPn'
    'k4KKm/dkelSEtHLk73R4Vm7dEFbe89MYKCVyhaAfBESHOcw1JzZDj0K5b7V1MEPST8VMOjuwx+SRpFvxY+19o7R2NindwOtsEwJ1'
    'Z32SDJgWbcVJeO72qo/H01+Q8bgMX/WGbh1+1mV4jic6v2VYBim3DuXWWm4dyv2yZThnlMFz8v9f8b97e7sw/aSGGxSjJeaDzGhZ'
    'n2e8xeo9PNC36XQnb3+ur2j9bbqw0du6Mn3TbfghNena5ZogMrRE3OpMfWsTraOQm+6SStlniLo/wn8eyK9+PItucdBrm5n72eWB'
    'Xwz/fM3ntY2XsCXySYzU8jLo5ZjKLoBolRUZcsYBVZ5XvsB/FOhk1M9WwplqTBHpCWqYXY3OGU42ER68+sxbK6kNnxPqXjhdCgXn'
    '5ftxCI0CTsnVxHD1we7mATofZQq1F0zh3UhxQZodK54J+x6pFIfD64BcpdKY4R8VSkKd5hYkcwfv/C++cyUjjbCa4XgZpPdDNT5v'
    'v5mPI4ccEq+E84g9dJpv117uH9S/H8TfD+rfD6Lvoys3YtL9dKn7v8vymuDD1kiUDLE9BNg+3k52t5SWnXi8p9TFfqlmPrxaJ6/W'
    'TQpZI31xF1oJ37Eudin/lIMThYUgDTxedLN38lD+Kd+5Fz/X4dMLcinlghAn9uMdfwziN/bjXZutkGlSh9dh193Pws93Oe3PyOch'
    'z7RLhSuiPwcskocF0vTNG6AjwjLezx4hZfW2Xw1yE04dMYXjA7W9NUWu6U9ixaxxDHLoVAC1bMVsBQtjmCOOejTUSfjxQg9KLNbF'
    'YM7FRLcd/6w8Y+V9Ep7AM2BPiF/tOSnjIxBFRYKWep5aJfa7Hl5mzFwr5xYrsj7X2hDdkBJxPX+aLX637jKiYXudUmZuv/fwt7+V'
    'ydV6gBr9m4b9RgPL9x9jmX67CyKjpf9D9qgZanTTjzTNSPh637KLB+2yPa2nlYg5VsfXKpMIuROegrI6HXkfwYdBDeYWjnkPwiJG'
    'ujC5NHwusI1XooiIXpXFS+oAT9bRk/VBDFRgHCXkfNap+iu3Cg1dwFVL5PxV3XZ91XMZSWFidnqXfnaOZO4xRKyFmiZ5LnvZa8sm'
    'y5i+C7NPF9y65+fIvhjSVVAhhHR8lntQi28Rn3FOr4TeZ8z1MCun3j/Gq2tCDl4fOPo5JC1YiHmZuQLUmy+L85i30AzAz6XiGImZ'
    '+q4QHqIqn3r2yWOfftIQ5y1bZ4zVOv/ltdQRko9xP50oQjKza8e42wnY9jrOVL2CEmYxXjL98Ww47s3m18DFHV3x/MTJ2zDB6Cfg'
    'A9MbOUkXhFSYKLMjdVMnfrVk1CVtu3sOwmshzeCHrO3DJs6sjQhC156OaTWvS3GzEOKj2E2b1NvHDjz6kDPD+JooalLRZ6keclof'
    'HHV02OHPUlHU8Zoge5lcES5htjvkhHLLuRV7zP4KU6bmfsUuKrAlv8XzDqbVPmRa42T3GuG3Zx9kGqDfks/6d9WGj+LU1tHmDXsf'
    'dSaaFSz/pFZd6P/HNh1LYpVQ+au6Hrx9C9aGGqcdD9l75+fnk/ELS81KLVimObfDUOopnaNRfSSPd0j/W08Be5h9Xn9EtdVofAad'
    'dUhKX47uSkdvav5+tkXXkS3+qhog9CMCzYdYfAcIvhWwP+xD8OptGFOET6Dvq3QyaoS0N8bEHq+eTyZuPkcdFI2TI7O3W7Lf+eIX'
    'TWEd1o6ULA8pyP1MulrRBPk7m5y86Rqg/jaW1h3LPE3Q/afJijm/3rRuP4V3VN+aTz4y8fD3ZdL05camW2+VPKH7Ybuc6exxp/we'
    'kpduDYPV0jRPcf5sZ8Mo4ccxrsA1Qq3nsMBifHmFLQ7o8iI7EmpmTjh4c1yFRb+Tpr1iVhEkUlPUhgjS2cKkRRKtSIo2WZIUMoLG'
    'pL5lpHLx9EQmFYmy65zNzuIsp/D1QoSVD6sGbuhsHaUZ1kmiC5swyz49OeeosufVqgl8Ug98G/FpYOql5aFDXyMv4oyZHAuRRqKM'
    'ydHBi86Wz2FgEKGH2Zd3Yc+/fv41rsRdB3FRz1RahxrYjC5YNdzMW6RKdTEv213MU5TBXx/A73lq6dai76Mju/++4fxeOmK0lila'
    'Nsb1G/RnV+EyaoH9g3pgP3cW7sb8KAP/jSQFYyClzM+CroXNlHDYKhcLtYqGk4PNMr8JypILixabUFCdGyzAvA4LUAMFGESgAKpa'
    'maegALKdzObnX8eoAHy93jWF7w7ai2EB9PVe/DrGBZDXgbn5e8ACtONN/n1hAOqt3vqdYWF9E8reU6QDbdkgphk4ami54EKMsAiE'
    'UsAJUf5drE3pRU2Wqbyo4zKFl/sbz61Mkhe5qsZuU0w/uimm3AXTHrlW9HbKdZ/2GErIB2stQdZ1vsYDLcEQwvm6sZjTZDWnyXJO'
    'k/Wc/ooF/dBwEgurOgi/uLKxz0gzbiV0tRnrEjreEr/ih9GMeXGDqssPiW5sV/ViGFKrPmxxw/ldUPevOkTui/jp2hbjXVSWY/bl'
    '363rb9bReiVaL8Of59A5jrATTRHWUuId20h1Y/zIvcIX+plXltXeu8pMe9YSU9WiPUvPoO1iZE+wLa8as55C4MhuwEKFn5CBdQfq'
    'k2lPM7AkEbqF1Ug4cqPmItRs2fFK4bjTHOCbso97oGuNMPFkeHNYXy0deajgIq0gjvAzqvTTBXtOHaBj9pQLPBXu81QooqJqKdRR'
    '7K8zZDR0cXYmPFI/VrlYboBTgqSfKopXuIcQ9EdAxc4bn2lVytXwq/8dfEyAucL2IGHRGdwl99wo5Lcjmf534obSSK5Mx2Uyx7pD'
    '7Pa1eG25QKSVAp0p0F4B2oOYfwZL3sBMt8SmKhguSZKuvxkwuQ7vGTJJgr5MuS/nEskIi34EPDOgP9GbEIBP7ELk41OeId7i6vGi'
    '5pC25+u0/EV4vt14nufduE8MEdXcmjy9PhD9xHV0EnVUz3/o6oSYJRPCkkyIPIJ7KjTBhJT9NFFxivxROSWQfXMbcwfALFPvxDMn'
    'AOkx1AQGpQKNDeDyGzEN7/tx0U1ihwc206Yc/KJKar6UfqR0LS1SmidcAEjzhkQLxsx+RDoax5MahzrPHDKaJcQ+CAEJIgG7XPfW'
    'eaZFIBky9DUKiKWIZgVAFobzRWlZi8P4taH3aApJJ+Rl3sverOYLpGQEdjSdx4f0hODJkBpOJ+W0XJ326jY/T44++BihsGtcKtfb'
    'bvYeXoXTMrZ+1GjXMJjZjPMYQVhXUNAhtNeXOcLFWM1dDnF1/IQ4eF/vk46RqQH3KdwyH+/u7gaudOhg5CklX8+XnNk0waTLXWvA'
    'NKSMTeVoowM4Z/TAQhW9hQZYrqoOfsYd2qt16LO2EG7O7t0DZuUqvOy8BzMg/11/cit+VqOgD1+rdtnUh7+k22GD5B9HRphEkzT5'
    'pc1N680prK9wHtb7Kasylj55hur3P6F2W4NPqliOAV1IohXY/1XLfMe4JvW2VUhpWfy2puNfMY0NMV93qVcinHyCNk7mQPfV9OVO'
    'ATYtVqDMis4KqFlDT4pya2kTLris4X1L/V4CM3xZ97y9VLyaGkZcFJtWOM/7rjlaLRoZpwahyMAXyQNQ8WWAcwyB8jgqLkw+Volg'
    'V6daF+Or7GAh8V7yYBd2wxPzAkySB8mVUo7gkmdJAaCG61pMb2WA0JsUebIult0MtroZFGmm2YP+zalReNGq8hHonC7Po5ZPVH8N'
    'jV+QF+aKRFrV11CxN6uAvVkDFa9CeEQVBdfUYgursDj+A0SdMUtXQ6+Ge+SJBdo/2scfiJVOTlR1TjW4Qek3lczHu70vH3eRZBB5'
    'j/Hfhw0GeECs2G3WdX9zGD4SPtcDqRAXfhkHURHKsDJHloWPHb+Mw6iszLotmCrt+m+6mfXfdR7/eSwjSDsTZp/Kj0vCLpg3ZRzQ'
    'Y298w8lMP3SYBvuPdm2uH+7mrTqHL03lkPZiFE9EmUzjI+3NKJ6GegnfK+fTJZXTBTe4pQo3AuNb4kUeSDP9PeAlagTkSp6bkzft'
    'qjtSzFsCIxmZHJbmtaw8HIva/j8h1rw19sSd+ufZxdX52HCy5FCOyuJ8WUxNmjQvsBKw0tVaScJYWgOIOtDF6UkG9F4yxYXQiBuE'
    's07B7KEzwuFcajvmmObdzjTwohytnaqdvmiudSvc6qlGek4nGLi8rbgvdnc/lrvFlPGArdLPnvm3UYIGg/uLUsEmWJ0+JVPTNG8c'
    '2yw/CT7AZ9Lhi74ztcDGEhQS2dmkXDh4b7np3sT5HCdFdTFuKPKjizuVl5qM2qzOFJr2hKhd7fwPIwK1YT0xCGaVz04ie/bnroAz'
    'f0WQCB/PcoUKZzQTWzVpaJuty1OqOhOsBQuvQj+92GY4ykkco3OkykQ+nJTAIYf44mKtceSglHfAiIBo/zicih1Akjv2P6/5oNqe'
    'qPLNQCZpbE/1qbE9voVR5JH1cLcxYNtfLl8AwDlMhtMMfleLaqzQCGp81Mw/qwvkUNW8elWtw28a8LXXBYag2cmjSxapEQhtgEtZ'
    '5qA+8sV8PmFd0DF5iS623ryvAglto5k52hiMzzROkI5UrhpU3q25i+WtsFTvsXzvW9HInOxoTWwrhsdRj8kKj47kzs49Wa5Dlem3'
    '8YYNKEHI/kfpeEAPJp0hEj3VRo7mCBl2YX4GMMITsLMTt0PSr3Tfz8lBE1NNoThbpseJxwjFeO9uGR1sfTis5GnbBCB3WmPpqYOV'
    'feFxUyzy6n1Xu3O7YRiRwHA3mMrniqZSP1VaFYM0WR//Yp3213pzFhj3lQGTkZr4gE396UBX2rFhf01Wl1dY1gT4xIcgMj+nBjFT'
    'bqFaoLgpK6YvtavPQHVQ+0GcqcJyLTDWMQ5IrOaT9+MftbmqozEAe3fYoDdnMHr8b8hg9G9NQfn3SEAZx/k673IX5Ot8z2uwqptS'
    'VWIa48yxdyaprBdeJ5jR0oZLqyw1KPmob/K2THZRvDyqwMdHQBulGQcHFX66ZKJp9N0DcNiuBc+HDxCOJT1q+WjNj2pR4Zhpu+KK'
    '3D6334PcnIaFqRXKNjDPvqpwVRQaSTJlzvbiQCOKDtEh/T1Q/lTfDw5Ua+zeDzYdrxTR6LMH97Md/7+snBZQb0ZP7j/4jMbe61k1'
    'LBQ4ubCMSV/u7i5uqEkdTwfgW6FaEAm4yP7pDy+zzutXv9O03pZ0nHVDbzmRZ1ew1IoAO6tID4drYUuLaj0bZtFJLEbf45uOXPbj'
    'JDx4iVtRGukNpdBqrJF/8ltLYmwI8Ug0FNNzu5S1SseVTc971RIaTqlTHxXXRcnyvZGw6iNf1I4+jNd4OStkGovJT4jTw1YUJlrY'
    'm4v07XdjCujudVVz8ZQJlB3vr/PZNWpI3Ueuk1Rd3RhhQLoi65zHIBIthS60UFwnhjuaD68Qk2Iz+M2EESqdLbld3xfVlvDgQ41B'
    'RFY6/LjQoRxmF0lVKxynIVjKF3IEEcK4tT/acs2tbnrIU6JTLvPSxYGS/y8DvUgBXliNFJeKWPpr2UadqHAP+ypwysVkcVF4IpoS'
    '0IcGU3ITCCiOxSO9tBY3iHp8Cq92yHmuIhIKx4XUAqJlg/St4JGMdTVH57DbtrilHyxm51tMKdJ89fNifL6lMn6uIzEzCXwAeRA+'
    'cB8vx+/nl9E+lt2Yqz947VBUNj+8Y8O5aN/uupVr5yiIIxv9ESOPRJN8tT7570Fw2Nzgrunpjf/yDZHUVvNCuKst9gRqTiEYf/vr'
    'f3Hu6lCFMSDZXOe02Ep4sEGx1P10K6wfXIY+uKpekD0XEZBDVOM1p32rfe7k9LPaVzjVC0xgsfqvM4kIRntxUU5GodkPrP423zyN'
    'v3y8dWI+03xkyCOKbsohSQm7nxm85Y4qq1fja3euYCWSwRUTnR4bqXGq0DWW533bH2jDvhYyNysW/ew/vvnxlTDMQHUsz9bw5zQ/'
    'M8pkWrGFvJs7cB5VxpSMLHNgTc+XKrA7YzaLRS9VBowZq9ihXA6YXDxcedMO22dnQggNjM6eyBF7M56o3vQP2JyduHkjKt2s5aHT'
    'XPjgP52W4dWyQi4yFSKlU7Frtgvi+IbVxb7lfmfVA/fVnm+va5kwGKpPvw+NKu/MLFDzfTm+7l1G4RLJpXHew5DOe5MLkKn0DRFh'
    'HnWzvcd027/U+6bDmC0fLaRF4eHyhCihUUtDMFBq7JciKiWYPH4kTa7WQjqDCx0q4T+T4BeQZot0y7Rawx/XMdZnq352+sUHDhPs'
    '20yDTaUq2tpvFzenXWCRhVLo0HBthS58IdbHq49Fr/VLvf745EKfAP8AlI3PzntnCGm7DK9+sg/kzbUVRofxoFwVk3Iog9/Sv7Zk'
    'ArZmiB2ZbHW9Iu270CInw9e+ULdbvmnMvQ0HQ8m+tOHc5i2RDCRUGq7QTAa3ee/h+NnLg4giOL1P/Sw6/jvZuLpl7ZRbF46ycQ8E'
    'RaYiOVjLMSF8Og/+VG1/8aCbbeldQLu0ZSmLTrxGxknFPaE7U0Vp+HyGO8gJRiTZPRIqj0RWDISHnQNDB/whQgL62Wg5X6i9bMb0'
    'BzSrGAQmexShEeSRcKIBIR8+HgiSxG14uV0vV+fwewA2jdFC2BuAkyBRlZfVuIN4rTerYnjZW8wXHS9j34YgmJmjpDq1eqfwjc6F'
    'fx/P2JEujOzILbvF/DTbvIG62Kcg36Fyt3esGDxN6sVyYq/4jkNPOu7hvuA9aM8tzcm0WF5+XS5X645ekjJtP5WX5R/GZ1VHa+ta'
    'A3mI8otpPv0KtPd5LaLE9picpG/ey0S/LKvVeCbfbZWzxdVKODbLQJ3SWT+f0Q6N728ctI01DyZXS19xzCzc9dHleI2oFvlu7Ox1'
    'Ml9Cxl7L/izOubfCYMc9Ka/xGt+ItLYQxkCGMO4tcPvNVl+Pz4qryUoDJnz7mmiVk8e9Ua9IuPrlFg+StAzd0e/H60+o9o4q3xaD'
    'jR3z2iZPZuijmFYcRUfJlCljxRg2YYJkMmpsEIg91bRIILaBAVrNf5ovpZZEzIQBtHp/DpnkKwhT0pkXk1L6+we5jRxbEaJfZYhD'
    'vv5P8C3r4UrKtHXFtdMbWI12rugfWRSpt6zkOpSsBaANBvMbYw/+Hh6F9TijkIyy3XO+hbHQM/93cB9kPX8fF8Lbz5puPikwEECB'
    'XgJkp/JDbQ5hYC6sm4egLn2DOzwgB+bFurn76uY32Nz912asutSMoTVb7Z75h+86//CAnTO7zAbza5rNrhDHM1Jk3ShMeFEOZetS'
    'xIqWO8lryXCW3Y3LrKCNT1pnR9NcPmmdF0WCfNI6I5oP84mfi/h83aiVAlVc9zOPLSZsmgWV6oFhMtcxT+u31MYadxDxP6sEbI5Z'
    '43i4uky4jiOvp5PKnW72XfLQdDo72SMaTZOmfvKaye/4l3NXE5FtUpTqzLGW/sn5P+8RIf3cMi8XgxzRqBBBVQktt71R9dBCzI4Z'
    'jYgVSr1HkW1olw4F/uVPAB0dkJff2wes43f64MIeGP9g7DNGoux4J93nwl4GQcK46EPWte8QScKGTgoXi8Vk/c/ysxaaOhORTLbb'
    'Qm64m+HkajTm7a/rY6vvUAChzgpeK7xU9JNeOeO/lgSyLbCijZolzgjniQe6gqnM6MJ+GMX/PKqVWrPU2kq5OJ9HB57rrt1FBrNo'
    'YLfgKyM8s9rlZKFYlz/MOSnKKHI/fcgUxQwB9sLSaXLG4cV8XjlvgJDljrRgNY9iV8G0Aj+nY5H3wnNqVefKy9dkAS3l8j26QAXV'
    'SKic3NYiv6LL09bH41+jUcZD64deUXEgPT/HxSlyIDgkwnZu4dsSCjjP/7uPvMpJLm1hKlunJesIo0R/W/Lr+Va6OfUpJ8tu3tp6'
    'tPRqOYaivdaxLzpb/6AWrPVW3qPf4Hdvf3gp1YDNjtUBwhHJIWGTi5hKFZSdXPuKNnh3zadPF7JRs9HhvR+++FD0bm67+Gd9m738'
    '4sNCf8oGvr0HDdjk8N5MJKB7cCqbX44P733x4e133/zwzZtjObdvL8bT8UlP9smtK7BDAfnw3n7vsX80KoArsSzWh/d+k4XHkGWF'
    'Fz28R0p378Gz0xZplON18AQJLkQy4hBir2vi1hzYD5a4Umgvfx0agkOgmPCYjA4bnEgGY4fAGmz6dLBWAg03B43ORaQa/bhH5dnZ'
    'mB57E+UhDpybOM71/FrbUcOkS5+gsDSV3BDkNAkcHhCrerUA8IgDRgz0TESO70cKquMxDQ24UvVwemBk0LcWT4+5MRWtyZMNbIDM'
    'nY2XHH4v+6dKvdfhtios3uyKh0J1sxfza0i7k/n8stpqo2rT+ZV8nlIvXJhNeYZJwsfLukyjAoKh7UJa3P10+AGg+/8gHTZDbB1j'
    'pE0OXxT6h98/bpN5HiohphpJgBQB9K6FkgAf1LA7xj0hrCIq9NgjzO0xbBY7slTOHhLvdRG0t1e0alRj2NRF4iaFjS8lxwVFsKSb'
    'WuG2AGU/CZRwQk+2QO+3J5Vv0JfvZiYAYsHkzWtdoRfFAuyhrIot2fcjnz80hj6Z3TV04XvGVdShGaF6dE9uz8LoWe4g2rp6182F'
    '83mFV50KKJstrS9K5gXY1L5Q5qh1FNb2V99C6fu2OOcz3w0p3trK5PIjEx/P+aUN0UayPblM5jw5kpHqoNmqqVzaWx2Pzscn8c0a'
    'TawcZ9ciijXntaVVJzkwxwwodh9f1e520ABDLQhq5PO75p+wI1E/V1QA1dBItlfnYQn4qnU+PnrGunRhDpJ8V1F2sq+LlSHy1Mjr'
    'pjMYio0GEwPrEdZN6CXM4D3Coj7WhHvuWakwGeoiGPlhxSoBX/hGKF8k//vnDHd8ouhG+kjhavrsh/oOSF+6pPoiEPnKKReFKr2V'
    'RT6L9Z50XDQ+ziw+MtNeQ4Pt4997vQq5w4UrJ4+JCL3Ig2jDIEndLeNRP8UXbyFmaU8wX+NeMXFaJXWqnay2ydsqFnrEtpnDJ29m'
    'SwsjzMlnQXVql177ftdynh5iGpX46YuPE8CPDsdN98bONIImglINGVBwr/e9q6OPY+BkcC+sF2MaC0bjLd0HHE4/Wzh7HLwdGadH'
    '59qSgTk5thz/XZ/kd9jnLANw35n/TLxKOuT80uJJTbTK9b7KZStdrdL9WsUbFhivfRM9Acbad5LlrV+xJt8v1c48e42F+JTlg0x2'
    'J2OC8dcZk8AcxMx5oDOp5FFnXPCsh6lQ3Sdmw20SL2yzzHvI2TG94NPq5iDI2VpuHZX7oy9njlixmN3KRdRp5MjlD3EVYT95Ny+V'
    'cKMX62SwPfWzSmme86930r8QtUfxrEQfBgNRAool1A2QWGC3WNhZDnQrAweLqUMPbE8DC4vpQ5NLW0joD+rWWVb4o/NK18KFqRls'
    'kTNFYnX2IgdUfB9hS6nX6QC88fKcMToRNVppekIPTALcK98+zCBex8Ee2LHKdTLmi7e80+BaI5+qS7lzMg99NpOQEAl73W+D/Moj'
    'PZc8/Vo+7kSyvNvKRz3dqnX8OetobW87MDakQXY3XSqIytr4B3b+zTPnV4ngye3fYJs/xi23HkW7z+0QHTgq9TEhPqEyPM56lrE2'
    'SoUJwTnqNZzr9Oz7xa3dDxu3e8tej7d58E3S7SD9wSUQGrIZsWn/w3inWK0QKDwKhNJf+O3AjbLKr1it33Kfe+0PbvY/j380X+a4'
    'kOMH0JNFlM8JRgXU36e7ylZFRx9IUDSi1g+AW46aiXD0KSbCO/Dj7iT5VwsQfD0rH7sedIt+Qvnri7GWC1a7hq3rk6RTmdIfkT/y'
    'h2LYha5wRw4D/OGr4VL4Z3BeUtzST0KdKOVwBxwgNYxmGxMObsbMksPVcrLNjuWIE/zb//p/bmst2Z/n8ylxqDUgA3WovQ+fgDPR'
    'X9PxqjA2za6uHfAvo/FkVfwnf02FZ388aL2OIiL9EQtbV711m3Y188ptWNHCSb/ch2/BpJgiwwNvIXNUGd8sOjuug/DbDaM80iwE'
    'cMjd3d17DM9K1aI/THXjTGrV4X+dde8+GnSGu+jGZoKsDv/rzHttRbGfL/ebanK4iQFfq3w/NqYsUwPng+xrOiiou+5cE3MaaUWu'
    'z/F0sVpH6TRUa+FsPlowZ7hokfWqRYm4Xji2gQ5D7CbEiRLF5uYG7YTK0e/vVktuK9dG8qAElSO5qwkmHfIW800UOtR4Z3XzxUdO'
    '4yc0EGHWcvNBcHwLF+az8RIBSWNgDXj+6Kx+G5zx6lA+qvqpXF04J9Gtms21zqIpR+GYCKPweHgU3EGVKehmZ3BETRwdifPZhYBw'
    'FjPr6NGDP/X+XC6+eFD2kDRTOggfC+nM1Uwed87yHrITd8rpYr5c/XPB2EG6JHbGy6Xmg8Qtc49+iWCPglvie5TuZ/fAqi6XQjmq'
    'Svqj7ASbxyb7Vqasc2ZsS02lOJwvhOxg86/GTXf0FyBlLxyIBqM8TP6M81rFID4O+UP4GPrk0XusgopghX/sZCDxEVA/iQ/yWYCl'
    'i2w2kDfznvbgn7V/xJGk87vFjZmJtdanA/3oDcS98Ck85NESEYkQJhYwSuQsIoLTs5kRhKQm6b0aVOqmWPUMDKBcaL4DIRVzJBAG'
    '2lGGuPcZsqYAhPFqpXnlq3norxsFyIg2JWSoYsYdTpb6QLlvddpHKpxjMTU7i6+EaYUrp2fvfaab+sXL71//y9s/vv4GNg9QuXLI'
    'O+/BzY7Snx0LXt06oOULY/EQ7fjxVn1vtra62tTbckowghpCNTbOVxxWA+a2LZqQrmiG3lIP2lt6cOSg7pQTVRmcgJey40RfIlBf'
    'cSuNXiA/GtxUENA608tyCXDxmV6SS8CKmzltdpAk99Edd2dGowjfZ0L9Ke5oHYfB/ShjXn+KfFQhhVW9txNLg6Vz/4FYKH2qGTjw'
    'rvXs1hWyNbGN8eOZmyyHViFFEmNPXFAzsewmlt7jrT+ttuDzNy5WyBm/bX4+dLyKfQHv/2km/3lw3s22sq3c+a4JK771t7/+65Zi'
    'NjDkbkzPoAAOEXpwqZwzg3YcoMPWn2ZbDkf2ezs1FtXcWRUDApzyUq3MHCS/HUjqAOANKxaZXU0HBHoZjAGkIQeNM4oAOncown6V'
    'N9/KUjH9E53Zor3qAqprw19y4DLuSo7RSnud7ImJzUgeQCse7+5GWcEiJ1xv001Vn26nH59Qx+RZbs2zjAd9EV04R1BEnTiiR+4h'
    'JOiKI69BO1zwdXrjaT0G3COLhTvmwX/GCudItBFGvtIll/9tOck9VqmZfx5r0RkI3/7nzvHO/e2//fX/+tv/8a9/+9//n7/99f8+'
    '+cufRtvHvfwk/1O1/cBm1M0XEWy0brWvdzhopy6Qc6W/ZaPu7KGXgEDSceT2in6ZqcbP7vEq6bs+MZgFKiVJdUNcbtdQQvpZ0oej'
    'tAt7JyYVdzXaFAfXR/RWQZqKVy1PlUOEmnJdjEP3nUcqZX8veavpdRGFV+95HW6Fy7eY0N45UaSy80K1JXKD2i0XYvr1ktHrntBZ'
    'cqiq8a+cuz5vibb5o8r5tgkHpW5RMpQ8W/mhGip55IXUTg/7PCSaJBT6LNcJ/G3hPjS4LpgifDifMPv76+cvv3n79htjGWtNuMLt'
    'TaXVk1q9uBjLETVC0ymhuloTxcflE9V73e7YPDARSDmKu12OLe507HRA8KK68SihU+NiJsLZojOM/MSfw97fKyv+2xke9djZfANN'
    'Gay/H/F4VsxXZ9cbOvjNTI6r3HEdvhM6fnyiRPuGauybI87EzUmcpnGUeEZ/0Hnqs5HO0Drip82e6v0pO6CrQRrhyrcvAjDF9uyo'
    '58AEUpJYu5atqeS8oHLeuDNfh+ZXYBvMbmnnyvRpwx4WvjlxtX2hxep7ot4hHaXbksMeozDRSrw7h+bNbI/9TnrNM2g7SY+pGt2y'
    'DjrVV04X0xbZeShKBm1pCYxMcrPMEUvIRqKKl6ORCJ49tAO0KMLsGeNopz6As1vbF57hRKreyFMGn+mG7FoPu75SbdOuUmoCwu71'
    'izGsuzO9MmOWtbcer7wZ1EvXJFMiKVQmhKhYqLD/7FIsJ2poqdtawYOtvuwHdQrsJ+co+noDObY6hPgfS3tBAI0o86aBlmGWi1Wk'
    'mo0G8smJC3gZJMpOVSXqsygFhE9m0PLO+Au0z/6pYsNyPJu04jIzEPgv5ukd7AxMXJfkYJNpJDaguyGnhXkatvlCO+qhTgtOF486'
    'c8XcMwCVbuKhk99ZVTDD+sXXCtPQ9eiyQ0sRVAslYjDlzN6Z8u0I8kJ33DUXPjXtLJAo9O5zaa+tY+ZJhMoPOCl6l+J3m0PyRMdk'
    'ZNShq9QFDv8I0kYNKK7FranNsallkBMbJNoJQ7R2IS3HD+FL5q9e9ZeHk3xtox6Gjar0Ikpzc4wndH59tKvkRH2T9b72OpS0psSj'
    'vFPzJDYv2XpEgPlIdxouxlHxKCwgNnPUGw8ITobeRPfwXUWphr4YPrI6ROhjGRbNMGhgoONv9kWEU/iURzZDZlFvOy4R3xQvs0Mc'
    '1tVgNm7A0Oj5DcL3LCD1Mah7FVmbWqc1iyifGfdnvcuSYFVC++pMKrl0eawlXIoUDWaJSIM9Fa4RN9qWg1/wKVfAvsYAFLN6hbkU'
    'ctiI3gF7Z49SqDMzGvmeKkS3kRROAFkOe661yGG1tCnbIZ0md5zvEwvGndLrHGs58yzmH3788e2/fPv9y5cHjX5zpOg3kWyhV8Hn'
    'W7IppL+D+TVEUlsf5x1kyedBZSPnjgxxrYfOQ186rJvFiQT35cCY237rO58LLnYhSCEJV7FhK9kB+uYgzArGF8q5JQGtUZuVYxOi'
    'jWfpRGVoTtEb6fFivToR21bMKgo3Tl6YLLYFdN7J/EoOhZSdQFS+uBqQBax8LiKbVoKv+Ui5jl+qw2ixmFoaUJqzOFUOrnAWtpun'
    'rL67GsBF+Ijje8FXyfgy4BPyEz9ULhUX4dWYCRwBdqmLws2qAzppAeOmm0Cxop9AcA+QB2s+aAEpp7qD9UXmzACnF6Pp8VvbG7x+'
    'fFfa7qCZJh2CQ4buaupwRehez4ZwF2RuWIQneWN+ucyOj3m/nJxkNOVlnt2pgDsNvXeUi8rIlpfB8jY3nnqk4YaERWlMfxSGXlnm'
    'cGXJePXGrgigS2TFR/K3AbrKip7asy8+RF/curGcOuXV22BpL0yqPp87nrofaaeFkzYzUI2jx5hmgU10umynzlUVrLPbmokmOJAp'
    '64ch0kgx8d4KQZ68WpmaNlZ4VTzxqrM9iAyS5axTbfTaqHO3zz0OoqJAFfRbBDoRfJudkNJXjqq0tLxmUpDaV+Ni5Lh67Ieq1+ZU'
    'ho/fsr1I45xHDmWyF6CiRrYqNSW9sSkM+IYrJ99crTKaowiKDnd8Au1FCv1YiTq6UuX5+M6Zi3pVOWoXiUwTZpZ12HuZcYci7vhc'
    'Qw4CIipTBbeL21TjbjMBrINEgTmLxB9bsh1gtc40mZ9utVeweidCksfxTWVj6HcjSWUrHJ/TLz5gEuXMvLha8Sp/QRlu6za798UH'
    'tHaLf6XAKSU4+dsdGjx+puet4pfyjbPBnOpvPVYOXNKW5Pvz2XypTrqKQShC/TcTF/ouXXXR8fiz5rd61Ots/YOZnhhxrEK5zHzR'
    'taMmtBmSAVXQ5aoYmB+tx+1pGjmxDnXftXpv4Qwk/XGb+fMQNPE5isYmy3aPBZrctUpA3YDiEarHm3e6dcdC1nvnt2Q9Hgj9L+Ep'
    '6OwKZhe8a8CM1P4fbLwMX8Q5/b0KtRbDdsc0qLD+8YlI3KGQj8uRp2BOi7VrwPE6rI+hS9M3uIYOChyp2dsUdid6eJlr/C5jtzeI'
    'bwoCN3Lujdtmwj6zmHKXlMDdxMTt4ZMIHkG7d15fLiUi+JIuCA5iJ1KBqwkh/TxeMa1hK2iRnNKTPeDncJRzujVvJjtSjVq/hrbQ'
    'Yv/pm+Fs055MNF/RRdzJu9HWkV5K1xLVX7up/XK8VqPxhtj4WfHe+3RuuG9akmqP2tJp3xVvnqpGyMC2qUbe3xAg48ahcL936DJE'
    '3O4aGuQhyt0H17qNEvIXEjuNlwuPVj6oOlqEvjkschN5O2o1LpqXXz6zupEr+3F75zTjyaEV3Nbv7mf7oV4t8VTmh1mrKbjikc9Z'
    'PQtYFkT1HVdR0Izhb6YhHClH6VAz30zlzrygelU4vKJymfgKxcYEw19FTkMVBJXhfCrLhMuGUcjVcAmPh06SOvMC3PPwohSRv2fE'
    'St3Vmqb4FHOpxhVsSEikWnIS6Bb/zeOhrPhwDfUM4FOOequ5S0IDoTnkd3bQvuVopwjZtItyyn2oDgsl3BEvhNnT5PDawicHgHcz'
    'RCdCNTSYr1YMVfxOdhLCMTFF1Vbem5+dCQnz8eLAUGpDYqKuyOMWdYYxeILiLTG+PimxnZQIda19XYRbGsYAClrXeq9eYjsp0YKa'
    'PpnDB0kGXM6gOL0hs39RInRljqxvBXo8Bdxt1sE/21rIYsKlzLaU1t+WSWcOWN++A2K1DC59VPfUKsJ/WX8fLWkjR9aUPOhnUU5t'
    'yqYKa+vSGU4Ryi+dyk1Q1bea5JBvddEi1/0baoVA4z6SzTlxz7SZuvHrg9AGP8HdDZnB/83pwPcZwv+xXODeYbFSf3nk3I58Eyt1'
    'mufTRuyAiuThaDMVt6zAXQmz+2m+7ejrO5N2O85aY7++YsphB5ODaVtZ1L8c7IG+RCSqCPi9s2vp1W8AsotrLa7le4XY2lRP6V5/'
    '7v9O8lJH9SkUAziCtorsnTqaduy3VLUL1Z2Q2J2HBOVqVn4HP9eC+dMO7oMd6+uRCV6uVcScSyU9xPD2RcToHKtEcpLTzTCJl008'
    'chUlPhZi/FEIURF4vwAy44VIUZpBWfVb0rfKd3STsLOVt1TJN9gscsPdVevd0pQTmhS/KW9eHdO5xlM6Z1/WYx7NSpc5wY4goDj0'
    'cDEI0iZ2lSP4cTGeGUMnndKwVRyJEMTaMt/SSqo4Z6jppVxrL+fXCGKqxjGk5sS68+eNXUmiyeAtzz7And4BMkWmC1fdemszI37n'
    'h0NuQa8Z8br6jcoRhZbwGmWz7a5N+QFvU2o/qpryo7Xxm/bGI73SQfuH77e8kwqBcKgd0x4gF5JsvgPNclBqEp/Bcn5djZeWHdOC'
    '+RkNPnMq8FhgC0vgoaA3CVupI2OkMFKqVVfXbGL15e9976y0YalGG9c4UidtXOjq0zYcUts9122PP++ocL6xwjnP0cYPx5/Wk/EN'
    'fJZ/VGc/dkifvH71u5bKre4HG+uuRSxv7t7gI1Xgdrvj8/Ijn+u1tnkEhwxHsh/bdxxr3FOdvY317Hzs053N3+5u/FadJM5KQMIo'
    'ClMKtRxbNv2SWOxJiBC+Q2GgTuUejc+qqit/9NY0e7O9PMHTTkLto5n8dp+/Opephj7pmZdj2/pn0fXeIRxt9zV0N7te6sXGbJTA'
    'FMk6b+Bi2s2+3aeukt2hNtH8zPFHlceeaXhJTDM3WLnRGn291Kg1+X9HWac5Az1tnMoNcC+XenEYNG/L2twF4+fDx52CIAk8+6Rb'
    'Vap4o8FjnQ3ff02zX7xQXxXDS/rn3rF/Y1X8ppptwe1XtpnmEET1riEGGMY0lDhBsQmfnRkwRZ6gVKjO3SykCYDEZmiH29b+PF/K'
    'ZfZyfLbazMwU72m63t0wItbwB4i0d1bxsRr+aXHn57vI9nbX90BH+FgNzQruOL8badbEBRHYchMQwYwjauJSRzo5MZsQKOUyxAn/'
    'n0igGJPnYq5UZWkpYjWYi7kURnCTaoS9wKrnoiQq2lD6nlWmRUX97i6c3x0HDh6Hbp0sQXQjpqC11/je28Rix3ShEG/L1WQcQVKD'
    'aKzwzFvc/BOv0y3VnhMw2OxB5MTd6+jo//JzNZ/lXzwoPayvqYeKKf0sna3P+0d0pjrVoFH/NGO7o9QLHvZac333oDOozS3800OR'
    'jr2PZfxGTUD6yDuByx60wIBuRqK4RYq8BXxpllTXa0i++Jn68p6q4Smqbj+u7dYZouJeALmZWFSnQS6uJlfnXpLthGUJM3r8n/90'
    '/aed7GTbxQXEqMl8toMgiVio4BzWAm/+f+LeZb2NLEkT3MdTuBiqhEMCwYsUSiV4G0qiQqqURI1IZWQ1xRAdgJNEErd0B3hJkvnl'
    'ajbTi/lmMTOLmU0vejHzAL3vR8knGfvN7NzcHSAVEVVdUSnC3c/92LFjd6MlYyCDEliSzY00ATdL+SVBkOaxRMlopRm92d3bbxnr'
    '4fNewuC2J8D9ymSjG485+TFdb1OkI80QY5zTjEqCOqQEifYIJqMl+UPwuxSBoQK090cnuclnqaQ4249Gq83o5Wk2GvSmOA1wJov2'
    'rogkHkTbnQ4MNLc/vpWST5rRR8juI/DV/VECpw+xdAa3GMWve1l6PLq0rhzBWFt2TBIDgENDpZxEVTyYjEocS4FsGUSAjC6aex/f'
    'vtr59BUvjSiB6n/ssSPFAy5L+KeWn44u0D6Gj48gPGig0oipOOYP+1dj8ci4jrpp3sl6Y/Teimq63GYbG1FC8x9PWoTSAk8rHLda'
    'KzqoKfapHeKWODS9vH77bufr3v7uJ3bRCmGjheVSzyz8/Jhw/HiR9V8kGe3+K7O25Yibzk37XEM+AN128QayMsKytAqsBWYM6kIV'
    '2te+8FhESnQOtgT1AJQNllHUIDm2nUOZCwrRZnwOKS01gKbgLDQczMmIknPIDph6Tu4shZ6GA3Ei/SDjrA1pAHg5YSsd1uhi5eir'
    'hHSbhMXpRW2NX4cVav/8x38xH3jWG26impW8JqGDaIoGATANRjRBPBywfU8sa74VHVA7cBc5UIv6YEFcBxq2YaTht4UtNssK8bGF'
    'ha3o6Mvw4bV5vhXNeV2j1smSmWbtKDCnSHTu7Os1Y0+3Zn0RjIwsIq6RWoh8rJ4OJ66uqkKc3P7eZJTB4xdaRkIasQP/kkr32sJ8'
    'w/bdUPi9rYd6RB98iYSDi+uQi4/9IyOCrshJTOxkFTT8U4aa8uKNqSb1/QAIVrTi3+ByIuN2f9QWm4tiRMlZ4JzI1iVNugyOZ+Ra'
    'Qqug05tdd/Jl7Ak0JR2Nz1gSa1Tlu5GORJCx7MmECdn32L9DPQ2lhcL2TEa8zBLBSNZ3xcpvbQu2NgydXtDY44Og9bh+2HBRi0p4'
    'k6W2hYQyybgXjxkq2iNWM1zfBirSicTC2CgCJVNo5ms25RAjTbnwwOFx+j86dOyhIrRjzSQ9yJzCO7PJaY5TOMzJSK6jQUq3WJfm'
    '8JFAvtZgFVea5XwdKD5ZxF1Sq5om0Qp/XpTRLu7TFuHCwNEh6oEeoluZail6FF5yfl+xGta8NdT6nsySRRh0WV/w6u8QBZ/FugAe'
    'p46kHslkmjN9/nT5Sf1b2jBMNj6yUFEVltSAITdMqvMz6FIYl02Stt2uv7hkP02sRWy83ZXyuoYr+yhr2Z279Rx7suboDKjpL00u'
    'VC+NVD+gjJmmWn1YgvEvary3A5KLRqYmpAnGN0zVgxZAMhkFJIqZXs7OIwmBw4VJM+wZmfWNBRwMAdFNDEm12LuiM5i/QrZQb0Zv'
    'j4P2tWFxg5TCsAicIPgijycGEyEkCzv9sAicMwR9Z6W8A6K0qCnk9ZSkGQ3JkEON5aA1kYxebO+wccdJj4Ob0ExxxYl34AihV5Uq'
    '1SURfoYaYqdzojORnBZDkkPUvqKiQE0qYEn7x40oM26IydAAiGXMbESnpN302S20e0Y0lbq3s5uS0KKIhz/kpWGFuuuOdRPGhFJU'
    '5dTTj9gBm1+JXnySBfFCL8OGAW7/Fa7tPOft8VgJIlsOUAbGdW80zYjsry0RZlrir1t8bjdwWadDpLP7/OntS9oMGgbheXeyBZS5'
    'SpO+Mahu2CwYDOLBYOuM/KQjiY4RHJZrRgUq+DphZpQaZBevJCJg7UzHW/5V6Z9yy26a5aIjU+jbyQvdkppIYjJt0Q3FlrihnTon'
    'Eho27vUCZbUwGznzlir3fsGCf2TkLqJqwKbBJoT7MngyRqDMr2AUXoQg2B40F8JxvUCOs4oMVkr+Z6M2W5Xw7WP2hJcWYzUw3Iax'
    'hnJiPLAtdgQFRgNWGIxwtbNGww5Ws/YWoF9Ei3LJYB9i/5apLdUanN+GMANHIlyktcrSGqdlH505T407Vr32yZxh6hlO+74zw5yk'
    'alF03J/mp55KzQ/uaHGpZc7kQJrvt6HJV0Cd8DJ7jt+3Beol/F7KLgc5bro/ioU08+mAC3uxyDelpH7KxK5TxiYFLprcTGwpE5Ys'
    'mm8eTBvaUlsUEtOnLf0gz3vMJdSU6/0gxgvl1IKssuFxi6QeL+7hBOjS5hk6G5ytoV/rNjyGo1cc6sglxM8107gtj8yG/V0rKhBo'
    'TGCYmWc66ayJuk4JUJqzFLS6BiOleqP7ZJIMyBrrJnoF/FR8CHxTtwn5vMg2zHe6/HyYlmY3ZGGBGBzpZRaJAsRLb2H0ZjM2hVVq'
    '37wtSoNOT4gznEiaLMNj0PYsfVEhgIv+Y5mqLVeyxdKnmBkrIzUIOaprhywC351Zu72Y5LzhdmBz9tr3lcmaIjLvm1jHM6CgYvv1'
    'y61igDu2co5SSgU4waSr4UeeysKd2Jv4B5bfeusA1oPIdF/ac1u3wwmHzVufyexVLN4eZROmNWv1wNDglnlwZQU9xNJwfQcoJXwr'
    '61MQ8RDrbn7rKjs4a835BiiK9vUYEPeQsGkcnQu+KVXKiFjyLNhLo1E2Q54o8F8SPAkNUDpEolO2dEUJcOeALKrWNOVUCIPoUkdE'
    'UCghO0rQWLV1vwDirKhwV8NmlUSFsw/iwemhnVe5ifjagN1vJ1YkHpIZKJUveifZXs5u6WRg+ucU1pwMhHWhFwClp+HtZm/yX3Ug'
    'QJ2wTLPuZBWVcKNBylhqVBz1sR3jsbtjbG2/vIDHPQRByuZ32dYebu9ZeMWqWb5n6D4xXGQk5RXR/4lYJSSHQwXEFWfx1p92Pu29'
    '3f2w5jc16NEIJ2IwX3XZ+XpmC7rMq+EsEK/2Ib1IMywTr7XuNGGIfU9YyGwh+9yzqou5dBrquQwSHF94xiGwTxNCBNMxjcsPS1jT'
    'DlrRwj7scTRiCWjzJMoDkF0ItNYzL8qAniwENQBT/FHyL3klJCsj/M5F8MQrp6pCVVqJ42CV3+AcX0EJr7rd7xtpXhDTVC0mylLF'
    'gOQjJiJ9MxqkfpYPgYut6GhXuAP1iGro6nZNjBgFILMrMSs+jCAKVgfCMLOnIBtC1lnMq60arRifJO98VTjusLzahY/0gyqqaZ8N'
    'p+hemey/tdqacR/xowhGxntGxRZdeJ2wVsgyVCHy99lpvf/ewiKB+omLjC94zHuxvA1kegeDIPyZxN60ghS1IAukUKkn3sGdJuqj'
    'KjcfukQJf7tlE2NLpDXs8e0KfbYdazA7Jpx5QMg5JtvtyTBqsL8kIpaZuu/CS/E4xDaB6PykJDqv19eca48nwj5umoc1X9Qtrz+w'
    '0Niog46b/GutyKupGSeb/ypvR9zvqY0W9j2AYSNuPq4/XJKsUmU4ePBgYA08DWojLEXTuTIqk70JkKEgZ0SRsp3hpA2N3XdUIBEW'
    '8dVjZLppSdYyOFg5BFUrQTU5fuY9SIhGFMTaLAXThMJhJsgIez9l6igEG1lsZdOE6q+yfqiwZRA7ulb08cOPYrEg4g+I5018yNBu'
    'QUM/9Uft/dELQunPnsKRhR6NLP4jdLgEWhm0m5sBNYbP2LpPLMJmdh8eTULsybGjWrR29C8N2VgCNGqIhsalEZJ0O4cTl6eyuBVN'
    't+h1hzoljX6FBBaskGYaVfTPVrHtJK4sKLnosSLYENfNKuZthxv3VDAIUjTszqFG72SjZLwhF9Xy2jYcldTzV14W4A7WSjmoHbMq'
    'ARMVmI/P46iWpkMgOLpF6AJjn/sbGTfTm3XDdfoAze67aN8JqABbWcpXf4EJoGspHSYSD5UK65rA0PNOwrpKL+ZJS4KJK1kXZJkq'
    '0Ynj4QkrlEbjSV7SAo1F5Y8LkcpxLjW6OfgyYxE4I0LUbMoDDA2lzoZESoW9nsnCFgl76DH40ABOx+xGRoc+VgkyN1WQjpWzXY75'
    'HMGH6SfjbdJJe33NE4mvj6LVuvg/+V9Pva/FYFdH6/n5SXQ56A/zjYXTyWTcWlq6uLhoXjxpjrKTJej3lqjEQqQZ5B5e/3S7oOnV'
    '8fSGnuCi8mJ0iUdJxEqd3UZ4uHIPP+EfKr2JUAhYg9t1NIz0cjba0OBEkYj4kYrQZHDSlKHW+JiIWyrVfEyDXiPShK65ycZ0crz4'
    'vDFDbE7VPZkdGhR870vyAswm0RFcPABQCXVzJe8lx0nWo2nBbcxGIjZBaZn//dOPToArGh3u0Hdcy+letpAkDwRJj1kKiycHc505'
    'el9CBOdJrsZYTd4iTgb6SNqng9CUrWJ3N/PWDqIzuWSHfyIMWNJLzFFttevlZowF0BE02+Sz2LJHw70FaSURCMVnZXIJQoHojiue'
    'o6YmnEhewvbJmi3BceMJnun/dfgNO2SjnKSi3SyRCNkxbR6Xrq7gRHSl7ew0JyM+9LSZ6to81ijkJfzg2Z47d55Z7Ih3aQgkGewC'
    'gY0TxqEz6nksgclLXUIDes8O3aWjkJuc904S5CO3HhgqlT7AKry0nuUg/a79ybfcWOmOOQxzUYBg0MB6SPZhWqkFPOe1lzBEQ1lD'
    'npqcJ70+I3sWpEKyCikRX+DUbs25vUJnd3E66jvNXWyDy2k4Gj5bnIEFaeGhGmHDkobxBc351hmKxEqj+jY4tjk6oJugc8YXP1PR'
    'K6vRqMbvmlDB0VKyMaUGEJL4v+hC27bhU2COpjYNNqetc/yLh87QMTTnqwx87MNpE0hvK5JMKWwfc8AbdMgmMuY3TBYnBDZMB+2G'
    'YVHYL5Z1s7IsUB/ZlaPjadepGe1JkNeWpLP04j96Uzah1EvN5NO2XfH4dLXejF678DM5opdr7B5QERro3CxyGysuUc4RMTQ3KmBT'
    'WbN6EqD1Js1oQSLeLmBcSGZJ+Baez9wGOz5DiSd7suhTsmw9+BPr1l3DrMLss4094ERU7xcJ3IupFdgms0qYzfTbKRzBc6Owd3n0'
    'mCDKceA4+DuDUrwd/fN/+d+jFy3uhEYvUUi21yJ8+N/wQd68qLP/6qn0ZkI44o0MaTjScbgPrO8nWF+YjBakN9bJLuDnguMHRf3n'
    'GQFjnnscNa4fmA5x88SJNeUXwem7tx92vr7aeb39+d3+HrsWyDeD+rUK+/AMu1Yih8BMTclgiqB9BNa09rXDw4pqrP4NK6KCqT67'
    'Ihbgrg4b0ezmvrFib8j1bsNVFHl/bj3htdHZId77yeS9idPub4OJJBcf0Lk4ZB6IMwVy+kExlo4PiEGRTwcY2WFdVLr6UV6xTYvF'
    'Q/GHeKQRdqbWsho2eX31C0HknPjhtT7e1tXAr14V3/0FTlYeWG0OPIPuRjQgZg0Z7AeB+TWc/h9Yi/IGi8NyjqbQdwH0ejmwBILb'
    'Tid+SPIk6kxz+OGzANggXovGHDk+zUHSxOBCJI4u8twRRVLX8PAmmLRfQCLm4jetg1uzIbtySLRpDcWrZfwdxyuNx4bgzc1mk/sL'
    'Iv6b4PEbEUfG7xNeRRCNBIm4rWO4F0KjA5GpF+AeVBKPu9bvIaYMeENtRHBfixujDeW3LA/SPuNO03aJeIParYrKLeXGW2b4VOmK'
    'F5Z6G0BQV46pfeaPcWBCqbmRQl5yhoGaES4Hw5L4/J4bRxAiMByBiGuudZ88z4WKUN8DDh+XO0MFN5pBaTTG5GDWrAozWi1OaaV6'
    'SquOefYk1AzvNmKvP8/T0hxru15KEGhUy8P2Bn3MNlVovgAoxxZQOEx69bCPedgr3k44/EUHRq3Wtk1Urlxduum6eU+MGbhtCTGX'
    'y9ERYZGgHoliTlf/Z76qLNEgiVkcRSbnGd3kA0IHVNQ0bcusGY4p0YETUaGfNGqZZOPWnAwcSkDyIHihbjDw/ZFpOz6dDHjNZdzW'
    'PssOiy6X77//vkagWeT6Odiw8J6vdt9/BFNJbLgIURHuZ49NJ+OjdVhOEgubJ0Miz/+mjuPot078LH88akhwziW8JZoPLx3mePFu'
    '9+Ufqaeln+OPN29Wb948ufn87mb33c27tzf87X/+vLu/c/Px087N/vaLd/Tvm53tVzf7L3Zf/dvN/uvd3f2b/U/08mb/1c2bT/WH'
    'S67pNO+8lzy5cEbmJQBNSXvmKNL44MuXo0dfD74crm/eHNaZMP3y5eGK789zkSUQUMTIUu6hM87JzK0C8ZuQSC6Ynx9Yhy60BAFI'
    'CA7bUGdOrNg3JnK4TqPIv+wdPtqq86MKgC2QJghJgv/1uvqrbQ18TAIKllxumBjvZowAI7loarW1SiQchHc2oVjxct/k/EQAnOb+'
    'zp/3v37YfbVjfc9dREoibK4iMeS6AmXMVme7bQLmHpGUYmeZp6mX65aVfTSsxya63p9AP5TdfiLrHbUUfzn4cnDwM/17+GV4+Jj+'
    'pd1ScgFxE3hjetG/RKu6ybz78aRufJZqFhtGhdhHxum8NPsHZvY774hh/2AWoFjb8T0d5OAW6/recJg6E0TZH2q7A4+GD7zmvgxz'
    'ov6f7LapD3v7n3bBG5qVAhjGtUePatp4XK8HsXW9dt767ey8L7Vxjyb2CkN5+8cd/82rnXfFVv/+93s0+5JWsOZsqiB1knVzxnVr'
    'pllzZLlQi/80lfPN49pRjQWuR0cs5+Qy4BaPjphRPPJfHtXW7BYXB7Rdc8BvU6CK0wDLgbYndK7b00lKtxi9hieN8cLRuXpMbADZ'
    'ZvixlOd0220OMbohPWzBxU7IUZCmeCd0KfsS2OagKz460JIc94MhmwvdHmpFz5kurn/JD3F8ypK/OrVfhPkS7Lz3YM7MoXagcj1m'
    'w48eHKDf4vrkWafm91Bs+cWnioa/SOTqKKIfpYqEHj/f7H1+Qf/7ePN++9MfCTWK3B3hNAtN6XZgfOsPryehv+At3VFagO6lis/h'
    'qLVpreFHpvDphgAFS1aQKHY0a70YE8mkQ5Iw5IKdwUaslFBzn8MPp33BFxli2fgYut8ziEZ84t+9rc1CS5AtMyKixkwd3o3ddzWB'
    'wN7jx7dNZocWkeh62o5MIiA+UDaflbRkGJ7H7KPi9yT53hFbkYbn8Nyh4Xw6HGa08nbx8Stb99G+gwiw220Ra92hFiF+mBjELHjE'
    'tyJMTzMI1xXp0rjqpWxKX4Zy1Q/FwKtd5yCpJWq5IwmfvG0wYDlreP6wABKIcYj2q4BIivqZuwKIYuta3rkiILHYRNaatjUInQTr'
    'i9okq9UP+W6csLAXBSeZncWh5c4nXde0BqZM+4LbeO0mXf/Gupcgz6rl+FzWTYP445FdP9/QXU5X+JcbbuLhypcvN7WindUBKjHH'
    'Kfl5bGx6IvXjxzS2EP90Rn1xYwSSXKkjUm+d+e4+bn89c7d+TugHWMhijhFDKZkbqp/7YfFpMFwJi8trm9kI50YhZZc888bO7Sy6'
    '0sVxWWrSjiPshpqOM0PLRDe05vUC5PhYxoyidsO3Y7kyH+2bWkBmHvCWo1vwww1T2Y3fDHpxEf7Y5dZ4ujxscRlf0VR91GwhQ10A'
    '5yzINHm7iqBuxSQWY/bZJNm9Uxaxr4KRuq+EnzhQ5moWUOVeqjuBCdQrXssmrn8VuewfiVmEcyXpyIwCMzVltHEtvWv6EqhsDTq3'
    'NzVPMa7PJTsnvp9hFdVZcVL1ev7o0WWXGgrWrNSlt1KX9dnU1JtVn0h886SCuPKatl+KXZgr/RLEkGFW+bIyT4ToXSegI743sa8f'
    'Xl+y9+7Ro0f4+eiRQ+yzRu34zJo3CAFL2gsLuZyn0M9ZaBNR2hFLbj8MZVPORd8/pjPJYmJv76CK/avroST7WysvmJLKRBUfydVm'
    'SOAvQ3pVm7Nzn9/5O7f7zl8Jc4/V5szgzadaxQbWnC0NLwpjjllNMH/vtyLuJZ1Cp/YzsiyYPQqu1+CgVBBs+korc3B2Q6S8GI2Q'
    'aivcc+fPK1TGO6Xj1CyWsCsfNw6MXAkeED+POWwDYtT3Q8xdlD7Hx4MgBr2PAVnMNtD1GnTt8fLQVJsFfKEgu16wyhEB10bUZoS1'
    'JRkoOItQQYAkBZoa6v06chKpNgfIloH0ezUXgd//cLoqZ5OFTC0jbCpgMJMtti2qA5cd8ujRO6MGaz1i8wkp4MUgESm+j8z87kW8'
    '6gFU7Xu+0dpqq1argMVg+EFd9Pj9NzawWtHC/CZc6ciR3jRzyDj5nl30qoc5YLCMoj/Dbua9iUtB18ucZHKU2YzKnpFGLzNix3xk'
    'BI0cBVp0kGFeGyZzKgYYcAXFxej3gjhSuY8u+Gzo1OSjpvyR1ChuUQSreccwNhmwE863iwKKHANMV90vP2vxqu60ba+5kiD/G09e'
    '1dIps7W1FS3X7w3KFn42bEs23K5804PUiJ4tgzadCWjB4hfgSobhn8vyrkWyrnJOtZHiQUW5eq3QrId7vFZLezsHHXkyeM6JWV4x'
    'oB+gHjvWmr8UZWWAh5n9G/f6SeNWGUb+pOHvBd5UgbDH8anUhjTJozf77981GD5MOkAxOse5YzKNswP+OBqdEJf3atRB0KCfRpmf'
    'tFRbQ0uxc66AHF0zibNl4Ua0uOLZMPWFiKW2mRDW7L9cEma4OIPcwmNqYn2p39tcX5r2N2sSunJxkQ2XCxHv50H2vBsFITV9vYC/'
    'f3UPdd91EayPN9d7m+42WF/qbdKFkOaduAxrEPCMN/2bwTtMDxwmCsno5ISzgDHUUM3TFUSeaEWiEztdxS8iNG8PpJ1DFxsVLq0c'
    '680sKkufkhNInGSAfKJE6iSvecREwfI63B6tFUQ3t96gBa1u8t7UC7u5Htl7wd9S2sx12lXd0MePTSw9iwllzKbuWhEapK7UMJ+8'
    'iRgMDeW62eWj9W7vfNNMaH0JT14EHTZbswvlzhtax+GBiTYg3xpnJ1GzO+pcih3O3yT1+J/fvxMPu2b0YkrEGoIjwG8Eia2RIaRB'
    'tx3CNCC3KSyj5BqD5SlmIpmUhjC3aWcJPNzFC55tZ9B3IziJ8XTMVtp0iF5lvXP4TlBP76huunt8TLxt05mGv/z08iuTrqAI43rZ'
    'GgpKtM902J+sCiu9+sMzl2sTB3oo2Q6xo/SNfjx+zAyhyROy5oqeSdEzKvqc/qAgp2iNfsfx35Yvd169eP78yepy9DMd3mhzk3Na'
    'tyL9uRZNDoacMJOflwM3XmhC67GNPNPJOk9WcRyvJsay3Yxo+fK1/t+ajyYuOWfa1cQkE7Erc0BD+TkiDu93NMEfDt3Ynju/Zy7i'
    'Gq7bAXoUMoECm+eppyVbYnuLnQ47utwwb9hh8XcmhsLZxCSD56D9SV+fOHK9qDklhLDbuZ5EMxpdQMz0ZjTNYBGyvh6trEQ35vV7'
    'OrUSKZs+/ODe70n4khiziFaCrDQcyEeLvSaK69/SBFLrxWjlD8+XuZ0/UDumxHvCDKd806wU+3ADZi0fJ2tg6PiuQneOBStgbHFh'
    'oTVriqIgVifAhvGsw/KiblOexYYJal/cqkE9cdJradEGQAcwBgByfnlWu5KK+wMC8TaITD2p+zJIzZLiNiXhiP544NPzYoooKlzZ'
    '8YXn8EaTIwbZILXpJTLzmMBzRbDBrYNwVDSk+AnMaC+Xny4/edr+wVBifdPyyrP4KcI7mYaDL8+45vPl6q/P2WbCG4//cQWfeiy6'
    'KddcWeXNqPhIE115ygtd3TK+P5edtHRgRRurq3eUoUGsPhMfg0IZzbBAB0tpaeMeUtrwjlnhp7JOq8sr3gp3Zq5wJ1zhGV+el9a+'
    'U1jecPE7hfUNFj/4+LSw+B1/cZ+VF9//jsFWLWxQ5ukdZbD4z2cvvt/WU5qJoICwiCA7lSp6viKRQRh0uT9ZVkcRp9vxhmUvcDHT'
    '14QR2i7du1OikGMwYJJDEdLmJu6Adzpgk+lj7nFeXTUpx4KDTBv7bPkHAItdnDTceqEICguYFgCgqlChM0CCIKRiG7rZpcX1DOsl'
    'GhtSkeI4sBRcF4imbqOyseDDCJIuB/2dHAeDb9bcU9/+bn1zgdW3HY3aVfsdIp39LhmM10DfrvNTf8IPm/xwIg8L/PDX6YgeiVLt'
    'cGzEgl09yCoeLvyYP4pO179Cf/r6YQ+8hXq+5J3TdJDkTVCSNGRhYHL2hLkgommcjRCplK6EQR+uMc+WOJ+wu+8+3bu5EZNVr9Sv'
    'QxrL0j77LuZI1+S1mk2HxqznaP2ilW3SP7ykLQ6evbEAIhChe+BcIysdMwVOxTbxb+Z72dCmJXwfwTujgQQ0Yt+4wREZtY8x+hh/'
    'zGDqxF4cW/JaXDouWudJH+4+/O12YUmpX6LxuS3uWmrT2M1Yxv4oBmm3l/gGodeKTrOeOsR5pxD+H7Ton3gdYrlzWRog+aVKimcU'
    '4w487S23jElmb7tvByfsLGYTWx6xnT2yTDZ5CreqHpdG1MK0NL5Q4mq3RkdLP8ctNVTq9vLJ/sbC8gL/emF/vbO/PuHX5pHe34/R'
    '2rhFI4GkpMOuVZ3L2wWaLP+8wpqjBMH3xyzqdfF2SN8xxo0FBXROm6kFOx/Of8yS8Wmvw8l8aG/Wk9aJ9+YdK6WGo5fs7L2dj9PO'
    'ZGNhBdWXKuv7Y7VNea0C+UXTrGfdyuacBl0yc6rU+GJhc51+tcZoFj+G5zQxjBwPNCCd+bKZtskcuuRKoDxm4Ff3B473baT06/X7'
    'GDt+R1mLg3qjQdptbi9pESmIgFr4aTyX0LD3YSlorNhLPpY1vzzOBvhLCCC65MFf4V/uA1KSWZu95KqOs3zyYzoaRPixsZDRUBbw'
    'Pjl/l+ugTBEdlXS+ZFbTH9tSsGGb3rNsvEAwoxEL2A6leGpN3bTKE0rX5cesCrnQvx6ycOe84pCXcUj72VNl1sSZcZPZzud80bJ1'
    'f5xMCPUjpXzoaayXDRSFSfaSaPrtSbxc95ih495kZzDFVC4a0SlnUfuJ/31T9zjDS7aRx5fOldGZZ6PpsBvjbfQoQpq2C5W1UpFN'
    'beFaqnrlO0j2hY9Ugaa6Jg3iBaQZ1jxAsumpsja04YU1CiOxBkeNGYrhrc2Mm6sVr5WET0aiOJ+ONZo93H1YIM45z42ZO1pnzzus'
    'RbuEaMVj0wjB6MmzNaCnGTYGXlpAWWi49TVppfGHVnvl+epzJnBXnvx+5ZmLzpAgLRTVX+0Nifdeaf7QG/pjEbHyRoWqBkDXg/NP'
    'q58es9sqVHxvuYIVDLlrLEDrCtaxAbZYHVLrDeOaGmRN9XxU2dcPAln8QMN/GadwAjRHAqPCBc7RClvsJ0oIdxW4wNr3HBWNB0CG'
    'sNAQWyELD5s7lTR+ixea6K6ogpfcy5xhrSsOGeqEpqZVgQHYW7PmIrejIT15tkyg7GTz6tXwXFn6xyhgsj3CJFj7UF0Ml2YZ1XBK'
    'KBjMd5OuCtsnm+XC+fkPy6vPzLgviFqK2unkAgEVt59inCe9Yf4dzojEQlBxLdy1WO5mYh0UJbGQkKivwIfpwJmuuVKfmIYQg0kv'
    '9oGlLCCz5UjbgUiX1UTSiyEmmIzgdm6dTChDCBpvs4nY3pXhlCw9uMdVatkbr+FggneiZOi6TmwfUKJB6Jeyi57mdVMAkDitIyRi'
    'R5VJztzCmiwfJ6mdJGdU/uOHH5f+9ePOj2wDTSOjpiYI/S+J6CGAddgEPRDllStzBHuselWqWfYf8tPMPhgaEXooOPYqHjRwBRyi'
    'eiiCN1XFAB3WYkvrwFpUemMhPvh54fBxfWHppB5atpihImQJu4/PMjfsDQoe6/RG3dXpX1NWArQY93Pnfe750ZbNX3AexLpl6WeH'
    'Vb4AragZHgbm4ZewGCGbrWJBRkCa99GKvbxx8mKz0LtoxXIvJ3TPBZ1mOUwIkpI+52QNHNHdN8m16tmplzzRA9dv8fxGDjQZOXy6'
    'TagQ36d7TdeNF6ZoDGO3lthbLAzYVUbsLUtPiAxPqY+LVnEyrCgpTsJyA0bHRqcL/AqxjGM6Ez1JHS9em5lqqeU0CVnMOTd7Gdxb'
    'LNv3kYODhd4Nl55vA1tHNDvs1XYpGg0izF6P4KpKF0re6RHxTcuZj/pJvkCvTreHeeFVJ/eelzaDlttes+3Ct573rVf4lnvfIEE9'
    'SwsFgAm9Mp1RH1l+halc/uHZk5crxaHg7vFqnNKS93nZtdZV2u+PLoq1ppx9oNjd1FQCI99Pi5VgEczV8ulYa+GmBmbbpj6HjvuV'
    'snSu6I9E4uNrnuqlmT4zURHQE5dKj2RM8V4yVYvfjvQwyLkzuWx5vmkgXQyRA0jCtdcwzmCc5UVssvXGdaYrcL1/o87dq0tPImba'
    'cwbS0JPqz4O+ulBR1/WCBe6/u3/Uv6uHlCdKyUUh0cWJPG5IXJN60Sw4dCK6043ofo5EnouDb8w43yFozavljDgNVLKI5WMWH9Py'
    '/jKh0CwfIYcxf6mf0AyTzTPJu+lbaYaWkfdxDsI+xmgJ6LvZbNJGto1hhNlT1+q9/YUqmu3dv9nPcxua3r+hb3FGqugp/4aePofL'
    '/Pnj3JYPCn4kh/fvCe4sc9sGir9/c+pYNbs5XIv3b8731akZQV6bRUd4qM2uuV0LDuQpHZAMF06UtUQsp2xDXO1eVeeISBXjl5yT'
    '4fj59Noe/PNb7dVUxjhCrxoSCJlpK72aSlinN7Cz9IQ0RAQxwQRWuMnUEsZuWHrh6MHQW24QL4k9/MMPqz/onOjp2ZMfiNh68uyH'
    '34PXr1chIN9JyVur4+LG3ob6TzWCLWhAP7LbPlydimIplkcZUXdJPmVl3FzXF0dV+UR103HhXlEWZzp4253pn+Q4PmbQV2gF++d9'
    'P7f8c76drf2hdLN2v6trjpvVNzha/Y9ygLKehh9jhgF2VL+mw6FSgUVPJBFj2WAGWNZaIN4iETAJSzlZOt6iPfnIJ54X29J3eLq1'
    'Jd523Rd+FLGsqX3kjfPXeVTpLI0VOu9wYGl6Lyg33lQMjKAdK2DxXn5VIcMLjyMoo9iRynoJrXhn/C5HpQYd+HrBJrrodbTiXGvm'
    'eHUZbSyBwURM0ofwbqOu4gkS1izXK/qxofOO+6NRFscOeHiNlngsHLEnk+jMuA7+JS/wDPSY/21j4Sn/EHprmdkpsDIbCy9e4z/H'
    'WViBKjfKa16bjMbQYqJb/G2PJpMRwnbXMs7WypFpYK38xv38U0283NhrSNqyNGPtXxBWIq3w/3ZIAYdh0u5vyh8BefrxEw38glUN'
    'WJ5HvAK3mA3kqBsL3cuERZLMgGyZRt6yPJWr4UOpvGLLI3soHpuaL2QRqEVdDiFK3Qcp9i65wqhNq8e9y7Qrh5E+viR+733CE+Bh'
    '8UieLxcHgZtc2cTq70tha0tmYSqG/WPW69KY8XRCP1+O+v6yMaNnLJMZhMysuN5RBTYmqCbcACCvcMlONUB+UyLsMdYM7gvmeph2'
    'K50LFujFquIoVPIZCgDGNGfhIuLp0SLkwc0RjpYTPXn9VJEXQ/+mcgdRnQHRl7E8R2rX5XrUztLkzCc2eDyPYQRY5pZOGfGUZhSU'
    '5EkoLTbpMLR0FNA7RTgfVgD5UDPLmm3eA75zeD/QdbOxLgs5Tu3d0IHE1MMEiBaOR+gMNxZer+I/4AVpg0GkE8CbwJxecYE/KsKE'
    'UofXjtOhRnD/menAqO4Z7E9qVZoF6BXEMl169Yna23DH12Qb1nnj5IEtL++9uLeVB03Ljs2jT8B6JPQEhBcfAFndSWYx1RsOLKz1'
    '8bpm9oLHJuvpMbblm9LOn9BgjRea3VRmL1jF1WodOGMJNwUTlLTiemXMtMHkmnUw57K0WU+eLRsKeCMK7qDCjZHgDpJashzjF10f'
    '71XcSiur3rX03APG7Wf4T7eD26kFDkVWkcYaHYvtC6ozxvahrqxgW6LBQDb1xxatstLbmA77s9SD2j7d2ih5vM7yeTUBEahTOS5c'
    'sWFX69ox73pShFuodn39BufX38D9tcBf3UkkU1u+pMgE3wmdaO8pzik41lbKaSpFMp5wwC16J0BRd6/9TJ51rjOtA06JM1PRNc6Z'
    '5z17zR3PEwspa4sW7bwKjVjALfMRKlJ9eG0vvCeNYC5b0SqN4AmH5UOz+WnvmLWzy3VWNrOS9/aozu46tJoykJns7xwHXgzcuIaa'
    'LfAZhpkOuDOX9y5f3JLfJ+xhJShR3FNEVZSh2Jy/vuDyOhDU3EuK2S9IMasiHnm8YoB5fultLTjrPntT7VjsM3TL886AJ4dyV5NB'
    '+cIjVCP9Zx7OX6liRTycX5zNHM9kDET9kpWNXKuUyhTAr8SrFnDODNa17Klslus2UCPnu8fGBuJB0QWL/d8KNiDfSY4bq+UoOtZZ'
    'HUvZLMSqWDx3Qy/44vO6r2rhgHMExt9JGKM7+1tueNH8XDM4DLDjIXxR5WC8Erm4gZ4BQ7AmBZcyXpTA9qqK4nkutie/2oDGicy+'
    'cywUd6mkXI9Zs0Dv98Mf8J/CqaH4qjGBc4yLAkQwo7Nf2o1FONU+d65jTxIIQkaTSwt1801ehbiB2cAnbtdLrnyBX6zB3NyXuY5r'
    '+xpfM3RoLZk+Wx/q7f4FcvkiPjKYZGf8Ab87ukOQ5Bf5TDn48QUHp+EI8mw+dowkF2xww8lovPj3aoDTLNAX4+GJ5x0mZnphPjET'
    'jvxaEiK0AH4iC/FC0LdMWEceSosuWaQyTTzr+nqJtOmWHGyoq2abixvrMgQ8l9zb0emo383VIOqSTjpsX2yLdsnVMGwMJ/OaxHd3'
    '4u/uOYRg1qAeXkb+m1WwaT/8/snKDzDYf/Z0GR4dszi31afLIsv4S8deXLDiyzwGxWFaMz7PeA+We48NkpAHxaIW0KKZTpmTumsy'
    'CBbAQR4AdkoJrTDkVYZECMqtcjmbF0y+BVLZGpulH82WzBZxMfBwlaR2pVJE+0tWyDNGVzMYlqdtEYowCbiou+bygoSho2luLHze'
    'f71I7Bcyr3WT/miYwk4hX9ja/A5W4qYZzr0hrDO8EYh1ljcZ3nzy31yMf4Etdei38Eo+mhaTX9AgXB5MfToDv8q8GyQN2wvgD2g/'
    'xI1XKcHJ3t9EpLCy8odlpm5O6fez50+ey0aPT94nQOuTES3LytOnLNzLJC+JeRSCyT3L7WWe5LRvLPx+mZnkYyI3vMeT6cSKAQBD'
    'ZmhLOmi2iNZN9K2Sj0eSMLnKFieBO27PN8Vxb9Ikn2znvSR4yeY5+qjSZJXDixHHr4NBbaQEgZsCn5pZKte7VB83rfEKZsqb9jdz'
    '3lZXZW/yv73Mi+/6CeM0fpcOF3984V/CS8UexsWnWQQLdrWHaa0+e2oePk37qRLzSvdqH36rS+Ec7XpYydXYKonoVVfKKW3NBd92'
    'NxY+AMr7vGDsSqLz09c877++5pOgQISKd/VlW+f7vNS4vOW2Efq7uzus6nYIG7i5w5m9rHrhLNkSSii5jf6hYqPlnbej3zZZc4uU'
    '5msSU6z8lnNGjsQPsEIKF0BSsG0sPFllyAqMsqmgUm/v3F1UvVDtMn278vrJc4LQpXAdn1Ss45PfZB1XZ67j6n/gOhK+XyjwF5XL'
    'uHLfZVx9/cPTPzwrLuPqswq88+y3WMYnM5fxyX/gMq4885fx2cxlXL3vMj5dxn+lZXxasYxPf9Uyhtr24lria1RQxs9Z0PvgLjOr'
    'jpgRT5P+nhQJbwIzC/Mz969wzirGStp//uO/gOH75//5X/nP//H/1jyHgOOBRFmoddNOjwbJ6lwYR71LQTrYx0+jQTL0K2r5d+Lt'
    'sBF5HktwLQLP3or+AJFl/NWI1UANCw0MUpjNE+SiZu+T4Bwxvft6MPEsVWmkB4gW/uRQyWRqY98Dz3+h5iDQuG3az/9qmQ1QTQv+'
    'ooeiAHX56HkeHqz/gSMh0yBPni0X7mFqvii3MyqT/5glEX+TyqV4eM3bX1qu/yHrYd1gfiWl59qpJPaSNrK7dyYfppAuek9v2b8S'
    'RTihCEMsaykMMrwiyrT7Ht9469RQAJvIIhKvqUA+M7fDlW/tMDhPc/sdcn9Dv5+g8+K1PvTq+141EHn3ugYIg1YJCru3s1te4RF/'
    'A3jv0oZnEK1Ug7n3ObhJvZo+aN3aWbl3Or+afhJA8ZmNTM7kLwfAT75neyHb5By+kRD3Gbw6yt7xNH+/zQgLn73tsoImX4j2+UZS'
    '9nkpN285MfXGgjzDsQxrVdUO7VixEbswrp3AR423VfzFARwD2cFS41SmyU7FhebZfcU1zQ0tobBxafb3UENquYCblR31Kzuy5qOu'
    'M6dZaUqUffPp/ahLNXcu6TIb8h0cAlKwqwEL3BPe9IAhSzznkc1O9UlfMaL8EKtWM8lvfzlscWO/EKY6MqBFUDCAKeUGI0x5KAMB'
    '7C9EOnJZymQ87vckzfTS+bBb6GVRe2gGAPtYoa2iB3yZ3cHsemPAYlDP+kDNqAH/r8oq/IHqWGRCNNnkAzvVswBpyfp+zR9sxWpI'
    'oAtbvxhGo2m/QK5kVmnmOLyj+5uOQtq9s/vwxP+mI7BNzxsEh3sYjXMC3Cz99jEYyETtReeZZnpc4qO0eUTXUHhwv+IQLAGg89/g'
    'wP5HXQYrRdQXxlxx+K8M4TOuhVXT4q8Z7dIgnSRYw6XCNrgBlbcZu1NAt6VdKtX6DfaqM26htY92kEo/dsbfvAizpy1Ndp0oeTzN'
    '+iI47iyl4maaL600V5ZcWbqSBnllBf5iS17mvRl5rVeW/vz+3R4PfrE3xOQ7kLV1Oy1Wsjn1n8tPh0vPfkdJ9oQdZZthsnMuZD6t'
    '61jlRdqNaETGNE6//PTk5av911A4usB8zcno7d6uutXVNcEAQiL8oX77n9BB0ChBR2mnKiCkBOgWQqw2orKKw7q2gnEirCoeYElb'
    'w7EglZUEx/iDC/EN06Bc87CgV5UMgSCY6hr6ygvYY5oXggqmD0JSmWYHTS+Wj5ofFMIu1n6jG04Cq1cnm97VWOj3yP9sZQ+apV6l'
    'QMTcmpzhpcjpI01O5rKqelmrz0El/KfeOExYHcU2oxkXqDdpVSDRwJ96kMwCCXRsVwi4BY2fKHRt+C0MFA8fex0vWbgxk7AxxfyQ'
    '8DaQWCvyQ8DDmIHdRwcaJZntivgNh0c2Ade9GWKMQTJugAG12cA/s7Jx/+Y74vJ2B3vDC+b08nAbR4ZiSRsZpLg2SUfzaXbeO09t'
    'mOVSXGU6GhJYWZr8JWnCrbbbc9Wt2CiJ1OztlFccEaoLzcgGVW04B/cvtWM31DTkspTbPOUvJUc5coxjQdKZy2FNef1w5neuDieO'
    '9cGy2L/Cyexc6SaI+i/OmK69m6zpFkoBs9r77pgJgyCF7zx4bPDJLJ1bDNc7qZ9GF1ThtNftctRt8wU+3f575AC+NFUZWRRLoJcH'
    'ASIyxdsv3VEr1tgo1PCmztGV36fDqc64eBtYZFz2aWrS+2mtXifMb3uDvVWVsc6cZg6SrJcsnib5eDSejg/RYBshJTy3Jy5B6J3O'
    'btoF6mS7FbkF6Jhj+DlCOp+4hN7irJJ2T1J2ttA0BZPJaLgWXZymEj9iMhr1Yc2INIR5FCcEvJw8+6I3JHxYh5tAMiFwG6IXzp9M'
    'JB0COnJttuuWxqOcyId0yLFbiMDocqrzNtFscobOe+mFF5wdKord4R5XibGIsvT4JexTk410cCta6ycVH3E4PipGxO0LxLsirEXg'
    'TwuLKGqcYJothqjYc0/DzeayG5xCin6sm0Jb5sei+UTEQVNWTi3OOUwHfbc1qt4u2lotCSIMtMyd1mdN6ogfiApP/xw/vOayt+NL'
    'ZACkK6Tb3TnnSP6EhJBGr5alsBuijTf26t8KpS3CDPGBQOlhHSAW7gEQgp9QZTI6IaTHx6I9GdrMpWySRS8RXhy/laJWYGO1iYb/'
    'AqB5ERqHiIBGLTWhyNJwL3u9dl/SahARJHJpXiwZ5ZqJfC5nc83Ah8MVWs2stz5irDnmVON5M5mGehy3qAx4EiQHI5t/4pR8Np3w'
    'ybOLXt6w8agHqyomKjiI66bm0XgA3yuwZk2eXD7ZauoWLeIQYmf8WfOufKexp+T/1MJuiajO7CwaIGqX99HGVt9/s/N+5+ve/u4n'
    'RFev5cxWLHaFrWixUVzN23Ca/T7eISNsRn9BYCs6k8NJlCsXwEssuZ28+aG7ykQwtdac+KUxddNsXYMY9UedpL9HYAo5AtVgcsEb'
    'Nhsfutvu1uB5HgZheD6JIBvgJkKTNibHWJeaxFIRim4wGmnqtKA+8156GZ2OBmnxfbG5vYseBsLh7rADWHpu332wW2JvJb9hf8DV'
    'M7E511Ftp6/ADlIbwffe0Mu4bmOsERM0pKs+J2SAiDWC0NEisx/DruTfvP2Ow1W9B9MS1+Jxlh4T777IKtxFZriJRsK4CStUAHKH'
    'Y3haGFa7VFDE8OxB9Kc13U7zLtjWk/K2FveU58uV6w4K06YJ6bZldsAz4eTbzyyEN/v8ioY9iKZDYrby6Go0rZ1zIDqY+NLF9V3F'
    'YUI1ZExhJNGSVhh7ppwj/IyT/vBlh0J9VdhPRmFJMf8rnEN7tlBV5DEeC0B1YXxMxIykf/rd73CkxDz4QD8eWibrOjqjK5mXYHiG'
    '7CXtv7QqysPFW4yQWtG7tx92vr7aeb39+d3+Hpfz48FxpEtOqWu7/4Ax+cwr57V60Ms/jejyyOvsiqPDmBAGRWZ6drjIdTx5kxfp'
    '5oaddGaNBFXZk4eBx4Z1Zlv/fYm2NWRFxD//8X8/vJZ8aEw6D9npuzYd8gFFRC8ryniyXL/95z/+n6O1kKTFxnqknbOM9nfEnFT3'
    'DjjAuazgqoH7Wg2t1TgH+hn7tYlNO22HugQc8X6a6IEPr+2M4g/xpEkrxEq6ev2WWbCq75NRXRJzHTFIEpT5pSZs+V+XgMJmxEof'
    'h+OdGDP9mlACUWIgFDwFn+hKmO5NGNyJ6yDCLRleSQF6g2k2i0boIBTnkx48QmxARPj9BHdbkSymNirqCflQsybt7Wa3l4Ol6fJm'
    'qOkt3aBJngNVNYVciWsj3LYPaLsIcGVND9CDuZIgKTxEtii6pRQ6y9/rvLNt+/LcGu2aNX9BpFvn1Ocx6BZnmGDOhM+Gv0ef0pyB'
    'qjQJU+AVTT5kc4IGGcj88u+Qz/qu4rfB5Q6AijG/RsRs210ngrHyxOAfwRuDQc/7WjoGfpxF7oO/eUuty9vl2UayPfxuTfho7w2N'
    'yEo7Ai47SNTKAW7kWDDqaURSuyWVjSvQPQeEFnQ8ttpu+y8Els2z9CqXZKw2l5fXrS6fzsJOz35fs7my3KUcXg4jAan4PrtShrVZ'
    'u+Qdth673OfTNiooJgFJbNLKeaOt00VAX5oz1pgWNZinK7w2e5JwhBEQ/HeBO2+iZ5jnQY0ZLjDKzM/iB3ts4gdTPrUiHJ6Z4PH4'
    'PM3AGbeEgWW8mEsG+lr+XTRvl4PJ/ypMicYIM1UQZEDOjqcwuHQjKjIWDo1KnIR23eKBIs5rhOiuiumgmSUDviZOEYOeuYhZ9A6X'
    'TVWDcX+pJ6+wEw6hjRpHT7mcEzG0NxxPJ0LcU0G5EiSkQ1STcdTW+IsigMipYOQ9u6PCS0citHDdySnxtzrJmmnasAW1HXB2AAtp'
    'vxEhHQUuVqh9+s3oXQpRW28SpYPx5Apf2E6x5zPI0FDToUwTSc7AUy8IkfQl14lpADreY1qI3AxeCFCXyqg74jPL9LFvQ4Hlpvdg'
    'f11sAWwJKviHLTJNGDmWn1bILmNldEGTKN4SZavLy9ZL5pKqDEbnvOqFydrByoh4jHR9nzOCg8ZMV15iUbtPni6Nz4FiCcH29chV'
    'pKskRFn205o7sH6eN38YD84NZc41wq7ubg8B1AFSsQu+jcUoH2u6YQJhgYymmU9GY+jhkhPWGcWeL1+KW0njDgIia+ZcxV4WGzsf'
    'v3TeScapK67cFMZXnz3Adn+aWQGU31Hd5KHzuSqVK4YIAhDKIuv93iDNAmkT5NiD/KR4OwAV8EcgsUmByuVLGZXwydGCNPS4hnVX'
    '3RL8stHhaEoktO0dlewD80ITU0im6DepsKutMmQvexlp8gvwqi9xr7Cp0qfd3f2vr9++e8defB+33+3s7+8QUYHZSNk0L4gD/CbY'
    'FktC7vCG2ea+Yy5jXdB6xMPbWJCakbhSAYkvdtjw9HZBFKsbC7jFTjg5QEveM6xuLOyzf6XioVquN19Lg6gzuyDh6BljIURbRqXb'
    'o4uFzff0Y31JBsJGja0Z4/rGIfHDpmvZt2MtrN49b8aOfzOaO66jeRT4RuRF57zxgQQU/OO+gHFAtBQZ5y3lm20sbN5OZkBO0tHg'
    'ICcy6xDIa0DIHk6eed2Joizh77EGRjCw4Tjz+EGOFuJejoUHK04vsXV0ERjHbEDKitc0h8uFgrSaSRKXxHE6jL06tBT9ZJwXBiSd'
    'PzhDoCpivmVGtg6HqS+Ur2owPLv5VrOj3zg2zw5LWplltXVsK5+H3VGhC4Kc0d6EoMhLtcVlP6WlsllaLvsN6pmmAJ2oZWaynLzj'
    'joqSk5s3mdj0aZwzb4fnin7MjLiFVyPwj6JFcGeHAW1LJL17B0ZAe9jsxKZjpEw/25KH6pL9M1e05uvS6N17Vm8VQAF3Yv/MFmQz'
    '2XJB/vax16lqopI1Oah9f/yCqDBO9H38dpLQYZbfe8g+Ii4QVKR3cmJ+753iGuOfSJMjv4TXxs/edrcLMv8hMyiV8Ck91mfv6jtM'
    '913z+CLa3Ih+r/QM19QR3l23xwVdRRl13dKjdBJyvBL6xhbjGQWlEEgkLMQzrJCDSwB7jo8S55xLBUcs+iRE2z//8V/5nEXqyI9n'
    'O7zeHvRMpa3sfeIbsLiTNk+LX9UbMn3FSx71ezvsfGcwPnWmG0KTQwEA5iBvEtV8muQ9u0n566Sbzi5+TF9t0e3pZDS7KLw493sS'
    'IpyLc6psb8hBaXBkbhA/sXKmuiQUN44aGHFmMeTkSM8b0fGQqQkBwtKdpSW8a2eYXnwD48ShUCQwOnImOMKUSMaPKWtH7VcaMmj4'
    'fjI8w2POvNayxyVkowE0DNjZQP0QMLaI1SDVJwSiaQwEhkTIiC45MnQuM/GmvboxU/iQXljOEVYJLydZ//F/An90AsIQ6Qz6LKdn'
    'vluU24BmustSZuHNBe/WiMpICdxkfhFO+mw+wvTB/whlQ/BxOy9+3s5tgZeIC+V/F/qQ9pK/xJ0pwkTY4rih/dJUDq/Md8PYeiUC'
    'dtm281ok7OVe8SF2/cHqQQWSpdIwPtrnxe/YUtCRC8XvmphO/Lqd6USK2gIfYQ1Tbp6NZGB8EsNOpSHPRphT6oUb+WOvm39zQ4bN'
    'kHZeTcWELhhQ17x0+yra5cJW6FvXmBBgwW4A0+2pZscWBN7wi03o2e1Vb1KelFFD04GpuXNzaysxVePVAkljPzIZE4zK+yi2aHy1'
    'ekWY7PX09mmTIBNRTmQhsYBVt24bx9i0RW0TbnFPdMG4B3fV86MjEfjRXPZ4APrAiQxevB9lKe5jmgOQ47eMGyFVqDDETzm1JBmB'
    '2NIlAYedqYVBjKk0Iho07bWyM/hlgtEkjGJVwZ6ztqPfO0tZ00E0EbFAaCZvzlPsF5gMYa2LgjfW5zc5hPem2kI0Isu8REpR0qse'
    'j9Vcr/RL6ZcqKwDZe6PSKu389bw1XCuowwotnpWhlzk/fHKoxlN9eMV9+bVf0hJiDoRV/OiXKp8/m5vKn394KMPxK+L8BcfBP01B'
    'VX7z8cOPAZINUCQ9+993fMvbclP6IWiuorBnK2qKevZ2KGiU8WV7PapQZcTnelSmqrTSskTme3CxyKttIa3n7g9sZ/p9U6Mb19oM'
    'DymncrotNYkLMf/2RpnjDVsUvvGXDNHYELi2Pol0425glHIhFIopx8xLQOxtZBhi4eDsaQIjEzFxAH3Or4I+hKUv9eGx8tQCD1WJ'
    'PmoGhJA+mXYsn2XvMgYBvLVFHAMWFnpruBkp5vFm4ZjEYC1eXPF6taxbZVGvpGXsQuMTMZKPh7KuQ2WbPPGOEOfEbCBVJZHKKdLT'
    'uWYNkzi/VWaz7t9oCc2pgDRotayfausW9Ow6q4FfLTeTx0A8NdWQVVSuZ2b+Sv0yIzY4gbsB86b0zW28+VBaAyMsO/Ynzi4LB8tQ'
    'zoZrwRaZYnkOFtcThrE8TYJg5YikdeyDr/CHd66/4RmLWxDMXdnRO5bdrBxzqcHTHmcg1ISAE05TJ38xubcQh/rdCVtZXrUK5aSj'
    'BdQvgciUNP0bkKiK5UXLyOqFyaibXBHVgYBz1C4ojjU2aBfpK5tYDiNIQJGvlO0th10xvSsztYEGUDoPGTdTkLWTdmrMi1cChOUl'
    'q5jzqt6q+3IAIIz8/fsCZ39HP65t5s/v3zZY9goQu2sGIjC4fzcsQ5jbz62Qt38EPJylV2LGzzQtsWE5Qjgy2Suaw2luNLCqYPFI'
    '1bLgUiMQGvpTH0VlaB9Vf9qkk7OTEHeIoJ/QAZVJ33YYLf/F5/393Q98Zw1G0zydjvnWsgujZGRRrdJuQpEEhpkmDlj/xOh/t82R'
    'MjMtNRbZBfFV1D5zTtQ2fKeuOOJivd4cSYU4Pz8pK6s1AWkyJNTkXkMhhjka5UYnGXJ4xiiDl4zUMUk+GxEEavVmxHcnnVDiEiTC'
    'JfGmkFlPTrPR9OS0kCJUvEuo3QQ2icwAsAV9lranPRMIUj3FhYHJOxl4AZodsQXi+gfEqx+J2YE8hLV4NNzaJMoHU9zD6IbQgqQG'
    'zCFqQou09t0+koLQfQOSeeI6iy9Oe6wmQjgZqtBOOwncQtgMLJmCWMui7Y9vYdmdpbRKkPKhF3Uo6OUcm5NWRMWGsiic3bxL65Hk'
    'kkrz86d3OXsBiOM+sRFXALnjRQwkwfXZdDbKvNQfeZtEzjgUpYWqJ3aC1y9GxIHTXkOLyC9ejzI1QdXyRpfnvXrJ53LCskCN9cnv'
    'P7ENnBqw+qMBHWXjwj9wA7SyMCn7YXd/5+v+9o97bCEjBrnJSbS4KdGnWX1cB++pmnK2kqcSbF+3HMXTITBQS+8BBxQ5Z8SF9cdH'
    'Ttn04pP84X8lcx3/fMv/7rznP5/lqynz9o87/PPVzjt59Vmrf5Y2kT6NfyDxGf/4+In/Uq9vVlocaJPgf5U/vXkif57i/RO8/8H+'
    'emZ+fZaOduXPOxmciyzOj9sy7vcy/jeftEOOD82vOAuJ/EL+RfmFHIzy65MWkj9S8NXbP9EQgPf3Pm5/4MjHr3c/7OPHd7dmq159'
    '2v1otmrp51iOzA3rUm56x8Q5pjfy74htvW4YpG8mdNPBO+NmODI1zk9u6Pic3gBz3rDC8gaOyDfQ29wg1NQNyI8bxqg3gnVvBNve'
    'gLSg45LcnNMJH90k025vdCPJbusPl3q+2rGc7dJXPnI64LtTZ8KPigOnooFNk0kTD6JBuCuBpkqyOY3CLMubbu/c9968SFi3FQNf'
    'gFvwklj4WZnhrkAUMEpV5kOQlMkc4Hpe/kvqoEn3AV0TIoQtDBL2sqjjmipmxZyuLi+32XSlhquoImlyeSQzUzNYEJPsDEMvw87M'
    'dM9AFxuRX7Q5GX2mKWk+xEaUTdl4xaKaAyp3GORXRgksBtZeE4jQwgeTEdw0HZ4NocCnjRDMM8YVlpwoAoJ+H2Dgtc3DM0kJSymF'
    'OGm5Lk9VKkKTOF5MgsIEEA/oEMKLPt9q0Xnq9SejVn2pJyvHMWPumFEhRnEwWOQqZA1lmMAagZVvEJjk5qR3fHORtsf1NRzYZ08b'
    'B8ni35YX//B4aeNLfvj4oRlIxcw4m6FObNam8kU248DgPMLimXcVg835tIKC4nctbEiYEzOIvR3uCFLv5eWVF5P8yj0xiT7WylWz'
    'lBnj4QjSArpChyP2EslgVLQ2e6Xr5ZawSJVjCHNBBk3tS+4p9/wmNOlMhGU2qd+Q1mx0wT8Py6AJOzXGh2+HVbuIXNwrywWIPOdE'
    'TWxYtk5fl8vzShrReSk6dgEFqe8E/s+DXvv21th/8UfOFk741Xe3oEffE8joE4nfEiJU/SIemBz2bBmytB4TP3vDeRVuTrP6l7YF'
    'YZPpntZWfzv8t37w8+bho82b3w3b+XhN8aBCiFgWA7e7a8mJkRCqLGKdF/H3sEUMvMTmaitL1JRv/Sf6yB4zrWw1pyQeFKehaa16'
    'vXPftARKKjZ7uZqXoEMshwEOU8BYTvo5nMvHlSlDFvOpdSUwvracx9oWfzYGLJ4BXQRVpjBhbK2nlmPEjnGzrIctlCA+S7rM1M+g'
    '6JtsZHnXRX3vjBU1lpsFGrlonmyYTg5NzyT4aFjp1BTnyblhO8GM9Ca1HE4jeAkSd9iV+4NtLVXG3gztqD7YYXpK7Qe+CZJngir3'
    'rhm7msjAAOmDfc0wHRfcl+Rxw86bGg3gyDg3ufRytpfACcrWN7p/5S04W0LBjAkOwWUPpc/qoaQrWKvP8MTJ05SXTrgeH/CheCFg'
    'C43oi6diNkTIrve64cRQZQtvWxYg5qzFlr8UXhV73DyrEyxDSLha5GOsiky1TnhGtXINQMvyA3FstzVK/Bv7ASfZ2U+9s56sUrhI'
    'UouFEMh7ex3afzo2kQ5iwDN6ggq3pI3oKWx+Ij4tPyGGgzsubDApcMAu7s5qshnBsvK4l0n416F44IOnjs57eW8CFhsHCQpfYpDT'
    'sXda/O0Uuv9+w7/HhpaBW05h6GvBNw74hI3ijhb3HVy6SEzNDYU4OfjbkhZuAW78q+UJz7VfAyGBZF1cr4Ysjw0RwoMQGkIz7BKk'
    'iP28+g0BWl71ssmVuzuGKvEdmnuVnkMTcf3GZ1IRmDuTJUS67/lE0Oa2U+BLvWu7YPa7IzFJYduVegvUDWxepkNxmiXSUKKvEDQk'
    'rJhHwBB+5UEX2D6CGw9aymY+9wd4cd0tXhIRTLmXok/GA/yCY4iwgGKa5Qj6nIh4x1h4YwgwXJe4Miy6YofbLMd00gzj9+JR8JLM'
    'VbDn5m4sSBJDC9zwErUhF5osSGczVZ80UNlTHnOecr5utyfxcr0JGBoNt4cdIphG2UsVUWXMggRyolJFxDazpIK942AwnIv1f2BM'
    'nHH7cpK0Fk+ogjSx1590XTUL93nuBGauVpRX0SW5I0VcB8VAMfjyctCNO4OuOhJGRvUT3uvVBJk71BUrEkQVSC/TDo40QVUs3lw/'
    '9SanL/f2jPu39QKfVYuHqEXF5dHdKuZ+qNg6S3cL+OKb3nKCFjftGtSkBL6y1VhJcONDQCehuXOqppI1eRmWRcTZFcDzQHqrBIds'
    'pmG33bumjfRCAOgueYp2xgVdlmCPN3FNlWCxm9Y5H1o39Xy6y+Sfrm8xxs6d1tfc4yLQTR4diDPBoHvofIM536fjJDQYAb8Jm1W4'
    '2JsgKJ5nqT3oFiMSzPUtHg0LSXzaLPfy93fLWQKdrjai0ycNSUPHrtyNaJylzuB2yHU8y1I0t4V/PbGQJxKIWOBZEWjMgSsrYHMJ'
    'OefDGvGJuU2F6m3BMQvkpDRzVpxzSUArx6lTg+IlXnRdYDQmwfEk6hXxTl3R/B7X/fV0sbWmfYlPhZIRh03j6Hlc2MSB4FaNh214'
    'AOUbB8uWMMUwayY2moNYN+nH7YLvL8JBqMeb621ERR9v1kIqkTCd2DZ9I9ZSnxJhcmbvelKjp5lyMRZ+tZaWauaoTzOQW+NsNBhP'
    'kL5qeIYBEobM2RqTO3MEG0qDaEIlTotlmvMHKk0ilKUTwd0lfKPStMFSEw9E6nX60y6BUu1/Ese7B+FbdAn1n7TD5Ls3mMdoag6q'
    'x3AKvDDWXu1zStt/tJ6w3BH7neYdHu0tAl3ah/WlZFPkGZKdi+k5i6yFu1djN5QPAIJ3elvGYcwEr+ePXYrJHshYa2EKPnj9bohY'
    'C/DKuaiP1h9e05tbBUx9sNnen2AWLuu0It/SSvBoN9cn0EQg+enoAhZGHEhb3q1PVOQvn7oc6Nv9pmKad0pbcgflqIDdkAx7NqBP'
    'uggRBoWd4eZQ3i+QMANswQ+fbVATRQ0fpxOfwoS1gzbHPJSvZJhk2oV3S3HScuC1Yu56ZMa83D2Ouc8GtiM3xdB6xWUzyWr1w6r9'
    'hQ95YXPnaEbQzJrTfOCI99jWnv6s+3nvjUNS1ENO9GyeRsM1ThtYv1fJdmYlrjF16lasmPZ+Z/sVpNCyKpMXo26PDX9EKIt3qlSB'
    'BpZvoKA1OKAAPl9wgpk4a0T36Swu9gYHF9ptnhKLLJmo5L7AnjnDbRsQorhJBAZ2k3zne40zktcDp8AZq3aPoeOocaBQRGWMOt+w'
    'F7TFwVp1GpEDhgOA8eNo5dDOfk3DPVbOlhhVHyppmayH9dxKd69SOCTamKDhitNBrco5ZzFdxeFyiKKuEOU3WSDJ4U1sLuMyeyj2'
    'KtbupkjOiw0WF7LErmJnSOhYOZQy7VePTNTXPbW2ifXDWknAxFY6s8fE3Bt7fRijzxmyqzvaCVysrwvOPd84pgp/co3FN+qyQVJn'
    'kvX/mF5hy9Im9Nj00IjO+BtVDqlOZ95W9iK/pgpE0qJ7zRPAbkLB4M04xfZH4LrSNZ0d2ZnUSCXJOYZIjwH7VHy2Ut8dlnIt/fwl'
    'fxQvLi7efHmE/26+fv1ap1cPl4TO8ev68lzLUlTNh9WoC9Togljl8UhhtdPtnbPVDky95H6Y0byNZBmVOMhR1vsbGKo+sg3W7Dmz'
    'K4Q9Y8AtefxXL76vN1irbOpMVZD33D9vM7bUP4ovAvy8o4uzmV1YInw2POwn7Vpxuz3qot8TlqSqdbPGwdBro+kEiaYZf0vm7JqV'
    '1sw+TKGjhTtKiPa3gQFXHaa64ZffUzHi1lN7ilDvfuuuhBIq4DLC4qeT10A3+8lJbF5jJyQKHhCEvL6gX7qwRotaFSImcbRZwvrE'
    'GXOZNVwJFMthzOOEU740otpXdjL0NcqNokZ5/nqP1d/MrndF1+UMMUTYYfgmGDLyM2+JFTPmcnBYP8QToqkcs63wHDbXKhk5Brxh'
    'SEvkeMBpl+TnhbGAIcTf2Le4MR2JoU+B0OeXZU7Gu84ad3QiUa/ravE7e8G7WXJC93Fm1rwi8Mgd9Ufj8vko7Awu130OgZtmv3Zj'
    'HlTtzFo1pMwKo6KpxEd5QA0C03wc5T2Ug03VR0Ry3VLIohJ/1jWnn/8GrmK2BlmHSh3g9ECdPNnDnPCmOTo+pmfhX9yzuSqN2Dkr'
    'oMZwmFzKjrEeVp1XtHoyPOBZsK12yhoRQ42K82gwzSdsljpJk77Pxdk41GJ48N0vFfm5UIAVJslieezTOeXtD90ef4W4sT3nYnCO'
    'ODihoXDRGI+rpK/CeNyebHFfMOUgKwgNx2/Bnjtz9OE+U90z3TnOKyzPZ/pynNcDIch50FHRR1CvbvudgaXaG4UX9O3gpOyOYr/M'
    '9kcx2CN0SpnpklIC3jyYBRPluPkCpztLKwmEvyJUGGh5OS44x1HnkF+wVo96kzUuw0HlxGRaFGZpt+lZCO99/aki9rKAmMSjW/tO'
    'xKlqQ0mlH1fGz9XWlMO5qPuWHxIWRIayQW08jmrjy1og07YbIdb2leFzqkJW33H1gocDjJ17XE/VmN4nk9MmhyyJO/1kMI6DIOrp'
    'ucNGq8+XG36I9UfRcvP39bqbk+t8OrZ22tcqLcN4qmel7kL4Y91Jq0tOcZFNxyo4mROpWrek4ZubVc2fDc6KKgaex8w9CEc7s5gb'
    'KmBchlqtQNOIlzY97l6KFLs0IadNq41r4SDpLGyLQhe3OwxGk+GV6IOJis4R45/xPVsxw7JUtOn5KST9uBMGyZkUaUOuALNCyYyR'
    'IlHGlcRVbH53NzFivKxD+oHz7G150mg4f+dA1FUkABboDrLlN+oF62YkCtEp7VPeYmuPDpJ/sTOIRJXPBYN0Tke9TlqNQt68/bC/'
    'V4FAuNVC8PY3eBfDREi4WI49zuWqQtTY2EtQaXGlNa/OPpcqRiijUjAf4gAzl6Jgid4ACqy3Ergq+W48mbTYni1hs9dUnymeccP0'
    'VVthPm25AJgaFcQbadkX3q5I9TpY9aW3EmwZGzqJO3mFPV+24Uo0zeMXKxYafKAHsxWt43HRawlBEuBj04I3D3VmLUqGCGUOCUM7'
    'S7IrWp40ycRBp+DdtO878xwTa5YHTkV5sSlwjV2YaoyJ65ReJbaChk5n5q2Ls812Kurc1KUBoGm2aCLQrqnxX4NtyKPYeC8+jtQG'
    'DFVsFIZFOESyqzuLHyVovYay91yDJAKNF53fuP6YoRs3H66cq1fE+2RcDpAf7f3px2hMazCma+jxYNIbpNrJpNdnvTcHxdSGt5ro'
    'Dbzw2GdB9Ct/ZK3X36HCHGu0S/+rZUpa0dg7o4TT4klR9Y8EbURyXtA1tgTL42W6DicIBdKTdOAHz5bhEpxSjW7tsBHJ86A3nBJ/'
    'jOfVp/RMGDfjp9834DZ+xb+fNp/8gLC3aXrGzyurqElwf8qPb4ewzp0QNNWuCJxqh4dGGwmqsRij6wBUQ4PjmB6CguYBBvGeo/UI'
    'ZZyMfWju/UFyGcPrCL+P+6NRRrSlE20MrXxdZ4m1/cuUXUUucPyPHl4PbyP6B8lr6Q/baiO5A+OG2i0W9sgYqZ9HSxs8DmNKKwTd'
    'BYHgaIJDYc7UBe2psifICa8GXSmUF5DujVklJXZ6NfZim0hUIs/4ysIX80j+zrL4CgPHhyag7vZGHxj68GTc/yWaO9vDMyA3T5M8'
    'PmOJi9GSyXvEwsH7Na8bRHOVO78RIdhgIzJB+hqR2ANzfI6zl9PsHNaM+M2xw3MhQDiVw/mJRt2v1cLcYhIwCowcR3oa9GjlJmn8'
    'r3u7H8TlSH6KG0Pv+CqW6dKt2Esv2MGzlKmCQEci7Qo6ggfhdEzNdjnd1eg7TVv2OpMovGm4X3CH1JQ7Ync8BMqK/jYaMZKE02GS'
    'yR2b0NkeOhQKX3p1vkxMNjMnw2NKMu+kQ2PK3eCAyu326BJW7hc+JLebILBxDJ89XaaPp+HHU/341Ma+lW4QwrjdvKSvaGApWqWD'
    'zn8b0RV/uuJPp/qJ/0p9tz9H6/SbUym9GF1yqmWciyv8c4F/Tm8XYFvCfrHb+ZiY2k+QdmwsXL7vdf+N/hcN0nSyEEm6KQaPjQWY'
    'SkKLLutwu75EfYj62bu6fBDhk0a4I+n3cR/GvxD8NBqxiigVxnOB8YbpMUhGIa8qLF9ALUjssW8MmFbOMBTEPSsHUpaL17uU9viF'
    'iPHko4vPrM9+iGaWXL3Z3du3xkvBZSYbbtsmpDPNa7N0CKbYj1mvGATwaL3bOzdxWFFmkSNRL2z+m3/3QxAixyOng5Sqc3KYfhQ+'
    '11G83t4MKdBF2snp5fpSexO0QfnzIOmwZSKdURSqN2Fd8HYoKNVwA0RjsAt2PkHEDZAadGqZ3wC9gZuXnocuZlxzfYmmFZpG+JkZ'
    '5qyZmbLJivG6xzazQguZRUAcRLNJWqGQeMfRrnbbxPgpGffi2hL9u6RfjNuUnKA4zTKz43eMdMl46lG/zOWpzopaaA7SPIcLNqbB'
    'YgxZz0nSZmSYpbyGhQ1UNwOf6sMSeO1VrWc4bc9OxsX5o2UonhYxuzYzfC20JfPDQa4KMc5WEixLET2dky0h5rJ1UDpoPnq89fPD'
    '69u4fnPw5fDLl0N2Uvry5eHvar5d5Wnv5JRj5sRYSJCg2UApE9xuRhSfd/h7MS2CpK+TKloUf+wwJEDByc7lOOaBxtxQnfB+7aQH'
    's5eB2PYAewKJEv7kn0c+5kKLaii+reHK0stOmo0JcCSO68T6CyiGwZBonPim5tMmGr04avr+NcMeMecV09eAs1DiYn1Rq6TTxRIl'
    'gLtFotD6vD3Lc5bI0HY9TvNELVkbm4lKpnoIlLrMmqQEifaWIeGH1UvC6lXprLemfU2sAYwzAZRqlvrxk/8JUvDuW7poqfhi9ANu'
    '4pQD4sq33pDXQ5vnUo+5z8fR82V/b2Jpk06UCYvKLCtXFtKeC3Dr9cqw9wiyiq7XI6/HsMFCKgx3tJz1oYdwQlvDv1bcNhqEX+Pt'
    'B5uqEECV/kqcX5+uPR5r3ShYXoxG/TQZ2s03KhrDwIhaBVaWx06wZvwQDVUrwe5vvwzxm+ly+YkFuD0qQ5nJ6oGRNZnLjPm4U4tO'
    'skLwYTfdXYY2/dUxEQVISt2SCZr5TFRhhAGFHQctm225lSj3Vauh+oGrvVE28dccseGsdS74FA7fqSmf4BjalsCcTTMKFgykL0cD'
    'GBIRSajvG87NpcHigCF0TOfEghGMwBkZyWk1i7FrFtWZZyAoT8xvPqG8UTlyEvuleY24rPyi0ydTkkIFB7hw18NI2nMuKdkBKW5y'
    'Xwl/Y97eAmkw46Z4C4wbRyi3d3BOrBvneIs4z9dcGOfcXro2R3c2e+RZ6hK1D/B2YE306jE8kwrADSxamBmU7YpbBbQtdm1ZIsyk'
    't5wk5mhwjDrlUd2LWy/hR/Tf/1t0JLwrvndAL9+q65h9UZ4VnzWWsFLDaMO+uBXuiH97DXM4cb8wv7hlKtx9L6+estVcCUILBTrN'
    'O2aPZEBkYp3RJnhdbhIL/jERRGhMmJVhX4iyEecAYM3eAugXvkU2FpY1WwBaMWa+0mbdTxHAdzAkN+Yj7IDV89ofFDMV4G08Th22'
    'r6AitfjMMa/Dv9w01E66J8QkcWgYIs6IR6KPmzod03GY/QCi4aSv85GHmTPag7SToEOEcRiwCFHleRFUHdvsalKEipnCmNcuQWER'
    '0AfadISSRUgCzuGKhLUB2cbGGr/vXdjsj8yhXqr38JpP3FYIRnrewuHiZWGsR+HS8zuPO7j1Mkl5B7ou6KA5HbJFUFzMWNHhDNrp'
    'xQKdU+GbPqQXL+ml2xLISWkvvEjWXq6KGbYJ0im7SlQhzlm8GjGpLIo1eTAZS2Jp52JKRpWGUzIYc3YXjgMUYvMqnTQN68AJNFnw'
    'Cy6QOpN84giMRmPqdSAAaICxY4kwNTWCRGd4BX5Qpc7MITJLN0vwHIM5UU6ByLQ2NF5m+HX/Kqpgc2VhXYIQw7Zoc3EV3WW/+SQy'
    'wnRtWKZvq2kGJ8Ypjho6CrBC9XEl6IiCIwDYVzhTZAC13qKUtjjBRweT0Vj5AHG77+Ul1HDpIwTFR0GylGgWGxbKCdqb78INafGW'
    'PbzmNYGzSjBlXDE2h8txP71cbCMYYAswsbA5HA1TgxvlbJqJm/O03e2+LsxETxSCNusYiG4OcV15CJsC+2mXGZVAxQHtMeg+jhU9'
    'beu0CkDNjLJqNZxWk61sIJLE5EUg2TRr64X3P9sfaSYFFyesC/9irBeVIUZuENdY1GIchYwY8pRuf+PzKxYPNDK+VoywmUeTXG19'
    'Gcb/pvIROAqbZOp80SNweLMecMGY0P5omvkshTfQMMBCf5R0TY4BzqEkWZamGQzHQmIPjG5BoJBeJoMxkbmy6AJr6sixPTRfzYxb'
    'yrPxuC0JhNBdLGZHdMNIWOAOjF4ueiapfUHEh/m91nwCMV+fdp7l6xvWw7whlp+oyE4wc3V8e4ysQsKDoTCFUgMZz73fIqmZt6iZ'
    'kotZU/LDZXLjV4iEdOV86Y443BbmL2CspjloDGnxOObn9a0shRPbVw3dVfEZsqwpKev64lDvpFrZWiHj9K0nD75r6AWMfW9rWqGS'
    'Kq1UDzwy6tAZTcoLMU0tW/h5eyYF7Ya1tC9rpqVdE2PIU8SkJDR2cYZWb7Vm5RXl0X7vkQ41j6n1MnuEHMqcOWO43oxRuh6eBlZo'
    '2GSODGdsDnLnNsz0EPj2IanlcNGMny2I7ctotq32XRNSg+EZV9r9IWwwF7q8e9kHskE9PH6BoHcpqOZD2MCDLhSRQXu06QzAsXek'
    'pEue2THN2vTqB/T1KEOEl1ZvGXeag3Im7r0xvqsudmf2FZPuYVYCFnzH7RQkWcG9sE90Q9ZL+n5GAMltfFcM9ooM6vUIWh+ubj75'
    '1n8srJbbqThOjM0GWX+T9sd3DpRnVB3x/VsDvPtNKmBXzf4uqfqDuQXWSqSxF1Ye+12yiHRbvLQU/TgCOcV2EZo7wxNJNxD7FU6b'
    'RPqLkp1m3qKXHLhYxNq0XRPhHqDxLVBAno1ETrcyp0+NnRUTQk2l1eGXjpC8x7QDVQczSUHKUFAF8OHb8oS3zViIl5u/5KMh4m9y'
    '9DOUdjlFwUdtuUzrGMOr/om/4lY3aAtwnqG6H8zDof6ILqcBkTex5FcNpU82QWsyzFlcb3a8ql+nZfG+joaStH2j/EHxvI3wggHE'
    '0lF9zaTIntmcN9bofsmGvRB/bZtjtN3smZTNdqXYioN/tKLC91e9HNcAF+ma34guzfSK68TzGZLxcBvhZOwYXG3N9IwpwrzJs2Zs'
    'jy4lWt+MZXGLGRgN3tcrrpJOKQ/v1giqK0hh/3T+Eo03uxEIdeyDoIE8QzR6J9FRjKYQe9vqaIPkwcVCvL2s9+FWjbuYNwZLTsme'
    'xByBDqf6grCKJU/BrB0nPRCqqqFUMPHoKWcGoMo241eOpaH6Jpk3sVSSmNniLxWfiqSC7UpU9kKlEbvJw1Bht3b1g1B2gfcdotNU'
    'JGMr2B3MyM3mcoHq2bVpLyWOR2RTW9q4HoW8bMW8bbQyqrX9BoJwptlDY6436Vyn0VmOlhaM1HxCIvewwsQ9qyVKyKMU7S8KvtPe'
    'KJbUDVhRBtxHpfKsY3uXacc9/FkDBOV6Y6AfiQSAsE/KFknEggSXQ5b7GikQ9FGJFDf+alS2wCDwuyKHMGtptrNsdPEKUDBn0FVL'
    'NHt0W+GWVDq1FmLc8FBGtXnsgguyhaO+C9uR9wn86VNJI+9SKOBAswVwFP/zP/9fLDFC5kGEKaCDM066EREPHNG+7pMiSDZALYq9'
    'UiAvRADXtMLvaz9L05/4m/PTAsvd4HBLr1nl2Nx7s/vTV0ReaugZSDqddMyOYC2J7zr0IxDY61WCkDei7y9GWR85w7yY+IjV6Hp4'
    '/fbd/s6nr592/nXn5T5dmuVP2y9f7nzcb1hJuY1SQXgYuVN0hhx3gaNoE5Eq4fI0jjaokBEtzh8hPfLeF80rEFR0rrvVAdNpsEdl'
    '2uzUMF++aWnaN6nXza+ge/t5za/hNcf1vOdibb+osX8pJuyZMwWxLo/O2szrc+r4kEoFLL/im/KsaMr1z//8/9WskWQKADbxB+lM'
    'hMPIx/cbB8dFRujTcWi97z1aShhANer3cc2xDeV//28RfC8iL8MwfdKYy+PeEIYprqhWHmVSifFXqWJlcvjkJC8Yrn/P76wklkPA'
    'aPDU3GTm4FR9u20i1XrJsAXrBclkMZzCa4J+fG1A8U19L3GSB86kQJf8CUyVm2oefyW+BURbjNkkFDr5zIvdqfY1Dc0emLL9jSb8'
    'oqmiMAfLAkoWrQhIlDWhJSHA/Y4DQzuzJLXl16CvanacSPj3WGqB3DpJYNNKawkDzjyie7LBpltELdY9q/j97R9hJBb/fHPwJY83'
    'G4f17+ODL+Prd7f0z4fbr4f+w5elxcNH9aWTqcmEQH2+TDqnaWAsz0b1x+pSbg0RvcBIJ/nucTz0I2VtmeCuyt4cWNvxiQQ84l7Y'
    'YtnEgXUKuZDs1JxLs+JTGyMb98ELWB2+J85eXv/OXIgTdR7EXPdoLBz5BzY6fMPi0NBy1g9Zv8N2XIOD1cNCAHbnmnzJgv6lnw++'
    'dGldH5tgEpd1D/HYqbOT4Ga0uoxg4vYtR+Y0NI4r65aJ9rzuTPDE+luJWU5cA6ChVRVNgUCowBcfm5ZGCb2clIC2ERE3PuYgo2DT'
    'tWqMaEvUmhZFN8OUgLZNH2l31ZDaZsvJsiubfogGkvQRye0q6klA0IRPlJpkD9L+JJfIpehA4+IGUMXpQ8OLVfJNXN/SQRjKZ370'
    'bFbwIqGNqxctXxLwj4vMRhYvoSFO7DCvl43aDGjXaSW0w4PJYbS1JecDMFNn8WL8cfvdzv7+jjV3G2rSdBetUeB4+Rf07W46mj/1'
    'X8wtoELZfsISAg5+B0j2RnzYzFlwyil/rQGetYTjH0k7pwKLUY+IdjMbtXNZjAol6tH6RrSicIrZjUUWsLhSiGp1JlzKWbRebBPu'
    'M6i0zt8R3UrCf2EWMcffjR5HZ/XoXwoVqW/tbE6hXzsKb+nY3eK3GQ8ro7Q3W4srVZeX3aYy+vEAVTS/h4ITN/I4WingBKoZxtj0'
    'YoJMTIRNi9A5Eq59BrMDe8eJFyu0MrT+PuKKiAbkCBYqOPrfP7w2325bMA/io6gIkolXC9fO/M62VrfGYeoh1sQ9Z665o0pSgQ1j'
    'MbpWtISSf5kOxsLE2zs1pCTeq7kENG+5XtRq5Dk6FgTJOjnWP9r3CVSRXX1ryJC601J2c7XD/c7kE2hGCyBaFlhZnHsURB5e8k2J'
    'FISrPVEq4WQkAlQidOLpEDJ8jvR8zFb4ade/72XuyvzJA7hu+fUWwv3g21tJ5mYKvOvl4Xe8MH508uaNOpodukYJwwkmC7WvPYGR'
    'ewicuGSFnNQbo8/G65cXsnp+G1LUilOLiRHckEp9iozUb8VFnnJKVb9X7xr6KxsMFsY6w9q2Y64p70bzYosg/IrJ2+FHPK/5pMt9'
    'aZ2SXa1yBjD07FYFduXbh89oSHSJz53CK4TjOK8hB478CpwpExJY9dxkCexUcxvUvOtBTE3d/cBI9q91+35ZXlvO/69BbJfva160'
    '6olYLrPl9YpKCh1O4WuOCbFL5qtgU246ebLmOqis4XfKxsam5qrxHrT1sUB+8b96pZ+uVZUVU2siyr8sfl2KD2FxzV1foOuLQlv+'
    'oCsas5jzr8Egw5IMWgGe9Ut7GyGvQBTo567Yoh3wA3FKh5bk1M9Fo2KEgiTGSiNCelCTHKwc1h0V4X1pe1+8A63YxvTDu7zciFZW'
    'xchK9glVfRxg8VHkobWAuXWNi4kvcVK9koWvcJYbVrwiUeMk00WNTinceWNvCh9iU7IuYXsd5MPNPX+dpTg3qM0ezco/4oxYQ5fA'
    'SphZ3A3vhrTzfyLTn5RtzCYn1tzK8dath9cdQ7/crvFPetUbnu0OY/sBNrHfqyEabMWqTMSqbXmPu9SYtQgmUhwmuyzQ63GsZWo4'
    'GGN3NKke5P6bnfc7ewdGD3rY7MT5adJNhe5FMzKq0L5rYExIA/QUIqSPHkL6bLfFTpOj6ua3Qbu8/aZpud5N8cBy1FugwlWRZj+O'
    '4p5/UQwD2DvoHVqPQnM1VWfZAM4UpWWQ1sQStGMPTNfoyUDqGn/5EI/rBjK5cX7RcYGTr5XWlh7qfm5aES6FFda8sRjfLJOOiVa8'
    'W9JCBFmFxXRGcu0Z5ovNQkzvQdrh7/x7dXZwT+9mhpXb3DoVWou58b5M0L56KTW3SCs9HGPCoLIEcUZA+MepMyPqqR2axVv1tarm'
    'DrwSh1tNkaO9JV6Zc9teS6x4guxhmiD8dI3ty26/PQRnCIl36ChmxiM0kB9Oa1ZjTn8wv0GD1i2T6uFwe6GshETpY/CkvH/xXSP4'
    'PP6m/sWVzP+yWOjr9k44DIK3ltIeXxvLcKZTbfgRlweF8My5CRcsKusKgvaW7soflut2LAxW94vk5JkFzrKA6kGVJDZPd0LD48xB'
    'vSisy1mYDw7YxeTwELyTkL4hr/YulOianDcHB0D6Uq0kBhavld4kClIuRbBGJwzG0ZpjQqgcSkAauoHEd8iSRmoT8mF5/30ucecP'
    'iVKJ9k/hTyuNq7X7KHC8hDVwgwEiZf0wpG20JzYkisTfdBHvWgbZ4o2dkUmWho6YD2xGHM8XInSk5wy7ZFH1dEzrwFJl07SNTCZV'
    'wYCyBC7tsfUNYivxFQyDTzpHzEzQrE6ISvFYy5/e/vEtZMlfDr4cxAc/f4GT7fDm+8PH9XirdfD9zaF5d/iovkV/D5dOjBzZ3cyO'
    't9li0WqJt/mSP/oypH8cE6PpCCq4MKZ+y3E0mCau4r48A5s7ZYJNdCMiinlsDzAIgmyYENzO7BvxVD+wTMElgjHC5fm5eL8p+a6v'
    'IXJyauxVKKheObTpPCG2fW9CbTk3YYFlDsM4VEc7AUXvUNrkcxX5+ky6q0DxKUnvVDZql8RK+cVVwm5oPfDSZDnUpMlZ6YSy8Mhe'
    'vPe9E3ncG4QckJJZOHDGluK1Zhvmbeg3pbRptcAF902+YaGW+jxWNhLHfFgA2CcwIKSrJ9Z2c9Cn5opMNeEd5OdKDPX1gFMZM7On'
    'o6ESzJyO0EmhsQInzsk0UQQCv7fdx4/XTOQVrURVOMRLD7mMqKMWTxG6oYaHhdRcSDQFn1I6MSzpN8hxOiZcTZB7cLCLHCyCipgG'
    'hqye8zkC904Qr4PwiEBOd4QYbu0sTfygNxkaTxFm+FN6nMejfnef1WUEExyww4/+KlsIeluL3YkW6qz0kjra4t11nNsVOuQI9CO2'
    '/DNAgVzURbfqzCjB1Lu/9oWQHf4/f8SpabCn94tFgABnqBZvbVD1Q8Kg9ZqGB5gjjmFm36VxzdIwZysHjE2bRHJOHAPsJ6wr6MvA'
    'yNcODjB0TpesoMCehe7E4/YRTasGFRiJRyOrV7u9nNq6Yq0pa5KuapmYYnVZXcqiLI6h4Ee4/Ipk8nvfdI/cfLP2kmbykjVWLDb1'
    'gjdpKBFV2jqlK0F/gwC8RziPDbZEPstlCOWlfQSwmoym7EEUczpsqvGdaOE5lFAqhFhOiLMrifc0RR9L5KeSNTXHBdgfjc58uxET'
    '8DsUKYp3nchZ72E+ooGWqw1HQpMNYhCBQatNNjzgG7D420uFbi8Xt42BMgp3TF0GLgKja87x1UJ8MhZntaKB6MM4OIJ9IhAcHCwf'
    '2tALuCVa/o2lRice9V7Wqg4OnhzW79c797fq+ps3Fs54jrYL1/5tUevKHQcSgEL6BacN1wjoL/f2tpoWAFnIqwm/31hTAOZPbBSA'
    'WhkrXfQVK9k6kDEPenkO2Kv4pDKlwvuq/F4eXN6ZyMYLYB35cauPm5LT+ljkmZojebJDlJX7hEAZmnTmWGPW8yhbPqV3LPHp6dsF'
    'soPqDEXX6qxwaE29JWVFeQ3zWLyAg8AF7BtnFtEma3b55hWmAdZkMf2MnoI4CW/SUgJtesYiHHe6AQBIhlcVp5/D/dsgNLI0EuHb'
    'muDODzjuJOLju6OTzwjnbbL6jbe8aONrOg7//TcFGb+uhJt7xxg3g8q2CrkLvYGZb7ve6Pw8hFs+NAtlr4HjpfGNDZuvUNvc3DBA'
    '671c31Bw9fIWMi0taWFw68FZFMcYscsCXnXh+2ghQqotvmoWFqMF5cMWVpr0W2yS6HbRl5v0jrP/IRIN1IjUj6d8hN/LWvToUZsI'
    'pUePGtGj3iTp9zr066hDEznim/vvf0ekvbP0738H7Ta0Y5OwdsTKi7c4LUozRFtBjpvOaRCDkqV81clUH9BHP/kkKCu8CpK0legq'
    'TqXcD7NUNuymF/fcS1TpElQ+KCWo5L6rU08WEwV3To23Gbvj6tOX6fJyslxI4cVytjDrpQpgnGRk3ECCl0Zk8jj2e2EuR5PXyBf0'
    'mzBF0n5V0kz+wvlBpIyfwGZL37XMG7/pcZbega6phEPYGrsIKaz1PXC1oKPMP2PB+Bk3gCIdKQ/r8/O8kIYEh7O1KpkfPJi3jEjU'
    'ooaOSrPlArsJDBY75lhwDCc6dgnNfbjIvAeAemQy6wiITdkCdOnn769XGqu3kaEZJrhODgox9Gunq7VDWkuUftJ4dmfpJ1xar+rN'
    'qFZVyO1/7VD9UNDBweKjx4d++2AxdX3QikSn/zxkg6y0y7p4GdrKQbN+d83dQj0XJEmceadhqkr1XvR3GTGqiikznPUpy7aIHczB'
    '9xGbIkwCAvb1NAbY5aQl9DT7o6eFKJrpHEpCehFHyIiju7oeGxwI0liWuSSADHHch5RzYF0BwIiba/WNXoX58K7lhO9XqUsexKyy'
    'mEnsm4sZcsN0bvOSvzU0C28hlR0rWqwuRodqQoeCmZ8OZb2S4wnTHrQf8NmfZCO6jxBPQMwvwMjYk3UxkpQcfL8MxQEG66shGZEn'
    'Af5OGhNXbGOrRNaVseQBZ0RT27jx/LwCqzmTtK6Yk+22XhViMLT/DJbZaUbLm6Z4MGFF8nVUe1RrEaG2hDxfxH0+IjbzcR0PD5dw'
    'Uum4YqgHbDFLX78c1rVcfgj2lCs8kuf6Vl2r9ajayuEhMhlJ61+/Up2v3PbXr17Lhyz+jWpHUuyISh1xqSMuhLtbyyFeNJf5+9+p'
    '0N+50N//zqVyKRLdHnRODyXmSDH6Mth7IkA5dTDHX8b8w8tsYGL8MV8XZ749/INBtU1hVkoVU0H+c5rxO46ex2RBi45baktYPn3Z'
    'ijgFgm1s/rGUYtWn0qrqZmZwREIsw2AWDO4HBzK0VRrQyqHfmUkdQpxz2g+6koNX5tYNo1375z/+V3u5QQwohgaTkcRnFrlBI3Ay'
    'lPsER9IMkzuJ+d8qtMAfGtYk09LCYd5EKwH8cVTQjiSOl2G7OCgy+GYlPB7zfeuZMMALSUYqIUnqzntX7gZ651GYXuIxJ78vOh0a'
    '2/CisH+WWbjaanwQSchrOgqEXjqw4LJ7ozrt+wlTAWuhMFVuM7EFvGxxhxyeeRXRm6/0BYIyr6wuc4oP2vqWhpynpeu2xOyjpiZg'
    'rejT7u7+/9/btzW3cV3pvutXtGhNARBBkJIdnwwlkSVLcqITR3ZJcnwSkjYbRJNsE0AjaEAUQ7EqT6nzcB5m5kxV5hfk5fyM/BP/'
    'krO+b6196Qsgem5TEwvs3r3ve+11/dYPX7786iukL0hn2a4q9zsulPR2isAWnXrsR9S0VkwbGcLhBlTT4Qd/+Ffd3Inn5tv5W2i4'
    'FGjX1n/DwNY3Qi5glRMWP8cbYKGqeC9NrzJduWwHNIkpv6HdwOXWNSNFCqOufDbK5yqmAO8THvGleqaiEdX3wfoluxq2tb6a2hgO'
    'hvMAfpMu6V245zNE5TRfqJenPynKmWgcewYbGi7Mv/91gBY2AFJEae3ipz//bcMVHhaLRTExtXk8AvqpalXDK10pEWygfB4u8zFc'
    'khBwilwLIBiqYOSAY3OMDDBayj720UnFSjYs3puTJ6eYBaOMyyxPUaN4fwvDc1Wagt/KNb+M/a0Qe4lnzgKMre0iMgM4ik+CXa41'
    '5IzTBQJR1HYiz97kcGYbexNP90DE1yNyJAy8rtiOugdCWSGizbXEwTj87UqMq0ViMqNrg1NRyDbgJgMq5kB/wVgHTCvqkBC0X7c0'
    'eS7tTSbyuGU888u/i0hjrYkGeZpk4u1luwQrXELq+ekv/2ImW9nE9uRfwTcCFgoAcP8aA9eXV7jyrc+QVvAlA+blK3hGRa84CsWk'
    '5Ssp8i8V3zTEjnF8tI3tJ10OmK5tMig1LER2U+UbYflQO6L8aQkKNStD+1ev1EMo+s7bHzsxqGabU9p0XPc6y+cRJGTbNNARpAwT'
    'umpOXhVGXtAFqq5Kd33G69RhsnmZde9MZ7LfpvSUjkuua+OhA34k7UH/YPu72Ui4/R3m23igpElN5sDuD4GI+o0tRgdHU2iBzi0/'
    '6tTxMLmAqOk7+p1jF5KgTrJ0Cny1jUp3q7iHZ4V196xAdRw0+7t3cNBwxbOlrzpE3hwdBRzEle0IQ2cNjSqzYgN57vwlrO8be3//'
    'a4RxV0N3bNIfdyLr1Kq2j7YMEZN0Uqu9d42d4j3/bnQIm/UvkYhLdqGuNSDtpmO5EFTxhz94b9eWMdwYu07hERxaQiACfbCkboyI'
    '0HtavdaIwdvzeB4ihiIHQ4FxtyQ0lN2oGBgGjZO7S/kNYtRSux9xiViwlibxsdCwOG6WWkdCJ8QGr1Ax5kUvpsnJ4r2simK0fL6z'
    'kzz4dPY+uXf95dev3lrCE3pRtWSJO8nycZffy9Ytl3My2lq3BQ0AUJx/xoG7Vomwa7/0yeJi8w1WgKpp8B/dsQ+9xynnQUmVJdni'
    '7OOanBcyK9m4mJ6VtLYHo6Nd7i5FIHJ3OTYkAqwe78a2f5EANURvs35RV3bxzaM7UbI+V+LWAFdnxRr3rrPiCGqIUbYOY03eRthX'
    'Z0WvkYdcWcHNs8J3/KxoAlW0soRlNq477kl7waQgk8bEINXF2hxFLpYjVkE/DgWFcM2OHW/qr2mX5k+Pg6oirPPr1iDue5X5esUB'
    '9OlxoT5vHpXsI8tVS1pfQ/9qJiWrn1lX2JQpt2gxpKT3W6TSqkPbIQmT25dVKr2pgYSqaxVYqXALNADU1fWq4sZezHjwKlfeghdR'
    'xcf6dsO5vZPvz3Ju9dPx0bz06z1tK1Pr9hIJa6+ZqTRQhfZPjvZjxsCiWlrznbZ0/+dsjyLak3di5b+rt+/k8PUHxuWvqo/cSKy7'
    'YgDogytwFPGd48p81Ceiz1xkLgCrLfmC8wuMQkl2IsXXGHLPO5pXauyWEh3nF2/5b12RJ8k7m3bzCLMXMWmoocvUT5T6ulWQmcN8'
    'QNbGiPtOLETydTyMtTCIByxiWZgRhdSaNEO5GnMEn5uDD3C3uce5ijwvXdQWPa3aFDJ17YoqaIpeDQZsohoai5RcoXy5pfplUlW+'
    'TP5zVS+JjjXSfdxe+5FYbBgXuXDeixx0SIfSGPtaDz58DEc34QhZ4Y2LP4vjcFXr0u5F3jiNHxfr6zfZ2hMd3XFGomue3c4OLtRd'
    'KGC5i5SmSJtB48KEP6ue3i/4XhOhUqqZeblqkDyt+3gPs5PC8r/hgcfkIJQAADcQ4JsmG1/Y7407TKVV0kzl3d363tOahTlOZdaT'
    '7gbP8y408l9DoDk62qiZ+DtwkoNdXo5INh6VPWqC0JBFQ5bgtuChvlikJ+f0FtseKEwDRwgndKqA2boCDiI/WyFDX1wxLTy9OBzU'
    'SF9dyRRLAe1wbtUBTZPuzrJpqShmyxkLO5tZSc3Sy4nOMUKj9VvAKwNV3WBENQZ58Kd8ZjYatAK2tiBQWroIvbMViOiR1INbOxsF'
    'x1H4CAbFshwxTQhK8TH4mQ8//2x4pV6L8hO7+FuRVX8p0nl6RT6tmy6KYVfeIZyWEAaDk/N0/kxoBr0Hes7t/CqdjN8sIOox3/Rx'
    '5961GajfRRbqDujdRqez0bvpHEd+5pySP+SzbruG2vnpGUJQmZ6qvBsQIVXoNTRs52fdJ2jc16eGW4Fs9JGHdK/vE+zA8w9vny5i'
    'F+rVLqLrnNlrbgxybOMeV/zbbxU4F+4EFxmcwrJ3EcJOVVPZxQDoMN2qdbaPj+9d43vA4F9sbrqsIfwU7l0tnz6ySTyACH9kLv9V'
    'O6GeMsRtlfOTPjvY0OZBHyZvzQK2/T0o2m6OTPCH293Z9OzDj7Ps7MNZfvrhMhvOeo9Qyeef9bsH6dafdrb+cXP7yWF5tAk80Jrt'
    'rJGVyIxQ79Wm9OCoDb4MjWky09kZ5rtZrjHtbuYGwi0jk9KqJZA95Fdh5by7SsL04zO3Ata4ZqpwDpbynPl19BTcbMekzW5F6ROn'
    '1R/rLp0vI97M2I1ezeybHLfV9silQmduNArilLO9zt9pTNWYnZfB8TZVFJygpvNxL0FUr1Qhl+sgwrieFtN1eumJ10kPIqUhu4FV'
    'vU4Gg8HY3ejw+dcbXUVP0yXLIcuQ0fZGln/c+3nB+fGJ6LsMQ+AiXASAcE1UmHDIcsLf98g6VZ5d9TyPZIg1LdYoApwddMBZwbuF'
    '7in4QVYKP5A8lX4vsi0IKk3nNBbJ/8QSQl3e2E9cmQQT9nm1j8zIdXBxFKCaMSA8kL8PHOiJmsKofoLTlP66azYu/WTg8aIWzAUa'
    'UUGFwz+o1CX9ClwaU8/pJtRXA5ISPQ2Weg6l2Q7oJUo/YsV6Qo7vQh+aLm6Ojo65x13auiS24gU22WHTPHA8Z6iKJd8WztUwGPv8'
    'QbpLp/luNyZiIFRHm45uBbIFl4fe9lneR+ibbEoZVy+G7U1aZoBjP7Zz6Ei1545DYBU8kOKBR3p6qGJ1HiI+2fZUzrRb5uoUIoN1'
    'pvDW+yGFSel88kniWDrZQnLAWBAnkXzBMUIKNc+YnIwTnAz0KO5DjCPFI74uUIhuVqpljzonH6/om3LK7BgKeQoh/YIuW2XHfScs'
    'hqXc3SVN3NVYkV0E1TN9UTQYEJAVgwGjV95mOBHN6l4bMQJZku4CeGwq3c+60F/Jg+7YyME+jwcphHsEanV948uZEeK6Em6kRWT9'
    'e7YTKh0zosrcImMPELHn/RcommNYfqJ55iwhmY646vVYzMhDdUSc0AXotsE4HByrdCAEbTfZiKbXFcYUbxzDee7gSAZ4rFw5kIyM'
    't6xntGbOqx5uPWu60zm6zc1p52owGfkLk4MwzdfhlHuB2ys8iW7R6fWn/RsNMprylYVOINZo2mnGKwhP/8VYuGhLgdMBeml+QrXY'
    'tryroRl4VnGhcUaaCbMZvHlweLi9e39/4/Heh0++F3KkYU9bnd7tdDHItJnc3NGYtHRksgfQmAhYA+DIDOZf+S1rM89BO2mfP9Ak'
    'CvS0HSY3R4M6BvZyKhU10q4Pl6fGWgcJo6vA08xMnuLBF8vTU8jYPVUuMXxT1oeh91LBYMj3vb4RkQBtqOlFUcTHpz8ka2aMGd47'
    '6LV38H9GJz592KUTAcVpbtWd9zuf7/zis+EvdnqocmvLKy2ZQxRwgedgN9CxF8JEzLsbbyGamVsmVpqj2fB+NQgQqDUI3cnnToiP'
    'o4WQuHUHPAFTDIbPHnzuPtvxsj+ytrKg/AR02nU14+E5kZ/jGmbx93ILwb5U7RpKPAwlcEa+Ynh7vZqHv4x6H/Hb87Sl8KehRiiu'
    'ssbQWOihL8QEnS09++xhS6OaXojLAUvU8wxOfQj0HfEX90y5HHJvaS0y8fqv/MdG2Gv1D9d+oP/yn7i/7sVDt4ar3v/Sj2meXtru'
    '9J0x529tbZPLEcs1GBiiHwyFaTuA7lr8ly3xEyIH4cIzYheO5i6nhYTnQDpwFHj+GOY51PPLlfXoKdV4zHIms6Spl6OqQZQzYK4P'
    'ZvkseytnZHl2zkJYkglhU4U0vNFSHaMsW/KtDKw3QDNR6JnyKrJMTyrrJL90k226ndSOvGepnCfwkvbhIkDDRBYyOWuGAGDxIWVf'
    'QeL6GgIClM9UNSon6gK55B9gr7eVt97WSI8+2jEFlpxOp3gaRCGdsrpXEIXUaEuNjOlu9LsqokCvJTLkbfHrxWTcnYxiUmqqL0vL'
    'HZ98dLmMGG0ivob7gC6wcIDFrdAVQUg50WPEDezsALho5K5NebOVPLjRN8eRj5paihxjUeGIGWF69EGDSw8/4I8AT6ANnrJBJPkw'
    'kX8/kvlFtlcn+9Mecy+CzafdM5sMsxHMVKcu5ewGs0wek4sgZ9bWIe0AGfWD73tUH8i/8qTnurPU8be0tKQtrFFrd//x3bs9Gyk4'
    'e1R+vljMSvgrs40Pk1S4rcL92dPWOo/T5HyenUrdDzf27j14vJ3udZr1O09p85P+oL7N9Gx2ffZKJyQIFMafsF9ALWjtr3pWX3rP'
    'avXA7u7fPbzfQ6zv4Xe9yH0azy/97MwesLXZQ9/ivevZAzh7zh7ePM7ZuPyBxvO2xtWbmr7UOgUlB17uxTzKkydSCELSkydaSLO1'
    'P7Bc7TUsrEU12GVnp3s4kgHxp+t2brOD3WyQUidq4jgCqhQfm/PkoyjN5JQnZzKKWpgfTveNz5MuK4wcfzcZkNyhoBnDgfuZdXou'
    'Oj6ndn5ZwJCpfKrxaWyTymGu8N7hkTy7/f3x8bHFpOCbXt0AdKJBXchDkQd7z4reUdiqV8kJ67EipQn2cHPzKOSRQf/8tXH8WCh9'
    'NOUR+4yZx8vj3qOat/uNV7RNwjwASYM99PrCLgKKPr+RM7XZHdwXWtHjBPm2Y4f2x0+Sh6Qg5w+RypLkkqow9EKekXY8Pv+05eWn'
    '7OGaae8elvcPtu7/cNSDFCB/3KutQuhS5/H5fK+zvrq9dWv4x4iUr127aj22cH+sr1pkgNw7LPe3+1WB4vvDAzn9m4dHB5tbR/vA'
    'clBdoWs/WuYQZCVTWLur/lhb9ajsqsXXqQCExIeB/K8+qTpCvka3dve3KIBVBgzu9iiYj6tHIQOY/JPEIYCoJBSN+8OHww/eEmto'
    'kaD0h4e9ww/bvaDksN1y4k6onxvnGJ+C7WZ72nUw6pteS1xzu73l0q6aF1tmesfpne3btVPatnTkbvYeL9BX+WcO8Bv5GSly5J08'
    'PJGlkx+RPwgezPfwVD816By2j6/n9jWqnFfqG7n6Rs36ag9YqfzLXh7H87t613QZ3PdBbgKE6oFCrDtU+SKb3Hr2b9EAl4GGHJS9'
    'fihE4U3jtVTFdj1wda+h/5tMohshkD1pvtds30hg0AiSmQeIDlsxJn6UzZDtkFrn03Eh4uqEZDLccAvVDyBMyquCtpOHuOBUO7gr'
    'zNrI4T6QSjr3gAmhGmLqcZC8/1/C6ynlmDwkFtLDAIHaSY6YDaXz07/9k2rZfvq3f5Z2I7nESSYYxEE8YWBGj1S/vKnxw5thrmLf'
    'CXcpOR1oNTfaMh/jgHbVDMDpadXFLojNrd1A2aOBTQe6X4wVa3fcCU3i+lLgKdnvRLi8AYLUj7AVwNvNF7S99qPstcr43AY5+PFo'
    'wH5BXWEdDL3Tda4X9OWs9wciZfaJUn5EsVMG3f2xX6tfSJN1GP9EeMeH22Nh7WQFpRaotB7jb9xiPxpievMq0/9jdZuYAFTgblbf'
    'KtFpbljbsVQW1iiJanE5K7QuqWo7mkx/YL3nCKb9x4BhvHJ6o7lBzbeZHE8y8UFl9DdraJJTS1AV4ijMGvpS28PGhxmvc1h+EI7s'
    'w96HVhL0oXIv9JoXA3qxgnEzHYO8D/PTXtzGFbN4srYsCwqvi+xIOPLNk4zP9o57TeG8gt4K6fnLuUwhgu2g5vWBx2XOJNUbF9nV'
    'rnoobhh7Tu9z4LDHIAqnoZLuooZyVYu73P5+a2vrcNoFEvSbo/v7vcMpH+xvh4icYFE+gM8AgQmj0FZTdmveC2w/KA9+o1B4ZoGO'
    '0c3A5xenal6O5IcazpjsvTq7K2u6Vafz7uzrxmGzXDj06cAeHOkyoVgA9Ymo9MFG5+gD/uP4nV7zODeH5C1H7xps+cHhZbIl4tsu'
    'Nmm9t3cv3tWDW+0xk7l4MSe0KG9Ct6sG+dpATbhpdF7W5J1W9LB6NSi/0Bnc7zgu6p00/o66RsM07ydbD2JvFXNX2ahjIm1/vzG4'
    'vxFXo4nJURmNFAQalBePfGLu65aWXJ91YKuHfkSnx+p5OuBHukGt0ijQt3fEM1bTzKv31+/oGOuV+nTX1T+g3tFfzmKUaV4dKAq2'
    'e93DQWEOWB8OpaNped473LZJyDR5XeSu4+DQ2qrcPhxMRl7fE39rgf2LSHJ2sr/msX9VOFA0qUItPYZFpXGwnVukkfdZIYP567Md'
    'GgfuSt9P8/mke/wWxEZdteDgee86/uAmsZRAZVEBBZ2kUPEl5bi4HCTPkJQnKab7x9Uc9urc+Fr1j+0V//Tnvx1HU7koiDqNN1hj'
    'aocDX7VNtqr61oiNvAIyvDMLa20clAMIZdsM8tSVyez7CI6/gMZcddBwnJU/9/lfqbXqaxi1MbxyDVguK7cLcGuwoYOs3tPBrJg1'
    'kzhkR/GmGl59E3T+a+tdWw08a5GJE8zgPDvtGwSlZwXlGbxGaUX49vXLZ4WcnCni1+WF6/EnnNuK8WCUz43ji4flbW4gLnoHbtf0'
    'WjosJuXqIvmqzDD+y2nn6sHKIG3XZodyR+XbsDq3/BbLxG+jka1Yi7rOzFTecFsgneFaXJkvrBJE56hACwJ08C/hLKEFqfavUMjY'
    'lcul2W0T2mJYcAefVkNccOQRGN1HuiaeS9DeZGyfbKkPXKcWSr15wtWnI7HHaihW07RMdETs4zcetCoMLtxO5gyDnlUMTxo7HbgL'
    'b+lJQy7S5Zxxtpl57M5gWgf9OUPkAI21vhr6ogrXFbm3gOGFVTuwA598knSdV8cHulAIT9Tt7u9uJcJZTvd7AHmcqF71XC0ltr6u'
    'nYPzI/IEgF43E3Pgc+qRKC4GmQESN5Vs1M6xp9fa0xgM9Pu7CgcKGdB99bPgQI/4/+X9zioHGROMaootRQAOsKa+tHNLXYUwM8rf'
    'uVa0bCWEB4013L5gkJCNbcWbgYPy/iAYLI6aOi8lYJgZ5zrOkkLoiM5Erwe7uUEaEsWHMRxA5igmWbSbuY+zjlOEC0CPjx3+7mll'
    'FeUp1dbqv6VJsvDrUaKLhJCvpwuZxOFykcnM+CGov5YyWL5kt2VtzANv1eUR5ZEng9Hw2FEnFPoEGwSkcl8d753SOXLuhHA0gT9h'
    's8S6WI4K+hPwFQCweCFipQN2Nbd58+fOg0+9h391kZ5xSPnM4CTVNzsv1YNCqQ7BEV1HB4boGA9Pn7UNi28qw/kQhaW41Dl9mLK2'
    'e/TNqaVN+UptGexeDBndED0+MX1yIzzNfyRXKjBy3SWZdKrZG9kSeDT77VYfuivlYFiLHZoYq9vzSkwt5A8hUGWejn6U7k0XOI3d'
    'zpBYURmdLVXUpb1T24sl26SqadNYGVCjvt9hfU8j+87mXKbTfJH/yfKP14kBAnUmwECVavbp5IjccO48OlLnD2XkaCS77AvqtiJe'
    'dLd2W5QGeXOeCWOxQOwAzdYW6FA+MkfdSpBHHGIwiBh7tTJDPnZuYfidj74+rWYvDekXX46cr6XDJGPuLfWZ3XE6Rc+Z0oNWw41W'
    'RRmhhpYoo5hrICSFLRSBWnJukHzBJOiRnHA5VfAw8M8k/HmEmigtlJUAaP4q/zhfdKs63Tow1AXUSkSE0nLGqnbbYMargVmYSSKg'
    'SlebLvmY6QpNm3CUHBSYOqzFtBbMNfEZAKxKzvDmZPCequuL5B84zl5yP/n04U6ypaO+nzywoC8pyfzx3UiZfJFs20dI/iGFHz7c'
    '8QsyMYdF+aa2NlX/ZpH6/1s8nCcHF1AaeB/nqf6NEAH8iJQTbns4T8m0LPOzKdBdrmsRbrV4toqaJqAGifSo5/3akQH/9qbXi3DD'
    '3eNKNRUvab2FqxewlXkU7t+pOUjLH07D4B0yXQj4dPADDoO0aTktoyDAGgpcPvqSEA5kKfZ0b0JgsPAePK77JrYEOLqb5MMnR9uQ'
    'm1oVHZGEJotNmqG8cN01vxoZwM57uCYZ2P7AaOgoLDgrPODrgdJSHawBU9yuharajp//4KbQNk+bwkua9HwHNP2Y0fhhz3Vz5Vvz'
    'Ioanb1jKZkmfRWo6wFZt5M5zVAK3qBbpWVFELZOkNo6oU2LKt+5CGyhCFOHwGpGnDV3mViICRXdwf7+3Cy1hb9/7CqkHjWwISy0w'
    'mYQJUGtTzFwydYNOEwC8i+BcXZvy4GYRk1aN4YPE73bAOBqFIhXTRKw7hV7fUa4I54yuFNZbIBRBIsSR7qLVZjoIeEXT+EZvbQ1w'
    'TCYV4PXIsztyCdewQ3p7y88Wx/Dw1Dt+B6755tY72+8b289xlPFIGMVvhCmS4x4F5Ym4QwXSfCL0+E8ZyBtnGnwP8fOE0jESZ6Sx'
    '+CVuLpdwbJeX840Cb5bGR/QVbSbiA4yofhyerQVWTbnvSkqVkKVnjR+eR1SbMGqXxKodWo0OuL/JR2W3xkuM0yvEBZuvroIPzubq'
    'Zq25GlSxKIX6FOKhCERfLH0RQE2ExAo/VgFwO9WAeGQUBkdoiJ7n+Sj7NbibXqRd/HqWIRz03nXMophyUcGwNu5d+2nWeOqbO4Vw'
    '3Z+cS13UEfMeNSwTDXFGXDI/ep7PEdmMly7LDWDk8OksPUMK8ous5L6ZZaakRY6mXRm/jhzO5n2NebVpH9zB1y/GLYAIo3l6JuLg'
    'vA7SAfHxrZC+8jSb7w8g75T7kV4Uk1RCNG5DhcDGWtNgMWuiL5xS7qw2yqHtD2SPBEy3WNnb0rSVEwlV5iD4PA4sYNDc5+VmPM+m'
    '3UhlL/NNgprN6WmhC73xrFiOR/A+5/ZioDBneDfZgMPsfC6krixlTfRy5U2gKYPHKrw7UIpoXVsgbQhk2ZySYDhAuiUPecFZ0ZRI'
    'pxbyApFlNzkdXGbDi3zxOhuniIGnMhfpYIwnVYfjUzBGOntNYA3vka96X2ckaLNt/McnrCW8nnGQJOBxxjSEVKvfMbDcDVSjmBq8'
    'VNLdQLg3jkIx3+gnG6ohGm3AORzdMHi6zHJiB4hCGkSFViE8Uup/XizlxZamqk4Np0JOUUnlEFgSCHXqVW6YhQCLogO24ljpVYuM'
    'QplihdpViQ5/4cEK+SeyRhfzTpwPDGDFBig1Ar64yI7pOLa4VjFDLEGTejbWDTArc1T7xsnixIQ3oAi1ZUcPwhBaZzeVpcWNDXGn'
    '+6qrYVk9Alq80tRSg/c9+LxQzIlKXEUlrlhCL9aqVODmTdGyICKMs9MFw43e5dkl24GQdT/hnxc3s/fHWIFZKHLFIleVInbv+drd'
    '/rcZh9utj2nbt1PhCzeTe/tXPl139KyMEgwounC1WZ+gpfVxIxWrLKXuEKgbQiqWaFEdR15PT1DdO/4DQ5qptf6zAGfiHeV2TnO6'
    'mMbRuktdCezs/9kgNTeVTXtzx3fjvw1XKV4jhyTy70NWimviXvMoR2tGVUnF2eiLfFu+O2u7kofjFbhq44s1kGnEvwgm4fHFSrQp'
    'T9k2xxcB6kg+94OqXQTCkJSECBEucZEqDwfq6xK6NS4HOhsNZlegz5NZacCcDKojOMdctoq0+kiJfrEENOxJgfJAHO2MsncdNjAl'
    'wIeGnoIztgYdKX/6zTc//O7F6zcvv36FG/PhzsPPBw8eDHY+G+z84y/+h8wfCnz7zfOnb1/88O1rQsYygmF3e3ueXg7O8sX5crgs'
    's/mJaU9ll29/kUJL+YdsfvHZ59tq5Noyxm0bfPL2SFZqW+gQFH7pUBjbp7MZRSKbpt24X33X510HVH+STl/qNPpHNq3wQeQTkF8d'
    '4ctXb94+/eqrH968/fr1C/S/2qHdabFlH28VCBiUbtU8IcZFOnqKXkbJon799Zu3zpEjGoFqW9JZ3u1sy3+3+arTq5n2eHrcVwO3'
    'BZB5ozbbQk7iBQJh4coGMih/oVlXl82fHkhXkgxbNueGBd2rAKmjArkUnss2GRczhtxhG9EY/A4a9nrdUY1fCnX8WRX+zrrXVi8i'
    '4/TXc5mObv21EO2+6fit9WfnmZzwXiDJd+tTanAU/xPOYvpotGvAj0QzlVWfjkqGZwABdcxEPMykB5uKdH1JfknfEYVCFhlyqzJN'
    '1HKTXZEx22aIjUc0D7jowDfCHQmfCGXYS5GyurKmP7x58eKVE/m6Ns7Sfce0GtIFEXnIgTJ6O1/sKswoUz0ymx2Qqa+AnyGDAkAQ'
    'eMKtRT4R7s2rlKzKfVc3NlJj/neTu/z49XLac3P8xWJK0c0BGwJ0pJOXW9KyB5uJR1fWRtdvNKNmiPg0ANDKNoZeUHhg5/trDfF1'
    'FLm+wE6d1IDXOsHe+JaF7LLpJw9/sbPjIfkXL3HtCXew5oPPod/+fGcn+9Qt0ill0EU6JOOmWwXPRkJzDbRf196Nv4Xe2DxslVkG'
    '/ZnU+ju38qkt+7dvnyHCTI0uWEoFaLoEdhRQpHYTT6cfDh589otPATidbDxMXhXv+GojcnmMD9W7ftiVnU7d+REO5KPrz256hwP5'
    'cTjy/24zbQg81IJL2STspk0Xe5118Z+BdL+7CW1Vn/n8NP33piYCpApXNkyGkqYU9nn0wBHLVCJh+lL2L/X2EyEsIgt2KCrJ31dZ'
    'Oq8UwPz8QfY/cJDePoNm3TyYbni9qDA6Ls7MIURJdvw0csvArvevqpStSsNNhYHzuZtcilhIkDG7gpCwkvoY8zFDzKfRH9nCQLVh'
    'GLgQ7yIzNDJ9xIvdHUfth0hyGIV+/XJ6WhhT6i7FNwvUqiCS3KLRY0wDtDLY2ppAz6CyZcd2TtMciFFVeHp/DONY/MXU5DxHDxCJ'
    'HB6hqaXB1EvZiFgsirOzcdbtnKfllnZLunD3bhhL76O3UzRuuVP0fFII5n2y+tr7+Vcauk6FYr3VY3dp3bsOz92XNwAyYn+Iuaw7'
    'ABFjG79z15a73t0qK93eIKHzEYrPzoXbE04/kLpolqq3CsXutd4jcsjXFBmiwGxNAUCiowwhiFfWwhvU3QFMSIB1Nz++jkyPW3Ir'
    'UVvYW86qYV7NVm6LQbmcTNI5zY2dpyREbjMUp4lBvD03paH15ayodnYmgqBUISdI3lQbApsX7bypYcs/F0kLXCGuYV/namxnB/lI'
    'ceO3QjMcIrFW+0Wq8MrLqV1AUaYlzCyy2E9H3aEsG1bF3WEL/6J4b7cqGUucvMog1h6TDbnup5pSipliUnqwMmE0UiHMlsMxk1LR'
    'e5WR/ZAn3KbWHLwDwjaCgWgwtdIAfWMpmoDeoWajhbWPKwQNPfSECyvwzP6IhZif/vy3zqqPjb6hA16JxworUlDydJ4p18fYhP2V'
    'fXE5BjZ+rzk+kDi44CU92PAeszLzgRkFDDRO9SvGyav+I1Jf8OpxtA+XDdUMxVmDIsDC466k4LgakwTFoFh1UuVtfjLOcKLP1xQ7'
    '/+xjdGFGzPHbua6NmuQAmPMd97a6QWMWJfOMIo50FpNofmgkuiJK1EqpXiLe7A0m1BvJNXhr1YiyCWQ3KVPrcOelu+uFaIzcOWS6'
    'KjOinte+yByhaidomdn1FSiaRWTdXMVy+M578djMihUVmVVdhOWNJljw2wpKjLxYljY2y1wX7dewydxeJZvzKrvM4Ezg6EDQZAAd'
    'A+ZV5pTSBFOg2+FkUJvsWKBpgRmfWs6fBg6QEO5sXmU/gpgdJ6qtS9h6UrdPVBj0PqPzQfpOKAAiQ+XUzoOLbSW/qVbmkIUy6P9r'
    'EvgmNy96NfixLKb7iyfYcGRz5TKAkVI6J2wbmK1psUVAJPCgPRbvxhzz3G/JvYpUH3VPprw2L7FcMkmnS6dAr3F/nlQ+aopTdbk0'
    'DLw66QYvGXOaajz2Spl5EMZtN+NZfAMrQmLwaKx2E9V1eIGSnEa5LWkz18LP8xJ5npGStn5FxpJjfQaM3qty1c1U3YpziwvATnBt'
    'Fm8iLtx30CvNlfPe+CpF6o+ahiGXE0KVXEMW6FNiNytzfkJkTCQLukyvqlx5NAVcSNwaWgVwjBo88y1Zq93q+3gV04/xUQr3Gfrx'
    'q6LRi1tyTrU6RnmJIzuK7RG1Ik2DRSggc9RSonGoIk4rEnTeVRlLv9XJB1c78VGrVB2TmFoiR8x8uhK17tO1m/zRSaqmRjIAxh4h'
    '94hNGbeKLAzBUgsAwVLikMUMoQfVEGaArt2SylW1FFsn5/NikhXlAB7n++9I9d6tJnYKylR1qEnXMSUdXzgdnKv/uXTEiqnVTP6O'
    'oKPQwhE6AMu9udFto3PswCOpxs/Tk/Wj6aCweSO4TnzkSPltK/J4Am8JvxbrGlJD7RU8a933pUr7I5cgKYP/EE2rPj5cJImGkSmm'
    'e3WaVtkeOoaVVK2euRWpX8KJc619bDJ4dmTbg/32F8yqixn4hVcda1/HABt7z48kNqI/+mjbb/0gqRc97Cg2+kCFtwb5qKSxk1P3'
    'eyyGi7/Lq572lnTXJYs/K0zkEZqtZJzY7S57ryqDEZfjNMEf6/prLRtNnNQQHkYLUAX5U/y+X+5UwPsCzNo3ssnyMlNEjUgROu8j'
    'TNFFn5jaq8YAKDHobHdWnexHlnq6YPZzIyFzFwcV3GeA4P7upoPYReb6rhk8bu6onhjUVwQcbNdu8CHydDVyIfIkWopFhXjFNl2N'
    'rlffAZzTlptbn9+46mXhYVKAmqhRuzthXSmUq/sadGDj5ZnieFocF9FvWJkpyqKKzBNJNWLUAGSDk+UcrplvXT6gFSp3i24JWvfQ'
    'aW8EaXQ5ZhudqdR0lo4zgYnD7Xymvdya52fnUJXNpwixL5gqNrnMpzJ+5/XmfLbI/VsJd5y6PC1oRhkZ+CX6QlHO0J5hHNjlGamq'
    'ee+16SCxY83/yhZ2n9MlDZ2JZAujyhcI6pXqno1zmdTXcn90oQi+Tjiq3YSBE98htVjfxmvPfp1x2DeRLvK7eTqDFzJzmumsmEv/'
    'JH3fffCwH9WWbMl50DJIcxJSlrXXZhlG26qzjqA+K1Wt8OaOoSrKBvx6qBu2G09ZDxHXeNyN5kYWnjEWywVP30c+1EkGNUhd4FWp'
    'SMH98ORLhuTsJgcdXYzOEbdkU/81z8zpvtKYmn1NV8oDXWekkVlVGEZhpdPyIknPwCXR7OZsIaS9SnmrrHLVbMQdxKCSIjShlJBP'
    '7t5tNc1VLMZ1263FX54zv6jXKwSLNCUZ/9zbBNSJWn2DK0NniNJy4fYLFsBqqpg20aBjJPG7Vy/deuf4fpRXJXEjoMr6jie6VM3Z'
    'vtdl1Jj8/eSl5t4FkSAPw7ThZhV1Qa3qrEk7mKH9K4OTLyxhijKxsbrMaexu3a6sdfmf0GzFZdXarlFpi0z2od2Bo64zN7lbItPV'
    'NNfb3TDtxkznert2gaLFyUZ3k1fuBPR15NV5C16BYZ060TTftobqlHcqQneVcQssaO6cMepOkc4Zpj7vK6/xGlVYOYVJW62virYq'
    '9by3WqkrB10+fVD11FjZcM23R45vAcag1cNzkc22hldb+FdIUVlCoIan52yOxE4n/vq0hEMsJ1RPeVBs3sKSYzD3/BhXhOrYzjOX'
    '3LJEU+QGMydgSM0X/hQUp6ea8TNH4HjGqjvvpGVq7BYIcVCGoYzvc61oTGKurkMp2jmVyyS1qPGFYvei0inYQdl6OHwIhQYqONMG'
    'yrQIcSTOxUVOB2+Xp+g0y8yV/SJD+6lyA0xotgzOd0pw3377dqUHj5v/TuR7yi7BK+Male0P8De9FzLirFitz1989cNvXvwevpLl'
    'b9MT4o39n/+nigqKaB3X/jJ3ELrHj4cukewyRyLhheKpupLwTWYkCQprdosYsMnpDPCH44As4ZzlVohDj+kWpDsZGRS6lSgDHxzL'
    'JpXD0xU4Xc5pf6ZiFXH+BbCbmWSqoLzERSBzLzyacEwoKm3Rw8DWiQmPxsyLZfjI2fsUYEsRwyZT+yZDPs6aJ0HopjBbO4jPt9Hw'
    '2aPII5z7R/OCjLoTTtEkpAvp/BZXvyx2yjR8oRYPxQLwToSZW6IlZEoiCk1evi6KRXfKGjl10+aMxbUEnQ77dGv/4zj0hapHS2xS'
    '6/2HD8ndSbwZem6cUu6b82JRyN0DH7+8jLy70E1Nl/CduQzwjIPMuQcTBE/oAyxeDvMdTAKlpjcwOLHmzD1OPu0lr7r4nKYm6Tjy'
    'Ufm0LGj5oPGZoma+xJAimBUs8A4RQuJlVlA4dP4rUC320dH9Z+l8KPtnlBfvZX4qXeViDVcv1mNZq0rHh5WOS5sHH6miNgiL37HQ'
    'PovG6T1qhNL4eJnOU+HKEJ0DWmiHwgU+44ApaUfoxFThy2IS9uKbN5gTqezaBTB1vsvGmiavqF3Jnb7yCozK7RpU8WyPFlV/61ym'
    'Y3ddGD1mfLudd2OWQYNHRZ93iZ7mBXlrqOmMI2i9lRDEboopaThcUdWLSGVK7QQJTusdVExPstrdM4BGhp07KwhCogEKQoHg1aZD'
    'QKXpWJ0sLkQsqPbJ0eJFPtvYe7mwYCLyVcmDnWSST5fU87t2RCiV5jHu6ZXKEz7H1L3rpfB3f/9rp3ejl59pd3CoxuRIPI+lRfel'
    'pJOnLTXVopixf8fJTb+yxjSFkrmaeKoA+HgI//L6E6HKiFhuXe8XWE9TNXpxW8Uf7VKaPB7u+XpxHTnRfiISBDIzvoQay81iaXmU'
    'CTOfDBEtMEpp3JNZU4y+6rrTg1KaiGNF2Irs2Ehdbckdy/TKzUV+wgWfw2nnXV6Sh6H/ogaZPL4YjvbogP54Gz9RnxLYNYv8zOJZ'
    'QtyLD2gZaI1vzvPTxWZcr02WT9hKzXk+CkncHyXID67g+5cisJdI6GoOClxPXZkRHc28P0fLhectkB+/0ghbVN0lmmReyWhlewxJ'
    '61bsj+/cDvZbwC9xP57pt+nQ5gOWWd3DLwlsgY0MH0JZY0X4wer26Fwa9QiXHU4kDrNMdnWPvL2a6SYg6ArhIlrXeNV0tl7uD9om'
    'aAKnw2FILxXNkpm1182TH0zrFMWbZs0kWTvVWZoWxnRlpq0omrP0G4SKnBWYRe9yHJEEosdJ/ULJszBGNLPmQLxCylvHLgod1dR5'
    'J4DSvszhHE+/QhfRip5pnlKnm5tL60Ojq7ddmE/rC/MrEVVkbLzeb7ltHZYU6fI5yLIfhfYsJySJiBV6vgsNLeeMheSx1Y0Wtrhf'
    'FZ1YOJnOm+uB/YT5vixYjFNtZX1+Qm1rzQJ84e5+9Z5aNRD6947mqfwaEs3FIwJ6HC43vIjIT0mVb7E45H6HXlQYfoTfrS/gbwvc'
    'i7p30Cg4XsBWZHSapwbwdrfVt6Xq6LgeP/3ln376yz//9Jf/KwfHFkaTMCKlGNYIym2bAwsr0ystUHdLLtygNqRElE7cdWbf2I1U'
    'BmSk5G2BVVYXF724cD/hKJgFtY/3oyhg0pfSSnd1XU6W81KowphxAyEbJdbNfDvdHUtzf519QlBZZRfbxlnP1ShhKk9s/uS0nCCe'
    'NNUIy3hn8JrbtVQvifoBliE3Jib2heHKqMQEfzIKTAeKPqDyKtAPdXu4zcYa60IWM++BrFg7TJTOn5b+tZr7sfmONyQy29a2osre'
    'xinIfixW7sOhK/rJ8FuWa92RRj88y1CjGfeuTQ9wExF+Lr0MTtm7HjioskJlTfFYW+JXBWgxtma+UFQ9lmM7zxbz8eYfam1geHok'
    'pI0XgXEH1ytvTHeCUtNMudJQl/I5rsZ5NqLatIVWGMoWlSBIN9tRA3RHMTqj55zsxnrALKaTJuJPtnoxUE6JOhbkGxT2P4B8cMvl'
    'cU6oK4k8B/9Mh72rxU+E1+Tgdb4jCcgRfsPVquRfSsyAOapTF2w84yrdtd6+d6J1+F24eM7ydxTFeZPbLSKCqSPzoC0UdEIV0cec'
    'ZLW9nRdjd5esuMCahILVPbfqRkvNHsgs6zaCwJuAu9U9hVtS6p+CijKvOudz5KQL58ahfaNqHstjWF8wKyKgDeoHZTJI6Bi8tCiK'
    'W2xH3VdNOjBPz1TzWdrN9O+6kFhN5fCD1s+LWUJyzAiqeI2DZLNlyarzhdJzmAgCA8m7PXUB+EohcM37bUuhPqVg0UotGlycXfty'
    'a+V6hUxkid4BvvipSPtbeGpp5d1oQCYIhs579GycA22NdIehorwIZYEgkPgqlH+P2EFK9DnvpI5IvSnnYrZc+Pspe5+eLMZXmjCe'
    'bV6myCZIAh1ELt10m0DgYH8wV5D5vHrE637ziJiumZMKgkE2mS0gBUPYrAsmtjoYWOAlPEew7opUfKSfeUlaDtKfe026tngvRklP'
    '/Ru9GxvnABg4yXK2mvCiACitqY3gYLDiLFR2GVlVOQt+Z3Dnw9OT8WbY//M5WKZ4K06zFFuBFFYVKFTQjEZ93YNMBkr3Jq91DtqX'
    'UjaAnifYQebxTlRJyym+RNQC/ajR5e/0FOGzfvQRhh+pYmQkuAuWM1o9GK/ALpYXkfNWa3Omf1BfKu0r6bRuwEpja3YtvCycTY21'
    'pmM5ssp8yqQLh3AJ1YM7XGfZwoKDNGhM0xeAmgq3+U7Tq5YLEdLOzm9ztS/YP4JeRU8ZqTaKtkfLJQ+ZsFy5ycpLmMWyj1/ixgAU'
    'bqZN2ORMdMMDGdio8M5Xck+Mh+m8565nKHi0HK+X6lXopvLjRPVXuIgjxsKtO5QwWHTrm9qOa9RblV2qMjIRGZF9OfYvzs5UDiXM'
    'YmdyM824y20Kk9N0pCRKjsCpXZpjeXCZzkelkxko7FEy1xaFmhK4HjfKR48FTu1r7ZONoYy1fmQ4OOFCxUs7qzZ5djm4IWnunlvs'
    'K8KGNbfNl4D0IoLXyp1z+oVIu0KeTl8SjBG/3kAFDQFYXuZnZ/rrDRAS8eNLBXGUIsUlK3gt/MVixcb7CubDFFYtMGbFCWys8368'
    'qbBK0sey7WrYjffOcryHdDQQzpNuYKa+0HutZ9sEY4hfv7TXzFbjqmJWG6zc05/+979g2eyvTfzGril1BnC4h5wBDqy9jjdwHXIf'
    'UrQe7hFOkmveneWIBx0W7/tJNh7ns1LdszRHCpOcpEbS5DsY9fAZW3q8LUOO2F5mICAJX1wWg6TWuum+uBg2pwunCOY+8weNe2xR'
    'GN7bKt1F86LkzN8NsH1yHep08zfTEOsvDF5/YjyNTfmN8fe1Leks0s0tmj8djeIdlwMiVLZi/pred6sUWEbBqb9C11MnWcQ6q4gU'
    'OhD8QAvdk/wEUUkp9XagfjLPNoif/vy3IC8M90hMdN0b0kPPyoABYxGw9cDQ9/eHsrtN3W2FZtCkWOmv7dCwbdkb9UwsP8LWFr4W'
    'aRlUc18BGWjkcYFDt98ihDit21Yg2K3mjux16xICrdRbmoReqBlA4/x1M/dreFkxL6A1y9GI1iLSIPdapjlyhDRbVSO38JDk0oEc'
    'MsFwLWvwd0Tk8vyVaUoYXqrrhurXLIrPdAxfgNJ5PMOzXkYy3PuEm8f6Rc3YFp+gf/zz/n308f596r9dd+T5wQHMXEdHToIinFlD'
    'vuo7GYwQ5q7sQmU9bofdhBDk9LIzz9PKp5jcbRNxwa+VtOY54nOlJghQsfRs1c7StDFgB9Uxo7nTPCav/YzSnh18v3d0f8+h1TqD'
    'fuNmFIoQVBiX6dU6zYkiEP+HNCTxzvQVVjfnttuY8LI7lQ6WKifW5LS+slbSXjoC9ZB1wPnAckww01SVK1zF8gS+PhhdbbOrmc5u'
    'HdbjVno5Rcs8T3DtjFdoVsCNbBFwG5vL4sGakUhpgJpif+4WFsaK0C9zTW315eO1x/6TIV+9doBeXSNx1dcOuYTkL2/y6dnpLaqS'
    'CWqNxZKy0h2YsUfmzwNMGDAEBbFknSF3Du5a+By9O1QJOdyjotH0T8oU5NO+XdM8MMLeXqwhHMbFIKaDrkQRV47OQu/l2E2zspqK'
    'xIvpes8QiPbWNH9sWP4mocN00NWnPQ/pWFs9YgDSxH/pLAjrl/BiJXsJ0FfkGKhX18dA6c03yuEdCGnenUfiJpJ84X96XCz8tXZM'
    'atvDNsNINV/OV0NWjqQU16fppwoFKTLXfcLRqOd+m0ZL5N6qEMsBw83BLg53VCsfrdGaOCT/eEU8Gp9blLbjuPaDZM9X3XoYFcPy'
    '4ydRGLeatGr9d4Z7Bdk1f0SeqbRUNdg+uR+HxFl15onQpdcOI/Ydi5IMIdvDUcUXrq9w/qigCukfuZVVATI9UL9CRqcGGb0bmfwO'
    'do6IZY5k6/j35lEF9zJxi1Lf6EqvAwpp1a+CGvFlma2hUE7prTTGwfW6k2GQl8AXjaV7sloNflQPHRVG6ZVi45i/qwWQiwTeV4zg'
    'NrOdw1FtYJ1SJIqdWHqVjhsSKx1SH+d7AYUVOes/pndvWJFUC1bGBkp0axXZqyJtR5uKlNDSUestIILPeKBmVP68ZCAKf/o8CoYh'
    '2WLmJchUOqWk1+6LNKR6pH2bfD3N6H4fhJ4S9F6uD1+XLA1W1XnGmaaQzkD0Jl1OsaOoiau5V/STk/MCTKys6m9jd6a+MqfprZxL'
    '1qiC8kWkvqeUa3pvLvogCRuPFN+p6NT2EjZzGOo6IkmnoOActIYquhLt1npfVZ3BjBKuVNfvS6acaF2/p1QChC95YE7HBfQjdqeI'
    'YNCP9FtjrohywzisvMxgKkBkO/CLodCnf9zHF/XLWsNYSXf8SrpAwly/ehH9NVYzBtgxx6UX5KGYLpg9PnkOs08a56ppuy8pszjT'
    'z235lLzE6MzleKVtm1JBME9W1+3j+vuP6K8rCgQ2FbYqvYg0yiD4G6kMQFlwoZEGsaBFM8BMlTkKMa8n+FwKXskVNWyzm/r2X7yf'
    '0baoCqembhINYjiRsZaKo+VsHa21ccW+URb0E5ICO3caE1wite1ZUYxMvP/jkheeNE4o5Y9rQDFXuzyJTcM53zHCrKki/UMBIyrN'
    '59PaOc1XaTXvXfuIBKqCzCUPc/anoph4Ebo8mRc2v2D5HduIeTxTiymCGeCxFgpaHVxK9S7qB6toowJ80rnxrjpqh1297rovMbCq'
    '5LnjVFTw6Jk712QVIJy3U7Bb+hVp3wQGQT2NzLreizdyL9LJoVeAr7Vuka4TbZZ5orko+PumXaqMlh5j1f2AGRqtkGQZ8JkOy64C'
    'dyfb1pj83EJGpL1kZ7DzC1zdLHl+NSsWXYMF33Jl3/cTgwH3j656TEjbc80HWbjVBTmK8KnsRWE4QLM665hDGox5AXtnZwXCRAQR'
    'QU5kC307LVN0wxrR+wVYQQhadNwWFT0+Dt8sL+znWv/gNVviO7Msp66aNI7z16Acjd1Hc+BgyIwS6LX1Nq8oi+6CH1Psqbpkkr5T'
    'Mr5auTyUMlmsXeaDp+XKo68nqKJ0xxd1re8bd6SU/FUcB+mnIN9ZxKSuAgetpPDKDLIkwBphqy7uIATEM3fBSdGU37s2VJdjU2Zq'
    'VxGC1+oJr5tDQbaroeJpeWHaC2wWBa1V9TdINrzoxpXxlPV+l1k6hzHryi23Y9WIeU11XQJzBhg+j9jgQiZ26SeE6EWvM83L9tgH'
    'YDke17YaQSQYRZWXatsNMBJ5uQJHItWmRkSPdUB4bByuSUACKrmTCOE7JpJWmZ46y9xN+6b/PZ3EUBNN+W46W4fDXvjpc8r3W1x7'
    'qLJ5qb1gnsAGB6OPb8/AaPmKoivLVOJzfaVA7hyRLOSvxWrH7f7Nq185NbkpuRYWBPzZ3/+alDTqYKurLQTAvfOLcHTh4aJ6zwVy'
    'tpiHRnwVVq1z0jlp02ImlJ/FsfsOpkjvMtXFEaPL1K+KAirW58UJ89uI+O/18BCLCQakERTsBfd/8FlTvYhzWGsx31WDJOCyp8bf'
    '3HulmypdLurZsEjno36ALqVZ6RabgX4EWVjkps+WDEk4hVG2niQK9Vh52XjKks5mLGeAlVIzY6LL5ZRczaQophHdUX8NpmtaXAK7'
    'UleZeDuuU44oKMNj3ijKdqgYKPfO6a3M4QsOoD58Bw8J+lVmi41VA6SrcOB77yZPGUxmvm70PZsg1e28bafXHN3T0aiM/C4aYQz2'
    'vtSQBR25dxujWE2vF00ODa6wvs3DaX0DEOYT2VVNcm+QFaT4tGOZ3C+MGPea5rqRb1fX3h5O5WJ3FpWgN15ZbTZs52lk+UvbCWHk'
    '2aEG2rldhFOvtaDaWi+jcbGgs8ZplqrXqBOG4m0CDaLuc2yJozgUGa29tY5H2IZ3i4u3xWuzKfVuHXBagRbTSyX8FbSGa7KwDcfp'
    '9EJzg40VYKiZrSwEP65OIBbiIjFPMkIEH3d3qkle4ld5HCdMp8MnISryIPfpfxixrRD2iiLjMI3khT1nNCajxIW77rMyqoWnu1zV'
    'N9kC6lU9u5Yigh8qOKGivaxBBvDh5v3EQMrzXh0JhFAc0i6IwqgXYqEVCRbPsfD7A/Q6Sjl0OkGvz1VjoCLeopB/fwNd8jkwa84d'
    'GMgCuSNWAN7Ju2fIKNfA/GDT1GcLqXTbDjtjRpdv8DNYDGR7A8DMDXb2vWu/DE7rJDLJzbEU0CH6WH6pEzea/tUjGQ5JGaRPir6k'
    'WDeqlnySdB/s7CT3k1xEnm5bOz1i3PxDJ6rmLchp+9BIaeOiCnwSZ0mXKdZuG05VVPo5gCd7TYQ13/1qSomcV89OVOLFe+ENau3F'
    'U3782CiYpiufjp5sGEnZUN7H/hJ2geX2muUBDx47avqixx5p2MLDNeTZevaKE2E5L15nf1zm8LErCQigyIIBhGFXsUCKqbA8yyki'
    'xUoNz6X6hO7AJU8PVHq29EQI0HgEwJ1NGcu+euv9xhNgQifvJo2N9Eb6ghc2yUBX/irDxXhWEFOZA3rkmoqw3e7eZV2MIYZZt1Kz'
    '/8BBBVe/BjB8EYaZDgtlnE/SOb2fOn6O+V0Tzd6hhfeT0It63kmkczsN4Id/XMpNqDqLYv50PO52BrJeW2ciDjLj4LgF7isUeBTT'
    'GmWhMOr4TwaWmg987+d0JKrEJ6ytdIcJP6p9sRKWOWmgMDH7KwCG99fUZUCY6kFAvSJurS0wxLvGvC1nauXk/jcgOanhK9mw7Hv1'
    'riHhAKxjuGNxR8AVVi4ObhfgMOCPsHTRvetfQHkTEW5XU/iKr+qfsoFAUixBTzigSnt4D1dXwmHu147TQeeVsC13gZeAT/njV3CZ'
    'XfDnN9n8VD6/2zk6QOt58g/JZ0da+8or41UrMqE/aNVSTTTFWi0Oi7vl29qqu0PzX35QLNsylgFz4paGdz8oVD1RzHVgOJQM5b0q'
    'y8J05VABIru58jZx9hjbcswuowgs3xHGIvVU1OugnR1MfVINu8elASEsfkmx/2yeXWkovqrzHemmflWB+O8YgKxnh32hyxR8m3nk'
    'UGoeJN1vGWNGQAP8GF9CVUfYzF6ETfHs61dvX3/91Rvm+BK5kNYQnLt+Yn+qlcX/mU9nUB071WFsdX9UOZThuEb8H7MrH0QESLm4'
    'AbVkfciI6DaiGl5LrztHzjimkhj1rVW6N4DJruuzRP2MXRaPvpa3m1qJJ20Uz8hXqjhZpQMUUI86H3gQqBeXue9dze2hLxggeqwi'
    '2QkIsslGUW9UlcDu4HZaTWqxu2hT7GhniTbU9lGNEBUXRuINwhdrQQIQrnag8ofZkA/wpMt5AtIBvNNXXQUT3R34iF9xOI+al467'
    'anG0i9NTXLXWE4Uji2m+cEwtstXPkiCczBMRhzryVz/5pSWP+tnECwNYR7v4fgXHXwGE/S+imC1SkBasCkJV6ceg9By9byKd1uBN'
    'B0jk6FJf+psU+8ldotWFfFQhwnq9GSF2wG+OW799280qtxpVPsO+boGRC/tqUDkKsiin+XzSFc41tUB2R5T3D6eHU+Ku4Cmtjcik'
    'ALoM11jZlFMHzxMFSDnAGdXJe5Aajzyz3wI4s4GVrkzfnXhMKrI05qmC37QqJaZUG2XEvDuspKuuNmmp5nw6TMTFU3FnEo9QIRz4'
    't4WuBnPViKhjJuxuewJlnY8GsN6XzHw8X06ZVF7pppqd6lr4KygczeUnvjEt7p8J4qfmTuCTiwODzuXCC1yUnpToeTt8aB2ejone'
    'FPyttbw7Xq2KiNbKmlCFdzD1VCf0EiJuyy/NaYx5jcGfy2rGszU9stNKF+hyMEUam55pkNRhFEDIZbUbeL2/H1RM7BdsZzIeqLPK'
    'QSoLgBC6Hn0w/pSBZlk6WDBW1Pd6xW8/cZliXTZ7OcIwY3YNRXaelUIH30ZkXMcaP28d4gq6hu76BeaKpUu4GYxgXoQarFdX5z26'
    '43PhhkZdCEtbDXgYlF6b/qOjKuMZXjhOw0moURSuZiE8PQ19oIFuVbN3R/l8cdVj3mk5LOHksWWn1bvR5obZWT5t4j4vp0Cx9Nks'
    'lmbtpTksEqNpwrgTZU59dOfxdnkyz2eLPfk1LEZX+Bcw+Xt3/j9/UgOF'
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.11.04.0957'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = 'https://raw.githubusercontent.com/BannerZerk46/spider-diagram/main/dist/'        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
    'zip': ([('Zip archives', ['*.zip'])], '.zip'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
live, closed_at = 0, None   # tabs connected right now, and when the last one went
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.startswith('/api/alive?'):
            return self.alive()
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def alive(self):
        """Each open tab keeps this connection open. Closing the tab (or the browser) drops it, which is
        how the launcher knows when nothing is using it any more, whatever the browser."""
        global live, closed_at
        if parse_qs(urlsplit(self.path).query).get('token') != [TOKEN]:
            return self.send(403, {'error': 'forbidden'})
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        with lock:
            live += 1
        try:
            while True:
                self.wfile.write(b': still here\n\n')
                self.wfile.flush()
                time.sleep(1)
        except OSError:
            pass
        finally:
            with lock:
                live -= 1
                if not live:
                    closed_at = time.time()

    def do_POST(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def shown_version():
    """The version to show. The source folder counts as a release when it's exactly the last published
    version (checked out at the release commit, with nothing changed since); otherwise it's 'dev'."""
    if EMBEDDED_HTML is not None or VERSION != 'dev':
        return VERSION
    try:
        git = lambda *a: subprocess.run(['git', '-C', str(HERE), *a], capture_output=True, text=True, timeout=5).stdout.strip()
        released = json.loads((HERE / 'dist' / 'version.json').read_text())['version']
        if git('rev-parse', 'HEAD') == git('log', '-1', '--format=%H', '--', 'dist/version.json') and not git('status', '--porcelain'):
            return released
    except Exception:
        pass
    return 'dev'


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': shown_version(), 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION,
            'summary': str(info.get('summary', ''))}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        # Stops a few seconds after the last tab closes (a reload is back well within that). A tab from
        # an older version, without the connection, just checks in now and then: then it's IDLE_EXIT.
        global last_seen
        before = time.time()
        while True:
            time.sleep(1)
            now = time.time()
            if now - before > 20:   # the computer was asleep: give the tabs a chance to reconnect
                last_seen = now
            before = now
            if live:
                continue
            if (closed_at is not None and now - closed_at > 3 and last_seen < closed_at) or now - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. It stops by itself a few seconds '
          'after you close the browser tab.')
    if browser:
        def open_tab():
            # A tab left open from last time reconnects by itself within a second or two: then use that
            # one rather than opening another. (Opening a file always gets a tab to open it in.)
            if not args:
                for _ in range(30):
                    time.sleep(0.1)
                    if live:
                        return
            webbrowser.open(url)
        threading.Thread(target=open_tab, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
