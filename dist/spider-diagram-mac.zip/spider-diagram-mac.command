#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrsvcly68iSKLjPr0Ap7b4850okMREET2aqmpIoUQM1UCRF6dZdgARIQgQBEAAn3VdmtSp7Zr3pft1m/Qdv28ved//J/ZJ2jwiM'
    'BClK52RVPbM6g0QCMXhEuHv4FB6//YPuDIK1a3DjYGod//Qb/uIszR79fmDYB/jA0HT4NTUCjRuMNc83gt8P5sGwoB6Ej21tavx+'
    'sDCNpet4wQE3cOzAsKHY0tSD8e+6sTAHRoF8OeJM2wxMzSr4A80yfhewkcAMLOP40TV1w+POTG3kadPfSvTpT7/9Q6HAtbU+Z0Kz'
    '38jPor8YHXHB2OB86JnTvGDpeBNO88kzzXVpKa5QgOqWaU84z7B+P8CHBxwOFj5PtZFRgnYOV1PrgBt7xvD3A10LtG+pN0d/kk7h'
    'Iwcfbf/3P4niOAjcb6XScrksLqWi441KIs/zWBxecjgFJ84KC/Iczyky/IPPf5Lq0I5uDH36CUAyNO/C03QTpokzdawQmJaBbawE'
    'Uh0/ruOPKzF+Sj4KUbt+4LicMxziwoRl8Flh4FiOh4/+JEryQNWHQ/hcyq0k5FYSy4pk9ONKpTTg7GE8Ls8YBBwZvUgAjT5RPIBP'
    'CoFubJijcRB/90gdAaeKG5qWhd/mnvUFQMBZ+RpDMOICT7P9oeNNyZzhF0sLjC+CyAlisfyVI2j1RSgqilL5mmzQdmyDjtJzJgYb'
    '4ZDMCXtWiMAUi0LiMY56oLn4wnPmtp559eqYdvIdhXRgegPL4AZ0aGQWBuv4M5liKR7Y1uJSsRyVh1FtqUFXndao7lFeqNBmGUjV'
    'vTpRPlFHfhcuVwvGHKGAJixitVsuCk1BLqqcwBerllSsFISi1BQkfCIXZUuED/ClCa9F+qQQPqriE6jFlYtlrprspDRiv5FQpfoB'
    'ZSs+4TiFseMHhFX4A890g+OfOK5U4mqua60JQ4H/wGX6BmCdAejk+QHnaqYdfAO2MjWmfcMzdGCNDjC5I86wfIOyprUfGFMOCCww'
    '7VERGg28Nfc3DvjtfArUUww/1C2DfgfuA6WLtLvfOcsBVH4MHA/4UXFkBJfQ3JdfGMw65ZLfSOFfvkLrHPdf/yv3ZaoFg3HTgNdf'
    'fvniAlczPJ/SNDBcLPuN0zVv8vWXr0VS1PC5f+R+wUe/cN+4XywkzF++/sr9M7Q4wAIfgZhVx9q/lcLJ/M0P1sjHOe6b5zgB9zcC'
    'a6HQH33jfh7KQ8kY/gpfXc02LHxC/uAT4NvwXRgCH1Lx+3QeGDo8UfoVUeV/Zc0gBcJDQzIEXcNi2mBg4Nr8TLkXPho7C8PDtoUh'
    'bwzwiecsRXzQH2pDNWzKD2Cmw6cVLKY72JBe1ZUBqebYFGxDNRiQ8IRB0K8OBrQWPGOw67KhR83DosBipoZIH22MNHA0P9h8wsqx'
    '6qzVMUXEUV/7IpbLR+H/YvUrmTPDnhf8saY7y2+wIQm8u+Ik/EEq8Ef4tyiUv4atOQSQsspLOhnJhI23MlToxMETNt7qUK/2RVox'
    'jWAEC/DFP4eL/hfElAJBE9xlvcnBX9N4IAgC8P8kHgiaMBD5GA8M2Sgb1SQeVMWqqkkZPBANSZDUFB7QrS+JB2JZVEUjgQeCIqhC'
    'P4sHgiyUBTXGA7EPrZeTeCDooibLaTyQ5DJfGabwADCDj1cswgNYXEUcbOBBPNIQDzJPQnyhc5aDB8qRqB5JIiCBuD8WlDNYIGu6'
    'ofJJLBBg2gQ9jQXiUOnL5TwswGUOkeDPwEX6zqrgm2/AC7/BZw+ZGDyinOYvY1PXDfuvyGxM37W09TcO92vuH8wpipSaHdCCRXMA'
    'Zcg+/Y0TFBfqU2Ei/Da0jBWt+yvZ+cPPdL/+xg3mngdocYqg/pra979x4q+ZHR/mE/f0X7O7ffQc0CkwgUsXNMB5eFyQXDai/jwI'
    'HDs5HtPG6gUE8FeOlC+YwNF9gAkAMgCa17kfmMN1gYnP8YsRglLONA1TUYSpXiTmQ07NB/k21bwRAswT2PCXGLaDkv4RLIWOu1JU'
    'LtEAz/+J9UjKkDXua4PJiIz+G7fQvC9Iv4BjZOnDJ4Ce8AhpbWghxtHFpTgydGwGW0koylwBhHXLKNC98og7QWG9qQ0eyfdzKHvE'
    'HTwaI8fgOpcHR1zL6TuBA88ahrUwcOq5W2NuwJuaBzrFEegDtl/wDc9k1BbNPp12/AlbJ8qpJioTAPZ8aodYipoOKCB/yxkk4Uow'
    'qAhxYQmmMA6YUt+xTJ0VwxVmm2cRWEty+RMALD1cT/y5BRHIesMUcWQJXU3XCdUABhDaTXRwGPbDAAMJfitUm6NC7sfAZWMfC9AW'
    'rhGSKpCLUE4jkUpwiKAQKbVkuFLhAXGWYxgHCFXawECyowPExn8GwQF1xK3kMDXtkAj5DDIRbv/11xRQYhoomQCl0IeriJp5MlW5'
    'QAEX8LGLwFgF0aKiVjP3GaFFky6Gy5AcyDZ+lRlu0Z5CiQ1CIN0W4seGZZmub/rZeUi3paPslOJvDMaCZQyDbwxIwPnSn4n8Obd9'
    'bWHoBdDZ7RGIeVgfdra1D1qqb/ZBQh87SwOAAEHTHpEqpKM/lxLdfiNbJvSbQ+Cb+EQKM4QybXceFIHX0nWndG/aY6DNIGc104uW'
    'u7apJSFP6MJtIjzd+r/mr+x24s5jYvOAbnTx6haxsptZigyZb6dqKTGSgkeJR4mHHD4S4uElHm3lNQSkbxbKBoOxaekxQ2CVGTYV'
    'CR14EfACewwCT3aNt9Jdiu4VpHuCzpFe/o2bu67hDUAz+JWzQPsBKLBbsnRFXjam2cGK6Z0NuLhhoSXhb4kdI8KcvRAxza63zR3d'
    '0NIoUklhGmJfFZ+EDMOF3Z8sZi5bSc4VLjTbV+iwKCl9s53gyzdAFw0oUP+au9kkyYjVDSuEcxM9QP6CkxsA7hXlGFDdGGpzK0g2'
    'UiTyyGZ3RJiNiSU1wUyszRIHlWxTIBZdz4RlXed2EREka+Vnov/kdRiV3ESzzb4i7pTsMdS6kuXR8odCTsxeJX5joSvRzorychG5'
    'KtRhOKrNAwfReZggJlLM1jy6A4ccTIl26J/JyJpQKn5N20n0YvpBonIGLMIZCN8QM8BhteNYytwQHYmgAezeC2Iq4NOkktpECOYz'
    '6SKFxsVygj3HImEOGLmrsYnRiZrFST8SPdkuRudnP060AcfYixgfHe37QlG40yACRI3+jPpYet1ENSV4FQPHsXzaO5HnoKTr+CYV'
    'Kz3D0gJzYSTR4MwJdmsu2b0KZzoci5gBPuZvq4Reh39xmO9IfeF8Etj8JbMCJSSZkWeCboM/C7CDuWhfLVBJ2cexuYYWfFGOANPd'
    '1VeGniqOYAMJGf4lN+4UNtItacnMTOFMi8m5od+iFvg/bJ4SsDBGuVFHjOrEzC+sMtVMrEQmjc4VDB+6R6UyRfoZ8AWy06fYYhLP'
    'BUp++czQ0vqGhTrgYLKpaWwXQcobNL7/Dhd36081y9pbaKC4hnYVtqvnEUskk6TF4E35OYR15GnMaBNjeXo7IV1+3ShDfDzQNSwC'
    'KO8j5s/4QuuAoPwV8eOI+hpcDQ0G+GCzHTpExFGKqGzDpyMtwvLbgLU4SQmA+/AoOSFF3XNcl5aLxE3U1XXNHxsbIi0rUqC+m29c'
    'QYm3G81eaH6CyxBunVbnIyzpW85gArKbMx+MoXW6FnRLmPsoslE5I6nWsPaLtqMbiUFFGBOxTsfbWGWtD3QJ2PErrDedNdrwFuWI'
    '2VMY3iYEtU0a3ybs070sLcBvMWFQmLNCTmyU2+AgCi64vM2MSrB/qE1Na50QXFP05HpGgVJUOAHMKqDZ6yVUgJl5g551JAgxQiu0'
    '8fk7ppZuoQJjs8xEQb6FOkSFyhd0xQqg/UGD4VJEmiNA5EPLoXRh+hz8xBekFaogcu9aNgivURLcbTeLSI2xCFUszfUB/QkTzVez'
    '6XREMlB2VJTfRlsHkpSaZX3iVvhyhBiToFmiawbb1qK71Y8swqaVXCkpkU76eqRDA/snuwY3NwtTx3YIRh1x0cdcFYkATYzH0A5Z'
    '6KG5IuqEw00N39fQQuCPQZBlSz12poaL7BoEnXDFY5QjlZF54BITwwNFPbIZJzTB2D9bgFdHXEElIkOksfAJNC/zKfPNQLMGX4Bn'
    'LZZcgZNEUm8ra9hYADLULEFHxvOvWbFXzhHA1LxtknRHRsVmgg2FK4r+UTxy/LqFzBiewwq0N0jtiFEtIzRnSJZiCRMEC/MFuCp7'
    'wpx/UBx4qU7djaBXGv7XI2AgOmcCbqJkymw50MlTVkRlKxjyhRyWES0MujyYXYkI+En0OOJg0tmzAOgNrbBxryeB/RHBZNPKw3+G'
    'WimH2FQDwoUNLWsUQKq1HIVf/6LBEArGCihbN/TfDwJvbqCziuKebgwcT6MzSAaOlMzwMvoebc2RMyCci+ICPbdEEcjwM4b0laTo'
    'W9mmFSSaLJp+wTaWWTnsHS06UzkPLCYe7FDlkw2NNb8wd3Ug9CwkzuRdKBKVPwQJaVqzQZajCwJ17+fofReKis8Zmm8ABhdAAIA9'
    'eIhRR2zf+F8mxnoI5AMcL6ryN5zZlC0FsT7ByWhYSbGCA6etTNHJzkU+ds/Q5wNDB5YcirX4HQ08u8eZGADb2qLJYRoo4bKh8kAp'
    'NGSOf+IOOcpSQ7OGyodm8BCNQJj+UkajxFHMU8fAU7Hk15SfhvZBSDGhYCOo6B34CCUnvBRR9eO0805UU2qeukHaKUSLm+nn4MaG'
    'wyJdhW3T74shxZzKkXiRY6bIqZyyKMXTgMv5GGjB3M/4V6StLC1TjUAU0dh+fq08tkqcv4K4y3zOvLtf87fEPELc6gTcMYh+LqvY'
    'VSFcCYp3oKAM03auaOEsZ/TBOUqYtpMLk2pRQ1+v9dHZ32xnLKf9rTnmNrKNRIob4UWpJsgH0BM+vr2+SwRChgjS3RnTCH8xqgd5'
    'ljfVrEwT+SaLfAvyu/boEPnSvlCe2wTTTc9r7lAzMyuzmQXZ5uBRWxgc85b94wFHxrt25iDa4gstlLqYeEOenlmjPKnKtMn+n5Ru'
    'ZfXXrIENPg+M7EolpyOpXErlkDjCjnf7IIs6AY0xW9wDZCm9B0Ry9ddfP4TQapqdoEdYJDxFCeXjD3nYPqYjhYwrVsbZ8sYRLl8T'
    'EzAWt5MaEa+2at9RE/sgVbLZyFdMaudHAcTzyDYVssWrmzXRsbfMeut+BkF7wwiQludFPinP028xKvKRuCArG+JCSkZgeldGRPhA'
    'ZEVSHIhxRolwRv0PgzMpGSKXC5dD3S0U/RLaqoJ+ayLskcUJLTF80vaSWhP6LWUZTq6CrCzGyRkTIy11E9dIn20Mls/IFhShmId3'
    'HnxEinsXzaXtZum4r9g0s80DsKm3bZWFSLN9DV084Szl+U3EfBkl9EBt2htTbZs50mXagLpDI0raBcjKckWx7MdEG65RyE6Ihpth'
    'S6IQiYxYAxTLNAeCv5WNEnMrr0g6PETkN6pZZizWhngpbZQqBqa7j/Qsb9SMrVYprImx+r04jjQ9UxCj8J487Xj32kcrbWuLGDc3'
    'lIe0aUhJDusWhrXF9V6O3RK2g1YqQDLkyFGnznCYVjBTwY15tqJUgaFpBQZ1IazZGYevmfnuF+dmOKAUVW6fko9x0nKeCLY96gvg'
    'OsNhfFJG/VlQNEnWtrGZrYHFiX7DlsJY1hQGfBSscEz1FRD6lk09Kkh6GVlk9458EFtcF6l1zvp3CJ4njATQ7gU2C7LrnkaOsEZk'
    '42A9sMlJOLki4wNx8dXf8+QkPBQ7jb7w82s2witHT95m3U2YvdEono4h23Cz7HDhbPX7fMq/VK1WNx1M74kZoZdjaBKz6fa5pTEL'
    '+5jWe1/YBEfLofyalPvLYkru/xOIdei6+vr1PcHrj5Cy8oKCExNyiUGDWQfmpiX3nfDbeIMRUmLTlvjD8oZe/F5YWU5UIBvADQ3n'
    'SYpyZR5FuayVLVPnmzF1YVf4pg0DFm7JQih+uXVgq+rDfuNz5MDOL5s+3IxtR95Lz4/tEsMPmfbUzS1Szo0fyFeKhvp7YWghTCzg'
    'NUKFVMQMv802ngzKjFoiYbh7Rxdsjc7dutORTojiuHdARG5bH4kUjnUPOYrJQjCCUUam2WKNSUlhea6G6kZgCsFZEG7MAYkX2lA+'
    'E4wqolCyIe7HtlCE+rAhIhdRQ+4Hc8QIabtrkfDCbS5xMqt0xBGvznMyfyrKf/dxj0gzjhZKpQ5s8j/XY8mo4kdo0lHcJ9sa99ed'
    'mQUzqRsT1YMx+nA2076AFHHTbzt8AayJ49Cwzygb/iaCL2lo3g4jCjqDi8TlnZDKhZ2SDB9K3CzaK2oxs/7IYcLR8DHdGP6O4KeQ'
    'mOnoEzxKjF06oZcQMPfX/Y+2vL/HMxVxa5R0PIAWCd5JEX82/KRAUJPIL3zMCGKbk5rcLQDKAg0ISkYCxOts+B/2Pam73R37nN2h'
    'Y41MKuEqb554+SGbBx0mDSj9235hNWlbuPrBIe48CJQCZ9OAI4dRNBux1BuVwyj+dOVIQ/r2bQwzSc6KfsFqhaX1dasfO7fC1PR9'
    'aPfrtk13u8uexdZtaTfQRtsh2RZpmBJf6DTgYTZ/v7NZ6bVU80Ox8cFHNkg5a9uVxD/lS6IpgIu2VQgY7u/rLtokjY8fCskD5Mf4'
    'tzZajvA6oVukYow3zJIfjpelbrGkTovsMW+UI+eD4RvZ6lHg/a4Ylc2KgDbZs6NJ6TlHHd9zdou6sTUyOGE92jBnlzNsJG5t1zG0'
    'jQomUyJ3qHzSHipfyi6yKSflvN4SyRcdV9s83bcJdxiOlPNm6AzmCXaSAn8rZ49CW/NOsqWm2epbmUNtKZHjT/thIww6XoBw49wB'
    'cbzdntCDyFGlLJ+Kt3Q59BxlB7WBTFkPTvkdj18MyV+YVI7zh9be3w+GmuXTULDt4RpR9VCfZ0lDEgq9FgTeF2K1JP7fsWPpxkbo'
    'cUQtW7WSxJxl/QORHzFRhjhCk26G1DFL4pDjE1bOREUpo05WUhXp8Uw5p+LcOkp+daw8KDMuirx2zOkoxyeTQM10lHvoSqMdqTSG'
    'MI88M92QRU4RF4k/Jjsq+ZQ5A5XqIXnIIdHkODUDgZ7Yb94TA5RQzMpmGAAhIsVIZD6351wLC5Py8vekRHUyx7O5EySdVWwq03bb'
    'pNBJ11DaZj3dg2gwKn5Hj7FUlLeeW4e7Je6eJSKQSCKC8vZg6gyI2k4RNUk4nz+LRqkqxV2HJHNOGj82Y5Z2xMe+3zuNa3emxp4R'
    'LRK/tzS6JWkEGR/2yNy6n8+VkNH5RBZf8OuPyeQQgbiRHaGSPqxOlE3i0c3V9j6mwm50nTaZ5JyS220yCVXpMA5zO0Fip4+G5pFT'
    'eXlmU1Hk97Gpb1dQUzbG9/wM+2ccyTHLx2PZKT8lnDzZU3/I0Whmm6m5+mLanO+N+kcZD55Y/lPquFgKdYZkj/eT9LsTRRnj2g9D'
    '97IXbDeV5rsEUmAX6YeP5bLJiTxl2n/C4/cxDxNzuG0n6e2gb9ox+HTkwQdDUdKd2E6wXVfG9ehrvumnTk9HdL3XCeK4eC5touFz'
    'w2woJEyhpPoWA9N7QdxpSxqJ2uI3m6Wf/SjCOWQaSaU6rhOVy298P99V0sgqZDgmBljur0uQfqnwmT0DTeZBiaknc7SZWFd3H5TG'
    'DguYieoIIQa59YtYJg5ZYeh9DfFpoHn6lvXfc4vdfkg2MlBsyH1/gP83ud7vJu7YOEwVM1+uKJTTB6qEMJKKTFakJpMvhLMXwrQ2'
    'f3vXX5Fn4n/+UmDBjjmKMvZSZKnDPr6DxGfN05syWfViMJ5PMRZe811Y1AIx3SDScSWgil/fO9n8I041b55opiq2/DGreWo8mDR3'
    'U23bcTA50QJLSbZpw2dI9uHw+xzDC4M1GTWZMl9uCDM/xNRPeyU5k/d1FP/Afn3bdF0jiIP+6PnNbMYRdszjIzrWBtSbYfbpoGGY'
    '7P7EDGgGwPALjUqytCmu26/JMgXHMwnbDdXhrYGcDIM0fbTNSxXHWlONVd0w1uWNnwkfux3rlfxgu/zsNwlwPWNhaNYueJVEIPGW'
    'c8IbG2TylG3ukdU8lhoCk2atSzMYg+QbA5p0mMYckp5E/JizO7mNs9gwNvXshEnoqnmXXLZkysjE5UWAptQpKZU6kX5LJ4cUikpS'
    'wiD2vWzCDwF4diEp9ch8JOZ/yJwO9DnJpjUaDg1eURLRkSw5bF78c0LMFdIO8fckTd9Avh27j8KHBRISGE9Yhd/7ZH/ccL47MV4b'
    'y06sSDpFDrV1fDShZ3F7Ss+wwyI2ilsAaTuvtZQ+SVN2oLEb4D/KfN+aImPgOT7IBKaXWIpdKTKi0AFC/MnTnjTnTmSEEWK/ulTO'
    'xgmk4lwEJUpg8j1HN8T3D2x8UG7k94gbDINH8OE7555oPWPwwWN6appMsIHDVGP7O3FZmUwkyn6ihpSuZKdtsPyHM2MVcs8fvaOx'
    'b9gQ0s2FnOBjCYc+A3hO5M5vJZZO/LcSu5gCpUXMMg4CJ83ff8AfhDcM4EdS/veDiM5CMjvgyFF/ik3soD9mKf/NX0/7joW3MhyY'
    'eK7QOYjudTggaaBk+Hdw/Fuc5/5AEA8wyT357f1+IB2Ucl9LxTJ5D3tJpoTI0xLVLe8xXz/rorq1EWWPMnJOPywD/8EPz7+PjZfo'
    'dG7OLG6jW2Y2BqjMicKioGpo4yDKVEEoCOOCnHzACQs1NQwJgNBETqTKF0dGULYqBSXxUCwqHG9VOKWWeAZN8YtqXKoAnxrl5PeC'
    '+LZzUMAOnfcGVYVZ42SuapUL5RTc8GwM01fWcPrwPwUL0700BGFnv57xbr9TmEzoGDotZDsWea7aqGY65lnH0s6OMQO1h9eq7O5b'
    '4aqcgn8Lu5HCteb+e/MHwxDHgozYWl4I8s72Vu9imErgEtQm/LLILSI7G/Tn9ofZgZwlMnFB7roQefgtF6sShz8sUJME1JWA/CpF'
    'BWDCn4mnCNtYxMUiv5WiJLMyhUTVapGv0PbipztHNHXeXT4EVtJwnihaVNlfxE6hUC1UX3b2QJwP+5B6I6ZQHmlvISQewG9YdjH5'
    'oCB2Ky/pyYVmF3KmEqAKzKbUUMnvCv5GhFd3Ak2MKVuAZvfcAJ/n1uQn23gENd558LOHnD3DgKtJBiwmgZ8i/ykXpKKA/5MzAeyV'
    'v1GAP+3mAZpp953lexMtAh5VNAG9VWH78AMJAR5Ha1yAJedxOuFhDInM8TtBoCbxdyGAZ3xmHdXkeAviuFApJhkx7FTVQrF6A5sK'
    '7DTVWly5gvQjNeQs5khpJHjZA+6C4xp7cDKclGIZVqWa2Dtg64PHfENM7jxCsQrVYe/BDUjmlNSAqmVsJgE42V665eQmBRMhJecB'
    'tdAq7MpFFT8maQFewEw0BDVZHRnNznFPjHXfAYX4HTwXCZ7LEZ6LCQlLUBJ4Hi2xwqnjIi8gobEPcvhBZR9UZGPkiRh9UsJPFdBX'
    'YC/cCTwqXe9yFTw0psGmFmFLWYZ/llRIPAVc4yvkBy5UBcApVoQsWxGEVIWyXMB2CoB7qeaB+ZKGsIlC2M4OcWGPQUwFtajKmGFG'
    'RJSpiKTdd8BvghhXwfDMCsG+isClK+WBCksiLiTYZ9SxRNaiCt+EKi6F9M5K+MF7KyFxCllZKVxi+BAiAiy1RPGB/lbHwvsdFohC'
    'Zuh7oAC0T1ARO6AfVPwg44uF3ETCxQ0VHjfkAUqUIvKQguSjtImkXti9jLq5MPfge2ToIGkABVhyAWVAujPBBg4fC/B3t6hlGZpX'
    'QLeF9u5sy1ylK48FBRYQ9lV+rIAAD/3BAvO40wplCzCBiBKAHvBxZ8fw6d1ZJpRb1XBQodSqNiqRmC7gTAJvi77jk3ElXX73fhyA'
    'gjl4d7GrnDwuVIkcwDfKOFaQquHze1I7DZN9f5TyQkkIQrhJdhGBYIoF5T1BeTDZY2dESVkASmYy+naccwL/fUm0nBJEQZHboplu'
    'L1DNK7BdqTMs98PyMeXzsX5U5EG41ICzMtQoF1UgnQEKCvAQ/5M9o4LcYyc0gaf5430YExAlYI4C2kRG+atkdmcFuVVXzuzRcnbT'
    'JTxGWCh041go7+1jxvv0LFQHMnCmcgG21kLFB6rG3/navRCq9+UtZoZy8v12XSfwzMn7OjoQRSNeLiKuSsjZcMvKMAQFByJmSeU3'
    'vJWP3TRqeAQO4KjcwNJ8//cDD0TaY2JyTD4lN16w5/AmTFULAPUbxLDAyrE7P9H49vvBqeWQy/lMP0rmhOkyRw4XOByms147cy98'
    '5cMg0agUNZRrMPptDi3S20N/ZjYNMjQY0G8lClUEJDmuhiCyy1ViuJhneWha2GQJC7Ihl2DMW0bPRQb9/Hk4h9YwhWAIt+a7jjt3'
    'GeRcJtElDW8OIbo1lkccisNkgvAimYNjbI9LTwmH6v8e8xJaCbZODY4NgR5GMLM+iKWcpPdHb90Bc/aF9TIjBqijETxigAancejq'
    'YSt6cHwbf8mCkGnqjqgCrK07MhF4ewq5oRaBJOlYdU8bcZhpwrEBgeJcrV8PjrHK3//lf9A1Z2OZ9A+OTwPPOrxjS/wODJiQLB4P'
    'JiFLou7BMT7K7+Bx/w5qfqYLh00aRUbyTPO3DuVxbA6Drf0l0fc7MLnOrmP4DCafOu76iHM1PzAILutzF+QImk+QHKs/OMbm/2jE'
    'NqIhfAaxcRAnnmYPxqlx0XtGyTE7Q2fjIYPEa53W6LIdsfy8ZgDrBTXyF/F0P3Q5nQf7dY/5h/sEXJqP2DOmDqARAWIe5MPQ2w+G'
    'e1zICAryjVuOtYBk6hs4rgmQaD6gMO0/zJicgfLgmNTMh6T7AUiuTd3PQOPY7NrYMG2DbfjYc5womYEJjOMIyW1khpSNrCS61dqf'
    '933qqvIZuGFLrOFdBLnnGM5CYojGUEPo1lumbWNxbUw7BEPAlY3ayofr7I9lETVd/yyHgKrRWn3BUU+MNWCQZ3CzuTmYoCsTrx/H'
    'sdfRqwXc/dL2De8P5xlaOKZPsQy8Byw1xogm2F61QRMfFneItT4cBkcZ1Mbqw9ztuRuZfRCFR1mYKeaFmJYCHOjlu6FmvW6ATZZ6'
    'P8CbmhnLCjXbARg9jqQIAHFBO+IweoaQjbO02RoY/ncD3gw7eAe6c89IkjebT3xLIfpuQLAD1uzGLJ45c3hcGABnmPyxDOCMSkWf'
    'ZQKP9Jpunxs6lEkvx45lxLIWa/6PJnk9OYoU2edTfGKWwliFg/h1TgEy3IPjGw32yyAx36w49e2zCsxkwWaoZRQ0z8PsuMk7CEhA'
    'NeYmG4D+tOZo/iLci4F5HXEo9eBpqgXsdOFBOg4FZ6BglMdi1kPPjAZr12D99p3VAZkSvwY9HBxz+AvA19e/lQiUKbjd1CDR4XRw'
    'fG0Yrh9xdjxCCQCS6EiAbIABqUsTwDHphRfEmkggn2r0SoVp8beSu3MyY9V0i9RGR4yUGksJ547FBLSYR3A6sgaykTIuweaFFI6K'
    '+ZukvrXTmmXldRnu3JhFGMVDjMtjTDWUNUjpkE3t0WOdkFSyv449zPYIDJUUQzU7r80MKma/fhbPHzH440NofsLwJUChcozaTzgV'
    'RCRAWyhIbRhSrxORgIWLwyrhQd8xTqu13o3Q9akL88E1wqwT0dznYfYOUOsabOYUul98EmAzB+UUsNenWpzvDAOq+VjwYKl5uk8Q'
    'zLB1fzeE59AIQIi/WLswenJNbIwXm6DuQR60UjjHv7EUIaRPvKIkGlrDWaKzKRaiR0bAscPUGElJApN8qndTdZVY0Y5/c1ycSW6h'
    'WXNohl7OCHo/+f1bib7NlsJ0vnPg8U3ye1spBOfg+Al+bivhDIfQlUNgwwu94nIlOtDjnFmLJuUGBpCZEvIooXLZNrwC9klCmjYG'
    'O5h7C0NHFQt/bwPSDzwNkQ5pg37aC8xNGvogM2yF3mk2mguq9RiUu0U0xpzYIdYdIXsmrPkTYkroEI8klVa68T340JatpWWEVJEz'
    'AuAFf//X/84BBkwi6JMbztBzpvTCHMctch1bdzggRNoUss2waYywTG9BKeDel5voZb9oUNwuVuULUx0SxpRnQiXgfiEa3cvXT6wJ'
    'CZDaKgalEMbYBgO+YTBQbfdTkJCQqXxIvstWtcJUrikBjt1W+xmxlLZGLBrQPoakoPikUR7Ith6ytTp/vDpqbI5sSr78MKn0kgzw'
    'y/3txddP8RvKtR4xQ1mKj2K65OyUegYJAwW+t8FIhYNj4f/7v7YxUPEgUkCPxe3FpINjaftb+eBYTr7dZ4M4ZXwhOTTXHrUx+fHG'
    'GGAHgg2N3KwKH7eBYdGd4Ca9DaTLkKzKx2fw85MbRY4Es0v4wCHFJ9RACkl8S0Sd7y2ApHTSEX3ENNGsiTVt3QQ0RDkKdFeXBslQ'
    'C2pIHjlUv0nxYXvIq+rMmg7tojk9auePkXzvKHPgvujOYD7F80f7bW11IrQTpUTDzEM6SYIDcpgFKhs9TOpzf/+X/zMSWkEsG2DW'
    'CPTeoQZd5C7tgTVHKTS+xTHcHT+jUiXQnXG882k81WRFw3l+gs2WCwfsUwcWbMH4+Ii7cJwRqPRnzsAnkvuN2feMu+HQHBiZLqHT'
    'DA04gxXIfth6KdXOlyK++rpVstSRCL0JUe++FKf61pLBClD93kJJgvD2L0V4srW00/dNUMCBdd2xT/BmbmG1N9ONq6UnMqTa7xXr'
    'thLULq3UXTOMTBMZW9EPElrU1C56o7JBSHWsoyTlfZRrhb7b1b05aJFhb+dirNgBRx7DVhFSBWzerjkI5qDIpG9z3NOsEbV+S8iV'
    'TCLR8YjpaqoFSK0hLRI8p6SLtAyTnERekCQQpTdocluvBMVIt+GWX+NYggUYConyPSI+DJekXEDFjRk/YxUa4KGZwoC5/OUv5ONf'
    '/4qJ6gBvQTmlKjWSLc4MaxxoIkTz+H5LmDJ3TEITyL2lfsp3DzwoIM1QKZoDsY1kZw4ch0GUphvAiuzFp98lee+KTiARMnlibZvd'
    'n4mn8zXP5jA1LawYCmuP1PF8Ft77Ccvtcv01+f2ZMAWEYS8hnAoXueA+wjyi/cEIlgasF7VkEA8rHl6cOvpnbPMkGP0doTz+kI4S'
    '4Ugqio/FirRNPeYa+IWziGX0GxfaOjOWul/8GJltQwusNUVJF9EsUgaJsQ7gGRnoCzg4bhOz5Y55Pjdj1yp8jqyrsP7+wMP5pfoO'
    '/xXjMIL91ZX8Yd/SiPww2MNh3IN6ISnlAhY6MH6PbEdHIc/CnAyYKQ1+R9RLxv9zoAG7oUCGXrIPrz49KBCp6wSu7xzq8IQEL+Yh'
    'ML5hEJ98BloSFrkPFQ0vWexiHhT0HYPj8jNwsMjIvSB5nGqwGXhbKJq+ZAIIAagAANX+/t/++85GT8zRaFub9F2yyd+xycNcLTO5'
    '7aQ07KynEO1fn/b0jDWXerLJyd9tAQKkjz9IpU4o1X48lKy7h2PWyw39eg+tYKsylBJrqPBGJyQpZg/Jo4xJHLZZfJgVRWExQw/Q'
    'NmnVhXkG4dZEy39+CRSbjk+c1bb3NMcFaif0w1Yp2kAxmlyGhGEY2xXWDXnvIxN2jniTmi98kp2uIRn1x2eLHCyGVcFfW8dp2u+p'
    '7SQZCOgs+OtHzMNeWvSwZfhGIkgIBZnkpvJLJKSi7+kLdabg+d8jil1HZNa+ooEV2kmU3aYt73Ycpb98hMOQBACfDzkjnpgNzsIi'
    'kjwiAYdTit2Rs9FnThDN6R/PdwbxAD/KdwjbWqJpKeWc2DHmg+M/ZpVAwfp00E+khTH/7/dHw9ATg5H08ocvoRuO/t9k40jMu1nT'
    '9Xz7C4bsAH57BsltnKH8cMK/kFA9QH1YEIdFZpJgWsdF7fHr90/9Pe1ph5Xtgztk1qJs4pM47o8NDBnZBsd/hOpTbfvW13zP73iD'
    '0RreaOue14MCvUKmyE57cpqKzBaJzkx4V0iwJlstZMX4/bsZ8Pf4VG7IITkGH37JDU5EV7C95mj4FXsWRWljBWS73BjYQRz/NHA8'
    '+3O6CuHhEcYhUDsVPHTlflpiRRnxiCNETU0oQFiDiW34/gbDZW7wT4zGSI3mD4/0t6IJ+UN8SVEfbSQMIizZxl7WTpjL0QFHM7QD'
    'S2IiekYCijIiRSEm2w2gpKlFKNhFi0rFvOQsW9nDxxKeqsuf9OTxpYYk7dgv8kChObUiWM7o1x8GTJhzCbtBO8r69wOFkz8Ko4Om'
    'zBhG+vWPhJEv8gInh4eikoB+DnFY8Mk2xKkRet4HczC9UcJawzjBvxfyGHYirhghoV4hlOi1pbaO4xswCRDu90PiskaG+S2KQ2Ih'
    'Z44dsu+vP2g4YpwLhjVFFDH6XuYUq1ApyAv17YODJvletw0bbcw/AHw1Wo188EWA/lPA92FPTMMO20iAd3ONw2CwHwH7R6b+4yP8'
    'HA2SjAXbabAdbqT7kCEeqImNxfjlR3IjkqUqlb9O+OAy00uHEoyCfP134hJEREnO1g8hkV3T9XnOvSNuDUWIzMkrErlG3QLEdUkU'
    'SNOPTleEB3gsx4Eh11wXzwM5LKCcFno/qhZbThtTToiHgZ6AoCtNeuC+UNZKtamRYzCXFwsmJngeRYeGlpX9+r8hNBL51j2ThGz7'
    'YwyfoVqSw4aOABxxRnFU5P4LXhzy69LxJiCNAuen36kgnjgMEAnkX1G9gba2OGY3oTojseOxXEBDySMwuC/0yWdkenpePBKDWdNW'
    'jmy/d6hgBDZ11/5BTsVwTvIs8NEEvXeci3hvvQ114gfO6E4NKQxcT0etJymLOLDRvxz6lgHaOQ01N0PvQukr+sRpS+/6D5Pue3Lc'
    'NTqDDEMbDAw3+P2AHfo9Kr76jn2kufSQGyjZJXyQVFi2NEcczGemd8DRfMY0A6WDTkV4YbqwDmEb2xsxp6M0WMTiUfpz3D/Nh4jH'
    '53/7h0IBfWfkml4Sxk5uOSXXXC3C0xkeTF/o6oaJJaEJ+jcWSw2lfBjhEdM1MVJhiE4cB++BCTTLKnKFAnQU6nLkLtXIyBc9ZlcF'
    'H0S+WmI5NDxo/kSL/UW02AHnObjqmmV48UmX2EZK67WJgT/H8kxfp4K4zpylbTmanjnw72dOcodnnMnBx819IwJ87sLWZuQBvgEr'
    'LboVVvr6wtkIXznukDeYuzs3+oVWvIH/HnJNckBtK7y4upd0ubZBTOniw7YCTIkZkvRP6cwGiU5Tw/8pS+6JgieBvTkT7F2GhPMb'
    'YBMCKJ+auV1VbreEFp859i8Ybgvb6UgzP3M2bpXL7ULSyFAInsIxzqxRio0kWL6OryhdYE5/Z8QAmDq6ZqVsR2Q/tgy9v2attmkY'
    'IJ2EsRh3x14AvxDZW/f4cki4gk5Gj9kejmg4zWCMMRA+5wOHoFsIwEVLkNMwluMHcaDMRtaO1NZNhmr6AxLgdRb1FGPwXh4m0swp'
    'bAcovdPfuaRCytEEClnUetTyzJlbVgiYCj2YkuuTSPaIXA0x+eP2vW7Ibil9UxMfHmr/BWNMshYE6AeT/8SzExEfvKEi23HOUcvk'
    'iN6xuyXXEXvDjSWWO76fXdAeYLmO03FNAG56NOdzKzmYpLSUnvhTGp/HBkG+kXgWNqG7Y0hYG4/kUpqtpyWSsbVP0dpsaesGKTUx'
    'g0i5W1ENt2tskTPwPBfbexnp6XjGfmn4mBvG8wOSrt3QfKPorvGEJTkWgFaWdbxXEzeQ1kcbPg2MI0cZ6YbtDzzTpS4M2j5hKVTY'
    '2BBtjn/6y08kSfkBg+ngG3cg8qJSFIQiLxUFuawcHOF7fz4lpAXvMdIJTSLAiLmhZvt0UJEPiAZGOSDhaCSKm8PzoaC3hDl3CFeZ'
    'zqEKOU43cKauNgjCsEESc4UijDe3WT6FpLXfL1JwaBgRAFPP6dt3PbwFDUEwManLEB1RFBYiKzHRGAUdUm6ISo7G9U3AeppIKSpt'
    'JA95wyAohDiCoeZRPQlgC9eF3hhAzuTgaTYfA/v0Ijs1D/VoigwbBZQByVOkkaVbw8oHdHV9kNY8lA8SMWYk7oyWD8PN8B4QAJNM'
    '/IScgQ1PlbrotC1y9KRZ3yBcxkSLPVbS1qw04gtHks2R0ScnmMKh2Sy3iB9gJARzoGIDIGfZc31EcnAAfGRWNKolRwvns5WLjvZj'
    'uBuorbghvDqmXQzZgc8tsXmi5GIjQUAOZKMoikcBSIAoEgWw0SnZnNa/YIinqZtINkDxyTQosOuv/cjXi+p5fCCLnNAqHvzE/fPR'
    'boQXpOomwrOY0fByA0R8sh7piFRQ031yRQBG9OH2SUD/GpMtkB+LWIVGUnmoYL4sdPXgQiAewxRCA7B2oGNnMb6diGDF1QhXngUR'
    'JrAa5V1cEfKDyPgYdRvFz144CCwZGBtNIlSZReEOcelgp4sgCsUFAB+XAkaMYI4pVoYDJ+hFRl8EtmeQwcYhvzANR9gssbf62aDc'
    'o8RcRDOL9ccaCxvOAYecISSIzuH949g6nWiqGzlc6I8G0QS0Msd+FxXEolAWKhuoUIuYN+HBDNmoi5Hx4nhXx9cphk8inxG5/XDb'
    'ipGD8JIBHhIk6T9gYRl3yVv/sEGGkL4ZRIhPb3EqkPslQsC+ZOaYSR+Ehegm2re/JsKpNTo2EkMdxJ0dcRubLuMVXLTRINZRs1m4'
    'iXG1IeWQrA4sDUzOODwXbeBV0lzfmhuwpMBqYkwJOeJyTDKURdVhgjUCMi5yMPdsjBM3oixmwAGYhoV7wLrI4XTNQ50LVSNCvqQg'
    'SSpEbG2xQkz4FK31mF4RurrRYXrMILMPFsllaQOLbkh4PDnMC21PqNjNLCBkh2ER7MwdTJCYeCK48GgvNZRANTPDuEM+wygaEMOw'
    'hnQSCQ2QbQTRJdD6WcyiYOHmpnva0s4H7VvMXh8LdAhfyHllCthRjDcRrHTT9Gn6ja/JsaHYuef4GK55eKjBpuZWPDDOduq0jECW'
    'D2eBLHXguIjUQzxGQNxRfiKHRXpCuMsh5UxYhRKIhi8Q7RArj+ihXnhAEMh3jqLTDITxs26JYonhFRM2OKwRnlJIih2snkYTyuyD'
    'TpK8iU6nmGzKx43XpunA3HkfUHaM/BEvqQFYuX86OAPCtBwXj00RO8g/HVDgB7S2azhop+rPTWKSM6aAOItIGmMUFO4ksCp5W1Om'
    'CzPEFpwTSj55YND1JChKmMO2caTABQGFmgkBXD8J7xcXxAHHlugrEKK/poZA5BUic8F2AOIIjmhJzN44IGRGrucAQ/EBi1qUh4Wd'
    'kCNwBFbi/ozF9H3WTchftzU7WeDHyeqOmIWOpKxDTowPfHPqYtw2ywDBHiO9oyzkURLLLke6/W8cTQQXzWAonBFyzEknx31h533C'
    'gwGJoz2hORGomSZUCw8oQTUm+9lJmqTAJrOXhRUIQ0X6S2c+o3Jlqg0qUuclTyvSlnsccmsG0VmcBpCxxuigI7Jzn006lcaTjMOn'
    'dg+Nir2ZtaCsJbEKRBrRaCILkq4p1FpjKqfenMCIFoxoT5NU6hqQCtI87JdwSXehFl8UBZBTcnaYWogYeGAGb5XFrmMRiyw5Jvs8'
    '4lieM3wfJkDCcW0gU3t7e9/eaQoEY3JrUjRaygtw0XEXBRxi4U9sXgnKsoA7DBks4NnKcH9bOhEMZHNMTTQIAnSFIkmHXKwNS3QX'
    'Jjr9+//6f1OojjYkHIqj+UIOQTv0itEkQkTiohp4SpAvck1gHRpKyGTvQat8JH5HQMEA9lpYSdxY2HO8rJ20lhZqQhiZ9Z6Z88cm'
    'nXcDCFtPn33LLC+0+21Hs1nvQDy6rM+B5NcD7urMMcVQ6PjIA+ErXao0xCjc+UwWJHstOzGHO/DQtMluQFeEEh6zCHM0KnKvWRWr'
    'W2Y1c9AWWK7D0JnmRcids/cq0X2FSgQk9eDmsUTKMo4IrrtEHmCN4UlfOliW0QCTjqTrwyQi8flEu8GJID7iPiUclyTQYw7leOXf'
    'nyNZlDfmKOyXXtpIz4J+i4+IHdHzYUc0oyKuFU2eFJ2NjhSc7DS+0zByYfIsPIVOdyCm0sS6N8MuWpRcVMcYPVkLnWRFCj36k68M'
    'XILDNufYcXpI6rt26IHlSFFJbpBQcUS2vhIWYSNdRzvd5oiZKIlyBjWcRWwlgz0MZchuNaUo9/5iibySa7KglhMmpuAQL8ygMe9/'
    'yxw1jTAnJETsPVLWUH3YxPstDeuhO44uETJROuX+Gpj09Ij6mokfw2daQHhUJs4GhGUK2hJZCVoaM2rN+7DChP30V0w4TgyhCTs/'
    'vY0s3wsT3r4eeVOE4++zgmcm2f+tBE3Stqn7N4SI3vQeWmh99o0E14/J2WhMXEgugyeWaf8owlQcO1kT5CEc9wXQ8esBmVG0qaI7'
    'n+ar4nzXsCxySD10S2yxfW8Nz0ZAcQf9bHgzy64d2ZYcYhFIIz9NqP1HxiRnc6zuTq8ajnlninCiCQDxk13wE67E5K1EEeqQjrD5'
    '78wujiPokqmNz5979ubMx4fwSaq1iKWGJzY0shFRO7lBTtl//fRQE6PM7oN7Zg3NDJAkhN+SIyI3Qfx3pkLdml/+Y9TUdLxsMM/H'
    'ySpMJ3AEG4eGJJ+688Ay+x7MBlvdz2SjJReQ/GCSagOXTxzRwvQGhf66QNIdRMIeNZqg7ZSamlO7b2Ir0J3vTY3AhXP4PinV6Rxn'
    '+IG9MfdRPA5V6xi8eC7S0IgeffC9e0s93eP7oJ8zFIiO8o0dNHtRiznDDyK80/2HhvV9zy0ZWWK/SePip6n9P0yyivxgHDbP9yh9'
    'HqRki5AIo0iivAwXpCRLcZFqlzmuU+X8lDM7eXSN1HASseyPkeK6cXbNMwYkBVeL/LbWoVN621E0cqnJ8S38zDuJljcnF56ppyHH'
    'C9XjULJMNMaUxOT8lDg9j+f+6M01sHjEr01u4IYW6FdQsCzS3ih8ghq3pa3ZszAq4Tc8Og5IrkW3NTheuB45MlJaBmuvSUYB4pIF'
    '7MWmw+YSgYEkLAXF2/q7rU+1lWXYI3KnJN7Zk+qNxHjEAa+kw9S8YoquaFKjHFwHOUQDJdvOaGQlsyOgvkyMA8SNQRIyxcrKJ6gk'
    'umMwln7D1jJ7JJVaJn2d5ozHD1G8dCKKLC7GcrSTgj7L455f8hHd7qwkLu6WYmcYTUQK0QzVW4r9/V//t7//6//+93/9P0DlZuXp'
    'Gcnc0nFOFFbWpnlNthcusYLIF7aUi4qYtr6rqVNWLn7SZU8G8cUouxo4Cyckut5hR+EXVhizfO4qx0fQJ1Zik0Pg4AwvE5wUExN9'
    'fYnfMyRyTtTuKJNNQOiTQ/Z0hCYX3aeyObEss7RVHtH5P64ixYDcmIkg2I0oHxIQEYbFGhGvT0TvsUQ8aWImhVuGnzxvfEYOtDqY'
    'wpKeOM7bLkjFZOjWd2bjiQOzyPMoijA/vJOUIddt7bqJi5pjvjNp0GqPLTg1J6k0UYmd0T7BiJDEbS6eRpOMsQOgP+WmBnQx8BRP'
    'Y2zbFMfiwXGD5mPbWkQ6OH6c98eZUvkd9hFKPFQBID3gr61pVzySHy6Rr/qnzTSAqWM7gykG4juJe0P+wBxJmz2HVzz+22RG2uw/'
    'cQ1knO2YPmFQdD6Z8pg1uy8g9OK99thz5qNxQmHFpwF7+nE42HV+e68Gcdh0bHbNKuFucYobkg2UhD58wctxShz13OFn4ghAb9rn'
    'jtVDNx8D8S4HwNv5tI8Pqd75OTCiC2Z3g0NYRypDAcuCQYVldvKVIdD1d6caeB+JrSQsLJtDmHHmw6i7R99kAi7pdekh6VJnX+Qb'
    'xnyxO7J+kJCwT0Xb5yf+yMqVCR7fxux1sY1EozfA5XNacncRNbRtYbEUAaP7oEhqvHfYNwlsRwzB06qw62+/lgAkd1oSPsynNuel'
    '0j3ltw5iK+mAHfracekBlCQdsJK0jx2Fydii4jkjfW9foXPVcDzzzbGBMbfmiYU4ozcofzZ9RXgB875EQi+kO2dXKaeyVcU5pz4B'
    'R+qK5v0sA0QmOXEwDSUISAEJQjDJ9IZWvqT4SZ/Q881JgXdLCkcavKL5NKRao+YyjNwqcn/5C+rpf/0rc8cEzkZQBsrDHPGDhZfT'
    'HaWddui8BPHt5zDd7BFXIPz2iPvzn3Hj//OfvxYPjrcMmcSTHaQlMwLKTnl26ODJhwzs/+//k4AVvhBOSz11hhnGnoIuZaFvKMAS'
    'dX+QPiqbysO7+3ggAeRyOso5i7dxoO+3EhH7Iy2ABvuj/200h+c6dD33uC/MSOiXqPegwCAp4Nvw/CH6fVkkgkTs/1/pBa3Eixu6'
    '8+Y0TCHKwBC5dWn4f6yDBPMgVwMJDZ7hqSJzgYKkY5FccpkVgTaYfhHrBvDs1Jnb2dMpGxdS5GsNWHu7znBjsPDh2BQcpZKCTYaY'
    '82F5o8H/I/Od/yClIhcrcQ6IZ/A3MxzBCflaMhMVxlL4Mj58JaVIAl+x83JZaoFXZyT/R3TM8KNMiRyOSeQlo86h9KGa7KBsbZE+'
    'v0VGhmf48Wf+oa3M8qawor4KPC33RBe8vCVDx5/Z2Y4JiB1d2XJWhR1DnXtnwBoPjv/2E3fAuPA37iBNVeivTnjLJfzKwk/RgU2c'
    '6cbUHUPH+B1nlHi4ScgVNsfu2SEPiRsHnrErhMgztCCQvMK0MvXRH+AFhpc6dijj1/DyWdYhzz5wByaW4Y/IZ5LOEloXkGdRfxVx'
    'JdK3q7jgOv7Irk34xtkgo9NHExDHCZBoPaWPSPo/fPaz2Bd1WWSPqRk4aity6v/TnOelwVg8fkKpYUqiH9I+bFoCzxTSTy6m1vBZ'
    '0gPiDTUxIgeX6IjETAZxhBU6bKiDngT2Jdw5SN6+Qer60G38kPp3iqxXl3U6t9gHy4zumKKRBBx93j+mByOArbCq/eNMnD658ouF'
    'mcSZCrAGMRIxWTK+35UGpGFMaNRHbM+IOgkhBcAiCNskJTk6VsKKQxI4GB3uiWuzxWczFm7GAUbF0svLwxbEeFg0AI2lVA+PNnA0'
    'IjosHp2B2QlofeUankmCcoeeYVjrb+mhvsSdouGPBuCStaICQ1j43AzikmE+a+YMSyw6CYfagKMEi3sAWPnPhMaENL0IaXoh17WS'
    '03FhAsqYYgpiUa6KlYooiXK5LIgKXzYKghzTUUEol4u8IEiSwFckXqlm6IrPUpDBS4Ik7EVBTgJBTwlyaYnsdaGeEuQtwn0KxWCE'
    '8VSi7Ja83xUoFOcR/Yt4UAKwNqyWRsqwomMbiZt8c1F17Yb4lkb1zQZpHF4xKsFuYUiXY6d74pvbNpc7mirgJA6x2UdzdRTPFMEv'
    'EiVM93/YHgjaZbONwLBimP1BDMmAHCH2Y04S45iYxjExjWOhEZao1yTnZQHUBi2FaxJfKaqKIgi8KlQroiDFWCZJxTLPVyVVqFSr'
    'ksJL72KZWq7ygwyWCblYlmSD4aAR3ARvSGAdu5r711QmEI5xeSe7kHqqHawbHXvRMOmykYc+ZzRQhPUZNojBhwmQmPYRQ0QPvOW1'
    '94R8MGwmuhc0bgv43JdkkDGIyhtHAT94H2h44gjHP6JhmGw4oU8Zg4/JEPzoHBzOKFHT3uFmUhrTpDSmkTwoJLOabgSaaaWYWblY'
    '5SuCIiuSXC2rippAMUERi8C/eBn4nCgCo6u8h2NDXh3wfAbHxFwcc9PXhIZH/qAUUQsJ/7GTO2i4XIe38Tr1NX1E+QrnY47UqNDf'
    '/9t/T62mlk1dQyg8Z9ctJfbMJyJ7JM7Kkkwx5AoQcnjJJjZCTo5RPMQZjKTN3Lwag4OtsEOy9BgAu4ISrwsF/F8D5fQT7CSaY+aF'
    'DYVCtvRyeunl9NI3qIYWn36L0t38MCSQ9kICPgK4nAa4vImr8TkNdkCYBq7+G0MsRBAraYiVNMTXmz7uJKCqXASAykK1LMmVcllJ'
    'ygnwSq1WZJAUFJAnyor4Hn0piqbywwygUi59EQsQYxYBatnhZy96CPvi3//lfzBMg6/RcyIqZJ+XopqlVHt9R19vtK0fpy6ML23e'
    'wx6JcoEeV0pIJ1Anvedni8fwJLutJ/f5HT1ckS2HSCXJff6IOxeRMxB3/we7vmWiCD3Y8y4EeXLNfh1RE+qOplMF9m216SySSb7M'
    'SMPJ64Hmr8TzNR/shXDFKO3Wjh4y3HjPJUAaeK/Rz0w5cWOWOOoPfK+DEyhJfY4f7YXedVKimxm79eS93n4Peyt8sDdyE2sJr5t1'
    '3uvjJeyDXZf6wZ5IfqwSy/rz7vo8pjt7/GBnGDj5Xhd3H+Uq9OREeGysFF0R+C6upcdS/yi1mEF8g9N7ffF7NF5KsutSco9Ae4uR'
    'kNXZXpaQtcKjh8lEAOS2gFSCgiiriYPHsunRFBQ8yIneHCWpkt5cK+nNVUTDVVObEHGeJPIYOY6e2GCVogSbKqpIqIlXZSmri/NS'
    'pVgFzUcuC0K1KqvqD7Ry7a89sdstwlsv4ln1jPBYItsrixxJOpN7X9jI4eLUMexy6rSFJCmAZi6rjvskl0Un9Bniwwgvms5Tl8LW'
    'Ny+cjxo9is/76mgvQ5MRMXNyieP7iQQ3DI0ycCcUQzwOm2/z4vy5XcLQ2ShBBYnNNfy8qNx3FCc1jX1qGvvILUZJca4CAltZUmRJ'
    'qIDIKVbkLLYJFako78C2yn62nwi+ahq+aho+vBEpJWyK1SJfrZQFni+rvCpJKdCq1aIi8mpFVipKuaxmDQbqR8xS9ConKEWuZoqt'
    'ahkztJCxQ584qyS8lWpRFnhFVmVVKFcq1UoSXrGiFsuqLKmCKFWqSuVT4AoZcPGeqBjarBEwYwVkd0UlIFbFIq/yoiALMl/hpWo1'
    'BbCqFJWKVJYqkqJWKuXPQSxmIA5vroqhzpiVhIxdKbq8KgG3KFaKiiqLFUmWVakiiGmkraqAGZIiVgF0oSJ/Cm4pAzcBJwY6Y6EQ'
    'siYKQCOf+y9E4EnALVT5Iix9GbQokZcrciWpPqlytQjjERWlKoIeKFbepbVcC1gMY0aVFjK6NL1wIQZOFqpFoSKoiAigi5ZTyMCL'
    'KiihFVEWypKkynKW2gRpL+gY/ZAE5+iIIiDEEGd0aSGjTJO7u5LmRDQaCmUVoJar8F8tJ0CuAL2pIirM1bIC+rP6OYiFNMT0FrEY'
    '4owuLShZBoEXelExG9ChTy8GTGz3fFGWAVHLoiSqEpBcYgDAR4pAfiro0jwvV6VPDoCREwk8jL13XBhcmHxEomehRjy8jDQjVLIM'
    'm8YzJZmgUBaKMCBYlSrwblksJ2kTlqoInBz4iSKUFaFafQ/Hd1ngzOkoBA9g93AsBxgJ8o3GH7y6xujXvuYbinxUqr6W5Frt4XHy'
    'ctUa1U5qDzX4Br9rZyV51Hh+7Nye9YSTxzb/ctWud+BdHQo0Lmvkz8OyVjsJ+nZr3Znop5fn45cns9aA9qB+nRapnYyfpdtlbZ8/'
    '0Hc1eCa/of/2zUPtB/yxJi+921f8pOKP09b66dzSELBzAl7LDr9f0+9m+P2efpf0xgmPnzr0+7p7fnWGn15Ie2M7893MfH8dNK5I'
    'fQLE2SroN7qvMXxknpovT+Vuh8zSCH8Mao1mrTM6adTqV89PXWcUlu4rMPVnrwK2NKHzHc6zOYX5CuQO9qThGC7DV6ePWP9+DD8C'
    'v5pqLzXfvZPxYFqPFwNqvkzh/f21DZ9vn+BRvYqP3X4M/8nu8ZzW6Hjqg1p/ebKoXcDv2omFzx8fTua1i2btZgSDPrusNWu1Ve2s'
    'XxKXJzB/nbMTRLZlpw6/z08eOhcny+XlyXLQOFmqN6fLSbP+oD7Wx/X7eqvePh8ve/XVg3beqrcuTuvPF2Neb6zUYX01MK9OL42r'
    'k6XRWFVo2w8daG8A7cmXpzXZOD+pdxpj2fi+/5USDLd1Wjtb1p5GZ7VHmP0xgL6qn5TUh9rFktAW9A3PUn+a9ZOH50Zt1CitarXD'
    'OtLO8gHKPgB8nctaSDmt83Ft1KzXR52Ly/Z5a9A5Px1pgJitptkUr9aTfr1zdXb1OBoNni752/pk3lh1pPsl9g1IhPR4Tmk3+ad+'
    'Cn2dn4wGl1judgzvR3WA8QHmuFmP+j6B+iMC5yP0fdJ5Ol+NXi7GJyvo22u05Mf7E/Xk4anJX7X9RaMkjmApl3Uc/1n9oVaq3bnC'
    'hdsarZTrtze3Xm3NOs/Ni3qbPFw+t+47mnVxdjL+j/3mofNcb166s9vHqX/2dDq2Hq+U147r1YRR89Jmj2tL03CEa215+3x2+j//'
    '+xG8PrtqtZyzhw7MyOM6qIuj25N2RxuP/0N8KmnX1zNl4rruk9utTFqNzvrwfunN+8NHQXvUZlZl1rmby5VXv3/iaMKDKRxOg06l'
    'e3cvTsX16vb0VRqsFtJLubPidf+NHz61Da3l3JY6L9LCcl7dQ+lpIJjqid2bPM7m0+naBsF5uG6ubVd/Ogyml+aqP5Ttx5o6XS+0'
    'e89SXFGRndeZOb0qLU/f7gS/cq3p/XG389aV3u4rl2Wjyr9NOk7VuwyE5eymrb51y3aj/HS5OLx/mbntw5c74f7tTr1fQ39zS9OU'
    'zsztLVqdyluTl8Sp4j57r4cz88a6by+lF/Xqdaycv96IrWXFuleab617u+Gtqu23AJZNP3/rnV612t3Js37/bPe7ffXqgb9zKzfO'
    'fP489WW1p2remF/d310p7uth62ppDF2hVJsfVhYtqc23pXDCp/LLyJnyJ8619tppXiY/1dzZ6UW9Q6n8AbDk355eYUHH2gwwoSV0'
    'n1pnlWfxvh2MbxaXbmemW8Htoq+c1YRe51q/X1bm3e7aMV8qh7P7C+NkIhu3d92h469KwfVtdfXUaI2fg9ug3tYNMRiet69r91bv'
    'Zl2Zvwy9heTq3c785f7l5nwKi29K/XGrAUxytVZwF7UOHf+kObx8rPZdTdKrp8a4PTurl82lVXr1gpu72ZVvT8fC3UoMukp3Zs3d'
    '0kmv2RFaYps/rKtDtcbzh3P5/K4/Fh4WpiuvpFX17VUnIx22z+6vOvnc6WR8fksKdZrevwN/bOv6De8Gk65hzTqljnBzISiD2aN9'
    'OedvFOGmZJXEgRus2t2ec9c6v79t3Y/PO+17p2+/KM+wQQjN6oKfSKPa/XRZfWI7z6x1Peu2jHLnubGadN3+qmJph97jzFq/tbqD'
    'eYfvDMrTy9fFdd/qdPg3WNaRLBGQGgL/trrKA/j8ovZMWdrz7ckDY2n4HUppNf78YnQLBW6xAHw9Gf+bvj8Vz/VeY63dLJyWIa3v'
    'LXj+NAA8W/dvu9PymTszn+25PerddNczoXeuN9Vny+7wM6t73b30nIU2uu2u7p6t66tXqfty3+3JF8L99L4X1BfKrSU8V8W7xqFf'
    'ra+E0nA2qWp85T4oC9OboHHvvs4mtRq/QmGvJkh3UrWp39xel568Sql22pSuFvxz1dUUQZ1Ur+37l/P1vGTM5t2qcihXT8UTUZ+/'
    'zF/aU+m51A7WckVzyjfz8lu50aw8am77VbxaKVeHdx7/qk7vkHvc1rQzybLt66ugpp2+PlyMGFuBF7AT9R/gGfzGF2SfckDc7Ydf'
    'Qg5EtypsgG1g/74lTqbydDgILq3z1bnnVJWLWywkHLpaz9Tsl+qb1Wl128pKar+N1oPezeLZMkovs85UCV6M+0HFMy8X4654znfP'
    'W/D/zhBG2tIwXnr+YjVT7OfFW7vRbba6h9UrvuppYqV9On+Sp8a6e8hPS95cVOrGfD613zpL9XXS109vtZamLBrzBwEhP2vyJVFT'
    'hq/CqjcR3ga9luob14ND93mtz/xp+aKiuaYt2IdGbSHdWMrCkGezhQI4SgZbPfNFTzfNG30+vXRfrfrgclSezmezcvcWuWI0Q6fy'
    'mu3UTydeiO44FEIE8Olk4jjLZ/yHi3pivp6Mlv/xf9ec5dkpWevr5sX1RffSJni5fLaAAz5f+OeUF/5P/umkNXqgZDdD1L7o1R+R'
    'cT0RxnUFK9mljGsK69sljAvf1wdvk+bZ2bDqriu3bqfa1XixdLO4vbeqPbWtVW6ue/54OOeb9uJ51ReHr0/3au2qVzfuG+vTWxV6'
    'umuujcAfd0u6eiG0SpVra1ZqvfbKje6wKRnrabXvu9W1aK8Ggv6mtU+dw6cXe/5acfqucgH175s39q266JXO13cPtqyJpYdVZTq0'
    'e/cBcC+vdK7PevL0qht0X17L/cHh4Ey/7yKSlq/n3cns9WbSs0pep1O+az96fPlcOFc7XicoLU8EvqTWzpXSCHrisadr5a5dvn49'
    'PJs03fvrald9u/KrD+qbVhq/VczSa+t6ITzM+X736epQM5/VxfKWr97ALDVq4p1/13X6yqPdmLtVZbzgO6JxJQRad7JWL2b2ahZ0'
    'LxfzXnmqa+J42bdPNfd18Vpp9l0BuY5wdyXcL8WH9c3Ee5n1+J7WbUtVaXG7epk/ecJp7+Z2bZYfFl6nezkzZNGyr31J1ufzq4p7'
    'SjYUXL7zcnb93lvf73wPzy7qQxyAF/LyNvlyMrt7Vsay93ptBZIn8Vb57lDQDoOObSt12G8WL+fzt/aid201tHr/ymn27stnJ8vr'
    'W39xFTzNV7z75Cnrw0ddsc8GK2G4vnie8c92xdYOFU/wKsNW5cy+nsEfC/4/zVxD6HYNoW03F5omte4qz+6wf396f2NXa7q37j0J'
    'M+vckUvnM693aFTEK2i6VHYGlXWjc39T9tzBWvH0U+Doh449r3Sr7mw5KE+UwCo33oT1fHZXr0F3Hvx1areDrD2qs1IBP4SKeCOs'
    'ha7Md6/NQ3l6+jybTnu1u5FcmlWswcusv+ZfuqeGGVzMSrf3ZplfXOi9Qc+68YbS6rq0qAb3ZVd9ur8b9fsXwltzdXhRXbSE9qpq'
    'PINs2tXnlf5jWfPceedG6nZmyk2lXdHO1jcg478NTmXrrb7uW+7w0bypdoe3d+X27PBKkVpKf3glSy+guzwJqjacuPz8Kmi8Ssa5'
    'JL+osrrUJ4j/rydrtX3nu8bqpnquvK7c3lzlq42g+fp0NuQFXmgtOmv59Ap28tM57gdPFEd0YDMMM3p0ZyD4QneGj5Zo3OkdvSPe'
    '3UurZuOpal2JsLBevyd7jdLD7f1EqZrP1Tdp8NZ8a3TOZuJt/613O9BX52flbqVU7zbcoKMH2uEbb2j2dfWh2u/1Z8Jzqd7xNKdi'
    'LQS3+jK8um+VPfGwtYKlnVcGs3nvWpkpimXMQCvrdq12r3wIG3XAP5cujIVTumqu9ZO3RXdxORhZXbtR0pu6sZqdHy46E2F4tdAG'
    'ykLzZrWBNXm5la5mUiVoT0a1mv+OHTMYl5/aY2myeA4O52+DtjA7f66cjY35eeu637sWbxet6q3WDgAx1qVLeXLxYr4ctszHSvex'
    'cve6Pqncj17mV7bYWTwbrf6iY1hat9JR+QpfdSdN41oWW5PnQLiZ3xrzJ42vaqbb6UmNttoWVrasdERVEVoWf6Wsh12vXz2/c1e3'
    '7k13eFq6qNz33l5BRjy/Mtv87WjlzpuKJ/duNbvqll4889AdtnuERZUfglv9utu5BnHVUa5tzZwe+uXbWeksEFr3g25juXxGE4tK'
    '9typI4BI5V8wNZO8esA3rxfle+vuTl5bwNquA9Hqzd1eMOuJV6LdUN8E0POCrmf6+nW90jmczh3lUOuUbkuXy4HXUfvnr9VH71Vo'
    'vV3aI328vtPHqv58OH0bmOZbS2lUhHG9ItzVlFdlvh5U+o3lrd+/6PlPbskTXLU+PrOh13VTupytm7NqT58LerX7WCo1J/X2JHgQ'
    'lOpkdXu+kLXh07AsnjfXtZpGTW+HmqLc6HeCrt9eG9ez5Um1trwpNQf6S1sRu63OYtyq9qtnJwv9UQ5uSg/iTbAaLm4f7dWV9HKy'
    'eBh4hjJdzxa+bwitw6vu7LA1lub98nW5NOu67SWov6f6+kH323PJ63qVx0qrdXjt1u/O5i9Gd3DIr/tCz36aTU6H+qgyW8AkOhV1'
    'zS+sTkmpXx8a8tqeL4Su0T0t1eVlvTKpKeuycDVyS2faQhjyjjmcPYIc6h96Zu9cVSYP5REpdefN9GF3OWm/zYdqfTZ3/VdhoPH2'
    'dDbT6vWKX5PM6mPZdvynetUsNQ+7yuRNKK19/V7pHr64D7dirW8ZzuFDyfKHle7hc2lxZZfWz7DvBrAVTmvS88l8ApX40lrVh1ip'
    'eiXcTGHZXr3y5eLt9uJkvgTeU22/NLxnwR1edR8OecX2qneNx4U1KMl3OjbCC41ONRjK6mNwfx2URl1XsUA3N32JVyetoTlwTm/X'
    'Nf21JZysgt6wN3BV5X7SC9TVKhjqQACHV+ftanu8xFKl/lvzURan3ZfZcOk9LB5n3cvqtTMzrhv21SEvAOOt3j7y3unEqJwozZe7'
    'c7s8P+8G5ouurGRQ/82bytnbVFhf6P1S7bI5Vyc3TzPnpevZ80enUhFutaHhtOXT6fXsSm/OHozgedhr3D7VWzeLyv3EsV9K5pPY'
    'U5Wn2+B1KI6fxFbTfr2e9HivP19UrLZsv956s/5lu9K7CLpXVaHrHr5Mnwx3AGpdrzHnh+Pu9WLSP5Vmc10rd9/uh6tD9656Velq'
    'SkV+mtlK1bsJPPmm3xrynUVbcPnDmT5v6a5auW3Jwkt58dpfHDqP4+FpcP7wdnPXel4MnyVPf1NvH69fOv3Wi3V/d6ku1u3Fo+F3'
    'dU2t2bqxACRz2+cLtdaT6vzc8s7XFdNVui7g8NAw+jV3JppvV+Xr+1qft/vlYdW5LXe7zfarp18b436gCUb5otThe5d6Ry1PZ3Ox'
    '33txe0L/Xqi3RVc8VHmneV2dTXuG3JWu1LsGfzmwK134A9zh0YO1AcVloc1sufbMjPInXtO27+78UnktddUb7b5yKAvztnDbFd3X'
    '5/WV3O1dL0b2251+AlpQrd+4LHuT/ttictNvLwPXqxyqy761Lg96WrnXfVq8djx7eepe1mr10Ye8VmuvcfkSvILQPOdduX9nl69f'
    'hNfZzeT6br1QriuH15ZVfbuwT07NB/32WZkGs3VPfZpNtWu7Cvy6dKv2jX5VPnztLb1Wp1oaDDqnU+3yRLnqz58q1p0ASmJwf2H1'
    '7n1VcTwvEPqdrtDxZMe70F/Vt/WtPV9rM169Bim+F1y/OCeifPeymrszvlVfN7WpVxHO20a5/SJLdwPdqJzPPa23nF9Ki4o51V5G'
    'F28nKvQ0L7eDvud67ZXbXT6cvfm1i+/1650pgXRd0Z9gDLPx8MJ6OlFHo0ZJfPj9d+oQ5Q6W6AVXePZtjL5RGaNtqP+WuEgfqVP3'
    '4PFgy7kFGtkcxgJGhxDDUCbm480Gzh1x/TXJWoERV19SgXvdqOxXciwBCsbJum2OeGdppu0wrLiIiSom3CM58wDPe4UbzRvFwdX0'
    'dCF2mxdyJ2SinoRM2BPNBTCmt+fiHY3kzMt8OEy6rSW5UixXBEnFlOfVspSMfqhWykWMda/KvMRLUOA9r/UH4trH4nE9cdQvDDuj'
    '922M45jixEFSOh488dknuQzIgBK5DFiu/nBN+nEjGNdGP5rHqdhfM3oxP47S84QBZseJkDz/2E9m3WFF/OPdJ0+j5Dh+FKCfLAAP'
    '2X0WBPD4LF8qym37s+QpwlSiGz8n4u6cBPAZrr/9hN0+Zw0I1eQfN2g4y+88bEDSrOTEx4bpV0g8ZDLHyn7ht2lSTjbM3kS0nUpH'
    's1/jmL8ip2V8HAY2Qns06c9nAnqBlXG+N/j9n/4zxuM/Yzz+M8bj3yLGo16vGbWNGI8GoSnobpmN8Rhcnjw8kxiK02GpXqvzOMtn'
    '8B3G7zdPHx5OTigdhHEWjXrrctx8GLUfuvXO+Wpkdqck5qLjtPXT7nlXmChPK7/aeORXndemddV+nmqP8tvt2pk9vj5Id6fB/RnG'
    'k/QJLY+alOYTf05qnZPa8vn0pATwnDktgBu+189OAVZSvhbDU3/oPD681C9g7sfN7vmKb3XbzzD7/qD+dPl6+fZg3YzVs95q4Fyb'
    'D6US0NUS5r92Wn9otmpnam1+UTtbGqPav9+f4dmwv+j3G/2rvqXP1tcT93JSUVrK4areNmbVx6vZzJbO235F7b09u6vX+7Pz65m4'
    'lhb6yaOvnHdv3+zD7tpV6g+vve5yVm9W1hW+0QI5ZzCQ7HpXCEotQ5hYvVer9mScvjw9zZaCpa3OebFcni4v5yXTvHy1eHVuT5pD'
    '6aFUvRw+9g4vR6Pzu8rhvFpatqrX43WLn14vFWN4yC8cvr2Iy+n8femxwYOWenl58uoKw6q0BOjXxsRwS9VHda0fKo1S7frhcAL6'
    'VP0OvrhnymNpBYiq33ml+eFpQ2zzr8J9adabkpaXZ7TB5li765y8lJWxd+M+a3PT7L1enTUn4lu5w/fnqu1cq6CNHM4DALJsI4yP'
    'y5lxDzDOxN7Iv5UDqxpM9HVw/tLo8pPp7Hby4q3apunMq+fqI86r+qr2uhcXg5eOcH/VrFQvpNOWf95ueNLsel72SvXZ9czod4JR'
    '79wbXC/O7tRDTak6fHA9N/pv0xuFLzklbQQ8rvNjsOi62bu40Kbz83ZbuFvcrx7nL1feSpx0Oz3RKq/npevaWvGuH5Xuxc3Nfc0X'
    'zjs3gTDp9I3D8ZBf8G1ppnZ7Tq/XM7uiw7vtkXsz0L31tXBq9XtNBfRiUX1Wu/asevgI6k7npdqJOr83pFa7LZ1ORy7ffXGvnvzX'
    'Vl0AxXJ2aQc3b5Z+2K5a0lP3VnLVrjS1hmetztq9arXWt/yT0Za86rlUuTGub3jPdeetx9UJyE2P1unZpFpWvbKmjB/n/en5xVSt'
    'XAwW4qLRrfi12rk56PwYYppdzq5Nd2aq0N5te3HxdHhSCZq+0B+vJ0+trtDlr+fj7lpRFO9Nc2fDE9FpzhcnUql2E7QOm5J/4fLX'
    'bUU6H5wOz7p95VR8FtyroVq7OnxxbG20VtTG8LDSGb5eqm/VZWPcPj08mz3KT9eCbnab1vLltFx6qXvVp5vG5cx1qmt3pdnO1eHl'
    'tNyR5sNOA5TnqtVsVWav7dfWRICOZL7RqYje7PairvDT6eFq3f//2XuzJceNZFHwXV9BVfdRkmIWCYAkSGapJMuF+5pcwKW6bgsb'
    'SZDYF27qMjtv8zLvM2M28zw233H/5HzJuEcAIMhMSX3u7fN2S6YkEIg9PHwLD/f5uS+enrH6euPFCYpzjlV0tqccVs8sVt9vtJsN'
    'p20dT+2jvLfbL+VpYz5fl/MFcVtZrtXxuWyyq4pzWi1fd57GWkxpuvCP80ex6ijlMdvwn+vieLxa2P1uydAU56XrHpT84RlH1tss'
    'K0HvhTMUr1rfnLbj0b7ctX1HGql+3xeY+dFg17vOZjKfWe56ylSFve0u9dmOzZ9WBuD18fO/FkM+twOhDwN6qjjH/HJS83YT2ZEK'
    'Q+elJGyzJ6PFFrKTVqBOAL/s+KE2uB4+5NZNyJ0vCbvsadNe1u3spCZb+4o5A8oIG/fwn+rOsBE4/GxttzuB7yxE0dxOxFW3U234'
    'ojlzHMVx1IZu26Jh7caDRls7jYfzNesAHs+unbqhb41ikdl7ngddU7yN6kyVrmuxrvo8EAb6CTcvyxTrGztrnvZtv10cl2cTqXHS'
    'lbF43nT95aIRnLenvL2cj9pq8+ywSn3WMHayaTPM/Nw8V4Pz4/DAu9WpKsyemA7zzJULx/lurjGzQhlgvVmoO2phuW4WFSHrDJuS'
    'd3ipDJy80NSF9bL6ONur2SFwq9VnLo9Pf5B7+Fp3C/ttHqbl1d/j05No+tziKdsUVs72vOj1l+vi8FgfcKavVOwC+1I9L5bTWbus'
    '87sR33b2O7YjPdWF+mg6H02LHbVdMcuKW/YMQ13y7ZGY5Tljfnx6yT8+K57KKnnbrgwKhqUM59PdanCYnAbsqtt0LWcwtwXHKZys'
    'vdZeD+aBKyq+oAxW4tZ0tU1nM5XbEnB6r+ItYz/qn+y9nLWG+mxY7iz0nSbpE7VUfV11vBU3PTYCYK6MkVwxVxVzVAEWfiVn3bw+'
    'm5Q7Ncy987Kl6jzf8Uxu2u62/OFpsdXr+R1fAP54PDZuYejJUkWu03bnjyeG44UF7ygB222xana7PIxqvD5f7flaxX5iG3l7Vt93'
    '9kK5XpkXasbZ7yAC7jTF88I9avuXqmPMnr1gOlkalQXXcgut/TQ4aXy3NGko3vyleTBWpc3xWcRjvwCGNBD3XS2rtwPzuTPfr46n'
    '/U7RJ6Uu52yr/ESqnrKbvinVD8dK28wu5AHX3WyLE4CH3qA1eXKzHGdVGfWlci5UDWm41wGyJkvuKPdWz8u80XzxteIiWzvnMftj'
    'nPv4buamPSnmD36/tQUwGgHBre82qqaaE/lVfemUJH5tssftYWUsVm3tfORORffU7TBMpT555kTT2ALyyp6q251Qr/BN67W73td8'
    'YcMXfZUtm4ysWbvKsF6fuBNHeFZby8Zk1NM1eVss+KPzvH0Q6sWOwlqzYFqd2YPx7NwZintnv5B9x9DPXkebqIu9t+Qen1R9Fq+e'
    'aJuPWcWYDVrNaZb13VEwUswqq9SU/FEYm21V45lp/eTrQEHsgH2aHvab3cQVS/XRyu0siuyhIPc6xY3THcmtQovvK4CI+zV9O1+X'
    'YJ6rwVwYrPntrjrbeme7nGX45qjjKYYwXHFG/fGJsVcxr9GoLp/Hk9554TmvlflAF0sDf98fsl1J75Wbm3Oj0m8/aY3TLKj0QDKc'
    'dRy7MRxx5pMwmpWrw8XS0c/Dc8vb7ftCn3EEYZh/rPE8iNT5yo7bi3LeUQEPiY453gX24jA1rNnUDWx/Wuo6s2futVOaufrjPFtv'
    '+IGg+9W5fVRqJWbs8oo9XEgg5+e9/sTZSltR0kfOfnxe6oAiRqvF1J+MykGTl7NP0zMTlDZZc7iePL6MXcFw151if2JUXl9fB/OC'
    'Pz4yM9OUDdPvO3717PsHyZ/WD3bHHwy82nmef6x3XkX92Z3km3X3OKqZI2cKe3Y62/KHR3E7exTrxtHYbyZdzVhw5fNJ6B/1pX+Y'
    'ZQ1G6ZX6fKvEOdZ2JlqO6LJdS+PFulQZy4DvdLV6loavM+N84HlfaOmmPhrY88F8Oc+yL8tnvTOfbU+ldv38Ou3N9adS4DiO0Z1O'
    'jm3JmSv54qbwOpMKG6XanO5LI4/vt46+tTdAcleelnu1XmCUcV5/CdZeYf9c5gf26rRhxFcOkPkN2yDoZavbLx+C7NaZV6xjo+MV'
    'vGNvOssOCoVCbbhU+s3O7jxTNtNyv2lpMAxvoVWaXX4ymXslQLSaEXhev7MXFVOd8hWGs/ZDgdO9G5bBLPFF4ayea4e9VOquFt5r'
    'VZsyO+c8WHL1yZ5VnZbmOlXNPQB309snB/hqzWRe6Y+k+bQvQDslVehUaow9HAL/WjlMe1dDUJi6US3OVyO2m51KwXbcyUujVa/+'
    'MuCfz2qlu7d4Pd8ZzGRr2GfdnSDPWqWBLSljXj31lMau79crwIMc3JPlSVxWqe3ZJ0liJ06prlhnTxVq/HR0VqvVrtBtliYltzg9'
    'N+2C71Uq+lBezFpZde1MR55b4+d9pjCU3ICdHEXLcBqB0pmqDHC3RvbxkTWtx0rH8Sxe6AMmXa8n7m432rNGzZWlxcKezsXAmzrV'
    'aVdYVcdiTdyrsyrwIwZbbx7FUWDPWNHNzp/2h5H32n92ZaY7ajj2eNqfT7tswM3aVdEtvzyxgQiCymhqd5XxQazUVdd0TLben5cE'
    'cT7KZ415uVbIN4/dhm71q9P8aHsU5xXgJOolc7hbbbWiXAyCk9vwK2PpRXnZ97fDun9cea+sd1qdpsy4tfcm0yN79Actu7Xs2rLY'
    '2csF2S3ZXMAyPMsW+GYLFkbZOFXPEfyJrnVPha3D77Lloaq82A39xGQBmOzjid02VmJQAWF+0BxYF+o25B4Lp/Fi4Eu2IMyVrT9Z'
    'se1gwom1VlHx6/NV162/TrcCZwIQZQ2+vx+XVu2y+rQYazbQ8e3GbjXKvWlPWnBttqWJrdXr4NV3p6WTKw8rg57aPZvF1bTU1Cfz'
    'jfdqr5yzWVidqy/s41O1NehfurKpzBYLz+hIov+kOm191IA9AYx0Yz9jTxLTO7ywz7LVH2uV3rkx0SpHtfF6nlVM7jiedPjd3j+u'
    't4IgNMa9ZctRu3NZbcrV2fmgAwNk5NWJ+Kz6s309uy+po/7Mno/z84pWC0q8b266QtbtZyvKmZWGzzMQCqRqqW81bbWSX1XqpRfG'
    'VFbIs77qhaHgVdrinl3uC9tAdZfFMQtjWgH/91jtFsxyfr1vqbuyW82fWuOy6XBqzZ/zXqF8HhTF0/CwAdFKH827wlwcabx1suTt'
    'Yl93gO10S3UQHZ3261PJdPRCfyEXKttzd9oFWbnkFRes2+gvjk5fZPsNf9SvjQZWhXd02wmGBu+YG3OZLbeOzTZfH05rL9357LVi'
    'OPN5d/tYPXO6I/enL/NBMVgvvE6+8vg07U+C4JWrdfT6THNc/TXga1Jnt129lvorcRw8C5O9a5jZhlTcafXS3M5vjNNeZ0tD5bBw'
    'dV9tObPlUPWdVnPk8jOnzG8FabOrGi8STPyEq+oTzw1WY6GrTCtax+mWn1mrzQ7nXWdY9IbHub42Xlm1tOWKq6CiWXl+cp4c9gVv'
    'l2132lsluzsvm6OsJI5mpj2rWC/N+s537bYtrebjjnEE9rmndX1RVivC/kWbMZ1ZxW/wniMzi+7wZXJ8Pc44bel3WKflltqDvFxS'
    'hiVl089P9zNp7giD4mTb0bxqvjpne0J1vJna/mDnVUsv/UrgH/d6wZF8xTnNPNdxRsu2bddZuXrKT81XrR2MaqNaoXl8rC3s1+cx'
    'SNtipVbcHfvT4uS4GrV2LLcGWXP+1C41BrZojhS9r7s7sSyyBWncLZxnNmOcFvKJ8QcvvUbROy6NjSg4wWFZmJ2Y6Ytdau0cx67P'
    'qwvNk9mTV5B0lhGc4Xwib0oyY67P681jzZsNW/OGcPYVYKKBn1O8Csssz/rL6xw2Tsd2Gu5+slziECyna7uOEeRfD2oTpkmYq8Wi'
    '6bs7q6zMFqJdEOqrl9l4MOJObH0+Mg7saSBMJwKQ3MCRzoNCc994eT1I0lJ+LGjlpTx3m0p/yrx0pWWJQx3jtmD3Smd9oXWONdEV'
    'JtWFWT8pbU8/n4ZHQZLb3nE0m09eKn1/54/nnX5Fn5W2dm3WX9Y24tZo+2NHW3k2dBJ2bN9+eaof+sfTzGcPAbf0Tb/qWFJ9zu7O'
    '9lSzy4UaP9NWdq0qlI7uVBCYUV3oD1etjVEWdEkzG2pPno0YV3oRLWk4O9tyZ8NoTHVvF+xWqb5sFhxnW+PmYtsORE3kpXWpPXQb'
    'z73DpGwM1+rusD8t3H57ynHn09yWyt4gUBrcQGBHzyXvbJR75ymrHqecwu1Hh0LD9U+NY+D3MSTesQ/8bZebnY5B8NyW6xqflaBz'
    'lUe9GHgH21q0nKd949Hzeq/FvV8/7IEGi+5I7K5aO2EyL4gO8ITLdlA+z0cCWy7tR+XSwDsGi+CpXF4Pqp4vVLdrgWG6S15VzV3p'
    '1FD7ClDQJvBb7EjttPb269nvDp7WLAjT5/lg71UZu2xKHWemO7w6arfsRaHDnoWRoq6zvcbkSSo8Gcqg5QlFZes2BhY/thfAbL4s'
    'LF9pWma9785lR+yWqoM1MB9GXzoX3KUEPZ9b29F5lj2PntuD0VxtMIZYnyxtoywLJ2tefu4YTrvbcIajQjXgTLNrNZ/4zWnpFurn'
    'wbTszA4FfcRnbaUgbYvN8Yzzp06909m+bv2uv4Ld2RrZ8mPRduul00yXXtwyry77q6VjG3y3Eziy050VxEZ/oLcsVikLTHvyVAS8'
    'qvTtqsyU1G7Fa4j7zqBqZuvOcL0ftu16XdcXiynrLJ2TPT/uR456BKy3PGkHfRNsmVmDmZ4c82nZqBT3IM+yPe65aIn9xXR44ntC'
    '2dtrp8Dhtwq7OrLN42BX6/Ve+lqjM2jvp0enZXqDM+erx9kQwDqYjKZCfyq87Oq73c5rbZaSOplIrH5eONnl0pFM8YkHjnUj1BdO'
    '/vDMqs3dZPTSUAA8s/1S3phmK7tpvSuUBuJSgKW23G7Zc0v9uj5hjax95BZsc1sYlnZKssh18ca+3OUFXpfnJXPPlFZZL/tc0QYB'
    'K4zyjUr+3Fmpg8TzuPNU1aud6jjoVo68DHNQNw/z3YjlHEDfBTO7nJTPjF1xuwuW7w5lPhjtx9uGLzpZKPwMImFPnJqmIRxXRtNV'
    'suwWRIZ961jdeqzv+R1/KDlLryswQjnoAuc0dtxjb/04Fzr6s/70arvPM9ihA9nZmR3pxD0+Si+nP9c/aYVO2W6Lq+G4fB63qg12'
    'Wu93m+5BcF79ZVCZufVK1lZ3LtQo106C7/jZQafTno+nnfZYcPqT1XkcCLNh5awLsFdLaqswbS8MdQl8+uGxVmFBDD6PmeqoOX0d'
    'DzWDCKjeHCRUQJEdrfps2YuVbsxn8GY+1YTJgBefWHfsrmoO3191SlPO7GhKxzJMrcDL42A97G5125B1Vz55fcFYBstsvXfw2oVx'
    'YVIUNzYvsCDpuSCKWgPJEMo7+ShwO8UqrzV5KtSZ3nZzrs+a3rzEL7ccf5439Hm1N2t3GhtT4FsnR182vYHgVAdVrjzRtsq0UH99'
    'VQcS7y17JZDQG/WuvS7v3NKaE7PK9ggrwJu6aS9sbtKd+LPxU8OqnuuCA2KUoCCKmbJF46U09bbsQdCFmqtztUOFPfXZgug2n5y9'
    '97peNIQX97Q4jVcntMM/HPNlfZSvqlNdPB56x/lmOJh0OVbQ+3XgDI7dqaAMX7qdnXg++k7DcVoglwG/ZQ9GqitO5rItWM/T3r41'
    '6Q4WO6tQfC31gpeOWh6/Cj3fPc6b7dnxdewbUs0ZmirfFUXHl51WoPEdB4QA0SgXj0GjJe6b00bfq83M7tj1zs6obSzMQNLHY0No'
    'sWJpt+UAauoMC8TdfFLqxc7Ue9oaecALs9kp7yn+PiuwleNcLL8s5EnRcqRSj3fszslb1UdTTzL5srQoDJcFQ7OcTklxR+pQ5ZvH'
    'ihvoitzrL+ogau4sUWP6lnoITmKb7z7uAq2zbcCQy0tmkZ9sbXs/n7rOS2ezKcEcIug/dc12zbaXlUp50m36Ur8/YXueoYlV3usa'
    'UtZVq8/V9iy/Gy86hgXbUZZYZnzcBx1Fm3YGkuUcgJOpZvfTEt/S5GG1rw6c+u75aa4bS18LQCJgTOt/WO/b3M4Yvz9jZLY5ex2B'
    'EDQ4LkoLu2GVXM7BqegeR9PhAkT/SkVeS+xm4BkBV190tDLX5oPVWZbqIIjabvYEAv5e1ORmu8Twwro6FRwHpxKk62l++srOgVw3'
    'nnrjSXeoeh0ucEwlmEnGdNna62phdKqo3u4QNAJnVJQHxfzgtV7wZqXXUn2x9KWyqcqDnl0E3mwG0pQr7uZV1lWVgiOU9rp2OK/k'
    'V9+udIpj5fVwGnAd1dg6S9tuD0A4OqPuWp7puihIx/5hVvPL5edg381uxT5gqEIA/PzguajOCu3gcKy/2rPF2apD7wWcGGXSOXrj'
    '1XkgApNf2M0nJ6NYPZf1l2IrP+4LWfGVZ2f1ATAtZqOqmExbaQf201gUq9vyeLPo8koy86BUPW0qtZWNZv391XhhFBbLV69evfrQ'
    'lLOl1+zzkNkKK2Nr90Zez5o9Z81ksuEs17L58tzzG/580+G6k8nRLrCdrKPL3GhYA25OAJy5KenKSPOKUl8RAuDpxudyndP768l8'
    'Wekuxp5fVZ60+fPE4Tp97jic7B27aDcU0XLnNuzjbtDmDv6uupO054IX9K0DcwJu5Wy4cscVFwCVzqms94XuVBTmzkzejZm9IzCc'
    'NXyZlar2qFrDm7awQ4JS7dUcts6t5+rCdhfdo8brTldYzAZi3lhOZwPVm0yEmmjW3XpBDIB1GqlVnvGHG7NrPgaN0uw8mz+DFLHk'
    'BqPzMliMKsCmrp2h4pSGPdsflU2579bGh+mgUhE7us13tmvLGdd39f7k6GuatjC2s54IfyyQAlpaSz08NQCy/2f+DZqBeNT2agmo'
    'p+E4DuzQx2bbMsTGUjcO80lgM8DOKmaf3dqzQX7J6+p+P63M65Oxx3l8C1Ce2988C54/2i+7c170t3N7ZM7222JDW4rL5fzcFKSs'
    'Xva7/cnsWPaDsa2zs7E1d5buseKUt4AxxosD8MZV9fwSFPbZylgLqlN9sOrNNM5WsqVVYb0Inl8aM6nR8X1hNT2pWXWvHqbnoTMa'
    '1o9Tb66bOruU61NxsBZ1QTZ9xnCbduFUFfuTgjtZyP1Zg13IeFnCqzZOhl1kiv1iMHflfV2oLHenIcgq46B+FtqA36Qgf6xslYU4'
    'bxRWA3buT9T8qXJ4fDa7l8swbLPXfRSs42rc4ZfOlD0sCuOOszDyh8ftvrBr1Y3NcanrGmzNOVMx9wCMG6exmjpqV9uI62O21e1K'
    '3aq07K4UUdBHj9XBMzAJrD+3phpbXk5UtunsBKFqg+BWOhlVQyxkV/BHPxtN0Zu/9tfCjFHOYmE2NuRy1XUFrdpRmcKrOzHqeknt'
    'NYQVP/V3sDQSN+AsXhsK7VY9bzBFdb6WbH1jFJqCzIry9NTXzEJfc5V+Yz+3RiCkwvIFuuwPF0510q+7jmxNSlp5du7uC8Cb7B+N'
    'VvOl2Ycu9uWt4RjAf/CW02wPuof/ESjkB7omBid+pHXMV3c3GKw2+e0oX2j1eke9ab2cS9lmtt/MPzZbiU/LEf9YyUbvom00DaCM'
    'Da667ASKP5rtJ9XJeARCwb4i5gO7yPb9znbqTqYw80vXYa2pFciFTYt7zs81jutw40KHZ2WlOxm1CyBeHOfOaKCvaoJ9Hp+FgOt1'
    'NlXTk9r8mN0rXrtxnpuiCX0SlWeovnR+Lsz4xfE8O45P5uLIlFkla9sWy2xsripWZ2XNKZ9WPafiSpM1X9elqXUK9i+7Mm/JpnpU'
    '25rS1Ivm6OCXpXHLsefZ6rTQDfL71WGwMudBf7rjlZeyP1Sz+cPLXjn22yfjJIz2/bnZ6M1c/2y56n5ULA0P2Z2pdvq7qbQoGqi2'
    'aW1n/mRUmzijF+9Z23d5X51w/LbKleqsOFM6zMZj2HK1/PjY2nRvMYS3bYxHwXa3YMuAGUrujh1Nef11s+qVO+2mXFLkzojv7pXu'
    'q81kB8PK0Go7T47DLFhBG9UDd6Arr5yoVRhhfyqcu4FRX3KcU+kbjiuy3MmTqqpi56vB/tUsO/q63FakleoqTbm7FICeD1tG6SwU'
    'uyz8V9xO5ZPsl+da0GbnE4vTAqdd8MrTMjcBzG9X9rXNgJt36+rMaDcPwwVf5wf5GVPR+OPE5xm+WniatkRz6pvemS9WS5NXt9Aw'
    'gAMvFBy1VC1Uy8GTKDfcRe14XsqzaWc8Zc6Ljq+tXGc2OrWq++3EnRwtqX9mYB/Ul3l5M9wOerre2/PKrD4Dzrs0GRQH5vA1f5yt'
    'Cq2BuslrXj54rTZBCkx8kP3dVg62y0ZnP9XWy8Hh8Wn3z+yVbCNfEDeeAtO3l+1AtDuz/vw04Fc1TRGdQGuBOGMJ4/PTeXzsa46v'
    '7pR5X5LErb9wxuZOCEqD571saMGcU8Y1W3aypclhIXtVb6uWPGU+3e/00eBltx31a/PzHjnOVnm4q9rVoaHuJjMQtbnF4JXl845c'
    'Pteam65fDV4fX5wXIzxu0pBr6lqOXO+XDy+Grq2e/XmDZedd2ZU1+6y3p6dOqW9mRyfeOa6WrGVb674gbibukevsZItjxOp42xXt'
    '/Uv3vFD29adVuTsuqNy4Uh6z3b6vAWNnMx3yP2/td731q36aSPpwuHALohmMFuLY0owtz8xGzZajTqoz054aTFacV31mVjTHs3Je'
    'HFr6VlbafpEFDPFYfXysverrt7N9eOIst7kEFnn+PJpN2d5ZVPGcvlytjYYgL2jtIjsMWqvSxF/168vyUJp1nJHQq+zc6kBfMKKG'
    'flRGq1fRYScGL+0AHRf54asuQCdGzdlAPnqvRdNZzhR9PO0HQoEP9I3i2TYjwRTIe72gjFvi4nFaAzJQOS0reYd1dHHGTtXZ46P6'
    'MiVeO+pCnR0p9dfi41PAPVVO3mghATkas1P/4J+6hWp3kJ8r+VZJEaTqXOt2ZwN+qvB+v690V92z3596XLEgil02ntftq21MSqel'
    'tOkPF11bspsOYGoH0IHl5L2y2HXMHbt0S2y3cXRPnL+pbhh1U2AnprowKjYgy7b8+CQ1Z38K1DWhYm9fvGrxAJwjL2h7w58656Fo'
    'VuoncTifHEWA8ZYtAGtWhS0zWFQd4Gb7zT6qNgb2+EU+yJsi7zi6W2kJcr/ru/7AErdCi6uqh2pfmOQfG45pAkwPbGYo8MKzea4v'
    'i7NS/rVkzvyOI9iV6mg238+B/3zcDSbtVa/v+g1OrPOKJJ66Ey4Y7MXluZ5tFfPz1upoTtSdNGE9tTNQ+Ce0qz8sm4f2U3kyWOyP'
    'zSZfesn2FNvszYvbbVXe5BvDcd/muWG9MVjP505Jbowqz68qcza6ldExG7zmt81kA1tmK6r+9viaqP1ludsbrRLfn52OvdFq1Z29'
    '8m2+2cgunk71mem2nHK9unwaHDWr1GkYgiCWVLvMjoYDrb3nz5MZq56tI2dOJ5WBV5gqnYD3fP1VrKjWed/eHMpD0WsI/aJjsVs9'
    'YNz50Rf69ZIOQiLAFxDH6pRnmLndFgee1BiN/O12wYL8CPRFNIAllWtAYVZDNyjpMmsLS+kclGcFYT/ajmfFx8ft7nZ/1RYVyzie'
    '58PnXv0ExFLNcicnCyKwMDcKLW0wP3e2wvzYstvHY+u420lWqdFXj6cOaraE+kjtdDauw7DTdXGvjsrO2tX0zq5aGq9rxWLxJIwt'
    'kJALz6xQf9yywtkZW8JUZFelZkvj20W92ra7Fbun+Iql25pqzvR53S7P6+0B6xzVXrMm+N3AAXKxkGDCmNdGperMm+axd2aDbuW1'
    'PA2GQ21pujIs8vFcn1fdYsO1+mc+mD8Z28eC6Y+LlWzbUP3jSmuK+rFUmfSqkpavDRZO3l89Kk/BSjgVe8ziuuoRtz3tjhystCIu'
    'DFjWwsAp+rXqiz8Z9oQVt18P1oUhApHYmg1Kw/5W99WXZuHZkrzTvDM3Z6190+Bsq8BUK/ud8PJUrJ9m5QZASB7EiadpfxEwev3F'
    'ceddO+AKXdu1gLGfjNT9RJ502JrINnw8ZmBGtWJrUh5w+lNZPlv9BnMC/v7MCgu1tJqWHp+WzfHj//r3B/qJfH75tw+RY+o4oHl8'
    '5YfENcfwIXgTxwr82+s2+XfKzFQpjAeKvsoxzksUpkyksRD/9mHj+7b3kM+rZu6g7TRbVTQxZ7nrPL7le5qp/N0QbeiYq4oKBlAL'
    '/JQBqSlIje7PiFHosjC0jUWicGZue7hxb+4vUa/Zsh5gfJQDRtLC+0s0NArWMrNc4mw7iq767s2vG3/S7I1D6QK6W+8SJ90/0LlI'
    'Oj/mmRzDcGWmXGUYhr/yLl0sVnMlrspVKsUyy7CV4r/Qyzr3e/fASEffXvca09heYjK+Hk7x1S297uW+VuhtHOcwjLhNbr1hJA+d'
    'xqWl8UouQeuIG977lCJ6G+rgXLF8X317aUz6WcQ4GQnX66IfRZRVTeXadbu/AXAwL4FXMALRf/z7//1o2/oJO0AjIVJf8P/x7/9P'
    'isbJu0pOkQhal2hRMSyRudq9M1ckObW1NPPSZfNEQlGFIXgSg8KIVyly2y2laCsQJzCg3yXCUS51M/NhwLeoYoUEPKNTu0vBTCu6'
    'ehVEkcQPextXgN58vIkt/CZ6U+I6lUQv4F1CRyWL5lJR3DzSDagaQ7+edDUKdXdd7U0oFZo/jC/2bsy3Gw/o3I0H9BcKMyRM9T+3'
    'tUpVNsczhUIZfTJUKm/cikd7+J9z3E4avjgBxoFTN8DYrQ/kJuxlLDf+0bkb/+gvBOpvx4LB6nIcU2IKpWqFKxWSLppLJT5XLZZK'
    'RRZ96BdL7J+P5Q98TP/eWEi3bsdyG4zvxms6CWiTxHYs9D9XKZSKRbZQZov8latpjOpULHBlDh1pM+V/Yhx/5Jf5ehwEZRDP7+ab'
    'Qdx4UeduvKhPEIXcrke5WszxVYCbCsMzFS5yF0/HwVdyTKVYBaTNFbgSy/3pOP7opu71OEggCOIJHnt1O5IbX+vcja91ipeAigJS'
    'o7v3gmcSYysVC7kKy1cwAhjD8tWrfcPguPlyuVDgC0zhz4fGrapqsXgztOKlyzfO1rkbZ+tFEmNX3ANyWiHJ/yHlbcSrWLt8qZir'
    'ckyFLbE8B51NhDvgWDZXYUqwBCWuAJ/YfyH9/J171AUMywPELSIKhZgohME4vChgT4wMw1DiiVB2mo5hbjH+JwnRuyGh7S6hRe6j'
    'a/IewcikCzETE2HiROj0Oy9lioaKdIyE6bbsFKEEBOuSL9obVg46vsAAKroGRNA9vR1OMq4NxjN/E9KG3HymvY46QnirDVlMcsUa'
    'iMJeUw+ExokuACUuMWEUFY/EMsGw3N59HLcuujQOo45vjNPhv9P9McDJOwvxXhyZ6N5xethvZBKkmUY+QU4EuD/kK04pdE7/R8Fc'
    'CL+YzimWfEzWdIDduiH8EhlYxFU2LGsNC/xiybDeiZCIuKxxfBpJJVE/N5Rr8u4Ti45PlLkmWUS8g/9HvYu42EQUx0sUWlvHDiSC'
    'Y+HnwCfRZa6ZqmfLPiUjL7qxCwYSdjExqvcDxfxJ8EXuJpwBdxPOIIxnhfvI+9cgggjr/NMRZLibkATcTUiCJizHww3wZ1MegfL/'
    'si7/cSAO7sY/BXfjn6IWyzywC+4piP6QMqx/FbJ92+H3qfelwzdiFXcjVg105JkJskwFNkyxQmQMw1P1/0LAeJ9UX2LG3nCqhRtO'
    'tfUf//5/GcAmY8TuEK8l2SOuwPwel3crDJb+lJhhG2+IGSMDmFR/zwtL/dItD2Qh9P4hqcSzB5EWThckRTECBvjFfQ8iHYYcJuFX'
    'DySAOqJ6OyAUx8ilHsN41m/8umCDb5263MaJVg3bD4MC0ypQbiFBg8P4s7kUCWaMTVy5dCFxi8NAZzZGorZWNCRyGBbsWtb4jizi'
    'Byqi02X8ULhh1yMQWbmWkWSxrAvnectrhpBxwytHvFNYUQwoVoKNeof7Diu7jU1cuKos9j2DlfHh0L779lPek13N9n/+7qfoQbZM'
    'z0/9NfU55aU+/xxH4Ms5AaAuKnlabtrLfApzevs15P1r+u4vsmjuRe8uc4/0WlfCVPKMiZ6P/nVoInnGRIwXDmtLU+nLXVx1fdCf'
    'wKe7jyII5+pH7+T5qnGfesLl6InymLzXYXnvgV1YW2pq2rpPjSyQba37VBM3va/JYqqvBsBfPLqaqEMvRNP76Kmutrr79F0+n3qK'
    'QrGT4G1IisOAbzRM2wPGbUTwQ4UFQDg6cUE2wICXNUYLBOFbxXolHRuBfaatoXE7cG0Un23oaS4czfCxW5tMajCgL3chNbm7T92F'
    'WJo8UvxHHilWIY+UYSaPdK+SR7ZaZmWOPJZWBUWmGapygZdK5FHmuFJJvvsazeZoMJj8vd7qdnFKQxb2Lvo4ngxG2LU7ynp+DEnU'
    'w56Ns7R6jb+PW8vaGLL9lhqDxMPcp3qIouC3iyI4/M67CLhM6ttlDUe9x8nbmuNqoUe1vwu10bg16EO24icAU1gXKTBs2Jial0oj'
    'WhGJMyj0j4MbuNdqjB4nUGCcISo6JKs0pqqIofA8YB4o/xYG+P7uO3T0A6iBeH35TDBj2E4iYjVRVKQ16BRqFQEvRDgj8x31E2Tu'
    'njHWnodL+DUsHylavDuMGYjVyDQPbjz6VQSU6mNA8gPxSYXcEQacxGGFasUVTAh8u7TTFQHJYju/fQvbIZ3TlNTHn0N0ilocHbOl'
    'DsAfYu1mKv1b6nifOsEGvE9tUt9gf2FjYe20Qdhi8EwbwtIkkG88I4kBocbLU8MmNGQ6sY6DqwHeMUl5QA33OHtQHFYe+XYCGUdU'
    'gqRO5O8OwAMQVGqtwmTgaCBJU56twPTD1w2NnA09gOJj1U/D7sfKA1Oxxj5GTMTJvifhU5Pv6ABogs64ot7fk5Dv8Us40PhdB370'
    'BRhd0kUfOocgig0hu9AkSrI4Lyb1UQqKa9ZcoDafUytR91TEZMADzUTXVJUo8dN3ITgr6koMdB/XLp1BBAprAsRqI3qaF8a0ghKK'
    'Gj0TZvohdUejOMLGPbiiDe8GDCAw4F0MfGsCRJUWgEWNNs5s9DgkozEJeYEh5cr3KVoOdTcYIhKaYXMlwF+r1UOqZYI0pcFA4s0p'
    '6SLZD3FP0bFZSyGlPdXHCYS+RUNKZ+4pqD+QlTMtBXv+W4rBP5pCFhy5Guh9Lw6reX8FD5Q3CVmTFLIlOFTIDPkIR/KQQFPf8D8Y'
    'bv7H1Mf4H4HPUECmwjCAuCH6lPugXB8Jap/gBS+lkQYKqutpII4CboF1PKXSRPtBUAt0+oJaUoBBQDhDDmIfFiHCDHYA5wmmiHJA'
    '6MCN9IS6PsM2JOKFzCeB5zH/QTxB3xB1KYANaF+B5QsIkopqx2CCULOq0EZxQ2CvMg9E0QMbKQXSAmQJtQHRal2WKlwTmLaQJQLy'
    'TybnQ/5D2MgHWheXAlQJAE7CCMKy6IEXzuPDG0RNOhsWp9w4/CukYqZQ1/ZqqK7+EKZ9SKWBH0NuErrzIfOJTJNJPKAhXk3ItWkK'
    'EQmAoPXDPwoXGdI8Mq4fV7olkj0dtfy2cOoOcwIHEfFssB7+Ach0KlS3x7WHdXxK2TBUcghBtdMk3GlYPdW00R4Q/QXUiGMBsR2j'
    'soo68FOokIDhXilX4kYQ36A65Z4q1w6ah3g71L4ABKx8mBBE5JcZyeRSI1TB4DjD+QMoAkgzVBGhEcE6rl+2bA06SlhYEPZtG9Dk'
    'KoBG9oUQ9BPUDHUN5JAFWXKiJ7A8gtI3VA10Ctn7nWkdcrSJYipSJsCgZUAzJ4DaD4QkwJi9DREP0RcixiRGAI6pBwxjHAPYZfSf'
    'SIYQmOJhrC0isOF+CkdEOPJLd8IjPp1SRdEj5wkSQJ2N20lJjjL26EjEDGyiZXoaFQTJDImx+A1ETdRhZ3q/v5VChAcYE1qsw4zm'
    'kazjA2BjWA+k7bnUj/nvZKAvHnCaB9XFrzXAyC5QdyCVsJvp22/fQqybQDGfCcvOAo4NEXAul1Pu461Imaf7xO5Dog4luLgEmcTf'
    'zV+4j1G6krsdI6ZdxnvB7KRK4ARQoYe4DaEEsRtsNVSJhXIUkwn1UDQW9UpzvcQpFQWgcCc9pAbSFnisHE5eDWqBJU6HSWr4Ct0j'
    'uOsf/4AuZHKGaKfTX3bQ/a9Im0JQwYSxj0q89A6SPwNXydylfkmReTP/iLwATnzAusjs0Tks3M56PGtFkgOo5CowSfxlsplCupFW'
    'MtCeqyJ1SFGvjjnNa5m+ulbdtPJLLqwmA/1SohdoHL7QEf4CmByI4SeQv+L6DQ0g0lfT6EIwQ2ACWZM9chfJlvHrJ/iorVLpfern'
    'K945k0LflwdCNq7hMH1n4vtdouhPKTaZP8pm+ZftQbPTwOKkxHVjvyElE6GDF2j+sv8adpH0HB+j8X8iZxLY9vckOUKxsNr+yVZx'
    '3yaTv8eVtQiA3P1z/QzXA2v59F200eK9+jnsLOqGYafo2llNMDuk6Xc2Bybf4IOHq37Gm4Ykkud7qqIOk8hzgmWjOAS7EwLe727c'
    '5GTfI3zCBqG1IbRHbUQNpHDfZn5vZ7/FAPG+DHfdZSC5EN9lYoa22+rX/j6eLLpE8PtyRw7lUcCkZ5nkiegi7oArfxyNBjOazwQe'
    'Bj8CBsQfkPhdHx9AOt9g1lnrZdKkWVFzg5/o4uATOctC0TXeIbIO9A+tCdI6Al8ouyGBvvNIxPqHkH+yzI8hw5raiyCUU4uOnWr7'
    '3yHBxCHJVLAKIVJP/fBDcpS58ODES+s5whNkMimZPkG5MO2qMB11shzhyEk58kTKkaercnQKkuXIYR4pR+O7YznylIBxGQEcRj9S'
    'pUDTlQRBSxOZUyQ4gwoO5GQJaA9KUynPFG0g1H4GZkMlNJLM2EHV9Y8IiEBI6YzlUnXCPADVx4bISQKt2jwR4ZMysKHOBNAuMBIk'
    'TD1Jjo+iVMKQI3GO6G8oA98hw+PuApuw0KHmDlsCigxCDvG4K3ofNejIxSYHVxAPyQi/QSRgbMwTQaIBxkK50gOc7lw14kncUMhW'
    'ldwFmi5oQKHoNtRl4db8Jd46lBjdo3tX+iFBoiJeO4IkWgHwuChO7VHG03WJiqsMka5iUlFHIUxNZ/cZhIE9QXZIsC5vd0jTsnvY'
    '1VEtlxY26hGqlLHG/H/7yxfmY1X8uPr6G//tr3kth4qGtEwQIgr+aVrky049ISFF9uiG6sLIMpnwJJlm1lCkpX1NQzlSV4i53xA7'
    'DSYPJgOK/ATyNDx9byYwunmDxqF+mNVA/ZRoDU8eP6fe1mzmKCnPJDPLIbtEOqREsmbUWo4ABuEJPMIi4CSGqcAFUEEU1gfqPmaI'
    'PEpfTpn7sM6Ie8BO/UKXBDKFPYkyhVIqLAOUJS8Z0g55TNHCsJBmjogjZAaISAKZLpLtQ6QM/AJz92/RS05XzbW/+Uqb+naZeagT'
    'UQKp8XNU9edk1eFDxO1cipo5osaEjsQw9gYQwzwE7dDcn1NRYrKm+HiOtI3aCCyRSCVpiW5HK4Oevml/JctCPI7QEKaGn5PthGHJ'
    'k41ESTctvDMUPI4lGyt+lskvbhpdNOx0T/Q3ORDPTSXOfp/6CIwyn4D1L3e2puuUXB0JFdN1DQZJaBNA1N3XC9aGSlDIoVSCiDs4'
    'KPKUrDCmm7AJCCEkIduvK8Jo7qQefCDV4MPV3BhrHFz+v12cTf8tn7bN9T/Q5fQ/1trqHwdVsjOR8+kv4scz4Ihs/vPXbIwhSDU5'
    '3PvhROHrAfhJJvG+wfdMvOFk0jSqm6AcbouwivvU4SGu4j61ebiUDyGYdj3WHn8hn9H7/9cMrXVMlydOp8W+vYUjesR9tcXJViPp'
    'WFmYIUpKIg8i4n9OsBEmsjpqEr+FWzdEkYD8gCJjlnBfYgNhLfhDCxIiALv4K9b9iZ6rIGtCfOdHR05GgB1AAZXqgETEEh91oFZ6'
    'lAUVNijiri2kywQ8URslImtjfyL6oFAmVj2QimkjacA4VEsbKkKAfhqah/LaRTi7OllMgZSxITSSqKrIQZ3l+blrgmEmKAXlCNJk'
    'nDekwlOvFLe4sMrXcEJJbSjD2GQ5aP8+wVtE7T7RL2T67K8Rur/gd1yQ6CsSFWwstxG9tI29iKuMVdcRVgxR4aeUQiwKU3SZP6Uk'
    'VxV3n0KoStHqREWB6i7gFsso740958F0pk0iRMSNJ0h3Ei1TzdWFT6VaBpEAgeeT1Ywl5VvaS/CTIR7TH1nC+CfBMewJCscU9UEb'
    '2RT7FhR/SxDIf5EyNgLueDvtLszPG2ZDf4/ZAAaKFqMy/v803/G9TnkOMm6dKBe+XqX4Fnmnn8jKYNr7nAg95/gcsRN6Lky45ifC'
    '5Jyr2rooq+n837xsfg3IPHWXyUEuIw1wApRKTcP8shzgT2Q9aDtk7Ffrg916CLsHq2U9kP6RVU+KO1T+Q45Dv3Acv0VLFKZdhEDM'
    'TDuPuejT9UeCHWP6SrJhSnTCQPPerjiAZOsKPv8UNt+AL5mBa/C9MLZUlI0XAIAlTLlegVDm/edWgGMSKxCKTxTocB5u5Ol4kuhu'
    'CoXmeLjILaIIEIrQLAyPTkkWn7+jSCUSvyM0djn58XLRM0GB9CQpzEXPg7wc/r79Gp4QeQSRXcifiKZohPe7vCTOkcLC9DQJpHEi'
    'fSLbER8s3eH5EP5aq1WSDfFyWAhhjD6lEqdRYa2XMykvFz3H8BSyr/cXpBSqF4jq7aKdwdNeTQltDHIx9op0JSLhgOjJ1DU+jrPH'
    'epWdpnhxbVAQYAAYJx8FiTf4GpBHVEzzRpZFSMi7WD064SXWkUCrH4CWxmgbBcsr0hrXSdDt79X5rmxw6Q+xtvknyn5+UxY7djl0'
    'vJoD2iUkYK6fTov3KYke94kht//LLykxhzj1YyotXdIkTMskVDAwEYNV2kSyFqoF4y5GVD2DXU/1E/JbtO2ICjBUKscXRlIirRnt'
    'O4jaH1AgOcYnR/JaaPjzjnqZXsyJbH5gT8VmP+F0wDaIJwOPqJPyTxoSCHirKOCRiUtnvjCwBZTEaBXV9jd0tOSwGwX5T38w8N/e'
    'Dl3JZmHUsW7ySuPrBZIP60do2W8hCkQG8HOKbIILA6XRhjWQsfGCFeVF4T2bzSTprowEF/dBGnJ90b4CecXsduBt0jKuZLwSkIw9'
    'CXeZuX7RViucqxgwLgMmyE+UvLQIsAEf/y2V5lI/0uRh61KlArJCmAjzmsgCxRTUfX+6nDkTKSxUksRNUiyrmWnp/oJx4eseARCg'
    'pifKXgoPtv7jf/8/Q/sHaq5ObYLoN7QCpSdxQG3Ciy8unvHgLbETwJqMKiR6LyiTS+xXFCzz8PMPbbgB3gx+RCUfikriXluLvuXm'
    'gNz4qCVDjuKSCu26j2uqqYhUGlBTB8gd0jIcm3+hVdjDv9ELaYRmwWioPRvQrptM44228v9GSdt//G//L+R8myeq42IxtUu0S0f2'
    'y6VDaR+JoU8m9JEKRJqMhxuRpYpnuyCSJq3Cw5NFG8TMT2gx54u78LyHKv+iDF7gEpmFHLwBhYxnF+v/TI3NoUu//oTWYuSs7PMH'
    'Tf6QEl1N/EhNQD5/QOLx4eefcCnJPcAPf9E+/vU3LPvtQ/7nn/JQ9udfP313Yw9AVejkXPgHPCSFruBzIgcez1EcKfuoPItN2mQA'
    'DF+t6Sq+pe8i+7XcWvWfgUWEcaTvOOUyu0TzWyfmapRuETzMEBZi5RHTv9TqgIZRyF0fiQlfyj6h9R1hLmh+Ns7Plml+PsrPVsL8'
    'LGVGaK6w1lKcq0hzVXBTwVo+b1ANLKNRjUfNiz54FH1+IF0m4iCxzSSolZg80tP30Pgm1NBeNDmRpXkutJuSX1TVDg126Lc4Iami'
    'xx50EAVR1v7K0ufTu5Y+b8VOQrki0YDqPN6g2qjiL9E3ZKnT76TCVmUSEtI/KZT2QSiMBVKiZsKEeHYQX9OxEAHSpMg1IV+GKgCk'
    'dApMk0qEf5T1iQQPPGAqXB5UneOFOTKjEeULyQOCGlV8w64kZ9sBSv8Hk16SRIk9uS6f3q7Lf2ZuP8dz+55sJEGNtHpC/+8JbYjp'
    '48fwUUrM9KUzX5CN+JqUG958g1UCUVfJRPLGn3b7+8RShxX86Uhw2XEcJu192M+QnPeB7wkX/D3CLhGgkG4Je8jzy+8P8/rD9Rgv'
    'nBC1Po3O1C1ihgIriCbWh1t2M8FsZigsmaEtNnJOidONxFr9Aa9GeSHz9wf+h6wcXZ+95mkSEdve4TsJF/t9uFVQdWPecpQr7ThW'
    'dUQXZF0TjFom6naiOLJtmdDgkDJx8RYmE/qMd82JjY1IDBYIXWO5lHUn4xfYTESthtvsMq/ptxOLxo50Pd6dXVLZI7ZA5jcWYJEs'
    'RCwysDYx++SLJofnDLBR3BwexOSO5PGI+yXik/IpLiGjApd+y2th5uT7G16MAtWMnoxFA/DQuEi+zIuBhvuYhstGRdXErIQWHrj/'
    'yARFZCBhvoRtuCqwQmj0FRrDKZobYi2sOQQj29IIOUIbOZBnTQqwKKoqCmK2xLp4Pmq7UTrBW0suVqafMokZ9w6wkd6ZcfsGQEP1'
    'HRXriKIwOjJNLtlF5bCmyD4q/zuLZl8WzcZF+5jMYpMsa8xikyxryJJYyURW8ugBjytmQiZXtoCzzmQuIrF0Gh8oAr9w44nBi9h4'
    '4l2KORPpNAgPbv6T8h1hIMYUGPAeKLWdJFkQDHTxhHQn9O5AFBC51AyNC1Hs/4iXPVJk3e8oV0gsY5WwgjThr9DQC9ogSUScE8mF'
    'U5dY1Cs0CK+4XiOT8unWTC4BuR6KdLhM+okaO0csJqmYnD5R8Z/IQDAyKu6iriBSy1xUFb/EE/YQzXk8lajgiSfTRjWdekTBISGn'
    'XJSzpDEbWwtx3o50AWaW4NGwJNF4hV/i6d8RZEhJJq4BzhzdhXScycHTyUIulZyAo10WnWFcIyQa4RklOe0mJw8RUk/gWkByZ5WM'
    'jPQYcO6l92SuopnIQa01Ud6k07v7lBaKhLv4aFD7hOYhSVmWVv0IuB9KyirdogkqbieoOG5QkgtJIu1AjvbAUK/nKKJDmeuuU6j9'
    '9h01gfAsvNoVIzyAGXW1Qmy0V0OrELTvjMgrTI2r4an9QTOTNpmEgYGluPDNkc1zYgKxumv8Q4CO6GzSxNwL7boitgiNcWQqbFwA'
    'MFYBAulVovO29FtuBphW+PiJ8pFPhBfwY27hDr03HO9jJpIwiXhcGZpNEi0ioX3khJXc6V0HuuiS8V9XRLxa0GboHKSRW2ciEZBq'
    'XbBuysHewxDDTxFnGzGs5HuG2kSTjxFvQ2IaE86VtoMG2gEAwylptQmCrUptexGacaY/4ZUPGnqaNOWGPLSrfqQMcYRwsHZRCj1F'
    'XJaGolGYZBS4YJa/Ty5UzJtdGKWYS4M1ZBNa6agSDivBJf0llSaV/wxJ+AxYlcsA/aap5OUhRdTORKK4nJio7jViFwHg0hKUALT+'
    'I4rlSXY7ofX7JZY70VglkgqxujRbghUpZqh8mDjYJh9BuCxmsGo2Ehyvy6AISVKq96lKqO4P7ea8iA7S6qQcpISshm0d0mwOK6GH'
    '5xRcE0R1dYgP9ZNHDCATE2uKOJ3ouOFDkXxIsKVImaCSh3C2aUFMurRxc8yOfUhfhGtyZo9aa3KGn+xa8lQ9UYghWnRyPp+Q0smh'
    'I/aAnthjhfTIPlEjmvfA3OSxf17ykCFFTAllWBkPVwfwKLFgeEh9/31k4HAfWd9jbwAoRE8l4/So5tyHnfBwDQcIm3QNYQlzuIbe'
    '4SZLaLVCcnE5WFkuPJvA9Q+nDXXHxIgB8vOph+uVto+w0rsQPN4pUHpT4EQKUM3+xaCVKGJu+DW8eRZiUZwrVMcArSEKgl//+ls3'
    'svKAGQ+fyKTffcNvq8O3FPn1vkEX//ob3g389uun5PHUDLdXN3dZU45H0IlSEDS4AqaQY6EfMS9Zu24O556k4J2aL1coG09AKGJI'
    'LHt4EpOK7TG+Dw2Nfkl9+QoNYKEJqo/CZCiOBkjYx2Qtm+tt1qXbjM1xleS52CE0OPBC3S80kjyDo5+Qw9ARq5BJDWefdIEAOjkd'
    'i4wLHyhpIcrlA728pW2Ilvm7hJnJRS2NI33HfIPU27v7msonDskiO5DQBgT4BNJEYpSRtcmPKQ+/bt77ugm/Xk4f1yIiT6jrhx9u'
    'J6MSDSjUL2ONGlJzLJO9zv0jTHo09rhfsqrp6XgIPm5W+P8CSDDObu6drYCgVCT6pS7dNrDXUti6vKFpuDO4aFIv9aG5aVjf93F9'
    'mUt/sBfQAbbEZEIWYIRzAzwuuU0gA0MeX0Sivpu88LYiEadQJYtAlzYszw85L3ohyEPeUNRD8CXmJYgiCdWmDeGRIL3EEbJMwJZo'
    'eshTRn6iqMqXtKElrBp6gGOSxp6hwHChyT0YINCN0+YPABqmDkTh+8vJw0eaAhMarWmGCDKweT6mcMdkyOeHC/ReVf3uXL9Jjay7'
    'rk0SRriUZMwjkIsCL/0bRYgPUeH7lELQC6w62UJ4wE54rM84SOgk7frH1Ag+uBa5ApkeoQAJyOZH8oVk/zEEE9p/khTyhqQQscO6'
    'hY4L5AKCoKoBWjWRMh1g57FsJpPJJKySJuLaC62E/+Ljs0YXOzSg8jSfQgWaLKMRhObjuTjlLekNr2jlc7GO85TyZFFPXOSPOXEK'
    'hfTqjr9BHYsTiK4fgivVQhDrO+AZJW29jn2HeSm81hkmYT8vMER6/Zn8hIoWauZLky4n/0gc/Qsfg5PGsvfvYFsmVy6SrYtLhWRP'
    'VK4xkh8iZbb0lmjxwJv89Tf/92iSvAGowov02EWCov3Q7t8nZnOXNXyDte/+cger6kdIG56xY98ysZKDDDcE8p/DFmI7NWyXHv2R'
    'u67RDVgJz7B/zUKPE4U/XhX+9uuf9ezPyr/p8vV8zAh+xP6B0B7AYqW9wLhPyVTXEaBTFBkJCBNrx3DtYEVpobhRNhNxpMllYoAr'
    '+pQElmbc3DWuuV5bvkSo4j2WaBBKc1UGNqL8bkkmVyplkrgnWYycE6Syn6NKs6Q/n0Ji8Of4n87WhbiguHBFhwibS8kQywNkpFTk'
    'qN+tJnO5gHNVxS3iu6aJB8qNcFB6c/VhQz4USlfm2bvfQeubk235aURTFI/3iLR0CPdb+rSJ0wi6vDAotL87AG+W6LHf9G33bsd2'
    'mcsxTNLK/GOa0OWr1cjcKF7JVbBueCsbfgCvIz9woBgeOQP8NdYLYugNH0/U4jv7hxwHJWn+5uHtJ8qcE7AJl4rgLQKJTfJ3EbXw'
    'tvdkQr+Fmt8GIFjlRFxlEf6TOjoBptjWjnhrkuxkaooanYij461rlI2ILZODCTVBRMeDOsoqRPcvEtqQmMX1yVVowtomWP3QlOEr'
    'Sjd+fCT9BplECC7102dSxc2plS26YsTP5Dwb6FH67m/UsjI+1AlNciMru0RpMhVQGmsJS+dT2XwmYdQcy/ikll/oTxbZZfhLyj+Q'
    'n6QlMw4IOk4MQ2jb/qfLYVNsYRqxIgk7jITBcSoqm6w9PPIgXFOM2qn2gjRKyiduP4UXM0k/8aAiMuy9LOkDPZcEYhtfto1sSpKt'
    'fIzOwxK90N62fSGvWgZVeR8/XkpdDfIq46dUwmo6/KLF0/AtYez9dqK+XbYmmq3EinLVkyMHNd7FKuLLDz/9/OErWkXIIZ29++EO'
    'JMgfRMP+hJZuP5E33ScvP5OXNX35QF7QUfGnu9S3L/LXTKwQdteokCH3bn6OZSK84Ahw5akt00fTzHBcaBUIuDg+KvuyT/0M08jf'
    'p8hDJfVDiiuV8I08fCV2MYlboEes6x7ZA5/4tkhuKTycgL5gDmhFCt/CfLDPUOyJddSUSolftK9Ey4S/H1P4SnRNyROKX7GWv/62'
    'SjOZb/f4y4a/XOZb5tcQuTwCj4aX1ZE/0gHMYpcFKHZQUxCiiABitNb21yYiAD2qvkLVIVEpooICncOpegKb0IRw8JcLsF+gQVhN'
    '6Wti6ISP2uNA94j/SqUEwTeOSeIXFkZDTTNO18xEOrEwhEJZyJGhWFpB9s/AkxzDjCTFDRWSPZFoAxW0QlWQXrHxWRAIKsiB64Qx'
    'ueIIFCVDymPXgOK6qDNMr6k5VT6FX/+NKGHC72v8jkpBl34mrP1DKu3i0VKcVEyowjjcCNCzH2l/mBxXIksMo8NPOq4/MLkl+Kbf'
    'KBpxD70zCC4cBcjgMCH0utmPNxmB0v4boeZchjyQEjDR2CK+yRFhDa3CXWC+1/C/xOJafvki36OnGgbowxf4lcNHhjwew0f8EGZg'
    'wkeZPB6/fv2SphL7SrcsN70hs4gcI0+evibgm3LSyQ5cICixVWLoYO+v2M49AgeZDAS1nG+F989hl+eAvx3jtdY0TNMdA2Qphx6e'
    '03d30WlsnZ6nES+MKJ+Hhh7kmN+wLMC8xF0JOS+NDUHuw3NYJRWeqP7+YXUOBTB6RZNsNUW1iYqA3OsMvTEoGnpnl9XIzAtAhdb/'
    'cH0UgFJUZNQV+NTKxAtPAEJv0NjSKvbUfbObURFASsCEbNS4UI76Ob+Pzw+pPw8iUoqksGb6CRM00SADiuaFCIfEOUV4icIQfWCE'
    'qAkgSTdU1c+RQ48+SK0a9SqvUnsZZAaId5fI+RJMpAejV9MZatoUFaOmTdjoWHWowWV8WEGWBw2MYR5PIAZrTqCmRNm1vNiZaVh7'
    'OONoLYd2iIEhmaKGxzKWlUmclkGbk2vF6Cphj3RlnxHdK8S0y10M+BB2/AupzLLDA4wI6Xy/QqXVKufinoUfhl74j+w3wnOJ5BH1'
    'O5CfTnDv9Ph7lZOPqNo70edTJqydMO+J1jKZaANM4kOk6AiOKo8iH2vhGZGJ64bX3oneCHYHuu0i3vxC03Z0YAQbaBNIuZuJJGO/'
    'WLl8r3nNQEonrAIyf2LIcrEy2EB9kdHMhTOMlisuda1vjy9+hiQsTEAydjGT0czdwHzLRLxH3uJmAJFXq4B2XEBAIGdWyvC8Js8s'
    'ixoLCfkznhxd/IXl2TIrEW35X1bk392n0DgwdDIcO7izqRLHgI0ppzMpURFt34txU4QB0tTJkeh+lHS8xPzBBWz1IfpKHSNRX7ia'
    'SXzhpgxLUWOj2kmz1qtF3k1IPjy2ktaJ/iEnYaN/vUQKTBO+c0qBLVTuiG8x8l7iC6p0R31+YYIiqWVSAJcMPV/lWI7eMcCvvFTm'
    'Kkx4V0F+oLygjI4Z8LJTGp/QAIwoHJDjgoRcuQIzm2MqSB/vL11CUzdVtcNSyRIkF0P+gfBMLjvgNFyGyRbZEltJDpNdcRxXvgxT'
    'LaoltXoZJq+KlZWaGCarFkReTQ6zWLoMU6yIK0m8HSaBzQumQOCQV0pBZRA4/mQSeKTnOTaagxCo/mQOopnCOQg9qom2PUEIS5ra'
    'Rg+hsW0Or696gLh9mhF1ETh/5D4LfYAxEsihbhqfqe7ZJYrYpG8+pFyUsqBDItGNTUoOkcs7eCWf8XIQ8bIX3xFI6HZTyHrB0Na/'
    'p+hfv6N5Sa8TR0ss8mnlTHQ8hggVDzIIU7nOaagO4ThSEVVzkGE1AQcCwUyl0W1fhmDBwCca9MT4RNlHaTwc5j29HYqOBkPdP/Hr'
    'RxU5F6/fWHvaVNfUUutzqJjPhOSYSPR4kKAeRbS2igkq9IBQNshyVt2k2VvY/IuGVvGEOTslSRjaUqGXP2rEADBzTN4fQOpB793j'
    'RaFL+omkn2Kt5vp95VRkFpegSFB/HvNHeiSol7xHOqSkhpCuxQHXYZO5ZkzdWx3/GupyiJU4teaKtFaAqh3sukLtvaJDCfeWkNLe'
    'xXTUQeY1kyCszgkTLspN6NpVZueUIcrPj1g1NWsMJE1OPf33/++swQ4IvUuKXuoLcalyT1QPrqWjfWn0CCAHfODXCNCTpgfRHk4T'
    'R41i7kjkQ0LeRbRuI5v/hF9O9MuJfDmRL0SbezEzVc+PfnoYS2wXMZUcPw+/IE8//MJ+vSfiiHT5wJIPXPhBvnzgyIcC+ZCYWfKV'
    '/ImGcE/TJCIw4KufuTp/JuqeJ/X8X9u9ixnQTefUKOnSQSNKQouym/F9+UJ7AxXAVwMlHYPkkml7X79eVB9eIMG4cDlxaKizplg8'
    'HvHV0JkMHSDhABFl+cik+ZRlix7RXgXap3ZosmiaF6ElNEjbR+IDMkTkwTqI6JPfJ0av9yH+WEXMXnj3/GdUCKRJdBpXXQH2UJIW'
    'aQTRoCwFHV3R27B4C/Yi/mM0gLDBWDEYqa9YciXqc6pYCe9CJU/u4m5m0XkGcqXwghCswbChRKxcXqUTQJwh/b1oB4l20UJFD/QD'
    'PZUSVV90ZzPqzI6KCzucYOjLjvQl0keQW81pqCQLxSnquW3XIGaAtGXSBCSEqnzSOHmNlIohvGy0pI+EcJr8G4WZb8XKG+QZkJC4'
    'cuwPEUMPUTkQwylYB3SbCwSCyFhAMX+FpF9T//3/oG5mqZYw7WlrE9377ELbK0JQEvjAOhD/uOE+gNcrYzlEqjGiCQlBjF5wP8dK'
    'mgjDY6ZMaDpvkUtqoQ3t2kyT2n+8QaJIUsIPOrpmLnJMUjsUuadNU7QnIb6jB7SEemAPfsSGCAJMUwwoIeqjuJ6QnDgTNZiKNrB4'
    'H6MAAGIOMhYSOCqRJH29WhUk+dR3r67t1IREHl37Fc3U+CPdgUR2D/2qEweirkt0bZedSjQFsTk2YQE8lOOJkOxRUTiyDMezWBS2'
    'QmekZorcEMaYEpHtdix8EWsDDZEYAH2Ueh+JEtjMJa4IdaVJrWdyqVboXN0NTPQgvNFIU29CTEUKEjIj0ekEUeoqqfSveOnM/PUB'
    '2wl7Fo/YyNyTa2muFuocx4lAVOh0lfBKYYAsAH80nSSM4SpwSR6ijAifUf2Mjfwq+r/iumxC5oy2hs2g3PMAwqm+grpJz1FGUqkN'
    'Lrq7gnnCo2uUBVNo0UrupyYt2ZMbhOoQ7lNErQgiHt0tiB7olwQewb3zHq0W/U9JECTQbRxjAv7tOkmiSdLXpGWNcSJ1v6X279VN'
    'di7UZFzqlq6SKHjH4yUusdHpdtq+T0Umt+R0a0e2Ox4QhacDxAPbS63+OO1OxsRRxC3ZJs3ZYXN2OJYo3QzTTZqOhixJRjMxaz9f'
    'JUcDvqAJ6tzVu7Xd/Z3b91++iJpBo1qlbxAg8n102OQ8A3WcXwnCfoBSV5CAvc2EOtCrD9+HXwpfv94cjUnUROMLk8PrgB/pD5Mr'
    'kOcCPpbIYwkfK+Sx8jUTDY4es/x+1xGJ3nSej1jWBJJlGervhVyuQp1f5DDbk9Ga/XPscvrWScgQeVXP/0r90pIuJc/0NvTMkLkn'
    '+ysyTbvhADh6KbrAXDEA0SqiFi+msUj2C2zminaHi016QKDyUsMbmcaKlGuXo714KhwCWRZC1k8JeYEl9juJXCeS60Rzba5yJUUr'
    '4KUcBGWHZq3Q24a+hzfObnzYRL+AsmgcL48GOLpc/0FTIl20qe0OTCUQcYy+R5k105IsQLOeGobpeLjyMERvc+au5pTexaoRNzvJ'
    'PtvXfeaRZN+Ii1ffk6ep318qhZkgeIHeBfBjBT3On09m2aGzzBav5tYncxtWzqLNM0INTFiCRwp5Z+TlCXARq2gGVoAA2I+pIj4j'
    'SF54Q8j8EwVkXIMIoj35UwTqw4udQYgn8UNI3tP1BK0M3eVEd3Bj34BIkXKZ1GNIfOnpPKFxkTY9IpIxuQ718qqyVgEda0Zkj08I'
    'UVw6VLPGKgRgIhWdUGqqKSHXwgj3R0MEiKHLKctUIxt+QotJZDgKUgSjhnBFnUESo3vK6McDJXb+eN2HdvQ+9J2tJjT8WA/hB7Ro'
    'MO7FvJGcaMScESHbidMSZGBD00fRx2Y8YBQBW6nhzfPwACFFqDNha2DoAR6phNdmCD1KycRnVlq8Wh+V6PcvQ0lythc8ObzCikkC'
    '5dN9QQ65Q6efRIlhKnfECdFNOnGDirSfnCC9U5A6TP3dorGqnzaM5/RhXbG6ZJg4JbQpkcWLpvehNISK6O/eQXaQJboMEVlxQxKa'
    'tgLfg5ne09GEWrKr8wNEhh9jnUuIfWNDG6DZ1CEf9gaxA7aLmxybid6y5I26a8SUU+iVKGnjhexLOIu/0IESZoNelXjLMfgSKYCT'
    'FmVHz9Fx9itGIrS/jdR0MQiFUT5CTbiInCYB8Bigwu0Lq09dniPkotdVekcnF9NMU7m+cojSPkFnqGxAsYgkHKOE2+uHiezMbXbm'
    'a3gV8W0r8VVE/JS8jUjeE7wQGsZfF/Upy+QTmc2nK+aLYUu0UBDxZJdqsZpsKmzt9JC6dCDxBVdn/37Zj79b9mNUNlyq6AIs2dFh'
    'hLzUryAT/Xoxmo78z/ipX4HTj/SdEVq9GJviW7xpfBIGJLFtYvUAE+oG0snt8wsAP+wgctUge/tpQ4Rahsm8w9Ywt2xNQnq90SQk'
    'aSztI1kO6GYOLQZRm0IWCxPQFt3IEEetv4SKBYB4qnCIWIrk3ryuaqORqb+uDgrf7kb1ejfiBOJm9CP54eM+3F3wANuL+COBb2py'
    'T5JCGFcJBhSQHNL1hZuEjkClAKgSuUSloKmKVGQvJC8mEEb4HTCPBBw16qFKxaw9GfaO9FWl0tGeDHoXCz5h20EyJ+1BcMmpSgnV'
    '3ZWIQwPRuKqKeIfc8HpIxU5Cw4gukRNtYiP3EDvIxorpMdClZOyN+8+KXjzxEPfTf68/Pk8GI9obIPUPxKj1PvSQTCLBEGfcGEiG'
    'v5QNTBI2KDy3SJxp6tcLRL8jtH+6Ai+iSiFzRjQvGGDhW+iYBueEbt/QnTXGekACTq4EUwUjCvzKQ0IXEbqJilQlv6cSSZocYXDL'
    'i8xDaXnkz+ifEfwSKh8JrZsSKh+adFH54GW2pHj1z4ulyYP0m4kJsZh5F9+5h4kybyYloT5CzVF0JkZUR9daXpwoqsqJ5gqkil2I'
    'SvEicKjKGf+BMieVJvH2VqlfTe/XP1DNYDu32hnLjOJ+0LP5a8VKuL6k9EPycIw6svEwMpRK/KsSdhF5TGtFXIr7RCNDF5Fav+ia'
    'IVEVTcw4u7R5SV2RW9jQAWotcn/lMFUOqJ8hDEgQrDdhiBFoZLC6KMrDVsgBG0y5e3/tNymE3ytJi5iSkEhCMHMeYHOQRn8NL7JE'
    '6jCyNERReGUrE1sC3Xr/oOAGA0AvM2GdROHyBw4U7v+TapbYxu3PtkvmPT3pn22aC9L/Tytz7sNp/px6q2aJ9BVkcSL3sTfqiYtm'
    'jmgovnzBkkSnghqa76/eopdK8oW7yle5euO+fr0+rcAoXqE9EU4bGS3w8yI1NIFmANvQ8Tz8ngIx4S6VbkwUVIh/IeSEb33hELkh'
    'hAkqbL8SR2XEbQop+oocceZakkiFU/bLL59pQkLwpV/Q5gj7GeIs6gP5grWo95Hoig/2TopdJGsg+T1ednW4Kenmxv0L8K654S4m'
    'bUSGYcQmLVLg0q9+KnZpYry/L7x0pG9KWqujX6qeaGOYM+k0jN0LR6nveVTCashshj5HcK6jsrgl4r0FAJDL5eJP68QnQh5REWp+'
    'feO5n/if2HkECqPC18ATOqz6/7l7t+Y4rixd7F2/IsXRMSqJQhEAL60uEERQlNTSaYqiRc7otNGYRtYFQAp1Y2WBQA0bEfPoBz85'
    'Tth+tiPmwU/+Df4p/Uu8vm+tfcvMAilNj+04PTEiKnPnvu+11/VbJZhjpQ9MTsgSl1Ud8zG6mQuHaNKl9pc4J1660CKDUGTgi+QN'
    'P3vOxGWkrn7t8aISKsTu5WRbbW4wutfAUyKgB3WSr/OGVsU8v+HMNKfdyrZBdAkuMjsKc3g66m6E5/9R1nmrzoOTjAK13JEy99gs'
    'iU6sF/nn1Y9Bm5PDQp0crikOO5Uf8mBe8MmFfxKI2IIqzT/GvJILkmhFezzM9h/VRICg0/yj6jT3H+UHbdpI4tQ8yyiB1FSQXOVn'
    '2UUUlvAuj1AqFR0ydPs57J+rStalm31lf//3sIoPr4NLgUZvpaaJzjAYE3ZqpgV550puMOxmz1uQLlHkFy3yixT5yhf5pW4Axj32'
    '/LiEF8iJ3l7y60Rt+V8d/2LPR/rrJFBFGVUY0v0s/Byp6IRIMHk2pJ2+cEX054BFPM10mQqijWyZIm0rjytTIry2kEy/l8HwGnOX'
    'g9sKzNY6S9gtUqCj2COjQfuj3XuzG3vBq4LAaQxkRW/2Yuf5xut182unb8CFu25+HV67O1fPQMuNO3fEtFUjFanfGSDLe3FBLbP6'
    'YhL1+7wdvC49o0/qR/RJVC8lv2tZxRsGfc+5SZEX4WZPf0MMvJD36133eydDjM56r942RoqL8vlyWawJ8N35YHZ05GYGT9X5i0PX'
    'Se0U+/ldaoF9OxCKl3b+/eyr+U1HWuP25r8wK8jf1nv9Y1v/YH+7biD5r9qrirZi6i35Yww/7CChDcFRVzFrDJQamcle72YPu6fX'
    'W+8JOX4xKReLMS2lmncT3A7CkKXRmAr7sRUaEwC3f9bT5WzX/AqGNb8CT3vczlvtqqJmtefA/5Jrtpu9M05vZ8QLEdXd0B6H3zd7'
    'Wjt+74zW7sZca4E1dz+bC6wd1mehDJyDt3uX0Aed4EbgWHBLeyebYXEQVcavV7vxOYP/z9JFfq724hO62uOrmk/ILi6W1Z4t7I+z'
    'FoEyoT/UnL/5pz9YwiaIXoGh6zjRss0twPkEUE2vwoE6EDBQ/BRC5SledJ2toVMXXKEzNW2rgdTFxA+ZMr8hli8sBSLNz2bq9Wgo'
    'dqu5t3CoD4QFEFwQOyj1bYgcI0wapbOoZpViruXIg4LmDedySi1CmBI6VkKms+/7xrgyKgMioYGghmB6xw4jtVaRoN6BKXrptNlq'
    'cLC8DAoW04XlNGFjP+hE+jzFujjOJqtWTjO6X5Wh2AVVOVvqiaypsEOq4/HkhaUXOGR7kVQGbgQq2PuJJumY5gqqneDR9v+BWeS3'
    'eAw4OvE6QpG4zMnJ6ixKg5ucGZwTAw8bT2LyWY0TPj6JI9RlmzzXUV6irBu3/Bn4zKOGT3KXH36VfIh5dp/NNn2mMCr86Ch7CCic'
    'qC+7zK+EDh0lvnnvcEdttPfuoFKGZe3lKRIL6ZF29CMVzloq3OsqitaeRzxQd0WQwd5uiGbZ2ooysbvTtJpfIdDKAcQj77KcJlvj'
    'F9AL0IsycqGMM6wRAuIJeQHEuX/pTV8PRRZ3T/fM4PBazbWx/1RnVS5ol0VE0B/zSMk2oWOQXZ5E2JiRuhCnE75YJMRQYbG2HeUY'
    'tCFajM2CIQ1ARbsKaicRmgMOp9mEVf4uF4g4A+EmwYt8yTRfNS2k2kS1Uqg1H0XM/q3nV+aDPqG7gBO9zWgNRCchqJfja8Dv++PH'
    'MYuE8EcNZ503DI6YpEiegfopEXD8jpG/lzXhdal2p5Jne6kWqdIEWCyBazM1OkJp3eFH6kvAZHX284/HMrX3s4dkelmX+hS4Muuk'
    'jLK0kZjkfPEPufjBVHTMX2pRsZa8TQVbJbKm0Oy57vvW/AuU2w6fYStado3N9W5/Yr07tXpP2sxoevcVkd2syCq5cHFTz8Y1XKBw'
    'DLC9Vleyaeu3Xda5vijdnvMOkJphAqLlhaVwLu16RhasBRjFkQPgqSY+pbNvTj0qwlFDzwlf9JklYZoo7Axa9BqC0KmwdfnyxzNv'
    '+RtTR93cwMsxyrw4hn4au6LGtSPwUhl3/gVfZff39iHiZpsoBHwZ0coXRiujna8CvjRt9NJ+cOfj86i7fZqfI18b26Tme/xCzxxn'
    'jD/0xPQY09hp0GhORaDSz4QEPo4kiNjZxp5Z615NzDsqj8nvC43s1fnGLUCin4cPzKEh/cSVd7dON8Fmk22uLMcLddQvF46VeEEf'
    'e9nv+t4PfE9d9eSFK+lf7bq6FaF1EXbWL1eM66P4QvbRb0TjNzX/qdPxL+b07g3CEU7jx+blo9tAxxp2gv32ZFDxjR5/6rx+Snv8'
    'MmlRnzTbbFkbTPvpD198eEHlAmAG+Nf6NnuBP/f8wz0+xF/7/tm+f/bQPwMpjhGXYAX1SBOasVdDy2gclaN1ittX1mIHj4Cruz68'
    '98UH3OgPe/uoHX/u9x7d3jvN+s16NNHxhnrAltRr2Io5UuyQ75S78LeEU56dPl1AFTk6vCfzQ5KOEZJm32Yv7dHdt4f/4O7LY3N1'
    '259WXXpn3P4P9xjOjXkc3t6zeUl/7VAcOLy35x9gZhEsf3iPkt29B8/iVWRSpnc6LcNyOUT2+RtUKdtQKh2u9e+1/L1067fX22d0'
    '7Je3UX8gutyy8ihjNEIhVG4bI+Ud4KuqIOgVq1UB0PPgO3XdtqP8Trg2LCQgxVgr8lJzUmvsq2Oo5NKEed8kOYtrR6Zivf/kfi0d'
    '6plxqqog9lLZUbRLvvgw8gOFqT+eeCe0NeYfM7Wd/f42WYZhsXCrIBJeMSxXMr29h5g1v4HREbm0Pq354Ya2q+uNDUt1co5ubRdY'
    'a84hxJ+bjtI3R8NNGs71oEKikYm3Mnm968EpJanujcbQOdq/sUojmK5SUNGrMv8187ISMbBSi09zagJI3SNYFeAYnEs9X3wQ2fxW'
    'fTwO7wnnXs2XfXp4jpfuyDSMJBZYAr7JYCPsmiqEN5mMfHoXv9M9mIO9VR5NJYT5bMXEYmWM/WRZH+QKVhzxZqoGxjRpSkdisbs8'
    'DdZZDWlCZ79CCvMq1heZpgk6wev5kolt5stROStWwJ6/Kg8VODiCmUGqREvy7YBp4pAL4j1cld3MYo19fHKsOnkrzzVq/ZjFzPrs'
    'E9rEi+6yVuAZxO16DnBIATZFm62GQU6HB5ZHy2XxCJSi1cSOAnlrrXekdtEsKYpWkASJb875EgAWKIElOVCiomdWFHgU6joKzfcH'
    'Idl9pLmQM7Xua+qL5W6/aV9cBvvikqaE5V4/23XZgwkrEWk88bubNaApWIlPspGAXhJhBKgOumXgL6M4BtQz0snaYaA4uI8DVVIW'
    'BGHuGtMH4fke4uf1fMcYSDHyOOoImVEpCIwJRBmzAop6ImwA/NzmM6eka4gYvEQOrUhAnbBYfwv6f9tDrxiRP08yGnukkZAUxwXU'
    'AoX5bW/oc5jnd619Y4G7zLBG1Gb8vv3rFx+sIvyJXihTZq4GnBIkhj2pCz0kEeE1qkRDX3wwKJbtbVeRTmUlPHgVob21xmEeZk8s'
    'DlOLk0BXms7sTA4RCG6HqCjbKWwJnfYeAEPoAfcdr6v5Yocjw1d+2upgH/pZnt86qoz/cd3ZOLZVMflDAJNBZSVuCrfj/nEmG/Hw'
    'HtLJvZE7ePzj7B8ruTyU6wHuimd7ALzi+B7t5DO5WjHQ26cP0oZcVxKp7PRqOen8g86wzjphvrKgA4UDZmUaYYaIpHvXZYVJjfx0'
    'qdhE7AJZivwk2qjOKEER6I0SMiMb46W6sZ/Nh1fV20Khtz0WbEhh6t7ncYEYE6alqPFuF3LOedY16kG+ZRd0TmQxO74bR9nW0/OI'
    'Y9r78t4zBSyHx6/X3if+VbOuQUwmwW4wHzCdiCarhpbaEa1ulDTuiQenR+YB6CL72b5LyfpBFXv9kLvt3Fwscmj7qeXvZ6fA3djB'
    'YLB98BZiyi1dlJOBPTh3Y0mzAIfAPe4WYTR09c2PAQ9eAmc2UEAok5SY4mXgLxxXa8lhnUscjSfQ3oIXZyoL6HW8TK0oVbOZy30B'
    'bKuRRm5qSvSfyYtw4RjD6ZZzTD9DNDEeMgWIZZ/ou+bRpl/z86ifKwSTXMunUIxsRalG84DfhE0kI74qFTAx2p615KPy8yVtNC35'
    'SANbxQchgQQCvDCpk/HIRRItHbye4p2Ye5Qi/CriVXl2NiYDoBmggwciEtx4ACZ3E5aWnSPkllF1NZdSnc+EbYJXluo3FPjq3gtm'
    'UBTBgSwnsbnApT13SEEIFtceIh0n0q5EWM6sXa1LLRnrJs0k9GCCLId0za8J+Y0QCqA5deIbVC8qy9t91FvNX86vx8sXRWW8mYHM'
    'SimsHP8QzjN0TaoLP9wl9fr5y2/evv3mOEluHT5xsJr/yRW0ByfpWeI2Kakl1w0U7ZM7Bj4dK9J/2C6aQVyvea1JeL34NZWX7qX3'
    'xpi4g5pwJhp1rVbCwfxG8xxogoFZ7LyUAr6k3t2RaY1w0gRfuVDsm9uDBBPahSh6X6JFMUpTLe12g1FbnfMLdefoZgOL41cQGOe8'
    'xtyx5hAQFdwJBQlNnXP1729qaM2GLtz3igVw0dKQehpEBXdCQW0o1alPXA42jXa383k+R7Q/HbEZq+f8rbcq50Yc0hXF8X6IgAta'
    'b21I5b80mPM9g93VgM4Wu16hb/Z251ukhm3Xr6pcWV4eIH2ahvAzuypHRlKiD3HMp6Q1JaIEVNFOdb9F9a2irHp5LzulHwAs+HFo'
    'P8mLH4zlSJFtWc7Uww/KfFPFGjVUR4FAXNQQfnwSx8DNV5q8tcOr0sE6y5VSi+pJQpnx48WcD+Jo5g2cZ4AAaSj3d2k87FwSL1OT'
    'uewEjCLCV1/qroEGdfdRbA6zDq9MEOMhe2eH7B0PGfyabmNW2eUo2W2JemZCLhq46VlC2kKMQVyvcWjtIuQqfJo5H6qHtSJO6JIi'
    'zqvqYa7tuyDcYCbjRCqR8QjwIrmodWUonxpBAErrvAte/H720ODgSY4+5atHuX2hk3A/e7IbR6+viJP6OE9tI7DR+NVm2s+w8owM'
    'dvtimYI825eylBqfHSOz6DjpZYmPU3OkRgsnZsRf5oPKb9tPvQw9IrSehvN5SPQVHFO6TZ+Tmr9k4z5RX4naPRLuzIJXyqCdkffO'
    'JnJ1WGq8OS1KLjVewcB392uQyJ/ObyU4XLxi0sRXHYShJhgSrfy0BqzIY6qGyIULP3W72a3uMITbaQS6rVh09OiaBxuKTXWxUooH'
    '0/dqDGCuYFIkmOX4M0P5Ng7ZUrHj72SwSEoYOBTmtwn8hj1N2ZaT+PMJ4alMr3OUQTi1X+AgWbk+xZ949JbTkwhdJWMLPTuC2AOu'
    'ivIS8nMQftJbvdMmgGGNPi6DDVrLRNtKepMHcasmYj0WEesgFcgiQSvskU/fFCJ+CCHZ7z0OgpSG1sEn0lyowp6rCVIoSb2AClLB'
    'gapvokBg97FI5Sg4VGEhIBvc3jF0CGF37Nknbs9KCy7bB4IM6tv2CaybOij0wTcJYuO+m/ihYjqwI26TxDHBwY1KUYbjUck8F0Jg'
    'FvzN8Xh5LyVnrxnP4ARVI2h5/pGj2TbM1/5kuiGSg76tqyJaR4heYBLcbW1xdp7xqRwCs+4dskCWEwfipabz9kwQ2R/z1MZHLk2O'
    '+ZOF8/15RzcHH3wzKld+ezRSE1BxSHBTmDX3HrsbqyULTTMJTUQkjBfwSRusN91s73eYuVWSNCRJKnZ33oY8TxtKc3Ssrpnf1Hyu'
    'm2kxtrMvFRfPWLOUL5uo7gLuvVPzxCaLveYDdb1+4BInZZHq4XhianXFPnL4RC1skgpAVNGdZy0neoPl5YsP2D5H2VZKmixb3bOn'
    'cMPKqLmD2o5aO6jsghFOfojALgcFvy6gzbsJViCRPkyYUCOQM2a+7Q3OE/tqO4khuQdlkdM+bLHCbfwK4KR7vX2qMD3Ujctmgq3Q'
    'WTmH9dOnzO3ETk97YZCApscnWN9OqcDFGAJK7+C0Q42q8s09kU1kqMVstQMnUrQi8wyH3WJyj3lIds6KaTlhxdzT9hQ5o6j7rNyT'
    'a5tKOQdhtjD2Z198GFdD2ay3Tx+gC89OA0I7snxEBPZWHTfjk4p77o6D2rrf6uQX46cEvEv516waIKqezOsmxONZI1xLUQNUFQq/'
    'SPws9Gea5shpUdyfVecjuth20NYb4pBHwKd62ma9CPRUg2jAUQTAbKMCRFRnMkvddMyR4fSY1TWRj8Ntd65pONWrl3HvYGQtR6f7'
    '7iBUpRHtB2qPx51ACY/Q2p1h7nhyv4xx9Uzg2awdgLBqMtFKz3vyz1EN13df9ay5a/BtD3DIBEx+9Dht1tf/tkfU51q1e70nrhJ5'
    'xNSiaWXkzjBHVmkDEdcyRfl2tiKj8lbLVLnGwkxoBlO2jJf9uAcP87hh3frAon7LFCNqRGIecT9KvI05yeVNE043fs+hPKfhS9Ed'
    'CfxZkS7L0JYFlVF5A4jZocwYWYIfhD0yC8mMiqBRsJLMqLAZrT1ttQ2N32v9fWG/HcU4S4hr1eY8cSv/YT9vA43sw74TCL7rhieI'
    'o4T0SzcS4i/d8F1c3vw7epNYStSQf6j2XhGLqzERgtJE0wef8RNaeOIrUK1TahsARE9VwZVhNEanPtnuUrscv/SXY2QX9DdRtLVC'
    'b+I53cmehCnVH/GMgslgejQb+BFw1QBqW5/quwrWruDljUaLddxnCmK00emFd25jlfbvtfiJPckeBTOh5kNnb2Qyzlvywn0IMG/U'
    'q9t6OphQel9PHFIDmVOiIYDeD4nRazxp6uoaHUqmKDTSceiIB0nE4Dzr2ysQ8CSdIuj5XqREcStnZ7yzB/+/XZfdGLG5UkE32RaP'
    'hWfCRew+edxFftA7PpBtlMf6FSWQUV7Vtvmrd0z69NDQ+5H5yXBS5OlpaInrSdR9EeusyZZ6wvD8HEXinEujm1q84zu2tEu2dLfs'
    'Nh5Oz/9Un9TTp0Mhd68ZrCzHEz/cEY3ZzdJTnrJGdco62Skd3Xkie/HpA1d9wvqdPi2nyGVysRyfGU2YygwvwVb+pvbQyg5cpQ7v'
    '0QodjSO/Bxzjaixs0/NqISP6qViV88N7Nz+Uoz/J/2dMsBXOTRwtx9BUN30rUAjZFYm4YWjw8jSSGVwZ4ZK+KYYXnc7E8bcfGtMf'
    '+N1ZxO9Cq1havf9BbO55r8no8inJ/3mUM9u+U4lFHzuq628VufM9WzwJbLFNaR4zZ/VUlt48CNGXKWEjZfMw3tWauDISzSI2FO9A'
    'maz+KJnd0vLzkEwJ/TrXkD8zJCp2Gi2baJuu7nLtRJmDzFzrBfAalqfUY2k9e3ACdIzysT45YeqUL598Of79ky1K+r4sku24aw90'
    'Rh8HMNDo/vzig6//VO9SaQbTjunWV/lGofK0KT0O/U7zm7s4/xPn2KV/jE8dW6ifOxSMmKDou8hJNuE1ZPBBhEyEzsB7sIxyxnIH'
    'pCKjUo5wYIY3TF6JvlnLjSH9h52d1UekRJMe5nIW3LHwS6iJw+xnX/+gsObPDeTH07ATMNBDN9LtOLkYOxKlp60nPmxn9PVCi+lY'
    '/TK5WqeEj/948InmJUIV1c2e45i5kfyi8PEV6PjNfuCp4xL7vsRdTt6Yd0g3CEaUu/mpeqtAhtro/luj6vALLYC9p0bHOsvTubf9'
    '+J6LpCVEjAguRVZNYRW897f/8X++5zJxec/p+WLsAGB62VeAEl3Nz88dJ2R+TaBhOmTgVj4iPM1htg5TGXi1+kKoxkAWbht7plNd'
    'DWB5Ufeb+A6SOiER7lFLQs2+14f9rrlcxpBrVyOmvJ2AxJRjQHN3ct4GuBf39mKCMYiJxf6+Uom9vU3+/K20YL+mLopP/uAmNP4f'
    'csT39muH+3cth1uPNme75eBGip+mPNIUmvIW3uDXLtOqFCb92Qvb1rYtpWd8nMY7DIJEOzCvv73dWCVIPcPHoi56TxqLFFEC7pVH'
    'oOJGAwaBBgxwHuzdvn93V2P7m894POt3CIEULsejkogBsfRDhSX8iOBsPpivVvPpzmR8tsr7sD+cKytQrtTzvZFjQHjNId0PDIV5'
    'FnkutIlFF44ciLBw4QgBhMGd7OHGo0qDIEIFNm4DulBcFGXYCF+j740+44n5cYynbnOka5jslIuwUy4+cae0i6xtu+WqckLAP5Qc'
    'o/H/F4loflGTzXE6HXXhSf01gnPv0cYglY0hRK0b7KKoXs1X8E/Na7K0SctM11gOYeox7lO31lLDpanN6qtV15ZGqkTw9bjKOvZJ'
    'sVh0ww6TpeOFwwQV6a6apZeM7K3Zp+4ttvjJ5OVHdICftG+ecFfMsIhferaM18RutIpPolX8vd4RD//9JOh4B/kJ9pDaQI0LUAY6'
    '60LMp5A6edo08yo1Y1KYE6P0XrHwqnmUe3IVit/du8d3cCbBZhB1P7EdJOqB8CbCXenQFxx6S/wh1xH+kduIv06907AZBVgXonki'
    'BPLFYrL+p3J83YmjVmj+ow4Y/gidLz68lxIaOci/1rd5Vg2LiX91ab7ejKxBQMnz1WpZDq7kY9Uli6g23dLklV90tv5B3WrWW/nd'
    'ZaXGxbwq0VOYSebLTpqNazmG74l1XdsuZ3Ksvnv7w0ti6iNEBwZ3VhWNFT+r9Wz4dj6fDIpleMAj/bqYuTgcxhmgx1i/H8azK+my'
    'cog5y7+0x1p6tVzDIjyXqXkjvRUCgPF9vxpPO2/e/vjTN93sP7/58VWvYqrf8mwNZ5vctONDJqD9YCCK8vX452I5I0uYRT8JfQFY'
    'n9W8qFadLRkBYvtI6K9W86p4P/b0BsjyQvj/9q//NQOlfYN3Ug4yL8EhirPxFjHabrEnHtzPdvz/hA1Go+v40f0HUY6t+XRarjpq'
    'M5iV1cXzWTmVSYA30PwN9IRqUm8fLy9oXzCkpH+8m0cVVBfl2arDzKX2yLzBEcn1dblcrTt5kmkVjosyUZ1fqvms2TMYFV4ror8S'
    'bphnnLlSfaIB0Iu/iVEsnKB2n/nYtVLre835+nN1tc6V3SDirdSOCGQEpCW9dTs26TeGzKmsxmMhCPi5ZS19Xp8mF2oTzcpdM+2m'
    'JFqW+aKT1+fN2meLod56i5+0tq7FqHu+xdoeM2YMl9qyUL/7dLvxOr13cTW4pyiLlffVNz/zvjmMh1TWTLwUUlm7LFQeEBTBWrOA'
    '4Ixvtio0xIS0D2jH8tlqwRSuqWaC1gjYEd1s3DvvaS7hqwExqRbz8dSc4BCMWyGNGHKR+nygTB2MbYVLyAeqbIybM7hq4IOaYOqT'
    'FEfe9qmjfVacwW+MPiWFaqXMh99EW/x9Zs4zhnM6J1yyfijS8JUsm0vnC+QvqMTQJFGZY4QB13I1loMh18NkHUVFIgiACrAOIUbH'
    'N7TgxHdLVdIVkcEA4xERRp0n3yUm6NL57tm3lJXa0lXDM6dQMF6p8hj/iUTiOFW7c6vvdPjBkXefL2XVbuCBKI+Dcxu8Z7eh2G3x'
    's2ck7B+Q+pQLslWFsKV0RSr6FGOQXd2jihik+0RxwXRpXGLVA92BqLWKwWeR+URJtgZjuAWXbW3Io3wcHYpoOezJt8AJlIq/H4Uk'
    'iKXz4Y20qDTuuJXR8nGQ1WV7mOeHpBmsX74Jf24YBTmU29vtkQz1YEYE8yE+IOroOaFhEUGrEcGqWW7rXNy1c+2a2dT9B9nwwCz3'
    'VuDWufJcNovo8MiFcS/8NLYFUULkF9VvB416MaA5d6qaS2RMjN4AbHXLMyBeaNULDaxQx/w09BauLSPz9BQTYWHcyVKqk6fTsXJD'
    '8ZdSzFtBPQYfNELtCwt9PtNERQ7p286WD0jWCJJZMHMwLI9fBUPuTH1cUizITX4jcaaYWeri3EgAnD3VvDCwqO66xIq1fE4uKbCW'
    'hfX14Ze+KFVxtw4W/1vCoupFwkgITWYEmjy8KCcjggD3owQtiy29lxwqs7FgwNzGuAqD1TJ38oXi5a/rafzo1/1KGNRFy4RbJgwI'
    'etz5i16ddH5en25u1pxy0GVIe8V8K5cOtbcru9xh+4aka5qfZYcfvP5erYnVYqkgI/bU88d2py3yphfQK+lmEtrdzPyyMC8g6cnC'
    'lMdIV19vTdXc5qR7Y57UmuXFStRCChcpqnK8mxaRl1O1GjP0F4lqI5AlefJY+EGNvQC+EmSwx7kW19blftsZ1c/ecpcxEG5GkNBh'
    '/yFMw7v4z5fyn0e/24VZ6Hjvd/IjeXeSbwwWQQ93WuJEzNN6TILIvtVVyCM4v6DA/SysJob0WUvSuVEBBCad+roDfuzTbxM/KtJX'
    'oJQa/rwI0LiPd30wCprwyVKKXCNSvrTyFy5IJS2KjDyu6OO0ORyFBa0JSx/uworVvWxBA4Z/pRWlsRktJC7fNG6CsMnOMx7jKAR1'
    '9Xo9eY5TNmbQ4Oz86/LsDO52Y4Dd9/0G9UmWbKoxpuB8S8lCpn8AUX1vvPN7BovQi8LHiHxggnQGu9X0UYwDaYSAfJZm39HZ2sd+'
    'M+TKbaSoux9TFBvfbXIbIPTqBSif8nXFKjhWfbhtpn5Y2M2iYUDe0oIBjcayu8dZ9PTgI6K73Mdqyx2NDHSxjjhyNcPvSq2zEQIA'
    'YlnAkX4/2t7uQpXAdECgBIHSsp8sOJetcOw8LjFK6PT7DFfH1M0rB/gpf4FYkazJz9IhxvSV1ddjn3DC2AQLF9RPjqDPAj/iT0PZ'
    '5y7ClJL5UFGyHEVsLH5ESyLTkaxISPP6SfxCNE2Nxc1b4UGgX3hbInXyh0iOdU87YaHOiaJXT/NbZdUEWfWGk/nwkvGGKnt4/EqN'
    'bUHnO5x91dukI34jzAagxBKJgltueLXs6AXmJ8aocIXlqCBW9OUffxvdBjnLi4J9F6eqsc/ZqkTCYGHLsfGumexXhrvDx6Uia0bh'
    'kwp3o/pdIceB7e8lY/hBWuv8ptWCFDkYzG+QSqKxwaPYV7KckU8V9KGyvUwxQUo1pf99T4seHcmf5My2FRf1E85DiJEVgvJECUqk'
    '+YgOiF5hMoUj+RhFtvx58Yy6nYrm3v8tu7B1F3GxwdDtnE3mBfUOqhLoR4GjwqSFzaC6A6w1CluC7HJlkF5AL11crVIEI1ndb2Gg'
    '/dWn0VIuer8V736yUg1ln2mfteXxdLFaa4LRKK7XQCerobQ/q4lcmp28ei8izwQAHj9DP20pylW1Cz5YNbmapDyU/Y46+rjwOhR2'
    'ghJTTQ9rMUWaYFf+eYobR5McuBu3INZfAXw/lNgGiGWu1WgKR73W2RkFXV+yC7dR8NAbVQkVDnWNBuKyodzxWATOmXGOLJ0wYaiy'
    'Cthr5creekVRb/NN8okHRIe45h+bTgP2Y+tpMDxSc9honIo7iORyPBUp4415KCRipV69Qa502s/PHYpPAhFko6bp8diKRtkSJkc9'
    'zGFuiujTtzBk0bKoqVu5g4+Pv/ig8/mqmCKUjrGe+e3JiVsotXfJ5r3XKMlg0fz2ngNa13oJx3o1m4yrimdQx8ugqVPvFG4HyzEb'
    'LeNoqH4DLTF1ZyJMVIqXF2t9VenrD2+VRx8qJA0JfcVARUd6jbliEEAAOVVV/nMPVTYbj4HrvgLR0Ysx2tAb7oZzg3uS6+zNeOVd'
    'RSrS9ZqQUlKAxRd5PEV+Q9fzGGCnTU6iWGF4UpS1YGEqYaRKArU56Ag464RnWPvmmliDur/dBZ3oJWLyHu91uRSUxRreoT1p7vJ4'
    'gzR2RqzyaeyJ2o6IuY46NffLLzJjVOdnUSjJsKlJq5LmI2VN5VRTitk91sNAJWQ/AhsbM07bPnRtLamjWrIO4ILWdT5S4QvTKnos'
    'Ziir6mrLklz/cLxYRbrKRFHZNUiGSF9pfalilZf1R3vDlVM4v2Sa6nrJVN3XrhL2VV/6oUbbBYbFYtU5m33S5XznImdnWNqDj2/R'
    '5Vj3s1JrRrzEvOvMQRl2aXR91bEi4O8qRdHlMTZ5KqDvWV28i/RAzXq4VDwgaTCJyCxFFhHawZApham0a84hbl8toFgmAF3FWH82'
    '7djKILhoH9BXh0Xy3HaG1Ue4O78zNRG2WjI6fFUz52AaTSumOxcWcocu5MwhDt74806r+cR8q7hVnAUrT7acCmmrVEiLhoLUsGYN'
    'iPBrKDx6sZElK8BoUQkB2VA1kZYohjKi6hvrtJfzOqKLsqx83qN35+jmQH/R1j9aH5hN9kGGPSXykVx1q368rFu1I0/9ssuM7jPX'
    'Xa3iJCQ+r+VZQWRP/eozOmDLbeNMZmfFkApKr90sVxE4U5zT/ALYmGgwAT5P0qkw8zoNbK63dJLipV3CXgaBEMIgX6yRZ0/HIA2O'
    '5ikzV4Gaj2024pwmKx686A7Ag+ZNqR8Gj4Bwer0XOvhaGx24+w6RQDXzywzjZ8dx8r8twRS/WC0n27tS0c6ZXNxjRnYvx++uhK90'
    'hHUq9ZjRTsVJ82ighYgbKuuI2GEGd+iJGfYOqhSN0Lq+kBsMEobLpOJoSQIoWg/P9Dr6O+FBLR20sFMxxlpLaBD4vKIkOhpWrciA'
    '7jBx9OWAhzr2otW1VgAeO/Uq+l8jjKj3WSO8LNgUTLtNq0IUdJYH2KhjzfY3M5zOOAmKo1dqP/I3jA3mKDuGGtZZu8o48nXOdIf6'
    'XYDQ7Vq6bcTJQup9SEPD3pe70ZfqMOo/xmweO+TSDtuK6JLXIUrt4Z3DoalESqDfEtSBWq8q9BVWXvqot2Hf/+myyheTMzqy0gzk'
    'SLEt9sgWIiT1mOpxw6qdgbXll5Y3VMGeQpbjRhaO8y6yf3vTQqzfneYaGuP0wE21rivhY2escstZurH2+NvrRs1x2zDy7D+yeXlb'
    'kwvDvXQBpCeedHV9DMRUIfg1SIjnVS5PoXmkOabUkukiDEVixOkg5UQKGOet3nin67giIPll9alrfr5wJg2t4iTERxc1c41TNdNw'
    '4mqq1CcF21aajqieIvHZ+faKu6tF3dBw6VNypqrxRYEDsx/ZGO4n3dcGFZShQGQePqBRyRtpLsN4YnNCAERj7oTzBbfEtqVSOLdf'
    'sKvotrFHD7LOfqz497p6tNwNCnmYHALYBCxhQMVtMSpMheTDZqavG4aFqa9DrlbjPsOzgvF90nJw7DMdxrfhou42008n1zT3Y+Nq'
    'dvjyykfxblYWroR3YLnMu9pQ0LoGvwQ521OATO092v2//y/aKsMJ//b5q8T2JmWU2HWzN2+/eR2989Yk0zct59cjg907V+i980F6'
    'iAtDzTOzbcFDfD7oXTtr7H5quC0M/G7tyl9o+Qtvvf0ytI8peM18kAHvIE4gW8/P3m1Ll7rSbKDE39qXfwET4/OaeoQYMAB7+7kX'
    'DxtJTlVskp68I0TreToN73qR9TrQyS+Tsb/rRWbrkF6SAw6CTTEjZ8vsQBuIDolIJG4EWpIkwfz8sqr7fcXKREtuHSjzncfy0WOj'
    'MZ7FKzU7FOL+wQpg6h1CqgvR+VZRQTP1OOIRONO0KKBUejDgAS0C+3vgj0GKKadKqeezseGUer5Sz442Lbxl5ZoZjCuX62dOgB2k'
    'aLcsfWZ7Jvf8fjybrGUvDfDr4WM5KAWkI8BXR0w2URWFe1Wg2bPSEHrifD0yJ1WURDnsNWayp6pU/3zKhD78O0b8mzordRQfKf18'
    'H2U+3ZTd06+pS/xbC2IMRBj5PmNCrM2AbJfCrUwry33rErIldmGMchoft4R+axIhbiDsD9mqskGm0eGh3jehua4MtagJuXVvaAgN'
    'HaHeJXd5A6bS1dDjp55gQQ8NItXB7HXDwFlOAUuKVQfNngsbMQXtBskLzaBS8s8HbgFYPo3A095I0WnilgaHAqGtCahf5vZIbbJ6'
    'vd5lFbw3bO78ZannnZzOXm9vvxm/fFWRnW70oZtdF7NVnNRTetQNreM7YXYv62HODx/LfzAVKay7MwSH8s+IcNJhKzvsBm/kWoV+'
    'DxGHeB2EVePPcKEpS9LFCUdyV7Cj18BNBsdqfsyVKsuZVMtSXo4cNqE3o6DKvFeHDKm014wTuKwHaZs8xPRZ3G1c9W0b7v0M+4Uj'
    'JB+zea9H6zWtsxqzuxiN2a9lM5xyN1YcXcZeQiW9hOJ8GnWgLc2kLFX0yPJ29uTbSbFConp+bLdr51WH2goPQI5f5mnE/DrHerld'
    'hoxOl044i9y4PkD4kMZk+gAwjWanrqVjU45YJaYcsXqYktidfBdfriy+k6npfnUxn4wjD01eBVFQd+SiyTtjFTHDzNaOnFamhD+t'
    'xotT1w5w+mtXRx6xYo2dqMDaQUfC23CCS2btLM7EGz8zsF2PUAtmTgPYgX7tGPTrq5p6puIViDmtnIjtrCbVCnHthoIrR8wL3cHN'
    'ko71nUoT1cgwW46BQ2w+PgYfszjRpNAG5wwPufhqq2UKiRTvirRKLuo4AbA3vYT+PpGNguq1oMHG6a6LMe/zPACmOhGIg/BnLMJg'
    'aBxvN7I3mUFv4Hg3rpLCUOT89UDpZbxI70eUCE/uutn39sPV3lW5YN8R1ahr2Udv0IiqFHkeILY2+ELN7vKFSo3F4VsZ8Zse7sFq'
    '5p7zQ/+ch1i2zrGiLp1wgju8yBWwCInskdcLOb6qGe/xtXshlW7rm6E/wg1+4o2IxhMFDJS2wHTxcB56QoRM0ivhiqAxh/8Qv8He'
    '8d/ENdOXE9baQn2Y5GwJw3gsW8yc4uUvVnMSsxVeLXTJ2kGmNJkhme5fNNc6d7Y9Pp7LjtbZ+FxZDenjLyddz28TTRjcBaJH0Fs6'
    'z5JyUmaAwFD7RMhr1KFMEwKg09G32gn+tj44CWiA8r5qbTxXMtMhkaApXeWVWbMhzsmdDeVJ362BeApxoOaXNb4nMEu6Nnbk8Wf0'
    'sU65P8r1SVdygm96tTk7ibsQExQWnpY+q00W7UC7m9gdu2ASrDHVdRjNe2bUQTsf8Vg9nBJ9tys//A31umDmgoba+3zej6DZIYtH'
    '6XLNjfgMqotI6ggyhqPAoOVkjmPWZDf/uMSxR/cMjI2TX8ENVJjCFjHk78Cqeo/HT+r2bXK5Y+LmUxnKqhggbfBCL0/Vr0NYRBDt'
    'ci63Iod7xazzidim2nzYv5hvMIaZmzPpVoCiCtOhLHOERyh3QABBj11xcYkfP3zczfafdLO9LwFWdZJ7kWi1abQjdwtYhBmaXuWQ'
    'FtgrOoQ+0RgxNOyKH/g5BI44jxbj+TbMbrzA6tM9XtigdAf7Q4af7sr01+Omc/jBtOs3djD0HPbUpjXKyc1Gz2HdCqm04sAF5lLa'
    'ELpAAhLrT72eImhcTd3wkaAwGFMqFdtNb2Y2TpX7m/EUd3XrA90n5ccUPeimKl7wMcL6fD9rf4fhY3V+UO+QyApThThC51AwjcWr'
    'PDsvQAYgYCL77DRi2L17n9zEl31jsfteIpgmEsGoIRLApnALlsKbYbpqa+pmcPPzxjP69po5CrqiSXFD3zezrFXzyfvxjxrvYKO4'
    'mq3IVTcmmA4mN/Ah3KWXSQqGYgfrxmf9g1CA0rS0uh22Ix83TiONrZEN3U/Sx62vPsJH02usrueeradZhRD4quxU1ROWQ1NeKOee'
    'BM6FnBjVdak5NeRAOsmEgXi0uTdEFF4OAyDLnCMpOvh9TefBDjnJBs6Jltla0aNlAqkkUxbNiwpoKO5tNW8qnbGdAwWNnEDkNjpn'
    'uOYZxZQpJBKq56AgAzBBhfrOCsYVyi4Xyge98rjkfUVtG4MUzLoAE+6Bk6TAjFGeuoJLsMk5NLWmajZNrhSnYbQjG/tUJIkSu9nV'
    'wvyiIMW2pZwZ1tW/ykwjePfGSS8Hme6/Gy/0ZkNlJ26CCsuMkcMTT+C0gZff//D921SdvuvV6QDPplkkDdCJ+PRuzM/HAL3GfqPN'
    'l4AVauT5S/j5AZIgVjEnP1jnHz0ySnhrSgM/daZQzmOM35f0e/T4vi9B72e8G15SQHFSAYWCA5bCq7W9gumLUoGdwsgH44pZmO8Y'
    'b6Tf9qFDcTrHlyGd40uo1P/6V6SwJmkJJXA14n4drI3EdKIv3KvfPG8fpTpmrfwBRnOvSOAVNsAF6MiLRrJDSjJHZefCk2en8B88'
    '9QeHlIWoU6Q9ZZzSx1MQUAx7M41UC4FYfBJp0p50GGl8PbcmdAw5l8+asHMO7UlTi06iUlZeQVIoP2w6fCQ06mU/jU3ZcTHG19qS'
    '9x0C4RjBq8Ir5pEOuZxF2cuwTFWXPSAif8hiEgg5BzgdI2EySFyx+qzuW9X3lz8Hrne9Ztd0wQ3C5Oe9KEEnE8FbTiqsU5fz8iNt'
    'ULxbG2cYOoirBfPuFWoLHg7Co4E+KlFqWMi9Pht9j7Bmu9qHgxAO6HwETLtRgLvcxRlgIQ2FHhbHZXGSG/SpvLMgilfuzR3hmy/V'
    'W07LdeV28D8pEsmjr/TR4LilRRZJJC0suqdW57MOKGUnIpFfuWMpFYfDuxNT0eehyHNfJNeDnyBMFym5KAK5KPzh72bLQVpsEIoN'
    'fLEkX83VKo12fMlir+Rfu0bQtZesJn5441hZKrmh0jN/aTkbMSJzyd30RyFUiaFzxjS/9fn6Y5iMP8bzhZuYdrQ4ZIR3VpS5zH6j'
    '5u1sFNlt5LsdPD5I5WTGHUr/Os+72Q6X8j73OwwBS2jRlgMwmaOBFfuqm20qleSlGZ8xLBJlGtF0yyJ5NuCzgX6Ovsp2sLtDyh/o'
    'o6/8o0F0ONyZBEo/WiTLzete2niGfXCUPdeQIl8BMcOSMOWWWrDzmr3ebvZaClvAo7sRXoDZDHEr5qUp0vAC/p8TuT9ovAzs50yp'
    'bcqBMq8KoljmV8IjDixLfO5yGkMNpIzjfN4N0M+4ZrJVOQUDO5Ynjo4PXZ+Kc9BEJXq8NHhd9LLO64jqgzdkOyC7OBrsBCymF+PJ'
    'wnreD1pryPKyvZZqFVr1su8xvDNqRagncVfEGYMq0Hv2JWR4U8MxexllqXROzjBWkwkm0yzUFDftmXCK7HxFsq9XmhNdtEuI8hpX'
    'qyhTp58HOY0RBQ/G2JVZY+lSsMu/Yq0Kray8tQ5jutpuzp3VzLm+zC+00yKGS/5Myv3SZvYtmEdL5HrNyCV/UnlWOGtwoaqb84F7'
    'MEhNw0biyD21e3HstDl9yN26tk+ajhzpJ87vI9XLS4vPFJdbKrK/sPZ2q3qSNb9BU3BE2Ich16aX8EktptrPWSD1eqgxoC7fTaeW'
    '2K9l5TanyKglLE7u2JBJeFMUssbXRmaQm93YkLtQBheTfJPkN49erGtfrMkS40XtC3uRdmCmHiC1/GuN7J3zJHvnnH76zAGofy40'
    'TZtDrHOeL88wHHvjk4UARk52s4yHbxymXfhmveve+Gwi9s167yDS7HKV0X+vOQooJaQYcIbHIT5jAneSnquZo6DJLLxOs1TDDIGK'
    'c2cWew5IfsbAIAkWW+tn+4+RF6zzF6dXS1JN7T8Kyupo88y5eVD1Zq+NedNj44IEJ6Ek7bREXa1ETFkZMdEvq/H597Ov5rILVkog'
    '+C9OKGwX9dXpNpey21yPbnPxagcbbbuzPKMVYX/XlE93HuAkETmLhfyHRpgjnRNjEynMaHwi/3yqflc84Qz4wVPMR1yBRZG2OpHy'
    'jnL5UM167Pz2ss4dapQuXdaDqwJqRzvqshCpn2ZwqBwAW2hL668cnkjX26LZARWB5KumAqWj8TmzYglwODaDSw+1AXpNbt3Ij4lX'
    '48ypmVShxWBuf5FezK/pFE8EOpoxlgn+UKoadY6jjN/x2synQH0IRNf8qH+zUqScnc2DW8dlXZq6yzuiVRfaYvvpbPATacCr0FXU'
    'AazQrTRPUqnO1S/sotyQT1Xj9DRYpHb4Y0++hiNfrZrjSmh/taZq9fgYweA7OMbH/g88ck/2Tk7aLNGjFnlCjcoVlDWdcKj3dvMw'
    'dDVJVzda5NoD8+R+QuCklRgKJ/P4eprMIdsc6Bz5u+mi5NOGFfG2xb8ENcjXt4ktzxe4NAcU9QumabBAdP6twwPaxMQ9rDNxdzEC'
    'NaKLPdrukaeT/ZwJqM7mpLxfuR/MfEZYsuj7usu0mrBUVP6qBxe45z36YkbO2aiiE/+OL8jnvQu4OnzVk3Uw69MmXuRnXHRa/DmK'
    'PzuUz8LXIiFBPIp8o1Ro/rkXHYhuhp/+sOSGjh6iLna7dFvY7e0+yTcekZ97IaJqZOo1Tx5+xgRQZ+eNBduREjR67baPRbkqll/n'
    'Z/RRt4XvQfMuCkgsjpH0lm4zJHhVkSad8OScIp1dI56yO6Xdlflou/B+2DuFcVhd487ArWDlSxJzQgP0VaKR9xHOnDMcm07C3B30'
    'gmBINfQLczoH8UoIxjOGXKm1KQ5Iiu1av4KwK/2tRyk7i96dlJiTb2YvazbQ+I47yv1fQ9xrhq4k3gi2TpTTBFLCG8zIucLMmMJK'
    'UFPLqSZKJHOQmoTeaQvYMyOROqeFefYBkSsa1MJ6oI1TtVqfZowKWEa6UO9HHURxpFw/y05n1SlacooA0wtEUI5T6pMvaDr6zEnl'
    'Z2qbqmLWV9rKu0F7bGyNeiuA7lUuPB+9pl/Dso8uOuWB8/vu0tClyIUE1XAbGcMO7I2J5IQ1ZAxXUD1bKJ4G6PFAFNNxLztFoOh4'
    'dCqtfuYkf7IrnquyD4V5CSslK2KBL6YZucxdAPP0itBgxdq89lbzec+CNfQEEaJRD5GqDKAcUYasiwE7d/TgwEfH99S4ZtG3vewP'
    'z1+rVW+p9GERhWYm/fVBladMbSgD5ht1MNQdZZptfsaaLFBJ4ekAMtxRNPIb5xs/mXD1z2yZ56QrIehyy29ni4BkuF9ECuxM6hR3'
    'rUdy98v/67p0McAMKXdR/aQcpeGLRA7gRxHpoFiinzepSEFNy3mNOzy3m0Q7Avbj3K4aewLp1/xXwrd6KdVL6rdxbflv506lsqFj'
    '0qy6GGWBnvxFZS45/Ev4C/0rMAfuglfBBT5rOmcn9eyeMjnSqPQcf1DJyqyhVSqyVp0QFgq8kfJspbn9zFCaONU6L9bKG1OoNQR9'
    'U5rnFHF6L65gALEEx2PvkXrgSFDtULp21HINBx+ISFKN+nWXbFcPKryRwPK6EI8CZUsqWMzDlW2l+9sFYwQdzo9nDo73w93KFdob'
    'bW5obZmptWVR83eNwos0mZNSG7hUIcozijkCECRc33VJQp0NfZ/xmiswYfuPLAbJqVneYS3jMKT9R7HLrDQKMZr3lXXlSOMr3ik/'
    'fmHQNO+Ug7+Qf26lU+8ij1qD2KMDkblT0vXvneqQWp6vm+7dUgIaqn6ClXdTUTvVTzJD8+G6VnLNh7WS8rDGzMve+Ro3ITfXJGxm'
    '4SQtHyhMN9F1ZvR+bigEXstNZvco2izuA+GoJ9RH0FTsXE92W+TAVClj6jlVmIxSrQk4W+ro/NtYgbK3a4o6VaOMUl0K3+7Fb2O1'
    'yl4C7jjpSStP0ZG//jWTH7vQsu3pjzXerO3NGm/We232vXYxZkJH2+D06PKpE3TF9EcsQznG/jId0g1HjzFiJMGoGCt3mv24bShX'
    '/0ChdjMxBLkXIohJwl9F3siF7hhHOQGH2R/UJzhiURXmgfd0leg9ST8+R+mUTezM4nMnM+tusUT2575wgJ621OEn98VO9Hqvif+5'
    'UVPwEQ1BTWOMhUhyMwsNSFXHWKZZrN+TEqkOeb3bTZM5o0RSx3qv6xOKuRIppYGTXcB6dl44HMCBi+i6aYQUmFOOR/Vze+aG3ju3'
    'sgsQ91o17zXDBgIzkjf0rbraTaXLSsN/O/NeOq121gnPx/ZI11fU7X8g/YtXup8sdD9d5+hn7IJu1Vaotmt1+ukf9LCIiVa2TmGl'
    'yF5NS1unt4Peeremta1TXymyV9Pi5pF+PV3Q6fqlmUuU5TPABbqQxjKZyuTpwhIyy52suIDFGOmXepXr+3ogE8WH1g7o4tagJWr7'
    'io1o9b5euALSZgrugtSma+xOcs+oS6B3RVEBaxxZZSOhivIXHhl/HlpSxsnbbq02u5si638Vcl63RrcMeNhvdjXoYgd8uOxTnm/5'
    'z7beOvqQR5qpR3nZ2EOUXO/pQytpFqDjWrSMnaUEp31AYVj37vticgXdul4Q2JDAulV7D3awXCgDtfFgm+Hd2t6t+a5xMyVXRhRI'
    '8PHTHDDTNphQzM6ox2Vul/JT9laOtJ009/wZ+83nay1/4cqvd93znfD8mY6lrlP7dRR9lpD0BMTZJS2HZ4eLsZ+pdXYerLOQyOJA'
    'c5fZnF+t3VcXNqDoq/oq3Eb9p3GNLOg8b4vxiMY3wfCMRuQbLF4Ylp0Bz39xq7fzKM36AxXIAy/kd90k2XWTZNdNol3Xviq1ztnC'
    '7KCHO3d0kRrCVK5NmJ7YOK9QmF4iXfsfa15trsSlLThLXLp1lBLteAd14eVjQocXK+oSR17v80RZpza+v1AfqZv6xRQ9X6fl1/Sp'
    'ql9B/nl8O9o0fm6knXFJNEv79ZGOyf4JPb6txcwCuJwOK84r7Q/S8BQUEUI0fix3GQksPOQf8rthS2jA0NqSeGjq5FEd36k6Pym2'
    'o9r9+Bn94qa7TEviYPcDbEvTItiN3a3TvIPlp/fqrm5E4P8tUPUNccGMrATS/z3/QPAKnDaO5JhIfU/AmnvcW+FAnsj5QejMPqxT'
    '+3/713+rbTIFtN8EZ2+IwfRtlIXYJsI6D/RcjjPJsbx8dpjRTuFeyo9nEOeaNDlY96a8GuUMLX8ofTxkC+pQ53yoxDbQ2k3wRSh6'
    'obyUK/plA1dhOA8BV3QQw5ePbBfUdLLmMDVYWjCAdFSYk0fqyQ+dyWh8rqEujUjLpWnRl4Ba2GarILeB/jQD1V1s9igmTI2IdY3Z'
    'TkI8E4hgTOeBbxP3DvfTEbdVbylbZEmL4p4BBT/Z9bsFwyvPNe+BQXc4Wwaz9qqLcVW71j8H39QpVp1l3hsRhZh/rfP2O9l2N0tt'
    'uKvZKORQuCs8QrwX2kHAFd8800Ey5bdr2t6FHoQH6EjUqHuR9Kk9iDJ2Z9J8AJsYishOxmke3STGMX22PvC6r2qsCJa8b+wLXjdW'
    'EsvbSEnwuf+6/JdxnuDqqifFcglFXx3jj0jMQyI/4tqhPvF8rC4M8P9D5J+DeYGG3cdSmmeCxe8zHQCwZ2p4M87EkiRj8Y7fVQxQ'
    'H6FwL3rZt4pPB56duyuPOk3DxhIuhZNMoWKccYIAYc6isVbvybG6URjGzWSdXYxvivP5rJhkFzKi9XA+jVMERSFiUZjL3TFirca3'
    'ZTEqryoH0xIr1X5FcFgkgG0IvWg6JMRpe+J4jGmIx5j26KmXqOSvu540qjk+Zz6R2A6ArM+OD2IsnDFK+je5IANYEJbnAwz8+k2X'
    'hI7zoTF0wlCcRChWfg9QpRsc3Iq25DVaZchgY79v8pCchmPwaTs7Rd0E/1ETvXcDBkpxRfNrfGjcEYnORVm5oQdkCmIdu4Myp06/'
    'BkOxtMgQYnuOad+qsusx9nXbOePORq3yrfZkDHfZhTpzI+aEoRsKhCFNK7Yf0LtDUMQoha4+nhpOXQzmiK+/mdF4bNZ5kycDBLUK'
    '7YYdYsYNJHczIHGw6PFTgFGf1CMRp5RKqjhO8LNafhvbM1AKLhTHMzDTVomywa7LHkGlcwwOXEPlhaJILwoNtJjiahg5nGx9Ncip'
    'UDzKjvUrqC7cm40fFeGjgSwcPzpOoyq4cQ4zssdUsXjswatpNzsmiDMpofZTnqanUgqQF5i7AwyBkVbMG4JSkgWYuyPtX64JYRhn'
    '8YlmnTZz3YCRN/Olso6XBsJ2qQYQZX4NM4z73HauYjfKAW9kK0pwEbelwph3fOKuUVtNFXWibDlyxsGcLPMGrobLoNMooTZAz/Lc'
    'bnQE0q5/mjd3rewv0XTIoOUjOc1ytYxi75CGdUsroT7+XfgJt+9avNw7lxTM4feocw7jZGy4Fg7zTn/FatVRCB8Cr2+BHPrzaeBk'
    'Ga6BAI9NmaYcyijxlqy0BkdsUwIYeaBHXDsXPljo3XLV8bfbLntt32uV9/Xfus5wGhJKhfHnrjRC/0QmDJmlOmFi4jKb99MUNV+A'
    '74++ZK24sPDEXvqmEW14a1zX9CYUaPt6u/3rZA82EotVQ00ytzG1mGrQdCipB7vtRwrbi5o1fR52zzx09qnbOZS8Hm/OtOXDVinV'
    'dBoVu/vV1e7uX1yioG+dOe9Tf4nLb8TcjnceJsr/ofSIE0BcBZuJauiTbc1TllbFkiNjNlwf0KTOhCOkwrUohNK13ekyasVvXfvP'
    '1rVgqZvMmG7PFdHCyEdGSpsRp6M45NQS+DSCTkd5jd+vsfqMO7WkM8rgGvbofDKZX2dIAL5kyzZK285CcgbkDpZ+i/EuKkYj7UrE'
    '5xPCfHC1Ws01WLwfgzFUWYccCy2x1xfSHHxM4AFQ0UW6FClmtBQ5wrunhRBU745gTj+XlBU05a8PYfWqeJYdqYLeZ4MZzKVOXj+Q'
    'N1QvB7ZljJRU5bCX/ZDw+HQJWlwZRHmRoEo4AUMZnYFwUhN1iKh62XOfNsryCCUzANoRZAS0oziS14WmiyWcBRyMmAVIR6NOEmla'
    'BQ/BEIkJVzO1ErShVyhI0t0u0qtPdZH++1g1/5uwaXr/B7oWY6mRGo5LQwQaZGOiTeZmz3BYhki6ROPL2j1a9mOKKt1X0Iv1HqEu'
    'rBAUNLuqgdmNfZYtd3jpoKWuCM/UQ1fyplyIgvSJUdh3/c7jvFy5eJWrBP/FmWr1Y8uDVNaQDyZ/d4adE+z2Y8xRWz8YtEYLvD1g'
    '0BoN8xzXcVzuhDMCxiR5Nwjv8jCdkzZkXBeq/C9j51IUS7AebZ+ibPgVZNrpcHUjU0o4ztMnu7vC6i5usi8+fPvjq7e3p5Horo7d'
    'E0OrjMZtPCCJKPMvAVSoMk9hjWQCYP9gPIklOQ8hoiSolvhp44ohvFwdbo8vexrxfykLc8Je+cXK1Qsj74GedlRc4YRDdY/xp6+Z'
    '4Zs9TMNnMavgo7f1rwHT0z1hftFJnH+TmVQ5kQZy/3Z8s5INo1X2rpHtjPL1LjBH83BK3OJNr3DNOfjAOj3ELXRoh4KT7w+E3oP8'
    'CNigt3kdaevuiAGPtQ1e4+xMK59HlTNrm9Xe8/Y8OsPvWZ4299bb7fQt++JSwUyIt7IqKbk7XYCOdTxyevzowOvmclD0dZPyVZEd'
    'JoetmzG9fXx26jrs9+RvVG48Ozu+GuhwNCaUTwoqbt6T6VER0sqRv9PhWbl1Q1h5z0/jqP7ISE4LOUSHOcw1JzZDj0K5b7V1MEPS'
    'TwX4ODuwx+SRpFvxY+19o7R2NindAJdrEwJ1Z32SDJgWbQ3qfe72qg8e0V+Q8bgMX/WGbh1+0WV4jic6v2VYBim3DuXWWm4dyv26'
    'ZTinx+xz8v9f8b97e7sw/aSGGxSjJeaDzGhZn2e8xeo9PNC36XQnb3+pr2j9bbqw0du6Mn3TbfghNena5ZqED7eEh+lMfWsTraOQ'
    'm+6SStlnCBE9wn8eyK9+PItucdBrm5n72eWBXwz/fM3ntY2XsCXySQwr8DLo5Zh3KSC+lBUZcjqtV55XvsB/NCp/1M9WwpmqAzzp'
    'CWqYXY3OGfswER68+sxbK6kNnxOXWThdCgXn5ftx8ONHUP3VxECgwe7mAecZZQq1F0zhqUNxQZoda/A9+x6pFIfD6wCzotKYgXUU'
    'SkKd5hYkcwfv/C++cyUjjbCa4XgZpPdDNT5vv5mPVVAMZC/hPCw5ZCB2ydu1l/sH9e8H8feD+veD6Pvoyo2YdD9d6srqUhImYIY1'
    'EiVDbI9Xs4+3k90tpWUnHu8pdbFfqpkPr9bJq3WTQtZIX9yFVsJ3rItdyj/l4ERjmEkDjxfd7J08lH/Kd+7FL3Ws34JcSrlgPL79'
    'eMcfg/iN/XjXZitkTr/hddh197Pw811O+zPA5+WZdqlwRfTngEXysECaa3RDnHNYxvvZI+RX3farQW7CqSOmcHygtremyDX9SayY'
    'NY5BDp0KoJZak61gYSxA3lGPZp56+fFCD0os1sXIo8VEtx3/rDxj5X0SnsAzYE+IX+05KeMjEEWFLZV6nlol9rseKmHMXCvnFiuy'
    'Ptfa4KmbEnE9f5raeLfuMqIhKJ1SZm6/9/D3v5fJ1XoAcfq7hv1GoyD3H2OZfo+M6x0t/Z+yR023+Zt+pGlGdsL7lgo3aJftaR0D'
    'PeZYHV+rTCLkTkBEyep05H2EdQM1mFs4gnSHRYx0YXJp+MQ1G69EERG9KouX1AGerKMn64M4qtY4Ssj5rFP1V24VGrqAq5Ywz6u6'
    '7fqq59LnwcTs9C59y0oeBeJbXFSSlK2XvbbUh4xPuTD7dMGte36OVGEBW50KIeSOskRZWnyLYGJzeiX0PiMw+aycev+YkCvaJ4z0'
    'QVCft2a6pt58WZzHvIWmq3wuFcewodR3BVdnVfnUU6Ud+1xpBo9sqeViYMH5r6+lDud5jPvpROE8mQo2BolNkGHXcVrVFZQwi/GS'
    'uTpnw3FvNr8GiOPoiucnzjSECUY/gXWV3shJbgvkbUOZHambOvGrJSOIaNvdc3gzC2kGP2RtHzZBEW1EELr2dEyreV2KmwV3dQUa'
    '2aTePnZIp4ecGfqKRxFACpVI9ZDT+uCoo8MOLJGKoo7XBNnL5Ipw2V3dISfuUM6t2GOqQpgyNVEhdlGBLfktnncwrfYhc3Amu9cI'
    'vz37INMA/ZZ81r+rNnwU52GNNm/Y+6gz0axg+Se16kL/P7bpWBKrhMpf1fXg7VuwNtQ4R25INTk/P5+MX1geQWrBMk0QG4ZSzz9a'
    'ywz9SRnh6/kKD7PP64+othqNz6CzrmcI35SY1tT8/WyLriNb/FU1EJNHREUOgaMOvXYrBKrbh+DV2wBRGOtL31fpZNQIaW8vyeH8'
    'fDJx8znqoGicyZO93ZL9zhe/agrrGEykZHnIl+tn0tWKJsjf2eTkTdcA9bexHMRY5mkCRT1NVsz59aZ1+ym8o/rW5MeRiYe/L5Om'
    'Lzc23Xqr5AndD9vlTGePO+WPkLx0axgGjOYkiZO9OhtGCT+OcQWuEWo9B1wTgyErxmaAQhbZkbgIc2IXm+MqLPqdNEcLIfCR9Ucx'
    'OSP8UQv5E0m0IinaZEnS+GYak/qWPsXFhhJGTyTKrnM2O4tT8sHXC7EjPkQQIHezdZQTUyeJLmzCLPtcupyjyp5Xq2aUfpIkV0SB'
    'EZ8Gpl5aHjqoIPIizpjJsTAsPkrvGR286Gx5wG3DszvMvrwLKPn1869xJe66cO16Wr162OxmKKyq4WbeIlWqi3nZ7mKeQmL99mBU'
    'z1NLtxZ9H+nT/Y8NTfXSEeN4TNGyMUbVcOq6GvpdC1Id1INUubNwN+ZHGfhvIGqPEdY/Pwu6FjZTwmGrZLJvc9kKm2V+E5QlFxZH'
    'NKGgOrcQ13k9xLUW4DqIAlxVtTJPA1xlO5nNz7+OI1z5er1rCt8dtBeHuOrrvfh1HOMqrwNz8/cIcW0HR/v7hrTWW731O8MCviaU'
    'vafIXdeyQUwzcNTQcsGFGGERCKWAE6L8u1ib0ouaLFN5UcdlCi/3N55bmSSJZ1WN3aaYfnRTTLkLpj1yrejtlOs+7THIjA/WWoKs'
    '63yNB1qCwWXzdWMxp8lqTpPlnCbrOf0NC/qh4SQWVnUQfnFlY5+RZtxK6Goz1iV0vCV+xQ+jGfPiBlWXHxLd2K7qxTCkVn3Y4obz'
    'u6DuX3WI3Bfx07UtxruoLMfsy79b19+so/VKtF4GlsyhcxxhJ5oirKXEO7aR6sb4kXuFL/QzryyrvXeVmfasJaaqRXuWnkGX+3y8'
    'clteNWY9hXOQ3YCFCj8hA+sO1CfTnqYLSGI3C6uR2LlGzUWo2bLjlWLHpglrN6XK9aisGmHiyfDmsL5a7txQwUVaQRzhZ1Tp5wv2'
    'nDpAx+wpF3gq3OepUERSq2uF7Yj9dYaMky3OzoRH6scqFwOyPiWi76lCzoR7CEF/RP/qvPFpAaVcDWz1P8DHBPgBbA8SFp3BXSa6'
    'jUJ+O+ze/0/cUBqZQOm4TOZYd4jdvhbJKxcI8mejMwXaK0B7ACTDYMkbmOmW2FQFwyVJ0vU3AybX4T1DJknQlyn35VwiGWHRj0AU'
    'BvQnekNXooEH2kLyKOUZ4i2uHi9qDml7vk7LX4Tn243nOfNi+z4xRFQTwfH0+mDlE9fRSdRRPf+hqxPG308YYj9hFD3uqdAEs6f1'
    '06yaaRR75ZRA9s1tzB0Af0e9E8+cAKTHUNG2SwXNGcDlN2Ia3vfjopvEDg/So005rDCV1Hwp/UjpWlqkNE+4APbjDYkWjJn9iNwJ'
    'jic1DnWeOZQfy956EAISRAJ2iZmt88TwJhkyJCEKiKWIZgXC74fzRWkpNsP4taH3aAoI6fIy72VvVvMF8ocB6JTO40N6QvBkSA2n'
    'k3Jark57dZufJ0cffIxQ2DUu7+BtN3sPr8JpGVs/arRrGMxsxnmMIKwrgt0Q2uvLHOFirOYuh7h6jL2LcedlzPukY2RqwH0Kt8zH'
    'u7u7gSsdOsxjSsnX8yVnNs2G5hItGsgCKWNTOdroAM4ZPbBQRW+hAZarqoOfcYf2ah36rC2Em7N794BZuQovO+/BDMh/15/cip/V'
    'KOjD16pdNvXhr+l22CB3xY/bPE2iSZr82uam9eYUg1I4D+v9NLeU12Dpk2eofv8Tarc1+KSK5RjQhSRagf3ftMx3jGtSb1uFlJbF'
    'b2s6/hXT2BDzdZd6JQJ1JgDZZA4oSs216xRg02IFyqxQgsBFNPyyKBGMNuGCyxret9TvJZiYl3XPW2r/8jreURSbVjjP+645Wi0a'
    '6VEGocjAF8kDquZlgCYLgfI4Ki5MPlaJYFenWhfjq+xgIUtU8mAXdsMT8wJMMl3IlVKO4JJnCNZQw3Utprcy9NJNijxZF0vFA1sd'
    'Mjw7zR70b06NwotWlY9AmnNJybR8ovpraPyCvDBXVL2qvoaKI1cFHLkaAm4VwiOqKLimFltYhcXxHyDqjCllGno13CNPLND+0T7+'
    'QKx0cqKqc6rBDfe5qWQ+3u19+biLjFhI0on/PmwwwAPiHm6zrvubw/CRnbQeSIW48Ms4iIqwXJU5six87PhlHEZlZdZtwVRp13/X'
    'zaz/rvP4z2MZQdqZMPtUflwSdsG8KeOAHnvjG05m+qHDNNh/tGtz/XA3b9U5fGkqh7QXo3giymQaH2lvRvE01Ev4XjmfLqmcLrjB'
    'LVW4ERjfEi/yQJrp7wEvUSMgV/LcnLxpV92RYt4SGMnI5LA0CVvl4VjU9v8JseatsSfu1D/PLq7Ox4agJIdyVBbny2Jq0qR5gZXA'
    'QK3WShLG0hoQfwGFS08yIFGSKS6ERtwgnHUKZg+dEQ7nUtsxxzTvdqaBF+Vo7VTt9EVzrVvhVk810nM6wcDlbcV9sbv7sUQDpowH'
    'tJF+9sy/jdDEDboqyluY4M75/CFN07xxbLP8JPgAn0mHL/rO1MKs9V4hkZ1NyoXDopWb7k2cfGxSVBfjhiI/urhTeanJqM3qTKFp'
    'T4js1M7/MCJQG7bkzgOIVLOTyJ79uSvgzF8RJMLHU7KgwhnNxFZNGtpm6/KUqs4Ea8HCq9BPL7YZJmgSx+gcqTKRDyclQHMhvrhY'
    'axw5KOWxmy0V0ifAqdgBJLlj//OaD6rtiSrfDGSSxvZUnxrb41sYRR5ZD3cbA7b95cCtAc5hMpymm7paVGOFRlDjo6apYJ7rUpNA'
    'VbUOv2lAMV4XGIKm0o0uWeB4E9oAl7LMQX3ki/l8wrqgY/ISXWy9eV8FEtpGM3O0MRifaZwgHalcNai8W3MXy1thqd5j+d63opE5'
    '2dGa2FYMj6MeM2sdHcmdnXuyXIcq02/jDRtQgpCqitLxgB5MOkMkeqqNHM0RMuzC/AxghCdgZyduh6Rf6b6fk4MmplpBdJyW6XHi'
    'MUIx3rtbRgdbHw4redo2AUj001h66mBlX3jcFIu8et/V7txuGEYkMNwNpvK5oqnUT5VWxSBN1se/WKf9td6cssB9ZcBkpCY+YFN/'
    'OtCVdpzD35KC4BWWNQE+8SGITCanQcyUW6gWKG7Kirn27OozUB3UfhDDqhswOGMd44DENAm0xgDs3WGD3pxu4/G/I93Gvzdf2t8j'
    'W1oc5+u8y12Qr/M9T8tuzKuGaYzTHN6ZUa1eeJ3gn0obLgeo1KDko77J29IuRfHyqAIfHwGHkmYcHFT46ZKJptF3D8BhuxY8Hz5A'
    'OJb0qOWjNT+qRYVjpu2KK3L73H4PcnMaFqZWKNvAPPuqwlVRaCTJlAmGiwONKDpEh/T3QPlTfT84UK2xez/YdLxSRKPPHtzPdvz/'
    'snJaQL0ZPbn/4DMae69n1bCYMBqrsPQeX+7uLm6oSR1PB+BboVoQCbjI/vGnl1nn9as/aA5ay5DLuqG3nMizK1hqRYCdVaSHw7Ww'
    'pUW1ng2z6CQWo+/xTUcu+3ESHrzErSiN9IZSaDXWyD/5rSUxNoR4JBqK6bldylql48qm571qCQ2n1KmPiuuiZPneSFj1kS9qRx/G'
    'a7ycFTKNxeRnxOlhKwoTLezNRfr2uzEFdPe6qrl4fsmE2v46n12jhtR95DrJK9ONEQakK7LOeQwi0VLoQgsd1BJsj+bDK8Sk2Ax+'
    'M2GESmdLbtf3RbUlPPhQYxCRQgk/LnQoh9lFUtUKx2kIlvKFHEGEMG7tj7Zcc6ubHjD3dcplXro4UEgfLn1OAV5YjRSXilj6a9lG'
    'nahwD/sqcMrFZHFReCKaEtCHBlNyEwgojsUjvbQWN4h6fAqvdsh5riLFYzUupBYQLRukbwWPZKyrOTqH3bbFLf1gMTvfIjx+89Uv'
    'i/H5lsr4uY7EzCTwAeRB+MB9vBy/n19G+1h2Y67+4LVDUdn88I4N56J9u+tWrp2jII5s9EeMPBJN8tX65L8HwWFzg7umpzf+yzdE'
    'UlvNC+GuttgTqDmFYPztX/+rc1eHKowByeY6p8VWwoMNiqXup1th/eAy9MFV9YLsORJmY4hqvOa0b7XPnZx+VvsKp3qBCSxW/+9M'
    'IoLRXlyUk1Fo9gOrv803T+OvH2+dmM80eQ6S3qGbckhSwu5nBm+5o8rq1fjanStYiWRwxUSnx0ZqnCp0jeV53/YH2rCvhczNikU/'
    '+89vfnwlDDNQHcuzNfw5zc+MMplWbCHv5g6cR5UxfxjLHFjT86UK7M6YzWLRS5UBY8YqdiiXAyYXD1fetMP22ZkQQgOjsydyxN6M'
    'J6o3/QmbsxM3b0Slm7U8TPJfM1id0zK8WlZInKNCpHQqds12QRzfsLrYt9zvrHrgvtrz7XUN1Z2h+vT70KjyzswCNd+X4+veZRQu'
    'kVwa5z0M6bw3uQCZSt8QEeZRN9t7TLf9S71vOozZ8tFCWhQeLk+IEhq1NAQDpcZ+KaJSgsnjR9Lkai2kM7jQoRL+Mwl+AWlqM7dM'
    'qzX8cR1jfbbqZ6dffOAwwb7NNNhUqqKt/XZxc4p04YtQCh0arq3QhS/E+nj1sei1fqnXH59c6BPgH4Cy8dl57wwhbZfh1c/2gby5'
    'tsLoMB6Uq2JSDmXwW/rXlkzA1gyxI5OtrlekfRda5GT42hfqdss3jbm34WAo2Zc2nNu8JZKBhErDFZqJjTbvPRw/e3kQUQSn96mf'
    'Rcd/JxtXt6ydcuvCUTbugaDIVCQHazkmhE/nwZ+r7S8edLMtvQtol7aMO9GJ18g4qbgndGeqKA2fz3AHOcGIJLtHQuWRyIqB8LBz'
    'YOiAP0RIQD8bLecLtZfNCIxPs4pBYLJHERpBHgknGhDy4eOBIEnchpfb9XJ1Dr8HYNMYLYS9ATgJElV5WY07iNd6syqGl73FfNHx'
    'MvZtCIKZOUqqU6t3Ct/oXPj38Ywd6cLIjtyyW8xPs80bqIt9CvIdKnd7x4rB06ReLCf2iu849KTjHu4L3oP2XBW3cmkuL78ul6t1'
    'Ry9Jmbafy8vyp/FZ1dHautZAHqL8YppPvwLtfV6LKLE9Jifpm/cy0S/LajWeyXdb5WxxtRKOzdKlpnTWz2e0Q+P7GwdtY82DydXS'
    'VxwzC3d9dDleI6pFvhs7e53Ml5Cx17I/i3PurTDYcU/Ka7zGNyKtLYQxkCGMewvcfrPV1+Oz4mqy0oAJ375mBeTkcW/UKxKufrnF'
    'gyQtQ3f0x/H6E6q9o8q3xWBjx7y2yZMZ+iimFUfRUTJlylgxhk2YIJmMGhsEYk81LZLhbGCAVvOf50upJREzYQCt3p9DJvkKwpR0'
    '5sWklP7+JLeRYytC9KsMccjX/wW+ZT1cSZm2rrh2egOr0c4V/ROLIo2MlVyHkrUAtMFgfmPswd/Do7AeZxQSq7V7zrcwFnrm/w7u'
    'g6zn7+NCePtZ080nBQYCKNBLgOxUfqjNIQzMhXXzENSlb3CHB+TAvFg3d1/d/Aabu//ajFWXmv2uZqvdM//wXecfHrBzZpfZYH5N'
    's9kV4nhGiqwbhQkvyqFsXYpY0XInOdoYzrK7cZkVtPFJ6+xoyrYnrfOiSJBPWmdEc7s98XMRn68btVKgiut+5rHFhE2zoFI9MExM'
    'OOZp/TZOKB/xP6sEbI4ZkHi4uswOjCOvp5PKnW72XfLQdDo72SMaTZOmfvaaye/4l3NXE5FtUpTqzLEeI7V677xHhPRzSxNaDHJE'
    'o0IEVSW03PZG1UMLMTtmNCJWKPUeRbahXToU+Jc/A3R0QF5+bx+wjt/pgwt7YPyDsc8YibLjnXSfC3sZBAnjog9Z175DJAkbOilc'
    'LBaT9T/Jz1po6kxEMtluC7nhboaTq9GYt7+uj62+QwGEOit4rfBS0U965Yz/WkKztsCKNmqWOCOcJx7oCqYyowv7YRT/86hWas1S'
    'ayvl4nweHXiuu3YXGcyigd2Cr4zwzGqXk4ViXf4w56Qoo8j99CFTFDME2AtLp4nGhhfzeeW8AVy0ocJcy79R7CqYVuDndCzyXnhO'
    'repcefmaLKClXO4yF6igGgmVk9ta5Fd0edr6ePxrNMp4aP3QKyoOpOfnuDhFDgSHRNjOLXxbQgHn+X/3kVc5yaUtTGXrtGQdYZTo'
    'b0t+Pd9KN6c+5WTZzVtbj5ZeLcdQtNc69kVn6x/UgrXeynv0G/zu7Q8vpRqw2bE6QDgiOSRschFTqYKyk2tf0Qbvrvn06UI2ajY6'
    'vPfDFx+K3s1tF/+sb7OXX3xY6E/ZwLf3oAGbHN6biQR0D05l88vx4b0vPrz97psfvnlzLOf27cV4Oj7pyT65dQV2KCAf3tvvPfaP'
    'RgVwJZbF+vDe77LwGLKs8KKH90jp7j14dtoijXK8Dp4gwYVIRhxC7HVN3JoD+8GSsAnt5a9DQ3AIFBMek9FhgxPJYOwQWINNnw7W'
    'SqDh5qDRuYhUox/3qDw7G9Njb6I8xIFzE8e5nl9rO2qYdOkTFJamkhuCnCaBwwNiVa8WAB5xwIiBnonI8f1IQXU8pqEBV6oeTg+M'
    'DPrW4ukxN6aiNXmygQ2QubPxksPvZf9Yqfc63FaFxZtd8VCobvZifg1pdzKfX1ZbbVRtOr+Sz1PqhQuzKc8w4e14WZdpVEAwtF1I'
    'i7ufDj8AdP8fpMNmiK1jjLTJ4YtC//D7x20yz0MlxFQjCZAigN61UBLggxp2x7gnhFVEhR57hLk9hs1iR5bK2UPivS6C9vaKVo1q'
    'DJu6SNyksPGl5LigCJZ0UyvcFqDsJ4ESTujJFuj99qTyDfryLi08ORx581pX6EWxAHsoq2JL9v3IJ6qMoU9mdw1d+J5xFXVoRqge'
    '3ZPbszB6ljuItq7edXPhfF7hVacCymZL64uSeQE2tS+UOWodhbX91bdQ+r4tzvnMd0OKt7YyufzIxMdzfmlDtJFsTy6TOU+OZKQ6'
    'aLZqKpf2Vsej8/FJfLNGEyvH2bWIYs15bWnVSQ7MMQOK3cdXtbsdNMBQC4Ia+fyu+SfsSNTPFRVANTSS7dV5WAK+ap2Pj56xLl2Y'
    'gyTfVZSd7OtiZYg8NfK66QyGYqPBxMB6hHUTegkzeI+wqI814Z57VipMhroIRn5YsUrAF74RyhfJ//45wx2fKLqRPlK4mj77ob4D'
    '0pcuqb4IRL5yykWhSm9lkc9ivScdF42PM4uPzLTX0GD7+Pder0LucOHKyWMiQi/yINowSFJ3y3jUT/HFW4hZ2hPM17hXTJxWSZ1q'
    'J6tt8raKhR6xbebwyZvZ0sIIc/JZUJ3apde+37Wcp4eYRiV++uLjBPCjw3HTvbEzjaCJoFRDBhTc633v6ujjGDgZ3AvrxZjGgtF4'
    'S/cBh9PPFs4eB29HxunRubZkYE6OLcd/1yf5HfY5yw3bd+Y/E6+SDjm/tHhSE61yva9y2UpXq3S/VvGGBcZr30RPgLH2nWR561es'
    'yfdLtTPPXmMhPmX5IJPdyZhg/HXGJDAHMXMe6EwqedQZFzzrYSpU94nZcJvEC9ss8x5ydkwv+LS6OQhytpZbR+X+5MuZI1YsZrdy'
    'EXUaOXL5Q1xF2E/ezUsl3OjFOhlsT/2sUprn/Oud9C9E7VE8K9GHwUCUgGIJdQMkFtgtFnaWA93KwMFi6tAD29PAwmL60OTSFhL6'
    'g7p1lhX+6LzStXBhagZb5EyRWJ29yAEV30fYUup1OgBvvDxnjE5EjVaantADkwD3yrcPM4jXcbAHdqxynYz54i3vNLjWyKfqUu6c'
    'zEOfXbbnI/e63wb5lUd6Lnn6tXzciWR5t5WPerpV6/hz1tHa3nZgbNK1lbvpUkEUyc/dAzv/5pnzm0Tw5PZvsM0f45Zbj6Ld53aI'
    'DhyV+pgQn1AZHmc9y1gbpcKE4Bz1Gs51evb94tbuh43bvWWvx9s8+CbpdpD+4BIIDdmM2LT/NN4pVisECo8CofQXfjtwo6zyK1Yb'
    '5Td3ncfN/i/jH82XOS7k+AH0ZBHlc4JRAfX36a6yVdHRBxIUjaj1A+CWo2YiHH2KifAO/Lg7Sf7VAgRfz8rHrgfdop9Q/vpirOWC'
    '1a5h6/ok6VSm9Efkj/yhGHahK9yRwwB/+Gq4FP4ZnJcUt/STUCdKOdwBB0gNo9nGhIObMbPkcLWcbLNjOeIE//Y//W/bWkv2L/P5'
    'lDjUGpCBOtTeh0/Ameiv6XhVGJtmV9cO+JfReLIq/ou/psKzPx20XkcRkf6Iha2r3rpNu5p55TasaOGkX+7Dt2BSTJHhgbeQOaqM'
    'bxadHddB+O2GUR5pFgI45O7u7j2GZ6Vq0R+munEmterwv866dx8NOsNddGMzQVaH/3Xmvbai2M+X+001OdzEgK9Vvh8bU5apgfNB'
    '9jUdFNRdd66JOY20ItfneLpYraN0Gqq1cDYfLZgzXLTIetWiRFwvHNtAhyF2E+JEiWJzc4N2QuXo93erJbeVayN5UILKkdzVBJMO'
    'eYv5JgodaryzuvniI6fxExqIMGu5+SA4voUL89l4iYCkMbAGPH90Vr8Nznh1KB9V/VyuLpyT6FbN5lpn0ZSjcEyEUXg8PAruoMoU'
    'dLMzOKImjo7E+exCQDiLmXX06MGfe/9SLr54UPaQNFM6CB8L6czVTB53zvIeshN3yulivlz9U8HYQbokdsbLpeaDxC1zj36JYI+C'
    'W+J7lO5n98CqLpdCOapK+qPsBJvHJvtWpqxzZmxLTaU4nC+E7GDzr8ZNd/QXIGUvHIgGozxM/ozzWsUgPg75Q/gY+uTRe6yCimCF'
    'f+xkIPERUD+JD/JZgKWLbDaQN/Oe9uCftH/EkaTzu8WNmYm11qcD/egNxL3wKTzk0RIRiRAmFjBK5CwigtOzmRGEpCbpvRpU6qZY'
    '9QwMoFxovgMhFXMkEAbaUYa49xmypgCE8WqleeWreeivGwXIiDYlZKhixh1OlvpAuW912kcqnGMxNTuLr4RphSunZ+99ppv6xcvv'
    'X//l7Z9efwObB6hcOeSd9+BmR+nPjgWvbh3Q8oWxeIh2/HirvjdbW11t6m05JRhBDaEaG+crDqsBc9sWTUhXNENvqQftLT04clB3'
    'yomqDE7AS9lxoi8RqK+4lUYvkB8NbioIaJ3pZbkEuPhML8klYMXNnDY7SJL76I67M6NRhO8zof4Ud7SOw+B+lDGvP0U+qpDCqt7b'
    'iaXB0rn/QCyUPtUMHHjXenbrCtma2Mb48cxNlkOrkCKJsScuqJlYdhNL7/HWn1db8PkbFyvkjN82Px86XsW+gPf/PJP/PDjvZlvZ'
    'Vu5814QV3/rbv/7blmI2MORuTM+gAA4RenCpnDODdhygw9afZ1sOR/Z7OzUW1dxZFQMCnPJSrcwcJL8dSOoA4A0rFpldTQcEehmM'
    'AaQhB40zigA6dyjCfpU338pSMf0TndmiveoCqmvDX3LgMu5KjtFKe53siYnNSB5AKx7v7kZZwSInXG/TTVWfbqcfn1DH5FluzbOM'
    'B30RXThHUESdOKJH7iEk6Iojr0E7XPB1euNpPQbcI4uFO+bBP2OFcyTaCCNf6ZLL/7ac5B6r1Mw/j7XoDIRv/7lzvHN/+2//+r//'
    '7X/9t7/9L//n3/71/zj5659H28e9/CT/c7X9wGbUzRcRbLRuta93OGinLpBzpb9lo+7soZeAQNJx5PaKfpmpxs/u8Srpuz4xmAUq'
    'JUl1Q1xu11BC+lnSh6O0C3snJhV3NdoUB9dH9FZBmopXLU+VQ4Sacl2MQ/edRyplfy95q+l1EYVX73kdboXLt5jQ3jlRpLLzQrUl'
    'coPaLRdi+vWS0eue0FlyqKrxb5y7Pm+Jtvmjyvm2CQelblEylDxb+aEaKnnkhdROD/s8JJokFPos1wn8beE+NLgumCJ8OJ8w+/vr'
    '5y+/efv2G2MZa024wu1NpdWTWr24GMsRNULTKaG6WhPFx+UT1Xvd7tg8MBFIOYq7XY4t7nTsdEDworrxKKFT42ImwtmiM4z8xJ/D'
    '3t8rK/7bGR712Nl8A00ZrL8f8XhWzFdn1xs6+M1MjqvccR2+Ezp+fKJE+4Zq7JsjzsTNSZymcZR4Rn/Qeeqzkc7QOuKnzZ7q/Sk7'
    'oKtBGuHKty8CMMX27KjnwARSkli7lq2p5Lygct64M1+H5ldgG8xuaefK9GnDHha+OXG1faHF6nui3iEdpduSwx6jMNFKvDuH5s1s'
    'j/1Oes0zaDtJj6ka3bIOOtVXThfTFtl5KEoGbWkJjExys8wRS8hGooqXo5EInj20A7QowuwZ42inPoCzW9sXnuFEqt7IUwaf6Ybs'
    'Wg+7vlJt065SagLC7vWLMay7M70yY5a1tx6vvBnUS9ckUyIpVCaEqFiosP/sUiwnamip21rBg62+7Ad1Cuwn5yj6egM5tjqE+B9L'
    'e0EAjSjzpoGWYZaLVaSajQbyyYkLeBkkyk5VJeqzKAWET2bQ8s74C7TP/qliw3I8m7TiMjMQ+C/m6R3sDExcl+Rgk2kkNqC7IaeF'
    'eRq2+UI76qFOC04XjzpzxdwzAJVu4qGT31lVMMP6xdcK09D16LJDSxFUCyViMOXM3pny7QjyQnfcNRc+Ne0skCj07nNpr61j5kmE'
    'yg84KXqX4nebQ/JEx2Rk1KGr1AUO/wjSRg0orsWtqc2xqWWQExsk2glDtHYhLccP4Uvmr171l4eTfG2jHoaNqvQiSnNzjCd0fn20'
    'q+REfZP1vvY6lLSmxKO8U/MkNi/ZekSA+Uh3Gi7GUfEoLCA2c9QbDwhOht5E9/BdRamGvhg+sjpE6GMZFs0waGCg42/2RYRT+JRH'
    'NkNmUW87LhHfFC+zQxzW1WA2bsDQ6PkNwvcsIPUxqHsVWZtapzWLKJ8Z92e9y5JgVUL76kwquXR5rCVcihQNZolIgz0VrhE32paD'
    'X/ApV8C+xgAUs3qFuRRy2IjeAXtnj1KoMzMa+Z4qRLeRFE4AWQ57rrXIYbW0KdshnSZ3nO8TC8ad0uscaznzLOZPP/749i/ffv/y'
    '5UGj3xwp+k0kW+hV8PmWbArp72B+DZHU1sd5B1nyeVDZyLkjQ1zrofPQlw7rZnEiwX05MOa23/rO54KLXQhSSMJVbNhKdoC+OQiz'
    'gvGFcm5JQGvUZuXYhGjjWTpRGZpT9EZ6vFivTsS2FbOKwo2TFyaLbQGddzK/kkMhZScQlS+uBmQBK5+LyKaV4Gs+Uq7jl+owWiym'
    'lgaU5ixOlYMrnIXt5imr764GcBE+4vhe8FUyvgz4hPzED5VLxUV4NWYCR4Bd6qJws+qATlrAuOkmUKzoJxDcA+TBmg9aQMqp7mB9'
    'kTkzwOnFaHr81vYGrx/flbY7aKZJh+CQobuaOlwRutezIdwFmRsW4UnemF8us+Nj3i8nJxlNeZlndyrgTkPvHeWiMrLlZbC8zY2n'
    'Hmm4IWFRGtMfhaFXljlcWTJevbErAugSWfGR/G2ArrKip/bsiw/RF7duLKdOefU2WNoLk6rP546n7kfaaeGkzQxU4+gxpllgE50u'
    '26lzVQXr7LZmogkOZMr6YYg0Uky8t0KQJ69WpqaNFV4VT7zqbA8ig2Q561QbvTbq3O1zj4OoKFAF/RaBTgTfZiek9JWjKi0tr5kU'
    'pPbVuBg5rh77oeq1OZXh47dsL9I455FDmewFqKiRrUpNSW9sCgO+4crJN1erjOYogqLDHZ9Ae5FCP1aijq5UeT6+c+aiXlWO2kUi'
    '04SZZR32XmbcoYg7PteQg4CIylTB7eI21bjbTADrIFFgziLxx5ZsB1itM03mp1vtFazeiZDkcXxT2Rj63UhS2QrH5/SLD5hEOTMv'
    'rla8yl9Qhtu6ze598QGt3eJfKXBKCU7+docGj5/peav4pXzjbDCn+luPlQOXtCX5/nw2X6qTrmIQilD/zcSFvktXXXQ8/qz5rR71'
    'Olv/YKYnRhyrUC4zX3TtqAlthmRAFXS5KgbmR+txe5pGTqxD3Xet3ls4A0l/3Gb+PARNfI6iscmy3WOBJnetElA3oHiE6vHmnW7d'
    'sZD13vktWY8HQv9LeAo6u4LZBe8aMCO1/xsbL8MXcU7/qEKtxbDdMQ0qrH98IhJ3KOTjcuQpmNNi7RpwvA7rY+jS9A2uoYMCR2r2'
    'NoXdiR5e5hq/y9jtDeKbgsCNnHvjtpmwzyym3CUlcDcxcXv4JIJH0O6d15dLiQi+pAuCg9iJVOBqQkg/j1dMa9gKWiSn9GQP+Dkc'
    '5ZxuzZvJjlSj1q+hLbTYf/pmONu0JxPNV3QRd/JutHWkl9K1RPXXbmq/HK/VaLwhNn5WvPc+nRvum5ak2qO2dNp3xZunqhEysG2q'
    'kfc3BMi4cSjc7x26DBG3u4YGeYhy98G1bqOE/IXETuPlwqOVD6qOFqFvDovcRN6OWo2L5uWXz6xu5Mp+3N45zXhyaAW39bv72X6o'
    'V0s8lflh1moKrnjkc1bPApYFUX3HVRQ0Y/ibaQhHylE61Mw3U7kzL6heFQ6vqFwmvkKxMcHwV5HTUAVBZTifyjLhsmEUcjVcwuOh'
    'k6TOvAD3PLwoReTvGbFSd7WmKT7FXKpxBRsSEqmWnAS6xX/zeCgrPlxDPQP4lKPeau6S0EBoDvmdHbRvOdopQjbtopxyH6rDQgl3'
    'xAth9jQ5vLbwyQHg3QzRiVANDearFUMVv5OdhHBMTFG1lffmZ2dCwny8ODCU2pCYqCvyuEWdYQyeoHhLjK9PSmwnJUJda18X4ZaG'
    'MYCC1rXeq5fYTkq0oKZP5vBBkgGXMyhOb8jsX5QIXZkj61uBHk8Bd5t18M+2FrKYcCmzLaX1t2XSmQPWt++AWC2DSx/VPbWK8F/W'
    '30dL2siRNSUP+lmUU5uyqcLaunSGU4TyS6dyE1T1rSY55FtdtMh1/4ZaIdC4j2RzTtwzbaZu/PogtMFPcHdDZvB/dzrwfYbwfywX'
    'uHdYrNRfHjm3I9/ESp3m+bQRO6AieTjaTMUtK3BXwux+mm87+vrOpN2Os9bYr6+YctjB5GDaVhb1Lwd7oC8RiSoCfu/sWnr1O4Ds'
    '4lqLa/leIbY21VO615/7v5O81FF9CsUAjqCtInunjqYd+y1V7UJ1JyR25yFBuZqV38HPtWD+tIP7YMf6emSCl2sVMedSSQ8xvH0R'
    'MTrHKpGc5HQzTOJlE49cRYmPhRh/FEJUBN4vgMx4IVKUZlBW/Zb0rfId3STsbOUtVfINNovccHfVerc05YQmxW/Km1fHdK7xlM7Z'
    'l/WYR7PSZU6wIwgoDj1cDIK0iV3lCH5cjGfG0EmnNGwVRyIEsbbMt7SSKs4Zanop19rL+TWCmKpxDKk5se78y8auJNFk8JZnH+BO'
    '7wCZItOFq269tZkRv/PDIbeg14x4Xf1G5YhCS3iNstl216b8gLcptR9VTfnR2vhNe+ORXumg/cP3W95JhUA41I5pD5ALSTbfgWY5'
    'KDWJz2A5v67GS8uOacH8jAafORV4LLCFJfBQ0JuErdSRMVIYKdWqq2s2sfry9753VtqwVKONaxypkzYudPVpGw6p7Z7rtsefd1Q4'
    '31jhnOdo44fjT+vJ+AY+yz+qsx87pE9ev/pDS+VW94ONddciljd3b/CRKnC73fF5+ZHP9VrbPIJDhiPZj+07jjXuqc7exnp2Pvbp'
    'zuZvdzd+q04SZyUgYRSFKYVaji2bfkks9iRECN+hMFCnco/GZ1XVlT96a5q92V6e4GknofbRTH67z1+dy1RDn/TMy7Ft/bPoeu8Q'
    'jrb7GrqbXS/1YmM2SmCKZJ03cDHtZt/uU1fJ7lCbaH7m+KPKY880vCSmmRus3GiNvl5q1Jr831HWac5ATxuncgPcy6VeHAbN27I2'
    'd8H4+fBxpyBIAs8+6VaVKt5o8Fhnw/df0+wXL9RXxfCS/rl37N9YFb+pZltw+5VtpjkEUb1riAGGMQ0lTlBswmdnBkyRJygVqnM3'
    'C2kCILEZ2uG2tT/Pl3KZvRyfrTYzM8V7mq53N4yINfwEkfbOKj5Wwz8u7vx8F9ne7voe6Agfq6FZwR3ndyPNmrggAltuAiKYcURN'
    'XOpIJydmEwKlXIY44f8dCRRj8lzMlaosLUWsBnMxl8IIblKNsBdY9VyUREUbSt+zyrSoqN/dhfO748DB49CtkyWIbsQUtPYa33ub'
    'WOyYLhTibbmajCNIahCNFZ55i5t/4nW6pdpzAgabPYicuHsdHf1ff6nms/yLB6WH9TX1UDGln6Wz9Xn/iM5Upxo06h9nbHeUesHD'
    'Xmuu7x50BrW5hX96KNKx97GM36gJSB95J3DZgxYY0M1IFLdIkbeAL82S6noNyRc/U1/eUzU8RdXtx7XdOkNU3AsgNxOL6jTIxdXk'
    '6txLsp2wLGFGj//5z9d/3slOtl1cQIyazGc7CJKIhQrOYS3wRqaMmwxGYE02N7cE3NTya4Igy2OJktleL/vuxzdv+857+H1ZcLu9'
    '0c39tctGt1gw+bFcb1dIR7oExjjTjGqCOqQEyd7Inswe6D+yfx9kEKiw2yfz88rlszRWnP6j2X4ve3GxnE/LK5wGBJNlb9bCEk+z'
    '58MhHDSfv/5eSz7sZa+hu88gV0/mBYI+1NMZ0mLW+bZcjs/mNz6UI+lr3/dJMQAIDTVmElWNYHImcUwFsmUIAzK/7r15/f3X3/z0'
    'Fzx0qgT5/nXJQIrPWVboz1Z1Mb9G/eg+XoLxkI5qJe7DBV+8XS80IuNDNhpXw2W5QOv9bMum2y1jNytk/ItVX0haEmmF47bVz463'
    'jPpsneCWOHGtfPv9y2/+8ubtjz8xRCvdG31Ml0Vm4c/XBfHjVdd/XSxl9b92c9tE3Axh2u8N8gHkdoQn0JUJlZVZoBWYFDRAFfrH'
    'sfJYVUpyDo6U9GArOypjpOH/Ie5N1tvIsjTBvT+Fia4MGCQQHCRXKMCpNVAuZUiiWqTCI5KiiwbASCKIKWAGDkHSv1jVpmvRX331'
    'dfWialOLXHQ/QO2r38SfpM9/zrmTmQGk3D2z0jNEmNmd77nnnvlIjm3nUOaCQrQZn0NKSw2gKTgLDQdzMqJkHLIDpp75raXQ03Ag'
    'TqTvZZy1IQ0AL3O20mGNLlaOvkpItzwsTi9qa/w6rFD7+R//3XzgWW+4iWpW8pqEDqIpGgTANBjRBPFwwPY9saz5VrRP7cBdZF8t'
    '6oMFcR1o2IaRht8WttgsK8THFha2osPPw/tX5vlGNOd1jVonS2aataPAnCLRubOv14w93Zr1RTAysoi4Rmoh8rF6Opy4uqoKcXL7'
    'u/loAo9faBkJacQO/Esq3SsL8w3bd0Ph96Ye6hF98CUSDi6uQy4+9o+MCLoiJzGxk1XQ8E8ZasqL16aa1PcDIFjRin+Dy4mM2/1R'
    'W2wuihElZ4FzIluXNOkyOJqRawmtgk5vdt3Jl7En0JR0ND5jSaxRle9GOhJBxrInEyZk32P/DvU0lBYK25OPeJklgpGs74qV39oW'
    'bG0YOj2nscf7Qetx/aDhohaV8CZLbQsJZZJxLx4zVLRHrGa4uglUpLnEwtgoAiVTaObrZMohRppy4YHD4/R/dOjYQ0Vox5pJejBx'
    'Cu+JTU5zlMJhTkZyFQ1SusW6NIcPBPK1Bqu40knG14Hik0XcJbWqaRKt8OdFGe3iHm0RLgwcHaIe6CG6kamWokfhJef3FathzVtD'
    're/KLFmEQZf1Oa/+NlHwk1gXwOPUkdQjyacZ0+ePlx/Vv6YNw2TjIwsVVWFJDRhyw6Q6P4UuhXFZnrTtdv3VJftpYi1i4+2ulNcV'
    'XNlHk5bduRvPsWfSHJ0CNf21yYXqpZHqB5Qx01SrD0sw/lWN97ZBctHI1IQ0wfiGqXrQAkjyUUCimOll7DySEDicmzTDnpFZ31jA'
    'wRAQ3cSQVIu9KzqD+StkC/Vm9OYoaF8bFjdIKQyLwBzBF3k8MZgIIVnY6YdF4Jwh6Bsr5R0QpUVNIa+nJM1oSIYcaiwDrYlk9GJ7'
    'h407Snoc3IRmiitOvANHCL2qVKkuifAz1BA7nROdieS0GJIcovYlFQVqUgFL2j9qRBPjhpgMDYBYxsxGdEraTZ/dQrunRFOpezu7'
    'KQktinj4Q14aVqi77lg3YUwoRVVOPX2PHbD5lejFR1kQL/QybBjg9l/h2s5zfjYeK0FkywHKwLjujqYTIvtrS4SZlvjrFp/bDVzW'
    '6RDp7D59fPOCNoOGQXjenWwBZa7SpG8Mqhs2CwaDeDDYOiM/6UiiYwSH5YpRgQq+jpkZpQbZxSuJCFg70/GWf1X6p9yym2a56MgU'
    '+nbyQrekJpKYTFt0Q7ElbminzoiEho17vUBZLcxGzrylyr2fs+AfGbmLqBqwabAJ4b4JPBkjUOaXMAovQhBsD5oL4bieI8dZRQYr'
    'Jf8nozZblfDtY/aElxZjNTDchrGGcmI8sC12BAVGA1YYjHC1s0bDDlaz9hagX0SLcslgH2L/lqkt1Rqc34YwA0ciXKS1mqQ1Tss+'
    'OnWeGreseu2jOcPUM5z2fWeGOUnVouioP81OPJWaH9zR4lLLnMmBNN9vQpOvgDrhZfYcv28K1Ev4vZRdDnLcdG8UC2nm0wHn9mKR'
    'b0pJ/TARu04ZmxQ4b3IzsaVMWLJovnkwbWhLbVFITJ+29IM87zKXUFOu970YL5RTC7LKhsctknq8uIMToEubZ+hscLaGfq3b8BiO'
    'XnGoI5MQP1dM47Y8Mhv2d62oQKAxgWFmPtFJT5qo65QApTlLQatrMFKq17pPJsmArLFuolfAT8WHwDd1m5DPi2zDfKfLz4dpaXZD'
    'FhaIwZFeZpEoQLz0FkZvNmNTWKX21duiNOj0mDjDXNJkGR6DtmfpswoBXPQfy1RtuZItlj7FzFgZqUHIUV05ZBH47sza7cUk4w23'
    'A5uz176vzKQpIvO+iXU8Awoqtl+/3CgGuGUr5yilVIATTLoafuSpLNyJvYm/Z/mttw5gPYhM96U9N3U7nHDYvPUTmb2KxdujSc60'
    'Zq0eGBrcMA+urKCHWBqu7wClhG9lfQoiHmLdzW9dZQdnrTnfAEXRnh4D4h4SNo2jc8E3pUoZEUueBXtpNJrMkCcK/JcET0IDlA6R'
    '6JQtXVEC3Dkgi6o1TTkVwiC61BERFErIjhI0Vm3dL4A4Kyrc0bBZJVHh7IO4f3Jg51VuIr4yYPfbiRWJh2QGSuWL3km2l7NbOhmY'
    '/jmBNScDYV3oBUDpSXi72Zv8Vx0IUCcs06w7WUUl3GiQMpYaFUd9ZMd45O4YW9svL+BxB0GQsvldtrWH2/skvGLVLN8zdM8NFxlJ'
    'eUX0fyJWCcnhUAFxxVm89aftj7tvdt6v+U0NejTCXAzmqy47X89sQZd5NZwF4tXep+fpBMvEa607TRhizxMWMlvIPves6mIunYZ6'
    'JoMExxeecQjs04QQwXRM4/LDEta0g1a0sAd7HI1YAto8ibIAZBcCrfXMizKgJwtBDcAUf5D8S14JycoIv3MRPPHKqapQlVbiOFjl'
    'NzjHV1DCqz7r9400L4hpqhYTZaliQPIRE5G+Hg1SP8uHwMVWdLgj3IF6RDV0dbsmRowCkNmVmBUfRhAFqwNhmNlTkA0h6yzm1VaN'
    'VoxPkne+Khx3WF7twkf6QRXVtM+GU3SvTPbfWm3NuI/4UQQj4z2jYosuvE5YK2QZqhD5++y03n9vYJFA/cRFxhc85p1Y3gYyvYNB'
    'EP5MYm9aQYpakAVSqNQT7+BOE/VRlZsPXaKEv92yibEl0hr2+HaFPtuONZgdE848IOQck+32ZBg12F8SEctM3TfhpXgUYptAdH5c'
    'Ep3X62vOtccTYR81zcOaL+qW1+9ZaGzUQUdN/rVW5NXUjJPNf5W3I+73xEYL+xbAsBE3H9bvL0lWqTIc3Ls3sAaeBrURlqLpXBqV'
    'yW4OZCjIGVGkbGc4aUNj9x0VSIRFfPUYmW5akrUM9lcOQNVKUE2On3kHEqIRBbE2S8E0oXCYCTLC3k+ZOgrBRhZb2TSh+qusHyps'
    'GcSOrhV9eP+9WCyI+APieRMfMrRb0NBP/VF7b/ScUPqTx3BkoUcji/8AHS6B1gTazc2AGsNnbN1HFmEzuw+PJiH25NhRLVo7+peG'
    'bCwBGjVEQ+PSCEn6LIMTl6eyuBFNt+h1hzoljX6FBBaskGYaVfTPVrHtJK4sKDnvsSLYENfNKuZtmxv3VDAIUjTszqFGb2WjZLwh'
    'F9Xy2jYcldTzV14W4BbWSjmobbMqARMVmI/P46iWpkMgOLpF6AJjn/trGTfTm3XDdfoAze67aN8JqABbk5Sv/gITQNdSOkwkHioV'
    '1jWBoeethHWVXsyTlgQTV7IuyDJVohPHw2NWKI3GeVbSAo1F5Y8LkcpxLjW6OfgyYxE4I0LUbMoDDA2lzoZESoW9nsnCFgl76DH4'
    '0ABOx+xGRoc+VgkyN1WQjpWzXY75HMGH6QfjbdJJe33NE4mvD6LVuvg/+V9PvK/FYFeH69nZcXQx6A+zjYWTPB+3lpbOz8+b54+a'
    'o8nxEvR7S1RiIdIMcvevfrhZ0PTqeHpNT3BReT66wKMkYqXObiI8XLqHH/APld5EKASswc06GkZ6ORttaHCsSET8SEVoMjhuylBr'
    'fEzELZVqPqRBrxFpQtdcvjHNjxafNmaIzam6J7NDg4LvfUlegNkkOoKLBwAqoW6u5N3kKJn0aFpwG7ORiE1QWuZ///S9E+CKRoc7'
    '9B3XMrqXLSTJA0HSQ5bC4snBXGeO3pcQwVmSqTFWk7eIk4E+kPbpIDRlq9jdzby1g+jkF+zwT4QBS3qJOaqtdr3cjLEAOoJmm3wW'
    'W/ZouLcgrSQCofis5BcgFIjuuOQ5amrCXPISto/XbAmOG0/wTP+vw2/YIRvlJBXtThKJkB3T5nHp6gpORFfazk4zH/Ghp81U1+ax'
    'RiEv4QfP9ty588xiR7xLQyDJYBcIbJwwDp1Rz2MJTF7qEhrQO3boLh2F3OSsd5wgH7n1wFCp9D5W4YX1LAfpd+VPvuXGSnfMQZiL'
    'AgSDBtZDsg/TSi3gOa+8hCEayhry1OQs6fUZ2bMgFZJVSIn4Aqd2a87tFTq785NR32nuYhtcTsPR8NniDCxICw/VCBuWNIwvaMa3'
    'zlAkVhrVt8GxzdEB3QSdU774mYpeWY1GNX7XhAqOlpKNKTWAkMT/RRfatg2fAnM0tWmwOW2d4188dIaOoTlfZeBjH06bQHpbkWRK'
    'YfuYfd6gAzaRMb9hspgT2DAdtBOGRWG/WNbNyrJAfWRXjo6nXadmtCtBXluSztKL/+hN2YRSLzWTTdt2xeOT1XozeuXCz2SIXq6x'
    'e0BFaKBzs8htrLhEOUfE0MyogE1lzepJgNbLm9GCRLxdwLiQzJLwLTyfuQ12fIYST/Zk0adk2XrwB9atu4ZZhdlnG3vAiajezxO4'
    'F1MrsE1mlTCb6bdTOIJnRmHv8ugxQZThwHHwdwal+Fn083/4T9HzFndCo5coJM/WInz4P/FB3jyvs//qifRmQjjijQxpONJxuA+s'
    '7ydYX8hHC9Ib62QX8HPB8YOi/vOMgDHPXY4a1w9Mh7h54sSa8ovg9O2b99tfXm6/evbp7d4uuxbIN4P6tQr78Ay7ViKHwExNyWCK'
    'oH0E1rT2tYODimqs/g0rooKpPrsiFuC2DhvR7Oa+smJvyPVuwlUUeX9mPeG10dkh3vtJ/s7Eafe3wUSSi/fpXBwwD8SZAjn9oBhL'
    'x/vEoMinfYzsoC4qXf0or9imxeKh+H080gg7U2tZDZu8vvqFIHJOfP9KH2/qauBXr4rv/hwnKwusNgeeQXcjGhCzhgz2g8D8Gk7/'
    '96xFeYPFYRlHU+i7AHq9DFgCwW2nuR+SPIk60wx++CwANojXojFHjk8zkDQxuBCJo4s8d0SR1DU8vAkm7ReQiLn4Tevg1mzIrhwS'
    'bVpD8WoZf8fxSuOxIXhzs9nk/oKI/yZ4/EbEkfH7hFcRRCNBIm7rGO6F0OhAZOoFuAeVxOOu9XuIKQPeUBsR3NfixmhD+S3Lg7TP'
    'uNO0XSLeoHaronJLufGWGT5VuuKFpd4GENSVY2qf+mMcmFBqbqSQl5xioGaEy8GwJD6/58YRhAgMRyDimivdJ89zoSLU94DDx2XO'
    'UMGNZlAajTE5mDWrwoxWi1NaqZ7SqmOePQk1w7uN2OvP86Q0x9qOlxIEGtXysL1BH7FNFZovAMqRBRQOk1497CMe9oq3Ew5/0YFR'
    'q7VnJipXpi7ddN28I8YM3LaEmMvk6IiwSFCPRDGnq/8TX1WWaJDELI4ik/OMbrIBoQMqapq2ZdYMx5TowImo0E8atUyycWtOBg4l'
    'IHkQvFA3GPjeyLQdn+QDXnMZt7XPssOiy+Xbb7+tEWgWuX4ONiy858uddx/AVBIbLkJUhPvZZdPJ+HAdlpPEwmbJkMjzv6vjOPqt'
    'Ez/LHw8bEpxzCW+J5sNLhzmev9158UfqaenH+MP169Xr14+uP7293nl7/fbNNX/73z/t7G1ff/i4fb337Plb+vf19rOX13vPd17+'
    '5Xrv1c7O3vXeR3p5vffy+vXH+v0l13Sadd5Jnlw4I/MSgKakPXMUabz/+fPhgy/7nw/WN68P6kyYfv58f8X35zmfJBBQxMhS7qEz'
    'zsnMrQLxm5BILpifH1iHLrQEAUgIDttQZ+ZW7BsTOVynUWSfdw8ebNX5UQXAFkgThCTB/3pd/dW2Bj4mAQVLLjdMjHczRoCRXDS1'
    '2lolEg7CO5tQrHi5Z3J+IgBOc2/7z3tf3u+83La+5y4iJRE2l5EYcl2CMmars502AXOPSEqxs8zS1Mt1y8o+GtZDE13vT6Afym4/'
    'kfWOWoo/73/e3/+R/j34PDx4SP/Sbim5gLgJvDG96J+iVd1k3v04rxufpZrFhlEh9pFxOi/N/p6Z/fZbYtjfmwUo1nZ8Twc5uMW6'
    'vjccps4EUfaH2u7Ao+E9r7kvw8zV/5PdNvVhd+/jDnhDs1IAw7j24EFNG4/r9SC2rtfOG7+d7XelNu7QxG5hKG/+uO2/ebn9ttjq'
    'Tz/dodkXtII1Z1MFqZOsmzOuWzPNmiPLhVr8p6mcbxbXDmsscD08ZDknlwG3eHjIjOKh//Kwtma3uDigZzUH/DYFqjgNsBzoWU7n'
    'uj3NU7rF6DU8aYwXjs7VY2IDyDbDj6U8p9tuc4jRDelhCy52Qo6CNMU7oUvZl8A2B13x4b6W5LgfDNlc6OZAK3rOdHH9c3aA41OW'
    '/NWp/SLMl2DnnQdzZg61fZXrMRt+eG8f/RbXJ5t0an4PxZaff6xo+LNEro4i+lGqSOjx0/Xup+f0vw/X7559/COhRpG7I5xmoSnd'
    'Doxv/f5VHvoL3tAdpQXoXqr4HI5am9YafmQKn24IULBkBYliR7PWizGRTDokCUMu2BlsxEoJNfc5/HDaF3wxQSwbH0P3ewbRiE/8'
    '2ze1WWgJsmVGRNSYqcO7sfO2JhDYe/jwpsns0CISXU/bkUkExAfK5rOSlgzD85B9VPyeJN87YivS8ByeOzCcT4fDjFbeLj5+Zes+'
    '2ncQAXa7LWKtO9QixA8Tg5gFj/hGhOnpBMJ1Rbo0rnopm9LnoVz1QzHwatc5SGqJWu5IwidvGwxYzhqePyyABGIcov0qIJKifuau'
    'AKLYupZ3rghILDaRtaZtDUInwfqilk9q9QO+G3MW9qJgPrGzOLDced51TWtgyrQvuI3XLu/6N9adBHlWLcfnsm4axB+P7Prxmu5y'
    'usI/X3MT91c+f76uFe2s9lGJOU7Jz2Nj0xOpHz+ksYX4pzPqixsjkORKHZF668x393H765m78XNC38NCFnOMGErJ3FD9zA+LT4Ph'
    'SlhcXtuJjXBuFFJ2ySfe2LmdRVe6OC5LTdpxhN1Q0/HE0DLRNa15vQA5PpYxo6hd8+1YrsxH+7oWkJn7vOXoFvxww1R24zeDXlyE'
    'P3a5NZ4uD1tcxlc0VR81W8hQF8A5CzJN3q4iqFsxicWYfTZJdu+UReyrYKTuK+FzB8pczQKq3Et1JzCBesVr2cT1ryKX/SMxi3Cu'
    'JB2ZUWCmpow2rqR3TV8Cla1B5/am5inG9blkZ+77GVZRnRUnVa/nDx5ddqGhYM1KXXgrdVGfTU29XvWJxNePKogrr2n7pdiFudIv'
    'QAwZZpUvK/NEiN51AjriWxP7+v7VBXvvHj54gJ8PHjjEPmvUjs+seYMQsKS9sJDLeQr9nIU2EaUdseT2w1A25Vz0/WM6kywm9vYW'
    'qti/uu5Lsr+18oIpqUxU8aFcbYYE/jykV7U5O/fprb9zO2/9lTD3WG3ODF5/rFVsYM3Z0vCiMOaY1QTz934r4l7SKXRqPyPLgtmj'
    '4HoNDkoFwaavtDIHZzdEyvPRCKm2wj13/rxCZbxVOk7NYgm78nHjwMiV4AHx85jDNiBGfT/E3EXpc3w0CGLQ+xiQxWwDXa9B1x4v'
    'D021WcAXCrLrBascEXBtRG1GWFuSgYKzCBUESFKgqaHeryInkWpzgGwZSL9XcxH4/Q8nq3I2WcjUMsKmAgYz2WLbojpw2SEPH7w1'
    'arDWAzafkAJeDBKR4vvIzO9exKseQNW+5RutrbZqtQpYDIYf1EWP335lA6sVLcxvwpWOHOlNM4eMk+/ZRa96mAMGyyj6M+xm1std'
    'CrrexEkmRxObUdkz0uhNjNgxGxlBI0eBFh1kmNeGyZyKAQZcQXEx+r0gjlTmows+Gzo1+agpfyQ1ilsUwWreMYxNBuyE8+2igCLH'
    'ANNV98vPWryqO23ba64kyP/Kk1e1dMpsbW1Fy/U7g7KFnw3bkg23K9/0IDWiJ8ugTWcCWrD4BbiSYfjnsrxrkayrnFNtpHhQUa5e'
    'KzTr4R6v1dLezkFHngyec2KWVwzoB6jHjrXmL0VZGeBhZv/GvXrUuFGGkT9p+HuBN1Ug7HJ8KrUhTbLo9d67tw2GD5MOUIzOce6Y'
    'TOPsgN+PRsfE5b0cdRA06IfRxE9aqq2hpdg5V0COrpnE2bJwI1pc8WyY+kLEUttMCGv2Xy4JM1ycQW7hITWxvtTvba4vTfubNQld'
    'ubjIhsuFiPfzIHvejYKQmr5ewN+/uoe6b7sI1seb671NdxusL/U26UJIs05chjUIeMab/s3gHaZ7DhOFZHRyzFnAGGqo5skKIk+0'
    'ItGJnaziFxGaN/vSzoGLjQqXVo71ZhaVpU/JMSROMkA+USJ1ktc8YqJgeR1uDtcKopsbb9CCVjd5b+qF3VyP7L3gbylt5jrtqm7o'
    'w4cmlp7FhDJmU3etCA1SV2qYT95EDIaGct3s8uF6t3e2aSa0voQnL4IOm63ZhXLnDa3j8MBEG5BvjbOTqNkddS7EDufvknr8z+/e'
    'ioddM3o+JWINwRHgN4LE1sgQ0qDbDmEakNsUllFyjcHyFDORTEpDmNu0Jwk83MULnm1n0HcjOInxdMxW2nSIXk56Z/CdoJ7eUt10'
    '5+iIeNumMw1/8fHFFyZdQRHG9bI1FJRon+iwP1oVVnr1uycu1yYO9FCyHWJH6Rv9ePiQGUKTJ2TNFT2VoqdU9Cn9QUFO0Rr9juO/'
    'LV9sv3z+9Omj1eXoRzq80eYm57RuRfpzLcr3h5wwk5+XAzdeaELrsY0805l0Hq3iOF7mxrLdjGj54pX+35qPJi44Z9plbpKJ2JXZ'
    'p6H8GBGH9zua4HcHbmxPnd8zF3EN1+0APQqZQIHN89TTki2xvcVOhx1dbpg3bLP4eyKGwpPcJIPnoP1JX584cr2oOSWEsNu5nkQz'
    'Gp1DzPR6NJ3AImR9PVpZia7N63d0aiVSNn34zr3flfAlMWYRrQRZaTiQjxZ7RRTXX9IEUuvFaOUPT5e5nT9QO6bEO8IMJ3zTrBT7'
    'cANmLR8na2Do+KZCd44FK2BscWGhNWuKoiBWJ8CG8azD8qJuU57FhglqX9yqQT1x0mtp0QZABzAGAHJ+eVa7kor7AwLxNohMPa77'
    'MkjNkuI2JeGI/njg0/N8iigqXNnxhWfwRpMjBtkgteklMvOYwDNFsMGtg3BUNKT4EcxoL5YfLz963P7OUGJ90/LKk/gxwjuZhoMv'
    'T7jm0+Xqr0/ZZsIbj/9xBZ96LLop11xZ5c2o+EgTXXnMC13dMr4/lZ20dGBFG6urt5ShQaw+ER+DQhnNsEAHS2lp4x5S2vCOWeHH'
    'sk6ryyveCndmrnAnXOEZX56W1r5TWN5w8TuF9Q0WP/j4uLD4HX9xn5QX3/+OwVYtbFDm8S1lsPhPZy++39ZjmomggLCIIDuVKnq+'
    'IpFBGHS5P1pWRxGn2/GGZS9wMdPXhBHaLt27U6KQYzBgkkMR0uYm7oC3OmCT6WPucV5dNSnHgoNMG/tk+TsAi12cNNx6oQgKC5gW'
    'AKCqUKEzQIIgpGIbutmlxfUM6yUaG1KR4jiwFFwXiKZuo7Kx4MMIki4G/e0MB4Nv1sxT3/5ufXOB1bcdjdpV+x0inf0uGYzXQN+u'
    '81M/54dNfjiWhwV++Nt0RI9EqXY4NmLBrh5kFQ8XfswfRKfrX6E/fHm/C95CPV+yzkk6SLImKEkasjAwGXvCnBPRNJ6MEKmUroRB'
    'H64xT5Y4n7C77z7eubkRk1Uv1a9DGpukffZdzJCuyWt1Mh0as57D9fPWZJP+4SVtcfDsjQUQgQjdA+caWemYKXAqtol/J76XDW1a'
    'wvcRvDMaSEAj9o0bHJFR+xijj/GHCUyd2ItjS16LS8d56yzpw92Hv90sLCn1SzQ+t8VdS20auxnL2B/FIO32Et8g9ErR6aSnDnHe'
    'KYT/By36R16HWO5clgZIfqmS4hnFuANPe8stY5KTN903g2N2FrOJLQ/Zzh5ZJps8hRtVj0sjamFaGl8ocbVbo6Oln+OWGip1e1m+'
    't7GwvMC/nttfb+2vj/i1eaj390O0Nm7RSCAp6bBrVefiZoEmyz8vseYoQfD9YRL1ung7pO8Y48aCAjqnzdSCnfdn30+S8Umvw8l8'
    'aG/Wk9ax9+YtK6WGoxfs7P0sG6edfGNhBdWXKuv7Y7VNea0C+UXTSc+6lc05Dbpk5lSp8cXC5jr9ao3RLH4Mz2hiGDkeaEA682Uz'
    'bZM5dMmVQHnMwK/uDxzv20jp1+v3MXb8jiYtDuqNBmm3ub2kRaQgAmrhp/FcQsPeh6WgsWIv2VjW/OJoMsBfQgDRBQ/+Ev9yH5CS'
    'zNrsJVd1PMny79PRIMKPjYUJDWUB75Ozt5kOyhTRUUnnS2Y1/bEtBRu26T3LxgsEMxqxgO1QiqfW1E2rPKF0XX6YVCEX+tdDFu6c'
    'VxzyMg5pP3mszJo4M24y2/mUL1q27o+TnFA/UsqHnsZ62UBRmExeEE3/LI+X6x4zdNTLtwdTTOW8EZ1wFrUf+N/XdY8zvGAbeXzp'
    'XBqd+WQ0HXZjvI0eREjTdq6yViqyqS1cSVWvfAfJvvCRKtBU16RBvIA0w5oHSDY9VdaGNrywRmEk1uCoMUMxvLWZcTO14rWS8Hwk'
    'ivPpWKPZw92HBeKc89yYuaN19rzDWrRLiFY8No0QjJ48WwN6mmFj4KUFlIWGW1+TVhp/aLVXnq4+ZQJ35dHvV5646AwJ0kJR/dXe'
    'kHjvleZ3vaE/FhErb1SoagB0PTj/tPrpEbutQsX3hitYwZC7xgK0rmAdG2CL1SG13jCuqUHWVM9HlX39IJDFDzT813EKJ0BzJDAq'
    'XOAcrbDFfqKEcFeBC6x9z2HReABkCAsNsRWy8LC5U0nj13ihie6KKnjJvcwZ1rrikKFOaGpaFRiAvTFrLnI7GtKjJ8sEyk42r14N'
    'T5Wlf4gCJtsjTIK1D9XFcGmWUQ2nhILBfDfpqrB9slkunJ//sLz6xIz7nKilqJ3m5wio+OwxxnncG2bf4IxILAQV18Jdi+VuJtZB'
    'URILCYn6CryfDpzpmiv1kWkIMZj0Yh9YygIyW460HYh0WU0kvRhigskIbufGyYQmCEHjbTYR2zsynJKlB/e4Si174zUcTPBOlAxd'
    '14ntA0o0CP1SdtHTvG4KABKndYRE7KiSZ8wtrMnycZLaPDml8h/ef7/0zx+2v2cbaBoZNZUj9L8koocA1mET9ECUV6bMEeyx6lWp'
    'Ztl/yE8ze29oROih4NiruN/AFXCA6qEI3lQVA3RYiy2tA2tR6Y2FeP/HhYOH9YWl43po2WKGipAl7D4+y9ywNyh4rNMbdVenf01Z'
    'CdBi3M+d97nnR1s2f8F5EOuWpR8dVvkMtKJmeBiYh1/CYoRstooFGQFp3kcr9vLGyYvNQu+iFcudnNA9F3Sa5TAhSEr6nJM1cER3'
    '3yTXqmenXvJED1y/xfMbOdBk5PDpNqFCfJ/uNV03XpiiMYzdWmJvsTBgVxmxtyw9ITI8pT7OW8XJsKKkOAnLDRgdG50u8CvEMo7p'
    'TPQkdbx4bU5USy2nSchizrnZm8C9xbJ9Hzg4WOjdcOH5NrB1RLPDXm0XotEgwuzVCK6qdKFknR4R37Sc2aifZAv06uTZMCu86mTe'
    '89Jm0HLba7Zd+NbzvvUK3zLvGySop2mhADChV6Yz6iPLrzCVy989efRipTgU3D1ejRNa8j4vu9a6TPv90Xmx1pSzDxS7m5pKYOT7'
    'abESLIK5WjYday3c1MBsz6jPoeN+pSydK/ojkfj4mqd66USfmagI6IkLpUcmTPFeMFWL3470MMi5k1+0PN80kC6GyAEk4dprGGcw'
    'zvIiNtl64zrTFbjev1bn7tWlRxEz7RkDaehJ9edBX12oqOt6wQL339w/6t/UQ8oTpWSikOjiRB41JK5JvWgWHDoR3epGdDdHIs/F'
    'wTdmnO8QtObVckacBipZxPJhEh/R8v4yodAsHyGHMX+pn9AMk81TybvpW2mGlpF3cQ7CPsZoCei72WzSRraNYYTZU9fqnf2FKprt'
    '3b3ZT3Mbmt69oa9xRqroKfuKnj6Fy/zpw9yW9wt+JAd37wnuLHPbBoq/e3PqWDW7OVyLd2/O99WpGUFem0VHeKjNrvmsFhzIEzog'
    'E1w40aQlYjllG+Jq96o6R0SqGL/knAzHz6fX9uCf32qvpjLGEXrVkEDITFvp1VTCOr2BnaUnpCEiiAkmsMJNppYwdsPSC0cPht5y'
    'g3hJ7OEfvlv9TudET08efUfE1qMn3/0evH69CgH5TkreWh0VN/Ym1H+qEWxBA/qB3fbh6lQUS7E8yoi6S/IpK+Pmur44qsonqpuO'
    'C/eKsjjTwZvuTP8kx/Exg75CK9g/6/u55Z/y7WztD6WbtbtdXXPcrL7C0ep/lQOU9TT8EDMMsKP6FR0OlQoseiKJGMsGM8Cy1gLx'
    'FomASVjKydLxFu3JBz7xvNiWvsPTjS3xpuu+8KOIZU3tQ2+cv86jSmdprNB5hwNL0ztBufGmYmAE7VgBi3fyqwoZXngcQRnFjlTW'
    'S2jFO+O3OSo16MDXCzbRRa+jFedaM8ery2hjCQxyMUkfwruNuopzJKxZrlf0Y0PnHfVHo0kcO+DhNVrisXDEnolEZ8Z18E9ZgWeg'
    'x+zvGwuP+YfQW8vMToGV2Vh4/gr/Oc7CClS5UV7zWj4aQ4uJbvG3PcrzEcJ21yacrZUj08Ba+bX7+aeaeLmx15C0ZWnG2j8hrERa'
    '4f/tkAIOQ97ub8ofAXn68QMN/JxVDVieB7wCN5gN5KgbC92LhEWSzIBsmUbesDyVq+FDqbxiy0N7KB6ams9lEahFXQ4hSt0HKfY2'
    'ucSoTatHvYu0K4eRPr4gfu9dwhPgYfFIni4XB4GbXNnE6u9LYWtLZmEqhv39pNelMePpmH6+GPX9ZWNGz1gmMwiZWXG9wwpsTFBN'
    'uAFAXuGSnWqA/KZE2GOsGdwXzPUw7VY6FyzQi1XFUajkMxQAjGnGwkXE06NFyIKbIxwtJ3ry+qkiL4b+TeUOojoDoi9jeY7Ursv1'
    'qD1Jk1Of2ODxPIQRYJlbOmHEU5pRUJInobRY3mFo6Sigd4pwPqwA8qFmljXbvAt85/B+oOtmY10WcpzYu6EDiamHCRAtHI/QGW4s'
    'vFrFf8AL0gaDSCeAN4E5veICf1SECaUOrxynQ43g/jPTgVHdE9if1Ko0C9AriGW69OoTtTfhjq/JNqzzxskDW17eeXFvKg+alh2b'
    'R5+A9UjoHIQXHwBZ3XxiMdVrDiys9fG6ZvaCxybr6TG25ZvSzp/QYI0Xmt1UZi9YxdVqHThjCTcFE5S04nplzLTB5Jp1MOeytFmP'
    'niwbCngjCu6gwo2R4A6SWrIc4+ddH+9V3Eorq9619NQDxmdP8J9uB7dTCxyKrCKNNToW2xdUZ4ztQ11ZwbZEg4Fs6o8tWmWltzEd'
    '9mepB7V9urVR8nid5fNqAiJQp3JcuGLDrtaVY971pAi3UO36+hXOr7+B+2uBv7qVSKa2fEmRCb4TOtHeUZxTcKytlNNUimQ84YBb'
    '9E6Aom5f+5k861xnWgecEmemomucM8979oo7nicWUtYWLdp5FRqxgFvmI1Skev/KXniPGsFctqJVGsEjDsuHZrOT3hFrZ5frrGxm'
    'Je/NYZ3ddWg1ZSAz2d85DrwYuHENNVvgMwwzHXBnLu9tvrglv0/Yw0pQoriniKooQ7E5f33B5VUgqLmTFLNfkGJWRTzyeMUA8/zS'
    '21pw1l32ptqx2GfoluedAU8O5a4mg/KFR6hG+k88nL9SxYp4OL84mzmeyRiI+iUrG7lWKZUpgF+JVy3gnBmsa9lT2SzXTaBGznaO'
    'jA3EvaILFvu/FWxAvpEcN1bLUXSsszqWslmIVbF47oZe8MWndV/VwgHnCIy/kTBGt/a33PCi+blmcBhgx0P4osrBeCVycQM9A4Zg'
    'TQouZbwoge1VFcXzVGxPfrUBjROZfeNYKO5SSbkes2aB3u+7P+A/hVND8VVjAucYFwWIYEZnv7Qbi3Cqfe5cx54kEISMJpcW6uar'
    'vApxA7OBT9yul1z5Ar9Yg7m5L3Md1/Y0vmbo0FoyfbY+1M/658jli/jIYJKd8Qf87ugOQZJf5DPl4MfnHJyGI8iz+dgRklywwQ0n'
    'o/Hi36sBTrNAX4yHx553mJjphfnETDjyK0mI0AL4iSzEC0HfMmEdeSgtumSRyjTxrOvrJdKmW3Kwoa6abS5urMsQ8Fxyb0cno343'
    'U4OoCzrpsH2xLdolV8OwMZzMaxLf3Ym/u2cQglmDengZ+W9WwaZ99/tHK9/BYP/J42V4dMzi3FYfL4ss468de3HBim/iMSgO05rx'
    'ecZ7sNx7aJCEPCgWtYAWzXTKzOuuySBYAAd5ANgpJbTCkFcZEiEot8rlbF4w+RZIZWtsln44WzJbxMXAw1WS2pVKEe0vWSHPGF3N'
    'YFietkUowiTgou6aywsSho6mubHwae/VIrFfyLzWTfqjYQo7hWxha/MbWImbZjj3hrDO8EYg1lneTPDmo//mfPwLbKlDv4WX8tG0'
    'mPyCBuHyYOrTGfhV5t0gadheAH9A+yFuvEoJjnf/LiKFlZU/LDN1c0K/nzx99FQ2enz8LgFaz0e0LCuPH7NwbyJ5ScyjEEzuWW4v'
    '8ySnfWPh98vMJB8RueE9Hk9zKwYADJmhLemg2SJaN9G3Sj4aScLkKlucBO64Pd8Ux71Jkyx/lvWS4CWb5+ijSpNVDi9GHL8OBrWR'
    'EgRuCnxqZqlM71J93LTGK5gpb9rfzXlbXZW9yf7+Iiu+6yeM0/hdOlz8/rl/CS8VexgXn2YRLNjVHqa1+uSxefg47adKzCvdq334'
    'rS6Fc7TrYSVXY6skolddKae0NRd8091YeA8o7/OCsSuJzk9f87z/9opPggIRKt7Wl22d7/NS4/KW20bo7+7OsKrbIWzg5g5n9rLq'
    'hbNkSyih5Db6u4qNlnfejn7dZM0tUpqvSUyx8lvOGTkS38MKKVwAScG2sfBolSErMMqmgkq9vXV3UfVCtcv07cqrR08JQpfCdXxU'
    'sY6PfpN1XJ25jqv/jutI+H6hwF9ULuPKXZdx9dV3j//wpLiMq08q8M6T32IZH81cxkf/jsu48sRfxiczl3H1rsv4eBn/lZbxccUy'
    'Pv5Vyxhq24tria9RQRk/Z0HvgrvMrDpiRjxN+rtSJLwJzCzMz8y/wjmrGCtpf/7HfwfD9/N/+Vf+83/9PzXPIeBoIFEWat2006NB'
    'sjoXxlFvU5AO9vHjaJAM/Ypa/q14O2xEnscSXIvAs7eiP0BkGX8xYjVQw0IDgxRm8wS5qNn7JDhHTO++GuSepSqNdB/Rwh8dKJlM'
    'bex54PlP1BwEGjdN+/mfLbMBqmnBX/RQFKAuHz3Pw4P1P3AkZBrk0ZPlwj1MzRfldkZl8u+zJOJvUrkU9694+0vL9b9kPawbzK+k'
    '9Fw7lcRe0kZ2907+fgrpovf0hv0rUYQTijDEspbCIMNLoky77/CNt04NBbCJLCLxmgrkM3M7XPnaDoPzNLffIfc39PsJOi9e60Ov'
    'vu9VA5F3r2uAMGiVoLB7M7vlFR7xV4D3Dm34BKKVajD3Pgc3qVfTB60bOyv3TudX008CKD6zMZEz+csB8KPv2V7INjmHbyTEfQqv'
    'jrJ3PM3fbzPCwk/edFlBky1Ee3wjKfu8lJm3nJh6Y0Ge4ViGtapqh3as2IhdGNdO4KPG2yr+4gCOgexgqXEq02Sn4kLz7L7imuaG'
    'llDYuDT7e6ghtVzAzcqO+pUdWfNR15nTrDQlyr759G7UpZrbF3SZDfkODgEp2NWABe4Jb7rPkCWe88hmp/qkLxhRdoBVq5nkt78c'
    'trixXwhTHRnQIigYwJRygxGmPJSBAPYXIh25LGUyHvd7kmZ66WzYLfSyqD00A4B9qNBW0QO+zO5gdr0xYDGoZ32gZtSA/1dlFf5A'
    'dSwyIZosf89O9SxAWrK+X/MHW7EaEujC1i+G0WjaL5ArmVWaOQ7v6P6mo5B2b+0+PPG/6Qhs0/MGweEeRuOMAHeSfv0YDGSi9qLz'
    'TDM9LvFR2jykayg8uF9wCJYA0NlvcGD/vS6DlSLqC2OuOPxXhvAZ18KqafHXjHZpkOYJ1nCpsA1uQOVtxu4U0G1pl0q1foO96oxb'
    'aO2DHaTSj53xVy/C7GlLk10nSh5PJ30RHHeWUnEzzZZWmitLrixdSYOssgJ/sSUvst6MvNYrS39+93aXB7/YG2LyHcjaup0WK9mc'
    '+s/lp8OlZ7+jJHvCjiabYbJzLmQ+retY5UXajWhExjROv/zw6MXLvVdQOLrAfM189GZ3R93q6ppgACER/lC/+Rd0EDRK0FHaqQoI'
    'KQG6hRCrjais4rCurWCcCKuKB1jS1nAsSGUlwTH+4EJ8wzQo1zwo6FUlQyAIprqGvvIC9pjmhaCC6YOQVKbZQdOL5aPmB4Wwi7Xf'
    '6IaTwOrVyaZ3NBb6HfI/W9mDZqlXKRAxtyZneCly+kiTk7msql7W6jNQCf/SG4cJq6PYZjTjAvUmrQokGvhTD5JZIIGO7QoBt6Dx'
    'E4WuDb+FgeLhQ6/jJQs3ZhI2ppgfEt4GEmtFfgh4GDOw++hAoySzXRG/4fDIJuC6N0OMMUjGDTCgNhv4Z1Y27t98R1ze7mBveMGc'
    'Xh5u48hQLGkjgxTXJuloNp2c9c5SG2a5FFeZjoYEVpYmf0macKvt9lx1KzZKIjV7O+UVR4TqQjOyQVUbzsH9S+3YDTUNuSzlNk/5'
    'C8lRjhzjWJB05nJYU14/nPmtq8OJY32wLPavcDI7V7oJov6LM6Zr7yZruoVSwKz2vjNmwiBI4TsPHht8MkvnFsP1TurH0TlVOOl1'
    'uxx123yBT7f/HjmAL0xVRhbFEujlXoCITPH2C3fUijU2CjW8qXN05XfpcKozLt4GFhmXfZqa9H5aq9cJ89veYG9VZawzp5n9ZNJL'
    'Fk+SbDwaT8cHaLCNkBKe2xOXIPROZzftAnWy3YrcAnTMMfwMIZ2PXUJvcVZJu8cpO1tomoI8Hw3XovOTVOJH5KNRH9aMSEOYRXFC'
    'wMvJs897Q8KHdbgJJDmB2xC9cP5kIukQ0JFrs123NB5lRD6kQ47dQgRGl1Odt4lmkzN01kvPveDsUFHsDHe5SoxFlKXHL2Gfmmyk'
    'g1vRWj+p+IjD8VExIm6fI94VYS0Cf1pYRFHjBNNsMUTFnnoabjaX3eAUUvRj3RTaMj8WzSciDpqycmpxzmE66LutUfV20dZqSRBh'
    'oGXutD5rUof8QFR4+uf4/hWXvRlfIAMgXSHd7vYZR/InJIQ0erVJCrsh2nhjr/61UNoizBDvC5Qe1AFi4R4AIfgJVfLRMSE9Phbt'
    'fGgzl7JJFr1EeHH8VopagY3VJhr+C4DmRWgcIgIatdSEIkvDvez22n1Jq0FEkMilebFklGsm8rmczTUDHw5XaDWz3vqIsWaYU43n'
    'zWQa6nHcojLgSZAcjGz+iVPy2XTCJ88uennDxqMerKqYqOAgrpuaR+MefK/AmjV5clm+1dQtWsQhxM74s+Zd+UZjT8n/qYXdElGd'
    'k9NogKhd3kcbW33v9fa77S+7ezsfEV29ljFbsdgVtqLFRnE1b8Np9nt4h4ywE/oLAlvRmRxOoly5AF5iye3kzQ/dVSaCqbVm7pfG'
    '1E2zdQ1i1B91kv4ugSnkCFSDyQVv2Gx86G67G4PneRiE4fkkgmyAmwhN2pgcY11qEktFKLrBaKSp04L6zHvpZXQyGqTF98Xmds97'
    'GAiHu8MOYOm5fffBbom9lfyG/QFXz8TmXEe17b4CO0htBN97TS/juo2xRkzQkK76jJABItYIQkeLzH4Mu5J/8+YbDlf1DkxLXIvH'
    'k/SIePdFVuEuMsNNNBLGTVihApA7HMPTwrDapYIihmcPoj+t6Xaad8G2Hpe3tbinPF+uXHdQmDZNSLctswOeCSfffmYhvNlnlzTs'
    'QTQdErOVRZejae2MA9HBxJcurm8qDhOqIWMKI4mWtMLYM+Uc4aec9IcvOxTqq8I+H4UlxfyvcA7t2UJVkcd4LADVhfExETOS/ul3'
    'v8OREvPgff14YJmsq+iUrmReguEpspe0/9qqKA8XbzFCakVv37zf/vJy+9WzT2/3drmcHw+OI11ySl3b/XuMyWdeOa/VvV72cUSX'
    'R1ZnVxwdRk4YFJnp2eEi0/FkTV6k62t20pk1ElRlTx4GHhvWmW399yTa1pAVET//47/ev5J8aEw6D9npuzYd8gFFRC8ryni0XL/5'
    '+R//7XAtJGmxsR5p5yyj/R0xJ9W9Aw5wLiu4auC+VkNrNc6Bfsp+bWLTTtuhLgGHvJ8meuD9Kzuj+H2cN2mFWElXr98wC1b1PR/V'
    'JTHXIYMkQZlfKmfL/7oEFDYjVvo4HG9uzPRrQglEiYFQ8BR8oithupczuBPXQYRbMryUAvQG02wWjdBBKM4nPXiE2ICI8Psx7rYi'
    'WUxtVNQT8qFmTdrbzW4vA0vT5c1Q01u6QZMsA6pqCrkS10a4be/RdhHgypruowdzJUFSeIBsUXRLKXSWv9d5Z9v25Zk12jVr/pxI'
    't86Jz2PQLc4wwZwJnw1/jz6mGQNVaRKmwEuafMjmBA0ykPnl3yKf9W3Fb4LLHQAVY36NiNm2204EY+Xc4B/BG4NBz/taOgZ+nEXu'
    'g795S63L2+XZRrI9/G5N+GjvDY3ISjsCLjtI1MoBbuRYMOppRFK7JZWNK9AdB4QWdDy22k77rwSWzdP0MpNkrDaXl9etLp/Owk7P'
    'fl+zubLcpRxeDiMBqfguu1KGtVm75B22HrvcZ9M2KigmAUls0sp5o63TRUBfmjPWmBY1mKcrvDZ7knCEERD8N4E7b6KnmOd+jRku'
    'MMrMz+IHe2ziB1M+tSIcnprg8fg8nYAzbgkDy3gxkwz0teybaN4uB5P/VZgSjRFmqiDIgJwdT2Fw6UZUZCwcGpU4Ce26xQNFnNcI'
    '0V0V00EzSwZ8TZwgBj1zEbPoHS6bqgbj7lJPXmEnHEIbNY6ecjEnYmhvOJ7mQtxTQbkSJKRDVJNx1Nb4iyKAyKlg5D27o8JLRyK0'
    'cN38hPhbnWTNNG3Ygto2ODuAhbTfiJCOAhcr1D79ZvQ2haitl0fpYJxf4gvbKfZ8BhkaajqUaSLJGXjqBSGSvuQ6MQ1Ax3tEC5GZ'
    'wQsB6lIZdUd8Zpk+9m0osNz0Huyviy2ALUEF/7BFpgkjx/LTCtllrIwuaBLFW6JsdXnZeslcUJXB6IxXvTBZO1gZEY+Rru8zRnDQ'
    'mOnKSyxq98nTpfE5UCwh2L4euYp0lYQoy35acwfWz/PmD+PemaHMuUbY1e3tIYA6QCp2wbexGOVjTTdMICyQ0TSzfDSGHi45Zp1R'
    '7PnypbiVNO4gILJmzlXsZbGx8/FLZ51knLriyk1hfPXZA2z3pxMrgPI7qps8dD5XpXLFEEEAQllkvdcbpJNA2gQ59iA7Lt4OQAX8'
    'EUgsL1C5fCmjEj45WpCGHtew7qpbgl82OhxNiYS2vaOSfWBeKDeFZIp+kwq72ipD9rKXkSY7B6/6AvcKmyp93NnZ+/Lqzdu37MX3'
    '4dnb7b29bSIqMBspm2YFcYDfBNtiScgd3jDb3DfMZawLWo94eBsLUjMSVyog8cUOG57eLIhidWMBt9gxJwdoyXuG1Y2FPfavVDxU'
    'y/Tma2kQdWYXJBw9YyyEaJtQ6fbofGHzHf1YX5KBsFFja8a4vnJI/LDpWvbtWAurd8ebsePfjOaO62geBb4RedE5b3wgAQX/uCdg'
    'HBAtRcZ5S/lmGwubt5MZkON0NNjPiMw6APIaELKHk2dWd6IoS/h7rIERDGw4zjy+l6GFuJdh4cGK00tsHV0ExjEbkLLiNc3hcqEg'
    'rWaSxCVxnA5jrw4tRT8ZZ4UBSef3ThGoiphvmZGtw2HqC+WrGgzPbrbV7Og3js2zzZJWZlltHdvKp2F3VOiCIGe0mxMUeam2uOzH'
    'tFR2kpbLfoV6pilAJ2qZmSwn77ijouTkZk0mNn0a59Tb4bmiHzMjbuHlCPyjaBHc2WFA2xJJ7+6+EdAeNDux6Rgp00+35KG6ZP/U'
    'Fa35ujR6947VWwVQwJ3YP7UF2Uy2XJC/feh1qpqoZE32a98ePScqjBN9H73JEzrM8nsX2UfEBYKK9I6Pze/dE1xj/BNpcuSX8Nr4'
    '2XvW7YLMv88MSiV8So/12bv6FtN92zw6jzY3ot8rPcM1dYS31+1xQVdRRl239CidhAyvhL6xxXhGQSkEEgkL8Qwr5OASwJ7jo8QZ'
    '51LBEYs+CtH28z/+lc9ZpI78eLbD6+1Cz1Tayt5HvgGLO2nztPhVvSHTV7zkUb+zw862B+MTZ7ohNDkUAGAOsiZRzSdJ1rOblL1K'
    'uuns4kf01RZ9Ns1Hs4vCi3OvJyHCuTinyvaGHJQGR+YG8QMrZ6pLQnHjqIERZxZDTo70rBEdDZmaECAs3Vlawrt2hun5VzBOHApF'
    'AqMjZ4IjTIlk/JCydtR+pSGDhu8nw1M8ZsxrLXtcwmQ0gIYBOxuoHwLGFrEapHpOIJrGQGBIhIzokiND5zITb9qrGzOF9+m55Rxh'
    'lfAin/Qf/gv4o2MQhkhn0Gc5PfPdotwGNNNdljILby54t0ZURkrgJvOLcNJn8xGmD/5HKBuCj8+y4udnmS3wAnGh/O9CH9Je8pe4'
    'M0WYCFscN7RfmsrhlfluGFuvRMAu23ZeiYS93Cs+xK4/WD2oQLJUGsZHe7z4HVsKOnKh+F0T09yv25nmUtQW+ABrmHLzbCQD45MY'
    'dioNeTbCnFIv3Mgfe93sqxsybIa083IqJnTBgLrmpdtX0S4XtkLfusaEAAt2A5huVzU7tiDwhl8sp2e3V728PCmjhqYDU3Pn5sZW'
    'YqrGqwWSxn5kMiYYlfdRbNH4avWKMNnr6e3TJkEmopzIQmIBq27dNo6xaYvaJtzinuiCcQ/uqudHRyLwo7ns8QD0gRMZvHg3mqS4'
    'j2kOQI5fM26EVKHCED9l1JJkBGJLlwQc9kQtDGJMpRHRoGmvlZ3BLxOMJmEUqwr2jLUd/d5pypoOoomIBUIzWXOeYr/AZAhrXRS8'
    'sT6/ySG8N9UWohFZ5iVSipJe9Xis5nqlX0q/VFkByN4blVZp56/mreFaQR1WaPG0DL3M+eGTQzWe6sMr7suv/ZKWEHMgrOJHv1T5'
    '/NncVP78w0MZjl8R5y84Dv5pCqrymw/vvw+QbIAi6dn/vu1b3pab0g9BcxWFPVtRU9Szt0NBo4wv2+tRhSojPtejMlWllZYlMt+D'
    'i0VePRPSeu7+wHam3zc1unGtzfCQciqnm1KTuBCzr2+UOd6wReEbf8kQjQ2Ba+ujSDduB0YpF0KhmHLMvATE3kaGIRYOzp4mMDIR'
    'EwfQ5/wq6ENY+lIfHitPLfBQleijZkAI6ZNpx/JZ9i5jEMBbW8QxYGGhN4abkWIebxaOSQzW4sUVr1fLulUW9Upaxi40PhEj+Xgo'
    '6zpUtskT7whxTswGUlUSqZwiPZ1r1jCJ81tlNuvujZbQnApIg1bL+qm2bkHPrrMa+NUyM3kMxFNTDVlF5Xpm5q/ULzNig2O4GzBv'
    'St/cxpsPpTUwwrIjf+LssrC/DOVsuBZskSmW52BxPWEYy9MkCFaGSFpHPvgKf3jr+huesbgFwdyVHb1l2c3KMZcaPO1yBkJNCJhz'
    'mjr5i8m9gTjU707YyvKqVSgnHS2gfglEpqTp34FEVSwvWkZWL+SjbnJJVAcCzlG7oDjW2KBdpK9sYjmMIAFFvlK2txx2xfSuzNQG'
    'GkDpPGTcTEHWTtqpMS9eCRCWl6xizqt6q+7LAYAw8nfvC5z9Lf24tpk/v3vbYNkrQOy2GYjA4O7dsAxhbj83Qt7+EfBwml6KGT/T'
    'tMSGZQjhyGSvaA6nmdHAqoLFI1XLgkuNQGjoT30UlaF9VP1pk07OdkLcIYJ+QgdUJn3bYbT855/29nbe8501GE2zdDrmW8sujJKR'
    'RbVKuwlFEhhmmjhg/SOj/502R8qcaKmxyC6Ir6L2mXOituE7dckRF+v15kgqxNnZcVlZrQlIkyGhJvcaCjHM0Sg3OsmQwzNGE3jJ'
    'SB2T5LMRQaBWb0Z8d9IJJS5BIlwSbwqZdX4yGU2PTwopQsW7hNpNYJPIDABb0E/S9rRnAkGqp7gwMFlnAl6AZkdsgbj+AfHqR2J2'
    'IA9hLR4Nt5ZH2WCKexjdEFqQ1IAZRE1okda+20dSELpvQDLnrrP4/KTHaiKEk6EK7bSTwC2EzcCSKYi1SfTswxtYdk9SWiVI+dCL'
    'OhT0Mo7NSSuiYkNZFM5u3qX1SDJJpfnp49uMvQDEcZ/YiEuA3NEiBpLg+mw6G2Ve6g+8TSJnHIrSQtUT28Hr5yPiwGmvoUXkF69G'
    'EzVB1fJGl+e9esHnMmdZoMb65Pcf2QZODVj90YCOsnHh77kBWlmYlH2/s7f9Ze/Z97tsISMGuclxtLgp0adZfVwH76macraSpxJs'
    'X7ccxdMhMFBL7wEHFBlnxIX1xwdO2fT8o/zhfyVzHf98w/9uv+M/n+SrKfPmj9v88+X2W3n1Sat/kjaRPo1/IPEZ//jwkf9Sr69X'
    'Whxok+B/lT+9fiR/HuP9I7z/zv56Yn59ko525M9bGZyLLM6Pz2Tc72T8rz9qhxwfml9xFhL5hfyL8gs5GOXXRy0kf6Tgyzd/oiEA'
    '7+9+ePaeIx+/2nm/hx/f3Jitevlx54PZqqUfYzky16xLue4dEeeYXsu/I7b1umaQvs7ppoN3xvVwZGqcHV/T8Tm5Bua8ZoXlNRyR'
    'r6G3uUaoqWuQH9eMUa8F614Ltr0GaUHHJbk+oxM+uk6m3d7oWpLd1u8v9Xy1Yznbpa985HTAt6fOhB8VB05FA5smkyYeRINwWwJN'
    'lWRzGoVZljfd3pnvvXmesG4rBr4At+AlsfCzMsNdgShglKrMhyApkznA9bz8l9RBk+4DuiZECFsYJOxlUcc1VcyKOV1dXm6z6UoN'
    'V1FF0uTySGamZrAgJtkZhl6GnZnpnoEuNiK/aDMffaIpaT7ERjSZsvGKRTX7VO4gyK+MElgMrL0mEKGFDyYjuGk6PB1CgU8bIZhn'
    'jCssOVYEBP0+wMBrm4dnkhKWUgpx0nJdnqpUhCZxvJgEhQkg7tEhhBd9ttWi89Tr56NWfaknK8cxY26ZUSFGcTBY5CpkDWWYwBqB'
    'la8RmOT6uHd0fZ62x/U1HNgnjxv7yeLflxf/8HBp43N28PC+GUjFzDiboU5s1qbyRTbjwOA8wuKZdxWDzfi0goLidy1sSJgTM4i9'
    'He4IUu9l5ZUXk/zKPTGJPtbKVScpM8bDEaQFdIUOR+wlMoFR0drsla6XW8IiVY4hzAUZNLUnuafc8+vQpDMRltmkfkNas9E5/zwo'
    'gybs1BgfvhlW7SJyca8sFyDyjBM1sWHZOn1dLs8raURnpejYBRSkvhP4Pw967dsbY//FHzlbOOFX392CHn1PIKNPJH5LiFD1i7hn'
    'ctizZcjSekz87DXnVbg+mdQ/ty0Im0z3tLb62+G/9f0fNw8ebF7/btjOxmuKBxVCxLIYuN1dS06MhFBlEeu8iL+HLWLgJTZXW1mi'
    'pnzrP9FH9phpZas5JfGgOA1Na9XrnfumJVBSsdnL1LwEHWI5DHCYAsZy0s/hXD6uTBmymE+tK4HxteUs1rb4szFg8QzoIqgyhQlj'
    'az21HCN2jJtlPWyhBPFZ0uVE/QyKvslGlndV1PfOWFFjuVmgkYvmyYbp5ND0TIKPhpVOTXGWnBm2E8xIL69lcBrBS5C4w67cH2xr'
    'qTL2ZmhH9d4O01Nq3/NNkDwTVLl3zdjVRAYGSO/ta4bpuOC+JI8bdt7UaABHxrnJpZezvQROULa+0f0rb8HZEgpmTHAILnsofVIP'
    'JV3BWn2GJ06Wprx0wvX4gA/FCwFbaERfPBWzIUJ2vdcNJ4YqW3jbsgAxZy22/KXwqtjj5lmdYBlCwtUiH2NVZKp1wjOqlWsAWpYf'
    'iGO7rVHi39gPOJmc/tA77ckqhYsktVgIgby3V6H9p2MT6SAGPKMnqHBL2ogew+Yn4tPyA2I4uOPCBpMCB+zi7qwmmxEsK496Ewn/'
    'OhQPfPDU0Vkv6+VgsXGQoPAlBjkde6fF306h++82/DtsaBm45RSGvhZ844BP2CjuaHHfwaWLxNTcUIiTg78taeEG4Ma/Wp7wXPs1'
    'EBJI1sX1asjy2BAh3AuhITTDLkGK2M+r3xCg5WVvkl+6u2OoEt+huVfpOTQR1298JhWBuTNZQqR7nk8EbW47Bb7Uu7YLZr87EpMU'
    'tl2pt0DdwOZlOhSnWSINJfoKQUPCinkEDOFXHnSB7SO48aClbOZzd4AX193iJRHBlHsp+mg8wM85hggLKKaTDEGfExHvGAtvDAGG'
    '6xJXhkVX7HA7yTCddILxe/EoeEnmKtgzczcWJImhBW54idqQC00WpLOZqk8aqOwpizlPOV+3z/J4ud4EDI2Gz4YdIphGkxcqopow'
    'CxLIiUoVEdvMkgr2joPBcCbW/4Ex8YTbl5OktXhCFaSJvf6k66pZuM9zJzBztaKsii7JHCniOigGisGXF4Nu3Bl01ZEwMqqf8F6v'
    'Jsjcoa5YkSCqQHqRdnCkCapi8eb6oZefvNjdNe7f1gt8Vi0eohYVl0d3q5j7oWLrLN0t4ItvessJWty0a1CTEvjKVmMlwY0PAZ2E'
    '5s6pmkrW5GVYFhFnVwDPA+mtEhyymYbddu+aNtILAaDb5CnaGRd0WYI93sQ1VYLFblrnfGjd1PPpLpN/ur7FGDu3Wl9zj4tAN1m0'
    'L84Eg+6B8w3mfJ+Ok9BgBPwmbFbhYjdHUDzPUnvQLUYkmOtbPBoWkvi0We7l7++WswQ6WW1EJ48akoaOXbkb0XiSOoPbIdfxLEvR'
    '3Bb+9cRCnkggYoFnRaAxB66sgM0k5JwPa8QnZjYVqrcFRyyQk9LMWXHOJQGtDKdODYqXeNF1gdGYBMeTqFfEO3VF83tU99fTxdaa'
    '9iU+FUpGHDaNo+dxYRMHgls1HrbhAZRvHCxbwhTDrJnYaA5i3aQfNwu+vwgHoR5vrrcRFX28WQupRMJ0Ytv0lVhLfUqEyZm960mN'
    'nmbKxVj41VpaqpmjPp2A3BpPRoNxjvRVw1MMkDBkxtaY3Jkj2FAaRBMqcVos05w/UGkSoSydCO424RuVpg2WmnggUq/Tn3YJlGr/'
    'mzje3Qvfokuo/6QdJt+9wTxEU3NQPYZT4IWx9mqfU9r+w/WE5Y7Y7zTr8GhvEOjSPqwvJZsiz5DsXEzPWWQt3L0au6F8ABC8089k'
    'HMZM8Gr+2KWY7IGMtRam4IPX74aItQCvnIv6cP3+Fb25UcDUB5vt/RFm4bJOK/ItrQSPdnM9hyYCyU9H57Aw4kDa8m49V5G/fOpy'
    'oG/3m4pp3iltyR2UwwJ2QzLs2YCedxEiDAo7w82hvF8gYQbYgh8+26Amiho+THOfwoS1gzbHPJSvZMgn2oV3S3HScuC1Yu56ZMa8'
    '2DmKuc8GtiMzxdB6xWWTT2r1g6r9hQ95YXPnaEbQzJrTfOCI99jWnv6s+3nvjUNS1ENO9Mk8jYZrnDawfqeS7YmVuMbUqVuxYtr7'
    '7WcvIYWWVcmfj7o9NvwRoSzeqVIFGli+gYLW4IAC+HzOCWbiSSO6S2dxsTc4uNBu85RYZMlEJfcF9swZbtuAEMVNIjCwm+Q732uc'
    'kaweOAXOWLU7DB1HjQOFIipj1PmKvaAtDtaq04gcMOwDjB9GKwd29msa7rFytsSo+lBJy2Q9rOdWun2VwiHRxgQNV5wOalXOOYvp'
    'Kg6XQxR1hSi/yQJJDm9icxmX2UOxV7F2N0VyXmywuJAldhU7Q0LHyqGUab96ZKK+7qq1Tawf1koCJrbSmT0m5t7Y68MYfc6QXd3S'
    'TuBifVVw7vnKMVX4k2ssvlGXDZI6+aT/x/QSW5Y2ocemh0Z0yt+ockh1OvO2shf5FVUgkhbda54AdhMKBm/GKbY/AteVrunsyM6k'
    'RipJzjFEegzYp+Kzlfpus5Rr6cfP2YN4cXHx+vMD/Hf95cuXOr26vyR0jl/Xl+dalqJqPqxGXaBGF8Qqj0cKq51u74ytdmDqJffD'
    'jOZtJMuoxEGOJr2/g6HqI9tgzZ4zu0LYMwbcksd/9eL7eoO1yqZOVQV5x/3zNmNL/aP4IsDPW7o4ndmFJcJnw8Ne0q4Vt9ujLvo9'
    'YUmqWjdrHAy9NprmSDTN+FsyZ9estGb2YQodLdxRQrS/DQy46jDVDb/8jooRt57aU4R6d1t3JZRQAZcRFj/NXwHd7CXHsXmNnZAo'
    'eEAQ8vqcfunCGi1qVYiYxNFmCesTZ8xl1nAlUCyHMY8TTvnSiGpf2MnQ1yg3ihrl+es9Vn8zu94VXZczxBBhh+GbYMjIz7wlVsyY'
    'y/5B/QBPiKZyxLbCc9hcq2TkGPCGIS2R4wGnXZKfF8YChhB/Y9/ixnQkhj4FQp9fljkZ7zpr3NKJRL2uq8Xv7AXvTpJjuo8nZs0r'
    'Ao/cUn80Lp+Pws7gct3jELjp5NduzL2qnVmrhpRZYVQ0lfgoC6hBYJoPo6yHcrCp+oBIrlsKWVTiz7rm9PMv4Cpma5B1qNQBTg/U'
    'yfku5oQ3zdHRET0L/+KezVVpxM6TAmoMh8ml7BjrYdV5RasnwwOeBdtqp6wRMdSoOIsG0yxns9Q8Tfo+F2fjUIvhwTe/VOTnQgFW'
    'mCSL5bFP55S3P3R7/BXixvaci8E54uCEhsJFYzyukr4K43F7ssV9wZSDrCA0HL8Be+7M0Yd7THXPdOc4q7A8n+nLcVYPhCBnQUdF'
    'H0G9uu13BpZqbxRe0DeD47I7iv0y2x/FYI/QKWWmS0oJeLNgFkyU4+YLnO4srSQQ/pJQYaDl5bjgHEedQ37BWj3q5WtchoPKicm0'
    'KMzSbtOzEN798kNF7GUBMYlHt/aNiFPVhpJKP6yMn6utKYdzXvctPyQsiAxlg9p4GNXGF7VApm03QqztK8PnVIWsvuXqBQ8HGDvz'
    'uJ6qMb1L8pMmhyyJO/1kMI6DIOrpmcNGq0+XG36I9QfRcvP39bqbk+t8OrZ22lcqLcN4qmel7kL4Y91Jq0tOcZFNxyo4mROpWrek'
    '4ZubVc2fDc6KKgaex8w9CEc7s5gbKmBchlqtQNOIlzY97m6KFLs0IadNq41r4SDpLDwThS5udxiMJsNL0QcTFZ0hxj/je7ZihmWp'
    'aNOzE0j6cScMklMp0oZcAWaFkhkjRaKMS4mr2PzmdmLEeFmH9APn2dvypNFw/s6AqKtIACzQLWTLb9QL1s1IFKIT2qesxdYeHST/'
    'YmcQiSqfCQbpnIx6nbQahbx+835vtwKBcKuF4O2v8S6GiZBwsRx7nMtVhaixsZeg0uJKa16dPS5VjFBGpWA+xAFmLkTBEr0GFFhv'
    'JXBV8t14MmmxXVvCZq+pPlM844bpq7bCfNpyATA1Kog30rIvvF2R6nWw6ktvJdgyNnQSd/IKe75sw5VomscvViw0+EAPZitax+Oi'
    '1xKCJMDHpgVvHurMWpQMEcocEob2JJlc0vKkyUQcdAreTXu+M88RsWZZ4FSUFZsC19iFqcaYuE7pVWIraOh0Zt66ONtsp6LOTV0a'
    'AJpmiyYC7Zoa/zXYhjyKjffiw0htwFDFRmFYhEMku7qz+FGC1msoe881SCLQeNH5jeuPGbpx8+HKmXpFvEvG5QD50e6fvo/GtAZj'
    'uoYeDvLeINVO8l6f9d4cFFMb3mqiN/DCY58F0a/8kbVeP0GFOdZol/5Xy5S0orF3RgmnxXlR9Y8EbURyntM1tgTL42W6DnOEAulJ'
    'OvD9J8twCU6pRrd20IjkedAbTok/xvPqY3omjDvhp9834DZ+yb8fNx99h7C3aXrKzyurqElwf8KPb4awzs0JmmqXBE61gwOjjQTV'
    'WIzRtQ+qocFxTA9AQfMAg3jP0XqEMk7GPjT3/iC5iOF1hN9H/dFoQrSlE20MrXxdZ4m1/euUXUXOcfwP718NbyL6B8lr6Q/baiO5'
    'A+OG2g0W9tAYqZ9FSxs8DmNKKwTdOYHgKMehMGfqnPZU2RPkhFeDrhTKC0j3xqySEju9Gnux5RKVyDO+svDFPJK/syy+wsDxoQmo'
    'u7nWB4Y+PBn3f4nmzvbwDMjNkySLT1niYrRk8h6xcPB+zesG0Vzlzm9ECDbYiEyQvkYk9sAcn+P0xXRyBmtG/ObY4ZkQIJzK4exY'
    'o+7XamFuMQkYBUaOIz0NerRyeRr/8+7Oe3E5kp/ixtA7uoxlunQr9tJzdvAsZaog0JFIu4KO4EE4HVOzXU53NfpG05a9mkgU3jTc'
    'L7hDasodsTseAmVFfx+NGEnC6TCZyB2b0NkeOhQKX3p1vkxMNjMnw2NKMuukQ2PK3eCAyu326AJW7uc+JLebILBxDJ88XqaPJ+HH'
    'E/342Ma+lW4QwrjdvKCvaGApWqWDzn8b0SV/uuRPJ/qJ/0p9tz+H6/SbUyk9H11wqmWci0v8c45/Tm4WYFvCfrHPsjExtR8h7dhY'
    'uHjX6/6F/hcN0jRfiCTdFIPHxgJMJaFFl3W4WV+iPkT97F1dPojwSSPckfT7uA/jXwh+Go1YRZQK45nAeMP0GCSjkFcVli+gFiT2'
    '2FcGTCtnGArinpUDKcvF611Ku/xCxHjy0cVn1mc/RDNLrl7v7O5Z46XgMpMNt20T0plmtVk6BFPs+0mvGATwcL3bOzNxWFFmkSNR'
    'L2z+xb/7IQiR45HRQUrVOTlMPwqf6yheb2+GFOgi7eT0Yn2pvQnaoPx5kHTYMpHOKArVm7AueDMUlGq4AaIx2AU7yxFxA6QGnVrm'
    'N0Bv4Oal56GLGddcX6JphaYRfmaGOWtmpmyyYrzqsc2s0EJmERAH0WySVigk3nG0q902MX5Kxr24tkT/LukX4zYlJyhOJxOz47eM'
    'dMl46lG/zOWpzopaaA7SLIMLNqbBYgxZzzxpMzKcpLyGhQ1UNwOf6sMSeO1VrWc4bc9OxsX5o2UonhYxuzYzfCW0JfPDQa4KMc5W'
    'EmySIno6J1tCzGXroLTffPBw68f7Vzdx/Xr/88HnzwfspPT58/3f1Xy7ypPe8QnHzImxkCBBJwOlTHC7GVF81uHvxbQIkr5OqmhR'
    '/LHDkAAFx9sX45gHGnNDdcL7teMezF4GYtsD7AkkSviTfx76mAstqqH4Mw1Xll500smYAEfiuObWX0AxDIZE48Q3NZ820ejFUdP3'
    'rxn2iDmvmL4GnIUSF+uLWiWdLpYoAdwtEoXW5+1ZnrNEhrbrcZonasna2OQqmeohUOoya5ISJNpbhoQfVi8Jq1els96a9pVbAxhn'
    'AijVLPXjJ/8TpODdt3TRUvHF6DvcxCkHxJVvvSGvhzbPpR5ynw+jp8v+3sTSJp0oExaVWVauLKQ9F+DW65Vh7xFkFV2vR16PYYOF'
    'VBjuaDnrQw/hhLaGf6u4bTQIv8bbDzZVIYAq/Y04vz5dezzWulGwPB+N+mkytJtvVDSGgRG1Cqwsj5xgzfghGqpWgt3ffB7iN9Pl'
    '8hMLcHNYhjKT1QMjazKXGfNxpxadZIXgw266uwxt+qsjIgqQlLolEzTzyVVhhAGFHQctm225kSj3Vauh+oHL3dEk99ccseGsdS74'
    'FA7fqSmf4BjalsCcTTMKFgykL0YDGBIRSajvG87NpcHigCF0TGfEghGMwBkZyWk1i7FrFtWZZyAoT8xvPqG8URlyEvuleY24rPyi'
    '0ydTkkIFB7hw18NI2nMuKdkBKW5yXwl/Y97eAGkw46Z4C4wbRyi3d3BGrBvneIs4z9dcGOfcXro2h7c2e+hZ6hK1D/B2YE306hE8'
    'kwrADSxamBmU7YpbBbQtdm1ZIsykt8wTczQ4Rp3yqO7FjZfwI/qf/yM6FN4V3zugl2/Udcy+KM+KzxpLWKlhtGFf3Ah3xL+9hjmc'
    'uF+YX9wwFe6+l1dP2WquBKGFAp3mHbNHMiAysc5oE7wuN4kF/5AIIjQmzMqwL0STEecAYM3eAugXvkU2FpY1WwBaMWa+0mbdTxHA'
    'dzAkN+Yj7IDV89ofFDMV4G08Th22r6AitfjMMa/Dv9w01E66x8QkcWgYIs6IR6KPmzod03GY/QCi4aSv85GHmTPahbSToEOEcRiw'
    'CFHleRFUHdvsalKEipnCmNcuQWER0AfadISSRUgCzuGKhLUB2cbGGr/vXNjsj8yhXqp3/4pP3FYIRnrewuHiZWGsh+HS8zuPO7jx'
    'Mkl5B7ou6KA5HbJFUFzMWNHhDNrp+QKdU+Gb3qfnL+il2xLISWkvvEjWXq6KGbYJ0im7SlQhzlm8GjGpLIo1eTAZS2Jp52JKRpWG'
    'UzIYc3YXjgMUYvMyzZuGdeAEmiz4BRdInUk+cQRGozH1OhAANMDYsUSYmhpBojO8BD+oUmfmEJmlmyV4jsGcKKdAZFobGi8z/Lp/'
    'FVWwubKwLkGIYVu0ubiK7rLffBIZYbo2LNO31TSDE+MURw0dBlih+rgSdETBEQDsK5wpMoBab1FKW5zgo4N8NFY+QNzue1kJNVz4'
    'CEHxUZAsJZrFhoVygvbm23BDWrxl9694TeCsEkwZV4zN4XLUTy8W2wgG2AJMLGwOR8PU4EY5m2bi5jw963ZfFWaiJwpBm3UMRDeH'
    'uK48hE2B/bTLjEqg4oD2GHQfx4qetnVaBaBmRlm1Gk6ryVY2EEli8iKQbJq19cL7n+6NNJOCixPWhX8x1ovKECM3iGssajGOQkYM'
    'eUK3v/H5FYsHGhlfK0bYzKNJLrc+D+O/qHwEjsImmTpf9Agc3qwHXDAmtDeaTnyWwhtoGGChP0q6JscA51CSLEvTCQzHQmIPjG5B'
    'oJBeJIMxkbmy6AJr6sjxbGi+mhm3lGfjcVsSCKG7WMyO6IaRsMAdGL2c90xS+4KID/N7pfkEYr4+7TzL1zesh3lDLD9RkZ1g5ur4'
    '9hiTCgkPhsIUSg1kPPd+g6Rm3qJOlFycNCU/3ERu/AqRkK6cL90Rh9vC/AWM1TQHjSEtHsf8vLqRpXBi+6qhuyo+QzZpSsq6vjjU'
    'O6nWZK2QcfrGkwffNvQCxr6zNa1QSZVWqvseGXXgjCblhZimli38vD2TgnbDWtqXNdPSrokx5CliUhIauzhDq7das/KK8mi/9UiH'
    'msfUepk9Qg5lzpwxXG/GKF0PTwMrNGwyR4YzNge5dRtmegh8/ZDUcrhoxs8WxPZlNNtW+7YJqcHwjCvt7hA2mAtd3r3sA9mgHh6/'
    'QNC7FFTzIWzgQReKyKA92nQG4Ng7UtIlz+yYZm169QP6epQhwkurt4w7zUE5E/feGN9VF7s1+4pJ9zArAQu+43YKkqzgXtgjumHS'
    'S/p+RgDJbXxbDPaKDOr1CFofrm4++dZ/LKyW26k4TozNBll/nfbHtw6UZ1Qd8f1rA7z7TSpgV83+Nqn6vbkF1kqksRdWHvtdsoh0'
    'W7y0FH0/AjnFdhGaO8MTSTcQ+xVOm0T6i5KdZt6ilxy4WMTatF25cA/Q+BYoIM9GIqNbmdOnxs6KCaGm0urwS4dI3mPagaqDmaQg'
    'ZSioAvjwbXnC22YsxMv1X7PREPE3OfoZSrucouCjtlymdYzhZf/YX3GrG7QFOM9Q3Q/m4VB/RJfTgMibWPKrhtInm6A1GWYsrjc7'
    'XtWv07J4X0dDSdq+Uf6geN5GeMEAYumovmZSZM9szhtrdLdkw16Iv7bNMdpu9kzKZrtSbMXBP1pR4fvLXoZrgIt0zW9El2Z6xXXi'
    '+QzJeLiNcDJ2DK62ZnrGFGHe5FkztkcXEq1vxrK4xQyMBu/qFVdJp5SHd2ME1RWksH86f4nGm90IhDr2QdBAniEavZPoKEZTiL1t'
    'dbRB8uBiId5e1vtwq8ZdzBuDJadkT2KOQIdTfU5YxZKnYNaOkh4IVdVQKph49JQzA1Blm/Erx9JQfZPMm1gqScxs8ZeKT0VSwXYl'
    'Knuh0ojd5GGosFu7+kEou8D7DtFpKpKxFewOZuRmc7lA9ezatJcSxyOyqS1tXI9CXrZi3jZaGdXafgVBONPsoTHXm3Su0+gsR0sL'
    'Rmo+IZF7WGHintUSJeRRivYXBd9pbxRL6gasKAPuo1J51rG9zbTjDv6sAYJyvTHQj0QCQNgnZYskYkGCy2GS+RopEPRRiRQ3/mpU'
    'tsAg8LsihzBraZ5NJqPzl4CCOYOuWqLZo9sKt6TSqbUQ44aHMqrNYxdckC0c9R3YjrxL4E+fShp5l0IBB5otgKP45//4f7PECJkH'
    'EaaADs446UZEPHBE+7pPiiDZALUo9kqBvBABXNMKv6+9SZr+wN+cnxZY7gaHW3rFKsfm7uudH74g8lJDz0DS6aRjdgRrSXzXoR+B'
    'wF6vEoS8EX17Ppr0kTPMi4mPWI2uh1dv3u5tf/zycfuft1/s0aVZ/vTsxYvtD3sNKym3USoIDyN3is6Q4y5wFG0iUiVcnsbRBhUy'
    'osX5I6RH3vuieQWCis51t9pnOg32qEybnRjmyzctTfsm9br5FXRvP6/5NbzmuJ73XKztFzX2L8WEPXOmINbl0WmbeX1OHR9SqYDl'
    'l3xTnhZNuX7+j/9vzRpJpgBgE3+QzkQ4jGx8t3FwXGSEPh2H1vveo6WEAVSjfh/XHNtQ/s//EcH3IvIyDNMnjbk87g1hmOKKauXR'
    'RCox/ipVrEwOnxxnBcP1b/mdlcRyCBgNnpqZzBycqm+nTaRaLxm2YL0gmSyGU3hN0I8vDSi+qe8lTvLAmRTokj+GqXJTzeMvxbeA'
    'aIsxm4RCJz/xYneqfU1DswembH+jCb9oqijMwbKAkkUrAhJlTWhJCHC/4cDQzixJbfk16KuaHScS/j2WWiC3jhPYtNJawoAzi+ie'
    'bLDpFlGLdc8qfu/Z9zASi3+83v+cxZuNg/q38f7n8dXbG/rn/c2XA//h89LiwYP60vHUZEKgPl8knZM0MJZno/ojdSm3hoheYKTj'
    'bOcoHvqRsrZMcFdlb/at7XguAY+4F7ZYNnFgnUIuJDs159Ks+NTGyMZ98AJWh++Js5fXvzMXYq7Og5jrLo2FI//ARodvWBwaWs76'
    'Aet32I5rsL96UAjA7lyTL1jQv/Tj/ucuretDE0ziou4hHjt1dhLcjFaXEUzcvuXInIbGcWXdMtGe150Jnlh/KzHLiWsANLSqoikQ'
    'CBX44mPT0iihF3kJaBsRceNjDjIKNl2rxoi2RK1pUXQzTAlo2/SRdlcNqW22nMnk0qYfooEkfURyu4x6EhA04ROlJtmDtJ9nErkU'
    'HWhc3ACqOH1oeLFKvomrGzoIQ/nMj57NCl4ktHH1ouVLAv5xkdnI4iU0xIkdZvWyUZsB7TqthHa4nx9EW1tyPgAzdRYvxh+evd3e'
    '29u25m5DTZruojUKHC//gr7dTUfzp/6LuQVUKNtPWELAwe8Ayd6ID5oZC0455a81wLOWcPwjaWdUYDHqEdFuZqN2LotRoUQ9Wt+I'
    'VhROMbuxyAIWVwpRrU6FSzmN1ottwn0Gldb5O6JbSfgvzCLm+LvRw+i0Hv1ToSL1rZ3NKfRrR+EtHbtb/DbjYWWU9mZrcaXq8rLb'
    'VEY/7qOK5vdQcOJGHkYrBZxANcMYm15MkNxE2LQInSPh2mcwO7B3zL1YoZWh9fcQV0Q0IIewUMHR//b+lfl204J5EB9FRZBMvFq4'
    'duZ3trW6NQ5TD7Em7jlzzR1WkgpsGIvRtaIllPzrdDAWJt7eqSEl8U7NJaB5y/SiViPP0ZEgSNbJsf7Rvk+giuzqW0OG1J2Wspup'
    'He43Jp9AM1oA0bLAyuLMoyCy8JJvSqQgXO2JUgnHIxGgEqETT4eQ4XOk5yO2wk+7/n0vc1fmTx7AdcuvNxDuB9/eSDI3U+BtLwu/'
    '44Xxo5M3r9XR7MA1ShhOMFmofe0JjNxB4MQlK+Sk3hh9Nl6/PJfV89uQolacWkyM4IZU6lNkpH4rLvKUU6r6vXrX0N/YYLAw1hnW'
    'th1zTXk3mhdbBOFXTN4OP+J5zSdd7krrlOxqlTOAoWe3KrAr3z58RkOiS3zuFF4hHMd5DTlw5FfgTJmQwKrnJktgp5rboOZdD2Jq'
    '6u4HRrJ/q9v3y/Lacv5/C2K7fFvzolXnYrnMltcrKil0OIWvOSbELpivgk256eTRmuugsobfKRsbm5qrxnvQ1scC+cX/5pV+vFZV'
    'VkytiSj/vPhlKT6AxTV3fY6uzwtt+YOuaMxizr8FgwxLMmgFeNYv7W2EvAJRoJ+7You2zw/EKR1YklM/F42KEQqSGCuNCOlBTbK/'
    'clB3VIT3pe198Q60YhvTD+/yciNaWRUjK9knVPVxgMVHkYfWAubWNS4mvsRJ9UoWvsJZbljxikSNk0wXNTqlcOeNvSm8j03JuoTt'
    'dZAPN/fs1STFuUFt9mhW/hFnxBq6BFbCzOJueDeknf8jmX5etjHLj625leOtW/evOoZ+uVnjn/SqNzzdGcb2A2xiv1VDNNiKVZmI'
    'VdvyHnWpMWsRTKQ4THZZoNfjWMvUcDDG7iivHuTe6+1327v7Rg960OzE2UnSTYXuRTMyqtC+a2BMSAP0FCKkDx5C+mS3xU6To+pm'
    'N0G7vP2mabneTfHActRboMJVkU6+H8U9/6IYBrC33zuwHoXmaqrOsgGcKUrLIK2JJWjHHpiu0ZOB1DX+8j4e1w1kcuP8ouMCJ18p'
    'rS091P3ctCJcCiuseWMxvlkmHROteLekhQiyCovpjOTaM8wXm4WY3oO0w9/49+rs4J7ezQwrt7l1KrQWc+N9maB99VJqbpFWejjG'
    'hEFlCeKMgPAPU2dG1FM7NIu36mtVze17JQ62miJHe0O8Mue2vZJY8QTZwzRB+Oka25fdfH0IzhASb9FRzIxHaCA/nNasxpz+YH6D'
    'Bq1bJtXD4fZCWQmJ0ofgSXn/4ttG8Gn8Vf2LK5n/ZbHQ182tcBgEby2lPb4yluFMp9rwIy4PCuGZMxMuWFTWFQTtDd2V3y3X7VgY'
    'rO4WyckzC5xlAdWDKklsnm6FhocTB/WisC5nYd7fZxeTgwPwTkL6hrza21Cia3Le7O8D6Uu1khhYvFZ6eRSkXIpgjU4YjKM1x4RQ'
    'OZSANHQNie+QJY3UJuTD8v7bTOLOHxClEu2dwJ9WGldr91HgeAlr4AYDRMr6YUjbaE9sSBSJv+ki3rUMssUbOyOTLA0dMR/YjDie'
    'L0ToSM8Zdsmi6umY1oGlyqZpG5lMqoIBZQlc2mPrG8RW4isYBp90jpiZoFkdE5XisZY/vPnjG8iSP+9/3o/3f/wMJ9vh9bcHD+vx'
    'Vmv/2+sD8+7gQX2L/h4sHRs5sruZHW+zxaLVEm/zOXvweUj/OCZG0xFUcGFM/ZbjaDBNXMV9eQY2t8oEm+hGRBTz2B5gEATZMCG4'
    'ndk34qm+Z5mCSwRjhMvzc/F+VfJdX0Pk5NTYq1BQvXJg03lCbPvOhNpybsICyxyGcaiOdgKK3qG0yecq8vWZdFeB4lOS3qls1C6J'
    'lfKLq4Td0HrgpclyqLzJWemEsvDIXrz3vRN53BuEHJCSWThwxpbitWYb5m3oN6W0abXABfdNvmGhlvo8VjYSx3xYANgnMCCkqyfW'
    'drPfp+aKTDXhHeTnSgz1dY9TGTOzp6OhEsycjtBJobECJ87JNFEEAr833YcP10zkFa1EVTjESw+5jKijFk8RuqGGh4XUXEg0BR9T'
    'OjEs6TfIcTomXE2Qu7+/gxwsgoqYBoasnvM5AvfmiNdBeEQgpztCDLf2JE38oDcTNJ4izPDH9CiLR/3uHqvLCCY4YIcf/VW2EPS2'
    'FrsVLdRZ6SV1tMXb6zi3K3TIEehHbPlngAK5qItu1ROjBFPv/tpnQnb4/+wBp6bBnt4tFgECnKFavLVB1Q8Ig9ZrGh5gjjiGmX2X'
    'xnWShjlbOWBs2iSSM3cMsJ+wrqAvAyNf29/H0DldsoICexa6E4/bRzStGlRgJB6NrF7t9jJq65K1pqxJuqxNxBSry+pSFmVxDAU/'
    'wuUXJJPf/ap75PqrtZc0kxessWKxqRe8SUOJqNLWKV0J+hsE4D3CeWywJfJZLkMoL+0jgFU+mrIHUczpsKnGN6KF51BCqRBiGSHO'
    'riTe0xR9LJGfStbUDBdgfzQ69e1GTMDvUKQo3nUiZ72D+YgGWq42HAlNNohBBAatNtnwgG/A4m8vFbq9XNw2Bsoo3DF1GbgIjK44'
    'x1cL8clYnNWKBqIP4+AI9olAcLC/fGBDL+CWaPk3lhqdeNR7Was62H90UL9b79zfqutv3lg44znaLlz7N0WtK3ccSAAK6RecNlwj'
    'oL/Y3d1qWgBkIa8m/H5tTQGYP7FRAGplrHTeV6xk60DGPOhlGWCv4pPKlArvq/J7eXB5ayIbL4B15MetPmpKTusjkWdqjuR8mygr'
    '9wmBMjTpzJHGrOdRtnxK70ji09O3c2QH1RmKrtVZ4dCaekvKivIa5rF4DgeBc9g3ziyiTdbs8s0rTAOsyWL6GT0FcRLepKUE2vSM'
    'RTjudAMAkAwvK04/h/u3QWhkaSTCtzXBnR9w3EnEx7dHJ58Rzttk9RtvedHG13Qc/vuvCjJ+VQk3d44xbgY12SrkLvQGZr7teKPz'
    '8xBu+dAslL0GjpfGNzZsvkJtc3PDAK33cn1DwdXLW8i0tKSFwa0HZ1EcY8QuC3jVhW+jhQiptviqWViMFpQPW1hp0m+xSaLbRV9u'
    '0jvO/odINFAjUj+e8hF+L2vRgwdtIpQePGhED3p50u916NdhhyZyyDf3Tz8h0t5p+tNPoN2GdmwS1o5YefEWp0VphmgryHHTOQli'
    'ULKUrzqZ6j366CefBGWFV0GSthJdxamU+2GWyobd9OKee4kqXYLKe6UEldx3derJYqLgzonxNmN3XH36PF1eTpYLKbxYzhZmvVQB'
    'jJOMjBtI8NKITB7Hfi/M5WjyGvmCfhOmSNqvSprJXzg/iJTxE9hs6buWeeM3PZ6kt6BrKuEQtsYuQgprfQ9cLeho4p+xYPyMG0CR'
    'jpSH9fl5XkhDgsPZWpXM9+7NW0YkalFDR6XZMoHdBAaLHXMsOIYTHbuE5j5cZN4DQD0ymXUExKZsAbr047dXK43Vm8jQDDmuk/1C'
    'DP3ayWrtgNYSpR81ntxa+hGX1qt6M6pVFXL7XztQPxR0sL/44OGB3z5YTF0ftCLR6T8N2SAr7bIuXoa2st+s315zp1DPBUkSZ95p'
    'mKpSvRf9XUaMqmLKDGd9yrItYgcz8H3EpgiTgIB9PY0BdpG3hJ5mf/S0EEUznUNJSC/iCBlxdFfXY4MDQRrLMpcEkCGO+5ByDqwr'
    'ABhxc62+0aswH961nPD9KnXJgphVFjOJfXMxQ26Yzm1e8reGZuEtpLJjRYvVxehQTehQMPPToaxXcpQz7UH7AZ/9fDKi+wjxBMT8'
    'AoyMPVnnI0nJwffLUBxgsL4akhF5EuDvpDFxxTa2SmRdGUsecEY0tY0bz88rsJozSeuKOdlu6lUhBkP7z2CZnWa0vGmKBxNWJF9F'
    'tQe1FhFqS8jzRdznA2IzH9bxcH8JJ5WOK4a6zxaz9PXzQV3LZQdgT7nCA3mub9W1Wo+qrRwcIJORtP7lC9X5wm1/+eK1fMDi36h2'
    'KMUOqdQhlzrkQri7tRziRXOZn36iQj9xoZ9+4lKZFIlu9jsnBxJzpBh9Gew9EaCcOpjjL2P+4WU2MDH+mK+LJ749/L1BtU3hpJQq'
    'poL85zTjtxw9j8mCFh231JawfPqyFXEKBNvY/GMpxapPpVXVzczgiIRYhsEsGNwP9mVoqzSglQO/M5M6hDjntB90JQevzK0bRrv2'
    '8z/+D3u5QQwohgb5SOIzi9ygETgZyn2CI2mGyZ3E/G8VWuAPDWuSaWnhMG+ilQB+PypoRxLHy7BdHBQZfLMSHo/5vvVMGOCFJCOV'
    'kCR1570rdwO98yhML/GYk98XnQ6NbXhR2D/LLFxtNd6LJOQVHQVCLx1YcNm9UZ323YSpgLVQmCq3mdgCXrS4Qw7PvIrozZf6AkGZ'
    'V1aXOcUHbX1LQ87T0nVbYvZRUxOwVvRxZ2fvy6s3b98ifUEyTlsi3K8ZV9K7CQIrZOq+HVFZWzEsZQiHGVBBhu/s4d/HPcOeq23n'
    'O0i4JNCu7v+CBltfcLmAhU/Iv8YaIBdRvOWmZ6muTLYDVokJvSHDwOUWq5IigVKXqnV7E2FTEO8TFvGZWKaiE5H3QftFUA3dWkNU'
    'bewOhvMAepNN0mOY57OLylEvFytPe1KEMhE/9hQ6NFyY/99/aaKHBQQpYm7t9Od//OuCKdwe5flooGJzfwZspypNtS9lp4ixgfC5'
    'Pe31YZIEh1PkWgDCEAEjT9hXx9AEva1sAI46gZasPbpQI09eYi7oZVzm8sxqjC7uoHgOuSnYrVxxTd/eCr6XeGc0wABt45HpgqPY'
    'JNjZXEVOP8nhiCK6E3q324MxW9+qeOJ9Yl8PmCJhx+tAdxTvE2YFizaREvt992xK9MMiPpqRvcGpGBEYMJAhKmZTfkFZh5hWLEOC'
    '035R02SptN2U+HHNeGa3vwVPY2mJFfKskvHBS6EEO5yB6/n5P/wnVdkSEOub/wy6EWGhEADuP/uB67NLXPk6ZnArqMkO81QLllHe'
    'J56FxKT9/3v7tuU2rizLd31FilYHABEEKdnl8FASGbIkV2nKJTskuTxVJG0miCSZJoCEkYAommJEPXXMwzx09zx0f0G/zGf0n/hL'
    'Zq+197nkBRDdt44uC8w8ee5nn31dm6+kyD9VfNMQO8bx0Ta2n3Q5YLq2yaDUsBDZTZVvhOVD7YjypyUo1KwM7V+9Ug+h6Dtvf+zE'
    'oJptTmnTcd3rLJ9HkJBt00BHkDJM6Ko5eVUYeUEXqLoq3fUZr1OHyeZl1r0zncl+m9JTOi65ro2HDviRtAf9g+3vZiPh9neYb+OB'
    'kiY1mQO7PwQi6je2GB0cTaEFOrf8qFPHw+QCoqbv6XeOXUiCOsnSKfDVNirdreIenhXW3bMC1XHQ7O/ewUHDFc+WvuoQeXN0FHAQ'
    'V7YjDJ01NKrMig3kufOXsL5v7P3bP0cYdzV0xyb9cSeyTq1q+2jLEDFJJ7Xae9fYKd7z70aHsFn/Eom4ZBfqWgPSbjqWC0EVf/iD'
    '93ZtGcONsesUHsGhJQQi0AdL6saICL2n1WuNGLw9j+chYihyMBQYd0tCQ9mNioFh0Di5u5TfIEYttfsRl4gFa2kSHwsNi+NmqXUk'
    'dEJs8AoVY170YpqcLN7LqihGy+c7O8mDT2fvk3vXX33z6q0lPKEXVUuWuJMsH3f5vWzdcjkno611W9AAAMX5Zxy4a5UIu/aFTxYX'
    'm2+wAlRNg//ojn3oPU45D0qqLMkWZx/X5LyQWcnGxfSspLU9GB3tcncpApG7y7EhEWD1eDe2/YsEqCF6m/WLurKLbx7diZL1uRK3'
    'Brg6K9a4d50VR1BDjLJ1GGvyNsK+Oit6jTzkygpunhW+42dFE6iilSUss3HdcU/aCyYFmTQmBqku1uYocrEcsQr6cSgohGt27HhT'
    'f027NH96HFQVYZ1ftwZx36vM1ysOoE+PC/V586hkH1muWtL6GvpXMylZ/cy6wqZMuUWLISW93yKVVh3aDkmY3L6sUulNDSRUXavA'
    'SoVboAGgrq5XFTf2YsaDV7nyFryIKj7WtxvO7Z18f5Nzq5+Oj+alX+9pW5lat5dIWHvNTKWBKrR/crQfMwYW1dKa77Sl+79lexTR'
    'nrwTK/9dvX0nh68/MC5/VX3kRmLdFQNAH1yBo4jvHFfmoz4RfeYicwFYbckXnF9gFEqyEym+xpB73tG8UmO3lOg4v3jLf+uKPEne'
    '2bSbR5i9iElDDV2mfqLU162CzBzmA7I2Rtx3YiGSr+NhrIVBPGARy8KMKKTWpBnK1Zgj+NwcfIC7zT3OVeR56aK26GnVppCpa1dU'
    'QVP0ajBgE9XQWKTkCuXLLdUvk6ryZfKfq3pJdKyR7uP22o/EYsO4yIXzXuSgQzqUxtjXevDhYzi6CUfICm9c/Fkch6tal3Yv8sZp'
    '/LhYX7/J1p7o6I4zEl3z7HZ2cKHuQgHLXaQ0RdoMGhcm/Fn19H7B95oIlVLNzMtVg+Rp3cd7mJ0Ulv8NDzwmB6EEALiBAN802fjS'
    'fm/cYSqtkmYq7+7W957WLMxxKrOedDd4nnehkf8GAs3R0UbNxN+Bkxzs8nJEsvGo7FEThIYsGrIEtwUP9cUiPTmnt9j2QGEaOEI4'
    'oVMFzNYVcBD52QoZ+uKKaeHpxeGgRvrqSqZYCmiHc6sOaJp0d5ZNS0UxW85Y2NnMSmqWXk50jhEard8CXhmo6gYjqjHIg1/ymdlo'
    '0ArY2oJAaeki9M5WIKJHUg9u7WwUHEfhIxgUy3LENCEoxcfgZz78/LPhlXotyk/s4u9EVv1CpPP0inxaN10Uw668QzgtIQwGJ+fp'
    '/JnQDHoP9Jzb+VU6Gb9ZQNRjvunjzr1rM1C/iyzUHdC7jU5no3fTOY78zDklf81n3XYNtfPTM4SgMj1VeTcgQqrQa2jYzs+6T9C4'
    'b04NtwLZ6CMP6V7fJ9iB5x/ePl3ELtSrXUTXObPX3Bjk2MY9rvi33ypwLtwJLjI4hWXvIoSdqqayiwHQYbpV62wfH9+7xveAwb/Y'
    '3HRZQ/gp3LtaPn1kk3gAEf7IXP6rdkI9ZYjbKucnfXawoc2DPkzemgVs+wdQtN0cmeAPt7uz6dmHn2bZ2Yez/PTDZTac9R6hks8/'
    '63cP0q1fdrb+x+b2k8PyaBN4oDXbWSMrkRmh3qtN6cFRG3wZGtNkprMzzHezXGPa3cwNhFtGJqVVSyB7yK/Cynl3lYTpx2duBaxx'
    'zVThHCzlOfPr6Cm42Y5Jm92K0idOqz/WXTpfRryZsRu9mtk3OW6r7ZFLhc7caBTEKWd7nb/TmKoxOy+D422qKDhBTefjXoKoXqlC'
    'LtdBhHE9Labr9NITr5MeREpDdgOrep0MBoOxu9Hh8683uoqepkuWQ5Yho+2NLP+499uC8+MT0XcZhsBFuAgA4ZqoMOGQ5YS/75F1'
    'qjy76nkeyRBrWqxRBDg76ICzgncL3VPwg6wUfiB5Kv1eZFsQVJrOaSyS/8ISQl3e2E9cmQQT9nm1j8zIdXBxFKCaMSA8kL8PHOiJ'
    'msKofoLTlP66azYu/WTg8aIWzAUaUUGFwz+o1CX9ClwaU8/pJtRXA5ISPQ2Weg6l2Q7oJUo/YsV6Qo7vQh+aLm6Ojo65x13auiS2'
    '4gU22WHTPHA8Z6iKJd8WztUwGPv8QbpLp/luNyZiIFRHm45uBbIFl4fe9lneR+ibbEoZVy+G7U1aZoBjP7Zz6Ei1545DYBU8kOKB'
    'R3p6qGJ1HiI+2fZUzrRb5uoUIoN1pvDW+yGFSel88kniWDrZQnLAWBAnkXzBMUIKNc+YnIwTnAz0KO5DjCPFI74uUIhuVqpljzon'
    'H6/om3LK7BgKeQoh/YIuW2XHfScshqXc3SVN3NVYkV0E1TN9UTQYEJAVgwGjV95mOBHN6l4bMQJZku4CeGwq3c+60F/Jg+7YyME+'
    'jwcphHsEanV948uZEeK6Em6kRWT9e7YTKh0zosrcImMPELHn/RcommNYfqJ55iwhmY646vVYzMhDdUSc0AXotsE4HByrdCAEbTfZ'
    'iKbXFcYUbxzDee7gSAZ4rFw5kIyMt6xntGbOqx5uPWu60zm6zc1p52owGfkLk4MwzdfhlHuB2ys8iW7R6fWn/RsNMprylYVOINZo'
    '2mnGKwhP/+VYuGhLgdMBeml+QrXYtryroRl4VnGhcUaaCbMZvHlweLi9e39/4/Heh09+EHKkYU9bnd7tdDHItJnc3NGYtHRksgfQ'
    'mAhYA+DIDOZf+S1rM89BO2mfP9AkCvS0HSY3R4M6BvZyKhU10q4Pl6fGWgcJo6vA08xMnuLBl8vTU8jYPVUuMXxT1oeh91LBYMj3'
    'vb4RkQBtqOlFUcTHpz8ka2aMGd476LV38H9GJz592KUTAcVpbtWd9zuf7/zus+HvdnqocmvLKy2ZQxRwgedgN9CxF8JEzLsbbyGa'
    'mVsmVpqj2fB+NQgQqDUI3cnnToiPo4WQuHUHPAFTDIbPHnzuPtvxsj+ytrKg/AR02nU14+E5kZ/jGmbx93ILwb5U7RpKPAwlcEa+'
    'Znh7vZqHX0S9j/jtedpS+NNQIxRXWWNoLPTQF2KCzpaeffawpVFNL8TlgCXqeQanPgT6jviLe6ZcDrm3tBaZeP1X/mMj7LX6h2s/'
    '0H/5T9xf9+KhW8NV77/wY5qnl7Y7fWfM+Vtb2+RyxHINBoboB0Nh2g6guxb/ZUv8hMhBuPCM2IWjuctpIeE5kA4cBZ4/hnkO9Xyx'
    'sh49pRqPWc5kljT1clQ1iHIGzPXBLJ9lb+WMLM/OWQhLMiFsqpCGN1qqY5RlS76VgfUGaCYKPVNeRZbpSWWd5Jdusk23k9qR9yyV'
    '8wRe0j5cBGiYyEImZ80QACw+pOwrSFxfQ0CA8pmqRuVEXSCX/APs9bby1tsa6dFHO6bAktPpFE+DKKRTVvcKopAabamRMd2NfldF'
    'FOi1RIa8Lf6wmIy7k1FMSk31ZWm545OPLpcRo03E13Af0AUWDrC4FboiCCkneoy4gZ0dABeN3LUpb7aSBzf65jjyUVNLkWMsKhwx'
    'I0yPPmhw6eEH/BHgCbTBUzaIJB8m8u9HMr/I9upkf9pj7kWw+bR7ZpNhNoKZ6tSlnN1glsljchHkzNo6pB0go37wQ4/qA/lXnvRc'
    'd5Y6/paWlrSFNWrt7j++e7dnIwVnj8rPF4tZCX9ltvFhkgq3Vbg/e9pa53GanM+zU6n74cbevQePt9O9TrN+5yltftIf1LeZns2u'
    'z17phASBwvgT9guoBa39Vc/qS+9ZrR7Y3f27h/d7iPU9/L4XuU/j+aWfndkDtjZ76Fu8dz17AGfP2cObxzkblz/QeN7WuHpT05da'
    'p6DkwMu9mEd58kQKQUh68kQLabb2B5arvYaFtagGu+zsdA9HMiD+dN3ObXawmw1S6kRNHEdAleJjc558FKWZnPLkTEZRC/PD6b7x'
    'edJlhZHj7yYDkjsUNGM4cD+zTs9Fx+fUzi8LGDKVTzU+jW1SOcwV3js8kme3fzg+PraYFHzTqxuATjSoC3ko8mDvWdE7Clv1Kjlh'
    'PVakNMEebm4ehTwy6J+/No4fC6WPpjxinzHzeHnce1Tzdr/xirZJmAcgabCHXl/YRUDR5zdypja7g/tCK3qcIN927ND++EnykBTk'
    '/CFSWZJcUhWGXsgz0o7H55+2vPyUPVwz7d3D8v7B1v0fj3qQAuSPe7VVCF3qPD6f73XWV7e3bg1/jkj52rWr1mML93N91SID5N5h'
    'ub/drwoUPxweyOnfPDw62Nw62geWg+oKXfvRMocgK5nC2l31c23Vo7KrFl+nAhASHwbyv/qk6gj5Gt3a3d+iAFYZMLjbo2A+rh6F'
    'DGDyTxKHAKKSUDTuDx8OP3hLrKFFgtIfHvYOP2z3gpLDdsuJO6F+bpxjfAq2m+1p18Gob3otcc3t9pZLu2pebJnpHad3tm/XTmnb'
    '0pG72Xu8QF/lnznAb+RnpMiRd/LwRJZOfkT+IHgw38NT/dSgc9g+vp7b16hyXqlv5OobNeurPWCl8i97eRzP7+pd02Vw3we5CRCq'
    'Bwqx7lDli2xy69m/RQNcBhpyUPb6oRCFN43XUhXb9cDVvYb+bzKJboRA9qT5XrN9I4FBI0hmHiA6bMWY+FE2Q7ZDap1Px4WIqxOS'
    'yXDDLVQ/gDAprwraTh7iglPt4K4wayOH+0Aq6dwDJoRqiKnHQfL+fwmvp5Rj8pBYSA8DBGonOWI2lM6v//IPqmX79V/+UdqN5BIn'
    'mWAQB/GEgRk9Uv3ypsYPb4a5in0n3KXkdKDV3GjLfIwD2lUzAKenVRe7IDa3dgNljwY2Heh+MVas3XEnNInrS4GnZL8T4fIGCFI/'
    'wVYAbzdf0PbaT7LXKuNzG+Tgp6MB+wV1hXUw9E7XuV7Ql7PeH4iU2SdK+RHFThl096d+rX4hTdZh/BPhHR9uj4W1kxWUWqDSeoy/'
    'cYv9ZIjpzatM/4/VbWICUIG7WX2rRKe5YW3HUllYoySqxeWs0Lqkqu1oMv2B9Z4jmPafAobxyumN5gY132ZyPMnEB5XR36yhSU4t'
    'QVWIozBr6EttDxsfZrzOYflBOLIPex9aSdCHyr3Qa14M6MUKxs10DPI+zE97cRtXzOLJ2rIsKLwusiPhyDdPMj7bO+41hfMKeiuk'
    '56/mMoUItoOa1wcelzmTVG9cZFe76qG4Yew5vc+Bwx6DKJyGSrqLGspVLe5y+4etra3DaRdI0G+O7u/3Dqd8sL8dInKCRfkAPgME'
    'JoxCW03ZrXkvsP2gPPijQuGZBTpGNwOfX5yqeTmSH2o4Y7L36uyurOlWnc67s68bh81y4dCnA3twpMuEYgHUJ6LSBxudow/4j+N3'
    'es3j3ByStxy9a7DlB4eXyZaIb7vYpPXe3r14Vw9utcdM5uLFnNCivAndrhrkawM14abReVmTd1rRw+rVoPxCZ3C/47iod9L4O+oa'
    'DdO8n2w9iL1VzF1lo46JtP3DxuD+RlyNJiZHZTRSEGhQXjzyibmvW1pyfdaBrR76EZ0eq+fpgB/pBrVKo0Df3hHPWE0zr95ff6Zj'
    'rFfq011X/4B6R385i1GmeXWgKNjudQ8HhTlgfTiUjqblee9w2yYh0+R1kbuOg0Nrq3L7cDAZeX1P/K0F9i8iydnJ/prH/lXhQNGk'
    'CrX0GBaVxsF2bpFG3meFDOavz3ZoHLgrfT/N55Pu8VsQG3XVgoPnvev4g5vEUgKVRQUUdJJCxZeU4+JykDxDUp6kmO4fV3PYq3Pj'
    'a9U/tlf869/+9TiaykVB1Gm8wRpTOxz4qm2yVdW3RmzkFZDhnVlYa+OgHEAo22aQp65MZt9HcPwFNOaqg4bjrPy5z/9KrVVfw6iN'
    '4ZVrwHJZuV2AW4MNHWT1ng5mxayZxCE7ijfV8OrboPNfW+/aauBZi0ycYAbn2WnfICg9KyjP4DVKK8J3r18+K+TkTBG/Li9cjz/h'
    '3FaMB6N8bhxfPCxvcwNx0Ttwu6bX0mExKVcXyVdlhvFfTjtXD1YGabs2O5Q7Kt+G1bnlt1gmfhuNbMVa1HVmpvKG2wLpDNfiynxh'
    'lSA6RwVaEKCDfwlnCS1ItX+FQsauXC7NbpvQFsOCO/i0GuKCI4/A6D7SNfFcgvYmY/tkS33gOrVQ6s0Trj4diT1WQ7GapmWiI2If'
    'v/GgVWFw4XYyZxj0rGJ40tjpwF14S08acpEu54yzzcxjdwbTOujPGSIHaKz11dAXVbiuyL0FDC+s2oEd+OSTpOu8Oj7QhUJ4om53'
    'f3crEc5yut8DyONE9arnaimx9XXtHJwfkScA9LqZmAOfU49EcTHIDJC4qWSjdo49vdaexmCgP9xVOFDIgO6r3wQHesT/L+93VjnI'
    'mGBUU2wpAnCANfWlnVvqKoSZUf7OtaJlKyE8aKzh9gWDhGxsK94MHJT3B8FgcdTUeSkBw8w413GWFEJHdCZ6PdjNDdKQKD6M4QAy'
    'RzHJot3MfZx1nCJcAHp87PB3TyurKE+ptlb/LU2ShV+PEl0khHw9XcgkDpeLTGbGD0H9tZTB8iW7LWtjHnirLo8ojzwZjIbHjjqh'
    '0CfYICCV++p475TOkXMnhKMJ/AmbJdbFclTQn4CvAIDFCxErHbCruc2bP3cefOo9/KuL9IxDymcGJ6m+2XmpHhRKdQiO6Do6METH'
    'eHj6rG1YfFMZzocoLMWlzunDlLXdo29OLW3K12rLYPdiyOiG6PGJ6ZMb4Wn+I7lSgZHrLsmkU83eyJbAo9lvt/rQXSkHw1rs0MRY'
    '3Z5XYmohfwiBKvN09JN0b7rAaex2hsSKyuhsqaIu7Z3aXizZJlVNm8bKgBr1/Q7rexrZdzbnMp3mi/wXyz9eJwYI1JkAA1Wq2aeT'
    'I3LDufPoSJ0/lJGjkeyyL6nbinjR3dptURrkzXkmjMUCsQM0W1ugQ/nIHHUrQR5xiMEgYuzVygz52LmF4Xc++ua0mr00pF98OXK+'
    'lg6TjLm31Gd2x+kUPWdKD1oNN1oVZYQaWqKMYq6BkBS2UARqyblB8gWToEdywuVUwcPAP5Pw5xFqorRQVgKg+av8eb7oVnW6dWCo'
    'C6iViAil5YxV7bbBjFcDszCTRECVrjZd8jHTFZo24Sg5KDB1WItpLZhr4jMAWJWc4c3J4D1V1xfJ33GcveR+8unDnWRLR30/eWBB'
    'X1KS+eO7kTL5Itm2j5D8Qwo/fLjjF2RiDovyTW1tqv7NIvX/t3g4Tw4uoDTwPs5T/RshAvgRKSfc9nCekmlZ5mdToLtc1yLcavFs'
    'FTVNQA0S6VHP+7UjA/7tTa8X4Ya7x5VqKl7SegtXL2Ar8yjcv1NzkJY/nIbBO2S6EPDp4EccBmnTclpGQYA1FLh89BUhHMhS7One'
    'hMBg4T14XPdNbAlwdDfJh0+OtiE3tSo6IglNFps0Q3nhumt+NTKAnfdwTTKw/YHR0FFYcFZ4wNcDpaU6WAOmuF0LVbUdP//RTaFt'
    'njaFlzTp+Q5o+jGj8cOe6+bKt+ZFDE/fsJTNkj6L1HSArdrIneeoBG5RLdKzoohaJkltHFGnxJRv3YU2UIQowuE1Ik8busytRASK'
    '7uD+fm8XWsLevvcVUg8a2RCWWmAyCROg1qaYuWTqBp0mAHgXwbm6NuXBzSImrRrDB4nf7YBxNApFKqaJWHcKvb6jXBHOGV0prLdA'
    'KIJEiCPdRavNdBDwiqbxjd7aGuCYTCrA65Fnd+QSrmGH9PaWny2O4eGpd/wOXPPNrXe23ze2n+Mo45Ewit8KUyTHPQrKE3GHCqT5'
    'ROjxLxnIG2cafA/x84TSMRJnpLH4JW4ul3Bsl5fzjQJvlsZH9BVtJuIDjKh+HJ6tBVZNue9KSpWQpWeNH55HVJswapfEqh1ajQ64'
    'f8xHZbfGS4zTK8QFm6+ugg/O5upmrbkaVLEohfoU4qEIRF8sfRFATYTECj9WAXA71YB4ZBQGR2iInuf5KPsDuJtepF38ZpYhHPTe'
    'dcyimHJRwbA27l37adZ46ps7hXDdn5xLXdQR8x41LBMNcUZcMj96ns8R2YyXLssNYOTw6Sw9Qwryi6zkvpllpqRFjqZdGb+OHM7m'
    'fY15tWkf3MHXL8YtgAijeXom4uC8DtIB8fGtkL7yNJvvDyDvlPuRXhSTVEI0bkOFwMZa02Axa6IvnFLurDbKoe0PZI8ETLdY2dvS'
    'tJUTCVXmIPg8Dixg0Nzn5WY8z6bdSGUv802Cms3paaELvfGsWI5H8D7n9mKgMGd4N9mAw+x8LqSuLGVN9HLlTaApg8cqvDtQimhd'
    'WyBtCGTZnJJgOEC6JQ95wVnRlEinFvICkWU3OR1cZsOLfPE6G6eIgacyF+lgjCdVh+NTMEY6e01gDe+Rr3pfZyRos238xyesJbye'
    'cZAk4HHGNIRUq98xsNwNVKOYGrxU0t1AuDeOQjHf6CcbqiEabcA5HN0weLrMcmIHiEIaRIVWITxS6n9eLOXFlqaqTg2nQk5RSeUQ'
    'WBIIdepVbpiFAIuiA7biWOlVi4xCmWKF2lWJDn/pwQr5J7JGF/NOnA8MYMUGKDUCvrjIjuk4trhWMUMsQZN6NtYNMCtzVPvGyeLE'
    'hDegCLVlRw/CEFpnN5WlxY0Ncaf7qqthWT0CWrzS1FKD9z34vFDMiUpcRSWuWEIv1qpU4OZN0bIgIoyz0wXDjd7l2SXbgZB1P+Gf'
    'Fzez98dYgVkocsUiV5Uidu/52t3+txmH262Padu3U+ELN5N7+1c+XXf0rIwSDCi6cLVZn6Cl9XEjFasspe4QqBtCKpZoUR1HXk9P'
    'UN07/gNDmqm1/psAZ+Id5XZOc7qYxtG6S10J7Oz/2SA1N5VNe3PHd+O/DVcpXiOHJPLvQ1aKa+Je8yhHa0ZVScXZ6It8W747a7uS'
    'h+MVuGrjizWQacS/CCbh8cVKtClP2TbHFwHqSD73g6pdBMKQlIQIES5xkSoPB+rrEro1Lgc6Gw1mV6DPk1lpwJwMqiM4x1y2irT6'
    'SIl+sQQ07EmB8kAc7Yyydx02MCXAh4aegjO2Bh0pf/rttz/++cXrNy+/eYUb8+HOw88HDx4Mdj4dPPjsd5/L/KHAd98+f/r2xY/f'
    'vSZkLCMYdre35+nl4CxfnC+HyzKbn5j2VHb59pcptJR/zeYXn32+rUauLWPctsEnb49kpbaFDkHhlw6FsX06m1EksmnajfvVd33e'
    'dUD1J+n0pU6jf2TTCh9EPgH51RG+fPXm7dOvv/7xzdtvXr9A/6sd2p0WW/bxVoGAQelWzRNiXKSjp+hllCzqD9+8eescOaIRqLYl'
    'neXdzrb8d5uvOr2aaY+nx301cFsAmTdqsy3kJF4gEBaubCCD8headXXZ/OmBdCXJsGVzbljQvQqQOiqQS+G5bJNxMWPIHbYRjcHv'
    'oGGv1x3V+JVQx99U4Z+te231IjJOfz2X6ejWXwvR7puO31p/dp7JCe8Fkny3PqUGR/E/4Symj0a7BvxINFNZ9emoZHgGEFDHTMTD'
    'THqwqUjXl+SX9B1RKGSRIbcq00QtN9kVGbNthth4RPOAiw58I9yR8IlQhr0UKasra/rjmxcvXjmRr2vjLN13TKshXRCRhxwoo7fz'
    'xa7CjDLVI7PZAZn6CvgZMigABIEn3FrkE+HevErJqtx3dWMjNeZ/N7nLj18vpz03x18uphTdHLAhQEc6ebklLXuwmXh0ZW10/UYz'
    'aoaITwMArWxj6AWFB3a+v9EQX0eR6wvs1EkNeK0T7I3vWMgum37y8Hc7Ox6Sf/ES155wB2s++Bz67c93drJP3SKdUgZdpEMybrpV'
    '8GwkNNdA+3Xt3fhb6I3Nw1aZZdCfSa1/diuf2rJ/9/YZIszU6IKlVICmS2BHAUVqN/F0+iHo9KcAnE42Hiavind8tRG5PMaH6l0/'
    '7MpOp+78CAfy0fVnN73Dgfw4HPl/t5k2BB5qwaVsEnbTpou9zrr4z0C6392EtqrPfH6a/ntTEwFShSsbJkNJUwr7PHrgiGUqkTB9'
    'KfuXevuJEBaRBTsUleTvqyydVwpgfv4q+x84SG+fQbNuHkw3vF5UGB0XZ+YQoiQ7fhq5ZWDX+1dVylal4abCwPncTS5FLCTImF1B'
    'SFhJfYz5mCHm0+iPbGGg2jAMXIh3kRkamT7ixe6Oo/ZDJDmMQr9+OT0tjCl1l+KbBWpVEElu0egxpgFaGWxtTaBnUNmyYzunaQ7E'
    'qCo8vT+GcSz+YmpynqMHiEQOj9DU0mDqpWxELBbF2dk463bO03JLuyVduHs3jKX30dspGrfcKXo+KQTzPll97f32Kw1dp0Kx3uqx'
    'u7TuXYfn7ssbABmxP8Rc1h2AiLGNP7try13vbpWVbm+Q0PkIxWfnwu0Jpx9IXTRL1VuFYvda7xE55GuKDFFgtqYAINFRhhDEK2vh'
    'DeruACYkwLqbH19HpsctuZWoLewtZ9Uwr2Yrt8WgXE4m6Zzmxs5TEiK3GYrTxCDenpvS0PpyVlQ7OxNBUKqQEyRvqg2BzYt23tSw'
    '5Z+LpAWuENewr3M1trODfKS48SehGQ6RWKv9MlV45eXULqAo0xJmFlnsp6PuUJYNq+LusIV/Uby3W5WMJU5eZRBrj8mGXPdTTSnF'
    'TDEpPViZMBqpEGbL4ZhJqei9ysh+yBNuU2sO3gFhG8FANJhaaYC+sRRNQO9Qs9HC2scVgoYeesKFFXhmf8RCzK9/+9fOqo+NvqED'
    'XonHCitSUPJ0ninXx9iE/ZV9cTkGNv6iOT6QOLjgJT3Y8B6zMvOBGQUMNE71K8bJq/4jUl/w6nG0D5cN1QzFWYMiwMLjrqTguBqT'
    'BMWgWHVS5W1+Ms5wos/XFDv/7GN0YUbM8du5ro2a5ACY8x33trpBYxYl84wijnQWk2h+aCS6IkrUSqleIt7sDSbUG8k1eGvViLIJ'
    'ZDcpU+tw56W764VojNw5ZLoqM6Ke177IHKFqJ2iZ2fUVKJpFZN1cxXL4znvx2MyKFRWZVV2E5Y0mWPDbCkqMvFiWNjbLXBft17DJ'
    '3F4lm/Mqu8zgTODoQNBkAB0D5lXmlNIEU6Db4WRQm+xYoGmBGZ9azp8GDpAQ7mxeZT+CmB0nqq1L2HpSt09UGPQ+o/NB+k4oACJD'
    '5dTOg4ttJb+pVuaQhTLo/2sS+CY3L3o1+KkspvuLJ9hwZHPlMoCRUjonbBuYrWmxRUAk8KA9Fu/GHPPcb8m9ilQfdU+mvDYvsVwy'
    'SadLp0CvcX+eVD5qilN1uTQMvDrpBi8Zc5pqPPZKmXkQxm0341l8AytCYvBorHYT1XV4gZKcRrktaTPXws/zEnmekZK2fkXGkmN9'
    'Bozeq3LVzVTdinOLC8BOcG0WbyIu3HfQK82V8974OkXqj5qGIZcTQpVcQxboU2I3K3N+QmRMJAu6TK+qXHk0BVxI3BpaBXCMGjzz'
    'LVmr3er7eBXTj/FRCvcZ+vH7otGLW3JOtTpGeYkjO4rtEbUiTYNFKCBz1FKicagiTisSdN5VGUu/1ckHVzvxUatUHZOYWiJHzHy6'
    'ErXu07Wb/NFJqqZGMgDGHiH3iE0Zt4osDMFSCwDBUuKQxQyhB9UQZoCu3ZLKVbUUWyfn82KSFeUAHuf770j13q0mdgrKVHWoSdcx'
    'JR1fOB2cq/+5dMSKqdVM/o6go9DCEToAy7250W2jc+zAI6nGz9OT9aPpoLB5I7hOfORI+W0r8ngCbwm/FusaUkPtFTxr3felSvsj'
    'lyApg/8QTas+PlwkiYaRKaZ7dZpW2R46hpVUrZ65FalfwolzrX1sMnh2ZNuD/fYXzKqLGfiFVx1rX8cAG3vPjyQ2oj/6aNtv/SCp'
    'Fz3sKDb6QIW3BvmopLGTU/cXLIaLv8urnvaWdNcliz8rTOQRmq1knNjtLnuvKoMRl+M0wR/r+mstG02c1BAeRgtQBflT/L4vdirg'
    'fQFm7VvZZHmZKaJGpAid9xGm6KJPTO1VYwCUGHS2O6tO9iNLPV0w+7mRkLmLgwruM0Bwf3fTQewic33XDB43d1RPDOorAg62azf4'
    'EHm6GrkQeRItxaJCvGKbrkbXq+8AzmnLza3Pb1z1svAwKUBN1KjdnbCuFMrVfQ06sPHyTHE8LY6L6DeszBRlUUXmiaQaMWoAssHJ'
    'cg7XzLcuH9AKlbtFtwSte+i0N4I0uhyzjc5UajpLx5nAxOF2PtNebs3zs3OoyuZThNgXTBWbXOZTGb/zenM+W+T+rYQ7Tl2eFjSj'
    'jAz8En2hKGdozzAO7PKMVNW899p0kNix5n9lC7vP6ZKGzkSyhVHlSwT1SnXPxrlM6mu5P7pQBF8nHNVuwsCJ75FarG/jtWd/yDjs'
    'm0gX+f08ncELmTnNdFbMpX+Svu8+eNiPaku25DxoGaQ5CSnL2muzDKNt1VlHUJ+VqlZ4c8dQFWUDfjPUDduNp6yHiGs87kZzIwvP'
    'GIvlgqfvIx/qJIMapC7wqlSk4H548hVDcnaTg44uRueIW7Kp/5pn5nRfaUzNvqYr5YGuM9LIrCoMo7DSaXmRpGfgkmh2c7YQ0l6l'
    'vFVWuWo24g5iUEkRmlBKyCd377aa5ioW47rt1uIvz5lf1OsVgkWakox/7m0C6kStvsGVoTNEablw+wULYDVVTJto0DGS+N2rl269'
    'c3w/yquSuBFQZX3PE12q5mzf6zJqTP5+8lJz74JIkIdh2nCzirqgVnXWpB3M0P6VwckXljBFmdhYXeY0drduV9a6/E9otuKyam3X'
    'qLRFJvvQ7sBR15mb3C2R6Wqa6+1umHZjpnO9XbtA0eJko7vJK3cC+jry6rwFr8CwTp1omm9bQ3XKOxWhu8q4BRY0d84YdadI5wxT'
    'n/eV13iNKqycwqSt1ldFW5V63lut1JWDLp8+qHpqrGy45tsjx7cAY9Dq4bnIZlvDqy38K6SoLCFQw9NzNkdipxN/fVrCIZYTqqc8'
    'KDZvYckxmHt+jCtCdWznmUtuWaIpcoOZEzCk5gt/CorTU834mSNwPGPVnXfSMjV2C4Q4KMNQxve5VjQmMVfXoRTtnMplklrU+EKx'
    'e1HpFOygbD0cPoRCAxWcaQNlWoQ4EufiIqeDt8tTdJpl5sp+kaH9VLkBJjRbBuc7Jbhvv3u70oPHzX8n8j1ll+CVcY3K9gf4m94L'
    'GXFWrNbnL77+8Y8v/gJfyfJP6Qnxxv7P/1NFBUW0jmt/mTsI3ePHQ5dIdpkjkfBC8VRdSfgmM5IEhTW7RQzY5HQG+MNxQJZwznIr'
    'xKHHdAvSnYwMCt1KlIEPjmWTyuHpCpwu57Q/U7GKOP8C2M1MMlVQXuIikLkXHk04JhSVtuhhYOvEhEdj5sUyfOTsfQqwpYhhk6l9'
    'kyEfZ82TIHRTmK0dxOfbaPjsUeQRzv2jeUFG3QmnaBLShXT+hKtfFjtlGr5Qi4diAXgnwswt0RIyJRGFJi9fF8WiO2WNnLppc8bi'
    'WoJOh326tf9xHPpC1aMlNqn1/sOH5O4k3gw9N04p9+15sSjk7oGPX15G3l3opqZL+N5cBnjGQebcgwmCJ/QBFi+H+Q4mgVLTGxic'
    'WHPmHief9pJXXXxOU5N0HPmofFoWtHzQ+ExRM19iSBHMChZ4hwgh8TIrKBw6/zWoFvvo6P6zdD6U/TPKi/cyP5WucrGGqxfrsaxV'
    'pePDSselzYOPVFEbhMXvWGifReP0HjVCaXy8TOepcGWIzgEttEPhAp9xwJS0I3RiqvBlMQl78e0bzIlUdu0CmDrfZ2NNk1fUruRO'
    'X3kFRuV2Dap4tkeLqr91LtOxuy6MHjO+3c67McugwaOiz7tET/OCvDXUdMYRtN5KCGI3xZQ0HK6o6kWkMqV2ggSn9Q4qpidZ7e4Z'
    'QCPDzp0VBCHRAAWhQPBq0yGg0nSsThYXIhZU++Ro8SKfbey9XFgwEfmq5MFOMsmnS+r5XTsilErzGPf0SuUJn2Pq3vVS+Lt/++dO'
    '70YvP9Pu4FCNyZF4HkuL7ktJJ09baqpFMWP/jpObfmWNaQolczXxVAHw8RD+5fUnQpURsdy63i+wnqZq9OK2ij/apTR5PNzz9eI6'
    'cqL9RCQIZGZ8CTWWm8XS8igTZj4ZIlpglNK4J7OmGH3VdacHpTQRx4qwFdmxkbrakjuW6ZWbi/yECz6H0867vCQPQ/9FDTJ5fDEc'
    '7dEB/fE2fqI+JbBrFvmZxbOEuBcf0DLQGt+c56eLzbhemyyfsJWa83wUkrg/SpAfXMH3L0VgL5HQ1RwUuJ66MiM6mnl/jpYLz1sg'
    'P36lEbaouks0ybyS0cr2GJLWrdgf37sd7LeAX+J+PNNv06HNByyzuodfEtgCGxk+hLLGivCD1e3RuTTqES47nEgcZpns6h55ezXT'
    'TUDQFcJFtK7xqulsvdwftE3QBE6Hw5BeKpolM2uvmyc/mNYpijfNmkmydqqzNC2M6cpMW1E0Z+mPCBU5KzCL3uU4IglEj5P6hZJn'
    'YYxoZs2BeIWUt45dFDqqqfNOAKV9mcM5nn6FLqIVPdM8pU43N5fWh0ZXb7swn9YX5vciqsjYeL3fcts6LCnS5XOQZT8K7VlOSBIR'
    'K/R8FxpazhkLyWOrGy1scb8qOrFwMp031wP7CfN9WbAYp9rK+vyE2taaBfjS3f3qPbVqIPTvHc1T+TUkmotHBPQ4XG54EZGfkirf'
    'YnHI/Q69qDD8CL9bX8A/FbgXde+gUXC8gK3I6DRPDeDtbqvvStXRcT1+/ft/+PXv//HXv/+/cnBsYTQJI1KKYY2g3LY5sLAyvdIC'
    'dbfkwg1qQ0pE6cRdZ/aN3UhlQEZK3hZYZXVx0YsL9xOOgllQ+3g/igImfSmtdFfX5WQ5L4UqjBk3ELJRYt3Mt9PdsTT319knBJVV'
    'drFtnPVcjRKm8sTmT07LCeJJU42wjHcGr7ldS/WSqB9gGXJjYmJfGK6MSkzwJ6PAdKDoAyqvAv1Qt4fbbKyxLmQx8x7IirXDROn8'
    'aelfq7kfm+94QyKzbW0rquxtnILsx2LlPhy6op8Mv2O51h1p9MOzDDWace/a9AA3EeHn0svglL3rgYMqK1TWFI+1JX5VgBZja+YL'
    'RdVjObbzbDEfb/611gaGp0dC2ngRGHdwvfLGdCcoNc2UKw11KZ/japxnI6pNW2iFoWxRCYJ0sx01QHcUozN6zslurAfMYjppIv5k'
    'qxcD5ZSoY0G+RWH/A8gHt1we54S6kshz8M902Lta/ER4TQ5e5zuSgBzhN1ytSv6lxAyYozp1wcYzrtJd6+17J1qHP4eL5yx/R1Gc'
    'N7ndIiKYOjIP2kJBJ1QRfcxJVtvbeTF2d8mKC6xJKFjdc6tutNTsgcyybiMIvAm4W91TuCWl/imoKPOqcz5HTrpwbhzaN6rmsTyG'
    '9QWzIgLaoH5QJoOEjsFLi6K4xXbUfdWkA/P0TDWfpd1M/64LidVUDj9o/byYJSTHjKCK1zhINluWrDpfKD2HiSAwkLzbUxeArxQC'
    '17zfthTqUwoWrdSiwcXZtS+3Vq5XyESW6B3gi5+KtL+Fp5ZW3o0GZIJg6LxHz8Y50NZIdxgqyotQFggCia9C+feIHaREn/NO6ojU'
    'm3IuZsuFv5+y9+nJYnylCePZ5mWKbIIk0EHk0k23CQQO9gdzBZnPq0e87jePiOmaOakgGGST2QJSMITNumBiq4OBBV7CcwTrrkjF'
    'R/qNl6TlIP2t16Rri/dilPTUv9G7sXEOgIGTLGerCS8KgNKa2ggOBivOQmWXkVWVs+B3Bnc+PD0Zb4b9P5+DZYq34jRLsRVIYVWB'
    'QgXNaNTXPchkoHRv8lrnoH0pZQPoeYIdZB7vRJW0nOJLRC3Qjxpd/l5PET7rRx9h+JEqRkaCu2A5o9WD8QrsYnkROW+1Nmf6B/Wl'
    '0r6STusGrDS2ZtfCy8LZ1FhrOpYjq8ynTLpwCJdQPbjDdZYtLDhIg8Y0fQGoqXCb7zS9arkQIe3s/DZX+4L9I+hV9JSRaqNoe7Rc'
    '8pAJy5WbrLyEWSz7+CVuDEDhZtqETc5ENzyQgY0K73wl98R4mM577nqGgkfL8XqpXoVuKj9OVH+PizhiLNy6QwmDRbe+qe24Rr1V'
    '2aUqIxOREdmXY//i7EzlUMIsdiY304y73KYwOU1HSqLkCJzapTmWB5fpfFQ6mYHCHiVzbVGoKYHrcaN89Fjg1L7WPtkYyljrR4aD'
    'Ey5UvLSzapNnl4MbkubuucW+ImxYc9t8BUgvInit3DmnX4q0K+Tp9CXBGPHrDVTQEIDlZX52pr/eACERP75SEEcpUlyygtfCXyxW'
    'bLyvYT5MYdUCY1acwMY678ebCqskfSzbrobdeO8sx3tIRwPhPOkGZupLvdd6tk0whvj1S3vNbDWuKma1wco9/fV//xOWzf7axG/s'
    'mlJnAId7yBngwNrreAPXIfchRevhHuEkuebdWY540GHxvp9k43E+K9U9S3OkMMlJaiRNvoNRD5+xpcfbMuSI7WUGApLwxWUxSGqt'
    'm+6Li2FzunCKYO4zf9C4xxaF4b2t0l00L0rO/N0A2yfXoU43fzMNsf7C4PUnxtPYlN8af1/bks4i3dyi+dPRKN5xOSBCZSvmr+l9'
    't0qBZRSc+it0PXWSRayzikihA8EPtNA9yU8QlZRSbwfqJ/Nsg/j1b/8a5IXhHomJrntDeuhZGTBgLAK2Hhj6/v5Qdrepu63QDJoU'
    'K/21HRq2LXujnonlR9jawtciLYNq7isgA408LnDo9luEEKd12woEu9Xckb1uXUKglXpLk9ALNQNonL9u5n4NLyvmBbRmORrRWkQa'
    '5F7LNEeOkGarauQWHpJcOpBDJhiuZQ3+nohcnr8yTQnDS3XdUP2aRfGZjuELUDqPZ3jWy0iGe59w81i/qBnb4hP0j3/ev48+3r9P'
    '/bfrjjw/OICZ6+jISVCEM2vIV30ngxHC3JVdqKzH7bCbEIKcXnbmeVr5FJO7bSIu+LWS1jxHfK7UBAEqlp6t2lmaNgbsoDpmNHea'
    'x+S1n1Has4Mf9o7u7zm0WmfQb9yMQhGCCuMyvVqnOVEE4v+QhiTemb7C6ubcdhsTXnan0sFS5cSanNZX1kraS0egHrIOOB9Yjglm'
    'mqpyhatYnsDXB6OrbXY109mtw3rcSi+naJnnCa6d8QrNCriRLQJuY3NZPFgzEikNUFPsz93CwlgR+mWuqa2+fLz22H8y5KvXDtCr'
    'aySu+tohl5D85U0+PTu9RVUyQa2xWFJWugMz9sj8eYAJA4agIJasM+TOwV0Ln6N3hyohh3tUNJr+SZmCfNq3a5oHRtjbizWEw7gY'
    'xHTQlSjiytFZ6L0cu2lWVlOReDFd7xkC0d6a5o8Ny98kdJgOuvq05yEda6tHDECa+C+dBWH9El6sZC8B+oocA/Xq+hgovflGObwD'
    'Ic2780jcRJIv/E+Pi4W/1o5JbXvYZhip5sv5asjKkZTi+jT9VKEgRea6Tzga9dxv02iJ3FsVYjlguDnYxeGOauWjNVoTh+Qfr4hH'
    '43OL0nYc136Q7PmqWw+jYlh+/CQK41aTVq3/znCvILvmj8gzlZaqBtsn9+OQOKvOPBG69NphxL5jUZIhZHs4qvjC9RXOHxVUIf0j'
    't7IqQKYH6lfI6NQgo3cjk9/BzhGxzJFsHf/ePKrgXiZuUeobXel1QCGt+lVQI74sszUUyim9lcY4uF53MgzyEviisXRPVqvBj+qh'
    'o8IovVJsHPN3tQBykcD7ihHcZrZzOKoNrFOKRLETS6/ScUNipUPq43wvoLAiZ/3H9O4NK5JqwcrYQIlurSJ7VaTtaFORElo6ar0F'
    'RPAZD9SMyp+XDEThT59HwTAkW8y8BJlKp5T02n2RhlSPtG+Tb6YZ3e+D0FOC3sv14euSpcGqOs840xTSGYjepMspdhQ1cTX3in5y'
    'cl6AiZVV/VPsztRX5jS9lXPJGlVQvojU95RyTe/NRR8kYeOR4jsVndpewmYOQ11HJOkUFJyD1lBFV6LdWu+rqjOYUcKV6vp9xZQT'
    'rev3lEqA8CUPzOm4gH7E7hQRDPqRfmvMFVFuGIeVlxlMBYhsB34xFPr0j/v4on5Vaxgr6Y5fSRdImOtXL6K/xmrGADvmuPSCPBTT'
    'BbPHJ89h9knjXDVt9yVlFmf6uS2fkpcYnbkcr7RtUyoI5snqun1cf/8R/XVFgcCmwlalF5FGGQR/I5UBKAsuNNIgFrRoBpipMkch'
    '5vUEn0vBK7mihm12U9/+i/cz2hZV4dTUTaJBDCcy1lJxtJyto7U2rtg3yoJ+QlJg505jgkuktj0ripGJ9z8veeFJ44RS/rgGFHO1'
    'y5PYNJzzHSPMmirSvxYwotJ8Pq2d03yVVvPetY9IoCrIXPIwZ78UxcSL0OXJvLD5Bcvv2EbM45laTBHMAI+1UNDq4FKqd1E/WEUb'
    'FeCTzo131VE77Op1132JgVUlzx2nooJHz9y5JqsA4bydgt3Sr0j7JjAI6mlk1vVevJF7kU4OvQJ8rXWLdJ1os8wTzUXB3zftUmW0'
    '9Bir7gfM0GiFJMuAz3RYdhW4O9m2xuTnFjIi7SU7g53f4epmyfOrWbHoGiz4liv7vp8YDLh/dNVjQtqeaz7Iwq0uyFGET2UvCsMB'
    'mtVZxxzSYMwL2Ds7KxAmIogIciJb6LtpmaIb1ojeL8AKQtCi47ao6PFx+GZ5YT/X+gev2RLfm2U5ddWkcZy/BuVo7D6aAwdDZpRA'
    'r623eUVZdBf8mGJP1SWT9J2S8dXK5aGUyWLtMh88LVcefT1BFaU7vqhrfd+4I6Xkr+I4SD8F+c4iJnUVOGglhVdmkCUB1ghbdXEH'
    'ISCeuQtOiqb83rWhuhybMlO7ihC8Vk943RwKsl0NFU/LC9NeYLMoaK2qv0Gy4UU3roynrPe7zNI5jFlXbrkdq0bMa6rrEpgzwPB5'
    'xAYXMrFLPyFEL3qdaV62xz4Ay/G4ttUIIsEoqrxU226AkcjLFTgSqTY1InqsA8Jj43BNAhJQyZ1ECN8xkbTK9NRZ5m7aN/1f6CSG'
    'mmjKd9PZOhz2wk+fU77f4tpDlc1L7QXzBDY4GH18ewZGy1cUXVmmEp/rKwVy54hkIX8tVjtu929f/d6pyU3JtbAg4M/+7Z+TkkYd'
    'bHW1hQC4d34Rji48XFTvuUDOFvPQiK/CqnVOOidtWsyE8rM4dt/DFOldpro4YnSZ+n1RQMX6vDhhfhsR/70eHmIxwYA0goK94P4P'
    'PmuqF3EOay3mu2qQBFz21Pibe690U6XLRT0bFul81A/QpTQr3WIz0I8gC4vc9NmSIQmnMMrWk0ShHisvG09Z0tmM5QywUmpmTHS5'
    'nJKrmRTFNKI76q/BdE2LS2BX6ioTb8d1yhEFZXjMG0XZDhUD5d45vZU5fMEB1Ifv4CFBv8pssbFqgHQVDnzv3eQpg8nM142+ZxOk'
    'up237fSao3s6GpWR30UjjMHelxqyoCP3bmMUq+n1osmhwRXWt3k4rW8Awnwiu6pJ7g2yghSfdiyT+4UR417TXDfy7era28OpXOzO'
    'ohL0xiurzYbtPI0sf2k7IYw8O9RAO7eLcOq1FlRb62U0LhZ01jjNUvUadcJQvE2gQdR9ji1xFIcio7W31vEI2/BucfG2eG02pd6t'
    'A04r0GJ6qYS/gtZwTRa24TidXmhusLECDDWzlYXgx9UJxEJcJOZJRojg4+5ONclL/CqP44TpdPgkREUe5D79DyO2FcJeUWQcppG8'
    'sOeMxmSUuHDXfVZGtfB0l6v6JltAvapn11JE8EMFJ1S0lzXIAD7cvJ8YSHneqyOBEIpD2gVRGPVCLLQiweI5Fn5/gF5HKYdOJ+j1'
    'uWoMVMRbFPLvH6FLPgdmzbkDA1kgd8QKwDt59wwZ5RqYH2ya+mwhlW7bYWfM6PINfgaLgWxvAJi5wc6+d+2XwWmdRCa5OZYCOkQf'
    'yy914kbTv3okwyEpg/RJ0ZcU60bVkk+S7oOdneR+kovI021rp0eMm7/rRNW8BTltHxopbVxUgU/iLOkyxdptw6mKSj8H8GSvibDm'
    'u19NKZHz6tmJSrx4L7xBrb14yo8fGwXTdOXT0ZMNIykbyvvYX8IusNxeszzgwWNHTV/02CMNW3i4hjxbz15xIiznxevs52UOH7uS'
    'gACKLBhAGHYVC6SYCsuznCJSrNTwXKpP6A5c8vRApWdLT4QAjUcA3NmUseyrt94fPQEmdPJu0thIb6QveGGTDHTlrzNcjGcFMZU5'
    'oEeuqQjb7e5d1sUYYph1KzX7DxxUcPVrAMMXYZjpsFDG+SSd0/up4+eY3zXR7B1aeD8JvajnnUQ6t9MAfvjzUm5C1VkU86fjcbcz'
    'kPXaOhNxkBkHxy1wX6HAo5jWKAuFUcd/MrDUfOB7v6UjUSU+YW2lO0z4Ue2LlbDMSQOFidlfATC8v6YuA8JUDwLqFXFrbYEh3jXm'
    'bTlTKyf3vwHJSQ1fy4Zl36t3DQkHYB3DHYs7Aq6wcnFwuwCHAX+EpYvuXf8CypuIcLuawld8Vf+UDQSSYgl6wgFV2sN7uLoSDnO/'
    'dpwOOq+EbbkLvAR8yh+/h8vsgj+/zean8vndztEBWs+Tv0s+O9LaV14Zr1qRCf1Bq5ZqoinWanFY3C3f1lbdHZr/8oNi2ZaxDJgT'
    'tzS8+0Gh6olirgPDoWQo71VZFqYrhwoQ2c2Vt4mzx9iWY3YZRWD5njAWqaeiXgft7GDqk2rYPS4NCGHxS4r9Z/PsSkPxVZ3vSDf1'
    'qwrEf8cAZD077AtdpuDbzCOHUvMg6X7HGDMCGuDH+BKqOsJm9iJsimffvHr7+puv3zDHl8iFtIbg3PUT+1OtLP7PfDqD6tipDmOr'
    '+6PKoQzHNeL/mF35ICJAysUNqCXrQ0ZEtxHV8Fp63TlyxjGVxKhvrdK9AUx2XZ8l6jfssnj0tbzd1Eo8aaN4Rr5SxckqHaCAetT5'
    'wINAvbjMfe9qbg99wQDRYxXJTkCQTTaKeqOqBHYHt9NqUovdRZtiRztLtKG2j2qEqLgwEm8QvlgLEoBwtQOVP8yGfIAnXc4TkA7g'
    'nb7qKpjo7sBH/IrDedS8dNxVi6NdnJ7iqrWeKBxZTPOFY2qRrX6TBOFknog41JG/+skXljzqNxMvDGAd7eL7FRx/BRD2v4hitkhB'
    'WrAqCFWlH4PSc/S+iXRagzcdIJGjS33pb1LsJ3eJVhfyUYUI6/VmhNgBvzlu/fZtN6vcalT5DPu6BUYu7KtB5SjIopzm80lXONfU'
    'AtkdUd4/nB5OibuCp7Q2IpMC6DJcY2VTTh08TxQg5QBnVCfvQWo88sx+C+DMBla6Mn134jGpyNKYpwp+06qUmFJtlBHz7rCSrrra'
    'pKWa8+kwERdPxZ1JPEKFcODfFroazFUjoo6ZsLvtCZR1PhrAel8x8/F8OWVSeaWbanaqa+GvoHA0l5/4xrS4fyaIn5o7gU8uDgw6'
    'lwsvcFF6UqLn7fChdXg6JnpT8LfW8u54tSoiWitrQhXewdRTndBLiLgtvzSnMeY1Bn8uqxnP1vTITitdoMvBFGlseqZBUodRACGX'
    '1W7g9f5+UDGxX7CdyXigzioHqSwAQuh69MH4JQPNsnSwYKyo7/WK337iMsW6bPZyhGHG7BqK7DwrhQ6+jci4jjV+3jrEFXQN3fUL'
    'zBVLl3AzGMG8CDVYr67Oe3TH58INjboQlrYa8DAovTb9R0dVxjO8cJyGk1CjKFzNQnh6GvpAA92qZu+O8vniqse803JYwsljy06r'
    'd6PNDbOzfNrEfV5OgWLps1kszdpLc1gkRtOEcSfKnProzuPt8mSezxZ78mtYjK7wL2Dy9+78f5NAvZk='
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.11.03.1456'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = 'https://raw.githubusercontent.com/BannerZerk46/spider-diagram/main/dist/'        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
    'zip': ([('Zip archives', ['*.zip'])], '.zip'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
live, closed_at = 0, None   # tabs connected right now, and when the last one went
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.startswith('/api/alive?'):
            return self.alive()
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def alive(self):
        """Each open tab keeps this connection open. Closing the tab (or the browser) drops it, which is
        how the launcher knows when nothing is using it any more, whatever the browser."""
        global live, closed_at
        if parse_qs(urlsplit(self.path).query).get('token') != [TOKEN]:
            return self.send(403, {'error': 'forbidden'})
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        with lock:
            live += 1
        try:
            while True:
                self.wfile.write(b': still here\n\n')
                self.wfile.flush()
                time.sleep(1)
        except OSError:
            pass
        finally:
            with lock:
                live -= 1
                if not live:
                    closed_at = time.time()

    def do_POST(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def shown_version():
    """The version to show. The source folder counts as a release when it's exactly the last published
    version (checked out at the release commit, with nothing changed since); otherwise it's 'dev'."""
    if EMBEDDED_HTML is not None or VERSION != 'dev':
        return VERSION
    try:
        git = lambda *a: subprocess.run(['git', '-C', str(HERE), *a], capture_output=True, text=True, timeout=5).stdout.strip()
        released = json.loads((HERE / 'dist' / 'version.json').read_text())['version']
        if git('rev-parse', 'HEAD') == git('log', '-1', '--format=%H', '--', 'dist/version.json') and not git('status', '--porcelain'):
            return released
    except Exception:
        pass
    return 'dev'


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': shown_version(), 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION,
            'summary': str(info.get('summary', ''))}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        # Stops a few seconds after the last tab closes (a reload is back well within that). A tab from
        # an older version, without the connection, just checks in now and then: then it's IDLE_EXIT.
        global last_seen
        before = time.time()
        while True:
            time.sleep(1)
            now = time.time()
            if now - before > 20:   # the computer was asleep: give the tabs a chance to reconnect
                last_seen = now
            before = now
            if live:
                continue
            if (closed_at is not None and now - closed_at > 3 and last_seen < closed_at) or now - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. It stops by itself a few seconds '
          'after you close the browser tab.')
    if browser:
        def open_tab():
            # A tab left open from last time reconnects by itself within a second or two: then use that
            # one rather than opening another. (Opening a file always gets a tab to open it in.)
            if not args:
                for _ in range(30):
                    time.sleep(0.1)
                    if live:
                        return
            webbrowser.open(url)
        threading.Thread(target=open_tab, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
