#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrsvdly60iWIPieX4FSWlbcmxRJbMRyI+J2kxIpiru4i9n1ABIgCRIEQABcs8usnsr6sadmzOYP+hfmfeZP8kvmuDtWLhKlG5FV'
    'bVZ3kQCHw/348bP7cccv/6BaE+9ga9TcWxnf//AL+kUZijn79U4z71CBpqjwa6V5CjWZK46reb/ebbxpWroLik1lpf16t9W1nW05'
    '3h01sUxPM6HaTle9+a+qttUnWhrf3FO6qXu6YqTdiWJovzKoEU/3DO17x9ZVzaEedWXmKKtfsqT0D7/8QzpNdZUxpUOz3/DPjLud'
    '3VPeXKNc6JlSHG9nOUtKcXGZYtukFpVOw+uGbi4pRzN+vUOFdxQaLFyvlJmWhXZS+5VxR80dbfrrnap4yrfEk/s/cQ9wScGl6f76'
    'J5ade579LZvd7XaZHZexnFmWpWkaVYeHFEJBwdqjijRFUwIP/+D6T1wR2lG1qUuuACRNcZ4cRdUBTZSuohc83dBQG3sGv44uD9Hl'
    'no1K8SUTtut6lk1Z0ymamKAOKktPLMNyUNGfWI6fSOp0CtfZiy8xF19icwKnjaOXsknA/cJoXI428Sg8ehYDGl4ROoArAUM31/TZ'
    '3IvuHfwOg1BFTXXDQHcbx/gCICCsfI0gmFGeo5ju1HJWGGfoxlA87QvDUgybyX2lMFl9YTKCIIhf4w2alqmRUTrWUvNHOMU48cvS'
    'IZhshokVo1FPFBs9cKyNqZ48Wli6GX9GIJ3ozsTQqAkZGsbC5BBdYxRz0cCuVucyubA+jOrKG2TWyRvyDfUZkTTrgyTf1InwiXf4'
    'd+GyFW9OYQ6owyTK/VyGqTN8RqIYOiMbXEZMMxmuznCohM/wBgsXcFOHxywpSQdFMiqBt6hcJkfJ8U6yM/83YlSueEfEioslTnpu'
    'uR4WFe7E0W3v+x8oKpul8rZtHLBAgf8gZcYaUJ0G5OS4HmUruul9A7Gy0lZjzdFUEI0WCLl7SjNcjYimg+tpKwoYzNPNWQYa9ZwD'
    '9VcK5O1mBdyTCS6KhkbuQfpA7Qzp7lfKsICUO57lgDzKzDTvGZr78pMPs0qk5Ddc+aev0DpF/ff/Tn1ZKd5kXtfg8Zefvtgg1TTH'
    'JTwNAhfV/UapirP8+tPXDK6qudR/oX5CRT9R36ifDMSYP339mfpnaHGCKnwEYv919PYv2QCZv7jeAclxivrmWJZH/RXDmk6PZ9+o'
    'P075KadNf4ZbWzE1A5XgP6gE5DbcM1OQQxK6X208TYUSYSyyEv2z3wziQCjUOI1RFVRNmUw0NDd/JNILFc2treagtpkprU1QiWPt'
    'WFQwnipTKWjK9QDTQamIqqkWakiVVWGCX7NMArYmaT6QUOJDMJYnE/IWlPmwq7ymhs3DpMBkJoZIis5G6lmK652X+PX81/1W54QQ'
    'Z2PlC5vL3Qf/M/JXjDPN3KTduaJau2+gkBja3lMc+oFfoO/R3wyT+0paS9IJnkz04J+DufsLmvA0nm2kLJ3l3T8lp5NhGBDj8elk'
    'FGbC0tF0aryW0+T4dMqsLCncyXSyGsdwUmI6iQaLTyebYyVWi00nIzASMz6dToZncowUTSc7htZz8elkVFbh+eR0cnyOFqeJ6YQJ'
    'piPEh9MJcySwk7PpjEYaTOdJSTDtBGcXplO4Z6V7joW5ZG+fzNzlyUSzFczln4Gnx9Y+7epHkEzf4NpBIgWKCN//Za6rqmb+E2J9'
    '3bUN5fCNQtqT+gd9hQw8xfRIxYw+gTpYa36jGMGG94lqD+6mhrYn7/6M9XBwTbTnN2qycRyY3QcE6s8JLfyNYn8+0b+AFqRhfz7V'
    'vWE5UIWng8xMK0C6UJzmbH9E443nWWZ8PLqJXk8jAH+mcP20DvLVBZgAIA2gWWxcT58e0r4xGz2YIVByJ00DKjKA6m0MH3wCH/hu'
    'pTgzBDCNYUO/2KAdZHffw1SoSEeE9WIN0PSf/B5xHTzHY2WynOHRf6O2ivMFsSGQCp76oASoDIoQy0wNRDhkcgmNTC3Thy3LZHgq'
    'DaazoaWJ5rqnCsh0riuTDr4vQd176q6jzSyN6j3f3VNta2x5FpSVNWOrIdRTDW2jwZO8Axb+PVjnppt2NUf3mSbEPkE7+gmKDFmN'
    'OjLtAezNygyoFPkd4A789cIgsXCBQYWEC1OwgnEASl3L0FW/GpphX5VlQELEpz8GwM5B84l+XiEEPN+AIgpPoa2oKuYaoADMgrEO'
    'UkE/PmBgT1+F6nxUSIj54PpjnzPQFpojxKrALkwuSUQSpiFMQrjWzqcVkQbC2c1hHGDiKBMNsR0ZIGr8j6DGkcd2lR1WuhkwIX1C'
    'TFhof/05ARSbBIrHQAmkcB9yM41RdREokAIu6sLT9l44qcjH2Lg+o4VIZ4NpiA/kmrw6GW7GXEGNM0bA3aajYs0wdNvV3VM8JNtS'
    'kSWTkG8+jGlDm3rffCCB5rN/xtbgxnSVraamwYM2Z2B0ofdBQR1c8BldfQz28tzaaQAEmH3mDL+CO/pzNtbtN6z5oN8LDH5OT7iy'
    'T1C6aW+8DMhaMu+E73VzDrzpXZjN5KRdnNvElOASMnHnBE80+NfLM3uduS8JsY1HtHM0uxn0sn0yFSdsfp2rudhI0g5hHiEaclDE'
    'RMOLFV2VNRikbwZS8ZO5bqiRQPBf9qkpg/nACYFn/GKwW07n+CrfJfheQHyPyTn0kr9RG9vWnAnY6T9TBvgiAAXqFk9dhua11elg'
    '2aRmAymuGciv/2tMY4SUcxMhJsX1NdwRhZYkETFBaYj6ZFQSCAwbtD+ezItiJY4rNNG+XiHDIqz0zbS8L9+AXBTgQPXrRWUTZyP/'
    '3eCFADdhAZIvCLke0F6GjwBVtamyMbx4Ixlsj5x3h23SiFkSCPat01PmIAZqAsSM7egwrYeLXYQM6bfyR+yNXOowrHlOZud9hdIp'
    '3mPgA8XrozgcMnIi8crRZxMthpoVmb0ZJFXhHZ9GlY1nIXKexpgJVzMVh2jgQIIJ9Ek7uuvFHp90jHkfSwb2wmvfIzvyzDjEpgQI'
    'dMeL6JxOMkNCTWDa9u2HBKFmcjEBHBl9F8C4iO9zmo29mVmOQ+PS11MEk7fJmsDOyXiWZbikYWw+QaO25erEinM0Q/H0baB9cdOP'
    'lve2o3CqGtCwAzSyJ+IiEif7mDeE/iLB8o6RFQwOw+bu/BBIzHCYOTq4EuhnGhSGjYKLaWKYumhstqZ4X4R7ICx7/9WnFQmN4Iwi'
    'fGKI68kEaRANsPNjLAFBsnHckLuwBfp3w1MMFl8unb3Dhu9EssZQxpqB3J7J8ty4vq51c2dEf7tQj7p1V4ph3KwnyXyjiICvyC4R'
    'bKiGk5bfuckYwDpzFD/cEFFaUoLiLr+e1cGLDNA1zCP4qzM/oP6FvAO24Vc0R/ck2G0ryEdGBeftkCEiOiHE4us4MtIMUIAJlIOQ'
    'FAN4DEVxhGRUx7JtUi+0sJB7qiruXDuz4vwqabJ4AF62EOJ3ophbxY1xOhZfSQ82pJKxYU2WYK5Ym8kcWidzQWTkxkVWClGtcUve'
    'bz9jWqoWG1RIMbgSCcKczbIyBt4A6vgZ5ptgjTR8xR/wQwg+3cZsk3M+u2bfEuGetFmveO0E5lO9HoWTzrhYQBPOX4vjYeqfKivd'
    'OMRstQQ/2Y6WJhwVIMB3hBXzsIMXADNH6FlFDMGGZIWiU+4bqCU6hfFFne+V47vAbCYSjUxYGvwdaC+OmvccdCw/MMHdxPYJuDPw'
    'iqHYLpA0IMG84i2SIYaK/hRUoi9DkYzYRDoVZ+xV+C5oah2TTqxrH7arVd+2ok+JMOmrcXHDajlWQ1cQTDqKQS1u9PTKMi1MJfdU'
    'eHnR0sdA41AmtIM93am+x1axRa0011WQo+uCX0sBKpFHO7dWmo1EMBgQxLONkxF+GQkENMXYfybkhJVczKGJFv3S8OieSktYFYeG'
    'Nx0j3RydiEJMFGPyBeTQdkelKY7F711l97MJwEM9ZdIwlPv11LbjLxg20iXVh7vDo/Ix4Q+FyrDufTRydHudd8hkbLwz7vTRGnh3'
    'dJw3yV2ILZ4OLU9eoIMITiC/Q+TNI+RF0hMzxgeifISVmaT9zWC5hkLajBQg5kMRgo8xRyCoIsnqs2sUaD8RKjlinmMFGOq1TC6Y'
    'gP+6QitvaBUuJDkBxVCQZ0kmJxCRdFwoJuaE3PlvE3ETnwVe2M7jGGNDUovD6YefUJ9dlEZxEkeUyGMSbdh4aRRvvNGCe1fucpfD'
    'Esm+Ivl6zTw+95wu9hw2O1aQKxRg6ZJTwV6ONwW+0rkhkGhbj+PHt12Sls0bjnacufHMAi/n3J9Dpg3mKIi0sTjORicQyzKhnYXe'
    'AKlF2fGlAvgrntXYGJeqJEOVLH32mqFHfmJAl9xZrYyn27cY4PzZm5HqSVBNRNXvxRST/ExADEPNlxzKt+c+nGlT2Ua0eRZ5T8p3'
    'IT6sBgzrShgoF/kLpoVUDRAZkshhp2BJJ97gEgttlwR+osJUNzyN2PYHP/vl6wm+x5mNHgwowZXXUfIxSZpED03ur69AAFyPaBgf'
    'cBrjRt8fGUHheOWamLm6Vh3rN2iJV1RNok8o4KNgBWMq7oHRz99OVsS9zAwcpQqdgys+RWKeTx0vTOeKCa4kESzQ7hNqlsnwLqUp'
    'rgY6MQ0vgQcwRUl3voX7X5faYeooYKCFb/wV2VgROIEHG/M+A23xR+x7F99zsWKuw5uWG/z8errakIgCEmV4zUSL2a7Isk2uZ5z5'
    'P2/4Vlcdsk85frIsn3t+75kZgQk3RZh7C7dkUfEW+3j4xUdwOB1CiOyVbn7JIcl/H9p1fwKzDvmUX7++Z3j9HlbWpQXqGEKe0QLW'
    'aWQhbi7ctBQcKRgmYTZdWQvLnTly7y1xXFih8gdQI4HnuCmXo5Epd2JCn77zTVvZoBW+KVPPX/rz44s/NSxQVWPQNy6FU7l+Og+u'
    'ROOlw/HeZsBhSTVVPyIKpXMVyV8M7F20DaCz95ZEApj8xdeQFBLhZPpaODm+QBi2hJeEbw77XV0pvqrpcCc4nnJzpPJiWx9ZtY58'
    'Dz5cPUBgeLMTm4a5bKknrDDxAjrluCrGa0eYZsG40Sc4mH7mfMYEVcihWCHeJraQCfURrxJT4kVCDaQf4MhnpOvxASwLrzjcBKtk'
    'xKGsvhQp+lTGydupR6FnHE6URKJQ+P/FsIPPFb+FJx2uQfqq8Xbf2V/aivvG2PXwBX2AzURSGZtgbnJ3eYUy3sT3IIjmczb8PV0I'
    'RNk2eKV+d7r8TiJaGRy3ilnlzJuWDB1Y3CtFN+Mtnsw/kjDBaOiIbzT3jVWJgJnJ6GMyipXoE4SKQLk/355m9b6O913Eqyv20QDa'
    'OKqeYP7TuHAakya2X+hIEEQxJymuLQDKNInUx8N50Txr7keiFhcUFFGJcWfxhjwyMtYwpBLM8nn21W+iPMgwyWrrX2+LjSdz1KQP'
    'DvHNpLQEOOcBHD4IhZ+t65+9HGSUJF8OPaRv3+aASZx+/AW9lt4ZX0/VZ4Lvz15Y6a4L7X69pnTxXKjaxHJ832mDzC2EBH/R60q7'
    'njK7Dsm1JcCE+ULQgBIr3dvyBJNzKV1OGkAFH1GQ/Glsl2P/dNkSTQCcMY2059P+u8YMk8ldTkz8eILSJUA+Gzu4ED6MtxzSdcy3'
    'SCzAn4UlP7yQ7awUI+nTIvF4aZQz6yqxXQmwnrwepohcJ/hLLwLZnOYxx63nC+74jdjNqNrVJftY9OgsnJ07ESNRa2+lRJ69oPtO'
    '5BsuH3eDy5eIi5zbSRceX1mOC1MnzzNNz+EmI72/9GRqTTYxcZIA/6pkD9ecL2VVJtBsjI2TBMuEyfGn26gRBh1NQKA434A4UrcF'
    'khQfvnQqpyKVzgcrR6eDOiOm0xWc3BsL4UlI/uJb5Qh/KNr7691UMVwNbYW5zgXR64E/728nizn0iuc5X3DUEqTaRJtbhqqd5QSE'
    '3HLVK4nh7HR9QAqDlVGdOZv0CtlEyi9ekKNjUc7Yi9yJOykmXiSpwvyFFzfGffzWMi5BebJEcakdfTW7sCYTI81k+kmwlEY6wqnz'
    'l9nzpBs8yQnmwkkEWKPiq5NsvUQP8eyjWJPzBAY8NaZv3jMDhMDMOt3tAkZEQpDw9MWeL0ZYfCvvsk6KvY5xvN7AfWzOfFQm47Zx'
    'o5PMIXctenoD06B0lTd6jKyiS/N5dbhXEmL8TTEc3hSTu54RcQKi8qaJGmccJ2le3GAEJrkqIV2neE9lkj5iqeHvp6S83ztJTrFW'
    '2qXQjm7ixYh40gVH32yNXtnAhMeHevSXdT+/b+fE52P9/IKff5tdRSGIZzt1xOTGCexs4hXdi97ex1zYs66TIZMLKaRvh0wCV/q7'
    '39B1hkSddjTFwSmrl8KmLEvfElO/7qAmYozvrTPcvvvtQlg+Gsub9lNskec0JRZJNLLLcqXvv+gm5Tqz8f3JCh6b+1MijzNBOlOs'
    '4904/75Jor7guo1Cb4oXXA+VXl4SSICdIRcf21cZeWSn3n9sxe9jK0z+gtt1lr4O+nkcg05mHnwwFSXZiUk05WVfGc3HWHF1N5Hn'
    'H/L1Ten1UfWLvIkCn2dhQ+Y0FOqrkBtFdmJS49seoon1M0ewTrkQkKKDTXw36J4P7EyIxnIxg4PN5M5yIWP7NzEir4TartPxaf4a'
    'HeSv0efNkmtAloeFTSg+4+GF6J2w3uXGb1vFi4ebmRPdgbY43O5V4X6JGX66VQLjQYjkyMkOCBxnfns/BeowjfaH3yOIwYL/wubw'
    '0jQzdb4GnDVRHPUKJ9xIudfz+MNQzZkF/DushMfn+93tdGe5oZEaojJMLpkfygQ5ZRhZYcAA32Adlw42m/713ZWbS4sdr1/Sftrn'
    'hZAB6iXjb+j/uC6NtqQkzRM86xlvvlmhrUuKa8OkpnEQCxEdlQWu+Pm9zRe/xcaL800XJNjAf2z9IDEedLDUuQP7xt6JWAv+QQHn'
    'qxk+kX0kGsxdCUH5sMbzRxOB3DOz7jdZ9CC94nPFbl0y/w37dU3dtjUvSn8k6einuwSJ3fQhb/MM6pMQFJ87SZ8GZI+XukfO5Qhu'
    'SH6WoazQvP0cr5O2HB2L3SAwcDWl1acgRZ1dW6/Dg5aiFCPpLGx5afy+GfZ2ioF4Oe3w8p7UGLiOttUU4y14hVhK9ZVtD2cKMr5p'
    '4GIG/iWRGgCTFK073ZuDDxABGl86jiSkqaFl5Y8t+8fVuJ8l56Men630LVy0epddcpdTPk4yFENAE44llzjQhNwlj2xhMkLcwsCR'
    'TngfK38icZBNmqXScauHp0OH50MLC8Cfy9PNxtOpRgtCLE/UP0DpUiZ4zOBnkjbkeza3qyG5HS2kBYVpnBwZIUykb96oFDV8eWE1'
    'mhvDjM1Icictifp89JidzPWDdoIOM6hRpAJw25daS3jWZFchCvsD/Pcn91d38U0cywWbQHdiU/HWLr4wiQIzf5TEmKLI1twwHMVE'
    'GQZc7jRjIpHxwwjhHssf2cTCvr915YN2I31DBmWQRoMK3z4RhVC5q01ud/pOgk9hA6lEY7cvZ/t1ThzR20wNLvmSmYxG0x/3GS+e'
    'DfRO7OIsmpJsLpAEH9sT/RnAL+Qw/ZL1j9z7Jesf3oqsRXQSHxic5IzLO/ouOIUTXeL6v96FfBaw2R2lOLqSJtT0653nbLQ7dJLf'
    'L+5hNbYMdHLpnZ42rJl1F559eod3i/Pw7+77L9FZkHcMe4cOgsS/nV/vuLvsxcdcJoefgy45qcHSpIZ85Tk609LvQr7aiHBDHf5C'
    'P/4plXe/+RmVqPEsQec5ZpEavYLZCKAcxTLbtKSgaA92ptJMmpmn+XgBxWylxDA4AEJhKZY4XxQeQc4Q00KskM0IFG2IlJCPlUFT'
    '9FaOaqXhqpyL36fZ45uDAnFovTcoGbBG8ZRs5NK5BNxQNgf05RSEPvSfgIV2r5YZ5s1+He3dfleATOgYOk2fdszSlFyWTzqm/Y65'
    'NztG58I56Ojht/sWKJkS0N/020RhGxv3PfzBMNg5wyNqzW0Z/s329u9SmIThYqQ6/DLwSbtvNuhuzA+LA/6UydgtPg+WpeE3n5E5'
    'Cv0wwE1ikK8E7CdmBIAJ/YyVItjmLJos/FvIcLxfJx17Vc7QImkvKn1zRCvr3elDwHIKwhMhC9n/i6iTSctpefRmD3gZ5hZWL0cc'
    'SiPe2zKxAvgN087GC9JsXxwlkQvNbvmTl4BUAJtcWcK/RfQbEbz0JtA4mHIFaP8saJDz1AH/9BUPI0WaB107SLKfCGA5LoDZOPAr'
    'JH9yaS7DoP9xTIB4pWsCyKe3ZYCim2Nr9x6iWaAjUWHQul3QPvxAjADF4RynYcpphE4ojCDhKfpNEMjiwLsQQBl9Mo9SfLxpdp4W'
    'M3FBDJpKTmfkGigV0DRyPnpZRPzDlflTyuGSRDC6Ae60ZWs3SDKElEwOZkWO6Q5QfVBMl9m45mEyMrwOugcpIJ4SEgOSc6iZGOBY'
    'vfRzcSUFiODieEBeqAxaOSOhyzgvwAPARJmR4q8jQfPmuJfaYWyBQ/wOnbOYzvmQztmYhcUIMToPp1igpHmGZhCj+Rd8cCH5FxIS'
    'Y7iEDa+E4EoEfwV04ZvAI6frXamCts8poNRCasnx8M/g0rFSoDVaxD/QRIkATkZkTsUKwyReyPFp1E4aaC/RPAhf3BBqIh2084a5'
    'cMMgVoyUkXi0yMMikhFZ3O474NfBjBNRoqqIqU9kqORLl0CFKWG3HOgZac7huZDhjpHRVHDvzITrvTcTHCXgmeWCKYaLgBBgqjlC'
    'D+S3NGfe7zCNHTJNvYEEoH1MiqgDciGhCx492PJ1xLhIoUJxmZ8gi5JFMiTNucjaRKyefnsaVX2r3yD38NDB0gAOMPg0sgGJZgIF'
    'Dpdp+Pu2qWVoipNGyxbKu9jmKbHPzxkBJhD0Kj0XwICH/mCCaaRpmZwBlIBNCSAPuHyzY7h6F8uYc2UFDSqwWqWyGJrpDMIkyLbw'
    'HpXMxWT9t/WxBw7m5N3Jlil+npaxHUCXc2isYFXD9XtWO0kYfn+U/FaIGUJISfYRAQGKGeE9Q3myvEEzIkuZAU72bfTrNGd57vuW'
    'aC5hiIIjd8UzvV5BvlThulOnGfaH7WMi5yP/KEODcamAZPVJI5eRgHUmyFCAQvQf6wwRSY83ofEcxZ3fIpiAKYFyBPAmTpw/8UQ7'
    'C0ha9fkTHc2fKl0sY5itQBTHVnhPj2nv8zMjT3iQTLk0qNa06AJXo9+XvXsmcO9zV8IMufjz676O5+jL9310YIpyNF3YXOWQZEMq'
    '60QgCGgg7Cmr/IK+XOF/jUdzMBwgUamJobjur3cOmLTfccgxXorPofXL4YkfWUZwj8s4sODX87+Lg4Jvv97lDYM6WBuH8r8w4cI4'
    'UNworHsxJvTLxtX8j+j80Q9bYOgB5l+ypOMQDrw3D0Hhn2ocdv3gLx5PdQM1mUUV/VFlYVhXBkiFMfvLQy1Ba3WoEsCtuLZlb2wf'
    'clKo7aErVVODXO4Aooa2u6eQxUvBYwqd4Hz3HbVHJVFCIQ//BrwEgYCrqEFjQ0BPQ5j9PnAwHJ/hiRbk7vz1vOC9kxED1OEIOigH'
    'g1IotJrjz+jd90Z0cwrCSVNNbO37bTUxItCxxfhDTQhI6osFlOIoMwodq2GZnoUP+trpJopJ331Hr/ztX/4XmXN/LMvx3fcHzzFS'
    'TX+K34Ghg9AejgduoAvdjUaDii530Lm9g7x70oXlI40QIy5T3KtD6cz1qXe1vzj5/gAl51X1s4QMr4aHBXxBMwRejQuvaNR6o0+W'
    'aCkCfWILUXkRRaVh6p5NVwPS+Z0pXQnG9BlCf0CnayfGqFBjRzEnc8onRLLTUAsG/wlZhqNtwTCoAm79jAYAdzeSmj4GVTY7hRkD'
    'B+S2984AB776Yaj9Xs/AxlN9G+B1RY/pCNMCGB0Kb3YGWaDcU2j1m9I9l7J2pj8HmvvDgNeDDt6BruRoMVoP8ImeEoh+GBDUgd/s'
    'GRYfrQ0Ug+sBjPT7CgD/03ifFQId8ikqlwL/iIjpuQVoCgWp3/zvzfJqfBQJtr/M8TEsBWuNd9HjCxXwcO++1xSwY7wYvv3qZG3O'
    'f8F3OXwMtbW04jjoCw0YPz6kOCESnbI0UQzjQJGTWKBtCoTXPYX2gaF9IVvtPtwSRCGtCBzsaSF3A7rI7jfy/UHc79ja32GUuHno'
    '4e47hX4B+OrhlyyGMgG3nRgkChjffa9qmu2Gkh1tBgMAcXYTQDZBCWU7HcDRyfmbOBqAIV+BFYm/a5b5JWu/iczItLwsgv0RI06N'
    'VGgJvGEEjXOIZASlItEA4i2UEj5ecOWwmnvO6lc7BVv1UpdE/NwDPSlblHGA8mp8oYqXtV2/z0BM3dBjEbNUvL+eOT3tEQQqrkYB'
    'mVxq84QUT28/S+cdtHj7ITIv+PTizRWPmiPTJkAFNglQLOMe6qI9jtgk8NM9YZbQlsU5QqtxeJugiysb8EGVg/3zIe4vUfYboBYV'
    'UOYEup9cvEAOrskUqNclJpprTdHX+FwPGvCsneKoLiYwzVTdtyEsQSMAIfrltwujxx9fiejiHNQb2IO8FOD4F/+wA9znAIn2YGhl'
    'a4eCxVrIvjPNC74yiDKhcGKBS4xqYotiL/j7L5aNMEltFWMDzZBPHoBRj3//kiVPT2uhg0k3IOPr+Pe1Wgicu+8D+HmthjWdQlcW'
    'hg2dGR7Vy5KBfr+AtRApNRjACUpwUeQCWqYJj0B84pSEs8FONs5WU8Hoxr+vAQlOuYKIDvEGuboJzHMe+qAwbAerS/5onvQtUSRY'
    'uoU85i9CBVSHPolLRPMnzJRgQSu0VNrJxm+QQ1dUS1sLuOLCCEAW/O1f/42y0bd1A+jjCmfqWCvy7UzLzlA98AYpYETSFBKbQdMo'
    'QyqpghLAvW83kU/ooGjBdbPqsjHVw2kIl0IgGNwv2K8bff3EnOAEh6tmUIJgtGswoCc+DMS3/BQkOOXhMiQ/YoeCmrMcL2HA+d+A'
    '+YxZSlpDX29GcSG0pIzMJ4XIQF/1YNVq/f7uqHY+shW++c2s0mc8wC+txtPXT8kbIrU66KylhBxFB7+eotTRcBoXyL0zQcrcfWf+'
    'v//7mgBl70IH9Dt7vRp39527/pS/+87Hn96iIB58uRAfmm3OuugY17MxgAYChYY/oAKX18AwiCaoJdVAsg4+H/b7I/z8pKK4YMG8'
    'ZXygIUU7TMAKid3FskZvNkASPumMFPmeaNJutg8xVWsfKCBDZEeB72qTRe7vqDhkjwtcf87xQXtIVhX9UBm0i2JlYTu/j+XbJMKB'
    '+hJ8mPjrbaqtiI127JQo6AwVFR/nAXaYAS4b2QzmUn/7l/8rNFrBLJug/e8o+o486Az1bE6MDbJCo49KBNrxMy5VjNx9iVdaRajG'
    'MxrgeQDKNvwks0ui06CCUfE99WRZM3DpH62Jiy33mj52tOZ0qk+0ky6h0xMesCZ7sP1Q69lEO1/Qd5/3X69alipiQmeJ3bsvmZV6'
    'taa3B1JvGciSwLL9SwZKrta2xq4ODjiIrqZ/BU82BnrtqNvRa0lEBlz7o2bdVYZ6yyu1Dz5FJpnMn9EPMlrY1Fv8RmyDgOv8juKc'
    '91GpFSzM7Fv6pI2HfV2K+dXuKFwMqiLgClDetj7xNuDIWNN4JOXGsEbYegOzK0Yi9vFw6GqleIhbA17EdE5YF/EyIDlOvGBJIJI+'
    '48lrvWISw90GKj9P+VvFYSg4S+8er3XYePM4ctz84GfkQgM85MwjEC5/+Qu+/Kd/QkduAd2Cc0pcasS2CDN+48ATAZnf4wrIiQWU'
    '2XO8tIg/o+ImFuZABnm4GWJFU2C24XNmPcvyIUryDVDF6XdYfsjyfmt1Ea9wXzJruxvw7XTFQLtrFcdEHz1FbIGMtQ5ZVfKDkPfg'
    'AGo2NT7g359Zg0Qw3GSEE+PiIrgdwCOKP2jeToP5IpEMNDvIYKBWlvqZ2DxOJn3HKI8ukqu8FN5K/rG13q6uRlID3VAGjox+o4JY'
    '50mk7ic3ImZTUzzjQEjSRmQWOoM4WAfwzDS0FnD3vYvDlm/guaR7UbQO2CCIrsL8uxMH4Zf4O/RXtMjq3e6uXB52g2TUBiu5li89'
    'yOIh4dxv+GO7QHRIHd0HMgvtqUZnPsHvkHvx+P/oKSBuCJDBKtmHZ58k+obuOobrB4c6LeDko0sEjJ74EBc+Ay1Oa7qFi6bPfu7R'
    'JSjIMx+O58/A4Wc23QRJB30YEGWaXeRo8tA3QDBAaQAo/7f/8W9vNlrQZ7NrbZJn8SZ/RU2mLnqZcbWT8LBPVwpR/OvTKz1zxdYw'
    'zeKde74SPlsMxX38Ti51zKl2o6GcLvdQfvTyzL++wSu46gwlzBpivBGExM3sKS46CYmDmkWFp6YoTGawAnTNWrUBz2Dc6ijyf7kG'
    'Mpu+F6z9tedkjzryTsjFVStaQ2Y0/qyLZRqH6w7rmb33EYSVEN0k8IVKTtE1xaP+OLbwxkCYFfTr6jh18z23HW/mB58F/fot8HCT'
    'Fz1ta64WabIHZMjElcpPoZGK1p6+kMUUtH/vnlDXPcbaVxRghXZida95y28vHCVvPiJh8Abez0oYEqg5lywk+wLULE7a/h4lewXf'
    'AQ5x+vvLnUk0wI/KHSy2/K8D3zbmu++3xR7yV1azyNKT7mWoLvKXkH051R3XC2qtlCWqFeQ24LN1wqVUfxXgNnv+g2QCHt6ns45C'
    'N9BfgP7xdByy5Sg0n353GrKD0f9dNFcM73peVS8HgFDOEDCYo+FjYk9ET4DwL2iVfwK8BxNiEecZJyU4lo3c168/jvoW6emNMN8H'
    'VfRpSFtHJeGo/e6wJD1TOR14faVc17319xY+ayhdxJldVbpDqDBMn1R5M6Cd5CK9raEMkdjyDroNZgvpAnT/wxrgRxZ1aniXjQ8f'
    'urnEsXjR3TxQJP/LLwtzQNELSO5TcxAHUQLWxHLMzzlLWImEFIeAetPDRGvJnzaZkZF6T2GmJjEcYKzJ0tRc90zi++vwnxiNlhjN'
    '755HbIQI+V0Ws8I+uogxsLVmajeFWwGXszuKHHYNIsn3EU5MsPBIlTDH5XoEFje1DSzLcFKJnRnHsnG6e5FD23IuIz2+/6HMcW/o'
    'i0ugkEN5Qlgeye1vBkxwaAvqBgVyDr/eCRT/URgtFEuNYCS3vyeMdIZmKD7YVREH9HOE42e/XCOcPObnWygHnY8SCxf5kuDfi3g0'
    'M5bYjCAhy1LIpVB2yiFKsECniCB9P8Vr5khgfgsTofycN8sMxPfX32g4bHSYhN8U9gTJc54SjLSY5rfS8YODxkbttWGjIPdvAL4U'
    'zsZl8FmA/lPAj0EnJmEHNeKhzxzNg2y03wL2j6D+4yP8HA/iLc/XebAbKNJb2BAdohZFq9HNbymN8DE3iQOwmA9OM/l+S0xQ4Nt/'
    'JymBTZQ4tn4TFnkLXZ+X3G8kziETguysSKbOkXUJvHaKHUjdDbd3IMmmrMDctCwYct62jQOyTUlGO6n0flovajkZzSngJQ6yBYPM'
    'NO6B+kJEK/GmZpbmr7n52cyYzkOHPgjt3NZ/DfNIuLjv6Dhn3J2j/B3iJVn+0BEA95SWmWWof0TfYPh5ZzlLsEZB8pN7YojHdiOE'
    'BvlX5N5AW1dWhs+hesTJ65FdQHLZQzCoL6TkMzY92XAamsF+08YF2/7mXMUQbLJe/DutagY4ubQEECLo3GMKFnODJbV7yt99EXcn'
    'fkOMvukhBZnzybT5OGfhFXS0wB0sbgO0G5LrrgfLG9mvaFGetPTuAmY8fwBvpgt3OMLQJhPN9n6987cU3mcWrmXeK8DN+gR/qCqL'
    'CuIOy5Xm8Ar3o+7cUeRAVHKEnYVWNeGBbsM8BG1cb0RfzZJg4YhH9s9R/+RANbT/9pd/SKfR4h3+4inOo8cfjMRfDNoG20McQF+w'
    '1g6IxbkR6jc/mRtquTDCe9/XRKkSU7SKZKFPaniKYWSodBo6Cnw5/FnKMMoYFvtfXb0LF4tR4cYGDaEVlGjBilQLRxLFZUnVLl5U'
    'uBDtJo+frLM0lO89/ASdoXsxi4W8WIP/DhI+eKPZqboI4UVIeiajvgYxIa8Pu9zoaLqAM/6Q3H4c6zQx/D+cck2sYsEzzzHhPzvh'
    'hMsN+AgByklg7q1XGldShB8t8yeUNgtaaabon9njtr8oNAIKOyE0chZdjBNjUjP4CkGQmDBnvv/YVJ1kg4DlCE2StgnvBhCRLx7c'
    '+bzs+nexD2ihbW/4owgYayB9g90WiO3wYjxKjKGoL1SW+nqHt3pNrJWNZDHZ7UC5tmYYOMUpiBmdq423Y2sIULQT+rOxKX/jtRqk'
    'xiBXzzxJ7yF7rX/PgNLpDt23N+cGY35z9zj2YoMPrX2CgONnUoWkgztCzf/gxnM0gj5GbZS95JjnmI9SuPBGnSCt5UsQbocxo8Qv'
    'a4rVKhrp108PNTbK0+SuG/ecngwQnxVwJcPw4tkBP7iR9urRAx/jprrlnFpiH2erIBkNjOq9glj+ngq+3IKEA9Fgn9nEjM+d+Y15'
    'qQueRWxhDWXFpceHNM6S8/yBEEPE0xScuoVMEOxBIZeaBOfBssKLQqr1oxl1VIC893moSJB7IgjMAOlRHlhgRaGA+zSAFy2nawrO'
    'y7r7UaVSTPb4PuglQg7RCvDcsly0b1oHhRLSClqVwjqGOGM/cnLKKZej/G1gyaCvi/7bGeegb+DEl959SzNwji7sC0DKjdhzISHi'
    'Mjwcnw8ue/u3SZn/SCmWJ6A9GJZ7BbQgGBDPuqW+FN3J19/a1joxhX2ya6HDwu8SNtY0IMjAjr+UJxp9cwiAiLfbwd8USrZIvjMU'
    '+BXx9Vf8hhULyKKbcKNicn0UvC28kaWNfxsHMDxQZunV5B587s/3Bvy8tJx6CSdPjq4mIUefFYj8oRNrdYUt4j/EctDQ4jU5vwlm'
    'DqeH4HPooQVyu7McA7c3C0rQtx4M5eCXBS7ELygBC3heIRvG8Fd0g/m4YCsmbdHuAefl4eRZYGbUdNBczLvF4QwUrym+2/pK2Rua'
    'OcMnq6KTqxK94ZhPFLXBHSbwija6hEgNd7LcXeAUqNm1ZjMjnmMI/i6IhznawhwckkkCV5ON9xnhF560GXkBQWsnPExE2HKskpNX'
    '0AU6jCEM/MX8uKiqf9pJWNn1T0U5q40n6SyUZuGTHqj/9/+hSGvuxG8L6GiiGW74xN+TEest2Lt9BbBHzfArkjMjrlQjoZeg0+Ck'
    'iSxFzJu3xx7lLAcgkbzji5X/9q//82//+n/87V//z7/967/51XG2AuFP4NXz91qJBJNoHycxif2DU87eesRJAxZp/UuEPNLpN5gh'
    'E23kQMzyFaHXz17BOQgkAwHv4YJ7R0srnqdcGv/jlcwE5SxShyx2DETe8EFIobSGr1SswygNwvBTJFYXuowTjh85Ro0HwpUoOOSy'
    '4rZJmBdlvF+cjmDKp7oZOyzoy/hAISl6T6YS4R7lp389b+TZJFW+UX/5C5K4//RP/vaU2Nzc45cpnOCOjjPB6e7oSy3oC1sZ+PGP'
    'M+9nP+ks2Hhzjy1XYivjbwK772CCfA8G79jGfSfOa8J7V74gLCNjNZgaFCybRmfvYCpwJw4QP2rhaIH7iOlCmcW2TaJH0HkEzblG'
    'QbjUnJPgUiR8yeNndH8iUkvxSfiG5xB5SHgiQIOoLvFpUcA32CxEJubjoYUIkJoei/ydBWgUF0lgPxaohbYBkbeYtvztD0nhjyu3'
    'NTeeZBUwpKP5aVaXzIvoi7F3n4zKJfdARIYqLu+SvZ3XgnG4zhtGG37k88QPbtW4xWRL4CSxOSdmSZkFdDBClMqmOArZ2uVnvfzh'
    '4oZMG4UJ0RLUNSNqzt59LxNmvFqFu/ve2YznJ7Uudxh93fvu+wv6dTXZ3cG78mKnhPzhfPNlYq1yskJ+hhU7re133Jly3nNwMO7f'
    'Zz/Kef+xw3OjMyZIiQ9F75MHTfjN3goIOa60Owc5OZvHAj2o1PNLPw6HfwjqzbOBTxbsmf7h1Fi6RRsL8B5sfALgF3QkYZYi9hS6'
    'xmsjaLP253IJoZuPgdi8AGBjsxqjQhK2+RwY4bHc77uoZiIt00/9Jc5VaFlgAqr+cH7l+0RsxGHxU1iDPP8Pk+4NfWMEPJOPTASs'
    'S06lDLbq4V36b6Q6I/uM+tTayOVs51M/JCbju2jPYBRbxDsIr4l2fGIkCVBfEbGEAMNTOPGGxHfEN86xQBSCUnRA618/DAqcB1KT'
    'fN6LfEvtndbBNcEd+Cvdbxw1BTVxB35N0scblfHYwuoXRvqeXiG4KluOfgTnQDHam9hEPJJz5z+bsxscW38rkziYK0r+AfSJPULR'
    'Tp9PwJE42P62SBK2SQoW2vzrf1ESObAIvUF0PG5+khKS1BU3eK9snN2RRBWXWm3Q8Ssk2myAFshc8jISzlPc18BtWqZGPI7wGAmU'
    '2QLm2x8DX+MeHBEkOO+pP/8ZKf4///lr5u77lSEjieneJS0zDMqb9iwJmp7ADr5FBCvcYEnrOzM6HhKMbgreCHAciQ0U3UkyPyhx'
    '+sHbOREYkOfV7EICwlkWwy9ZbPaHXgBJSEBbh2YbKEc+0MahvvgxdjdLVt3SPiRp9DRIugA94keIKQ6vm30lZ17jw2f9TUjOhhyB'
    'HaadhkcIkCSFyAfxNt5FDyRYL/Bp3dC3+INzBt7BdzIj0IbvX0S+AZQ9gHMXy1JIZBuGx4Bd9hrQ29d9hpqm+Ae1hSsp4f4ZUDL+'
    'Vqto8P/F/0rnb+RUXKRKhAO8ov6LHoyggG+zeuyFORc8DN2mOZdgCfTIz2445RZ49IiTnsOkkI8KJXxkSGwzFllU9X9dGZSpbJM7'
    'nfDIUOIi+hkh5Y3pTVBFce85ysV1DXjYwENHP0+xHTGQO3F0O+DG89wjknuzcR5BNN59/+sfqDtfCn+j7pJcdXcPD31WgqccunX9'
    'M3fhHn3L9E5b2XPoGN0jjN6jMgMfgQjN+acb4kK8/All/sGNuAxFEPBpDuTlP1D/jLpAx0Y/q6hDHt36+Q1Bh7R/Qd3pqA59j6/x'
    'JmJonUEyq+OHdcCrI0/3UcVDdOkfVvWNMsFGJ0VLMMcxkCjaTorwpktU9kd2zKo86xeTZYOwLRIBgFr/bUPT3GTOfh8gq2GFA0PJ'
    '3A9SIwtVyJWN8oldP9MTZxHoaF8kmiKU3KEbHjn9JFjv1D2wHqb3FNiGsdVQxN6uht91oduokCyPZvxebb/TjeFfGHp4sifuRaFI'
    '+fg7SfICseK/Ov4e7Hok+5/IQat+JC5Kz0Rv4CCRb0uisljmILjarhv2EcUzwk4CSAGwEMIuDqahdcngxSnZQhoc2xG97U++j7FA'
    'GQMQJqgxNBlBC2w0LGWMDH8/ijlRHOeAFAUJvQXVw6Mg3wS0uLc1R1/hjz44mmYcviWHOoo6RYcq4qwdMoHEYAgql3QvqhmcIuKv'
    'JccmHedJncGRhcm9Q1/PxTzGJPmFSfILPiRfVd0wcBnjmDSb4WVWFFmO5XM5hhXonJZm+IiP0kwul6EZhuMYWuRoQT7hK/qUgzSa'
    'YzjmJg6yYgT64Medo1h1GHi+NAmtBInBCCNUnkZpgUMRHtHyPIoSA9UGryWJMngRJbwEp9pf7hyttfj0liT18wanuqm780xYI7bO'
    'EtXDytqNnZd7Pt0hqkCS+Is6URg8GaLHJ0cT/Q/qAZPd6boQ2rEdwuxOIkj8ZaFIkkQ0xiZpjE3SWGJVBG/09dc2YrTG0WJGEgSG'
    'oSVGFlmGi6iM4zI5mpY5iRFlmRNo7l0qk3IyPTmhMuYilcXFYDBoBG5MNsSobkXExM+J9GfKl/LW6USqiXbQu25wcreCjrrQLpHP'
    'I0mw8vsMGkRLRDGQfO8jgoisNlxqb4DkYNBMeBp71BbIuS/BMfko1wJM5Zh8AUo5fPgU9mC5BY1/hqVUMJwgJ8LbWWTDretHfsgR'
    '19hNe0eacUlK45KUhpO/8XYyVfMU3UgIs1xGpkVG4AWOl3OSIMVIjBHYDMgvmgc5x7Ig6MT3aGxKSxOaPqEx9iKN2cnD2RGifnKw'
    '4sRuIZY/ZlyDBtOVakTzNFbUGZErlIs2hoeV/vY//i0xm2ergJjDL2jdbExnDrDtETsFC6fH44PXkAsMBhKKEVJ8ROIBzaBDk0/O'
    'u4/AQa24JGSFQNaDg7/RIe1A/wfgnHFMnIQ49lftA6PQn3o+OfV8curLxEMDh0rH33uKcvx/MyLgbiICOgQ4lwQ4d06rWvQRG9dD'
    'B9SQ43r/zhAzIcRCEmIhCXH1PCciDqjEZwCgHCPnOF7M5YS4nQCPJFnkwVIQwJ7ICex7/CUIikRPTwDlLvIXjgD5wsLD34f3r52w'
    'EPTi3/7lf/mUBrdhOTYVTsuz4ZvZRHv4o/OnbavfE5/pyZ5//SY05Tw1eilmncA7SZ1/Wj2CJ95tMa7n3+ihglUOtkriev6eKrFI'
    'MnSQVP9g1w3fFEEK4AYILtk1t3VEQqhvNJ2ocGurdWsb39mkhx7OpR7Ipl30dakP9oKlYrjX6I0eTqTxjVOAeOC9Rj+DcryMmaXI'
    'euB7HRSgJllz/Ggv5IS5LFFm/llz7/X2a9Bb+oO94fPvs+iQf+u9PkZBH/4h9R/sCZ9am8Uf1qOUd+enk+ys88HOUN7xe100PypV'
    'yEHrwak72fBg5ndpLTmW4ke5RfeiczPf64u+ofFsXFxn4zoCxVu0mK3u67KYreVH3Ih1O7bgbpXGRyT5gQ/ih4cHh1roGyC7OYrc'
    'IMMDGXWXnCQxqVzFpHJlUeCqriyxOY+36M4sS40pWCHDgVJFLhLyxGWeO/XFaU7MyOD58DmGkWVekn7DKNft3pN/plhw1liEVcf/'
    '/EaoKzMU/hbOxVNaZ5YffkFI9g8DS0ZI4gboySdCoj7xJzpi/gxewwg+73HJXQpaP//MT9hosOGKfBedhIxwmBPHvPzPs2D1SDLp'
    'fTI6gTvmGILXdSXmRbkbM4tSvwOSdHFuueZeyip/x3GSktQnJakPnx0ZN+dEMNhynMBzjAgmJyvyp9TGiFyGf4PaxNtiPyF8chI+'
    'OQkfOocyYWyy6IPBYo6h6ZxESxyXAE2WMwJLSyIviEIuJ50GDKSPhKXIAZpQCx+IGUXVTsLQzEkcumDt4/CKcoZnaIGXeInJiaIs'
    'xuFlRSmTk3hOYlhOlAXxU+AyJ+Ci0zkjaE+DgCdRQP+EzhjEEpuhJZpleIanRZqT5QTAkpARRC7HiZwgiWLucxCzJxAH54VGUJ+E'
    'lZiTuFJ4ZGgMbpYVM4LEsyLH8xInMmySaGUJKIMTWBlAZ0T+U3BzJ3BjcCKgTyIUzGmIAsjIpf4RGzwxuBmZzsDU58CLYmle5MW4'
    '+yTxcgbGwwqCzIIfyIrv8trFCFgE44krzZz40uSUqQg4npEzjMhIiBDAF80liIFmJXBCRZZnchwn8fwptzHcTdD5/INPdUELURiE'
    'COITX5o5cabxianxcCIKGjI5CaDmZfgv5WIgi8BvEoscZjkngP8sfQ5iJgkxObs1gvjEl2aEUwGBjlElZjaQw5gcxxxT93SG54FQ'
    'cyzHShywXGwAIEcywH4S+NI0zcvcJwfgsxNOPIxW76gguTBehLNn4Y1oeCfWDCOeCmySzxQXgkyOycCAYFZkkN08m4vzJkxVBiQ5'
    'yBOByQmMLL9H429F4PTVLAAPYHfQWO5QJsg3kn+wsLXZz2PF1QT+Pisvsnw+/9JZjirtWb6Qf8nDHfzOP2b5Wfm102s8DplCp0uP'
    'Kt1iD54VoUL5OY//vOzy+YI3NtuH3lJ9eC7NRwM9X4b24P0iqZIvzF+5xi5/yx/oW/Ze8W/ov1t7yf8Gf4zlaNhYoCsJ/XhoHwYl'
    'Q0GAlTB4bTO4r5J7PbhvkXtOLRdodNUj94d+qfKIrka4vbl5cq+f3C8m5Qp+HwPxuPfG5f4igg/jqT4a5Po9jKUZ+jHJl+v53qxQ'
    'zhcrr4O+NQtqjwVA/eOCQS0tCb4DPOsrwJfH91BPChrDc/DooYPeb83hh+fKifYS+B4W5pNVMZoMeHO0guetqgnXjQEUFWVUbI8j'
    '+Atvj+chT8ZTnOTHu8I2/wS/8wUDlXdeCpv8Uz1fm8GgH5/z9Xx+n38cZ9ldAfDXeywgYtv1ivC7VHjpPRV2u+fCblIu7KTaw25Z'
    'L75IneK82Cq2i93SfDcs7l+UUrvYfnoovj7NabW8l6bF/USvPDxrlcJOK+9F0vZLD9qbQHv880Oe10qFYq8857Uf+y9mYbjth/zj'
    'Lj+YPeY7gP05gL4vFrLSS/5ph3kL+oayxJ96sfDyWs7Pytl9Pp8qIt7ZvUDdF4Cv95wPOKddmudn9WJx1nt67pbak17pYaYAYbbr'
    'ep2tHJbjYq/yWOnMZpPBM90oLjflfY9r7VDfQESIH0uEd+N/ig/QV6kwmzyjeo05PJ8VAcYXwHG9GPZdgPdnGM4O9F3oDUr72ehp'
    'XthD3065zXdaBanwMqjTla67LWfZGUzlrojG/1h8yWfzTZt5stuzvVA9Hu2i3F73XutPxS4u3L22Wz3FeHoszP9jP3npvRbrz/a6'
    '0Vm5j4OHudGpCIue7eSZWf3Z9IvzO12zmKqya7w+Pvzv/3wGjx8r7bb1+NIDjHQOXpGdNQrdnjKf/4e4yirV6lpY2rY9sPvisl3u'
    'HVKtnbMZTzuM0lHWhrjuNTe8uHDHBUthXnQmtfJ6Yr/ZYlfsYd94WHCT/ZYb5Xp7WnWP9HTQ1ZS21cj2RtzWsBZ2ihtMGF0qmMNl'
    'Z71ZrQ4mGM7TQ/1g2uog5a2e9f14ypudvLQ6bJWWYwg2K/DWYq2vKtndw7HJuGJVUcfzfu/Y544t8TmnyfRx2bNk59ljdutaVzr2'
    'c2Y5N3jeplqjtd1NjZpM69iUWgfob2MoitBb28Ntuyce6zTHrgT71Vmk1nrNaHV33EiqLOZCaVFj2zvRaAn1Y7tllp293D16MG1q'
    '6Th8qLS7/eWr2no1x/2xVHmhm7ZYszab15XLS0NJceb0vtWsCPYi1a7stKnNZPOblLhtc126ywUIX/GjmbWiC1ZVWfTqz/GrvL1+'
    'eCr2CJe/AJX8/fkVJnSurIES2kx/0H4UX9lW15vXts92b60aXmM7Fh7zzLBXVVs7cdPvHyx9JKbWrSetsOS1RrM/tdx91qs25P2g'
    '3J6/eg2v2FU11puWutV8yxjWDuJmNHW2nK32e5tRa1QrrWDydW48b5dBSO4PAtKiRspyC/Xpc0ce2wqnyg/avLt+LOb0nZFdOF6t'
    'ua645mrONPes1xf6a2NjZwvDeo9ps106VZSmUp6mUxu+1BzPmZetbvN7bi8fFyoe6bT72Kr0LkunwrzUwJV6deffQT52VbVG296y'
    'rxnrXrbH1J4YYbLumM8buiYwtayRZSe2t+/2h1azXWo12q15qddtWWNzJLyCgmDq8pZecrN8a7WTB77mWber635by/Vey/tl3x7v'
    'RUNJOZ21cTi2+5NNj+5NcqvnxbY6Nno9+gjTOuM5DFKZoY/7yiWAS0/5VyLSXhuFF1+koXuopeTp0tOsARUaqALcFuZ/1+cPbEkd'
    'lg9KbWu1Ne7QMqB8MAE6O4wb/VXu0V7rr+bGnA1r/cOaGZbUuvRqmD16bfSr/WfH2iqzRn/ffDWqlQXXH7X6Q/6Jaa1aQ6+4FRoG'
    '8yqzzXLKlYt7JjtdL2WFFltejlnVvHLLXqyX+Ty9R8ZenuGanFxXa41qduCI2fxDnats6VfZVgRGWspVszUqHTZZbb3py0KKlx/Y'
    'AqtuRptRd8W9ZrvegRcVK1fb5I65cl3sKHZ3wVb2QiXVdOiFtGoi6dHIK4+cYZrVipdXHhYvTzNfrMAD0ETjFyiD3+gB1lMWmLvj'
    '4CaQQERVoQZ8BfbvW6Ow4lfTifdslPYlx5KFpwaqxKRsZagr5kg+Gr12vyvsue5xdpgMa9tXQ8uO1r2V4I201kR09OftvM+W6H6p'
    'Df+bGjNTdpo2Grrb/VowX7fHbrlfb/dTcoWWHYUVuw+bAb/SDv0Uvco6G1YoapvNyjz2dtJiOVYfGkpbEbblzQuDIH+s01lWEaYL'
    'Zj9cMsfJsC25WnWSsl8P6tpd5Z5ExdZNxkxp+S1XM4Stxq/XWwFoFA9WfnRZR9X1mrpZPdsLozh5nuVWm/U6128gqRhi6IE/+Jp6'
    'UHACckdDwUwAV4WlZe1e0T80qQV9UZjt/uP/zlu7xwc819X6U/Wp/2xiuty9GiABX5/cEpGF/5tfFdqzF8J2a0TaT8NiBwmuARZc'
    'FZjJPhFcK5jfPhZc6HlxclzWHx+nsn0QG3ZP7is0m61tGy1DHkpdRaxVh+58uqHr5vZ1P2ani0FLyleGRa1VPjw0JOipWT9onjvv'
    'Z1XpiWlnxaqxzrYXw1y5P61z2mElj11bPrDmfsKoR6X7YKUGI3OzEK2xLTzB+616zWxI22G2dGi+mLzCZl/24mpqDlseSC8nW1LX'
    'Q35V6Xv90SI3nqQmj2qrj4g0V930l+tFbTk0sk6vl2t2Ow6dKzElqef0vOyuwNBZKV8SsjPoiUY9VYVmN1ddpB6XdbtVlfvSseLK'
    'L9JRyc6Pop5dtKtb5mVDj/uDSkrRX6XtrkHLNcBSOc823WbfGgsds7yxZWG+pXusVmE8pb88SE9rc7/2+s/bzTC3UhV2vhubD4q9'
    '2C7E+thmkNRhmhWmtWNfDrWlM1oP6aHS73Iyt23sR5uBwzwMa42DnnvZOr3+81rjWcOsuhyvbjYV0X7ACgVNXyl3On/vze8PPoey'
    'p+IUDcAJZHkX3xTWzVdhzjuLquFxDkcbuWaKUVJezzSFIuib7ai0OXa3w6pRVorjilUftnKPhV214W4r3mCzp+2BIxxSHVUwHyd7'
    'Znp4el3Tr6ZoKinBYRxx2hYfzeoa/hjwf7C2Nabf15iuWd8qCtduiq/2dNx6aNVMOa86h+GAWRsli8+W1s4wpYlsBZrO5qyJeCj3'
    'WrWcY08OgqM+gERPWeZG7Mv2ejfJLQXPyJWPzGGzbhbz0J0Df618Y3Iaj+rtJaAPRmRrzIHp83S/qqf41cPrerUa5pszPrsWjclo'
    'PT7Qo/6DpntP62yjpefo7ZM6nAyNmjPl9tXsVvZaOVsatJqz8fiJOdb3qSd522a6e1l7Bdu0r27EcSenOPamV+P6vbVQE7ui8nio'
    'gY1/nDzwxrF4GBv2tKPX5P600cx116mKwLWF8bTCcyPwXQaMpEyXNr2peOUFp5U4fiTx0k5dIvpfFA5St+na2r4ml4TF3h5uJFou'
    'e/XF4HFKMzTT3vYO/EMFNPnDBumDAaERFcSMTxlDohkwvRDN8NEa5abaU3tss8Xt6+WBbFRYmFhnPOSdcval0VoKsv4qH7nJsX4s'
    '9x7XbGN8HDYm6r70mOuL2WK/bHs91VNSR1pTzKr8Io+H4zXzmi32HMUSjS1jy6NppdXOOWyqvYep3YiT9WZYFdaCYGhr8Mr6faM7'
    'zKVAUXv0a/ZJ21rZSv2gFo7b/vZ5MjP6Zjmr1lVtvy6ltr0lM61slYmwVZx1fmIsRw2usuZEr7uc5fPuO3FMb54bdOfccvvqpTbH'
    'SZdZl17Fx7m2KbWr42GVbWzbckPpekAYh+wzv3wa6aNUW++I/Y7YXBwKYms22lRMtrd91drjbU8zlL7Yk2iRlu1lXavybHv56jG1'
    'TUPbDBRaVnS7N+TKXanL7E1e6LGSwLQNuiIcpn1nLJea9r5h1/rTh+yT2BoeF2Ajlip6l27M9vamLjj8sKGYsp0dOXrKnnaHWETl'
    'XryGWu33qmCuWkLVVPRVys011tlHj2m3Jv3ybveKQiwS1rkriwGTyn3y3Uz86AU9WTzlWkazyR8MEG1VjzWGG3vorYdshTXL0pEB'
    'P8/rO7qrVotiL7XaWEJK6WUb2efdxOlJ49JC7jgLpn18Nmfq/NBU55L6mlodJ7p+bAtlkZkXRaaZFxbC5jARx+Vdwx0/Dd2BnXUY'
    'WyrOH03o9VDnnteH+loeqhtGlfudbLa+LHaX3gsjyMt9o7TllelgmmNL9UM+r5DQW0oRhJraZFS1UdWq611Bzu9q2fpEHXUFtt/u'
    'bedteSw/FrZqh/dq2Re25u2n20bH3Fe4UWH7MnE0YXVYb11XY9qpSn+das+5zThXzWXXfbu7A/f3QT28qG53wzl9R+yI7Xaqaheb'
    'j5uR1p+k6MOYGZqD9fJhqs7E9RaQaInSgd4avaxQrKY0/mButkxf6z9ki/yuKC7zwiHHVGZ29lHZMlPa0qfrDtihbsrRhyVJWL7k'
    'ZrhW01mr0/5u2T1uplJxvbHdBTNRaHO1XivFoujmOV3u5EzLHRRlPVtP9YXlkckeXLUl9FMj+6XB5seGZqVesoY7Ffup1+y2YmYP'
    'r6B3PVCFqzz3Wtgs4SU6e5DUKXpJrjC1FUzbwsk9b4+Np8JmB7JH7o7KzitjTyv9lxQtmI7cLHe2xiTLN1XUCM2Ue7I35aWO16p6'
    '2VnfFgzwzXWXo6Vle6pPrIfGIa8u2kxh7w2nw4ktCa3l0JP2e2+qAgOkKqWu3J3vUK3s+Fjv8OyqP1pPd87LtrPuP8tVa61Vy2Yl'
    'RTMgeOVGh3YelppYEOqjZsnMbUp9Tx+pwp4H91+viY/HFXN4UsfZ/HN9Iy1rg7U16jvmpmOJItNQpprV5R9W1XVFra9fNO91Oiw3'
    'BsV2bSu2lpY5yuoDdigJg4a3mLLzAduum4vqckg7481WNLq8uWg46/FzVxw+ef2KzPTt1Gg10OwJuHXD8oaezvvV7XL8wK03qpLr'
    'H1vTfcpuyhWxrwgiP1ibguzUPIevjdtTurftMjadWqubtmpLYqPNM6PcdjHepqzOfPrglV6OtWb7dTt95Rz1KDU61VFv3B4Zreaz'
    'tD10tx3N7auKlDdVbQtEZndLWyk/5Ir0xnBKB1G3hb4NNDzVtHHeXrP6sZKrtvJj2hznprLVyPX79e7CUavafOwpjJZ7yvbo4bPa'
    'k3Kr9YYdD0f2kBm3mGKXtdmURFv1qrxeDTW+z1WkZpl+nphiH/6AdOg4MDfguGyVtcnnX/2gfMGpm2az6WZzB64v1ZSWmOKZTZdp'
    '9Fl78Xqo8P1hdTszj021AF5Qflx+zjnL8XG7rI27O892xJS0GxuH3GSo5Ib9wXbRc8zdg/2czxdnH1q1Ojjl55G3AKN5Q9v8uGnm'
    'qiNmsa4tq83DVqiKqaphyMcns/Cgv6iNV2HlrQ9DabBeKVVTBnmdbUhjbSzzqcVw57R7cnYy6T2slOeCUBlvBqLRZMBJ9FpPxrDl'
    'SoLlOB4z7vWZnsNbzpO6kI6Hhrk5KGtaqoIVP/SqI6vA8s3RfmOv6XbxUFdWjsiUulquO+K55kTVxNLGUYa7zTO3FfWVMpo9HQsS'
    '9LTJdb2xYzvdvd3fvTwe3fzTj67rPQoeVxXVAYxhPZ8+GYOCNJuVs+zLr7+SBVHqbodWwQXav5ujtVEeZduQ9Vu8RNohi7p3nbsr'
    '+xZIZnOQCxhuQgxSmfw13tPEuXv0kXN0agX+XGgica8f1v2KtyVARXSqhY13iVw8Yy2DDqpYUvhjeChB0P9mXZhcTXYXom4vpdwx'
    'J1lPzEnaEzkLYE4+GaDhj2dTrreZTuPL1hwvZnIiw0lMjpXlHBfPfpDFXAbluss8zdEcVHhv1foDee1z9nsxttUvSDubKOiU9HmU'
    'UxzbSErGg3Z8jvFZBnhAsbMM7skkBnMyjhpBeW3kUv+eyP3Vwweb7+HxPEGC2fdYSp773Y2fuuNXcb+/vfM0PBzHDRP04xWg0NRc'
    'tJkFAx7t5UtkuV0vi+8iTBx0417IuCvhBD7Ndq/vsLtlrwHmmsvbDcrW7gc3G+BjVi7kxwbHr+B8yPgZK7el3yZZOd5w8JnKgLcT'
    'x9Hc1jg6v+JCy/iTjH5iI7RHDv35TEIviDLKdSa//rf/zPH4zxyP/8zx+HvkeBSLeS1/luNRxjwF3e1Oczwmz4WXV5xD8TDNFvNF'
    'GmH5Ee5h/G794eWlUCB8EORZlIvt53n9ZdZ96Rd7pf1M769wzkXP6qoP/VKfWQqDvSuXO/S+t6gble7rSunwx8bBWncWL1zzwWs9'
    'onySMeblWZ3wfOxPId8r5HevD4UswPNotQFuuC8+PgCsuH4+gqf40uu8jIpPgPt5vV/a0+1+9xWw706Kg+fF8/HFqM2lx+F+YlX1'
    'l2wW+GoH+M8/FF/q7fyjlN885R932iz/7/dn+jgdb8fj8rgyNtT1obq0n5ei0BZS+2JXW8udynptcqWuK0rD46u9X7QeS9U1e+C2'
    'aqHjCqV+42im+gdbKL4shv3dulgXDyJdboOdM5lwZrHPeNm2xiyN4cLID7SH0WCw3jGGsi/RbC632j1vsrr+vDBoaWMu61PuJSs/'
    'TzvD1PNsVmqKqY2c3bXl6vzQplfVnaBNU/TWorvbqJ5Kt7KdMg1e6vNzYWEzU5nbAfQHbanZWbkjHdSUUM7mqy+pJfhTxSbc2I9C'
    'J7sHQlWbTnaTeiizXXrBtLLr4Qq3vHskDdbnSrNXGOWEuVOzX5WNrg8Xlcf6kj3mevR4I5lWVQJvJLXxAMiciWDs7NZaC2Bcs8OZ'
    '2+A9Q/aW6sErjcp9erlaN5YjZ9/VdWsjl6QOwqu0kIb9p6fJqMe0KnVRfuIe2m6pW3a4dXWTc7LFdXWtjXvebFhyJtXtY1NKKYJs'
    '0V51o42Pq5pAZ62sMgMZ1/ttqKhaHz49KatNqdtlmtvWvrMZVZw9u+z3hqyRO2yy1fxBcKodof9Uq7XyLlPq1Txm2RtrqfmU3tJd'
    'bi31h9ZwONT7rEXb3Zldm6jOoco8GONhXQC/mJVepb65llMdcHd6I7kXdt7SuHa3yz2sZjbdH9mVgbtoFxlwLNfPplc7GmqqKxvc'
    'oN/gbKnPrYzpY7t3sCvt9qFBD7Qu58glTqxp1Rrt2Pam3dkXwG7qGA+PSzknOTlFmHc241XpaSWJT5Mtuy33RTefL+mT3m/DTOvn'
    'dVW317oE7TW626dBqiB6dZcZzw/LQbvP9OnqZt4/CILgHBV7PS2wVn2zLXDZfM1rp+qc+2TT1a7AlSYP08f+WHhgXxm7MpXyldTI'
    'MpXZQZDK05TYmy6epaO8K8+7D6nHdYcfVBlV79eN3eghlx0VHXlQKz+vbUs+2HvFtCqp51Wux22mvTI4z7JRb4vrRXfRXjLQEU+X'
    'eyLrrBtPRYFerVL7w3h4bCiHB9R86elxveGHLKMaTF3dTR8Y1HzjqVJ+Wles/aGyn2ztyqPYexoOZ2KWUxbSaKZ1jqLJTKX1YTp6'
    'Wbo6Y9G53qu3H+YVea2KHebJeygpnc701W7UcitdXT/WnJ2a3T2gkdXnI2lTf2RXqiuX5odFp70Va7a3Hrc1r+H16eF+xcyW1Xl3'
    'OLCcWY+W+1vbGRmDJZM9TFcg1zsPv62EfKhs+g0YUEFa77OjbtFddifrMddaP+b6i9Rh9cxwqe7zRuuCfFkKLb2ZHD7UNkyonc31'
    'l6nDvDIq2alucWJtJXMAmhEYd/chcFpPm7UwmNmV6sZbvyqKuegq01pVfvIUc7Beq+u19mTYtrKylp3mU0U/dFrDGbMGOZ6arUsr'
    'Y7HieXrrui6Aprpzbd1Ta47FONpDs980Doh5GZovze2UedhWvArfEQfd8dPBUDvKcV7zRq9Pm+PikLVHw3ZFKx/XjFoaPK2WE9Om'
    '6eGxfJQ3x3xrJzhyT+sPCnSVfmBFbj9cDnV6wIlA62WutNa40azMq/3UulUeu7tHqbnO9stGfzaS84OtlmqBtSo/sFl09Ubt1kvJ'
    '4baLLKDlxduiq4JieuxrIVXuT9eL42u9MZrxrX2pyZqeKtkc8ygfX0e9QUU0hGVbqKy3S6Y6LpT6pXZv2O7xVa0imaLqiO5qpY2E'
    'SltJCexquC88ZvMPqqsxata2pSa3stTWsLecNnfdQ5OZ1sqOtW4O7f56zR2srV6ZNYcbR1G9vtqcKgvT0efVeW9SGYOl96KcGvbt'
    'xsHeTlJWyxi0xOqrsdTHRlfLyS/Tqjtle/unDRhXq/ZEMqeS2ZbAhJ9OUk7WGHTFahHVXrqpnDzMVl2T7VVqz17r8LowStmlwIF9'
    '3OmsTmmoYGkKW604w/yBZoX+q7BWN0ztmdFSi9GuXRSM4XQrFCW7wDxl7UFpW932xZI05Iqro1dFArhaVo6vzl7fPsrr1eDB3fS6'
    'o5X0yj473PO2tznoQi3XfVLd4WN5t5rm5vsHBS37bWBITWVb01NGZWM+VIfb6f6wXapGN1dj1wtZ6I7lQ2reMMel3V6qmKnXSZOt'
    'zRd8F+ih3nzuFpwUy1oyrT1KR05ejVtbAyirO2L3k/r0YZRdlR89nX9NFY9ZVD0f1t5frFy2u3x25zWeF0BGbVC4peVc0zWzO3nR'
    'Hqu5sTAzmf1iN129Tiv6cc8eeOdQq9K0VOo+sIq5WoDwSh3kxbJfkoSy9VKbbYtefy7wnsaIJj3RraXUKpW6Tnfdf9CeR0/ddt3Q'
    'Jwue89rHYWXXL/FVlbEGm548sJudwbHaUrbr7evEW6+Mo1vVu9rr1h2x+YJmDMLZU2wzn1JXg+ZzuZdiPKe9aaumzKhFNbvvd8yK'
    'pgt0r3TwDNAg9oYp9Hbb+bLrKLlSe+pUX3lmx03qVX6+rrUnz9yz0FBBEDeKxmI4ywGe5c2w35wJi6U8WLhHW0zRQrldddVVvzVl'
    'V6V8gbanoa3xJI8eOt368dVdv0jDpqHkmt620WJqY6MulufHJ6lRKehPh8FGqoNnOKiu7adWmzUL/fZAlFuvo7VxbB2f3eW20W/Q'
    '636/lc0XBQFc6qy0ZLfKJLvWQA4pa7Oz3Nivu97KGvScje31crX14IF9qeYGjpEfpkpP3qZvePLQ3qvFHN1xBNVuvY7Bz8+6je56'
    'MV4oY6O93naOIwNERHv62vO6bXFTFiapQu9Ib3LzlNmadfOPHae/cmZVvtFdSS8vL80h53X29MA0Jyvz/2fvzZYUx5ZFwff6ClXu'
    'OhVQRABiJrIy02KCICCAYIbceXcJSYBAaGbMnWbnrV/6vbvNup/b+jvun5wvaXdfSwNEZFad6e3mtl0hpDUvXz4vd69pe+Wj5+2m'
    'Xr+ys+peq+U+HEepm0r9RdLvnF7qseLsOw9Gx+7Dme0Pl4XdjbQc3kiV9X69XfQa2nqcKR4Pg+Zen3i7YWKdVp7zzUItn7HN5VAy'
    'bckRG6ZWkCrTUlcGfKer5eO0/TJcH3eFgjeo6YbeaVmj1mgySoj3kzu9PhouD/mnyvGl/zzSb/Mb27bXjX5v/zS1R0oqt8i+DKfZ'
    'hVJ+7G/zHbfQrO09c7sGyV25nWzVSjatdFP6/WbuZrd3xULLmh0WaeklA8j8jG0Y6EWz0SzuNomlPSqZ+2rdzbr75/4w0cpmsw/t'
    'idJ8rK+OQ2XRLzYfTQ2m4Y610mOj0OuN3DwgWm29cd1mfSsphtovlNIZc9seZHT3jGUw8oXc4KgeH3bbab4xG7svZa2fXtnH1iRT'
    '6W1F1a5pjl3WnB1wN8/b6ARfzKFcUJqd6ajfHEA/eXVQLz2krXYb+NfSrv98MgUlXVmXc6NZR2wk+tPNsltPTTuz58p9q3B3VEuN'
    'rVnQU/XWUDbbTdFZDeRhLd+ypkq3oB6eleqq6VVKwIPsnIPpTjMJ5WEr3k6nYs/OVxTz6KqDh0K/c1TL5cag8Zjv5Z1c//hoZT23'
    'VNLb8nhYS6hzu99xnYfCqJnOtqfORuztJXNtVzdKva+mgbtdJ25uRMO8KdVt1ywMmoBJ5/Oes1p1tuL6wZGn47HVH0kbt2+X+43B'
    'rNyVHqStOiwDP7IWK497qbOxhqLkJEa3213HfWneOXK60anaVrffHPUb4iYzfCpLTvH+VtxIIKh0+lZD6e6kUkV1DNsQK81RfiCN'
    'OqnEelR8yKYe942qbjbL/VRnuZdGJeAkKnmjvZottZyc22wOTtUrdaf3yv22uWxXvP3MfRHdw+zQT3drW7fX34t7r1WzapOGJUv1'
    'rZyVnbyV2YjpgihmC4812BhlYZdde+D1dK1xyC7twipRbKvKvVXVD+kEAJO1P4jL6kzalECYbz22zJC6tTM32UN33PKm1mAwUpZe'
    'byY+bXoZ6aGWU7zKaNZwKi/95SBjABAl1oXmtpufPRXV23FXs4COLxdWrVp87j9Px5knsaZJtdlL68Vz+vmDI7dLrWe1cTRys37+'
    'Ue+NFu6LNbOPRnZ2LN+LN7flWqsZDmVRGo7H7ro+lbxb1X7SO1U4E8BIV7dD8TBNP+/uxTvZbHa10vOx2tNKe7X6chyWjMy+26sX'
    'VltvP18OBoNq93lSs9XGSFYf5fLwuNOBAVqn1J50p3rDbSWxzaud5tAadVOjkvawyRc8Y9EYJJxmoqQcxWn7bghCwbScb5qPllpK'
    'zUqV/H3aUGbIs77o2fbALT1JW3GyzS43qjPJdUWY0wz4v5tyI2sUU/NtTV0VnXLqUOsWDTujPnijgpstHls56dDeLUC00jujxmAk'
    'dbSCeTDl5XhbsYHtdPIVEB3tp5fbvGHr2eZYzpaWx0a/AbJy3s2NRafaHO/tpiQ2q16n+dBpmaWCrVv2pr0u2MbCmCSKtf3jU6HS'
    '7j/cN0bDl9LaHo0ay5vyMaPbcrN/P2rlNvOxW0+Vbm77zd5m85J5qOuVoWY7+sum8DCtr5azl3xzJnU3d4Pe1lkbieo0t9Iq+ZGV'
    'WqwPW13Mt5Xd2NE9tWYPJ23Vs2uPHacwtIuF5WC6WJXX91NY+F6mrPdcZzPrDhpKv6TV7UbxTjSfxPaoYbdzbns/0ufrF1HNLzO5'
    '2aakmalC79jbbbPuKvFUf1oqidVx8thJTKXO0LCGJfP+sbLyHOvJms5G3fp6D+zzs9bwJFktDbb32jBdH5a8asG15fS40b7v7V/2'
    'w4w28eqiXXPyT62UnFfaeWXRTPW3w+nIHrRyvWVdc8up8kh8HpS7i77ltVZuOX/fLG28/VbP2lNPsQ9D17HtzuTJsiqiXD6k+saL'
    '9rTpPHQeso/7m4ex9XLXBWlbKj3kVvtmP9fbzzq1lZiZg6w5un3KV1uWZHQUvak7K6koidlpt5E9Dq30+jCWD2mvdf9czbn7yXoh'
    'DezNbpIdHtL9eytfW9m2VRmVx5oriwc3O9XF9MBuj3ryIi+njflxvrh5cIft2qg6OHoKMNHAzyluSUxPjvr9ywgOTt2yq862N5ng'
    'FEy7YTn2epN62amPsEyDkZrLGZ6zMovKcCxZ2UFldj/stjqZg1gZddY78dAa9HsDILkbe3psZR+31fuX3XQ6kW+yWnEij5xHpdlP'
    '3zemk3wGdYzLrPWcP+pjrb5/kJxBrzw2KgflydWPh/Z+MJWf3H1nOOrdl5reyuuO6s2SPswvrYdhc/KwkJbrJ69razPXgkHCiW1a'
    '97eVXXN/GHribpOZeIZXts1pZSSujlZfs4rZh8JQm1kP5UF+7/QHg3SnMmi2Z7XFujjQp5pRVZ/lYSftTO8lc9oeHi25vkhr6fLW'
    'ylq1fGXymLXt5UNmJD1ZG0mTCtN5/qntVO+ed73iuj1XV7vtYew0n/qZzPEwsqZFt7VRqpnWQOzc5d3juvh87Ivqvp9RMtvOLlt1'
    'vEN1v/GamFFy3wT+tpEZHvabzd2TXNEKiSkMrnSj5zbuzjLHNft2W71x3eeX3Nar7LZAgyWnIzVmtdWgN8pKNvCEk6dN8TjqDMRi'
    'ftsp5lvufjPe3BaL81bZ9Qbl5XyQTjcmBVU1VvlDVW0qQEEfgd8SO2q9trVejl6jdTsXQZg+jlpbt5y2isa0bg91u6B2nmrWOFsX'
    'j4OOos4Tz9Xe7TR7u1ZaNXeQU5ZOtWUWutYYmM37sekpj6ZRaToj2ZYa+XJrDszHujk9Zp3JFEY+Mped4zBx7Nw9tTojtZpeS5Xe'
    'xFoX5cHBHBXv6mv7qVG1251seZMxjIb5eFtYHCZOtnJs9Yv2cJfVO4WEpWSny9xjd5jx+nalXl++LL2GN4PTWetY8k3Ocir5w1Cf'
    '3jvFgjppzia2tS406htbthvDrFRttvSaKSrFQfqpd5sDvKo0rbKczquNkluVtvVW2UhU7PZ8236yKhVdH4/7oj2xD9Zov+3Y6h6w'
    '3uSg7fTFZpkeVtP9g23cTqql3BbkWfE5c5czpea43z4UngdFd6sdNnZhqYizvfi4b60enp/vm1q13nra9vd2zXBbx4yn7odtAOtN'
    'r9MfNPuD+1VltVq5tcVkqvZ6U1E/ju3EZGJPDem2ABzrYlAZ26ndnag+rnqd+6oC4Jlo5lPrfqK06lcag3xLmgxgq02nUXSdfLOi'
    '98R1wtpnxuLjMtvOr5RoldPq1W2xURgUdHmUN7bp/CzhJu5KWmsjDjqpail1rM/UVuS5W78t6+V6ubtplPYFGdagYuxGq46YsQF9'
    'Z43EpFc8pq2S0xiLhUZbLmw62+6y6kl2AirfgUj4LPUNYz3Yz9aPjpIQlyAybGv78tIVPdere+2pPXEbg/SguGkA59S1nf3z/GY0'
    'qOt3+u2L5dwN4YS2ZHtl1KeHzM3N9P7w5/onLVsvWk/SrN0tHru1clXsV5qNR2c3sF+8yaY0dCqlhKWuHGhRfjgMPNtLtOr1p1G3'
    'X3/qDuxmb3bsbgbDdumoD+Cs5tVatv80XqsT4NN3Nw8lEcTgYzdd7jz2X7ptbU0CqjsCCRVQZF0r35nWeKavR0P4Zdw+DHqtgnQr'
    'Ol1n9mAXmrN6vp8x6ppSN9eGli3I3c283Vjq1lrWHfngNgfryWaSqDzv3KdsN9vLSQurMBBB0nNAFDVb0/WguJL3g8xKMYtzTe4P'
    'Kunn5eJYGT66o3xhsswUjqOqPio/D5/q1YUxKNQOtj55dFsDu9wqZ4o9ban0s5WXF7U1LbiT5zxI6NVKw5oXV05+npESynIPO1Aw'
    'dMMaW5leo+cNu7dVs3ysDGwQowYKopi+mFvf5/vuUtwN9MGDo2cediXx0BSzkvN4a2/dl/m4Orh3DuNDd3ZAP/zdPlXUO6my2tel'
    '/e55P1q0W71GRhzozQpwBvtGf6C07xv1lXTce3bVtmsglwG/ZbU6qiP1RrI1MO/6z9tar9Ear8xs7iX/vLmvq8Xuy+DZc/ajx6fh'
    '/qXrracPdttQCw1Jsj3Zrm20Qt0GIUBaF3P7TbUmbR/71ab7MDQaXcc92p2n9djYTPVudz2oiVJ+tcwA1FTSIhB341ap5Op993a5'
    'TgFeGA4PKVfxtomBWNqPpOL9WO7lTHuafy7YVv3gziqdvjs1CsXpONueZNeaadfzitNR22rhcV9yNroiPzfHFRA1V6akpZumutsc'
    'pKdC42a10erLKky5OEmPU72lZW1Hfce+ry8WeVhDBP3bhvH0YFmTUqnYazx602azJz67a00qF9zGeppw1PJd+WmYWnXH9bUJx1Ge'
    'iunufrupK1q/3pqa9g44mXJi288XaprcLjfVll1Z3d2O9PXE0zYgEaQN8z+s931cDtNec5iWxcfhSweEoNZ+nB9bVTPvZGxcisa+'
    '02+PQfQvleT5VFy03PUmUxnXtWLmqbCZHeVpBQRRy0kcQMDfSpr8+JRPFwbzcn9g27iUIF33U/0XcQTkunr73O012qpbz2xsQ9kM'
    'p+v+pLbV1WznUFLd1W5T3didnNzKpVovlaw7zL/kK+OJNy0aqtx6tnLAmw1BmnKk1agsOqqStQf5ra7tjjP5xbNK9VxXedkdWpm6'
    'ul7aE8t6aoFwdETdtTzUdWkw3Td3wwevWLzbbBuJpdQEDJXdAD/fusupw+zTZrevvFjD8dGswOgHuDBKr753u7NjSwImP7sa9Q7r'
    'XPlY1O9ztVS3OUhILwVxWGkB02JUy4qRflKeNtZtV5LKy2J3MW4UlGjhVr58WJQeZha69Tdn3fE6O568uJXyyYdHOZF/Sdy108vB'
    'bL20njvuszm8SxjR12t7MpeN+7tnr+qNFvVMo9fbW1mxnrB1OdNpPwA3NwCcucjrSkdzc9OmMtgAT9c9FisZvTnvjSalxrjremXl'
    'Vhvd9exMvZnZt3tb28pZVUUynZEF57ixecrsvFV5NdXusu6mae7SB+BWjmtHrjvSGKDSPhT15qDRlwYjeyivuumtPUhnzPb9MF+2'
    'OuUHvGkLJ2STf3gx2rVj7a48tpxxY68VdLsxGA9bUmo96Q9bqtvrDR4ko+JUstIGWKeOWi6kvfbCaBg3m2p+eByO7kCKmGRaneNk'
    'M+6UgE2d223FzrefLa9TNOSm89Dd9VulklTXrUJ9OTftbmVVafb2nqZp4/Vy+CzBf0yQAmpaTd3dVgGy/zP/Wo8baa9t1TxQz7Vt'
    '23BCbx6fzLVUnejr3ai3sdLAzipGU1xaw1ZqUtDV7bZfGlV6XTfjFmqA8pzm4m7gep3tpDEqSN5yZHWM4XaZq2oTaTIZHR8H04Re'
    '9BrN3nBf9DZdSxeHXXNkT5x9yS4uAWN0xzvgjcvq8X6T3SZKXW1T7uut2fNQy1hKIj/Lzsebu/vqcFqte95g1j+oCXWr7vrHtt1p'
    'V/Z9d6QbujiRK32pNZf0gWx46bXzaGUPZanZyzq9sdwcVsWxjJcl3HL1sLZy6Vwztxk58rYyKE1WhzbIKt1N5Th4Avw23aT2paUy'
    'lkbV7KwljryemjqUdjd3RiO8DCM+PjduBuZ+1q0XJnZf3I2z3bo9Xqd2N8ttdlWrrBf7ia5rcDRH6ZKxBWBc2NVZ31Yb2kKa7xO1'
    'RmPaKE8njZkiDfTOTbl1B0yC6I3MviYWJz1VfLRXg0HZAsEtf1iX11I2MYP/6Mf1o+SOXprzwTCtHKXssLuWi2XHGWjluprOvji9'
    'dUXPq8/VwazQ91awNdNMK2MWtPbgqVZJrdM5dTSfWvpinX0cyKIk9w9Nzcg2NUdpVrcjswNCKmzfRpe99tgu95oVx5bNXl4rDo+N'
    'bRZ4k+3NuvZ4/9iEITbl5dpeA/9RMO3Hp1Zj9x+BwkJL16TNodDR6saLs2q1ZovUspPK1p6f9/qjeX/MJx4TzcfUzWMt8mnSKdyU'
    'Ev5vyVo/roEyVjPlSX2jeJ3htlfudTsgFGxLUmpj5cSmV1/2nV4fVn7i2KLZNzdydlHL3KVGWiZTz3Sz9YIoK41e5ykL4sV+ZHda'
    '+uxhYB27x8Em81xflA13+lToilvFfaoeR4ZkwJgk5Q6azx/vssPCeH8c7rsHY7xPF0UlYVmmmF5YmbJUHhY1u3iYPdslZ9qbFyr6'
    'tG8eNtv7VbFgyoa6V5805VHPGZ2dV5x2a7Y1SpT72cYmtZ3tWjNjtGn2VwXlvui11URqd79V9s2nw/ow6GybI6P6PHS8o+mo204u'
    '394lVoZab67603FujWqb2nLo9ToPPbtz795p20bBU3uZwrKcyVdEaajU0ws3LRbLxZub2qJxjiHcZbXb2SxXY7EImCHvrMROv6C/'
    'LGbPxfrTo5xX5Hqn0NgqjRcrnWi1S23zyb617fRYHGidysZp6cpLRtJK6cH2kD02NuvKJJOxS8217Uhi5uBOy6pipcqb7YtRtPV5'
    '8UmZzlRHeZQbkwHQ83ZtnT8Ocg0R/pdb9uWD7BVH2uZJHPXMjLaxn7JusV/M9ADzW6Xtw6KVGTUq6nD99LhrjwuVQis1TJe0wr7n'
    'FdKFcva2X5OMvme4x0KunO+9ONnqGjjwbNZW8+Vsubi5leSqM37YHyfysF/v9tPHcd3TZo497Bxq5e2y5/T25rR5TMM5qExS8qK9'
    'bD3r+vO2oAwrQ+C8871WrmW0X1L74Sxba6mLlOamNi/lR5ACIx9kb7WUN8tJtb7ta/NJa3dzu/orZyVRTWWlhavA8m1layNZ9WFz'
    'dGgVZg+aItkbrQbijDnoHm+P3X1Tsz11pYya06m09MZ211gNNvnW3VZea5tRRuk+WLKdyPd2Y9ktu0s17yqj/nald1r3q2Wn+TA6'
    'bpHjrBXbq7JVbq/VVW8IonZm3HoRCylbLh4fHhcNr7x5ubm379fc3KQh19QwbbnSLO7u17o2u/NGVVEcNWRH1qyj/tQ/1PNNI9E5'
    'FOz9bCKaljlvDqRFz9ln6ivZzKSlcnfZkKztfeM4VraV21mx0c2qmW6p2BUbTU8Dxs5K1+n/BXO7ep6/6IfeVG+3x05WMjadsdQ1'
    'tfWykB52Hmu22isPDau/TiekUdlLD3NGd1hMSW1TX8rKk5cTAUPclG9uHl70+evV3t1mTOdxAizy6K4z7IvPR0lFO32x/NBpg7yg'
    'PeXE9qY2y/e8WbMyKbanw7rdGTyXVk65pY/TkoZxVDqzF8kWe+vCdAXoOFdov+gDGETncdiS9+5LzrAnQ0Xv9pubQbaw0ReKa1np'
    'KSyBvNWzSrcmjW/6D0AGSodJKWWLti4Nxb46vLlR7/sUtaMyqIgdpfKSu7ndZG5LB7czngI56op9b+cdGtlyo5UaKalaXhlMyyOt'
    '0Ri2Cn2l4DWbSmPWOHrNvpvJZSWpIQbrunyx1r38YTJdNNvjhjW1Hm3A1DagA9NOuUWpYRsrceLkxUZ17xwy3qK8SKuLrNgz1PG6'
    'ZAGyfJJvbqePwz8F6odByVreu+XcDjjHwkDbrr2+fWxLRqlykNqj3l4CGK9ZA2DNynBkWuOyDdxs87GJqo2W1b2Xd/IiV7Bt3SnV'
    'BnKz4Tley5SWg1qmrO7KzUEvdVO1DQNgumWl24PC4M44Via5YT71kjeGXt0eWKVyZzjajoD/vFm1ek+z56bjVTNSpaBMpUOjl9m0'
    'ttLkWEnUcqlRbbY3eupq2hNdtd5SCrfoV7+bPO6ebou91ni7f3ws5O8Tz4plPI9yy2VZXqSq7W7TKmTalWprPhrZebnaKd29qOnj'
    'ulHq7BObl9TyMdrBMr2UVG+5f4m0fj9Zbde1fKE5POyfO7NZY/hSeCo8VhPj20NlaDg1u1gpT25be83M16vrwUDKq1ZR7LRb2tO2'
    'cOwNRfVo7jNGv1dqudm+Ut8UXE9/kUqqedw+LXbFtuRWB82cbYpLfZN2Rntv0KzkdRASAb6AOJb7hXR6ZD1JLXda7XS85XIsgvwI'
    '9EVaA0sqPwCFmbWdTV6XRWswmR43xWF2sO0su8Pczc1ydX6+HsYlc70/jtp3z5UDEEs1kTnYCRCBB6N1tqa1Rsf6cjDa16yn/b62'
    'X62mZr7aVPeHOmq2BpWOWq8vHDst9ue5rdop2nNH0+urcr47f8jlcodB1wQJOXsnDio3S3FwtLvmoC+Js/xjTSs85fTyk9UoWc+K'
    'p5i6panGUB9VrOKo8tQS7b36/Pgw8BobG8jFeAoLln6plsr26NHYPx/FTaP0Uuxv2m1tYjgybPL+WBmVnVzVMZvHwmZ0u17eZA2v'
    'myslntaqt59pj5K+z5d6z+Wplnpoje2UN7tRbjezwSH3nB6fNt3JLA+rfQZ2WpHGa9jWbMvOeQ/le6/Xfh7MMtt5a55tIxBJtWEr'
    '324udU+9f8zemVP3MKqPjGFt+7jOWGY2XS5tV4P721zlMCxWAUJSIE7c9pvjTVqv3NvOqGFtMtmG5ZjA2Pc66rYn9+rigyRWPTQz'
    'pDsPuVqv2Mrot0X5aDar6QPw90dxMFbzs37+5nby2L35X/9+oJ9IpSZ/f+cHpg4SmgdXfiivOaYPwZs45sY7v26TeqPOUJ3yfKAY'
    'qxzzvPhpyiSWC/Hv7xaeZ7nXqZRqJHfaSrNURZOSpjNP4a/Us2Yo/1hLFgzMUSUFE6htPGENbwV469+fkfzUZTy1jUlZOOPnI1w4'
    'Z/eXWNRsWd9gfpQdZtLC+0ssNQq2MjQdCrbtZ1d98+bXWTxp8SygdBbDrTcoSPevbC2iwY8L6WQ6nSmmi+V0Ol04iS6dy5WT+Uw5'
    'UyrlimJaLOX+C6OsZ753D4wG+vq6V5fl9pKi+fVwiU9u6TXC+1o82jiuIc+4TbfeMJOHzvLSsnwlYdI6CsN7KSiSu2ABzhXT89TX'
    'l8amHyXMkxEJvS55fkZZ1VBOQ7d7CwAHI0y8ghmI/u1f/+8by9IPOACWCZHFgv+3f/1/BJYn7+S1QBm0wmxRASzRWq3eWCt6LSxN'
    'zQiHbBwoFRVPwROZFGa8Eui2m6BoMxAnMKFfmOEoKZytPE/45jesUMIztrQrAVZa0dWTJIqUP+x1XgF28/Est/Cr7E2R61RTdgEv'
    'TB0VrZoU/Lx5NAxoGlO/HnTVT3V32uxZKhVWnucXezPn21kE9MxZBPR7BjOUpvqvHa18WUwW0tlsEWMylEqvwor7Z/ivBW6njsMg'
    'wDhxFgYYh/WObsKGczmLj545i49+T1B/PhdMVpfMpPPpbL5cyuSz0RDN+XwhWc7l8zkRY+jn8uKfz+UHMaa/Nxca1vlczpPxnUVN'
    'p4Q2UWwnwviTpWw+lxOzRTFXOAk1jVmdctlMMYOBtNPFvzCPH8VlPp0HoQyK/G68msRZFPXMWRT1HqKQ8/0olnPJQhngppQupEsZ'
    'P1w8m0ehlEyXcmVA2plsJi9m/nQeP7qpezoPSgRBkeBxVOczOYu1njmLtc7wElBRQGrs9IZ4JjK3fC6bLImFEmYAS4uF8sm5SeO8'
    'C8ViNlvIprN/PrXMrKzmcmdTy4VDPgu2njkLtp6jHLvSFpDTDEn+r4K7kE5y7RbyuWQ5ky6JebGQgcFG0h1kRDFZSudhC/KZLHwS'
    '/wvp53fuUWcxLQ8QN58oZAOiwJNxuH7CngAZ8lTikVR2mo5pbjH/J6XoXVBquzC1yKV/Td4ljExDCJgYHxNHUqdfuIIhrVWkY5Sm'
    '27QEogSEdemL9oqVg4GPMYGKrgERdA6vpxPNa4P5zF+ltKGbz2zU/kCIt1rQZtIVayAKW03dEY2THABK3GJiFBWXcplgWm73Mshb'
    '518ah1kHN8bZ9N8Yfhfg5I2NeCuPjH/vONZuVuMR0swynyAnAtwf8hUHAYPT/yiZC/GLsaRiyvtoSzs4rQvil2hiPldZNc05bPC9'
    'KcN+R1Ii4rYG+WmmKmX9XDCuyb2MbDo+Meaaikh4B/9Ho/O52EgWxzALraXjACLJsfDzxqPsMqdM1Z1pHaKZF50gBAOlXYzM6u1E'
    'MX+SfDFzls4gc5bOgOezwnPk/tcgAh/r/OUMMpmzlASZs5QEj7Ad12fAnxBcgvL/tiH/OBFH5iw+ReYsPsVDIPPAKbhkIPqrsDb/'
    'q5Dt6wG/Tb3DAZ+JVZkzsaqlI89MyFLYWLDECskYa1fV/xsB421SHeaMPeNUs2ecau3f/vX/WgObjBm7OV6LskeZbPp7XN65MJj/'
    'U2KGfbwiZmkZwKT8vSgslXBYLshCGP1jqlJkD5IWDiGSYhgBE/ziuQeRDlMOU/rVHSVQR1RvbYjirJPCDc9n/SquC3b4OqjLeZ5o'
    'dW15PCkwawLlFkoazPPPJgVKZoxdnIR0obzFPNGZhZmozRlLiczTgp3KGj/RJr5jIjrbxnfZM3bdB5GZY66jLJYZcp7nvCaHjDNe'
    '2eedeEMBoJgRNuoN7ps3dp6bOHvSWBB7Bhsr8Kn99O33lCs7muV9/Ol3/0E2DdcTfhE+CK7w4WOQgS9pbwB1McnTdGJu/D0v6W7n'
    'UPaX2MXfZMnYSu5F/BLpta7wt/SML10P4+uwl/SMLzFfOOwte8t+XARNV1rNHny6uJJAOFev3IPrqetL4Ra341mSu/S7Att7CezC'
    '3FSFfu1S6Jgg25qXwiMeek+TJaGpboC/uHE0SYdRSIZ75aqONrt4/1MqJdz6qdgpeRuSYp7wjaVpu8a8jQh+qLAACMcgLsgGrOHH'
    'HLMFgvCtYrtTHTuBc6bNoXNr41goPlsw0iSfTfum8dDrPcCEPl9wanJxKVxwLE2PDP/RI8Mq9MgYZnpkZ5UexXJRlDP0mJ9lFZkV'
    'KMvZwjRPj3Imk8/LF1/81ey0Wr1/VGqNBi4pZ2Ev/I/dXquDQ7tgrOcVJ1HXWzEoUnuu/qNbmzx0odhXoQsST/pSeEYUBX8bKILD'
    '31EDATctfAv3sPN803vdctAsjOjhH4OHTrfWakKx3HsAU9iX6WZtwcHUXCGGaEWiYFAYHwcP8HOt2rnpQYVunFR0SFZZTlUJU+G5'
    'wDww/o0n+P7pJwz0A6iBor58IMzI+4lkrCZFRUyDQaFWEfCCjzPiP7E4QcbqDnPtubiFX3h9X9HiXmDOQGxGZmXw4LGvEqBUDxOS'
    '7ygmFXJHmHASp8XVijNYEPgW9tOQAMliP1+/8X5ocJoiXH3k6BS1ODoWE3bAH2LrhhD7KuwvhQMcwEthIXyD84Wd8dZZh3DE4Jl1'
    'hLUpkW+wIpEJocbLVXkXGjKd2MbO0QDvGFQfUMMlrh5Uh51Hvp0gY49KEOFA/10BeACCEuYqLAbOBl5pyp25MTz+c8EyZ8MIoHpX'
    '9WJw+rHxjaGYXQ8zJuJiX1L61OhvDADUw2Bc/ugvKeV78INPNPitAz96D4wuDdGDwSGIYkfILjySkiwoi6+aKAUFLWsOUJsPwkzS'
    'XRUxGfBAQ8kxVMV/+f4nDs6KOpM2uod7F4sjAoU9AWK1kFzN5TmtoIai+s/ETF8LFyyLIxzcnSNZ8HsNE9is4be08cweEFVWATbV'
    'PzjDzk2bZmMQeYEpJYuXAquHuhtMEQndiMk84K/Z7FqoGSBNaTCR4HBOdYnOQzBSDGxWU6i2q3q4gDA2f0qx+CUD9WvaOcNUcORf'
    'hTT+R1Now5GrgdE/B2k1L0/ggfEmnDURkC3BqUJhKEccyXUETX3D/8F0U78JV8E/gk8uIDNhGEB8LXmM+2BcHyW1j/CCYW2kgQPV'
    'cTUQRwG3wD4ehBhpPwi1wKBD1CIABgHhDDmILa9CwgwOANcJlohxQBjAjUbCQp9hH1OKQuZR4nksv5MOMDZEXQpgAzZWYPk2hKT8'
    '1jGZILSsKqxTPBA4qvg1KXrgIAkgLUARrg3wdyvcKr4nsGycJQLyT4vzLvWOd/KOtZURAFUCgFMaQdgWfePydbx+hahpsLw648bh'
    'X1YImEJd26pcXf2Ov3snxIAfQ24ShvMu/p6WyaAIaIhXI3JtjEFEBCBY+/CPwUWcukfG9WqmmxKdab/n15WFCywJHITPs8F+eDsg'
    '0wJXtwet8zbeCxZMlYwQTDtN6U5580zTxkZA+gtoEecCYjtmZZV04KdQIQHTPVGuBJ0gvkF1yiVTru00F/E2174ABMw8WBBE5OGK'
    'xJNCB1UwOE++fgBFAGlrVUJoRLAO2pdNS4OBEgsLwr5lAZqcbaCTbZaDfoSaoa6BjCzIkpOewHQJpS+YGujA2fuVYe6SrIuc4CsT'
    'YNIyoJkDQO07IgkwZ3dB4iHGQsScxAjAAfWAaXQDAAtn/54KcGAKpjE3SWDD88RnRBx5OBxu4tMZVZRcsidMAeosPE5KdJZBREcS'
    'M7CLmuFqTBCkFZIC8RuImqTDyXS/f5Q4wgOMCT1WYEVTSNbxAbAx7AfS9qTwW+onGeiLC5zmTnXw6wNgZAeoO5BKOM3s19dvHOtG'
    'UMwHYtlFwLEcASeTSeUyOIqMebqMnD4k6lAjE9SgRfxu+exlgNKV5Pkc8V043xCzU5PACaBCD3EbQgliNzhqqBLjclQ6zvVQLBf1'
    'THPciJWKARA/SddCa7oEHiuJi/cArcAWx/grlf+E4RHu+uc/YQjx5FqyYrHPKxj+F6RNHFTwRddDJV5sBa8/AFeZvhA+CbRuxo/I'
    'C+DEa2yLVo+tYfZ81YNVy1EJoJKzjUH5l+kwcboRU+LQn6MidRBYVMek5tYMT52rTkz5lOTNxGFciv8DOocvbIafAJMDMXwP8lfQ'
    '/loDiPTUGIYQjBNMIGuyRe4i2jN+fQ8ftZkQ2wofT3jnuICxL3dENk7hMHZh4O+LSNXfBTFa3i9meuHxYMVZYnGqcdrZV6RkEgww'
    'hObP2y98iDRyfPTn/55sEtj3z/TaR7Gw297BUvHcRl//jDtrEoBc/LVx8v3AVt7/5B+04Kx+4INF3TCcFF07qhFmh7p+43Dg6zN8'
    'cH0yzuDQ0Et6vmQqav6KniMsG8MhOBwOeN89uNHFvkT4hAPCWkNo9/vwOxDw3Ma/d7JfY4DgXPJTF04kyfFdPGBoG7Xmwz+6vXGD'
    'BL/PF2SURwGT2TLpiXQRF8CV33Q6rSErZwAPgx8BA+IfkPgdDx9AOl9g0WHtvvfIiqLmBj+xzcEnsmWh6BqcEFkH+ofeBDEdgY/L'
    'bkigL1zKWH/N+SfTuOIMq7CVQChnHh0r1fJ+QoKJU5KZYMUhUhd+/TU6yyQ3nLgxPUk8QTwuyOwJ6vF3J5XZrKP1iCOnevRE9ejp'
    'pB5bgmg9MuZRPZbfHevRUwTGZQRwmH1HnW40XYkQtBjJnBLhDCY4kGUJaA9KU4JrSBYQai8Oq6ESjaQV26m6foWACISUrVhSqBDz'
    'AFQfOyJLAmvaOJDwyRhYrjMBtAuMBKWpp9eBKUolhhyJs09/uQx8gQyPs9pYxEJzzR32BBQZhByKuCu5VxoMJPTJwR1EIxnxGyQB'
    'Y2euBBINMBbKiR7gcOGoPk/icCFbVZIhNIVoQGHoluuy8Gh+Co4OI0aXGN6VfYiQKJ/X9iGJNQA8LopTW5TxdH3KxNU0SVcBqaig'
    'EKbGEts4wsCWkB0SrPDXBdK0xBZOtd9K2MNC3UOTMraY+h9/+5y+KktXsy9fC99+SWlJVDTEZEKIKPjHWJXPK/WAhBTZozOqCzOL'
    'x7klmRXWUKRlY41BPWqLY+5XxE6DxYPFgCq/gzwNTz8bEYxunKFxaB9WdaO+j/SGlscPwuuWjSQj5fFoYZmzSzQgxZc1/d6SBBjE'
    'E7jEIuAi8rfABTBBFPYH2t7HSR5lPw7xS96mzz3goD6xLYFCfCR+IS6lwjZAXfoRp37oUWCVYSONJIkjtAIkkkChULK99pWBn2Ht'
    '/sX/kdRVY+4tvrCuvoUrD20iSqAWP/hNf4g2zR98biesaiRJjQkDCWDsFSDyMoR2WOkPgv8y2lJgnqO+URuBNSJv6V1k2P7OYKRv'
    'Nt6paSIeR2jgb/nnaD88LXm0E//VWQ9vTAXNsXSwgmeZ/uKh0aW1FXuWvEUSxHNDCYpfClfAKBcisP75wtJ0nZGrPVExXddgkkSb'
    'AKIuvoRYGxpBIYdRCRJ3cFL0FG0woJtwCIgQUsr204Ywmzu1gw/UDD6crM16jpNL/Y8w2PTfUzHLmP8TQ07/c67N/rlTp1bcDz79'
    'Wbo6Ao5IpD58SQQYgppJ4tnnC4U/d8BPpiO/F/g7Hhw4mbpGdRPUw2PBm7gUdtdBE5fC4jqszyGYDT3QHn+mzxj9/0uctdpl2xO8'
    'Z9W+vYYjZuI+OeJ01Og9NsYL+K+iyINE/A8RNsJAVkeN4jd+dDmKBOQHFBmL8HOJHfBW8A+rSEQATvEXbPs9s6sga0Kx832T03qD'
    'A0ABlemAJMQSVzpQK90vggobFHHnJtJlAk/URknI2ljvSR/EZWLVBamYdRIDjMO0tFwRAvRzrbkor4XC2YllUQApY0E0klRVZKgz'
    'XS95SjCMCKVgHEGM5nlGKlz1RHGLG6t84QtKraEMY9F2sPG9h18+tXvPvtDyWV98dB/id9wQ/ysSFewsuZDcmIWjCJoMVNc+VuSo'
    '8L2gkEehwLb5vTB1VGn1nkOVwJqTFAWaC8EtkFHemnvSheWMGSREBJ1HSHcULTPNVcinMi2DREDgerSbgaR8TnsJP62lfexKJMY/'
    'Co58JCgcM9QHfSQE8TUofo0QyP8iZawP3MFxWoXMzytmQ3+L2QAGilVjMv5/mu/4WWc8B81bJ+XCl5M3nkm/2SfaGXz3NifC7Bwf'
    'fHZCT/IXp/wEf510VEuXZDWW+rubSM0BmQsX8SSUWscAToBSqTFYXzED+BNZD9YPzf1kf3BY13x4sFvmNY2Pdj0q7jD5DzkOPeQ4'
    'vvpbxN+FQiAWZoPHUuzp9CNhx4C+UjF841sYWNnzHQeQrJ3A55/C5ivwpRU4Bd+QsWWibLABACz8zekOcJn3r+1AJh3ZAS4+MaDD'
    'dTiTp4NFYqeJC83BdJFbRBGAi9AiTI8tSQKff2JIxRe/fTQWWn7cpP9MKJBZkngpZg9yk/j39VduIXIJkYXkT0JXNOL9wh8ROxKv'
    'zKxJII2T9IlsR2BYukD7EP41Z7MoG+ImsRLCGHsSItYo3mpok3KT/nMAT5x9vQyRElcvkOot1M6gtVdTuI9BMsBevq5EIg6IWaZO'
    '8XFQPNCrrDTFDVqDigADwDh5KEi8wteAPPxqmtsxTSIhb2J138JL3pFAq6+BlgZoGwXLE9IatEno9nttvikbhOMhb5u/UPfDq7o4'
    'sNDoeLIGbEhIwBwvFpMuhSkz90mc2//0SZCSiFOvhNg0fDfFd/GICgYWojWLGUjWuFowGKJP1eM4dKEZkd/8Y0cqQK5UDi6MCBJr'
    'Gf07SO0PKJDM+GSS17jjzxvqZXYxx/f5gTMVuP3w5YBjECwGmqij8k8MXhB4qyjg0cLF4p/TcASUyGwV1fIWbLZk7EZB/v0PJv71'
    '9dSVRAJmHegmTzS+7mbqwf4RLfvKUSAygB8EOgQhA6WxjjWQsfGCFeNF4XciEY/SXRkJLp6DGJT6rH0B8orFrY27iMm4k8FOwGsc'
    'CT9lxvxem81wrQLACCdMyE+aujEJYAM+/osQywi/sdftWtikArICfwnrGikC1RTUfb8Pbc4khXElSdAlw7KaEZtehhgXvm4RAAFq'
    'niXZFdCw9W//+//J/R+YuzrzCWLf0AuUWeKA2vCLLw7aePCW2AFgTUYVErsXFE9GzisKlin480+tvQDeDP5ISoqLStJWm0ue6SSB'
    '3HioJUOOInwL/To3c6ap8FUa0FIdyB3SMpybF9IqHOHf2YU0olkwG+bPBrTrrFB3oc28vzPS9m//2/8LJV+X8dsIPaZWkX7ZzD6F'
    'A4p5SAw9WtAbJhBpMho3fE8V13JAJI16hXPLogVi5nv0mPOkFbf3MOWfX8DdOCSzkOENKGSwutj+B+ZsDkP643f0FiNb2Yd3mvxO'
    'kBxNumIuIB/eIfF49/F33Eq6B/jub9rVL1+x7rd3qY+/p6Duxz/e/3TmD8BU6GQX/hWNpDAUfI6UQPMcw5Gyh8qzwKVNBsDw1Add'
    'xV+xC99/LTlXvTtgEWEesYuMEq4uaX4r5K7G6Bbh4TSxEDOXXP+E2Q4do5C73pMLn2Ad0PuOmAtWXgzKi0VWvuCXF0u8vMiYEVaK'
    't5oPSuVYqRIeKtjLuwWqgWV0qnGZe9E7l6HPdzRkEgfJN5NQK7k8Mus7d77hGtpQk+N7mie535R8r6oWd9hh34IXURU9jqCOKIix'
    '9ieePu/f9PR5LXYS5fJFA6bzeIVq/YY/+9+QpY698RaOajoiIf1FobQJQmEgkJKaCV8Eq4P4ms2FBEiDIdeIfMlVAEjpFFgmlYR/'
    'lPVJggceUODbg6pzvDBHK+pTPk4eENSY4htOJdm2Nyj97wx2SRIl9ui+vH+9L/+etf0QrO1bstEUWmTNE/2/JNoQ0Mcr/jiNrHQ4'
    'mM/IRnyJyg2vvsEugairxH1540+H/XNkq3kDfzoT3Hach8FGz8fJyXkT+B6+4W8R9ikBxfScsHOeX357mqcfTucYckLM+9S3qZvk'
    'hgI7iC7Wu3N2M8JsxhksGdwXGzmniHUjslc/4NUYL2R8f+I/ZOXY/mw1V5uS2PYG30lc7M/8qKDqxjjnKGfavqvqiC5oXyOMWtwf'
    'dqQ6sm1x7nDImLjgCNOC3uFdc/KxkchhgeiamBHMCxm/wGEitRoes3BdY68XFp0d2X68ubrU2A32QOsbCLBIFnwWGVibgH3yJCOD'
    'dgY4KE4SDTHJPT3u8bz4fFJKyERkVODSz3ktLBz9/YoXY0A1ZJYxfwIuOhfJ4bqs0XEf3+G2MVE1sircwwPPHy2QTwYi7kvYh6MC'
    'K4ROX9wZTtEcjrWwZQ5GlqkROUIfOZBnDQawKKoqCmK2yL64Hmq7UTrBW0sONqYf4pEVd3dwkN5YcesMQLn6jol1pCj0TabRLQtV'
    'DnOG7P3639k0K9w0CzftKlrEoiJzLGJRkTkUiexkpCg9usDjSnHO5MomcNbxeCgSTw/dHUPgITcembyEnUd+TwPOZHpoccPNv1O+'
    'Iwaiy4AB74Ey30kqgmCgSwekOzy6AykgksIQnQtR7L/Cyx4C7fsF4wrJM1bhDcSIv0JHL+iDXpE4J9GFU4c86hWWhFeaz5FJeX/u'
    'JheBXBdFOtwm/cCcnX0Wkxom6xMT/0kGgpkxcRd1Bb5aJlRVfAoW7Npf82ApUcETLKaFajp1j4JDRE4JlbPUmYW9cZy3oiHAyhIe'
    '5TVJ48W/BMu/ImTISCbuAa4cO4VsntHJs8VCLpUs4OiXxVYY9wiJBrdRkrWbLA8+Uo/gWkByR5VmRiMGnBuOntbKX4kktPogyYtY'
    'bHUpaFwkXAWmQe09uodEZVnW9A3gfqgpq+yIRqi4FaHieECpFJJENoAkG8FaPV0jnw7FT4fOoPbbT8wFwjXxaleA8ABm1NkMsdFW'
    '5V4h6N/pk1dYGkdDq/1OM6I+mcTAwFaEfLPv8xxZQGzuFP8Q0JHOJkbuXujX5bNF6IwjM2EjBMBABQikV/HtbbHX3AwwrfDxPeMj'
    'b4kX8AJu4QKjN+wvAyaSmEQ0V3K3SdIiEu0jCyvd6Z1vdMmh+Z82RFEtWDdsDWLIrad9EZBpXbBtxsFewhT5J5+z9RlW+h5nPtH0'
    '0edtKKcxca6sH3TQ3gAwHKJemyDYqsy3F6EZV/o9XvlgqaepK4fz0I56xRhiH+Fg69KUR4oIt4ahUVhkFLhglX+OblTAm4WMUsCl'
    'wR6KEa2030gGG8Et/STEqPGP8AqfAatm4kC/2Vv6cS2Q2pkkitBiojqniF0CgItNoQag9d9QLI+y2xGt36dA7kRnFV8qxOZiYh52'
    'JBdn8mHEsE0fQbjMxbFp0RccT+ugCElvypdCiav7ud+c69NB1tw0CW84q2GZu5iYxEaY8ZyBa4SoznaBUT9qYgCZmLwpgvek44YP'
    'OfoQYUuRMkEj13y1WUV8FfZxZmbHMcRC4Zps9qi1Jht+dGhRq3qkUpq06GSfj0jpZHTEETCLPTbITPaRFtG9B9YmheNzo0YGgVwJ'
    'ZdgZF3cH8Ch5MFwLP//sOzhc+t73OBoACslVaZ4u05x7cBKuT+EAYZPtIWxhEvfQ3Z0V4V4rVCqThJ3NcNsE7j9fNtQdkxMDlC8I'
    '16c7be1hp1ccPN6okH9V4UAVmGY/dGglRcwZv4Y3zzgWxbVCdQzQGlIQ/PHL14bv5QErzp9o0S++4bfZ7ptAf91vMMRfvuLdwG9/'
    'vI+ap4Z4vBrJcE8zBQQd/w2CRiaLb8gs9BuWpb1rJHHt6Q3eqfl8grLRAsIQQ2TbuSVGCPwxfuaORp+Ez1+gA6zUQ/URfw3V0QEJ'
    'xxhtZXF6zBrsmInJTClqF9txhwOX636hk6gNjn1CDkNHrEKLylefhkCATtYx37nwmpEWUi7v2OUtbUFa5p8ibiahWhpn+ob7BrX7'
    'fPFFSEWMZL4fCPcBAT6BuojM0vc2+U1w8evira8L/jW0Ps4lRJ7Q1q+/ni9GyZ8Q1y9jixpSc6yTOC39Gyy6P/dgXLKq6bFgCh4e'
    'Vvh/CEgwz0byjaOAoJQj/VKDHRs4awL2Li/YOzwZGX9Rw/bQ3ZS393PQXjwcD44CBiDm03HOAnRwbYDHpdsEMjDkwUUkFrvJ5bcV'
    'SZxClSwCXWxtuh7nvNiFIBd5Q0nn4EvuJYgiiWqzjtAkyC5xcJYJ2BJN5zylHyeKqXypDy3i1fAMOCbq7MkFhpAmP8MEgW4cFj8A'
    'aFg6EIUvQ8vDFXsDC+rvaZwEGTg8VwKemDh9vg6h96TpN9f61Vvfu+vUJaGDW0lz7oBctHFjXxlCvPYrXwoKoRfYdTpCaGAnHusD'
    'ThIGyYZ+JXTgg2PSFchYBwVIQDa/0Rcq/hsHEzZ+esV5Q6pEfljn0BFCLiAIphpgTZOUaQM7j3Xj8Xg84pXUk+Yu9xL+m4fPGtts'
    '7kDlah6DCnRZRicIzUO7OOMt2Q0vf+eTgY7zILiypEcu8gecOINCdnXHW6COxd5IjsfBlWkhyPsOeMapNp8HscNcAa918lc4zhCG'
    'aNQf6A9XtDA3X/YqtPwjcfRCPgYXTRQv38C26WQxR0cXtwrJnqScYiSPI2Ux/5poFYA3+eWr9z2aJC8AqvAiPQ6RULTH/f49cpsL'
    '9/AV1r742wXsqucjbXjGgX2LB0oOmi4H8o+8h8BPDftlpj+66+rfgJ2iDfuPBIw4UvnqpPK3P/5sZH9W/9WQT9djSPgRxwdC+wY2'
    'K+Zu1peCzHQdGwyKIiMBSQfaMdw72FFWKehUjPscaXSb0sAVvY8Cy2PQ3SmuOd3bQp6o4iXWqBKlOakDB1F+s2Y6mc/Ho7gnWo3s'
    'BELig99ogsbznhODP8f/bLVC4oLiwgkdIjaXkSGxAJAhqMhRv9lMPLyAc9LEOeI7pYk7xo1koPbi5MOCPmTzJ+7Zq++g9cXBMr0Y'
    'oimGx59JWtrx8xY7LIJ3hC5DBoWNdwXgLZIe+9XYVm8ObBUPzTBRL/OrGNHlk92Inyle6SpYg9/Khj+A15Ef2DEMj5wB/l3Px+To'
    'DR8PzOM78UOOg5E0b3H9+hNjzgls+FYR3iJIfKT/jv0eXo+eFvQb1/xWAcEqBwqVRfwnC3QCTLGl7fHWJJ1k5orqW8Qx8NYpykbE'
    'Fk/CghogoqOhjrEK/v2LiDYkYHE9ugpNrG2E1eeuDF9QuvECk/QrZOIjOOH3D9TEmdXKkhzJ52eSrgX0KHbxd+ZZGRh1uEuu72UX'
    'qU1LAbWxFV47JSRS8YhTcyDjUyuf2J8EssvwX6p/TX+insw4IRg4OYawvr33obEp8DD1WZGIH0bE4Vjw60Zb5yYP4poC1M60F9Qp'
    '1Y/cfuIXM2mcaKjwHXvDLb1mdkkgtsFlW9+nJNrLlW8Pi4xCe913SF61OKryrq7CWieTPCn4Xoh4TfMvWrAM3yLO3q8X6lt4NNFt'
    'JVCUq67sB6hxQ6+Iz7/+/vHdF/SKkDmdvfj1AiTIX6W19R493X6nX7pHPz7Sjzn78Y5+YKDi9xfCt8/yl3igEHbmqJChezcfA5kI'
    'LzgCXLlqzfDQNZPPC70CARcHprLPW+EjLGPhUqCHkvCrkMnn8Rc9fCG/mMgt0D22dYnsgUexLaJHCo0TMBYsAb1M+S9eDs4Zij2B'
    'jppRKemz9oW0TPj3SsCfpGuKWij+wFZ++TqLpePfLvGvyP9m4t/if3DkcgM8Gl5WR/5IBzALQhag2MFcQUgRAcRorm1PXUQAelR9'
    'hqpDUimiggKDw6l6BJuwF3zy4QXYz9Ah7Ob0S2TqxEdtcaJbxH/5fITgr/dR4scro6OmEbzXjMh78jCESgkoEWdYWkH2b42WnLXh'
    'S4oLJiS7EmkDFfRCVZBeiYEtCAQV5MB1YkxOOAJFiVN9HBpQXAd1hrE5c6dKCfj1X0gJw7/P8TsqBR32mVj7ayHmoGkpeJWLqMIy'
    'eBBgZL+x8aSTmTxtMcwOP+m4/8Dk5uGbfqZoxDP0xiQyfBYgg8OCsOtmv50VBEr7L0TNM3F6oBqw0Ngj/pJ9wsq9wh1gvufw/6mI'
    'e/n5s3yJkWrSQB8+w1+ZP6bpcc8f8QMvkOaPMj3uv3z5HGMS+0w3TSe2oFVEjrFAT18i8M046egAQgiKHJUAOsTLE7Zzi8BBi4Gg'
    'lvRMfv8cTnkS+NsuXmuNwTJdpIEsJTHCc+ziwrfGVpg9jaIwonzOHT3IzL82TcC8FK6E7KWBI8glt8MqAreoft9YnUQBjF3RpKOm'
    'qBapCOheJ4/GoGgYnV1WfTcvABXW/vWpKQClKN+pa+MxLxOXWwB4NGjsaRZE6j47zagIoBqwIAs1qJRkcc4vA/shi+dBIqVElTXD'
    'i7igSWuakL8uJBxScAp+iWItecAIMRdAer9WVS9JRo8mSK0aiyqvMn8ZZAYouosffAkW0oXZq7E4c23yqzHXJuy0q9rM4TIwVtD2'
    'oIMxrOMBxGDN3qiCJDumGwQz5a3zFUdvOfRD3KynhqShWcY04xFrGfTZO1WMziL+SCf+Gf69QnwX3sWAD3zgn6kx0+IGDB/p/DxD'
    'pdUs6eCZhT9pduHf99/gdomoifoNyI9FuHdm/p4l5T2q9g7s+RDnrRPzHuktHvcPQC8wIvkmOKY88mOscRuRgfuG195JbwSnA8N2'
    'UTQ/7tqOAYzgAC020+TZQtLcQy+XnzX3cTONRbwC4n/iyBJ6GSygPd9pJuQM/e0Kap3q24OLn5yE8RdIxkI3Gc1YtYzXTMRb5C3o'
    'BhB5uQxoxwEEBHJmqQjPc3oWRdRYTJE/K5Dp4m9iQSyKU9KW/21G/y7ec+dAHmQ4CHBnMSXOGg6mHIsLkiJZnhvgJh8DxFiQI8m5'
    'mup4ifmdA9jqnf+VBUZisXA1g2LhCmtTUQOn2t7jw/ODH92EyqHZajqPjA85CQvj60XewDLh74ySFbOlC4otRr/zhaw6vWAxv/CF'
    'MlWLVAG3DCNfJcUMu2OAXwvTYqaU5ncV5GvGC8oYmAEvO8XwCR3ASOGAHBe8SBZLsLLJdAnp42U4JHR1U1WL14rWoFJp+gfCM112'
    'wGUIpynmxLxYik5TnGUymWI4TTWn5tVyOM2CKpVmamSaopqVCmp0mrl8OE2pJM2m0vk0CTZDTIHAIc+UrJpG4PiTRSggPU+K/hpw'
    'oPqTNfBXCteAR1STLKuHEBZ1tfUfuLNtEq+vuoC4PVYQdRG4fnSfhT3AHAlyWJjGO6Z7dkgRG43Nh5SLURYMSCQ5gUvJzg95Bz/p'
    'M14Ooih7wR2BiG5XQNYLpjb/nqJ//obmJTaPmJZE5NOKcd88hggVDRnEVM6TGqpDMhlqiKk5aFqPgAOBYAoxDNsXJyy48UiDHpmf'
    'JHsojfNpXrLboRhokOv+Ka4fU+SEUb+x9Zihzpmn1geumI9zckwSPRoS1L2E3lYBQYUREGWDIkfVibq98e7vNfSKJ+bsECVh6EuF'
    'Uf6YEwPAzD56fwCpB7t3jxeFwvcHen8ItJrzt5VTvltchCJB+yks7+uRoF367euQohpCthc73IdF/JQxdc51/HNoyyYvcebN5Wut'
    'AFXbOHSF+Xv5RgnnnJCy0QV01EbmNR4hrPYBX4TKTRjaSWH7ECfl5xU2zdwaN1NNFm7/5/931OAE8OiSkit8ppAql6R6cEwd/Uv9'
    'RwA54AO/+IAedT3wz3CMAjVKyT3Jh0TeJfRuo8N/wC8H9uVAXw70hbS5oZuperzxYu1AYgvFVDI/tz8jT9/+LH65JHFkGn4Q6UOG'
    'f5DDDxn6kKUPkZWlr/QffwqX7N2UBAb86cVP7M+k7rlVj/+9wwvdgM4Gp/qvwgGu/VfoUXY2v8+f2WigAfi6RklnTaVk1t+XL6Hq'
    'w91MYV64nTg11FkzLB7M+GTq6TibIHGAiLI8ZNI8xrL5j+ivAv0zPzRZMoxQaOEOaVtffECGiB7MnYQx+T1yer3k+GPmM3v87vlH'
    'VAjEKDuNo84AeyhRjzRCNChLwUBn7DYs3oINxX/MBsA7DBSDvvpKpCtRH4Rcid+FilrugmEmMHgGcqXwAyFYg2lDjUC5PItFgDhO'
    '4w21g6RdNFHRA+PASKWk6vPvbPqDWTFxYYULDGNZ0Vh8fQTdao5BIwmozlDPeb9rcgNkPVMX8IKr8qlz+ukrFTm8LLRojAS+TN6Z'
    'wswzA+UN8gxISBw5iIeIqYeYHIjpFMwdhs0FAkEyFlDMP+DVH8L//D9YmFmmJYy52tzA8D4r7ntFBCWCD8wdxcfl5wB+njjLIVIN'
    'EA0nBAF6wfMcKGl8DI+F4tx13qRLatyHdm7EqPXfzpAokhT+QcfQzLlMOqod8sPTxhjamyK+YwZaoh44gt+wI0KAMYYBp4j6GK4n'
    'khMUYg5T/gGWLgMUAECcgYLZCI6KvJp+8UUjCqZIjp3Ezzgyo+QYmymQg0hcdzYGht9daNxNe6buUL6OZlsKq7oU4sK30v/EIweH'
    't+BIVaoIsT/wKpfxx7XvqB0c9zXwCEM8sb63ALIKqs1c9qht9JNmsR+xaWI0/FHIOkaj8My5SpfsSGR2AynOj3vKddU0QbpQJgl4'
    'hU7nqMZPjsG8/ABgPdUhF2I0jEuBQiMCeRR5GWM7x6xLwffsJCPKiqDq85dzEkBwYCEcHvDvAYMUT/33Bn+Pkm7ELQ5VMPopjEbg'
    'OUIpfxeymTTnG0Fcy/l6xClumx9T2JXR4fdDEJX3zPQxZSZ41INhE5fCFfuTTmbpOYuPeXrM42OJHktfThEhBgh+41iGV2IWzDqT'
    'viRpz3cCOsO1GXb9NJs+QbV+H6gvCbAZItisGD/BktwiRDFIaWPCFl5xj6avxgiNKMHJtmmxTTy1v0c4M5E8JSKlDlTqwEotTkpF'
    'mVigWjZunM2Klti9Ls/Fuz1n0UL8vwCELGOSy1LJhBctEDZ1yWJeErCUgC4xzxkji4Y5NeHouSpPiHB9EsuF3ZtLnqwpu/XyQAFN'
    'omO2TsdcQOR4xpiffI/arX4OG4WVoKPBvK69QBWK6+fRKttslcXcydp6tLa8cRG9SxFqYMEi1Cj0GSPYIvfTNGwAwddvQi7ts77Y'
    '4CnWvmJHjPmsEvcJh+B3cuVLJ9MUNTMSF8SFT3SIcOP80+S+909ZO7QCcySNH0I+iiL+3T9UbvqNHgtpj/exUYAnd9trIYjYxMNr'
    '+xENyWB5HUQrRMzBZPKwZhAa8c+qhteiKRbgPyo3d71Wh40G8P01eRhc8nB1FJabIiNiVO9CWHdjUAx3LkRGFExn2Ip9R3r6PjR4'
    'A74jukYYj8ggRrtlyqOWwRM0MndyBupkWebPAG8giXQHVR7QD0Mk4DKyWrHuFeMdAQuENIBroPyohdgP97aM0wUGciT6A5f0D/xw'
    '6acQjIVN4C0Sg9gZHnOfX2I6IYlAxx5YDkgQaoHsGQaTivktJ8/nf0jFjPH4mYJ5QVQnUDySpx3pkE+SLZIygUUdpFj8pIZ2qSCR'
    'Kl8lwVMo+UtCgjeeeV6fNJ6awxz7kNDyS7Khs1VI3w8wvCi7hToOihDDaB7TDXDlIzq0XmKYajdK+L6yhQzi2LPN8QkSw83car/R'
    'wmILgq4LpqliqRLCUPiqfsfDz3yg/kJyiVp1HAec5ihwfyYzMJ0ElHg8huToJY+VSbK/oVxQ7J6z9xQ9FKuR4eWNiizO6Hervv9P'
    'cAFIDtsRL8NVnOgrW0Xo8G0uhDAWsfNkDoz6Fr8V0IW1GeUnp2g6jfCT7FWUn4y0HyLUUKT/GFG4hFxKRErZk3LghCd+HwyD1mK9'
    'D5QC305fTfmqfWHolgYSNHxgDUf56LOGJb7I67Dh6ckrv2Eu2MGxuWG7vsIl9+EAHol9wNtBXz690uFdUsXbk4oId34143vVmNsx'
    'VfokZNF1POJdlqZ4hDigTyeyrI0o+LtU+wobJTOmGD/1XAbR/AMf6J80aLzRoHjJbp2IgYcgE++RgALxDJRoFxeRzCU+dvHMDRom'
    '/YAqmKcAsAuH+Tukq6R1iKgcohFJyWWygB4z5BcGrOhC0lFcyybzwVuR+zK3Ud5g6BuOJlWOeZpF94rQglaPR1QPmLUDcbGKRj/y'
    'SDUI29K9VgwPQ4QJBQlq7YpJqqwjir7K7ZTQAVJRL9RngDgc3lvld5rImAdF0UKLhIwIADvezG5KQfOENawV68L12NWkwOuGxoeJ'
    'rpjOViemz7dhsjHSDQggMCuQ4pTQsZXNGY5Lnbl/mIyQR5UamhVw2nWmU7KjLwKIgWcnYOkY5XcIG0ALCDUO4QD8QdCDW+D3ydkr'
    'DirIV8SoEuMIKbgr/1n/DEv7m5D9gi1SW4wz9MscTsowDW9ElvJ11x9o8ynDCk34M/0iPOD3BJ+S6ABJoMJ+omM9ghjhCb+34AOW'
    'S4TVEBR5NKrvt5v4i+1enbX7hUO1f++aAIDxAmFibCQ2LjAgyLkY6pkffXgMELy8DQDtOfUXYiQQs540P9kPi8iECsoFT3mgcXYF'
    'JWwLtTOK77Du6kEKhKA7Oh+Ro4YjJ3f/n3jQQp25aWOPUZ2Cb9gP9xI/tiiGEHy6ZCm33wBgR8Uyd58xLjRCxZmkiXI906XRE+r2'
    '/OfEB/Qzee21Rx8juPKO48oI5DOhEbrm+JL/IMjH6pHhXuNjVGLiQMp1dXfszNGK0Q92YpLkAxB7haNpKUIs/RET8YQ30r2oyMTf'
    '8d6DwOREo+JR9HvHPGHYeiMVIKQfDysQNTyv4pf3qc7lyV0mAHPGgt0xxbZm+azVHemkAd7Z92DiIjNpwAe/ZPAp7bfNbjRbIWQt'
    'N2QHJ9sWsdMBIHL+m8UL92Viy1ypFPh/M1/4GDz5Z+vyp2DA5hpCAv8doEF2HyD/V9f1r/RHNU96ZG9e9/nG3uCy//H8y1fcieQe'
    '3fLo6fBNuMNHMXgp0kt8ygTvMsG7bPAOUXH0hgIKqoFnJotwz0yxJL/C0foDqS/sxRW+wnvohw/vfvmKFD2bzGDr+JhJ5r69+0O4'
    'ft0OSwzwnXZIpj9r4SLKoSOEPDLuIqAS/lWBP363UMmifHgH60MoHWdIOPub0OCvfkw9ggo/Jh7fby7x15o7pRnfJu/I/QnXUf72'
    'jq/L6a8rEo8+vBODF7iy6Fz24R1Juu9SH6O7SEEMbbYssubIqEndY5MAhtCofGDPB3h2/P0TkxnyJil9i4wHRblv1HgkwwKaDpgc'
    'q2KIWLzu4YaCr+R5EgYJCT0Sd29BVAAJO353AD2reS/wkeVwYL4iPkMFRBM1MFyy5X5gGNmf0T+gr5p/S4hzqszrPJBSP0Wg5Jev'
    'SjBR1MZEF94XYl+tP65UQih/O9kGWbL8XQCJV5I1D5Y3mcVVCwAYBwJE6691L3+nb3f33Y6hOThH3zgU8N6YTPMpPDcxht98HM61'
    'A3F2UFGigYXnZeLnQ/clq7Pmuszm7OP+7zbJEabfKGLRjRb/96wL5VfiuWxfLU14qSt3KexIvRuHdn75utC8b0wN9+EdcO6u6VyT'
    'gUN1/CNz6k4emMdYOlvmZsnJlAS8ia4E4dACSA+cH/lXnleWJATT8CgQpxa9K8GjJAEJZnE3Xoc2IhsgC4FMsUv8uEZ8sMwESOlK'
    'MeWHG9Wfcc0bOmKxtKuyaTqKZmDWyaSw0T6wi/YRt2wMLexnnuSO3NFgO+QfudEuBe6bE/jzRFVJmNGTeXl9pmJfGDYKAsBFN92P'
    '8oTvgkSQkZwZKAXwJXo7JpzhxiNyOtpEg9vlVDzixBm4XUf1LFgg/marPwiFxqKKMe++E6eq78dICx0SSQI7iRkWKTrjRdF/k0UH'
    '+/QJdU4yCCcOsgry4ZqFinLS16+tTU5obXIwe4XgiDydJbHT6IYZcYLH35fCK1dOaiQISnVySZQ8ctELkoGMgXF4yO+P9K7IqAU+'
    'w7577HumtJUoaMElZ/pQeH6H/mbsfEfvDEQjdWAbYSRxEgRUurgZZQWYlzCwAZhv1zR8peUrEYOIyAdeJPTS5L5x3Emul8RRkQeb'
    'eZIBIPDMDYPI+Q4oGLWgl5SDnB/xH+39qw2+pIikFOUAf3/75y9feUP4iKNgTBk31NCSYCD1L+dCD6GI8DM2iR398pW7LicSfkNs'
    'KV3gwd3I7ag3/RY+CAXut8CKE4J2WfjPGRwiRLgx8iJOnLr54mU7IYU+9ymCOyJXpnVFM8NawbKdO8eyavH4Nx8r4z/ad+ocwUrS'
    'q6HzNTamIaXwIa5vACB+eIfhV7uYBLxl9F0gHozrQT/lgO1BR2Wf72GD/AikFSf67ffUaUf+UE6ksj82jh77G1thtup0LUYIdcKq'
    'MlddriEnQ5+/3j/GODxMmRF/G6EoJw51SeUEg8CeN9ilqpkpb9yexKJQBNeiw2je/vd4tEDUPfqNopwtW8ARpmPMLJ1Ql4bApgv7'
    'FAuG8Um4+H0eYYbE0ruPLHYHOroFhopIt6QgZ7cto3a4JFpKKLIWy9uAGmAfH11G4qcWgjgtGIQH1Yx+rnXS8iD1Ak7gWvgD/Uyv'
    'cMS4/biSKGZ8ixMkR0efmvsDPo16H3oQ0G6fp4A+z9XMlUEMGeLHkD/wuVI/pWQkxSVpX5GXptBNqJcJZGJ2K8Mw/FhP6PpAdxv4'
    'BfzYkHgJ2h1U1AR7hh2xLlSZQl7xaEvXfvfYZ7Cx88g4PQkTSENVVGxcREJrx8P7CggpMOONxi4IRmDwLNh2kHP7jfjbIVtEL8KA'
    'SWhmx0XVeVJu7q5KRIj59zKrGb/Rzm54aLOZSgScZTwIIxVjQLfgwoFPyTQejSqMpcbUzbSVzIkN2B5VouzvsBfsose7O4oYDIw/'
    'sYx0FwW5rBvfMx6do9gIMfw0hhmLxC6g1pm17I0IrfrrpCvIxPCcCWex2zGeH94hYzHkohSQERqep+JT0jMb5k517iSX81b8UjWU'
    'wp2jB+Acw6FBc+EPn8j42apOkjmEVfxrpK8yWZ2eJQITlpObAVAETn4w8bXKItuE4MIyZjAyzVoCXi36mZSP/se4j6d1/6CecBbM'
    'H4pZPafmnsX1YQF1jKgt/dTB+dSAHjEVUvgEPxUSy4J0EgPBdxQJ3HEtSTkNLZi+DL3amFFOYr4ul+Q+h6Y05vTs38ejWOnc3Bcp'
    'eBUWpFAMcdr9377X0YE6Wvj1mc1u8UZHzIAYKXgVFmQdnerEdT/mKJ0ZiZ9PzPnL7vusNYwIimCJ+OrC9Z3MwvB8/mUUijdnmV6o'
    'tWYdMfnt1KWGfMUM5hBAPV4GCnnuP3Dg7gLMUO+Py9U8HocOb7ZyDd9PnB4qHKVEKuIxXxOu0dARgynKmf8aDQtVFEEU2XhS+IP8'
    'GtAjIep3R+glmAyPCUaJjWEgshrkEQ+xIXN8CJELM+x//hK5GQorxYKVx3y3OgpjACQlwje/8kvDH3cmvYi6pn2HcwxdXl8p59Nk'
    '/Iut6H4oC152FfrkU7iGFYMa1ICmc1FzFh+wxwUpOmQ2P2Q2HTKMtPQtyur6MbnSb/ieUQBKMtgj8rMIt9CdOiSvUQcnK4zN+7vg'
    'O5hlz4r4QhMU8b3LsnHWv+8KFZq5aCEZkgkinoDkwawjMlTlCAFvJZuYhA5Vqzz8CaGjv1IrF+c12CL8JhROvKw8uhecj5/aNtDG'
    'Euw2hbkOdx6/Bp5UzmlQA14TtpJ5yUU9kdk86Q4/Vj41JzL/qxMz4NKcugHY/lViGERAYKdhboaBLUNHm8vXPjQRKimFKoeQnjDf'
    'jzM6EtJMiUjK9G1uPXCeAdLBQ8GaZBHyQ8FK5H7o/8LL5773Teg20qTQwM0Yfj1xYY2/4ZSZ5g7wgVcm8+jjax85ROSSidYMvmiS'
    'x3AXGqE9Fa+UhMY9uoapBumqGK/Lk4jg84nYi+F0Q16DIrOFnIOfKeuEAflyknGLLlZwDcsnAcXEIL/VNWucvcVHfNWj/T+RkTQK'
    'qRUwFjAEiSVQIq4Afk7Dn+T5FntLXsJ1/3ORafpmmQiAwGjioXR0JhHlQSJ6fyo/ReSicN/fkIlw1q+SgpHbIaCETDIfyj3MD5GS'
    'MPmu1D4cnYlEWJIkdCYSha5d15ypDxl33CRNCV29cCOQy//2g6mjOPUDmC34MAs9+HGqYH6vwLaAdkY2KRxD0CWiDb+eHkwVlwMh'
    '4ttJyLPQ9Y7Uk+ivyNS9Jhxpbku/Fk58CxFncNfFePI/K8efBSm//A84nkW9uf/UgQxjUEostQ5dLb4W/rpPGAekT6F/1plb2Csv'
    'sLe+By5h0PcrR6/zaxXnXl9vfJ9++Svo7y1QagfYzwcjkje+vZVq4k1Iwt1GYPP3m19pD1hF14/RwM4oMY08ah4K5CzhR8A2EsPI'
    'L3JgJT+QHvcoDPHozzF2COnFg6J5wTF8FbyIVKV0/RkNuWLep/FvxKl7HabuND0qthSEdeKjuRTEIq6etztL/ReGHf1xZKd4/LSj'
    '0yhe3o4ioBdY3MzXgbMSQondnOPM7CknSwvCIpSsCbS59HOgFwjUC/+2p0/RmLLms5708zCiJ6PvcPgGY8lERlJKzoU3MOd3bE2/'
    'fEXw+SRcnJIAHs/24+/oeCaQrhIVlaSnRCVlaHaEHwsVzzP+WqD+ch/avUBe4+IXM3v55ttecjo/sSi/jcqJrLLkZ7r8ht3xu7Xw'
    '+rKYzJDSNrii4cc7Q1CIeX7A+D9+p+iPNOh1MpwkBq/BKri/MY2FNsApYOkrtCqg4phJhO8A18FUJcO7Qjdi7AXWGV22Jf0dRSq7'
    'mklrTaeGCab5W4wqSdpe13+z40sJ5yBcLZz7x1++qq4MwPrt9xQO4eMfYQwXjAMWIWTfQidb/6QiP/GDg/omvJ2TOZw/6QzSpDFI'
    'h2k3A3LKgBBfA3N5pggijcSUaYjRExR/SuznaSBEX+/kP7rfN7VF1Unn17r3FKkkcjWanTYjGbkWza7MIucWhtSIXDli4a4Z0FEU'
    'LV+96+4oNkLIVcx5Hmyib3QZA1l/HsXbr/c+bIpds3jPPBCQLpBMTME3YnLcl2KCbYw2TyG+X7eOV8aZkYg1Ok/Cn09nN/8zTP0c'
    '9zvsJTFgAoVUyOVPuw3a7yUpLsRZs2Ky4DcCryj4+GljxAXjGkXSY///xL3JdtxY0ia411NATP3pgOh0DhpS4RTFozGl+jW1yMjI'
    'LIoZhLuDJII+hQMukkGxTq7q9KIXfer06e5F96YWtejHyidp+8zsTgCcpCIi/8o4STmAOw92zeyafVaHLPD60fKu0VsNQ2UqcyMh'
    'GOdcMz52/RbcS/yKZekDrWKXQcjk2owjjdhe4qvPwszO6g73/nfuylO+6hP/T3YNLpguU9dmKavvkhpUg8EKsBzMwWN9pXdCY+ZT'
    'Bu5eaMx8xuDc0lZd0Hg+l+djfTYU4zAgrkWTucgl/eF2Xjoa2cWNliP4phmWIA4C0k/NCIg/NcM2cXb2G1oTXCCJ6cKW3HBr1Dea'
    'zDAUxeYtCeaFOy3/CJT7OLlNMdH8EJAVjbrxdVTlcHxkD0fvJtSeRN7Scq3xx3QleuiGVB78EQWTwQCq2vFtOJjBnaw61FclrBzB'
    'M8wkcS6xySYQwgvNfPjMrc3SxlKDZdzD6L67GJWIKdwaGoyjBuTYC+ee+LQWxU/tzYf5SeaY06JMBSm8z178nnOxM+71NiWDGCvp'
    '2DLEg0lE7yjq6icQ8ABwGfR83VM7mZnTPR6vw+JxzcQ/KAouoB0siwfEM+EgNlketIEgfkUGWkaJr5ESAukhrzeNX7Vh1KZ7iu8D'
    'bEh13qO3B64mnk/G5SHxWatsKMd1z46RJzYboP3wjt8/Y3M9ZHNzyi7j5ejob9VBPXjcJ3L3kR1PaXviwWxRn93MLeXJK1Qnr5Kd'
    '3NCdhxx90xQfsH4Hj/MR0M4kXidXOKIRnoGt/FX1oZYVGIdtLfG9u9ePZAlIB0VGbNPTYko9+oTgUltLZ+/ywd/o/xFDcLp947uj'
    'nq95w1eCQtCqCMQNxYuht57MYNLYgEhDGxCpNvyO3x17/C70sLmW+y9ic486dUaX3zL5P/Kiamg+kVjktaG69lShM9+yxUPHFuuQ'
    'Jj5zVgW7theqEH0ZNN5Tz/f9VS3Q1p5o5gcypm+gTFq+B3c7UwQ/JlNEv47E6VOvXgX8gO+COWARjPvp2PGwBW1QPxXAKz7oVI4C'
    'f3dg9mgY5T15s8/gao8ePsq+e9hiSd+mBRyfOfZAZ+S1c2L3zs87F7b8AzlLqRoMO4ZbPiULhcqDuvTYtyvNLu706G88xgYg2t91'
    'XEN13yGhxwR5+Tyz4IDXoM47ETIQOh3vwWmEM6YzIBQZhXK4DdM/Y3hrtE1rrnXpX7Z3ymukRJUeJrQXzLawUyjQovrYlR8srNl9'
    'A/nxwK0EdHTL9HTZhx/lhngA9lVo5GZGXw40n45VD5P5eUj4+B9za7VRP0RYRXW2bjhmXkh2Uvj1HHT8bMPx1H6KDZviKrN2jDuk'
    'G7hf0tn8WIx4IEMtNHiuUHVYwqYDIKeMBYA4ZHnipeUHSza6MUIdk+CSRsUI96hL//xf/9uSweq0tuKTaWYCXnaiZ4BmLSdHR4YT'
    'Ujs/0DDp8ikNzf02DD22onM3lI5Xq06EaAxo4paxZmIT/p15Wv8MojIhEa6zloRvUKw+7E/16VKGXJrqMeXNBMSnHD02EAj2Ww/n'
    '4vq6TzB6PrHY2BAqsb6+yIOhkRZsVNRF/s7vnbnK/yVbfH2jsrn/1LC5ZWvzaDdsXE/xU5dH6kJT0sAbfOs0lTkx6U+e67LWZUkt'
    '49ehh0fPSbQ9tXNcX/NVgqxnuM7PpPOwNkkeJeC1ch9UXGlAz9GAHvaDftuw366qbGPxHvdH/QohkIXLbJAzZoQv/bDCEpZXMK/v'
    'TcpyMloZZodl0uUgo8IK5KXY+vtgEXztQ7xmnw02NFb62LP1aBKLjg05IGHh2BACCIMr0b2FW5UvXuEcsXAZsNHJcZq7hfACba+1'
    'GW/U8iUbmcURzmGwUo7dSjm+4UppFlmbVsu8MELAH3Luo/L/x4FoflyRzbE7DXXhnfotgnPn/kK3nIVOU40L7Dgt3iMAEl/hBbK0'
    'CYAEESfv46pHuU9ZWjNxEGdtVjcIHI0g7xxUKYo1Szqdtt0Ko6njA0fwtoJVNQ4PGVpb45uuLa7xxuTlAxrAWZoXjzsrxpjER5Yt'
    '42NizZvFh94sfidnxL3fToL2VgBvtd6G/zhfLkAZaG4XfD6FqZOlTWOrUlMmhREuc2ssDDuk+4klVy751a17cAVn4u4MvOYHdweB'
    'esB98cCJYrZ+h94SP+g4wj90GvHTgbWl1ksBLouj4Fq/HVpgw/O/5Nlp7Pvp8PUf64Bh9xHfufhCKcRXkn+dXyYSv8t8OlHrdvYl'
    'wk3z07Kc5b05ZRZdMolqo5bAW9+JW38QQ6TzVnJ1WipxOilytBTXJJNZHOJ1zjJY62jTpe58TNvq9e47RI0UpyQYNnBRXl/xWJyP'
    '+7uTybCXztwL3tIf07HxPGLPCrQY8/cuG8+pycIhJpz+rb6W1OXsHDfCExoaRGYmAoD+vSmzUbyz++HTy3b0n3Y+vO8UHAwgPzyH'
    'eVJiIhYyRL2EtL/NEbF/SGdjZgkj7zGS2KibRAzSooxb1AN4MzKhn5eTAsF5DL2ZTU4LIvz//Mf/EYHS7qQSfZ2xAgGHkR4iLCnw'
    'pDgy8t1oxf6P2GBUeu6/urvqoXBORqO8jOXOYJwXx0/H+YgGAfZTkx3oCeVavbm/fEDbhC5ozYO1xCugOM4Py5ixzfWV2s/Dd+1F'
    'PivP4zCiNEw9aaDin4rJuN4yXCp8pAVDTRHCjesZc10pVuSwk8BvBs4iTlCazxFbpFBte8Vc/bYYpyfCbnDkBSodPtdwwQtaa1Zs'
    '0G50mYeyyDIiCHhsaU23q8NknIu8UblqpM2QeNMymcZJddy0fq7RlVut8UZza2r0mmdrrKwxZcZwqM1S8VQIlxsfp0vH8x7IKHE/'
    'hfVuUMv8rprYu2AXHCfCBbtQ8Eii13rGwj1NtofN0ypQEUPWr/I9lsWzB1N4zmomaI2AltGOss5RR6INzHuMSjadZCM1G4T7cQGg'
    '0ZGEUVfVLIILYFnhELJ2Pws9BTel2+PMBjqwYQw8/4TQNSFKEWdHbEpS0Uqp14OKtvh9qEZK7KgA3hUVSUaShuc0bQbwH1HhoBJD'
    'lYwj6mMqmJqLDCGyymx47vmBwm2CFWCIEI/LN77B8c+WImfjTXafyAYSSF5tHzWQu1o7al6WlZoCWsA6J2VTUxS5hz+eSOwHczGO'
    'CHHMGbatw0FOs3YGm0167YwIYW+8DMVug2eCBE0DODpPSMu4NdKshDPCUTK5k21Zo4KRJOtEkOFkagz0+qasQJTK6/FwPmO2HTHQ'
    'LbxrPrMTTsua94S+9jaFD3Eqb16RBBNTwW8GDiY5N1bPnhaVL3fMzEh632btpNmx9SKoBvOX1EObudhBZjby5eVm34+q+ybcF+FR'
    '4TX0CA09gc+w+ECLZrmpcX7TjqRpeqduM0T9Tb251wSXxpTnpJ5EusdcGK+FT5lOiBAiO6l2OYifkEINml1VnyJlYuQE4FpblgGx'
    'QqscaGCFYrXTkFO4Mo0mfm9sd5ZQnSQcjtJ0xR5KPm8F9Rhs0Bj/kVjoo7FgZRpUXN1b1gVbfG7G7pqDrRw5l7vIHYuNi+ZlH/PN'
    'hXYjoJChz3YImu+HCIgeC6w/blTXDPRyBYfUhA2QtLh9vffIJmVV3KUNwZQz5DAfJOw7gtFNmSb3j/OhBAjsRulpei7qganGQhKb'
    'ibZhwRAZWeJQC5CYGuBPJcqE0AQ/oBks4d8TgzptGHCNYQdBj1f+tFMlnberw82LVWKfnTi41jIdb9AnDMcUxmsnrLKd0ihapydG'
    'YNyKVjjDxzdym1hMZ5mLc/vxjeWP9UybJnUroPfUzMCZXUv2WjJVKyBqyVSVxwhoU61N1NxqDH2mFusobNmkqDhhTu1qmlZX09Sz'
    'cirKjJ2dAWXvwUoh6jTxg+KtAkQpyGAPEkkutdP5tjKo7r3ZGnuNmBGBVezGPVwNr+HPIwQZ/tMa27iu/4kegm/7yUL3GrRwpcGz'
    'Ri3aMyaI3LaqCnkA4xckuBu52USXbjWAJQ9SYE7J0FcNk30vCB34QRp+AqUUh++pQ1p+sGbddyx4b39SwHqe5/SRpj82bj1h0gJ+'
    'Zpr0QVgdtsKUbxNm1kGICxbzsilfYNhPUlDozdJA4pJF/WbYOVp5lfDjVGqn06H32GUZu1mOj17kh4cwt8uSxMZ2oQXqx8LDUKNP'
    'zvhW4ImfYLKJIGUr37F7TRHgE19wCBV2D6zoo9hzpuY04wepFeNxXDtgvakJ+TKwle/6FEX7dxmcBnBWew7KJ3xdWjrDqotLnz6J'
    '4fpUTxZxnLI3LejQIKPVnUXe281rRHc6j+Uud2CCyFUxVuZjPBdyO+thHsDsHRzpm8HychuqBOCSMO6no7TcTk44oaWwZywu0Uvo'
    '9LvsoI+hmxTG8p5+gVgxWaPH3GDkdIXVl20fcMJYBFMDY8AcQZcTfMBPTsCuGjKkzHyIKJkPPDYWD96U0HAEMyKzcGN+wRum2uQm'
    'jYAo0C/s5giucOHJseZt7CbqiHEDQzBkDtw+nAD7Zzjpn7CHpsgeFrFTfIjQ+JhHX/Q2YY93iNkAeFogUfCS689nsRxgdmCUCheY'
    'jgJiRZf+safRpZOzrCjYNZ694i0elTmCHxBbjoV3CuU+urvCr3PBEvUcTgXgZ6ah5zy2vxP04R3VFv+q2YIU2etNzmJaLrUF7nkL'
    'M8vp2VRBH0rLSxUTTKlGbH/fkaTb2/STObNlQYK9wX5wXsVEUB4KQfE0H94GkSOMhnBAmZGkZfeLZdR1V9TX/q9ZhY2riCcbDN3K'
    '4XCSst7BRju2rrbEpLnFILoDzDUSD7P0i/jrCogZ8Fqn8zLEbKLZfYUL2m/ejcxHcS7ZQtb8pBQNJa1cYq+l5mw0Lc8FGd/zhFaY'
    'zaJP9Y8rIpc43RRfSOQZArLkB46eLUFMRLULPlg0ueJP49K+Zh29n/jcJTaCEse47VccbiQwBP3zGCcO29HZEzdldMMUiIZIsQzY'
    'zkSK4cb25VjnxvTFd9bELbdOWjuiEkoNzhxfEOc15Y5FbzDGjBNEG8EVhiirgDaXl/rVKoo6i0+SG24Q6eI5/1i0G7AeG3eDIrCq'
    'wUZtV1xBJGfZiKSMHbVQCMRKOXqdXGm0n7cNblEAiqS95qvHPU267wwWhtsdjGGiiuiDXVxk8c2iRHHiFby3d+dCxvN9OoLLInvH'
    'Jpf7+2ai5L6LFu9SLSW71yaXSwZqX8plANr5eJgVBe9B6S87TR1Yo3DdWIbZaOhHTfXraImqOwNhohCEQF/rK0pfu3mLxMsoHn5M'
    '6At2CDWkV5krdgJwsK6iyn9qwdnGWQZkf8Rg04PRW9ALzoYjBbii42wnK62pSMF0vSKk5CzAIkfiD5Fd0JXke1hpw33PuxqWFHnF'
    'vZqVMFQkQ9MZsA0Y67h3mPv6nGiFsr7NAR3oJXzyHsRry5TF6l+hPamvcn+B1FaGr/KprYnKivC5jio1t9NPMqNXpg+7369r0oqg'
    'ek9ZUxjVlKCUa6g0VkJ2PXi1jD3bNaOpa8Y6qhmXASTUqs6HI2WKVtGiT0NZVVVb5sz197Np6ekqA0WlCcLk6Su1LYWv8tL2SGt4'
    '5gTAMBimql4yVPc1q4Rt0Se2q95ywcViWsaH4xsdzldOcnSIqd28fonOMlnPQq3Z48XnXccGvFFCq76PNUmbY0czbjBvY5WnHN6g'
    'lsVnkWyocQeHioVgdVciYfhvvgebcpzwunGIWVdTKJYZcq9gdASu2rCVTnCRNqCtBr3lqa4MLY8B/uzKlLhecpMR86fKdQ6GUbVi'
    'snJxQ27wmMx1iAF0vh03Xp+obRUvFXODlQRLToS0MhTSvK6QmGBuAzzEHxYerdjIKYtEI5aybCiaSA1RxzKi6BurtJfHdcAmyjTz'
    'SYetOwdnm/LEd/2D8029k12NPjHYHElIdNiV3eDq4EgA40+zwZHl/9R4Z0qTPJlhBVJeFb+Ug42hlLQxHNi9ne8bqIkj6D860UsX'
    'uEbclRmGGxFnszFfA2mod4GAQAJdlbkJHm9CJOSlItYwLy2R4G0p7OeM3NIBBGFnnG/9OomOSainBLwocM7TIuHrQlGiCqINW1xB'
    'HYd4Pli2Hp0peTt6JwNe1M9PGVpnJ+D2tLVNB7eryxc8Pwe61ohAY5DJCDwI6MGrHKzy83I2XF6jglYO6TjP2N97lv08J27TkNsR'
    'laNXeSJkqp0D3xvxMotiEkb0Gh7aYxOe2I/mo02f0rkGucNE2DEUJgBWrTptWs39lTCpGpOFmKwAbRORve2Wr1nSghNMc0acA3ue'
    'RsDZGJpFt8mT7tvZ8vApqJHSBVEOcLjQzq2aA5q7dVD9N987eG5piYPi4o61ZW/SdtxP6oKy3DDZM0g7sx3tQVFr7sNy3zcWRMvk'
    'c7DCcOvCUMKTFnLxPb6KWH/kx5MUk1KbGSO7Z9BcY67Lo1xWy0ilu28G24d21YlEcUW8FC5XVP4CtU9tlPOya3/qlL1Oh4ds6urH'
    'xDYTP9CJcLt4JJIwZu0QzC/nTNniUAG0TNKGyCRH7WiUBLHirKJ2lIjzjNEU1xW/JsVxGH9Z615cup/3tFayXzeugTbuu6JfPX1f'
    'uXPgwK/hFQ0fI+ka/Z+mfDb1cB6emi1wmI45LDe2M7HCY3ucGrsEoRtyLWjiokpATpZwPOc6e5KbSiSwR3QMrMGxhBMbByf+cYrj'
    'fXjOkgNu/U8n9hQWYEJQ+KNJKfFIvHPDHgIOV1a1aO9lLQEsB1Cu6Vr0BINVC1ubQv+frmvYpnRNgtFSDoysvFvXd8vunX9JfGLt'
    'A5QxYqD6k+Km6/5oai5+bFRIDjAP5e9a7e5EeMvatUkxTcfcHeksFotfE7W6hDITKBMpXA2RXKK2m8pP/KCURh8ym2J0OPDF0ZTX'
    'rn3Upzgc7+3oEVxJHziHyECzh7CqvBk0Py2ODf/Cw95RoIFtdxHB4c5tkbgB3GKaXr9NGdGphstC/V67UhnZUmRrCOcN5ZkOC+0Q'
    'myRlR0d66SwcK4AqAiC84PZalWPX2PzgVNS9p+ylsrARd4GRngP3cm/B0RdzK67L/8Q5yTQB9QjqJ4xE73pUwyyVQozAMN7e+i3N'
    '+i0b1u+mw0TT1rSDe1jAKHOdAuXReeBVHHxas/ehUGC/EwWEvZRRjgGc8TA9Y6WlMj/FZPgl+6A8Vo11YF3AGdS9a6wQCP1WvKDN'
    'cpqCK0ZqZorlFdji8/o+ZL7YE3c67JgZryfXM8rWGOPpTCIjB1RTvZj7LEoop2hiDWvIrpTVwEwUOSqYC0nsDKYYAoo5ZURcAnAB'
    'OBWzyhhCzr/dt04AhX/j4al1p53olbAzMQJdwsko8RrNtlkzwXBMe8xw45AgbpKPXxvZgqNgQoMpIZzYTIsI/3F2lh4x839MPTon'
    'dte3OfEWhCeLjgpnvGjWycjaVD3G5azTcOmFL6MxIFvACHU6HTOTI99KQVie25UQBsyqqZGPt4o80fioRtB9OxAfoX7kEOpHUFQv'
    '+0kYYJWO/MRwE5d84/HAi6YnbkQW44f3r+L88G/GqHLor4zMInmIzHV1PGJOm2icLxPuyqyBLdyROoTYtMkaQop0JhH6fJY4awc5'
    'N40deJxG/+aRfiLxSOo/V79vRgZ4WoITgyL4m8ZsEW9fSETUvhfAtLC40Cb4eC1mOC1iDXuH4N8ZLA9TiHxY1037jFe2gmBLSxDh'
    'aT5lBgn3chJlY2xAnoUVhDq444W2CXSheyOlwz7vj9wvx6xkWQgjjIXJKMJ77+Ma8COD71VwH5P9Kr0cgazRLvKo2a2KwYSumYRD'
    'r7IIaLAt7c4U1HbT5M7hMC3fwbkBQGm9fTlLJlNqRSoQxiPGWDGKV/nUS/gkIqlGckG2MV8WZkpdph5NHGfa2w/AV3jh0PnJ0gwC'
    '+Fg2bU6Cwx5rBZkSSjvpbbgrKQFzHROzgRGIG+mx8fDxnD/qlrYfzwW91DMLqUK3ygJMmiBoYe+lCLQq5Btgc6wcXbnCEtMGr5m/'
    'BOfxMhXo29bY8Nk6mwZfzppf0B6fgYtKakYrxiSjlkJsV6wn/eUiZDuDpSo0WzHubLqfIHXyFS/9rKX9yRsO6jRlot1cAk+4l5Wn'
    'GaymTyfBUEwtSO1evi9AvPr40z7j7tdjm01dULOphCFJ2VJnJrd9M9xw/yxPvlmMgeL4+pWKfYJMy0jLj4+ddEfvV+j9QhMeK5RS'
    'wruRpsavHoyZ6MfActA4do5ND4qfZ2XsI2C7/FLkXfm3Cls3chZKrv+JSU1VES81cqZKsRsYP83i9TRCyQyK5uXkUiUS7or5aKum'
    'j14sXpegKfdyc+5gDdYs1UxI9YW2ahO2MZauOKGLeVJZj2xHOq1Expu41TNxjX1sVo5CFS803eqbmRS/+VrB5nw1pZvzl7HJqV/x'
    'hM9Te4jTMwKSZSv3AuOtfmNw+b613pqEZlv8VqL44L5Y24AqQ+Rn4lqmTDtP9UynXouoe26zVUA/mQVH+Y4rYhacXykprbPgA58H'
    'V4sQFoKqQacuLHvvWPKBz5OrFYMwuHKM08MQgWyBJFzDfVaIOxz/M7vE+CxKBwNpimd0jXsWEvbKEoGBxkMaBU/8K6KYORZWJJqI'
    'FPDvPSrYkyIvk2gwyw8ha7J+MYxpLNHibilQNMsK4kNibX3tFQWnHYADOR1Y84LehMrk4wfyBi4wxJwog41T3u9E7wIeH0pl6JTV'
    'USWQY42AIYxOjzgp4uxZ09yJnlo7JFXrByMA2uFkhFscLQ8I96ep+B9ozGIIE7TbpDd9DFEW3tNZ0dATExDflw3pGkR0B+3pcznh'
    'VVZ5vUTglDZnax4taQsij3s8W/fNYunz+pVmsrK+9e7laiFDKrbaE4iwAYAhsc9nQcSss3VJseylOA/KOF9rh4iHSBGUcb7etqgb'
    'JkUQVQhWJkWbpxq2hjw1uCtEDDBqI2U8W1dEXUQDixlI6Ny8mgVhwc7WVTQ/X2eBXBMNzhhUcnDuUCWdjQNPvRDoOeZt3kFTkrpc'
    'iIQc21duDCSfxUOaG4/cOS0F9974eUhmNazJEQjDZ9t/d4adB9isR5+j1nYwMCbfM+sLib5GvHLM/drz0+3ziIAxCb713DcXIPb2'
    'sKi62HleUr9kxmXMl2BdaCeIsu7JybQ1CN/1jQp+r4oeE46pN1QMVq/fRsuWmmgURDVgvYmIWbydxM0MyCSeJMdaDeiZa7D5w6tm'
    'jLbqQJwT9k54muCPUE7EedtOloayUZdpEVd4wNuRwJiGn9llTDB1AnUBRhV89LL86gmMMBusD32DbjbNr4ETK4CrgShmQ2pG+XO7'
    'xEzeaI5jjvHvONZxSA9xCm3ppuDBtxtCzkHORCy1Wfk+q6/BrnMEU7i3xr/qgTRegdc4PJTCJ17hbAaopYugJfwoguqq4Z/5ypKW'
    'cKIccvfSxgJINUxfmbPkbmO6ctZsYDTe3oaXxWW0nhcVCK15Gm0Fm60dsb+kv3c2K3m+MH8jcuPh4d68t29QytFsvElZcfOFmR4R'
    'ITWdwpZ76c5rwsoXzsrmS+vVqjlkOS40sIP2TvZNJBKX7pXUDmaI2rnKksXhpr5mHoma5b+W1tdSS2OD1AbkKalF5vOEQFlZN5IB'
    'w6Q/+UvJ9PepWass5D2zT5DxeBqedfpmHn6SaXiKNzK+uZsGSnfu0p1LunOX7tum4YjDIT1l/v8Z/11fX0PUZJeQLdIo2RMoCi5o'
    'RPPqOOMrZu/epnwNhzv4+lN1Rqtfw4n1vl4GyFyLT8OLoOG39XD1joZAtAxH6pUOtPQiabOuY0Q933gARLUH1KoRQNVcMWZy0God'
    'mbvRyaadDPv+nN9XFl7AllAWG6HF6hNNFCRVH7K2HSYeuC+W0EeGVz7GHyIkMw40BwwFYoPF3mLGdtrjOeNXxOmQePDChWBjbfhk'
    'rHeaLBS4gLX8cZYV82EpTQC7mzCXbazTEKQYPC+8tUVcoGohk5m2eyrFfv/Ui74l9NSLjHA3MppbidHuhUeQbyalpxGWoDl8GITn'
    'Q5EdNZ/MeyYogiFnAedxZuMsNH0994MmhCl6fv5eNX/Py+8duR6TbocLJIgEIbVxjdYWRmBAF0MCdWEvSjnzcrC6KTWtRI5cT8Oo'
    'T6KZd5/Og0/ndQpZIX1+ExoJ355Mdk7/5L19NgA+Yhq4N21HP9NLeGn+bD78tB8Snlwi/+RTUC/z8DM/9Pwv+vBzXXehTmr9U7fq'
    '7kbu8WfoP8Sqvs8eo9Sk1CSRxx4nSdwEuUhTl/Vt7KbxbnQfBvvLdjaYmzDqiJEJKVVV5Kr+xFfMKsdAm04EULXV5lowMTA/lFBp'
    '1rToJnHF7JyWMxjH8bLjn4VlrCyqCPF3gt9Tec+U8T6IIq1JKeexFqLPblEYV1Fm5ho5N1+RdVtKo9mtEHHZf+Irs+biRZirJ1ZN'
    'Avd1o3Pvu+9ocKWcu9F650+1+xuJcbbxANP0HVz4Ykn9b5HDgvRrdZpmmLveVd8Kp13Wt6ZVl4GOXzhWw9cKk5gIYj/IWEzfvTvz'
    '/hUhwpwujA4NawCw8EgkEdGqsviQ2sSbc+/NuYmU6An6c8j5XKbor8ws1HQBLIBW1FmoMVBoocJNe8Vs9C5ddXPzrKTVzjKw5+tE'
    'H9WWlq1sjvV+OuWle3QEyzK2q2YXB1YIHSNkoQaG5+StgpFX2L23c4tNWcYcwkoinzrnI2uBbM2bbze6TrHefAY4dcdbBFg5zuBu'
    'xkIiLtJw3yQqn6pl3Z41rdtPfINKP5TE5NtLqRod7OF82hejA/YtcLO2FXkzthWd+3b6JZQw02zGxt/jftYZA2yBWM05759Ha6Er'
    'OMP/nFZP5NJX5MDMD2lWqGzWic9nVF4mju3rxsd3StXggeb2XlJTRWmPIHStS58QrSyU4qxuSqGAxovU23vGHmOLR6ZzlJWxNWKJ'
    'WC21FbF6yGh9sNXR4E3WN21FrCiKrSZIPwZHhHEXMJtco/lhKXbYyhVXmWLjilXEeD6v8D7GsGpGNuoOVq8Sfn13QcMA/RZl615V'
    'WsU72V+8bu2jzECzgukfVopz7b9u0XFKzBIKf1/VgzcvwUpXG4E2BN/TwHayFiwSjwPXlapBe8XV6EYuhlXz1i3gVoWvWG01yA6h'
    's647ITd7OqiaX107i1YkrthVGy2GsSldeGpjBtkydok2I3h1333PGi6K+ThWkPH3bvSwBaLccGjGc8DIur4ROLcWcLr84ddirIyt'
    'lVriHDCcS/sth+oryMsyOEndNEDsbdSpBdM86vgTPQpmjKHfamXbIbyi+EZvGu+Kh59PgqpPFla9wCHXp/tuuRzK6PFKeT9nVwXP'
    'TsreWLDLiZqAw7yVb23SMxIZxRuOZTpYSam1/WbUbIQf3F+EtmyiMlh/FDjgFL45ecBbBrq2B1VdG1KgwoExul8s7IxvqIwZL9DE'
    'OMODsShhevITGpij1FxbqOrsqGdeBIoz/1rQCKPmTtCIqmHayRkbWKdsQH3U65warBwMow9kcQbLlXNNfCyJjxclPg8QOKiOx3qv'
    'TyXgZ/2MM4NsFmDleh1FIPM2Yv+wRLQdrYDd58gMqIGxvJjt5rt2lwHaW2pRQ6ZzzlS5RMZIq3Fummh2fe4lKmOQzEO8XE8ZgcLi'
    'o6SieBpByUJvRQG5hQbJc094T/ne2xQp3HzvVbFnb/OYJIGnag1dj2NsNCDqvSDyy+CdfLOJRUyde7S2Nj0Tr79RD1ZbUM8AHjb6'
    '/tPbKP74/s9iUJ4LHyvxO2YZbcdzYEvCANJEjOqfJ51bKcAxI28npoM3yBMf5sMADm4+wxFDlXT6lKjM5KKAniWlRdX0rxNHR8pN'
    'SpGGKZEYIpDPZkN1Sz9Nc07fGWT9ycAm1a0PjQ4+jlMaxnQoXvG0FBmPZ3wcflU/ePO5qHCENIC04u1V3vgUJSRBfUEwxPW2b5BA'
    'TaF5Tnybk4ZEx5Jos+LdT9R4DhWWjuDLISu04hbxO1/SAkiSfbmyQKRGPBwbF5TjoKiSo2yBe3xOWxA3Hq2NgQmMg8sQOCDJkNO4'
    'cJSaNQl9GNqDcTGUnAri1C9oGcVe4g7WlWeXP5wep5aIhgT0nlo1nTkCylgBGpL7DJckjyEEgxUzBQk+qoSZrt6f0gLpasJt6ms5'
    'QeOw2lq8pFen46MWiEXDp5+m2REC+nQecew9G/ERUVDGvBEueB3Psi+TE28d02pMRHysbIpCx4e9Sdy+aF7uspQr+8hx4wvZF99n'
    'Vdg9KY/+bjr+bgF3Z+mNzbmT/2Jd/lvcEmBeEMEAyKxKtwz1gvtLdQeUZApkIevp0sLdalHPJ3PiZgCRxqhf4hqIfK3msaPdz8W+'
    'x662kET/EYPYgIR0wcVfJouH8dv7WyXmY8auZoiLjKGQFyHzWmiIvHifnZp9BUQ66lyqIA8GedUAV0xm+VFX1wfq0NxE5sbptNuE'
    'WixrnxWdUrDekKv0kHiFcTRFTmOgKyYzuQm2PgFI5n1U30CPsfLlT9pgdPDwzKuUq9k4nk7sv6EtJkgYNDKfsDhjv3olKu2o4aW5'
    '7LR3BTIsgoqOYxPvqFG+JFfFqnbym11Z1Xt+kfH1cye0Q2kAQZR7HcFe8bQrwaGBUC1tDh0FMhV+YQOy+21BWr4bnch5E7OK1yoX'
    'Jen0vB09ZCc5r6a+CwxTDYW1LaFiusZ2he1cpmLuMlRrFipHDQEEJtfMBoOwtC1jfYiA4wZ0nKoay92UCdV7OT07gFfY1KVCg/rn'
    'mujYJuLy+OjjpKeSU44/fnMsb2AuAcrG7xAZCyW5Tz9oBkTH0sRoMF64MFnyiwNjCX50S6rHIL12NfJg2NKngmnGX2pjr91BV6JH'
    '2p3LpEHxwYRKtBuhB/DVaw/bTz9uehTBKCuqe9Hw38HClSWru1ybsB1lHRAUGopgY80y8Wpa/Vws31ltA5ve6Pzl5AhEKVGkI9Y1'
    '0Z2RGHXcDkLfMcnuMKFy8b56xMNOYHIH/lAgvQB4ACEuNlDQBStu2WNGPK2d8ULiCSeiP7q4Xm8UqHnsNa8crgax4Ups8So6d3DJ'
    'yjqzsaGkMrRypgiQ7S3R8el3f8S2ZWKASKSnmB1mHTcBoeZUDLlsCzdrR5PR2NeSJWyqFSCCZx2cF9chttNw0LD9kJ/kn7LDIpbS'
    '2lpB4i4FfJrP1wrS+qSigNI1Rjvp5Rca6Ld5UWZjytfKx9N5SRxbrFcJAZ214+mt0ACencpeWHJvOJ/Zgn1m4apMJ9k5lGCULzPq'
    'ZRovImMfaX2mR7y2XGezDqUX9c5LktamGcfnzTpTnH7j8kV2mM6HgkTi6jd4iT7IjF8QInm0JA6OoOv/e3Z+g2KvKHI37S1smAef'
    '5Qa+WrCnTHW4fQNhgmgwKmwQ4zAcZ8NpNisWMUDl5AfAScaBmAldPzDNSCZ5BmGKGvOc4c0+0Wlk2Ap3WUZdFPSzv8LOp4MjaSFU'
    'mkn6N04K/9VmnDSPbAuGn4Xi/q1GrlcgO1x8E7ry72D0yuX8Doavdc/gnoc/pXaELla67Wq9C6Lu6l3RBQdluMhuV1RkvSuaL2YT'
    'vcXN/4jmo8HPEcK9SEJBd10E3Y01Yw7hTO3GJ1Fvcsq+SfNSIFJyh9ADNnSa92npsojlTffPfEmKoPEfiZ1Hs9YWTrP4eDxsHJ2f'
    'eXQeNo6LOI48bByRn3lEHiZNOLRncgeOIk67kTVFJjZN76Bkw2B0phKy4xVrY5U78PifMrBN9wEyf9At70EetqPXwUvV6axE9/kW'
    'MKjqB6uZfM2/VB6AyGaxTc6pfTEHhPAii5ZpL8HlFURQUULTaW/crm0NPjumNMJXKHXut91oAiS47T4iBmrcs2Dn6BS/ONYXyj8o'
    '+4yeCDseh+uc2EsnSCgXvcVlbRgDJregg8RBIB2PrAE/jpbb1MZ9qMPFG6cBqLNCqHjN8iux4gMz36MA9n3acSDxWx7ayP1KKgcP'
    'v2VlGErlcOErZ5F6ZahvHPhKz/y5cjhhISP9uwkPijCKvJ4uIjF65khzl7j6QOi148mkMF7k1bhtE++qC0wrzO1ivagnnlOKOhJe'
    'viILSCqDgxeiD4qc3FQj52Lf3BuEJPB66Xet61olYJYlgiNxFHhwSOzl00LeHAo4y/+bTFbl9JxjoTUOSxQTo8SwVMyvJ61KPAN+'
    'y4OlJ29lPhpaJdiSlYaF8at80Gqw2b46gDgi2iRc5dSnUinLTqZ+cU64uuSDx4huHQ22lt7duUglElfaOb+M3t65mMojLeDFQeRf'
    'v3z3cmeP9u3ucTbK9heExnvQFFX+T9GDK8Or1qRR7q+xZgjMSIIeuxt5mRMz5zAVUZBNor38tKUGH45iwgfM22xAZOhlxmELADbQ'
    'qME3DDBaNmKPuIWlxEOxsecgPzzMGLdsKDyEXCnqvmb4RBzBfNIatAWxYivykkPBClaJM3DtLMbYbgKQtfCXVg8nG4Y6bRBfFaIU'
    'fLPKkzVTgsjsjbfc/U70fSEIGIhNRizeeM6bQnSzx5NTBrudTE6KVhNVG00QKiykXjgw6/KMRgasyjQiIKhzHqTFtZtbKwAMwEVT'
    'q5kkNcnh01R+2PVjFpnloQJiKnbIQBRg5CsoCZChYuqTdQQOsMMtwtjucahEmipzH+KvdRK0l0u+1SiyUnDGmcL6h1IIJ8t2iotq'
    'scE+9x0lHBYSB87Q++VhYSu06Q0cMHM49OWjzNDzdAr2kGZFp+zNoBHRdHxV1xmn12vQuJSAZViTy2PXe05XR9dF3EqJusaguQ21'
    'c/j1xfUTZfZqR2Kpv3ylQdT5nW0GJW+sZXhyzcD7Y36iXdSeLA9PgjEPtuSVWLGqcmmuFeCH+/7J6g0sbWdTI5LdALXYBksQSBpQ'
    '7K7Gq/aPzZyxhWFWMXFq5KOrxp+tlLx2lqwAqhgvLZdHbgr4U+N4XLvH2owt4CT5thjlRS/SUg34KuR10R50yQa9odr2rXC4AVyD'
    'd9iL6gEbUdt3uVjVSMBgz7zZVwnYxGcICOfkf/uendMfijGkvBLrti63Q2wHqC1tpvokENnCWS5yRdpbFsrm6z05RprycXrjYyJb'
    'VQIUenoV5g6nJp3Bqp8mTrRhM1YT3bwbuiM3ELOwJRivrJMOjVZJAPGG5bKLopx6bJuBnsXJrCgyxJzccqpTPfSa17uks/TQw0Ln'
    'D9cTwGu7Y4Z7YWNqHs5OqQbAFJzr3SqAbySMPq+Fc0Z4h9DUknXA3elGU3MfB+dYxkZiM9m8rTBY+u/5fnLF/Vxb7Ga65vpPxaug'
    'QcbW2x/UQKtcbSsdttTUIlyvhb9g4RLWVdETvltdI1le2hmr8/1U7Niy15iIm0wfZLIrGRP0v8qYOObAZ84dnQkljyrjgncdDIXo'
    'PjEaZpFYYZvTfIGc7dMLflucbTo5W9Kde+n+ZtOpIZYvZjdyEVUaOTBwI6YgrCcHScwSrvfhPOhsR+ysQpo34MxO+ieidt8fFS+j'
    'uyAKbGjbHLCIDWg5sbk5UEQ3CVrtgbpJzOpBYMINEsqoCbC/YlT19zIXBpGyCV3fQ+/l6DLOFJX4yBbcTIg3nuE2JPeBsBUqUGO1'
    'sybotq0f1yBWx8EtMAEuZTAm010+02BaQ1kpOf1j4lm6NhsQ723zudtkIZx4ei56i3DusSfLm6W83ZGlWjVX14ZW1rax3aamleak'
    'CwVRBDA2L3T/q2XOrxLBg9O/xjZfxy03bkU9z3UTbRoqdZ0QH1AZ3s6ylzE3QoXZY2fQqRnXyd63k1s5HxYu94a17i9zZ5ukCPED'
    '9oNwFemI6LB/ylbSsiRRMxs4QmkP/GY/D45SMfCX3G2r/cHJ/ksmOO5hIsMPGKB4o+IqJPZS0WVzlZYE44UExZeo1Q1gpqNyRTi4'
    'yRXhFebmV5L8+RQEX/bKdceDLNEbpD89ziSdu7Wr3XXdSDqlIf0AuMl3ab8NXeEKbYYjIjlFf4awOMR5TQEabAPRUDqcAZtAkhFw'
    'MuLgxgxE2QfAODcsAWTvP/+3/3tZSol+mUxGRceLQdHX+z5kAWciT6OsTJVN06NrBfzLIBuW6V/tMeXe/W2z8TjyiPQ1N2xtsdat'
    '36upVW7tFs3t9JMN2BYM0xEAIfgUUkOV7Gwar5gGwm7X9XJbQAtgkLu2tv4AlpWiRb8X6sYZAyvmv+Z27y4qNBd33onNeFox/zXX'
    'e01JsZ5PNupqcpiJTWH28iVTpiySC87V6AUbKIi5rkRlMKQV0KAS7smhb4jWwtz5SEJYYONLp5jmAPiBYRvoMMRujlAlRLG+uEE7'
    'oXK067vxJreRa2PyIASVe3JVFYxRZG/MF1FoV+KVxU2m1+zGG1Tgubjx4oPguAsT5sNsBiyYDIiRlj86rJ4Gh3x0CB9V/JCXx8ZI'
    'tFW5c62yaMJRGCZCKTxebjtzUGEK2tEhDFEDQ0d2C2pDQDj0mXW0aPVz55d8emc17wBjkxoIGwtqzHxMr+PDpINACXE+QlSIv2Cc'
    'kg6bJMbZbCbwkThlltguEeyRM0v8gtTdaAms6mxGlKMoqD3CTnD1WGSvaMjiQ2VbrEFyA/GlWmpc+UILJczNXqfTEdl7ynABsMrd'
    'linCeb23n+zLfRK70V81MXbyFhks2BnQcT5cZIZwkp0LdMECE4Rx+sWyzgviFDa4Og+anJyvutZnPZzh4jhAUCNENYN0yEV+YcE4'
    '5EKeA1kaVMQvsLIbgB//AlO6AdBns9nU4tP2iliSMAnkJGceUynFmEtTzvnEwiOudx40N86g5EnCZcl3V6CMDKoeUjym8WFf4gFD'
    '6tEr60k8diZDLhCqUaEx4F1o4ezZj4oyUl17d0YTkgGGCPg4ZpDaYc7Qyqm4IGUD9tJNg8go/cmIpgkA0nzZK9H3aNY4Mopezx8j'
    'jDkd4NMiEfddwxXUXXhD09bmOEFVMGTxDWXetWEL7fXPAAaGKwZYqW3T0Wr8QxH20XndKtM3ygcrqfNxTvMRr0MD8kNc3zFRBnHZ'
    'lxpufM8uaPn3YU4xKUu+EXpNKwm3XhiiopV0JoeHtAnttTxMVZsMXtmAwZqHxn3fRkXMWtmMIUixHKRwZZ3bstiqte/bqUhZ5+vV'
    'FMtBCs+BGOofGNQOJyD1beDh0p/0jI+94xwawgntCnoDCEaSKLeJo6B/liWRXr1TmmVKLc8KTzuJelAJqb8bB7qN6HigpI+1IPzl'
    '8ruoSSrZ1qroRTfyPJ1ZU8CtZfMPmHmMYDFBjUpUXSBfzxkgjr/KpHkakjPmJUHjrvGxDbhgHakzOz/QINkBbi/w1/7NTtobbClx'
    'nYe25QsLUUvAE9pjAQvRTfDbmopGMC3d1mYHaZqBq9yYu6EXtJf7Slfqy1vGrR4q9mfsCGqsESXGmRhX0MbuyUdc+MXjpHN4Sq36'
    'E3wZcaz5pbwRS+ZF5eTm8237O/AW9soTixeI500F6Tfh52N9pqLWAKiGWAf32Pa5XvgVXEWDaWWzDaUgXGs5NMCzczF7mFAhHVyV'
    'dseTMt4Tm+f9hLm54FoyEHwEGnUyyl4O1UzabgWnfML3KRxgjtPxYJgV1gOa2lbYhoZ3Idsdool8k9ZKGoqUmJm0WOiEu6pUNemm'
    'oWyqQNT8cAyBmWwDiONoItdWRqbiclRwFLrMA2xDBUxYe3ji25ou4rS4Bx+Ib2QrZW6U3A5ysCJ7V9gw3lRLJU4pC1x0rL2dnEJX'
    'XGS+59JQm/PLwqYESnsoJbgN0FrEFn7TctmmuPOFxUkJCzMWN2tHQeLSUxkN/LyiwMnCAic8vAszZjdrCcnYxN98mJe4SeQGyZuP'
    '7//cULiWvbqw7Mp94eLm9a4pAkTviuz5NdmF2i3uwRYrA/Vh+YrZZiDJ9YXlrFyXdWVx3rXWYkGFgQxyGGSpf33g6OirT+2UqObH'
    '3c81t0oQ3Viks7bwzZFUlZhW4qcyMGpABLyRfLXBT/FJoKoPW2bFm6b26d22uaJkxXNXgZlOZ0LvHDxpvAOtSTt6tcGuzdwcvi7l'
    'AHMczDsvEt90EB/Zoth0FnCk1baeiM6Y/tuO4oYIslI59bPVSjg8QNdzjGuYm6uM6O3lrZEbA7XvjYgtFbEjqtt4Qf4XEhjam6hn'
    'af+EVU5XrN8wznRzyTrh+hQtpjnswnRVF50TRHiRF9iQuWyHahaSBDYictGgV5yB+cZiw4rLxvY8nc0mp2+zw3LxGZd+od3NcZgW'
    'l/AJks6VRVxXwvfTK7MT/25JTGN+2CZcV0K9gCv270KaNTTANjrdbI6g19MSTFuccmjHLFK80GGIHf5HJlCsETcazy2+BNfokaJK'
    'ZSQDDk5Vw0DY5SilHGybJNoxww0ZDgpP6GSO6HhQyOL2fKg2daxYHQvuZD/jw3mgn5Hfxc/xYEiIQuzm5TDzHEJBNEq8s1a49o3V'
    'UuUSCt1ZQOsLz4+uE0vvv/5UTMbJndXcOtWp1oCDj9qgTmxMwJGa4pEMNWjU92Oud0DidzEd0ry0PtOCAIaiuJE5ky+UZsNBbZHQ'
    'ZJoWfHnCUo+8kqg3sgYFnJl4dCaKLabIgOGRlCQirDBMBz+q8lWLP7hzUSluwy/tkosyabQV8JtkS9ADJy4Vw/mRFXBiNy1uRPf+'
    '/vn080q0v7x6xEMZ+CzyOzrQQ16Tx1CmYcUsKRoyXmQwngFkqaKbIiwk9JYCaygm1V2kjNY70esPO7vC+9Kx9iVPebntyOJ+oXHh'
    'SdyU2LPDdA7EH+COSSxIwT0FIEe0Q2uSBF7+h9bvagQ+G6t9ODni6LK4W+rRzi9gsIraNzrR8+PZZJTPsRugyo12zkm2GkVP+/2s'
    'KKKnH99Iynud6OMQaxzi1nCSIoYjbwkWIqL4VT7LDidnNnJB0NaubZPcwLNhJkImDCf9VKKHyjxhKIBVQQzI5LSz8/HNi5effsRL'
    'I2FS/o853xze5rREf1rF8eQU5aP5+AjGgxoqhZiMU/6wez7lbbF3EQ2yoj/LORpJN2rpcJtpRGxFRDvvEklrQdTPpZ2r2G6tbrTX'
    'UurT2scpsW9qefXm7csfd3Y/fHoJo/BwbXQxXK1N1gPi58eUvbdFBXyazmj2X5ixrfu7uEvSL2pwAXI7wBuoUDYRZOsURELOY+co'
    'YF/7OkXRNNA+2BbSg6VsqIySBiZwdkA8GH5mcbZYeUcFoChY7Y1HV+CRFGww06bv5bWpONj5SK5w3ks7W2NqAF6WHLSbWB42WEXV'
    'YlBdhsnpRWuTX4cZWv/8x383H7jXW66jGgOjJYZ71EVDAJgHI54gHo/agGiPZcy3oz0qR4NiWRt+OyCuAjWamKjzKyBQCzus0Cra'
    'tbAdHXwe37kwz5cH7L+bqM24DJkp1rYCfYpakhKlLZjT7UVfhCIDw8MV0gqJT8scA9hxiQBs8M4d7pSTGe7bcH1CRCN2y79dtUy7'
    'sGu+betu6/plgHkLlHHpOxaAhcMF05iTT/0tI/qPyJpkuM7q0vB3GXLKi9cmm+T3zQ/EZybYPobaxb3hpNfmcqv+HIuWcypTl3bo'
    'MDhcgHSEUsGndwZu50vbUyjQ++odQaOwm48yQKzJEdaENiMV0S7bWFtb81SFROxz9jvfFb9nKaEyPeWEh1nsB2V8161az5Zgc+Me'
    '+hm1Pd4LSo+T/bazGazRTVbmVeBc0mkeT3lV9Casfb64rHrvCnbLYYY7S0l6ESF0zQTQgx9pTbbafDWRzQqm17rhV0DsW03toMP8'
    'ryuyxld2aQxB0bG26XinB6Bdoy0140q8TIJwDz85ZJkOSo7N1Wpswi5kxGjPutUdxewlHMBhZDObs3VSR05riKdHOGeJYjACiTC+'
    'LRMRgjWPs87kBJv4pw6XT3uSDvFTnpWXeBHrB6QBxkZakhDELvaOtfpps46tAzk6253EsjX8eTi1PZVvupJ/oAypxc+TBKcdLia2'
    'K4MlO/ONNX52VfOi0xJli/t723dx2WEq3VKu473cKdSBlVhl5kE+4sUNfNccaJChc+AsDP1wQYPccsS6ba3S39VCDBwumMZ0PTIH'
    'y4JuVNkgDBZkej7TTs86yOuUMLU+S0Kr6zFSwmudJ+NiKWOsk+gl8IGIcO2fWDgi716fz32HToRuKbYTM2tyD0irkj+IAspz7jV6'
    'ywWT8rT4NdOi5Gd+RCdzKSAhhsbT9JAUJByWs32wh9q2S9ll7j/mg81wbeGJJjPv1kB0zWyvpAVPuG3YFXPtg4PPOqKyGBpPjwWr'
    'oGH69Ytit183lVcoBZWBDjrdvH7kqc5cx17H37P87I0DSD9RYZ/bvkxsc8Jm89TPpPeqluhNZiVTsFYS6P8vmQfSo9gjLG1Xd0BS'
    'wrcyPhUWm1gn81tH2a2z7hXfsIqiXd0GdDikEhFnEp1P5jMj5cGTjgWrDNZZzfKcrP8a4y+21LVNJDp9q0aoLdwrliyytgyUdLAG'
    'UaW2iFah4FzVVmPT1P2KFWdFtQ9qNFQT1RZvxL3jfduvehHxhVl2v59YRywCn+gq33k7WfeKP3TSMP3nGEYWvAgT0WphlR6Hp5tB'
    '+fltGwICB8uUieMVG9eNmmgx115t9aFt46E7Y2xuP70sjxsw4optApLYjhAHchYesQwuKlo7RUEqDW8SSXol9H8hjg7QOMgAryoW'
    'L/7y8tPOmw/vN/2iRjm1kFgOTthw2Pl6frt0aeERZ0R7YXIYvc9OsxmGicdaZ5ooxK4nrNFWhZpvINEZxRiTmvpFGgmTn3CPQ2HC'
    '0PDz6QAhwZxRZksr6EZLu7CzEz1KAc1IGhXBkl0Kbg0WHpSHw3lxbG5OK67IMH38KOgTXgrBpILdvzD+PHKqqlWloUTObnJ+ugIJ'
    'WozLnw6HRppqQIRukOoClu+YRuD1ZJT5Ps6yLkhE/iB6MlH6EasuozswATp1AZlZiVnxZHhp3PoIMiVYZbFPSFjM1lKNVpJ3kre/'
    '6oYHGqDBGs/6JqV6426NSd0rg33Yam0ag0TfhpLJDCNGiOZsADtG1spZhVBI/CF44waIylWZw5F9MXcNBBKSrdoAsYV86EAOi0BZ'
    'F9HR+iVTOAqGP0x7gJ1BO2+Fh81huIsDlcBRTSWQJJvOCNMTzQ875mHTF+Hl9XsWho2a67DDv/hmxqkL/MBYVqFIEhYgVND31b//'
    'AY3fijvLyZ1VjVNRG9/bt0fWnsGQDNr91J1zowraKUFkhOi1aOptZVjBY2PmFFWO3hV89QQEAST+/tOb55PRdDKGrmC0t74PblFM'
    'ddkq9wZHczsKLHhrJrpQpKgmtQHILKPln82Z63CrmDc2D7aKP8JNN93qNNzRiH1ANwJmtOBEQz3P1w0TMSOo3McodM9w0tudPCNS'
    '+fA+7Dbp0egYPkI3TUsLcVG8bTZTFGhM3SeW/PlesjMxTJQsd8pFYyeRwMwNR7uVYLCRGobOTwuD9auqmEvR4Iu+eqxdAnnJAfuY'
    'iqKdeT/Rq1uFvdk/GvIesaKj1DKtnSah6CUX7qmW2tEJzdcVXN614om0N5ROul7ZRlKRfP7IywBcI7KoZPLSjEognATWUldJKqvz'
    '8ckYF24xHQzslPNV2s18XGKkOX9B4zB+jvJFfwqahLU1y/hIrTDXRO6zccoOakisYwIDlmsZ1iZ9n6eFCDqu7FKAXVHjv6bjI1aU'
    'TaYcOjnUbk3lKgMHDaVjhBai2HxItNknGoQJOTvyAAMKyQPmEDIEjYvBdolE7PIEZ2g251O2mqZNH+uFKxeVhA7VdQytKe8jmOz+'
    'YIwr+1k+VPQpfL0bbSRi7ut/Pfa+eiI8o7MfPC6+HEVno+G42Fo6Lstpd3X19PS0c3qvM5kdrUJvuUopliLFpblz8cPlkoK24uk1'
    'PcEi89nkDI8C70aVXUZ4OHcPP+APpX5y50LG4PIxCn7iBcFthJJ3QPIt3ibiQEA5l6nRm3Tk0zFXbs3Lw5VHbayAbFwj5ZTd04VV'
    'AejlbUDZ2C3G6XdnOKBtwNWd9DCd5dQtWEkbzx9c5RUAg2O58i9/JjIzmnAkw/QQZi5coW+nLZj/upLkgVbSMpYdP7k1dyNQeZRr'
    'YeV/ADI9Cgng5V/bt7duAjLPpCaWhW6jCZSwUjdbw70FS3OckdwnUXg45nE+HDIuL1WggEeloB31jjZtCvZGEzB6bX7bNlmpwUKo'
    '+4YMTvVVm05AyPOmp8n00eWb6INnU1f3iqmy+d6hISvJUBcoQpySC5VRzVNxd6pV2Z9Mz29YoTt0dOWmX/KjFCin1itHtb17GIXn'
    '5iWzfhd+57uurXTG7IcermAYqFV5xtFAbdGLEOPNd9ZTpl/SfMjEnhWU0FhC+8IHOJXbcl4eMP04PZ4MrQEIfGxMmBsTSSdSFDqA'
    'zSISBl+YtY3rQ8Gnzlg0QT1iBLOyaLPHFCqgk6B/wgc/CyPrG9Gkxe860UsXFElqinq0S0ccC1XLNnfgU1yz612NRcpzdu7x2Blw'
    'hGYKdz+P6Q/bKkS4gZwZ+CSzTjkAwHYk/td877fHE7TPV3/mN0wxSlo2zAd9AJCUMW3pihsICwUyLLB8sSNH29OOUyfaQWCedNit'
    'hHWCKGG7jNFELbViinnPjnh8vJF0olcOjqSI4GdMrchnbLZTCMq7GeQeRpykmALO6UXJ7UUlJrNihXFEqk60BFvHcbmEdgEii+gt'
    'HH24DPbzgdmEzMmKz8myVcQPbIHhCuYbwSHbDmKdiIHGaQpvmjFCzlL5owyevuC9Mvg9sYFIiM7DDFGBDXfOca+wlOKn0T//63+L'
    'nnW5Emo9rApn0dPNCB/+d3yQN88Sdtc4ltoKfYs30qTxRNvhPqCSmNb6UjlZktrY8GkJP/WFxc9KPOMm9HMnB17jMLgS5eJJEuvI'
    'L1qnb9+8f/nji5evnn7/dneHTSblmyH9moVtk8cDq+mK9vaGGhh+2EF0uBaNfWt/vyEbm4GGGZHBZF+cEQNwXYXtaHFx35gxH3O+'
    'y3AURY9eWMcvLTREvLXWpknncJiWCKc4ZEHRmwacc8QBxPEe7QsJHMz4QwxqlGhQYRJQNKYwWrafiBWsfpRXfHlp6VD8Pp4kYu00'
    'txZjsDUYqr3rdnQQxXcu9PEyUcOFEIVR980z7KwisEYZeYZq7WhEwhpwcUeBWRl83G5bS7k2q5kKdh4UVFHudl6ASsAjel4qtoBa'
    'DffnBdzOWLFqCK8lY44dnxcSFIGkkDa76gI9hzgSGcl5KUAGom42CUAUuvybxsGN2ZhNVLuiJ8C02TT+jOMVe2/CjITNS7i+4JJZ'
    'jxmOEDtAjOUvsJ7spYD3tH5QnsdoH6rICdAdsoGJVcjtbg1zakwfsqEWIrSvy4VxzF96yxeUWmfc79gqATGr1aoK2nJuPGVGTpWq'
    'eGCpthEUYPUgmCd+GzlNJ2gp9CUnHF5FW7gWNOuEm+WZpwbYRWELRF1zofPkWWRe1pslgfMKF3/NtWZUa40fZLqpV5UebVS7tN7c'
    'pQ0nPHuaX17vNj6f38/jWh9bHxjPRo+lVruh2V6jDyWsapYVlYVyaBcKR1BrbvYhN3vdmwlHv2jDaPC/p9oYWNyyBxMdN+9IMIO0'
    'LfgFhWwdURYJ6emKlVsn+p6PKss0tLkMx5HJfuYAuhok0BRt02waiSnVhhNToZ8UgkYwPqWoiD3nJMSJD3FMDd+dmLLj43LEYy7t'
    'tsF2bLPocPnDH/7QoqVZs2mZsBkcGOYXH959hFBJYrgoUV/RObHDFifxwWMYnJAIW6SIofOL+kmh3oTkWf54QGcKhmwVb4nnw0tH'
    'OZ69/fD836mm1b/HH7++3vj6+t7X799+/fD269s3X/nb//L9h92XXz9+evl19+mzt/T39cunL77uPvvw4m9fd199+LD7dfcTvfy6'
    '++Lr60/JnVUvgkjRfyfoe0SCZAjAU9KcOY403vv8+eDuj3uf9x8/+bqfMGP6+fOddd9O+XTGkRkRWbxMQlhoKRWE34S1cMDFvh85'
    'HWgp/G0Rnh7XhKVV+8bEDifUiuLzzv7d7YQfVQHsYKnhgYv/5wP91bNOmaopkABMgt1QuDZiGclBY4JsVIkwZ0iCAOH9Dl7uGiQx'
    '+Ht3dl/+dffH9x9evLTQecRO4MjY34d/yzl2By9P4ozZEf1DjxZzngIFGtCZRZZ5CHp8iUbNWoawjcr+UgvBYkUE0Ymuxp/3Pu/t'
    '/Z3+7n8e7y/TX5otZRdKE5A7j/4t2tBJ5tmPy8TYYrcSF7m+GsTxsrn3t03vX74lgf29GYDmMMccYgbInmI1yPjIVssr80Nl92Gp'
    '+Z7H3NdhlurXwu4o+rCz++kDZEMzUliGcevu3ZYWHie2COv5oFnf+OW8fFcr4wZF7FSa8ubfX/pvXrx8Wy31v/yXGxT7nEaw5WyV'
    '+oJw3feNYDdNsWbLcqIu/+Pw11sHLVa4HhywnpPTQFo8OGBB8cB/edBycW+qDXracovfAquJMSTrgZ6WtK978zKjU4xew0LYWBdr'
    'Xz0hNljZpvmxpGcQz14mkci4hm24Dgg7CtYU74QvZRtJWxzuYA/2NCW7ufLK5kSX+5rRcxKIk8/FPrZPXfOXUPnVNV9bO++8NWf6'
    '0NpTvR6L4Qe391BvdXyKWb/l11At+dmnhoI/j3m+ooh+1DISefz+6873z+j/H7++e/rp34k0it6d9nW1KJ0OtO/xnYsy9IO4pDNK'
    'E9C51PA5bLUWrTnCUOOObwhIMEvWtN8dz5pUIQD4uBam31JnCa9RJc3DnKG7h0IvZnDd9in0MDeERnz93r5pLSJL0C0zIaLCTB6e'
    'jQ9vW7IC8+Xlyw6LQyuAz5z3eGmjA7yhWlhaWVrGUpIReOoRaAVFFoA41DxH5/aN5NPHcNxuPF18+spWczTvYALsdFvCmjjSIswP'
    'M4PoBbf4UpTp2QzKdSW61C6zR70TZixH/VgMp3rJ5UETt9yXsCjeNJhluah5frOwJOI+j2nStIgkqRxPn9WtwFtRbLXKM1ddSKw2'
    'kbGmaQ2QAmDV0CpnrWSfz8aSlb1IWM5sL/atdF4OXNEa6ywbCm3jsSsH/ol1I0WevZbjfZmYAvGPx3b9/Sud5XSEf/7KRdxZ//z5'
    'a6tqv7SHTCxxPgXaf+xCjrSjeJnaFtKf/mQo7hkgkutJtEJ/WO4e4vTXPXfpI03exkBWota7cGR6Qg0LP3YMNYYzYXB5bM2OSOyF'
    'lB3ymdd2LmfFpa62y3KTth1hNVR0PDO8TPSVxjyprByfyphWtL7y6VjPzFv7aytgM/d4ylEt5OG2yezabxq9sgI/s3pp3F1utrjC'
    'rQt/hmJpOS5c56zILJR5rS51qyaxFHPIpr7unYqIQ1WMJP4lfOmWMmezC1XOpcQpTHC94pVsEIGb2GV/SyxinBtZRxYUWKipk40L'
    'qV0a05f4ZELO7UnNXYyTK9nO0vefaOI6G3aqHs8fPb7sTGP1mZE680bqLFnMTb3e8JnE1/camCuvaPulWoU50s/ADBlhlQ8r80SE'
    '3lUCPuIP4hoEun/GXkkHd+/i5927jrAvarWTM1teI2RZ0lzYlYu163uhyup2iki0A+VzU57Ivhj623QhW0zi7TVcsX90mfCU9QFT'
    'Vpm44gM52gwL/HlMr1pXzNz3b/2Z+/DWHwlzjrWu6MHrT62GCWw5WxoeFKYci4pg+d4vRdw2+pVK7WciNnaOguM12CgNDJu+0sxQ'
    'dVj17LPJZJil43DOnZ+ScBlvlY9Tc1OirrzdOLhl4/KA+nnK7qhDoGKFlLuqfY4PR6WvivEpIKvZRjpeo0GrAeWXA9FVFNlJxSpH'
    'FFxbUY8J1raExRD86FCBJAnkOxRJTiPV86DGhzm2IINuhB+ON2RvspKpa5RNFQom6PpoDP9yEXsP7r4112Ddu2w+IQk83+oDL3yo'
    '4ut51Yt61VtQrT/widZTW7VWw1oMmh/kRY1/+MYCNhpKuLoIlzpyrDf1HDpOPmdXvOw26+oq4umc6NUvzyaiAMkFmtxCWs3kZKbL'
    'mMHFjZFGPjNqRxNMSC7/9A4ymDFhcxoaGEgF1cEY5gE+RuGTC94b2jX5KOcOd8UfQqFq3jaMdW3yJmRC11LiGFC65nr5WZM3Vadl'
    'e8XVFPnfuPOahk6Fre3taC258VK262fLlmTR5eSbjR/+cA286cKFFgx+ZV1JM/x9WZ+1SMZV9qkWUt2oSJe0KsV6tMcrtTa3V5Aj'
    'TwcfwWy4PmIgPyA9tq0tfyjqlwEeZfZP3It77UsVGPmThjCW9aYXCDuMu6E2pGkRITham9cHYGVhSSDG3Nh3zKYxsv+fJ5MjkvJe'
    'TPoAQ/hhMht0aicCSvICskKPzhrdthjrb0Ur654N01CYWMQmAyMsRtIxp4QZLvYgl7BMRTxeHeZPHq/Oh09aAsm1ssKGy5u3bryy'
    'rzpRABXm3wv485f4kZ+vOQgeT588zp+40+Dxav6EDoSs6Mf1tQYFz/SJfzJ4m+m2o0QhG21CiWDVUM7j9RYH/JQ7seMN/CJG83JP'
    'ytm3Rxi7ijKGjRlU1j6lR9A4SQN5R4nWSV5zi4mD5XG4PNisqG4uvUYLWX3Cc5NUZvNxZM8Ff0ppMh/TrOqELi8bjCBLCaXNJu9m'
    'dTVIXslhPnkdMRQal+tmlg8eD/IvT0yHHq/iyUMGuLzlD5TbbyjdBHnDyrfG2WnUGUz6Z2KH80vOcez++u6teK51omdzYtai3jn7'
    'Y0Qx7N/h10e7ZjKazrKigGWUHGOwPEVPAJGLiz1qe2+WznIUA38Ktp1B3e1gJ8bzKVtp0yZ6Mcu/ZAkfrG8pb/bh8JBk244zDX/+'
    '6fmPzLqCI4yTujUULtG+p81+b0NE6Y0HEnbWhtjFFl7bjDCj9I1+SIxdVscIgrBNeiJJEerkEf2DhEjSj/7IuDZrZy9fPHv06N7G'
    'WvR32rzRkydPIsat0Z+bUbk33ucMeF4L3GNxE5rE1qO+P+vfA7Z977w0lu2mRWtnr/R/mz6ZOMM8cXJplR2ZPWrK3yOS8P5IHXyw'
    '79r2yPkTcxJXcGIb6HHItBTYPE89GNkS2xvsbNzX4YZ5w0tWfwskOfC2mYluC0ZtOtQnCdzF15zwm/Bu/cpcUBomp1AzvZ7MZ7AI'
    'efw4Wl+PvprX72jXCjAkfXjg3u9kVMgA73nUHbItnKy2GPuVXfCI4/pblkJrvRKtf/dojcv5jsoxKd4RZTjmk2a9WodrMN/yMTYx'
    'r45bDXfnGLAKxRYXFhqzjlwUGFT2tvFYw/Aib0eexYZpxo7+22E+cX7ratI2lg7WGBaQ83eztyuZuD8AYLBNbOpR4usgFRTcTUrK'
    'ALZ44N3zbI6wmJzZyYVf4OUlWwy6QSoziLdlV/gXJbDBqQOYDWpSfA9mtGdr99fu3e89MJzY0JS8/jC+D9gKG8XQ//KQcz5aa/76'
    'iG0mvPb4H9fxKWfVTT3n+gZPRsNH6uj6fR7o5pLx/ZHMpOUDG8rY2LgmDTVi46H4GFTSKKAwbSzlpY17SG3C+2aE78s4bayteyPc'
    'XzjC/XCEF3x5VBv7fmV4w8HvV8Y3GPzg4/3K4Pf9wX1YH3z/OxrbNLBBmvvXpMHgP1o8+H5Z96knQgLCJELsVKvo+YpEhmDQ4X5v'
    'TR1F3N2O16wwqJfBR9Zy6dydE4ccQwCT4BnQNndwBrzVBhtg6yu388aGRmwINzJN7MO1B1gsdnCycOqFI6gMYFZZAE2JKpVhJQhB'
    'qpahk10bXM+wXlBmOp0ObwfWgusAUdct2ozG6dajcjREMKqtiE/Wwru+/ePjJ0t8fdtXeJbWHwEQ88d0NN0Ef/uYn4YlPzzhhyN5'
    'WOKHn+cTeiROtc+YTxW7erBV3Fz4B3+UO13/CP3hx/c7kC3U86XoH2ejtOiAk6QmiwBTsCfMKTFN09kECGx0JIyGcI15uAoTSQ+I'
    '69ONi5swW/VC/TqksFk2ZN/FAtEJvFJn87Ex6zl4fNqdPaE/PKRdBgXdWgITmM2+ZHCukZGOmQOnZE/wd+Z72dCkpXwewTujDbx1'
    'sW/cYqQprWOKOqYfZzB1Yi+ObXktLh2n3S/pEO4+/O0SoadFG00iAMriqiU3td20Zeq3YpQN8tQ3CL1QcjrL1SHO24Xw/6BB/8Tj'
    'EMuZy9oACadQu3hGMq7Au73lktHJ2ZvBm9ERO4u1DVdwwHb2xNBfdrgLl3o9LoWohWmtfaHG1U6NtpZ+TrtqqDTIi3J3a2ltiX89'
    's7/e2l+f8OvJgZ7fyyht2qWWQFPSZ9eq/tnlEnWWf55jzJGC1vfHWZQP8HZM39HGrSVd6BG/k4T991/+PEunx3mfsetpbh6n3SPv'
    'zVu+lBpPnrMT9dNimvXLraV1ZF9tzO+31RbllQriF81nuXUru2I36JCZXaXGF0tPHtOv7hTF4sf4C3UMLccDNUh7vma6rf7naLJJ'
    'gfTogZ/dbzje94b59FU+HKLt+B3NugxWigJptrm8tEusINCu8NN4LqFg78NqUFi1lmIqY352OBvhXyIA0Rk3/hx/uQ5oSRZN9qrL'
    'Op0V5Z+zySjCj62lGTVlCe/TL28LbZRJoq2SylfNaPptWw0m7In3LBMvK5jJiF3YjqR415omBlbTDqXj8uOsibjQX49YuH3esMnr'
    'NKT38L4Ka+LM+ITFzkd80LJ1f5yWRPrpW8XTWA8bXBSms+cS/mkt8cNQ5eXL0RxdOW1Hxxw05Af++zrxJEMOWcZf+ufmznyGaGsx'
    '3kZ3I0QlOVVdKyV5oiVcSFYvfR+xLfCRMlBXN6VAvIA2w5oHSPAYvawNbXhhjcJErM1oLGMxvFWNOHxmxIrXasIlTCSAMBSlF+4+'
    'rBBPOp6ZO0pnzzuMRa9GaMVj0yjB6MmzNaCnBTYGXhQcGWi49XUQfpn+odFef7TxiBnc9Xt/Wn/ogBFSREGg/Bv5mGTv9c6DfOy3'
    'RdTKWw1XNVh0OZx/uohxh02FK743nMEqhtwxFpB1XdaxWWyxOqQmbeOaGsS38nxU2dcPCln8QME/TTM4AZotgVbhAIeq9LTLfqJE'
    'cDdAC6x9z0HVeABsCCsNMRUy8LC5U03jt3ihyd0VZfBiWZg9rHnFIUOd0NS0KjAAe2PGXPR21KR7D9cQ+8/q5tWr4ZGK9MtIYIIb'
    'wSRY69C7GE7NOqrxnEgwhO8OHRW2TjbLhfPzd2sbD027T4lbsmExn95HO4/ycXELe0SwEFRdC3ct1rsZrIOqJhYaEvUVeD8fOdM1'
    'l+oT8xBiMOlhH1jOAjpbRhANVLp8TSS1GGaC2Qgu59LphGaAdvEmm5jtD9KcmqUH17hBJXvtNRJM8E4uGQauElsHLtGg9MvYRU/D'
    'mOgCYDxt0IgsRZayYGlhU4ZvMh6eR2V6Quk/vv/z6n/6+PLPbANNLaOiSkAaS+xyKGAdNUENxHkVKhzBHitpiqzG/kN+VLXbY6NC'
    'DxXHfqzXNo4AjvQaquBNVjFAh7XY6mNQLUq9tRTv/X1pfzlZWj1KQssW01RAlrD7+CJzw3xU8VinN+quTn9NWgFoMe7nzvvc86Ot'
    'm79gP4h1y+rfHVX5DLKiZnhomEdfwmREbLarCZkAaZgjq/by2smDzUrvqhXLjZzQPRd06uU4pZWUDjkEWeCI7r5JaDHPTr3miR64'
    'fovnN9WjLYdPt4EK8X26N3XceGCqxjB2akm8xcBAXGXC3rX8hOjwlPs47VY7wxcl1U5YacDcsdHugrxCIuOU9kQO/a3iHPHu5F+8'
    'm4Qt5hBT+Swr3H6ZfWTQrdC74czzbZDYl332ajuTGw1izF5N4KpKB0rRz4n5puEsJsO0WKJXx0/HReVVv/CeV58EJfe8YnuVb7n3'
    'La98K7xv0KCeZJUEoIRemv5kiKB2IlSuPXh47/l6tSk4e7wcxzTkQx52zXWeDYeT02quOaMqV6ubm0wQ5IdZNRMsgjlbMZ9qLpzU'
    'oGxPqc6xk34lLe0r+kcQ7viYp3zZTJ+ZqQj4iTPlR2bM8Z4xV4vfjvUwxLlfnnU93zSwLobJwUrCsdc2zmCMXi822XriOtMVuN6/'
    'VufujdV7EQvtBS/S0JPqr6OhulBR1UnFAvdf7h/1L/WQ8lQphVxIDLAjD9uCa5JUzYJDJ6Jr3Yhu5kjkuTj4xoxXOwRtermcEadZ'
    'laxi+TiLD2l4f51SaJGPkKOYv9ZPaIHJ5knODKxvpRlaRt7EOQjzGKMkkO9Op0MT2TOGEWZOXak39hdqKDa/ebHfX1nQ/OYFfYsz'
    'UkNNxTfU9H04zN9/vLLkvYofyf7Na4I7y5Vlg8TfvDh1rFpcHI7Fmxfn++q0jCKvx6ojPLQW53zaCjbkMW2QGQ6caNYVtZyKDXGz'
    'e1XCiEgN7ZdYWmH7effaGvz92+zVVKc4wq8aFgihZxu9mmpUJx/ZXnpKGmKCmGGCKNxhbgltNyK9SPQQ6K00iJckHn73YOOB9ome'
    'Ht57AAjEhw/+BFk/aSJAvpOSN1aH1Ym9DO8/1Qi2cgP6kd324epUVUuxPsqoumv6Kavj5ry+OqrJJ2qQTSvnioo489GbwUL/JCfx'
    'sYC+TiM4/DL0Q6k+4tPZ2h9KNZs3O7qucLP6Bker/1kOUNbT8GPMa4Ad1S9oc6hWYMVTScQYNpgB1m8tgLdIDEzKWk7WjndpTj7y'
    'jufBtvwdni5tijcD94UfRS1rch947fxtHlXaS2OFzjMcWJreaJUbbypejOAdG9bijfyqQoEXHke4jGJHKusltO7t8escldq04ZOK'
    'TXTV62jdudZc4dVlbmNpGZRiko7YzagqLhGbey1pqMdC5x0OJ5NZHLvFw2O0ym1hxJ6ZoB7jOPi3oiIz0GPxy9bSff4h/NYai1MQ'
    'ZbaWnr3Cf06ysApVLpTHvFVOprjFRLX4VwI649eMo9AxMg2slV+7n39piZcbew1JWZZnbP0bYCWyBv9vRxSwGcre8In8I0uefvxA'
    'DT/lqwYMz10egUv0BnrUraXBWcoqSRZAtk0hb1ifytnwoZZeqeWB3RTLJuczGQQqUYdDmFL3QZK9Tc/RalPqYX6WDWQz0sfnJO+9'
    'S7kD3CxuyaO1aiNwkquY2Px9NSxt1QxMQ7P/PMsH1GY8HdHP55OhP2ws6BnLZF5Cplec76CBGpcckx6LvMElO1Pg+Y4g7DHVDM4L'
    'lnqYd6vtC1boxXrFUcnkCxRYGPOClYvA06NBKIKTI2ztAK316mliL8b+SeU2ojoDoi5jeY6QdWtJ1Jtl6YnPbHB7lmEEWJeWjpnw'
    '1HoUpOROKC9W9nm19HWh96vrfNywyMcaMc9M8w7onaP7wV03G+uykuPYng19aEw9SgAUbjziznBr6dUG/gNdkDJ4ifSD9SZrTo+4'
    'wB8VMKFU4YWTdKgQnH+mOzCqewj7k1bTzQLuFcQyXWr1mdrLcMY3ZRoe88TJA1te3nhwLxs3mqadmkefgfVY6BKMF28AGd1yZinV'
    'awYW1vx43TJzwW2T8fQE2/pJaftPZLDFA81uKosHrOFotQ6cscBNwQQlazhemTJtMbtmHcw5LU3WvYdrhgPeioIzqHJipDiDJJcM'
    'x/TZwKd7DafS+oZ3LD3yFuPTh/hPp4PLaQUORfYijW90LLWvXJ0xtQ/vyiq2JQoG8kR/bNMoK7+N7rA/SxLk9vnWds3jdZHPqwFE'
    'oEplu3DGth2tCye8604RaaHZ9fUbnF9/B/fXinx1LZNMZfmaIgO+EzrR3lCdU3GsbdTTNKpkPOWAG/R+QKKuH/uFMuuVzrRucQrO'
    'TEPV2Gee9+wFV3yVWkhFW5Ro+1UpxC7cuhyhKtU7F/bAu9cO+rIdbVAL7jEsH4rlOO7o4VrCl818yXt5kLC7Do2mNGSh+HuFAy8a'
    'blxDzRT4AsNCB9yFw3udL27N7xP2sAJKFOdKqKo6FBvL0FdcXgSKmhtpMYcVLWYT4pEnKwaU59ee1kKzbjI3zY7FvkC3dtUe8PRQ'
    '7mgyJF9khGai/9Cj+etNoohH86u9ucIzGQ1Rv2QVIzcbtTKV5VeTVSs0Z4HoWvdUNsN1GVwjFx8OjQ3E7aoLFvu/VWxAbknsGHvL'
    'UXWss3csdbMQe8XiuRt64IuPEv+qhQHnaBnfEhija+tba3tofq4YbAbY8RC9aHIwXo8cbqBnwBCMScWljAclsL1q4ngeie3Jbzag'
    'cSqzW06E4iqVlctZNAvu/R58h/90nRqOr5kSOMe4KCAECyr7tdVYgtPsc+cq9jSBYGQ0aKZwN9/kVYgTmA184l5Sc+UL/GIN5ea6'
    'zHHc2lV8zdChtWb6bH2onw45HjbwkSEkO+MP+N3RGVJMGPx4xuDHpwxOwwjybD52iCAXbHAzhX2Yh3+vBjidCn8xHR953mFiphfG'
    '6TJw5BcSEKGL5Se6EA+CvmtgHbkpXTpkL5ME4MXWuj6psTaDmoMNVdXpcXJjXQbAcwlZGh1PhoNCDaLOaKfD9sWWaIdcDcOmcDJv'
    'Cb67U38PvkAJZg3q4WXkv9mAmPbgT/fWH8Bg/+H9NXh0LJLcNu6viS7jp749uGDFN/MEFEdpTfs84z1Y7i0bIiEPSkXtQosWOmWW'
    'iSsyAAtgkAcsO+WE1nnlNUIiBOk2OJ2NtyXfAq1si83SDxZrZqu0GHS4SVO73qii/TUj5BmjqxkM69O2iUSYwFZUXWdtSWDoqJtb'
    'S9/vvloh8QsRzQbpcDLOYKdQLG0/uQUrcVMMx94Q0RneCCQ6y5sZ3nzy35xOf4Utdei38EI+mhLTX1EgXB5MftoDv8m8GywN2wvg'
    'H/B+wI1XLcHRzi+iUlhf/26NuZtj+v3w0b1HMtHTo3cpyHo5oWFZv3+flXsziUtiHoVhcs9yepkn2e1bS39aYyH5kNgN7/FoXlo1'
    'ANaQadqqNpotonUSfavkw4kENm+yxUnhjpv7pjjuTZYW5dMiT4OXbJ6jj6pNVj28GHH8tjWohdRW4BNZnxpZqtCzVB+fWOMV9JQn'
    '7Rez3zY2ZG6KX54X1XfDlGkav8vGK39+5h/Cq9UaptWnRQwLZjVHtzYe3jcPn+bDTJl55Xu1Dr/U1bCPdjys5mpqL4no1UDSKW/N'
    'Cd8MtpbeY5UPecDYlUT7p6+53z+/4p2giwgZr6vLls7nea1wectlA/p78GHcVO0YNnBXNmfxsOqBs2pTKKPkJvpBw0TLO29Gv62z'
    '5hSp9dcEplj/PfuMIHvvYYUUDoCEYNtaurfBKyswyqaEyr29dWdR80D16vzt+qt7j2iFrobjeK9hHO/9LuO4sXAcN/4Dx5Ho/VJF'
    'vmgcxvWbDuPGqwf3v3tYHcaNhw105+HvMYz3Fg7jvf/AYVx/6A/jw4XDuHHTYby/hv9qw3i/YRjv/6ZhDG/bq2OJr1HlMv6KAb0J'
    '7TK96osZ8Twd7kiS8CQwvTA/C/8I56hifEn7z3/8dwh8//y//gf/83/+fy3PIeBwJCgLrUHWz6mRfJ0L46i3GVgH+/hpMkrHfkZN'
    '/1a8HbYiz2MJrkWQ2bvRd1BZxj8atRq4YeGBwQqzeYIc1Ox9Euwj5ndfjUrPUpVauge08Hv7yiZTGbve8vw3Kg4KjcuO/fyfrLAB'
    'rmnJH/RQFaAuH7nn4cH3P3AkZB7k3sO1yjlMxVf1dubK5D9mSMTfpHEo7lzw9NeG63/KeFg3mN/I6blyGpm9tIeo6f3y/RzaRe/p'
    'DftXIgkHFOEVy7cUhhieE2c6eIdvPHVqKIBJZBWJV1Sgn7mywvVvrTDYT1fWO+b6xn49QeXVY33s5fe9aqDyzgdmEQal0iocXC4u'
    'eZ1b/A3L+wNN+AyqleZl7n0OTlIvp7+0Lm2v3DvtX0s/yULxhY2Z7MlfvwA/+Z7tlWiTV8iNRLhP4NVR946n/vtlRhj42ZsBX9AU'
    'S9Eun0gqPq8W5i0HfN5akmc4lmGsmsqhGasWYgfGlRP4qPG0ir84FsdIZrBWOKXpsFNxpXh2X3FFc0GrSGxcmv05VEgtB7jZWNGw'
    'sSJrPuoqczcrHUHZN5/eTQaU8+UZHWZjPoPDhRTMaiAC5yKb7vHKEs95RLPT+6Qf0aJiH6PWMsFvf/3a4sJ+5ZrqS4NWwMFgTak0'
    'GKHLY2kI1v5SpC2XoUyn02EuYaZXv4wHlVpWtIZOsGCXdbU11IAviytYnG+KtRjksz5QC3LA/6sxC3+gPJaYEE9WvmenelYgrVrf'
    'r6sb2zAaAnRh81dhNDr2C/RKZpQWtsPbur9rK6Tca6sPd/zv2gJb9FWNYLiHybSghTvLvr0NZmUi94rzTDM1rvJWenJAx1C4cX/E'
    'JljFgi5+hw37H3UYrFdJX4i54uhffYUvOBY2TIm/pbWro6xMMYarlWlwDapPM2anQm5rs1TL9TvMVX/aRWkfbSOVf+xPv3kQFndb'
    'ihw4VfJ0PhuK4ri/mombabG63llfdWnpSBoVjRn4i015VuQL4lqvr/713dsdbvxKPkbn+9C1DfpdvmRz138uPh0OPfsdKdkTdjJ7'
    'EgY750Tm02Ntq7zIBhG1yJjG6Zcf7j1/sfsKF44OmK9TTt7sfFC3ukQDDAAS4bvk8j+jgqBQWh21mWpYIbWFbleIvY1ozOKors1g'
    'nAibkgdU0uZwIkhjJqExfuNCesM8KOfcr9yrSoRAMEyJQl95gD2meGGoYPogLJUpdtTxsHzU/KACu9j6nU44AVZvDjb9QbHQbxD/'
    '2eoeNEq9aoFIuDUxw2vI6RMNTuaiqnpRq7+AS/jP+TQMWB3FNqIZJ0g6NCrQaOCfJAhmgQA6tioAbuHGTy50LfwWGoqHj3nfCxZu'
    'zCQsppgPCW+BxLqRDwEPYwZ2Hx0pSjLbFfEbhkc2gOteD9HGIBg3lgGV2cafRdG4f/cZcXG7g7nhAXP38nAbR4RiCRsZhLg2QUeL'
    '+exL/iWzMMs1XGXaGgKsLEX+mjDh9rbbc9VtmChBavZmyksOhOpKMTJBTRPO4P61cuyEmoJclHIbp/y5xChHjHEMSLZwOKwprw9n'
    'fu3ocOBYf1lW69d1sjhWugFR/9UR07V2EzXdrlKsWa39w5QZgyCE71Xrsc07s7Zv0Vxvp36anFKG43wwYNRt8wU+3f57xAA+M1mZ'
    'WFRToJbbASEyyXvP3Var5tiq5PC6zujK77LxXHtcPQ0sMa77NHXo/byVJET5bW2wt2oy1rmimL10lqcrx2kxnUzn030U2AOkhOf2'
    'xCmIvNPezQYgnWy3IqcAbXM0vwCk85EL6C3OKtngKGNnCw1TUJaT8WZ0epwJfkQ5mQxhzYgwhEUUp7R4OXj2aT4mepjATSAtabmN'
    'UQvHTyaWDoCOnJvtuqXwqCD2IRszdgsxGAMOdd4jnk320Jc8O/XA2XFF8WG8w1liDKIMPX6J+NRhIx2citb6SdVHDMdHyYi5fQa8'
    'K6JatPxpYIGixgGm2WKIkj3ybrjZXHaLQ0jRj8cm0bb5sWI+EXPQkZFTi3OG6aDvNkfT2xWbqysgwiDLXGmyqFMH/EBcePbX+M4F'
    'p72cniECIB0hg8HLL4zkT0QIYfRaswx2QzTxxl79W1dplyhDvCerdD/BEgvnAATBD6hSTo6I6PG26JVjG7mUTbLoJeDF8Vs5al1s'
    'fG2i8F9YaB5C4xgIaFRSBxdZCveyk/eGElaDmCDRS/NgSSs3DfK57M1Nsz4crdBsZrz1EW0t0KcW95vZNORj3KL6whOQHLTs6h2n'
    '7LOphHeeHfT6hE0nOayqmKlgENcnGkfjNnyvIJp1uHNFud3RKVrBJsTM+L3mWbml2FPyP7WwWyWuc3YSjYDa5X202Oq7r1++e/nj'
    'zu6HT0BXbxUsVqwMRKzoslFcy5tw6v0u3iEi7Iz+BYOt5Ew2J3GunAAvMeS28+aHziozwVRap/RTo+um2ERBjIaTfjrcoWUKPQLl'
    'YHbBazYbH7rT7tLQeW4GUXjeiWAb4CZCnTYmxxiXlmCpCEc3mkw0dFqQn2UvPYyOJ6Os+r5a3M5pjoYw3B1mAEPP5bsPdkrsqeQX'
    '7De4uSc25jqyvRzqYgerDfC91/QyTizGGglBYzrqCyIGQKwRgo4SWfwYDyT+5uUthqt6B6ElbsXTWXZIsvsKX+GusMBNPBLaTVSh'
    'YSH3GcPTrmG1SwVHDM8eoD9t6nSad8G0HtWntTqn3F/OnLhVmHUMpNu2mQHPhJNPPzMQXu+Lc2r2KJqPSdgqovPJvPWFgehg4ksH'
    '162GzYRsiJjCRKIrpTD1zDhG+AkH/eHDDomGemFfTsKUYv5X2Yd2byGr6GM8EYDywviYmBkJ//THP2JLiXnwnn7ct0LWRXRCRzIP'
    'wfgE0Ut6P3Ub0sPFW4yQutHbN+9f/vji5aun37/d3eF0Ph4cI11ySF1b/Xu0yRdeOa7V7bz4NKHDo0jYFUebURIFRWR6drgotD1F'
    'hwfp61d20lnUEmRlTx5ePBbWmW39dwVta8wXEf/8x/9z50LioTHrPGan79Z8zBsUiF5WlXFvLbn85z/+34PNkKXFxHqsnbOM9mfE'
    '7FT3DjTAuazgqIH7WgultTgG+gn7tYlNO02HugQc8Hwa9MA7F7ZH8fu47NAI8SVdklyyCNb0vZwkEpjrgJckrTI/VcmW/4kACpsW'
    'K38ctrc0Zvot4QSi1KxQyBS8oxvXdF7yciepgxi3dHwuCegNutmpGqGDUbya9eAWYgIiou9HONuqbDGV0ZBP2IeWNWnvdQZ5AZFm'
    'wJOhprd0gqZFAVLVEXYlbk1w2t6m6aKFK2O6hxrMkQRN4T6iRdEppauz/j3hme3Zl1+s0a4Z82fEuvWPfRmDTnFeEyyZ8N7w5+hT'
    'VvCiqnXCJHhBnQ/FnKBAXmR++reIZ31d8svgcMeCitG/dsRi23U7gqlyaeiP0I3RKPe+1raBj7PIdfA3b6h1eAfc20imh99tihzt'
    'vaEWWW1HIGUHgVoZ4Ea2BZOediS5u5LZuALdsEEoQdtjs33o/UTLsnOSnRcSjNXG8vKq1eHTXtju2e+bNlaWO5TDw2EiSyq+yazU'
    '19qiWfI2W84u98W8hwxKScASm7ByXmsTOgjoS2fBGNOgBv10iTcXdxKOMLIE/yXrzuvoCfq512KBC4Iyy7P4wR6b+MGcT6u6Dk8M'
    'eDw+z2eQjLsiwDJdLCQCfau4FV01y0HnfxOlRGFEmRoYMhBnJ1MYWroVVQULR0YFJ6GXWDpQpXntkNw1CR3Us3TEx8QxMOhZiljE'
    '73DaTG8wbq715BF2yiGU0WL0lLMrEEPz8XReCnNPCeVIEEiHqCXtaG3yFyUAkbuCkffsjgovHUFo4bzlMcm32smWKdqIBa2XkOyw'
    'LKT8doRwFDhYce0z7ERvM6ja8jLKRtPyHF/YTjH3BWTcUNOmzFIJzsBdryiR9CXniakB2t5DGojCNF4YUBfKaDDhPcv8sW9DgeGm'
    '9xB/HbYApgQZ/M0WmSKMHssPK2SHsRFd0ASKt0zZxtqa9ZI5oyyjyRce9UpnbWOlRdxGOr6/MIHDjZmOvGBRu0/eXRrvA6USQu2T'
    'yGWkoyQkWfbTptuwfpw3vxm3vxjOnHOEVV1fHgDUsaRiB76NwahvazphAmWBtKZTlJMp7uHSI74zij1fvgynkuIOYkW2zL6KvSg2'
    'tj9+6qKfTjOXXKUptC9Z3MDecD6zCii/osTEofOlKtUrhgQCK5RV1rv5KJsF2ibosUfFUfV0ACngjyBiZYXL5UMZmfDJ8YLU9LiF'
    'cde7Jfhlo8LJnFhoWzsy2QeWhUqTSLroF6lrV0vllb3mRaQpTiGrPse5wqZKnz582P3x1Zu3b9mL7+PTty93d18SU4HeSNqsqKgD'
    '/CLYFqsvtlhCwiNuytaSpFri+8aVPtuXXi7J/enWEg6rI44B0JX3vCQ10ZPHq1JUaBtaadENT5u+f9qYc6OvsQn4lOGOcCz2QKsI'
    'mWxXlkbACFSF0W2VRS2+NA8RM/VH2WS0VxDrsg+CMCICCsfJInHqHctMe+y2Eba3nLQb3y5QQpwX71IgDDFlAVkm4mqcnbFd1r2i'
    'GYIWl47Ngoe4+U2zcezloaEYptOi0iCp/PYJwJ9IoJUe2TwM/V5J31RguB+K7U5fvzHezUvWXrIYaPPYUr4fDyaVKmjlTHZKWkVe'
    '+CpO+ymrpZ1l9bTfcOXRkUUnVx0LxTiecceZ9Hk+ig4zcD7fcOLN8JXqFNMjLuHFBDKZaObd3uGFti3a0509o/Tc7/RjUzHCkJ9s'
    'y0NzyuGJS9ry76fo3Tu+MqosBZwzwxObkE1P6wn528e831REI7u/1/rD4TPibDh49uGbMqXNLL93ENFD3AooSX50ZH7vHONo4J8I'
    'PSO/RH7Fz/zpYADW+Q4z/Y3rU2pMFs/qW3T3befwNHqyFf1JeQTOqS28Pm/OCV1GaXVieTzaCQVeCc9gk3GPglQA5wgTcQ8bdMsC'
    'Cs+YI3HB8UmwxaJPwgj98x//g/dZpM7xeLbNy3dwd1ObyvwTnyrVmbSxT/ysXpPpK15yq9/ZZhcvR9NjZw4hfC6U6mC4iw5xosdp'
    'kdtJKl6lg2xx8kP6apM+nZeTxUnhGbmbC+w2J+fw016Tg9SQclwjfuALj+aUuAxxJ+yEo3UhzkX2pR0djvmElkVYO7M0hXfsjLPT'
    'bxBGGF5EwMYRh8Axe8SGfcz4xtF+pSaDLx6m4xM8Fiy/rAWSIMAN5FtJ6y+LQZ0QORhwjBPDGOpF/vvs1MpWuLd/Xs6G/39vb7fd'
    'xpGlid77KVKUegCIIEjJLk8NKZFHlmVbU7bkJdHtU03CYoJIkiiCSBgJkmKRrNVXvc5aMxczfWatnifom7k4l3M//SZ+krO/b++I'
    'jMhMgFR1z/RMWWBmZPzHjv377dW/gwRxDNYJgP9jarIpmar5F3tTbqaMQq67rssRSxktgXspLMK0yO4lnAPCl1DHRy9fFNXXLwpf'
    '4CWQk8L3ykHJyvBN+/AcQAq+OO7bsLSUwyP33ol+QYlIoPT1fKM66HqreNEu2zM7Y6VJe+pLGdsQtYrz+d50/L4gdntYbC5/l30a'
    'zetdcgZJ2QmtckPc+o94Fwdf4SL2L3n5Rr0KXqpXEi+EoAiZtcCCm/VkBYB3oYoWzEzTXTHA/nR1PRwIISz/KK8k/lleZfzTXUr4'
    'A5Yr7LXowQ/5LMO9Ib3GIf6UngJOQwpD9VBITZoNhl4OKaSrmVmX2+h8N5FOy+qaEge/HBBJSlJgxtWCmu7x6DSjllvu7lbBaore'
    'MqNuhRlWsaqqdKEtt0f45m2zg3cTz2QnxvnIoxH76q4B+WX3bJMFWFfbmTNqa329bA63KqaQSo2n9f3KYCC8Kg9RoPYOioe6y7Ck'
    'ZxjKTWuqp7BU/cT5vETh+ONjGPffSMJfcQDC8xN9yic/vvm2pG75NDrv8OgL378KvS7rVdmLqLqGwoGfoCsa+FqhoDPE1n215IMm'
    'B66yRWP+azOtU+TeByTTPXqhLODS9YHfxHjsvhDZe8D9kDGNz22tSpD64tMrpWQW16jyzV/TRWc/Lut6J9UP8su7N6OWi3ehmvEX'
    'kn31tdBuqHW79KWIHAzUvA0+ko+iNlT0rLURiJxSA7tqzIlUgyve/nL1eHnA317cAnjqi5SCQlzoteO6tVggQ8R9Umel9tqToFUv'
    'YjQWDUp6ASR2PFAH6fZE53Vi7H2ghlAmUphipCkUli5DarKyWifMLK+V4sD9K62ROVOORbXWbRMDW4KRn2dz7moVbvDoSGCimNA8'
    'UbZMIaXWLgWGs2O4mlOGknflwrsXtTlwSp2jcOB0V9/bgGEungt646nXMUSxQGlDvY8CIBVAUToKt6/KMXfOv5NtqksQjd3Epjum'
    '3c0cpanor/fMPmfJ4OZMUab/YnCvh1naCptT8ac+aw2GqZIXMJ90YVOy7M8goqaSVQsTVcvzfJheCdcBsDGpFxzHFp2Z1VBP97pJ'
    'Ak0dclXS124yVLeruvAVWX+08VgGcQVpmfJDo8zYuCG8zNMkRDa11txWuQFU4Lx/W5BA72inrJty5P3rhmjZsMXuGoEKtvdvhrLu'
    '0nZulb39A/bDaXalLtzkaQ/PgfWUz8j2qtXovHDWN1OuB6xqXcFm6HOO/7Q/1Vzk/zTbWU9Ozqv08KQNwEfo/+us7yBGSv/qp93d'
    't294Z53l50V2PuWt5SfG2MiqSn3QgxEBoqAMHHv9Hcn/2wFREmdWaqoytkhSUj9lJakbcTNXRNvrdHq5ftAuLo7rhkpLPplOhDSV'
    'j2EMwRidH8xhOiE0XzJDhIR+4xI8dhMofjq9hHennFCREhTdcJoW0K3OT2b5+fFJJT2kRhZIvSn80SgA0Ht6lg3ORw4E0KKEVYAp'
    'DmeQBWR0IhZo2BcIr70UYQeSPi040t3WPCnOznEPoxkhC5oWroBKBDXK3A/HSAgh9w1Y5nnZWPvyBKMU6igbST4YZIcpQgLoApSe'
    'g1mbJS9+fA2v3lkmswRtFFoxZ/JRQVxGmRFTb+mkMLP1UOYjLTSN4k/vvi/oAa5B2yJGXGHLHa2hIymuz17pn8qp/pHLpPqwiSrX'
    'TY3+Knr8VS4yt6w1LEh88E0+M/dDK+/sOMGjlzyXc+qsDOeRz9/R/8mcF8PegI/ymOAPyg56j2Qt++bt7qsPuy++fU/vCHXGTI+T'
    'tW1FHqbpsAPZ06yk9JCWEvSt2kja5xNQoE27B8pNUTAbKiz/PzJdz1fv9B/+V7OW8edr/vfVD/znJ33ryrz+wyv+/PrV9/roJ/v8'
    'J60TqbP4A0mv+OPHd/xXWv3uySZBFmX/P+Wr7z7Xf77A88/x/Hf+15fu10/a0Fv953vtXIkqzT9faL9/0P5/984aJDYwHzEDhf5C'
    '7j39hfx7+uudFdJ/tODXr/9WugC6//7HF2+IevvN2ze7+PHZrVuqr9+9/dEt1fovbT0yN9T534yOkH3+Rv+b08/nhlv6Zi43HTzz'
    'bya5++Li+EaOz8kNKOcNDWs3CEK9gX3hBjBDN2A/bkhRb5Tq3ii1vQFrIcclvbmQE57fpOfDUX6jiU47j9ZHoXmsnukwNJIxFezd'
    'aRMRQ0PQTFSw7bIo4g/VdN+VPNE0roTQX+R1MRxdhJF7lyltMG3QC0gLQQKDMCMvXNWFA0apRix8TZdLcONluQ+lgZ7cB3JNqHqx'
    '0kn4SuKbsqpqRsTzpxsbA7ottHAVNSTMrfdkISy/32KKzD8JsqssTPULcvE8CYv25vlPMiTLhddNZud0XPCkZk/K9aPcuiiBycDc'
    'W/IImfhoMEqbzienE+TXkoVQyjPFFZYeGwFyCd2Dutk9l5Culk6GCatteprS0Lmk4eoOEoP/P5BDiAjqYmdTztNoPM83O+sjnTni'
    'hdwxogo+bdRZ5KmjJS1OXgxQ3RuAUtwcj45uLrPBtLOFA/vlF929dO3PG2v/YXX9+X7RX33kOtIwMmays4EtWlReZAsODM4jvF25'
    'quhswdMKDorPNrEgcT7ECHc5XhGkXSvqM6/u2I1r4pI8bNU/nWUUjCc5tAVyhU5yRgjM4FCytXimO/WaMEmNfYjzAEZV7WreofLv'
    '72J3vlRFZpf2Cymt8kv+7Ne3JnyUSA9fT5pWEXmYn2xUduQFk/TQqeiZvN2ojyvtJhc1ZOQKCTK/efxfsHv901vn+8OXzBQt9DV0'
    'tZc/wygQZ/cSeUuZUPOJf+Dyl9ODYf1ZW+TZG2Lq35zMOvsDv4VdlnOZW/td0r9ne79s9x9v3/y7yaCYbhkdtB2iXqWg7eW1VKqR'
    'mCme1hyR7+GHFkUILbWq1bip0PNL7WYjCq30mDIWj8nmI7dKi3hm2zIFxir2RoW5QaBBTIfbHK6A85oL8/fWjys5Q6r5zLMOFN9q'
    'LtpWF187R4vAeSqBkU6FMHpqmdeQiGOslvbCSgmRs7TJmfmYV+NSnS7vumqXXDCjzmuvwiNXXVOd0ElYcrLg+aQxoKVdpBdO7IQw'
    'Mpq3CgQM4CFY3MlQ7w/62ZmOvRf7+7zx3QyMrw9CV5nA/VDvXdd3c+WAo8wb/5h7ul0JXdE/n/txS6XRPnKBLWVqMd9KFADjv3c2'
    'apMtiJRfcbdBMGg9OuUni06xGWx1FkRhFFnGqVOpJ9z4MLzIZosdqKunYvGO0FUfDeOB4ZMdPN30G2LJXOyEUxF84o9b4B2BaYgZ'
    'V098nPeL++wwPqP2cQublvoDDWr2X9TkN8aAprPTn0enI52leJL0KyohkPP0Ovb9K8VEOYiRzBgoKsop7SZfwDcl4Wn5GfH75XGR'
    'Q+Bka4Y344UubS/Zld+aQt0CbZAmFZqHi1ExmkPExkGCiVcE5GwanJZwOZXvv1/377Gg9c2tpzD2s+eNAznheXVFq+sOKV01pu6G'
    'AkYK/t3UGm6x3fhrM1CeW7tuh0SadQ27mVAfGxOEB/FuiF1waztFfactZgS75evRbH5V3h0T0/hO3L0qf8fuwfaOZ9IIWHkma4R0'
    'N/CHl8UdZKCXdtcOIewPc3W2oFdGZxPcDbw5zicaMCmsoSJvyG5IaYoHWAQfBbsLYp/sm2C31N1R7r/hNWyzekkkcONdT9656N9L'
    '4kdQQXE+KwD4m6p6x3n3ogtwWlZMEaquGGw5KzCcbIb+B1gEnJKlBvbC3Y0VTWLsKRpfoj7cvkdFOt0pQ9bAdE9Fmzmqed2+mLc3'
    'Oj3soXzyYnIoDFM+e2kqqhlFkEhPVPsQuFaeVfB3HBxbC/X8jpxeZ6xfT5J9xQE1sCb++tOmm0ZRvl46gIWzlRRNfElRsiJlA1WQ'
    'ELx5eTZsH54NLYgscaaf+F5vZsjKQ90wI1FEefYxO8SRll3V1kien0fzk5fv37vQXx8BvOgrdtGKarhbeau4+6Fh6TzfrdsX7+yW'
    'U7K47eegpSXwlv5QNcVNuAMOUxk70/TUvJ7re1lVnEPdeMGW3qntQ7pp+GUPrmmnvdANdJc+xRpjwTJDbCCblFXV9uIw6zAX1jAL'
    '4nnr7J/NbxVf5U4vYba4BnJTJHvq9H427Jdxocz1WEoSFojOJ3G1ti/ezwGIFngUnw2r0ehL40rzSSWBy4B6r3B9d0pPoJOn3eTk'
    '866mIGMYbzeZzrLSMXTCbwIPSFS3g/8GaqFAJZBQ4dkAMlVuVxpgC4UbC/eayImFT4MZLMERFXJampIV8+3o1ipw6szxdZ2TbhOM'
    'yhQYTRGPRHYaquX3qBPOZ4mrdD5WbCKUTAiZReQ0FnYYAKzVRVfGB1DfEShZwyLgfitiNAGMe/LjdiWMayAA8XT72QCI2NPtVswl'
    'CqVT36ZPpFoW+6BCzuJVT1vy10K9GJVfm+vrLXfUz2dgt6az/Gw6R+qiySk6KBQSpkZrrGTYUBpMEz5iSiRXXdhRrRIwhqUK7i7l'
    'm5SWBdYv8Yeweofj86Fspdb/pUFXD+KnaBLmP62H7HvQmVVUtYTUozsVWRhzb/45teU/eJZS74j1zopD9vYWIIf+j2fr6bbqMzQz'
    'E/k5T6xVujdnN5SPNgRX+oX2w7kJXi/vuxbTNdC+tuL0a4j4fK5qLexX5iE+ePboWp7c2sa0P3ym788xijLjsBHf2kywt9vP5rBE'
    'IPFlfgkPI4Io67Nnc1P566shQZ7L31LMcg5ZTeVBOahQNyRCXrzR50PAQ8Fg56Q5lA8LpBSA/fbDaw9oYaThx/N5yGHC28GqowwV'
    'GhnmM2siuKWYsBp0rZq3HFkRP749arPNLjOju2KoveGymc9anX7T+iJ+uLK4SywjqGartHzgiI/oEy7/PAtznrvAmWSEfNizZRaN'
    'snJZwM69Sg5mXuPavjvz+47OeW/+VT4c0fFHlbJ4ZkYVWGB5A0W1IVAC+/MrJhdpz7rJfRprV1tDIIasNodElSWZSrYF8ax01fZg'
    'ANVFkm3gFykMvDaMiaITBa8tmLV7dB1HjSCRQORLDj9hLWSJo7k67CblZtjDNl5NnvT96LcM6q9xtCKohrtSpslH1y796O5Zirsk'
    'CxNV3HA6pFY951TTNRyuklB0bEeFVVZYckSSusu4Lh6qv4r3u6my8+qDxUKe2TXqDA0djUMZeb9O4hA/35u3TdtebNUUTPTSWdwn'
    'Sm+MZ3BOnwt0V3fUE4XXXleCUD6xTw2xxIbDlg/pkHQ4n43/kF1hybIe7NjyRzc55Tv5OOY6S/e2egTxtXwgLC2aN4x4RrxEnXf9'
    'VN8f3deNYckMYiarkWmCa3RR/ozEp+rfXuv7ilqu9V/2i8fttbW1m/3H+H83Hz586MijR+uWOD34NtTnepGiaTw0o65IpSvqlcee'
    'wmtnOLqg1w5cvfR+WFC9RzFMahJkPhv9GQLVGJnmWv6c+RnCmnHj1qK9myc/tBtsNVZ1aibIe65fsBg7FvnDiwA/72jidGETnglf'
    'vB9200GrutwBdzEeqUjSVLub46jrrfx8jiTDpN+aNbnltTWLD1McaFEeJSC9PUeHmw5Tx8nLP0gxkdYzf4rw3f3m3RglfIDLCJOf'
    'zb8BudlNj9vuMVZCEdBAIPTxpfyyiXVW1CZ4kLTkzVLaExeMZVF3FSSUENbtlOk+uknrA4PhQotyt2pRXj7fRN4N57uh6Xp2EGHs'
    '0H0HhIvcvDvqxYyx7PU7ffwFJI0j+govEXO9kZH4304grbHjkaRd059X+gKBEP+2Q48b15A6+lQYfT6sSzLBdda9oxFFPO6Yx+/i'
    'CR/O0mO5j2duzhtAJ+74Pp/Wz0dlZXC57hL+NJv9axfmQdPKbDXvlEUQGpZGOi8ibhCU5se8GKEcfKp+BIrnju0sKfF/25zLzz9C'
    'qlhsQbauSgM4PTAnz99jTHjSy4+O5G+VX8q/3VXp1M6zCmmMu8lSvo+d+NNlRZsHww4v2tvmp2zIDeZUXCRn58WcbqnzLB2HUpzH'
    'IFbHg8/+WpVfCQPX4JKsnschn1Nf/jjQ8V+hbhwsuRjKQByc0Fi56JzHTdPX4DzuT7aGL7hy0BXEjuO3EM9Ld/TJLrnuheEcFw2e'
    '5wtjOS46kRLkImqoGiNoV7d/z83SHI3CCX19dlwPR/FvFsejOOoRB6UsDEmpbd4iGgWZctx8UdCd55V0h38tpDCy8hITmhjahHuC'
    't3oymm+xDAHF1GVaDWbZsBd4CL//8HMD7q5uMcUi2/pM1anmQymlVxuxU602k3AuO6Hnh8JXaFeeSx2rSWv6sRXptP1CqLd9I8xL'
    'E1zxHVcvZDjssYtA6mnqE/OrE1qjfThOz6btCEA7uyip0dPfb3RDeO3HyUbv33c65ZjKxs+n3k/72rRl6E/zqCxcCP/4cNLmkue4'
    'yM6npjhZglJsS9IN3c2axk+Hs6qJgeNYuAZxbxcWK7uKPa5dbTagGdqhT436PkN6VRlQaU1rTVtxJ+UsvFCDLm53OIymkyu1BwsX'
    'XQDfnfSeXszwLFVrenECTT/uhLP0VIsMoFeAW6FmRciQJOFKMfV6n93NjLgo65h/YI61nUAbjeDvAoS6iQXABN3BtvwbtYJ5cxqF'
    '5ETWqdikt8chEj8xGEQRxQulIIcn+egwayYh371+s/u+gYCw1gpw93d41oaLkEqxxJ1muSYoFY8RBJMWP9oKvtllqSo6lZSC+xCB'
    'UD6qgSX5DrvARytBqtL3LpLJir33JXzmkuYzxRF3XVutJ5TTNiob0/Augp7WY+H9jDTPgzdfBjNBz9g4SLzUV/jz5StuJNPsv3qx'
    'SOcjO5j/0AceV6OWAJKAGJtNRPNIY96jZAIYa2gYBrN0diXTk6UzDdCpRDfthsE8RyKaFVFQUVGtClLjEK4aU5E6tVXFVjDYbApv'
    'Q5xt+qlYcNNQOoCq6dEkW7tlzn9d+pAnbRe9uJqYDxg+8SgMawiIZKg71Y8KWG4w5kFokIKfB8jsLvTHdd2F+fDjwqIifkindXD0'
    '5P3ffptMZQ6mcg2tns1HZ5k1Mh+NafcmIKJVvNNDa5CFp6EIYm/5klavv8CEOTWkw/CtF0o2k2lwRoWmtedV0z+ScwnLeSnX2Do8'
    'jzfkOpwD/GOkqaD3vtxASHAmXwxb/W6if5+NJuciH+Pvp1/I30JxZ/zr33cRNn7F31/0Pv8dIE+z7JR/P3mKL2Xfn/DP1xN4585l'
    'N7WuZDu1+n1njQTXWMWS2gPX0CWGZR8cNDsYYf0mzxKUKXXsE3fvn6Uf24g6wu+jcZ7PhLcsVRsTr1+3UWJu/3TOUJFLHP+DR9eT'
    '20T+g8Sl8g99tQHsT9rQusXEHjgn9Ytk/Tn74VxplaG7lC2Yz3Eo3Jm6lDU18QT5wM2hK4PxAtq9KU1S6qfXYhTbXPF2Aucrv78o'
    'I4UrS/UVOo4XPey62xv7g7sPf7nwf0Xypj88N3LvJC3ap9S4OCuZPgc6Lp5vBc0AyVPv/G4CULxu4sDkuon6AxOf4/Tl+ewC3oz4'
    'TdzoQhkQwvhfHBvieqsV55VSYCMIcgQtOhvJzM2z9n98//aNhhzpTw1jGB1dtXW4ciuOsksGeNayFMjWUZRVJUeIIDyfSrVDpjrK'
    'P7OUVd/MFIE1i9cL4ZCWbkX9jicgWcmf85xEEkGH6Uzv2FTO9qQkoYilt+DL1GWyKnV45CSLw2ziXLm7BNMdDPKP8HK/DHfyoAcG'
    'G8fwyy825OVJ/PLEXn7hcU+1GcDXDnof5S0qWE+eykHnv93kiq+u+OrEXvFf/b5cn4Nn8ptpdL7KPzLNLs7FFf5zif+c3K7At4Rx'
    'sS+KqQi176DteL7y8YfR8I/yv+Qsy+YriaYa4vZ4vgJXSVjRdR5un61LG2p+Dq6ucIvwpAntSMdj3Iftv3L7GRKtqShtjxe6x7uu'
    'xSgRgT5q8HwBt6AwWp8I7FXPLhOl3Ahdjt0tpOJjp6GEEXVezcG19Z4PVNGnL0v0Xvs7BPClbuu7t+93vXtTdN3plvB1C1k6L1qL'
    'rAyu2LezURXO7uDZcHThEEVRZo04xSvbfwy5A6hK9AAVctQyC1+Ok1MiKjtpPxtsxzzqmqz1+cdn64NtcA/112fpIX0X5RSjUKcH'
    '/4PXEyW6Tl4QLoRB2sUcmBxgRuRcUyIBR4K7Wf6elHhpvWfrMqzYeSLE7V8yZ27ILmfCNyN61Sq35CYBiH5ukeyDSlqWkrv1y6bu'
    'Uel01G6ty3/X7Y0LrNIz1s5mM7fid/R03cXySbuUA82qJTX0zrKiQJA2hsGdqvM5Twckl7OMc1hZQAtECPlCTEFQX9N8xsMOPGlK'
    'UDuZhup5UsdsN8JvlPukxBxlMlD37c9ctnhgazMVDxB5fQjTXu/x6s4vj65v252bvf3+/n6fYUz7+4/+XSv0vDwZHZ8QVaeNiQST'
    'Ojsz3gX3n1PWF4d8XwXN1+Rm+okVxT++GwphcPzq47TNjrZZUUduhtbxCI4xlrkd9BVkVigsfx6EtA01miv5CwM0yz4eZrOpbBxF'
    'JJ37iAKjMOiS9BPvzMHaYZVrKGcYgTMZifjeMHyDToWZF/OLr2pWX0xRin23JjzcmMuzsWSKHPc3YhIgqcl74cxNdzUC5OcGbU0p'
    '0rBtwAYAv5iUBlhtbLRlbc29i0zpJKifef4oTA2nRCG4keUqluJrye9wV2eEdtV3ownnw6pnqVW2uZr8fiNcm7bWKSfKAXxSqOXH'
    'yvyzAGvvNIKiAy4UTT9LghbjCiuJEsqjVfonBgQn9kb8teG2MYh2Q2OPFtV2gHz0q8iGY7kY2deOM8F8lefjLJ34xXdGHCfiqOEF'
    'fphHperNRSo6vleh0G/3J/hNzl1/YgJuD+q7zOV8QM96lEPbPO5SY6l7kf3hF728DH1ypCNhG5CyeFMH6MYzN5MSOhQ3HNXsluVW'
    'MdCbZsMsCFfv89k8nHOgx3n/XUgyhK60hEAIHR0oKGXP9YKqg+xlfgZXI2Ea7Xm3DITpUmEwgRXqQoQ02SMIV0bqUstxW1aLzylV'
    'yC5P3W+eUC5UgYy1YWnOEcvqLzl9OiQtVAmRi1c9xoRecknpCmhxlxlJJSD39BZEg6Kd0S2IdsTa9ndwIcIdM4AlzAK1dI8z85PN'
    'zcGd1R4EvrwiD2B7l9taONojxC5VNjeoaGVkMMcbbdWt7anrpmfCXPLDeeqOBlHsTIotH9wG6SCS//U/kwOVbvH+EBz1rQWX+Qf1'
    'UfGsUQcrFaMO/+BW5Sf+DiomMHZYmA9uyaeX7+uzZ4I3P4JawzadZaXyRzJiMjHPqBPSMKvEhP+YKiF0Ts4m0q8ks5xo9rT9rYB/'
    '4S3yfGXDcO9Ri3ME1jo7Idg972DodtxLeApbbHbYKYodkH4CWZ5J2YWLtOIL+/wMEeiuokE6PBYxiuAxwpyJFCUvt204ruEYxx/K'
    '43Rs49E/Fo7oPfShsjtUXYcOq5pV/14DV0evXoP3bxgp3H39FFQmAW2gzpJR8gRJt3M8I/HX2NnOCxu/713YrY+OoVP77tE1T9xO'
    'vI3svMXdxcNKXw/iqeezQDq4DfIMBQe6o+Sgdz6hz1C7mnvhkPmVs8sVOacqN73JLl/Kw3JJoEmVtQhQnIOsCwu8F7RRBlM0Ec5F'
    'spqIsVTWuiyJpJKY2qWUkqTSSUqOYi5uopQAldm8yuY9JzowvSJVw5ACpTHNNg3oNOnT6BAqgi4EO+qMpaocOp/JFeRB00tTQqRI'
    't0g13YZwYpKCsGkD2MRc9zvhVdQg5urElqkunNhi1bWb+C7/LmSRAeT13At9Oz3XOXVfKbmhg4gqNB9X2R1JdASw922fGTGA4W9N'
    'S3uaEJKDeT41OUAD80dFjTR8DAmC0aMo7UeySAyL9QSD7e/jBdnkkj265pwgnCUaMq4Yn43kaJx9XBsALnATe2Jle5JPMkcb9Wy6'
    'gbvz9GI4/KYyEjtRgHW2PgjfHNO6ehe2de9nQwoqkREE9mXwfUSTPh/YsCqbmoKy2T1Kuyf9cKC0xOBVZdlzcxsA1Z/u5pYToEQS'
    'GyICGfMlZUSQO2u3qGpxoUROUXkit7+LClafCOkZrxWnjmZv0qud/Un7j6YfQSixS7XNix5g4r1OJAVjQLv5+SwUKYKOxhAM4zwd'
    'OrR8ZtjRHDznM7iWxcweBN2KQiH7mJ5Nhc3VSW+F4PYvJu6tG/GmyWzst2eBAO5FRTzwDxMVgQ/hFnM5cinPK0pAjA/+TRSbeH36'
    'cdavb/gXc0G8PBFD8S+fndBjY9ag4UFXyKG0wMaz9VukvAomdWbs4qyn2cNmeuM3qIRs5kLtjobkVsav29icd1AZkqYRFfT6Vqei'
    'VOw3db38JBTIZj1NaDbWkPtSqzXbquQjvg00xnd1vUKx7+1vq1xSox/rXsBG9Uu3Sn2gzqt1H8BgzbSgX7BNa8s7clnTIhhyiBiU'
    'gmdXR+gtW1teX1Hv7cOAdWgFQm2QoyKWUJaMGd0NRozSnfg00OThU/1xn9Fh5M5lWBhD8OldMt/iqqM/fYz9w2SxN/ddAzKX4gVX'
    '2v132NnS3RXcy+EmO+vExy9S9K5Hn4U77CzYXSiinQ540wUbx9+Rmkx3YcMyatdqCPkbcIYAoLZ4mvI0R+UcMr5zz2sudmfmEZcQ'
    'YlHyEWZIz88jdHDeC7vCN8xG6TjMGaCZb+9CaW/Ir91JYBfi5+5V6B9IZbXeTtV+om8ehv27bDy9s6OlsSgo6W6ZaNjNwPGfihMf'
    'Vmm7v2mK7lK9P1haYKvGPwfo9BhYNC1mlpMCZgb4BAqz0I7WXRrAtDROaVFsj7/uzB7nciMn4d9m/IwvvapBz6LuYmbitjGyZd1C'
    '0fSEM4RJa1tEAe8yHt4jpsq39jxqjSb3XHnMLBlktIrLJRfwCmp6eB7JWkmN2LuYCSlbuYL4rHoHLZqaF0jX+zW2xZJON03R4t7t'
    'BGu0KLCqgrPAruStZRdSCfQCy81bWCd/SBHTmWka2xLGGwIwvdCS9m//+b9TJkFeJ4TKCtM+TYfCwxdEVe4EhhsCXkuNajOPJFKA'
    'CGYNsQe7syz7me/KWAEwdV1CfnxDpXbv/Xdvf/4A9I+uHYr08DCbMhhhUzEGJ2EUrL99FAi3mzwUrnyMvDUBLjPwwsoWvnn9/e6r'
    'dx/evfqPr17uCpGqv3rx8uWrH3e7XhfjI6WFyAC/30bI2F8iuQqFU8gmw3KFLjaXyfkD5JPgedWAB2C7pS7/e5Sq4RMVpAEOAEa4'
    'O8cu9av7FTXvX2+FXwTV8bs4y3D0dVjUWVirSSOWZY7WvXU6IDfJ1LWxQh57+WsQ8uS06izw23/+Hy3vqJNhAzsMLDkTcTeK6f36'
    'QWxOwO9NYw/S4E9vKMOmysdjWKHpx/O//mcC/98kyMYorwz3cyqS+0lY1D7OZ/oR6Vftw8bktOlxUXGefMhnXtYnDIEB+BUOHZ7p'
    'ot4OipFIr5NN2McUTX1yDs9d+fGhC9OKtL1OoHGieYuoewx3uZ65aF6pf6tI+lO6JcHqMwvw48yC27UMVhktvJZ0RoaKwgRsAUlW'
    'vRtkNER9ysULFcFnBCctDd/mT2rAg+b6lioEcVu/ghR4nMKvSuYSTkQFMlp36RwgclMn8MzcffEt3BDav9zs7Rft7W6/87C9tz+9'
    '/v5W/vPm9kM//GN/fa3/uLN+fO7QuKXNl+nhSRY5bNKx88jCGr2rSwDOcVy8PWpPQrSWHQcwaLLTnvdfnCvoBluh15zDIgxTy4eC'
    'sOX9WISR6nNb+xcBaGr8XHhHffzv3IU4twAWjPW99IXoE7AC84bFoZHp7PSpQaSnwNne034FBLgMj/tIVdL6L3v7Q5nXVRfQ/LET'
    'EB4/dAaqbGue4nJCiA7nmJ6ybDlNsuad0slDPRDNN4HJE7BpZFZVF6U7VPcXj82mIdV9nNc2rXCEp6Mpge6gA7ZP27kmQ7eiaGaS'
    'yaYdyEtZXXPm8xkbZrMrnwJDOpKOgSZ0lYwUlC7liTK3wLNsPC8UPQ8NGDZjtKs013J0sSrm+fWtHISJz+Z8HYSdTPAglYXrVG2r'
    'aU/YjrVk0DPE2hD2HCd2UnTqbhNua3dkJqzBvXk/2dnR84E906EA27Yc0t6hYmIJZkvEMN3HG39F2+VNJ+OX9qv41ib2j1OmkCcA'
    'E3Zy0ON+r6BojleH3sXD+1rwRzoopMBaMhIu3o3GLKlrSaVEJ3mGvMtbHuMLqIJ0Q6kgq5wqsspp8qxaJ1y48dEzvgfCikLQYBRt'
    'YkAmq8lpJ/mbyofStjW2pNC/thfB1NHl99+mP1R3Wmv+K37UXF5XW8rYyz18Yhjztp1YyWrypEIT5MsY5y2IS587lDdP0InG6P+G'
    'sAOPmnmAV9cI77yL2HbVsR3ABoqj//DRtXt3uwkDNI+iEUgyr35flw4evraOdz+wKIUe7jl3zR00sgp0vULvNpN1lPzT+RlyN5GK'
    'GWGKOYkfzCAH3W5hF7W5EeHYgUBS60sNt3+eQtk9tKeODemUevBhYZ5enzlM616yAqZlheaIIuAgiviS7ylaBa721LiE41zTSwmj'
    '0z6fQEtEtNEj+nlmw/C+17Gb8Kd/QAzXX6+hPorevdaEQq7A96Mifo8HLpZDn3xnwQ79slKhcErJYv3+SPfIPdx8WbLBSzfoYyjX'
    '25uvdPbCOrSox+esgnOXXaq1qV6MYS0l+kmptg9bDa6hX+mSUunrAn+uQ3dNBTdaEN8OCACHHR+i7rZC1uW+vE7Nc8skA7gSDZvA'
    'BXn78IzGTJfGfdh+BcgSzmssgQPje+KybFv0EDVe54av3QquB3VmKu8HEtlfO/75hj72kv+vEb7Aw1aAmDpX3zj69j0xTWJJU3jN'
    'kRH7SLkKXouukc+3ygYavwgbpTub+/Kpi2Dx32OCwuK/BqW/2Goqq858wpTvr31Yb/fh08emL9H0ZaWusNMNlXnK+WvUybgkt1ZE'
    'Z8PSwULoIzAF9nqo3g57/EMkpb5nOe111W0NcGQiWBkqWbBr0r0n/U7JRQRvBsGb4EAbtXHtcJU3usmTp2rG13XCpyEN8PQoCcha'
    'JNyWlasTmUhSo5oPmUqWz716RZGLFG29JacUIWXtYAhv2q5kR6Ejy52PUMuCSa4ndPdmVJ3Jjzgj3pQa+aFRxH0e3JB+/J/r8Od1'
    'L4b5sTfol7L15qPrQ8e/3G7xpzwaTU7fTtr+BbyuHpqrA7wRmpwQmr3FjoZSmfc5E1YcTmFU6I2I9ykVR30c5vPmTu5+9+qHV+/3'
    'nBK93ztsFyfpMFO+F9Vor2IPgjPnpBSRp5gg/RgQpJ/8svhhEtmxuI3q5fK7qvV6d8Uj36RggipXRTb7Nm+PwotiEu29vVHfR7W4'
    'q6kZ6R00U606EbS+Z2inwTbdkr/cTt3imzftacftTFbOB4cleOe18draQifMj6jKpfiDraAvzvvfpQSRGR9C3a2mnIZkFmar1XxP'
    'Tvii4dG1HqW+/Cy8VxcDzAU3M/woln7TYMZYijnjgKM6tfSwqq0MaIyD4qMGcQEo8WpWGqpH5ung6VZnq6m6vaBEf6enerTXIisz'
    'v+K14hXLzp5kKSBQW/RguP10GLh4J95ho1iIieV2fjysRZWV9oPlFTqy7oXUgIb7C+VJzJSuQibl+rXv6sFP009qX4MVwjdrlbZu'
    '79yHEYBgLfXmtfM9JJ/qQ+BLLH6hMxcOsrLTWcDQ3spd+buNju8Lt9X90EQCx5NFNvYRTElqVb9zN6zOyl2vKNL1TKB7e3Ri7vch'
    'OynrG8tq38caXZd3YW8PRF8/q6mB1S96NE+itB8J/B2FghExtC0EleGsWtENNL4TahqlTuiH9fnDQrGP+8KpJLsniNjSys2fMo9C'
    'e+Bv1uWGyAilDW2brIkPy1cMuBJ1adMRWzzxI3IJe9AQ5cBeQkxJqNCRIi5ukqrq86nMA7XKrmqPjqOfQgClBi4bMcwa+B68guFS'
    'JOeIwoSM6li4lEC0/Pn1H15Dl7y/t7/X3vtlH2Fck5uH/dVOe2dz7+FN3z3rP+7syL/99WOnRy5v5lK22dEUzlXZZr94vD+R/5RC'
    'jEFiN0hh5H7rsdzkiZukryBQ6E6dYA/NqIpimdgDCoJAbwcDWzoWAtPvDXUKZTICp1xeng/ykxJAhhaiUk+NtYoV1U/6PqUc1LY/'
    'OLiXMhBN9zKhwCYWyqFbMTiUPgFSQ84ol3IlMnxq4iXTjfop8Vp+dcb1C9qJ4oCoh5r3mBlJOYuA7cXzMP6F/X4uxAFpQVUCJ7XU'
    'uAhfMZdh3NPSrtaKFDx2OS+VWxqzr3RDxHioABzLNuj4bO++mb2xVFcVqoXuIEdM6rivB0ynSWHPeiMlKJzmaKRSWUUSZ0I3FIHC'
    '7/VwdXXLRf/bR/IJYQZGyKchDW1yiLANdQMqZJFTail4l8mJoabfEcfzqdBq2bl7e2+RB0BJEXlg6OqZUwy0d46YcaEjunOGOXCE'
    'BrMsDYEXZqg8A9Tlu+yoaOfj4S7NZbInGDQeIhDqEoLftmJ3koUOjV76jdV49zelYz8aJApyjn/8pkA+1Grg3swZwSx+tLUvxA7/'
    'v3jM9AhY0/tFuwJkB5+1d57L532hoJ2WBaAuUcdQ2C9TCc6yOG8gQQuznrCc81IADpMmVexlEORbe3voOlN22lZg7Ep54nH7qKXV'
    'wlZzjZmheXU4KqSuK1pNaUm6askkqTc0zKVUZTFKN0RZ+4CExu8/6R65+WTrpYzkJS1WVJsGACIWrG5G29LoKru/m2jSbSTLU3Wr'
    'lhGSl40BojLPz+mj3mZKVvniM7XCE84iU0asEMI51ORPliaKGvlzzdxX4AIc5/lp6DfiQGdjlaLGb6ie9R7uIwb22ew4ErtsiIAI'
    'CtrsshFsvjOqv4N0vP5yKZcxMkbhjulox1VhdM08M5vAyKE6azM5U3sYw2/9X7IFz/Y2+j64F7fEZnhjmdNJwL3Xrapne5/3O/dr'
    'ne09Ldtb1hdm3UXdlWv/tmp1ZcORBqACAV5aww2F9+X79zs9vwGp5LWks995VwDKJz7OtFWnSpdjo0r+G+iYz0ZFgb3X8Mp0SpXn'
    'TTlmgn15ZzKFAEQ1CbFTj3qaV/VI9ZmWp3P+Sjir8hVCsS3xwZHhJrOXmyGnd6QYyfLuEhnqbIRqay29cGROgymlobyFcaxdwgX1'
    'EiD9C4tYlS0/fcsKSwdbOplhVjklnEI3ZSpBNgNnEWKfdrEB0slVw+kn5LSHOdCpUZRZd1vdAXpbasSndyPkLoCUdZmlpjsB4u2W'
    '9SN8/klAt9eN++beOLeuU7OdSv6soGPu3dugd2EurJ1wNytnb+DFWvnz5z5nltW5/dxt2uDhs+e2XYPcWeSlNTUBbj2EI+EYAz8n'
    'klVXHiYrCdK98KpZWUtWTA5bedKT3+qTJLeLPdyWZ8xABawDmBGlncD4CM/qreTx44EwSo8fd5PHo3k6Hh3Kr4NDGcgBb+6//AVo'
    'T6fZX/4C3m3i+6bQSiLKazyiTEovJltRnoXDkwgHjVq+5oR+D+RlmAANnBUeRYmCanwV03mO40xpXb/o1TX/bGmqd58kjW03pz+r'
    'Jqs8PHHxDAz4sr/2zzc20o1KGhnq2eLMa6aAKTUj0y6SDHQTl0tsPIrzibncGqGi3wFhaP1Nidv4hhj1WiZMorBjzzbdk7Dq6Sy7'
    'g1xLiZJgGzoG0qjac9BqJUez8IxF/SdtAEeamwwbyvOcSMeCI5zPjMwPHiybRiQLMEdH49kK3bspHBYP3bEgSogcu1TGPlmj7IFN'
    'nbvsDrrFmMQ9Wf/l4fWT7tPbxPEMc1wnexUc59bJ01Zf5hKlP+9+eWfpz1narurtpNVUqFz/Vt+CnNHA3trj1X5YP0RMmx/UogjJ'
    'P03okJUNaYvXrj3Z63Xu/vJt5bsShkPDxc7jdGkWHxOuMlBQqrDtpfcpdVsiDhaQ+0RMUSEBkFAjQ5n5ON9UfpoRj1kFyS1bltCb'
    'rWioTUKEwbLFLsHInGdZmYiKO45taLlyWzdsYGA3entj8MHy/W7lVO73ecbDIDxPmdS/uZqlMU4ptCwBUdcyQVbSKdHQUmYz1646'
    '+DoI8+cTna/0aE7eQ9YDUaHzWS73ESJW1f0Cgow/WZe5wsLzfplkiblqJAb6BaxuYMcaLqP6xjaprBvxjLHPhKf22MX8+wm85lzi'
    'pGpeoNtOE4hV7P8ZTXNpGa0vmtHBlIbk66T1uLUpjNo6cs2I9PlYxMzVDv54tI6TKscVXd2jx6y83e93rFzRh3jKDx7r352djn02'
    'ks+e9PvIpqG1f/gg33xg3R8+BDX3qf5NWgda7EBKHbDUAQvh7rZywCxlmb/8RQr9hYX+8heWKrRIcrt3eNLXqPYqAijEe2FAmb6S'
    'GKAYf3yZnTkUKcp17VnoD//grNmncFZLV9DA/jPV7R1HLxCyYEXHLbWjIp893EwIw+0rW34stVjzqfSmuoVZxJCUxQmYFYf7sz3t'
    '2lPp0JN+2JiDrxfJ2VLV+9wtPHh1ad0J2q3f/v4/+csNakBL25wrRqjqDboRbLfeJziSrptspM3/NpEFvuh6l0zPC8e5u7wG8Nu8'
    'Yh1JS1mGfnEwZJxaius279vAhQFRSNpTDXqnskrd1fRuiPNgB8lvSv19FerR+YZXlf2L3MLNV6PMmQ7ycggPLr82ZtO+nzIVey1W'
    'puptpr6AHzfZICFCnwJB9MoeABj0ydMNwszL0m8a7LFM3XBT3T5a5gK2mbx7+3b3wzevv/8e0XfpNNtU5X5LdbP3VQQ26NRDP6K6'
    'tWJSy1ILN6CGtOnqD/+mPXLiufl2/gANl0I52vqvGODvSpmPUuWE+ad4A8xVFe+l6UWmK4e4TZOY8hvaDVxubTNSpDDqymfD0UzF'
    'FCDKwSO+UM9UNKL6Pli/ZFfDttZVUxvDwXAewG/SJb0N93yGqByN5url6U+KciYKWJzBhoYL81/+qYcWVgCDQWnt9Le//+cVV3iQ'
    'z+f5manNwxHQT1WrGlzpSolgA+Xz4Hw0hksSwFeA9w2C4fLQE5k/AlgNlrKLfXQYWckG+Udz8uQUs2CQ9ZPlKWrkH+9heI6lKfit'
    'XPPL0N8KwZh45izAR8xhryGaZfi9T8RaLDXkjNM5AlHUdiLP3o/gzDb2Jp72noivfXIkEMqfR7aj9p5QVohoMy2xNy7/diXGcZGQ'
    'zOja4FTksg24yYC71tNfMNYBNYU6pEnGN5GlyXNp7zORxy3rjl/+TVl8q5MGeZpkwu1luwQrXEDq+e0f/tFMtrKJ7cl/A98I4BFA'
    'DP23EDy5uMKVb32GtIIvGZ4sX8EzKnjFUSjqIV9JkX+MfNMQO8bx0Ta2k7Q5YLq2yaDUsBDYTZVvhOVD7YjypyXJUmTw5q/eqIdQ'
    '8J23P7ZC2LYmp7TJuOp1NpoFoGNN00BHkKKc0EVz8iY38oIuUHVVuOszXKcWEx7LrHtnOpP9VpEPm67Y1rXxwEGLkfagf7D93a4k'
    '3P4OVWjcU9KkJnPgR5eBiPqNLUYLR1Nogc4tP2pVEde4gKjpZ/qdYxeSoJ5l6QQIPitRd2NkrePcunucozoOmv3d3turueLZ0scO'
    'kbf9fom0tbAdYeisoWE0KzaQr52/hPV9Zftf/ilAUargh9XpjzuRVWpV2UdrhrlGOqnVMj1ziVV1q0NYrX6JZDCyC3WtAZo0GcuF'
    'oIo//MF7u7KM5Y2x6RQepUNLGYhAHyypGyMiuJNWrzVi8PY8nIeAoRiBocC4G5JqyW4kVoUDXxi5S/k9YtRSux9xiViwliaSsNCw'
    'MG6WWkeCk4UGr7JizIteTGeH84+yKqQpB19ubCRPPp9+TB5df/P2za6B7tOLqiFT0WE2Grf5vWzd4nxGRlvrtqABQNbyzzBw1yoR'
    'du33PmFRaL7BClA1Df6jPfah9zjlPCipsiRrnH1ck7NcZiUb55Pjgtb20uhol7tLU4X8MY4NCSBRx5uh7V8kQA3RW61e1NEuvt36'
    'LEgY5UrcG0LlOF/i3nWc96GGGGbLUHzkbYCucpx3arlwlRVcPc59x4/zGlPYzBIW2bjquCftlSYFmTSC08eLtToMXCyHrIJ+HIoS'
    '4ZodO97UX9Mu1ZQeB1VFWOeXrUHY95j5esMBdOlxoT5vHvfmjuWqJE6u4MvUE+NUz6wrbMqUe7RYpkX2WyRqFbISb0GQMLl9WaXS'
    'mwoMnbpWgZUqb4EaRK+6XkVu7PmUBy+68ua8iCIf6/sN5/5Ovp/k3Oqn487cyMs9baOpdXuJhLVTz5ZXUoXmT/o7IWNgUS2NOfca'
    'uv8p2yMP9uRnofLf1dt1cvjyA+NyqFRHbiTWXTGXqer8hwHfOY7mozoRXebDcQFYTfDezi8wCCXZCBRfTEl9QfNKhd1SouP84i0H'
    'oyvyPLmwaTePMHsRkoZKdvjqiVJftwj7s5wPyNoYcdeJhUgAjIehFgbxgHkoCzOikFqTeihXbY7gc7N3A3ebR5yrwPPSRW3R06pJ'
    'IVPVrqiCJncamhJXmZKTRUouUL7cU/1yFitfzv5tVS+JjjXQfdxf+5FYbBgXOXfeixx0CbhfG/tSDz58DEc34QhZ4a2LPwvjcFXr'
    '0uxFXjuNd4v11Zts6YkO7jgj0RXPbmcHF+ouFLDYRFo9ALPTuHDGn7Gn9yu+12R8lGqmXq7qJS+qPt6D7DC3HER44DE5CCUAwA0E'
    '+KbJylf2e+UzJmspaKby7m5d72nNwhynMutJe4XneRMa+bcQaPr9lYqJvwUnOdjl5Yhk42HRoSYIDVk0ZAFuCx7q83l6eEJvsfWe'
    'wjRwhHBCpwqYrSseJ3IE5TL0+RVTE9OLw0GNdNWVTLEU0A7nVh3QNPHjNJsUCjR6PmVhZzMrqFl6faZzjNBo/RYAnsDtNaA6jUHu'
    '/Xk0NRsNWgFbmzPjVjove2crENAjqQe3djYsHUfhI1gqluWIaVI6io+ln/ngyy8GV+q1KD+xi38SWfX3Ip2nV+TT2uk8H7TlHcJp'
    'CWHQOzxJZy+FZtB7oOPczq/Ss/H7OUQ95jw9aD26NgP1RWChboHerbRaK53b1kHgZ84p+bvRtN2soXZ+eoYQVKRHKu/KidqFwNi2'
    'KEDDW3V+1l0Cm749MtwKZEQOPKQ73TIPd1/fvpiHLtSLXUSXObNX3Bjk2IY9jvzb7xU4V94JLjI4hWXvtAw7VU1lGwOgw3Sj1tk+'
    'Pnh0je8BtHy6uupw6fkp3LsaPt2ySdyDCN83l//YTqinDHFbxeywyw7WtHnQh8lbs4Ct/wKKtsns5fvr7enk+OZP0+z45nh0dHOZ'
    'DaadLVTy5Rfd9l669ueNtf+wuv58v+ivdh6tjyq2s1reCzNCfVSb0pN+E3wZGtOEetNjzHe9XG3a3cz1hFtGro5FSyB7yK/Cwnl3'
    'lZTTj8/cCljjioXuHCzlOTM46Cm4XQ9Jm92K0idOqz/WbTpfBryZsRuditk3OWiqbcul42X2HQrilLO9zt9pTNWYPSpKx9tUUXBK'
    'NZ2PeylF9agKuVx7AYrqJJ8s00ufeZ10L1AashtY1euk1+uN3Y0On3+90VX0NF2yHLIMWRVvZfnHnU8Lzg9PRNflsAAX4SIAhGsK'
    'UjtPeh87ZJ2iZ1cdzyMZYk2DNYoAZ3stcFbwbqF7Cn6QlcIPJPCj34tsC8KW0jmNRZDPGk/Ojt/bT1yZRKL0uV37ZuTaO+2XYKAY'
    'EB7I33sO9ERNYVQ/wWlKfz0wG5d+0vN4UXPmowuooAIu70V1Sb9KLo3JjXQT6qseSYmeBktuhNJsB/QSpbdYsZ6QgwfQh6bz237/'
    'gHvcJUZKQiteySY7bJonjucsq2LJ3dy5GpbGPn+QHtBpvt0OiRgIVX/V0a2SbMHlobN+POoi9E02pYwrII6BKTuYAY79wM6hI9We'
    'Oy4Dq+CBFA480NNDFavzEPDJtqdGTOxirk5lZLDOFN56P6RyUloPHyaOpZMtJAeMBXESyRccIKRQM9nIyTjEyUCPwj6EOFI84ssC'
    'hehmpVr2oHPy8YK+KafMjqGQpxDSL+iyVXbcccJiuZSbm6SJmxorsomgeibICAYDArJgMGD0ivsMJ6BZ7WsjRiBL0l0Aj02k+1kb'
    '+it50B4bOdjh8SCFcI9Ara5vfTkzQlxH4UZaRNa/Yzsh6pgRVaLXjz1AxLb3X6BojmH5ieaZs5Q3OuLY6zGfkodqiTihC9BugnHY'
    'O1DpQAjaZrISTK8rjCleOYDz3F5fBnigXDmQjIy3rGZVZVaVDm49a7rV6t/n5rRz1Tsb+guTgzDN1/6Ee4Hbq3wS3KKT68+7txpk'
    'NOErC51ArNGkVY9XEJ7+q7Fw0ZZkoQX00tEh1WLr8q6CZuBZxbnGGWmutXrw5t7+/vrm452VZ9s3D38RcqRhT2utzv10Mcjlxkzb'
    'iElLhyZ7AI2JgDUAjsxg/pXfsjazEWgn7fN7CtNNT9tBctvvVQH3zydSUS317+D8yFjrUsJoK8o+s+OmePDV+dERZOyOKpcYvinr'
    'w9B7qaA34PtO14hICW2oCexQxMenPyVrZowZ3jvotQv4P6MTnz9t04mA4jS36sbHjS83fvfF4HcbHVS5tuaVlsxSB7jAE7Ab6Ngr'
    'YSJm7ZVdiGbmlomV5mhWvF8NAgQqDUJ38qUT4sNoIaQG3ABPwCRW5WdPvnSfbXjZH3kBWVB+AjrtOs6pdUIo6LCGafh9l6mgK11D'
    'iadlCZyR7xneXq3m6e+D3gf89ixtKPx5WSMUV1ltaCz01BdiCriGnn3xtKFRTWDB5YAl6usMTn0I9B3yF/dMcT7g3tJaZOL1XyRh'
    '1xF2Gv3DtR/ov/wn7K978dSt4aL3v/djQp5t3Z2+M+b8ra2taobwQK7BwBD9YChM6yXorsV/2RI/J3IQLjwjduXR3OS0kPDsSQf6'
    'Jc8fwjyX9fx+YT16SjUes5jKLGlyz6BqEOUMyRl609E025Uzcn58wkJYkjPCpgppeK+lWkZZ1uRbGVinh2aC0DPlVWSZnkfrJL90'
    'k626ndSMvGfJQs/gJe3DRYCGiTw3ctYMAcDiQ5h9uZjLP3QaB8pnqhqVQ3WBPOcfYK/Xlbde10iPLtoxBZacTqd46gUhnbK6VxCF'
    '1GhLjYzpbvS7GFGg0xAZspt/Nz8bt8+GISk11Zclfg1PPrpcBIw2EV/L+4AusHCAxa3QFkFIOdEDxA1sbAC4aOiuTXmzljy51TcH'
    'gY+aWoocYxFxxIww7d9ocOn+Df4o4Qm0wSM2uL7fcyL/TiDzi2yvTvZHHWb3AptPu2d2NsiGMFMduaSGK8xjdkAugpxZU4e0A2TU'
    '937pUH0g/8qTjuvOuY6/oaVz2sJqtbZ3nj140LGRgrNH5Sfz+bSAvzLbuDlLhdvK3Z8dba31LE1OZtmR1P10ZfvRk2fr6XarXr/z'
    'lDY/6Rv1baZns+uzVzohBZUw/oT9AmpBY3/Vs/rSe1arB3Z758H+4w5iffd/7gTu03h+6Wdn+oStTZ/6Fh9dT5/A2XP69PbZiI3L'
    'H2h81NS4elPTl1qnoODAi+2QR3n+XApBSHr+XAtpPuAnlg24goU1j4NdNjba+0MZEH+6bo9sdrCbDVLqUE0cfaBK8bE5T24Ficwm'
    'PDlnw6CF2f5kx/g86bLCyPF3nQEZORQ0YzhwP7NOz0WH59TOLwsYMpVPZjsJbVIjmCu8d3ggz67/cnBwYDEp+KZTNQAdalCX9JCV'
    '2LsFvaOwVa2SE9ZhRUoT7OHqat9fJOyfvzYOngmlD6Y8YJ8x83h50NmqeLvfekXbWTkPQNJgD72+sI2Aoi9v5UyttnuPhVZ0OEG+'
    '7dCh/dnz5CkpyMlTJEsjuaQqDL2QZ6Qdz04+b3j5OXu4ZNrb+8XjvbXHH/odSAHyx6PKKpRdaj07mW23lle3vWwNfw1I+dK1i+ux'
    'hfu1umqBAXJ7v9hZ78YCxS/7e3L6V/f7e6tr/R1gOaiu0LUfLHMZZIXM3fFd9Wtl1YOyixZfpwIQEjc9+V91UnWEfI1ube6sUQCL'
    'Bgzutl+aj+OjkAFM/nniEEBUEgrGfXOzf+MtsYYWCUq/v9/Zv1nvlEoO2y2H7oT6uXGO8SnYbranXQejvuq1xBW323su7aJ5sWWm'
    'd5ze2b5dO6VNS0fuZvvZHH2Vf2YAv5GfgSJH3snDQ1k6+RH4g+DBbBtP9VODzmH7+HpmX6PKWVTf0NU3rNdXecBK5V/28iCc38W7'
    'ps3gvhu5CRCqBwqx7FCN5tnZvWf/Hg1wGWjIQdnrp0IU3tdeS1Vs1wNXd2r6v7Oz4EYoyZ4036m3bySw1AiSmQeIDlsxJn6YTZFP'
    'i1rno3Eu4uoZyWR5w81VP4AwKa8KWk+e4oJT7eCmMGtDh/tAKuncA84I1RBSj73k4/8tvJ5SjrOnxEJ6WkKgtpI+s6G0fvvv/0W1'
    'bL/99/+KLPC3wThUMsEg9sIJAzPaV/3yqsYPr5ZzFfpOuEvJ6UCjpYdjPw5oW80AnJ5GXeyc2NzaDZTt92w60P18rFi741bZJK4v'
    'BZ6S/U6Ey1sgSP0JtgJ4u/mCttf+JHstGp/bIHt/6vfYL6grrINl73SdqwV9Oev9nkiZXaKU9yl2yqDbf+pW6hfSZB3GPwHe8f76'
    'WFg7WUGpBSqtZ/gbt9ifDDG9fpXp/7G6VUwAKnA3q2+V6DS3rO1AKivXKAlqcTkrtC6paj2YTH9gvecIpv1PJYbxwukN5gY132dy'
    'PMnEB9Hob5fQJKeWoCrEUZgl9KWyh40PM15nv7gRjuxm+6aRBN1E90KnfjGgFwsYN9MxyPtyfpqL27hCFk/WlmVB4XWRHQlHRmOS'
    '8en2QacunEforZCev5nJFCLYDmpeH3hcjJgGdeU0u9pUD8UVY8/pfQ4c9hBE4aispD2voFxV4i7Xf1lbW9uftIEE/b7/eKezP+GD'
    'nfUyIqe0KO/BZ4DAhEFoqym7Ne8Fth+UB39QKDyzQIfoZuDz8yM1LwfyQwVnTPZeld2VNV2r0nl39nXjsFkuHPq0Zw/6ukwoVoL6'
    'BFR6b6XVv8F/HL/TqR/n+pC85eiixpbv7V8mayK+bWKTVnv74PSiGtxqj5nMxYs5ZYvypux2bJCvDNSEm1rnZU0utKKn8dWg/EKr'
    '97jluKgLafyCukbDNO8ma09CbxVzV1mpYiKt/7LSe7wSVqOpb1EZjRQEGpQXWz7163VDS67POrDFQ+/T6TE+T3v8SDeoVRoE+nb6'
    'PGMVzbx6f/0tHWO9Up/uuvoH1Dv6y1mMMs2rA0XBeqe938vNAetmXzqaFied/XWbhEyT1wXuOg4OranK9f3e2dDre8JvLbB/HkjO'
    'TvbXTMlvcgeKJlWopcewqDQOtnWPRMUKa1K2IXfoFxs0DjxwWagPdkFs1FULDp6PrsMPbhNLCVTkESjoWQoVX1KM88te8hJJeZJ8'
    'snMQZ0lW58Z3qn9srvi3v//ng2AqkdbcQEiwxtQOl3zVOtmq+K0RG3kFZHhnFtbaOCgHEMq2GeSpK5PZ9wEcfw6Nueqg4Tgrf+7w'
    'v1Jr7GsYtDG4cg1YLiu3C3BrsKG9rNrT3jSf1pM4ZP1wUw2ufix1/kvrXVoNPGu/GRGqpD3LjroGQelZQXkGr1FaEX569/plLidn'
    'gvh1eeF6/JBzGxkPhqOZcXzhsLzNDcRF78D1il5Lh8WkXO02atlhXZx2rh6sDNJ2ZXYod0Tflqtzz2+xTPw2GNmCtajqzEzlDbcF'
    '0hmuxZX5wipBdI4KtCBAB/8azhJakGr/iEKGrlzw3iibioW2EBbcwadVEBcceQRGd1/XxHMJ2puM7ZMt9YHr1EKpN0959elI7LEa'
    'itU0LRMdEPvwjQetKgdX3k7mDIOeRYYnjZ0uuQtv6UnLXKTnM8bZZuaxO4VpHfTnGJEDNNb6auiLKlxX4N4ChhdW7ZIdePgwaTuv'
    'jhu6UAhP1G7vbK4lwllOdjoAeTxTveqJWkpsfV07eyd98gSAXjcTc8nnVCNRXAwyAyRKsc+NU12CmnoagoH+8kDhQCEDuq8+CQ60'
    'z/9fPG4tcpAxwaii2FIE4BLW1Jd2bqmLEGaGowvXipaNQnjQWM3tCwYJ2dhWvB44KO/3SoNFv67zUgKGmXGu4ywphI7oTPR6sJsb'
    'pCFRfBjDAQRlVLJoN3MXZx2nCBeAHh87/O2jaBXlKdXW6r+lSbLwayvRRULI14u5TOLgfJ7JzPghtMokwWXJdsPamAfeosujVG0o'
    'g1Hz2FEnFPoEGwSkcl8t753S6jt3QjiawJ+wXmJZLEeE/gR8BQAsnopY6YBdzW3e/LlHpU+9h391kZ5hSPnU4CTVN3tUqAeFUh2C'
    'I7qO9gzRMRyePmsaFt9Ew7kJwlJc6pwuTFnrHfrmVNKmfK+2DHYvhIyuiR4PTZ9cC0/zH8mVCoxcd0kmrTh7I1sCj2a/3epDd6Uc'
    'DGuxQxNidXteiamF/CEEqsyL4Z+ke5M5TmO7NSBWVEZnSxV1ae/U9kLJNok1bRorA2rU9Tus62lk19mci3Qymo/+nKlre5UYIFDn'
    'DBioUs0OnRyRG86dR0fq/KEMHI1kl31F3VbAi25WbovCIG9OMmEs5ogdoNnaAh2KLXPUjYI8whCDXsDYq5UZ8rFzC8Pv0fDtUZy9'
    'tEy/+HrofC0dJhlzb6nP7IbTKXrOlB60Gm60KMoINTREGYVcAyEpbKEI1DLiBhnNmRU9kBMuJwoeBv6ZhH8UoCZKC0UUAM1fxa+z'
    'eTvW6VaBoU6hViIilJYzVrXdBDMeB2ZhJomAKl2tu+RjpiOadsZRclBg6rAWk0ow15nPAGBVcoZXz3ofqbo+Tf6G4+wkj5PPn24k'
    'azrqx8kTC/qSkkwo3w6UyafJun2E5B9S+OnTDb8gZ+awKN9U1ib2bxap//+Ih/PZ3imUBt7HeaJ/I0QAPwLlhNsezlMyLYrR8QTo'
    'LteVCLdKPFukpilRg0R61PN+7ciAf3vb6QS44e5xVE3kJa23cHwBW5mt8v6dmIO0/OE0DN4h04WAT3ofcBikTctpGQQBVlDgRsNv'
    'COFAlmJb9yYEBgvvweOqb2JDgKO7SW4e9tchNzUqOgIJTRabNEN54aprfhwZwM57uCYZ2E7PaOiwXHBWuMfXPaWlOlgDprhfC7Ha'
    'jp9/cFNom6dJ4SVNer4Dmn7MaPiw47q58K15EcPTt1zKekmfRWrSw1at5c5zVAK3qBbpWFFELZOk1o6oU2LKt+5C6ylCFOHwapGn'
    'NV3mWiICRbv3eKezCS1hZ8f7CqkHjWwISy1wdlZOgFqbQuaSqRt0mgDgnZfO1ZUpL90sQtKqMXyQ+N0OGAejUKRimoh1p9DrO8gV'
    '4ZzRlcJ6C4QiSJRxpJtotZ4OAl7RNL7RW1sDHJOzCHg98OwOXMI17JDe3vKzwTG8fOodv0uu+fbeO9vvG9vPYZTxUBjFH4UpkuMe'
    'BOWJuEMF0uxM6PGfM5A3zjT4HuLnCaVjJM5QY/EL3Fwu4dgmL+dbBd4sjI/oKtpMwAcYUb0bnq0BVk257yilSpmlZ4kfnkdUO2PU'
    'LolVM7QaHXD/MBoW7QovMU6vEBdsvroKPjidqZu15mpQxaIU6lKIhyIQfbH0RQA1ERIr/FgE4HakAfHIKAyO0BA9T0bD7DtwN51A'
    'u/h2miEc9NF1yKKYclHBsFYeXftp1njq289y4bofnkhd1BHzHjUsEw1xRlwyP/p6NENkM166LDeAkcOn0/QYKchPs4L7ZpqZkhY5'
    'mjZl/DpyOJt3NebVpr33Gb5+NW4ARBjO0mMRB2dVkA6Ij7tC+oqjbLbTg7xT7AR6UUxSAdG4CRUCG2tJg/m0jr5wRLkzbpRD2+nJ'
    'Hikx3UJlb0PTVk4kVJmD0uexZwGD5j4vN+NJNmkHKnuZbxLUbEZPC13olZf5+XgI73NuLwYKc4Y3kxU4zM5mQuqKQtZEL1feBJoy'
    'eKzCuwOlCNa1AdKGQJb1KSkNB0i35CEvOCuaEunIQl4gsmwmR73LbHA6mr/Lxili4KnMRToY40nV4fgIjJHOXh1Yw3vkq97XGQma'
    'bBv/+glrCK9nHCQJeJgxDSHV6ncMLHcD1cgnBi+VtFcQ7o2jkM9WusmKaoiGK3AORzcMni6znNglRCENokKrEB4p9X+dn8uLNU1V'
    'nRpOhZyigsohsCQQ6tSr3DALARZFB2zFsdKrFhmFMsUKtasSHf7KgxXyT2SNzmetMB8YwIoNUGoIfHGRHdNxaHGNMUMsQZN6NlYN'
    'MAtzVPvGyeKEhLdEEWrKjl4KQ2id3VSWFjc2xJ32m7aGZXUIaPFGU0v1Pnbg80IxJyhxFZS4Ygm9WGOpwM2bomVBRBhnR3OGG12M'
    'sku2AyHrccI/T2+nHw+wAtOyyBWLXEVF7N7ztbv9bzMOt1sf07Zjp8IXrif39q98uu7gWREkGFB04bhZn6Cl8XEtFasspe4QqBvK'
    'VCzBojqOvJqeIN47/gNDmqm0/kmAM+GOcjunPl1M42jdpa4EdvZ/a5Ca22jT3n7mu/F/DFcpXCOHJPLXISuFNXGveZSjJaOKUnHW'
    '+iLfFhfHTVfyYLwAV218ugQyjfgXpUl4fLoQbcpTttXxaQl1JJ/7QVUuAmFICkKECJc4T5WHA/V1Cd1qlwOdjXrTK9Dns2lhwJwM'
    'qiM4x0y2irS6pUQ/Pwc07GGO8kAcbQ2zixYbmBDgQ0NPwRlbg46Uv/jxxw9/++rd+9dv3+DGfLrx9Mvek43e0ye9J7/73ecyfyjw'
    '049fv9h99eGnd4SMZQTD5vr6LL3sHY/mJ+eD8yKbHZr2VHb5+lcptJR/l81Ov/hyXY1ca8a4rYNPXh/KSq0LHYLCLx0IY/tiOqVI'
    'ZNO0Gfar6/q86YDqD9PJa51G/8imFT6IfALyqyN8/eb97ovvv//wfvftu1fof9yhzUm+Zh+v5QgYlG5VPCHGeTp8gV4GyaK+e/t+'
    '1zlyBCNQbUs6HbVb6/Lfdb5qdSqmPZ4e91XPbQFk3qjMtpCTcIFAWLiy2KFkw3S6IMmAoEUI6b5+K6SHlPtCLoGvZVuM8ylD7LBt'
    'aPz9WysJxXr1c9fk4OVJdnj6E/ssbXp6+KA6HnwArCJbqbcarOnOVrV0pw6RdFg2ZASjmzz93caGQ718k11mUHMJk6NpE/wZQ9wW'
    'BH+inSv0OQAnkOwtR+hORj5HHUCAVATaMDE06lqE6kSamdnM1DZAmEKpuvY6snUOo1VaM2e99CIdjeGzLAsx88vjjcBRBh4Les3A'
    'mlY2x2rSsm97fyryyc78Odbta2lTpNxLyM/SOyEVUDrKJmesrlM8mm8H9BtmbmcdIp6F6209vki2o224I0/KPEuV6QpX7SydnDuO'
    'j0clUIhd+MHFE1zqwS4U60rr+iqdwUMqVlC5+o1Z/6PCb5uAPtHtYcNRr6zSe6Dhc8/rcwgRsUxezIjujZSKo0m2s2KJGSNs77Cj'
    'HCqOi9aAeNPaAW29oPXDrX9+lBgi0dfmHyRbFvz+Vc+f97g2qD9QT3hsL+Ki3+a1ZrFxQQG0u7L7FS4Zmb5B6JBEtKEOodjYsVGW'
    '+7KIDDqkBQtLuJvSkyT0t7aFZucT20ChsHBh0saS+roKmxp3/U4JooofRQHEHW8PLauaGJrhec3KHUSxkIyl5aIETqzNou1ABbbJ'
    'AdrDK0qWs3QTid3NESDvjkR7+bGPb7C1wxORQbK86ME7YOeCZOBi0el3AbSx8jNd4pGQtnzhtHeivgLSESumEo78HYT5ooU+OgAt'
    'y2aYGpmyulTj5+n58tG0UNg0R64Tdx0rt5OzYS+BZsuvxbKGVKi+ghXUfV9oxoAg+Xc+HlIM9r78x3ldIAipTJWyRNtDx7CAttSz'
    '7ACmtzyErrW7JoMHSbb9b3//z+y1cSzNVxWwJq5a1r6OAfqQjh9JqPDYurPtXT/IZDgaTvZbimMn01cZjNKLKOWAnLo/YjGGJS0M'
    'vSIsQZJL7Hec07mS+Y+L+UiufuLsuUxLGRLB04cKfoq9e0zbOy0bTFwMvKCYCr/fiAAVytB3kbnORkWmUU4BYzPrwnXUeQTpWjTf'
    '9a311sL729KB5cxI5+9v800rVZpA1bu4bcGflPnXKkwo/gf4AZBcEZCxLdulXtfTz0Ct6+myFAsKfZ/O1Qgbq3+vF98P3LzkRFhN'
    'xFI21EMp7Ydscg7RK+QvSmhLpdNtu/qdZll2w2//6f9LhIyddyhrGKPPHpf7jt+uIJ2HXIYrm7KpThORmEcT2iiS+cgQLLGJdAvF'
    'F3/M4Qa5QssmdKn55MEDgj68l+WULsI4+nqenbUjMaUqMJjT3wmTWnjWuRSDaHLyz70spJa73JLQBUOnX8z53BEQzJfVFLH0aNDd'
    'iPjdqZZuPDy+H8VVwWAFyB0/M7du0eLGF+7DdTxmeXaS15rwBeecxJi5qriC3cR5UqqFgBmvDWJOKfVobiidLjO05/d72u7m/duV'
    'tS7+DZqN7CTW9lfzSbjLzR3W+xOXrEGVSo/cEin5aFhvd7Sa5S5n71m6QMHiZMMHImTZCejqyCssqldFl+vUCqb5vjXEU96KePX4'
    'Birv0pHTAFQ18U4DU533hXSqQhUWTmHSVOubvKlKPe/RQS+aDrp8+iRWDyxsuKJQkuObz6DdbTIrzLPp2uBqDf8KKSoKiBcwL0xn'
    'QBM+9NZLQ7llOaF6liVXNm9uiIxMeGZ5sC1XumVUKNAUr7vMcUpS86k/BfnRkaaZGMFbOWPVIq9K1RMmnYR7FWl5EZpTtaIxFXmq'
    'r0rRzpHcqam5Ks8VMAaVUl6VrYfDxwSQwp4Rq16mRYgjgytOR7QqOnDcoywz++lphvbJHPV4OczPS42vEtzdn3YXqo3c/LcCgwe7'
    'lF1wt57Pd3r4mzidGYN7rNavX33/4Q+v/ggFffFDesgg1//8P1QII6/Zcu2fjxxuy8Gzgctecj5C9pq5gni4kjCI0X0BhRVSMYwS'
    'dMIP/rCfDuXcAP1Cf1fqonQnA7avHZm2vUcmm1Rrrq7A0fmMToHUmcC5PAdgEJGNczJ+XARyL1k6G49YVNq6BKtm60SUXeYrTQ2U'
    'J/uYIsIviOGTqX2fIQlEJXav7GY3GWzAKdxGw2dbgRmS+0fBKIftM07RWYlR2foBV78sdkrs97IWH/8DxAj4Nhu6L+B5Gfo0Kt7l'
    '+bw9YY2cukl9xsJaSuGUfbq30Sv0t6Amw9A0K71HruWzcDN03Dil3I8n+TyXuweK5VERROMwryAx+piByJ1xkDn34AwWe33AZIKI'
    'epoC1Fox9SyGtT5zz5LPO8mbNj5/eYJg2jOCIHssULS8V/tMoRpeY0hBbA8WeINhKeEyayQyOv89qBb76Oj+y3Q2kP0zHOUfZX6i'
    'rnKxBosX65msVdTxQdRxaXPvjioqgzCnEfMnMxeQzlbNf8M7abReCFcGlxDQQjsUztsWB0xJO+z1E42ZDUnYqx/fY06ksmvnNdP6'
    'ORsrNnteuZJbmgpVXUHbho8z3WaIm791LtOxuy6MHtOp2s67McugwUMRzUDy9TTPyVtD32AcQeOtBM9pk7Cl4fKKii8izSelnSDB'
    'abyD8slhVrl7ehAt2bnjnJEvahUXCgTEdR0CKk3HVL8lpyIWxH1ytHg+mq5sv56bBwv5quTJBnLMnVNt6NrRVMsY9+RK5QkPbPzo'
    '+lz4u3/5p1bnVi8/E1NxqMbkSDyPpUV3pKSN3eEhz/Mp+3eQ3HajNaZXFJmrM08VgFkG45e8fihUGW6yjev9irkciwgk3cQf7VKa'
    'PBts+3pxHTnp/EwkCKQDeA153M1iYcl7iG2WDGCiHqbU28usaWB4vO7/ETHe0kTooMBWZMcGejfLKFCkV24uRocuE+MsuxgV5GGY'
    'm0s9G56dDobbtHo+W8dPzR4JArtkkV+aE0XpbOG9KHpa4/uT0dF8NazXJstnCcl8umarZitBUipFfLucpXKHDq5s7+p6di3t6STb'
    'LKXhhgvPGxfuvtIYKxfvEs1spmQ02h4D0roF++Nnt4P9FvBL3A1nejcd2HzA6KJ7+DWjKbCRf/uHf8Qaa1gZVrfDXJtBj3DZMXX8'
    'Eb1K4z2yy0ygc83ApjEKjWu8aDobL/cnTRN0ls8yXzyeJcsCvmye/GAapyjcNEsmydqJZ8mykjIdByWtvD5Lf4B/wnGOWUSmv3GF'
    'JDBkWeoXSp6VY0QzSw7EG+RZceyi0FHFaz8EftPlCBZZWqmdGyV6pskxmH9eHs2k9YHR1fsuzOfVhflWRBUZG6/3e25bF8BIunwC'
    'suxHoT0bMQ5GxAo937n6M3PGyowl8UYrt7hfFZ3Yc1zm9fXAfsJ8X+Ysxqm2sh4UX9tasgBfubsfPNnigSSp7NvhLJVfA4YQ+TB0'
    'H/zphhcQ+Qmp8j0Wh9zvwIsKgzv43eoC/pDjXtS9g0bB8SJWIoMhH4L4fW+rnwrV0XE9fvuH//LbP/zX3/7h/5WDYwujyP/AscYa'
    'IV7Q5sB8mfRKK6m7ZbSpURtSIkon7jqzb+xGKspwvGQ3xyqrN6ReXLifcBTMFNTF+2HgpedLubyzXJfD81khVGEsE1QEKRCwbpey'
    '+MEdS5N2lX2CJ1O0i23jLOdqlDAVhzZ/cloO4cSYqltfuDN4zW0avihi+WSEQaJgTOwrC2YqM9BRYNpTl3eVVxFyr9vDbTbWWBWy'
    'CPcOsmLtMDsXf1rOkTjhQP0db0ikU6lsRZW9jVOQ/Zgv3IcDV/Th4CeWa9yRRj88y1ChGY+uTQ9wGxB+Lr0MTtm7DjioIqKypnis'
    'LPGbHLTYssAzlJvl2M7L+Wy8+neVNjA8PRLSxquScQfXK29Md4JSk0y50rIu5XNcjbNsSLVpA62w0E4qQZDjpKWWtJYCQwTPOdn1'
    '9Zilx6qBKoxC/FWEgdVEi4AzN8unCY9FmNibRUoOc80y1Yzmeq6gqi0vctLYdO5TX2GlQG79alG4SsngNa5a7TY18ivUY6RH+Uxo'
    'zAWwS16I1LWGp5ZTyo0Gy0UkJNKz4zHybev600+MBEnIEBhDX4XyUcG1TMlqRNrQEukj5VwgL66jEyJsHs7HV5otim1epoAS50Ep'
    'WV/dEKtwv2d/MFfgvb2Y6nVwYfKvJXMSuS8zWa1II2D6qwyirQ4GVtJ0T5mXkSoNjvpEYmUJCD6VXLm2SJ+CjAf+jdKo2jlAAIyI'
    'vIupEQqAFpn4DkPZgrMQ7TKyDHIW/M7gzofvHbGnsf9nM1xd4VacZCm2AmV9FWQpKA9lYrgHmQmA9nKv/Sul4EI2gJ4n6KNn4U5U'
    'jtcpIITlhR2gQuV+1lOEz7rBRxh+IBLLSBBjcD6l9pnOj+xicRp4AzQ2Z3KgGue1r1QM6AaMGluya2H0drYN1srsccoEyKQLpb6E'
    'COgO13GmXvjSWR48xS4Dzya3/oXmVijmwiwfn9yHxM7ZP0a8BU/Rj81hsD1qm+wlefNi4SYrLmGegOBzx13HE2mWHrUWkOnnTLTL'
    'BzKwYe6t+fM8Hw/SWcdho0PQ1nI9RgpdnuTjzIuDNpV3E9VvRxdZILLDypDOTin3rJE9t861y1iKHAiyatSrkHPVQqgsb7JLF9pD'
    'bGgcpomcUtgrjuWqmnLb25wmR8j7B5olZ+IIeH9Cccfy4DKdDQvHzJELp8ikLQp5JYwVrpg7zwmO8Tvtk42pCNUxlCe4AkLWCzu8'
    'Npt2W7ghKZLnPTYagwjr++gbBPgxnm/hVjr6SsQQoVdHrxmajV/voRuEZCIvR8fH+us94qXx4xsN6ZYizMP18OhdVmTzBTvxe9h1'
    'UpgbwG3lhzB+zbrhLsMqSR+LprtiM9xM5+NtgFNCakraJf/zlV50bptgDOHr1/aa2JWuKmJcYuVe/Pb//COWzf5axW/smkJnAKd9'
    'wBngwJrreI/gEfchZZ7BNoPLuebt6Qi4B4P8o4jg4/FoCllcCipiIiEPU6Nx8h2sLfiMLT1blyEH0g7xyEjTRVLtJZXWTSnBxbA5'
    'nTsNHfeZP3ncY/Pcoj8XCZX1m5Mz/6AM4pX7Uaebv5mURH9h8PoT46ltSkuVWKVuzlRY36Ij5P0NdtwIgAGyFUfviDSzSLNgJJ2K'
    'BXQ9dWH3oTIhoI0OEqskju7J6FC4f66TXj4yzzaI3/7+nzHDXFJ5SmKi615uwb91O1TLgCNjEWglgKjlLxTlf+tKtYhm0NYT9dd2'
    'aLlt2RtF4Snu4HNzX4u0DKq5k1DPS+27c9a+/xYh4EFV6Q1XzsXskr1uXEJgF3gTgNAL1c/SDG2buVuJnguZA61ZjkawFoFqr9Mw'
    'zRpiO00nuBE40bVMIwOSSxfyzHQjlRwiPzM+zzNcJsLSa0rXDdUvWRSf94RZZp1PHXw3ZSSD7YfcPNYvqizW+AT945+PH6OPjx9T'
    'Mem6I8/39mB/6PedSMXgxprA1XVCGQGNXNm5Cn/cDpsJAYno/mQeXtGnmNx1k0fBwBU0szjiY3m5QcXS40U7S0EkwR+qxby+0zxC'
    'h/0MQJD3ftnuP96Ok3M33IxCEUoF4mV6tXiLvjQ8kntqFkwDWMT6yXBn+grjzbnuNibcn5DwrFDBsSK4dZXXkvbSIaiHrAPOB5bj'
    'DDNNHSZ51vn5IZwwMLrKZlf7id06rMet9PkELfM8wecuXKFpDv+eeRnFXV8WD90CWNUek7aVblC3DSyMFaHD3JLaqsvHa4/9J4e+'
    'eO0AxLBEBKuuHZBF5S+vi+/Y6c1jUQW1hnJKEXUH9sWhOVqMpDkwBDmRJZyFbQZ2W/gcvTtUOzTYpgao0GfKFIwmXbumeWCEvT1d'
    'QjiMi4HXMH08AjYdnT0e4T5QdtPMX6Yz8XK73jOEpbg3zR8bsleYm1CfdnyAd2X1GBFM2+ulU+0uX8LThewlICCAOFatrouB0s1q'
    'OILbFsR7dx4ZRU3yhf/pcbGQo8oxqWwP2wxDVYU5I7qsHEkprk9TWOUKAzeQRc7P1hBVLA3MJjQM1SiuCMKxVMsBw/5sF4c7qtFH'
    'S9QoDtcrXJEgAa8uStNxXPpBsu2rbjyMGtF+90kUxq0ivlr/nUVVITfMUYxnKi1UL7ZD7sfF5cdeFgHWzNJhhE49AeQosN/6kZNS'
    'V8G9UEEM8BX4+8Th8h62SwFkUgOQ2QxsMXsbfSIbIfUS/r3diqLgE7co1Y2u9LrEJIgN3rvUkRt70UyhcPhJ1EljHHiHOxkWAA+0'
    'gVDcJ6tV40f10FGDlF7R5OEcES1oTyTwriKGNNlTHKpCDfmAIlHoXdCJOm64DPQUfDbaLjEZkMHqLstJTb2varEitByhW4vI3sJs'
    '1qSElpxGbwERfFxma/68HA0VJ2NcoqpZRHmD/W1G/mFCSa/ZSWTwA8HzGrfJ20lGv+hS6ClA7+X68HXJ0mBVncuSqQ7ppUE3v/MJ'
    'dhRVcxW7dzc5PMnBxMqq/hD6mXSVOU3vZfVfohsazQN9PqVcU4Rz0XtJufFI8Z3OTi215WYuh7qMSNJbo/TaWEIVXYlmM6qvqspg'
    'BvCL8fp9QwC6xvV7QSVA+SUPzNE4h37E7hQRDLqBfmvMFVFuGIeVlxlsB3IxFUAzgYafjkt3L+o3lYaxku74FfRNgx118SL6a6xi'
    'HbBjjkuvlIdCumCG0uRr2IHSELmy6b6kzOJsQfflU0YFRme+oAuNjpQKSs+5eN3uVujfodCOFAhsqtyqdO9Q9+/SEURlAMqCc3UB'
    'DwUt2gWmqsxRwCk9wSdS8EquqEFdwJ2U7b/6OEUlqSqc6rpJNIjhBH6EVBydT5fRWhtX6LRi0RhlihDn52CCS6C2Pc7zoYn3v57z'
    'wpPGCaxytwYUc7XJk1i3aPIdQ3/qKtK/y+E7B5qVTirndLRIq/no2ruKUxVkvlKYsz/n+ZkXoYvDWW7zC5bfsY2Yx2M1ocLLHK5E'
    'ZUGrg0upbh/d0kxaqwCftG69D4UaZhevu+5LDCyWPDecigquFjPnM6oChHNDKQ2ZfkWaN4EB0kwCO693rwz8PnRyoKAqawXXsIxo'
    's8xzRabj79tmqTJYeoxV9wNmaLhAkiUyajoo2grjk6xbY/JzDfio28lGb+N3uLpZ8uRqms/bBhK05sp+7CYGCuQfXXWYnqLjmi9l'
    '4Ubf0CD0ItqLwnCAZrWWMYe0IPMC9l6oxDNiaAdRSGQL/TQpUnTDGtH7hXl1L0tui4oeH+lplhf2c6nj5pIt8bOZmlNXTRpGkmq0'
    'hEaHojlwMGRG8UfzbR4pix6AH9Pw+6pkkl4oGV+sXB5IGfqOAIYv1DLzxYtiIQnQkxQp3/FFVfv73h0tJYORZxcdGOQ7C2nT1eDg'
    'lSRemaWWhFhDINUHGQSBKEcueiSY+kfXBilwYEpN7SpipBpdlXWTgBjDcWkc9dAiiVw/iiydqaLgDIo8W0vHhxHehro4dX5Gns54'
    'GzCEmKEno0INsWUQ8ahYEEWcqup0CGVrAu8WRJtRmYqIPxmObO4LpTZkfaWiIj1yVrPb5g35R3rWoCba3cGkpG7nV/3f2Qs/BU4x'
    'fo8rCVXWL5xXRPSucRf6+P7MhZaPlFBZptKY6yuFZfMNd3FSDRY1bsEf33zrVNimgJpb5OQX//JPTHEOUB91+edlls5Oy2MFdxTV'
    'Sc6BrmjuFOE1FVvOpHPSpjmaK6+Jo/AzzIQO90AkRISwoNVv8xzqz6/zQyJRimjudeQQWQkFoW7n7AV3sLLEGr4GscHisIcNprXY'
    'sxxoEmqYHXlXXlNzyyU6HeTpbKjIf9Sy0eRzj81Ao39WLnLdwYrG8HyYLSdXcqIXXgT+tKfTKcsZyJDUzEDS4nxCjuMsR1SKpwXq'
    'XEFg1fmldNhWmWgLrlO9BPZHF2NrriPKEqiIJnfC0b1M1XMOoDp8hxYDClRk85VFA6R/ZcmTPkheMALHHNPoKHaGpBSzpp1e8Q5O'
    'h8MicJKo+X7b+0L9vEtSqKwsRF66qGgaF3Bs1W1entb3QJY8lF1VJ8GqJFQqTBuTyeTCJHGvKSqlfLu49uYYFBfwMI8ihXiNNNmX'
    'nVuQZRpoJoSB14UaT2d2OU28RoEqZb1OxvmcjhRHWUrbmBdUwm0C7Z7uc2yJfhi/idZ2reMB1tPy3GD3A5bRS6X8q9ToLcFLHozT'
    'yami+I4VdqKOK1xGjC2G+i2DyTBPMkJEbLY3YjjG8NUoDK6kh+DzMpTMkpATZRthrvADm3US4FDPHNKFvLDnDGFjaK1wvl1WRpXt'
    'ZJOr+j6bQ/WpZ9fA3PihIkwpjOaScGofo9tNDGN+1KnCJxC/QNoFURh2ygBSTgifY+F3euh1mPfrDL0+UWlexa95Lv/+AXreE+Q3'
    'OXEICnOgvC0AQJJ3L4H9XANKYNPUNQupdNsOO2NKP1nwM1gM4DIjacItdvaja78MQbbb2wMpoEP0AdBSJ240/atjyb2CPikmB1WI'
    'pjJ8nrSfbGwkj5ORiCPtpnY6TIr0N62gml2Q0+ahkdKGRRUtIsxnJFOs3Q4ya1npr/NJVgMNCbsPVLXy9YhXz0ZQ4tVH4Q0q7YVT'
    'fvDMKJgmFpoMn68YSVlR3sf+EnaB5bbr5WUDR767vuhBJYveRONErWdvOBFbCnPzLvv1fASHuIJR1IorVUaubyqAQj4Rlud8gvCa'
    'QmMaqdqg727B0wN1my09w6rViRtgNxMGAC/een/wBBhTLj2vbaT30he8sEmWRyvfZ7gYj/MVjJQD2nJNBcg+Dx6wLgZewuQa1ew/'
    'cEhm8ddAKczLYaaDXBnnQ8uU2PJzzO/IU33P1GL5sXBv7dZ0NjpLZ7Czl72oIsQDePmohL6qJ8/qyXqtHYuIRmzwcdCMpZ1qlQW2'
    'QlqjLBRGHf7JaDxzWO98SkeCSnxqiag7wBmo9MVKGMZpT7E1dohnOsrPC0P4srCynSV1GQyaWvep88OttQaGeNOYt/OpWiC5/w1e'
    'SGr4XjYs+x7fNSQcAPUq71jcEfBblYuD2wXB6/ijXLowLaZ7AcVKQLhdTeVXfFX9lA2UJMXyMZYHVGkP7+F4JUTGgtquSu72Wm+E'
    'bXmAIHN8yh/fwr91zp8/ZrMj+fxBq7+H1kfJ3yRf9LX2hVfGm0ZcKn/Q4lJ1LK1KLQ4qsOHbyqq7Q/O//aBYXhQsA+bELQ3vflCo'
    'KhzodclwKBkadWKWhYmFoJ5DHiLlbcAkgL++EHbOthwxRBW24mfG/qeeinr9sLNRqb+oAZ5Ab+i0AYTzE+o3y640fllV7Y50U/eJ'
    'GM8i/8zgAz077AtdphPNEg9vGU0DmrR/YmAOo8DxY3wJNRpB0zpBQP/Lt2923739/j3ReEUupKUC566b2J9qAfF/jiZTqHWdWi+0'
    'iG9Fh7I8rgH/xzwoewEBUi6uR81VFzIiug2V1jvpdavvDFcqiVEXGtM9S9nWTT55l4Wjr2TYoVbieRPFM/KVKrhQ4aKw1dvNRwmU'
    '1IvL3PVu4PbQFyxxTawi2QmIiMmGQW9UlcDu4HZaTGqxu2jva2lnCdHS9FGFEOWnUVYvrgUJQHm1CwUNZkM+YE4uzhPCw+E5vugq'
    'ONPdgY/4FYezVb903FWLo50fHeGqtZ5YurmA5gvH1CBbfZIE4WSegDhU4ZK6ye83Nv464oUBLKNdfL+A43dXyf9OitkgBWnBWBCK'
    'pR/DH3P0PsCqsuwoWe/wfAb12a5iogNy3YHU+5sU+8nn1o4Wcisiwnq9GSF2aFmOW79/2/Uq12pVvsS+bsDeKvdVLzoKLle3cK6p'
    'Rf86oryzP9mfEKwCT2kJBHQw6DLcVmVTThymSRDN5FA6VE/ukT08XMdOA0rHClY6mr7PwjGpyFKbpwj0ZhF4vVQbYNc/GESJZeIm'
    'tcigzPY6USyolkk8QoVw4HdzXQ3iLYuoY+bldnOqE52PGhrZN4yrmZ1PNH846aaahKpa+CsoHM0dJ7wxLViaqZwmZur3aYAA3MXQ'
    'nXfnARelJyV43oy5WMX0glZCKXBzeXe8GhURjZXV8d0+Y2Y1qBM6CfFW5ZdmH8G8hpCguD6ClNFLemSnle7JRU+TdNUybhVxN/B6'
    'Z6dUMbFfsGu5fFw9l32rQ/+IP2egWZa4AYwV9b1e8dtNXE4Hl3dKjjBMjKgaizTLCqGDuwEZd0m/y+eNQ1xA19Bdv8BcsfQcLgBD'
    'mP6gButU1Xlbn3ng8LLRIJVerQY8LJVeq/6jfsx4li8cp+Ek1CBkltpWuUDKPtBotqDjUrvT3KlzIkYSoNip5WlT2Mjj0SSpoJ5+'
    'FuQr2Prs2XpxOBtN59vyC0mp8S8Aj7c/+/8BaIteMg=='
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.10.21.1553'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = 'https://raw.githubusercontent.com/BannerZerk46/spider-diagram/main/dist/'        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
    'zip': ([('Zip archives', ['*.zip'])], '.zip'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def do_POST(self):
        global last_seen
        if not self.host_ok() or self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': VERSION, 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        while True:
            time.sleep(15)
            if time.time() - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. Everything stops by itself about '
          f'{IDLE_EXIT // 60} minutes after you close the browser tab.')
    if browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
