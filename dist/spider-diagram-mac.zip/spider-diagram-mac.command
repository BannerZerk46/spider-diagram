#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrsvcly60qSKLi/X4FSWr57TlIkMREAz71XrymJFDWQkjiJUlYuQAIkIYIACICT8pVZrdKeWW+6q9us/+Bte9n77j/JL2n3CMwc'
    'ROmcm1XPrM4gAYEYPCLcPdw9PDx+/SfNHvobR2cm/sw8++lX/MWYqjX+7US3TjBBVzX4NdN9lRlOVNfT/d9OFv4or5yEyZY60387'
    'WRr6yrFd/4QZ2pavW5BtZWj+5DdNXxpDPU9eThnDMnxDNfPeUDX13zisxDd8Uz9rO4amu8yloY5ddfZrkab+9Os/5fNMRx0wBlT7'
    'jfwseMvxKeNPdMaDlhnV9Ve2O2VUj6SpjkNzMfk8FDcNa8q4uvnbCSaeMNhZeJ6pY70I9eTWM/OEmbj66LcTTfXVb6kvp38ULuCR'
    'gUfL++2PPD/xfedbsbharQoroWC74yLPsixmh48MDsG5vcaMLMMykgj/4PmPQhXq0fSRR58AJF11r1xVM2CYGEPDAr5h6ljHmiPF'
    '8XETP675OJU8clG9nm87jD0a4cSEeTAtP7RN28WkP/KCOFS00QieizsLcTsL8SVJ0AdxoWIa8CAx7perD32G9J4ngEZPFA/gSSLQ'
    'TXRjPPHjd5eU4XComJFhmvi2cM0vAAKOytcYgjHju6rljWx3RsYMX0zV179wPMPxhdJXhqDVF64gSZL8NVmhZVs67aVrT/WghyMy'
    'JkFaPgKTL3CJZOz1UHXwg2svLC3z6dU2rOQ3CunQcIemzgxp18goDDfxMxliIe7Y3uxCoRTlh17tKUFnnZYoH5Gfk2m1AUjloxqR'
    'PlFGfBcuR/UnDKGABkxiuVcqcA1OLCgMxxbKplCQ81xBaHACpogF0eThAV4a8JmnKfkwqYwpUIopFUpMOdlIcRz8RkIVqieUrXiE'
    '4+QntucTVuENXcPxz35imGKRqTiOuSEMBf4DlxnogHU6oJPr+YyjGpb/DdjKTJ8NdFfXgDXawOROGd30dMqaNp6vzxggMN+wxgWo'
    '1Hc3zF8Z4LeLGVBPIXyomjp9B+4DuQu0ud8Y0wZUbvu2C/yoMNb9a6juy88BzBrlkt9I5p+/Qu0M89/+G/NlpvrDSUOHz19+/uIA'
    'V9Ndj9I0MFzM+43RVHf69eevBZJV95j/yvyMST8z35ifTSTMn7/+wvwL1DjEDB+BOCiOpX8thoP5q+dvkI8zzDfXtn3mrwTWfH4w'
    '/sb8YSSOBH30C7w6qqWbmEL+YArwbXjnRsCHFHyfLXxdgxRpIPMK+0tQDVIgJOqCzmkqZlOHQx3n5g+Ue2HSxF7qLtbNjVh9iCmu'
    'veIxYTBSR0pYlefDSIepMmbTbKxIK2vSkBSzLQq2rugBkJASQDAoD4e0FKQFsGuirkXVw6TAZKa6SJO2eurbqudvpwT5guJBrROK'
    'iOOB+oUvlU7D/4XyVzJmurXIexNVs1ffYEHiWGfNCPiDFGBP8W+BK30Na7MJICWFFTTSk2nQX3kk0YGDlKC/5ZFWHvC0YBrBCBbg'
    'h38JJ/3PiCl5gia4yrrTk7+k8YDjOOD/STzgVG7IszEe6KJe0stJPCjzZUUVMnjA6wInKCk8oEtfEg/4Eq/wegIPOIlTuEEWDziR'
    'K3FKjAf8AGovJfGA03hVFNN4IIglVh6l8AAwg41nLMIDmFyJH27hQdzTEA8yKSG+0DHbgQfSKa+cCjwgAX88FpQyWCCqmq6wSSzg'
    'YNg4LY0F/EgaiKVdWIDTHCLBn4CLDOx13jPegBd+g2cXmRgkUU7z54mhabr1F2Q2hueY6uYbg+s180/GDEVK1fJpxoIxhDxknf7G'
    'cJID5akwEb6NTH1Ny/5CVv7wma7X35jhwnUBLS4Q1F9S6/43hv8ls+LDeOKa/kt2tY/SAZ18A7h0XgWch+S84AQ9Gix837aS/TEs'
    'LJ5HAH9hSP68ARzdA5gAIB2geV14vjHa5APxOf4wRlBKmaphKAow1MvEeIip8SBvM9UdI8AsgQ1/8WE9KOmfwlRouCpF+RIVsOwf'
    'gxZJHjLHA3U4HZPef2OWqvsF6RdwjEx9mALoCUlIayMTMY5OLsWRkW0FsBW5gsjkQVg39TxdK0+ZcxTWG+qwTd5rkPeUOWnrY1tn'
    'utcnp0zLHti+DWl13VzqOPRMU1/o8KXigk5xCvqA5eU93TUCaotGnw47/oSlE+VUA5UJAHsxs0IsRU0HFJC/7ugk4UrQqQhxYQpm'
    '0A8YUs82DS3IhjMcLJ4FYC3J6U8AsHJxPvHnHkQg8w1DxJApdFRNI1QDGEBoN9FALmwnAAwk+L1QbfcKuV8AbtD3CQd14RwhqQK5'
    'cKU0EikEhwgKkVyrAFdkFhBnNYF+gFClDnUkO9pBrPwPIDigjriXHGaGFRIhm0Emwu2//pICik8DJRKgJJq4jqiZJUO1EyjgAh42'
    '4etrP5pU1GoWXkBo0aDz4TQkO7KPX2W6W7BmkGOLEEiz+ThZN03D8QwvOw7pujSUnVL8LYAxb+oj/1sAJOB88U9E/lxYnrrUtTzo'
    '7NYYxDwsDyvbxgMt1TMGIKFP7JUOQICgaY1JEdLQn4qJZr+RJRPa3UHg2/hEMgcIZVjOwi8Ar6XzTunesCZAm/6O2UxP2s65TU0J'
    'SaETt43wdOn/untm9xP3Lia28OlCF89uAQs7manIkPl+qhYSPcm7lHikuMthEhd3L5G0l9cQkL6ZKBsMJ4apxQwhKBxgU4HQgRsB'
    'zwXJIPBk53gv3aXoXkK6J+gc6eXfmIXj6O4QNINfGBO0H4ACmyVTV2BFfZbtLJ9e2YCL6yZaEv6aWDEizDkKEdPset/Y0QUtjSJy'
    'CtMQ+8qYEjIMB1Z/Mpk72UpyrHCig3WFdouS0jfL9r98A3RRgQK1rzsXmyQZBWXDAuHYRAnIX3BwfcC9ghgDqukjdWH6yUoKRB7Z'
    'bo4IszGxpAY4EGuzxEEl2xSIBcc1YFo3O5uICDKo5Q9E/9nVYJRzG82224q4U7LFUOtK5kfLHwo5MXsV2K2JlqOVFeXlAnJVKBPg'
    'qLrwbUTnUYKYSDZLdekKHHIwKVqh/0B61oBc8WdaT6IVw/MThTNgEc5A+AafAQ6LncVS5pboSAQNYPeuH1MBmyaV1CJCMD+QLlJo'
    'XCgl2HMsEu4AY+dsbGN0omRhOohEz2AVo+NzHCfagmPiRoyP9vZ9oShcaRABokr/gPpYet54JSV4FXzbNj3aOpHnIKdjewYVK13d'
    'VH1jqSfR4NL2D2su2bUKRzrsC58BPuZv64Reh3+xm+9IfeF4Eti8VWAFSkgyY9cA3QZ/5mEFc9C+mqeSsod9c3TV/yKdAqY7668B'
    'eirYgy0kDPAvuXCnsJEuSavAzBSONJ8cG/oW1cD+buOUgCVglFtl+KhMzPzCIjPVwEJk0OhYQfeheVQqU6SfAZ8jK32KLSbxnKPk'
    't5sZmupAN1EHHE63NY39Ikhpi8aPX+HiZr2ZappHCw0U19CuEqzqu4glkknSYvC2/BzCOnbVwGgTY3l6OSFNft3KQ/Z4oGmYBFDe'
    'x8F+xhdaBgTlr4gfp3SvwVHRYIAJ2/XQLiKOUkQNFnza0wJMvwVYi4OUAHgASckBKWiu7Tg0XyRuoq6uqd5E3xJpgyx5unfzjclL'
    '8XKjWkvVS3AZwq3T6nyEJQPTHk5BdrMXwwnUTueCLgkLD0U2Kmck1Zqg/oJla3qiUxHGRKzTdrdmWR0AXQJ2/ALzTUeNVrxHOQrs'
    'KQHeJgS1bRrfJ+zTtSwtwO8xYVCYs0JObJTb4iASTri4z4xKsH+kzgxzkxBcU/TkuHqeUlQ4AIFVQLU2KygAI/MGLWtIEHyEVmjj'
    '8w4MLV1CuYDNBiYK8hbqEDKVL+iM5UH7gwrDqYg0R4DIg5pD6cLwGPiJH0gtVEFk3rVsEF4jJbjbYRaR6mMBipiq4wH6Eya6W82m'
    'wxHJQNleUX4bLR1IUkqW9fF74dshxBgEzRJNB7DtzXpY/cgibFrJFZIS6XSgRTo0sH+yajALIz+zLZtg1CkTPe5UkQjQxHgM9ZCJ'
    'Hhlrok7YzEz3PBUtBN4EBNlgqif2THeQXYOgE854jHKkMDIPnGJieKCoRxbjhCYY78/m4dMpk1eIyBBpLGwCzUtsynwzVM3hF+BZ'
    'yxWTZwSelNvLGrYmgHQ1S9CR8fxrVuwVdwhgyq5lkjRHehWMRNAVpsB7p3HP8XUPmQV4DjPQ2SK104BqA0KzR2QqVjBAMDFfgKsG'
    'KcHmH2QHXqrR7UbQK3Xv6ykwEI0xADdRMg1sOdDIU1ZEDWYw5As7WEY0MbjlEdiViICfRI9TBgY9SPOB3tAKG7d67lsfEUy2rTzs'
    'Z6iVcohtNSCc2NCyRgGkWstp+PpnFbqQ19dA2Zqu/XbiuwsdN6so7mn60HZVOoKk40jJAV5G79HSHG0GhGNRWOLOLVEEMvwsQHo5'
    'KfrK+7SCRJUFw8tb+iorh72jRWcK7wIrEA8OqPLJiiaql184GhB6FhJ7+i4UicIfgoRUrVogy9EJgbIPC9x95wqSx+iqpwMG50EA'
    'gDV4hF5Hwbrxv0z1zQjIBzheVOSvOLIpWwpifYKTUbeSgowdp7XMcJOdifbYXV1bDHUNWHIo1uI7GngO9zPRgWBpiwYn0EAJlw2V'
    'B0qhIXP8I5NjKEsNzRoKG5rBQzQCYfpLCY0SpzFPnQBPxZxfU/s0tA1CigkFG0HF3YGPUHJilyIqfpbevOOVlJqnbJF2CtHiagY7'
    'cGNrwyJdJFim3xdDCjsKR+LFDjPFjsIpi1I8DDidbV/1F15mf0XYy9IyxQhEEY0dt6+1i62SzV+OP2Q+D3Z3v+5eEncR4t5NwAOd'
    'GOxkFYcKhDNB8Q4UlFHazhVNnGmPPzhGCdN2cmJSNaq412t+dPS365mI6f3WHeY2soxEihvhRakqyAPoCR9fXt8lAi5DBOnm9FmE'
    'v+jVgzzLnalmpordJovdFuR37dEh8qX3QllmG0wnPa47u5oZWbEUysYLf0uxSstIPJuUkehbJCOJbMSCRWmLBaf4biDLZtjuB3ar'
    'kyw2JmuikhLaVkI59UM7XR/TVUIGEivFwTDHniYZvCrtxOxSKA+Hy2lCA5BwL5AsoGRyQu2WTeqzqTmhbylrW3IWRGk5SY4YH0n+'
    'STiDbVRss4MOyBl+rdDPdNds4X9kZXyX9IT9pr64rVjd3WdV3ZaF964vpNqBimbzcJR22aL53Xw/tOpv23BSdRs7Vuy0UeqAlJnU'
    'tcjMgmpV8mKiDecopHuiNWS4Ks9FyzCWAGE9zSrgr7yVY2HuypLecufZrWKmEYsKIV4KW7kKvuEcI5GIWyVjS0AKa2Ksfm9vPE3P'
    'FMTIZWKXxnF47qOZttRljJtbAlla3ZaS3WpCt/ZsZ5ZiUy+ot6D5A5IhR44aBU0rLbSnHMZ26d+pDCPD9HVqlt0EfuNfM+M9KCyM'
    'sEMpqtw/JB/jpKVdy9p+TxqA6xK78cl1/w+cpAqiuo/N7HXWTLQb1hT6B6Yw4KNghX2qroHQt0unM5JWxibZbY3sunvMwal5ztrM'
    'CZ4nFC+o9wqrBXngSMUxLBHpjUELweAkNg4ihY5sm1Tfs44nrL4HDWnw82vWa2aH7rHPYpYwJaKhMe2Xs2W6PmAW32tL/5TNvlwu'
    'bxvt3xMzQsvxyCCmqP1jS/eBjzFX9r8EAxxNhxQNNtGn+ZQ+/UcQ63A74OvX9wSv30PK2uVomRiQa3TEym4KbVvH3nFpjBcYLiU2'
    '7fHpKm3pGu+56uzwtAo6cEddJJKiXIlFUS5ruciU+abPHFgVvqkjP3BhC7alf27asFQNYL3xGHII4uftfbGMviwepTvFut7oQ+YS'
    'ZXuJFHfuye6UDaCx91x7QpgCJ8IIFVJeCOw+e2PS0S2qibg2Hr1ju9fjce9KRxohW2FHbzLvrOsj3pex7iFGfi4Ihj/OyDR7NNyU'
    'FLbLfFve2uwnOAvCjTEkPhhbymeCUUUUShbE49gWilAf0SoJJu5E1JD7wRgFhLR/u4bwwn3bjGRUaY8jXr1r4+5TntOHXegjzTia'
    'KIVuCpL/O3eBAqr4EZp05EsXLI3H686BVSipGxPVI2D04Wim7asp4qZvB+yrQRVnobE0oGz4m3Boo+5O6O6GHqerrBsp3WAskG3E'
    'hFTOHZRk2FDiDjxoohoz848cJuwNG9ON7h1wKAmJmfY+waP42Ewe7rwA5v5y/HGB99f4QEXc63kad6BFHCJSxJ/d0s8T1CTyCxsz'
    'gtjmpCRXC4AyT50skrur8Tzr3oft+cphE/Ix5yFoXyOTSjjL26cIfsjiQbtJnfT+epyrQtq+qHywiwcPV6TA2TbgiKFnwpZ/6lbh'
    '0DM6XTjSkL59m8BIkvN3X7BYfmV+3bs3uLPAzPA8qPfrvkV3/zZo4K+0p15fHe+HZJ/3Vkp8ocOAB4S84867pOdS2e3eigkfWSDF'
    'rG1X4P+4WxJNAVywzLwf4P6xJvht0vi4o/0uQH7MnsFWzRFeJ3SLlN/mllnywz6IdKshqdMie9zVy7H9wS3xbPHImfnQvv92QUCb'
    '7Hm8pPS8Qx0/cnQLmr7X2zJhPdoyZ5cybCSu7dDRnq0CRqBEHlD5hCNUvpRdZFtO2vF5j3dUdARo+8TUNtyhi8eOLyN7uEiwkxT4'
    'ezl75C6463RQapjNgZk5KJQSOf54HDZCp+MJCBfOAxDHy+05PdwZFcryqXhJF8Odo2yntpApu4NTOuDDmIbkz4FUjuOH1t7fTkaq'
    '6VH3mv1b4FHxUJ8PAjEkFHrV990vxGoJXG2oT2xT07fcOSNq2auVJMYsuz+gRMbKOM+ET2uFfOroGtmQYxNWzkRBIaNOyqmC9Mib'
    'uKPgwjxNvtrmLigzWxS76jFm4x17MgnUTHsOh1tptCGF+mXtIs9MM2SSU8RFfDrJikqeMudKUi0kHccTVU5SI+BrifXmPTFACsWs'
    '7KltECJSjERkd7a808ISSHm716REcTLG84XtJzergqFM222TQiedQ2Gf9fQIokFP4wMtxlLRrvnc2909vszB4W6BHO4u7XdQzYCo'
    'HhRRk4Tz+fM9lKpS3HVEopGk8WPbD+SAz+H7rVNfYXum7zLtGBbZjEj6wArs0dLonoP4pH/YYrCt+/nz5xmdjw/8C375MafjIxC3'
    'TpzL6QPARNkkO7o7tb2PqbBbTadNJjtOHh02mYSqdOjbtp8gsdG2rrrkpNMusynPs8fY1PcrqCkb43v7DMdHcdhhlo/7clB+Smzy'
    'ZE9SIUej0UJmxvqLYTGeOx6cZnbw+NIfU0dwUqgzImu8l6TfgygaMK7jMPQoe8F+U+nuLYEU2AX68LH4IDu8+QLtP7Hj97EdpmDD'
    'bT9J7wd9247Bpj0PPuiKkm7Esv39ujLOx0D1DC91IjWi66NOZcbZd9ImGj63zIZcwhRKiu8xML3nGJu2pBGvLXa7WvrsRV6jIdNI'
    'KtVxmSjf7sqP27tKGlm5DMfEo43H6xKkXSp8Zs+VknGQYurJHBcl1tXDh0+xwTxG9zlFiEFu/cKXyIYsN3K/hvg0VF1tz/wfucTu'
    'P3gYGSi25L7fYf83Od/vBkPYOqASM1+mwJXSh1S40JOKDFakJpMXwtnzYaiQv767X7HLxP/8JR84O+5QlLGVQhCO6eMrSHx+N70o'
    'k1kv+JPFDP2LVc+BSc0T0w0iHVMEqvjlvdOiP+Kk6PYpUapiix+zmqf6g4FIt9W2A4c9EzUEYZ62bfgBkn3YpXmH4SWANek1mTJf'
    'bgkzP8TUT1slcWiP3Sj+ge16luE4uh87/dEzcdkoDoHr/Ed0rC2ot12X007DMNiDqeHTqGrhC/VKMtUZztsvyTx52zUI2w3V4b2O'
    'nAEGqdp43y4V6bQSO9YoW8a6Xf0PhI/DG+vybme73RFFEuC6+lJXzUPwSglH4j1nL7cWyOTJxZ3HAHex1BCYNGtdGf4EJN8Y0OSG'
    'acwh6emuj212J5fxwDcsGPrAaz/cqnmXXPZEH8j45UWAptQpIRWOjr6lA+5xBSkpYRD7XjaIAgc8O5+UekQ2EvM/ZE4H+pxmQ8WM'
    'RjorSQnvyCDg5i7/54SYy6U3xN+TND0d+Xa8fRQm5olLYDxgMnv0aem44t3bifHcmFZiRtJhR6it46NBEgv7wySGDRawUlwCSN27'
    'akvpkzQMAhq7Af7TzPvesAND1/ZAJjDcxFQcCjsQuQ4Q4k+eoKNxTCIjDBfvqwulrJ9Ays+Fk6KgEN9zdIN//8DGB+VG9gi/wdB5'
    'BBMPx7OjWO7pww8efVLSZIIV5FKVHb+JG+TJeKIcJ2oI6UJW2gbLfjjaUH5nZMd3NPYtG0K6upATfCyIy2cA3+G582sxCNH8azEI'
    '9o/SIkZuBoGTxkQ/YU/CqO34SPL/dhLRWUhmJww5Pk2xKTg8jZGff/U2s4FtYqT7EwPPatknUaz8ExJaR4R/J2e/xrHDTzj+BAOH'
    'k9/ubyfCSXHnZ6FQIt9hLcnk4Fmao7znO8ZAD5oo761EOiKPuKOdIKr5yQ+PaY6VF+lwbo8sLqN7RjYGqMTw3DKvqGjjIMpUnstz'
    'k7yYTGC4pZLqhgBAqDzDU+WLIT0omXJeSiTyBYlhTZmRKok0qIpdluNceXiql5Lvef7tYKeAHdrvdaoMo8aITNks5UspuCFtAsNX'
    'UnH48D8FC0No1DnuYLuu/m67MxhMaBgazWcb5lmmXC9nGmaDhoWDDWNUXxevqjjctsSUGQn/5g8jhWMuvPfGD7rBTzgRsbW05MSD'
    '9a3fxTCFwMUpDfhlkpsZDlboLawPswMxS2T8ktwfwLPwWyyUBQZ/mKAmcagrAfnJBQlgwp+JVIRtwuNkkd9SQRCDPPlE0XKBlWl9'
    'cerBHs3sd6cPgRVUHCeKFuXgL2Inly/nyy8HWyCbD8eQej2mUBZpb8klEuA3TDufTMjzPfklPbhQ7VLMFAJUgdEU6gr5LeNvRHjl'
    'INDEmLIH6ODuEODzzIb8DBYeTolXHnx2kbNnGHA5yYD5JPAz5D+lvFDg8H9yJIC9sncS8KfDPEA1rIG9em+gecAjWeVwtyqsH34g'
    'IUByNMd5mHIWhxMSY0hEhj0IAjWJvwsBpLGZeVSS/c3zk7xcSDJiWKnK+UL5DhYVWGnKlbiwjPQj1MUs5ghpJHg5Au687ehHcDIc'
    'lEIJZqWcWDtg6YNkts4nVx6uUIbisPbgAiQyUqpD5RJWkwCcLC+9UnKRgoEQkuOAWmgZVuWCgo9JWoAPMBJ1TkkWR0ZzsN9TfTOw'
    'QSF+B895gudihOd8QsLipASeR1MsMcqkwHJIaMGDGD4owYOCbIyk8NGTFD7JoK/AWngQeFS63uUqeGhMhUUtwpaSCP9MIZ9IBVxj'
    'ZfIDJ0oGcAoyl2UrHJcqUBLzWE8ecC9VPTBfUhFWkQ/rOSAuHNGJGacUFBGjdvCIMjJP6n0H/AaIcTK6Z8oE+2SOSRfaBSpMCb8U'
    'YJ1RJgKZizK8cWWcCuGdmfD892ZCYCQys0I4xfAQIgJMtUDxgf5WJtz7DeaJQqZrR6AA1E9QERugDwo+iPhhKTaQcHFBheS6OESJ'
    'kkcekhc8lDaR1POHp1EzlsYRfI90HSQNoABTzKMMSFcmWMDhMQ9/D4tapq66edy2UN8dbZGRe+KEk2ACYV1lJxII8NAeTDCLKy1X'
    'MgETiCgB6AGPBxuGp3dHmVBuWcVOhVKrUpcjMZ3DkQTeFr1jykRO5z+8HvugYA7fnewyI07yZSIHsPUS9hWkanh+T2qnbrLv91Jc'
    'SglBCBfJHiIQDDEnvScoD6dHrIwoKXNAyYGMvh/nbN97XxItpQRRUOT2aKb7M5R3Zdiv1Omm82H5mPL5WD8qsCBcqsBZA9QoFRQg'
    'nSEKCpCI/8maISP3OAiN76re5BjGBEQJmCOBNpFR/uTM6iwht+qJmTVazC66hMdwS4kuHEvpvXVMf5+eufJQBM5UysPSmpc9oGr8'
    'vVu750L1vrTHzFBKft+v6/iuMX1fRweiqMfTRcRVATkbLlkZhiBhR/gsqfyKN50FtzfqLoEDOCozNFXP++3EBZH2jJgck6nkFoEg'
    'Hb6E4T8BoEGdGBaCfME9imh8++2kYprMxl64YVBCD/qBdqMo706b0K8LTw8uXfxDYLYg0APMvxZpwxEc5EQaQhHcSRE1fRFsHo8M'
    'E6ssYsagV0Xo1p4OMpHNfndXa1AbRl4L4VY9x3YWTgA5k4kPSD2YQ4ia+uqUQYmXhGHE+zdOzrA+Jj0kDGr4R4xLaAjYOzTYNwR6'
    'FMEctEGM4SQqOm7InQT7eWG5TI8B6qgHbfTBYFQGd3OCGT05a8YvWRAyVd0TaT+o654MBF46QS72RCBJFEvNVccMBpOwLd9OhLj8'
    'enKGRf7+r/+DznnQl+ng5OzCd83cfTDF78DQxmGP+gMv0IThxb3BpN0NtI9voOJlmrCDQaPISNJUb29X2hNj5O9tL4m+34HJ1SCK'
    '/Wcw+cJ2NqeMo3q+TnBZWzggKtAwbOTk/MkZVv97I7YedeEziI2dOHdVazhJ9Ytez0hO0ula0B/SSbwNZ4O7suMgrKnhw3xBid2T'
    'eHEculws/OOax7CtAwIuDePq6jMb0IgAsfB3w9A/DoYHnMgICvLGrCaqj6ybGdqOAZCoHqAwbT8MNJuB8uSMlNwNSe8DkNwampeB'
    'xraC2zbDyAyW7mHLcXzZAExgHKdIbmMjpGxkJdFlwN5i4NHdKC8AN6wpqPgQQR7Zh8uQGOJVEKHb7Bm2rcm1MLIQdAFnNqprN1yX'
    'vy+LqGjaZzkEFI3m6gv2eqpvAINcnZkvjOEUdyvx1mbsexU3roC7X1ue7v7uPEMN+/QploHXJ6X6GNFEsFZt0cSHxR1ikA+7wVAG'
    'tTX7MHZHrkbGAKTdcRZminkhpqUAB3r5bqiDVrfAJlN9HOAN1UiIkZYNMLoMiQIA4oJ6yqCDDCEbe2UFc6B73w14I2zgHehqrp4k'
    '72A88SuF6LsBwQaCardG8dJeQHJ+CJxh+vsygOC29c8ygTa93dhjRjZl0quJbeqxrBVU/3uTvJbsRYrsd1N8YpRCd4ST+POODKS7'
    'J2d3KqyXfmK8g+x0+z4oEFglghFq6XnVdfEKvmToduIzjeHHhqoJ6x4NUYRrMTCvUwalHjwwtYSVLjwrx6DgDBSM8ljMeuixUHql'
    'PWl3YK9PyJB4FWjh5IzBXwC+tvm1SKBMwe2kOol7Sidnt7rueBFnx1OSACBxgATIhuhzujIAHIPeE0AMhgTymUoj0c8Kvxadg4MZ'
    'a597pDbaY6TUWEqo2WYgoMU8gtGQNZCFNOASwbiQzFE2b5vU9zYK6uyuJsOV29TVJYqH6HoXMNVQ1iC5QzZ1RItVQlLJ9rrWKNsi'
    'MFSSjQE02VVnBhWzr5/F8zb6d3wIzc8DfPFRqJyg9hMOBREJ0NwJUht6zWtEJAg8wmGW8CzvBIfV3BxG6OrMgfFg6mFgiWjsd2H2'
    'AVCrKizmFLqfPeJDswDlFLDXo1qcZ498qvmYkLBSXc0jCKZbmncYwhpUAhDir6Be6D25XTPGi21QjyAPWigc41+DKCCkTbzZIepa'
    '3V7hflIsRI91P7y4Hp0lie+RR/Vuqq4SQ9nZr7aDI8ksVXMB1dA77UDvJ79/LdKv2VwYsXcBPL5Bfu/LheCcnD3Bz3057NEImrIJ'
    'bHgPUpyvSDt6tmPUokG5gw5khoQkJVQuy4JPwD6J19JWZ4cLd6lrqGLh731Aer6rItIhbdCno8DcpqEPMsNWuAEd9OaKaj065W4R'
    'jQX71CHWnSJ7Jqz5E2JKuOcdSSqtdOVH8KE9S0tLD6liRw+AF/z9b//GAAZMI+iTC87ItWf0nhHbKTBdS7MZIERaFbLNsGp0okwv'
    'QSng3peb6B2paFDcL1btFqa6xFNpl5WUgPuFaHQvXz8xJ8QHaq8YlEIYfR8M+CWAgWq7n4KEeEXthuS7bFVrjNaaEuCCSz4/I5bS'
    '2ohFA+pHrxMUn1TKA4Olhyyt9u+vjurbPZuRlx8mlV6TDn55aF59/RS/oVyrjUHIUnwUIyJnh9TViacn8L0tRsqdnHH/3/+1j4Hy'
    'J5ECesbvzyacnAn7v4onZ2Ly6zELxEXAF5Jdc6xxB+Mbb/UBViBY0MiFlPC4DwyTrgR36WUgnYcETj67hJ+fXCh2SDCHhA/sUnwI'
    'DaSQxFvCsfxoASSlk45pUqCJZk2saesmoCHKUaC7OtQPhlpQQ/LYQfXbFB/Wh7yqGljToV40p0f1/D6S7z1lDswXzR4uZnjE6Lil'
    'rUqEdqKUqBhcSCNxbkAOM0Flo+dFPebv//p/RkIriGVDDAyBG3SoQReYa2toLlAKjS+/C1fHz6hUCXQPOF5tFg81mdFwnJ9gsWXC'
    'Dnt0AwuWYEw+Za5sewwq/aU99IjkfmcMXP1+NDKGeqZJaDRDA/ZwDbIf1l5M1fOlgJ++7pUsNSRCd0rUuy+FmbY3p78GVH8wUZIg'
    'vP1LAVL25rYHngEKOLCu++AJvixMLPZmOHGx9ECGVPu9Yt1egjqklTqbACPTRBbM6AcJLarqEL1R2SCkuqChJOV9lGuFe7frB2PY'
    'It3ez8WCbCcMSYalIqQKWLwdY+gvQJFJX4J3pFkjqr1JyJUMItHxiOlqpvpIrSEtEjynpIu0DIOcRF6QJBClt2hyX6sExUiz4ZJf'
    'YYIYCtAV4sh7SvYwHBJVARW3wPgZq9AADw0GBszlz38mj3/5C8aiA7wF5ZSq1Ei2ODJB5UATIZrH1wLCkDkT4n1Arnv0Unv3wIN8'
    'Ug2VohkQ20gAZt+2A4jSdANYkb0v8rsk70MOCMQJZpdY2wmuHcQD+KprMRh9FmYMhbU23Xi+DK9LhOl2mMGG/P6MmwLCcJQQToWL'
    'neC2YRzR/qD7Kx3mi1oyyA4rnk+c2dpnbPPE3/wdoTx+SDuCMCTaxMfcQTqGFnMNfGFMYhn9xoS2zoyl7mcvRmZLV31zQ1HSQTSL'
    'lEFirAN4xjruBZycdYjZ8sA414x4axWeI+sqzL83dHF8qb7DfkU/DP94dWV3t5vU6T509rAD7kF3ISnlAhba0H+XLEenIc/CsAsY'
    'DA1+R9RL+v8HXwV2Q4EMd8k+PPv0LECkrhO4vrOro3Pin7gLgfFLAPH5Z6Alno/HUNHoOnBP3AUF/RbAcf0ZOALnx6MgaeNl5+iM'
    'upOi6cdAACEA5QGgyt//+78drPTcGI/31Um/Jav8DavM7dQyk8tOSsPO7hSi/evTOz0T1aE72eRw7z4HAdLG76RSJ5RqL+5KdruH'
    'CayXW/r1EVrBXmUoJdZQ4Y0OSFLMHpGkjEkclllMzIqiMJnhDtA+adWBcQbh1kDL/+4cKDadndvrfd9pGAvUTujDXilaRzGa3HeE'
    'bhj7FdYtee8jA1ZDvEmNF6Zkh2tEev3x0SJnh2FW8NfefhrWe2o7ifcBOgv++hHjcJQWPWrpnp5wEkJBJrmo/BwJqbj39IVupuAR'
    '31OKXadk1L6igRXqSeTdpy0f3jhKv3yEw5Az/p93OSM7MVucJfBIcokEHA4pNkeOP1/afjSmvz/fGcYd/CjfIWxrhaal1ObEgT6f'
    'nP0+swQK1qedfiItLNj//X5vGHooMJJefvcpdMLe/0MWjsS4GxVN221/QZcdwG9XJ+GLM5QfDvgX4qoHqA8TYgeemcSZ1nZQe/z6'
    '/UP/QFs6YGX74AqZtSgbmBL7/QUdQ0a2xfHbUHym7l/6Gu/tO96ht4Y73rvm9SFDP5/JctCenKYio0W8MxO7K8RZM5gtZMX4/t0M'
    '+Hv2VO7IObgAPnzZ6ZyIW8HWhqHuV0Fa5KWNBZDtMhNgB7H/09B2rc/pKoSHRxiHQB1U8HAr99MSK8qIpwwhampCAcIaTi3d87YY'
    'brAN/one6Kne/O6e/mY0IL/LXlLURgcJgwhLln6UtRPGcnzC0CDswJICET0jAUVBjyIXk/0GUFLVMhTsokmlYl5ylM3s+WIBD87t'
    'HvTkCaW6IBxYL3aBQsNmRbBc0tcfBkwYVgmbQTvK5rcTiRE/CqONpswYRvr6e8LIFliOEcNzT0lAP4c4gfPJPsSpEHo+BnMwglHC'
    'WhNwgn8v5NGthF8xQkJ3hVCiV1fqJvZvwDg/uN6PyJY1MsxvkR9S4HJmWyH7/vqDusPH4V6CqogiRr+LjGTm5by4VN4+2GkS0nVf'
    't9HG/APAV6LZ2A0+D9B/CvgBrIlp2GEZ8fH6rUnoDPYjYP/I0H+8h5+jQRKUYD8NdsKF9BgyxAM1sbEYX34kNyKBqFIh6rgPTjO9'
    'VyjBKMjrvxOXICJKcrR+CIkcGq7Pc+4DfmsoQmROXhHPNbotQLYuiQJpeNHpivAAj2nb0OWK4+B5IDtwKKeZ3veqxZrTxpRzssNA'
    'T0DQmSYtMF8oa6Xa1NjWgy2vwJmY4HnkHRpaVo5r/47QSLS37hrEZduboPsM1ZLsoOsIwCmjF8YF5r/g3SC/rGx3CtIocH76TgXx'
    'xGGASCD/iuoN1LVnY3YbqkviOx7LBdSVPAKD+UJTPiPT0yPhkRgcVG3ukO2PdhWMwKbbtb/TpmI4Jrss8NEAvXeci+zeulvqxA8c'
    '0YMaUui4nvZaT1IW2cDG/eVwbxmgXVBXcyPcXSh+xT1xWtO7+4fJ7Xty3DU6gwxdGw51x//tJDj0e1p49WzrVHXoITdQsouYkFRY'
    '9lRHNpgvDfeEoSGLaZBJGzcV4YPhwDyEdeyvxJiN02ARi0fxT3H7NOQhnpD/9Z/yedw7IzfxEjd2cpEpuclqGZ7OcGH4wq1uGFji'
    'mqB9C3ypIZcHPTwNdE30VBjhJo6NV734qmkWmHweGgp1OXJdamTki5KD24BPor1aYjnUXaj+XI33i2i2E8a1cdZVU3fjky6xjZSW'
    '6xAD/w7LM/2ccuK6tFeWaata6tQ0PRyaPMkdnnEmBx+3140I8IUDS5u+C/AtWGnWvbDSz1f2lvvKWZd8wfDcO71faME7+O8i1yQH'
    '1PbCi7N7TadrH8SULj5sK8ColyFJ/5SObJBoNNX9n7Lknsh47lvbIxF8y5Dw7gqCAQGUT43coSLNPa7Fl7b1M7rbwnI6Vo3PnI1b'
    '7+R2IWlkKARQlh572GnxTsKONIPj9HHrUS8kZoo91ICER6Z/Rg+GrH4K7WD0mBhvo6mFL1QgONtxkC/Zo3esOsklDVtDthWvat+P'
    'jLQFoJuztNcMgJvuTW1hJjuTXIvTA39Bvb+CTpA34i0RDOhhD4Wgjja51WSvL37Sc/Mpmps9dd3Z45PkCMIYJCrOoBouBlgjo+Np'
    'oYCzM8MJOrdoeIJ7pXsYecT1fBLvW1c9veBs8PwecTpHHX4TrwRkk0EdoIWYul2Rg3J0OfCGruFQAzmtHwELlrKthfPspz//RKJc'
    'nwQwnXxjTniWlwocV2D5Alfi5JNT/O4tZoQnwPdK1AECR7B1Q424ATwxZuPnVKeJbxmuZF44dXG/iFQ7xGMY5IA1LBgkRXcLFAjq'
    'mgIgdCBzWGGAJp5BvOvooX9yFUaeBOkOAfuScS0LKBCjiOABSbylOOGwptK+ES81P27slNlCPAq9ykSDjdZgqpiEE8lUyIFMmEda'
    'BgQlGJzoSmMd7+NkBuZCB0HKN0gAnMBr1j8NwCQxYKLiMMAqARlFLn/hWuiJp0dxYjYeE6xhLpD1psDgcC3CVY3czG6hlo4ZSdgG'
    'os3EIgfoCLpHS7XTM0JnNzquiGf0Cyc/Mf9yehiLxJKwhUV3xAGRHJeCuqdUNg5kTBTVvcBHMDC4ExGK2HqY8PAUFUWhmBHuNCRQ'
    'CVAdT/t4Ojltp5sjOohk1wuTicjtq4MsZlGw8JCh5qorazdo32L9sp2nXfhCToRRwE5jvIlgJeVApCcb6V+TfUPWe2T/Alxz0W3U'
    'ogotHslTiS9+as8lmD4cBTLVvu0gUo/QUZMY/LzEKeH0gDDXI0QrWoQSiIofEO0QK0/psSlIIAjk2aeRvyhiZDj4ZOnGDaxp0Dks'
    'EfqBogSLN90BqYTlVHpk/xh0EsRtdLrAcB4e4y4siwZccUDNNdCiDgxAw8naMP8MatgSSNRBx3Qiaf7zCQV+SEs7uo2awGBhEKVH'
    'nwHiLImPIYrsAQWROzjorKCCnUWgTBNGiC04JpR8doFB55OgKGEO+/qRAle1NlQRA3C9JLxfnI0/sS2BfoKF5GuqC6cwaZh9gxvA'
    'IGlhj1bEsIAdQmbkuDYwFA+wqEV5WNgIOWRAYCUG5nipOmbeuN3ztgl8N704HNBpoAORoEDIiTHBM2YOesYFZ2yDZKR3QzN0l5JY'
    'djrS9X9jaKidaARDJZyQ446APcyXwKM6dL1MOE+HChtQMw1ZE7qAQzFaPsDpFPUm48OEBQhDRfpLx5Yh85SuA+nd2xmepkBr7jPI'
    'rQOILuNASwFrjI6SIDv3gkGHCVe9FOOACUcWCDI6+ZieC8paErPATIg+R44Kk4AYoeQWUzm1l/l6NGEbHOVpKjgASAVpHvZzOKWH'
    'UIst8BzIKTtWmEqIGOiSjFfzYdPh8h9wYAyndsoEkWTwexhiAvu1hUyd/fV9e6cq5gu9eiLqLeUFOOm4igIOBRvMwbgSlA1cGtAp'
    'I4+nV8L1bWVHMJDFMTXQIAjQGYokHXI7KUzRfRhK7u//6/9NoTrdknAoju4Wcgjaod2RhmkgEheVQlMh+wpMA1gHNOzRtQftHiHT'
    'jIGCDhw1sQK/NbE1vPGW1JYWakIYA/tIYDABjYGMuw6EraVPF2SmF+r9dqDarP0l7l3WqkMiGAF3tRcYxCE0Le0C4SudqjTEKNx5'
    'gSxI1trgTAKuwCPDIqsBnRFKeIHOzVC/k6NGlS/vGdXMUSZguXaAzvTk6c4xe68QXVeoRECCO20f/KAs45TgukPkgaAyPEtFOxuc'
    'GcVj3enyMIhIfB7xZ8KBIFb4ASUch4QoCkz28cy/P0YiL26NUdguvfmKnrb5Fjvhn1IP/FMaswrnioaniE6fRQpOdhjfqRi5MEkL'
    'z/nRFShQaUKr2pcQU2lWcttPwOjJXGgk7kS4ZzL9GoBLcNhibCsOwEV3B2x6JCxSVJILJBQck6WviFmCnm6ilW67x4EoiXIGlg+W'
    'VYQrgz0BypDVakZR7v3J4llpa7KQsIhKHYop2MUrw68vBt8yh3kizAkJEVuPlDVUH7bxfk/FWmjwpFOETJQOubcBJj07pdZ8snPj'
    'BVpA6Iwcx1vAPHl1hawET61k1Jr3YYUB++kvGLWVGAMSti56pUvCXJ4wf4RX2IaHdybc2fdZgjKD7P1ahCpp3dTAHkJEr8sNrRRe'
    '8EbcFyfk9BmGhiI36hLrDAxQiKnYdzInyEMY5gug49cTMqJAJg5umNCIIIzn6KZJjgGGprk99p+9DnAIKK6gn3UgC+KXauHxMZtY'
    'BNLIT0OW/p5eX9kodocD2IV9PhiElWgCQPxkFfyEsTZ5tUOEOqQhrP4747diD3pkaOMTfq61PfLxMUcSzCZiqaFPrEoWIqKwWjo5'
    'x/j1011N9DK7Dh4Zly3TQRJyd88p3J0heL8z2NzeCL4fo6aG7Wa3Sz9OVuGBzVNYOFQk+XiTiWhqAxdGI5jdz8T7I1HcfzBJdYDL'
    'J5zg8QBpfrDJkwOlkbBHjSZoO9XJudrU6ptYCjT7ew+fMuEYvk9KVTrGGX5gbY19tONJ1boAXjx5oqtEjz753rWlmm7xfdBrAQpE'
    'hyUmNpq9QCyBdSW8KR5XXLr+UMeJ74lDniX2uzQufpra/yMdB86AdoGWxD1nEAN/mKSqyHypesOvP3p/L7P9Gsz7A0rDJylZJ2QK'
    '0d7xrjPNJGdwqDlVb7CZlMrnpTaYkocVSAk74b3YjhTprdMKrj4kQVda5Le5CTeK9h0+IGHsz5rwc9fZg11jcuUaWhpyvCU3dh7I'
    '7JDOyC7sT4nzknjSg15HADNH9prItapQA30Fhc8k9Y3DFLQAmOomSAt3Cn/Fw4JAdGoUn9t2w/nYIbOlZcLOhpwhJQe9gZqw6rC6'
    'hCsI8f1Bcbv6bu0zdW3q1phcFIYXMaRaI/uusYsTaTA1rhiUJRrUKOrKyQ5KgZwdezw2k+dhUX8nxgqyrUJCcMTK0ydIJLo4KpbG'
    'w9oyNEylqOlAo1GC8SHykEv4DcTZgqi8JKMXRO7dnbONwc+CnDi5e7Jd6maQicYk3ZPt73/73/7+t//973/7P/7+t38L8tNTMTtz'
    'x6fgg7wWPcm+P3MxyIh8YU++KIthaYequgjyxSm9IGUYh8I/VMFlOCBRQO8DmV+CzBjX7VA+NoI+MRPbHAI7p7sZh4GYmOjna3zP'
    'kEiNmAGi2AU+oU8G2dMpmoA0j+oKxNIdBCpxiQ3i4ypbDMidkXB72tp5Vz2kqMARSo94PaUfwhaC0AtpYiaZW7qXPGF2SY4w2Ri0'
    'jJ4x27VckIJJd4rvjL8QO0uQ9A71Ttjn0EPyHFiEyafAPPSdYSKOWYJTY5IKDJJYGa1zDMqYiN/vqjSsTHDk56edwaAcdDVC/9t9'
    'i+KEPzmr0wg8e7MIJ2ftxWCSybW7wQFCiW60ANIj/tp70N4lEYESEUp/2g78lHLUHs7Q9dJORIr/HaNibLcc3tv1j4mFsd1+4m6v'
    'OL4lTQmg6H4yyGVQ7bGA0NuUOhPXXownCQUaU/0g9eNwBHc0HT0bZAOpawV35xHuFgc1IPHfiCvGF7wOocjQnUR8JhsTuLv3uYOU'
    '0MzHQLzfAWBzMRtgItWDPwdGdGvg+yqHlTqTGpx7psJycNYpQKDb7z5c+j4Sm0lYgvO7YYyBD6PuEW2TAbimd+CGpEs3H6O9aowQ'
    'eOCcN3oMMJ/yr9x91DsrVyZ4fAfjFcU2G5Xe+bOb05LbKqjhbw+LpQgY3QBCgiG9w77JARPEEDyfBKv+/kDUILnTnPCwmFmMmwrw'
    'sbt2EFtJA4Gb/4Ew15CTNBDkpG0cyEz6FmXf0dP31hU6VnXbNd5sCxhza5GYiEt6LeZnDyyHt2oeSyT0CqJacD9mKj5JHGXkE3Ck'
    '7t08zjJAZJJzGwOPgYDkE6cIgwxvaHVMip80hZ5oSwq8e4J2UWca1WNmCwz9Ss136ElWYP78Z9TT//KXYHvIt7ecRFAeZsi+XHgd'
    '0Wl6ExE3U0F8+0MYYPCUyRN+e8r86U+48P/pT18LJ2d7ukz8207SkhkB5aA8O7LRGzkD+//7/yRghRfCaenOoW6QLuHOIOjBuFfl'
    'Y46qN0wfjkpFXjx8IIQAcj0b7zh9sXWE49ciEfsjLYA64OJ+4HgB6Ro0vXCZL4HR0ivS3Yx8AEkev4YnTnAfOvCMEMh+xFd6JR/Z'
    'VQ63FxfUbSI6cxttM1OX3FgH8Rf+Tg0kNMAGuG4aSxQkbZNED8rMCNQR6BexbgBpF/bCynqMb4Ug3601YOn9OsOdrgZB4iPTdBQ8'
    'BBYZsr0A0xt1/r8Ge/k/SKnYiZU4BmSn8lcj7ME5eS0aiQITIfwYqU0TIUUS+Ck4IZGlFvh0SU58RwdLPsqUiMN6IhIN3axKO7pn'
    'O2Wpy3SYF9IzPLWJP+NBOTC9Kayorn1X3Xn+BT42SdfxZ3a0YwIK3Mn3+I8HB48W7iWwxpOzv/7EnARc+BtzkqYq3D9P7N4L+Bq4'
    'w+KGOtnc12fOBBrGdxxRsuNOXMCwuuBmBZJItpUgLbg0gqShBYFEkqSFqc/ACV5Zda1hgyK+htcNBg2ywQNzYmAe9pQ8kwBmUDuH'
    'PIvun5GtTfp1HWfcxI9BoOxvjAUyOk2agjhOgETrKU0iAZ8w7Q/8gNdEPkimZuCorsjJ4J8XLCsMJ/zZE0oNM+KNkd5TpzmKkIU+'
    'OXiY2guOuZLdWQM9hHCKTokPpx97fOEGEnUYII6Gie0lJG9PJ2U9aDZOpPtNhaBVJ2h0YQYPphHdKkI9GxiaPjijJ9yArQRFB2eZ'
    'cwPkkpfA7SU+m4oliJEokCXjG/2ogxz6qEZtxPaMqJEQUgAsgrBDgtDiRk9YcEQcGaOQoXHpYPKDEQsXYx+9dMfoghfVwMfdog5x'
    'QRDdoeq6G1woqId2mD26huIgoNW1o7sGcRIeubpubr6lu/oSN4qGP+oQTOaKCgxh5prhxznDCKbB5lxi0ol71hYcRZjcE8DKfyE0'
    'xqXphUvTC7mgj5xYCUOOxRST5wtimZdlXuDFUonjJbak5zkxpqM8VyoVWI4TBI6VBVYqZ+iKzVKQzgqcwB1FQXYCQS8IcqmJeEWh'
    'nuLvmoSHFIpBD+OhRNkteaMfUCiOI+534sENwNqwWBopw4LoSBDf3bgTVTdOiG9pVN+ukPoFFqIcQdztdD6yWHuJu3q2pzsaKuAk'
    'NrHZR2N1Go8UwS/itUzXf1geCNplz5dDt2KYvWEMCTCSoW56MSeJcYxP4xifxrHQCEvUaxLlLA9qg5rCNYGVC4okcRyrcGWZ54QY'
    'ywShUGLZsqBwcrksSKzwLpYppTI7zGAZtxPLkmww7DSCm+ANCawLLmP9JXX2mwm4vJ2dSC1VD5aNjuGoGGZT34U+l9RxJWgzrBCd'
    'IRMgBdpHDBHim7uzvifkg2E10U1wcV3A574knZ5BVE7wF8CUzYdvgAtPQGH/x9QtNOhOuMeNztCkC15g+aFO1URNe4ebCWlME9KY'
    'Rk6+k1g6mu6rhpliZqVCmZU5SZQEsVxSJCWBYpzEF4B/sSLwOZ4HRie/h2MjVhmybAbH+J045qQvhsOB+tklCydRCwn/sZIraDhd'
    'uWY8TwNVG1O+wngYFS/K9Pf//m+p2VSzwQoIhe9YdYuJNfOJyB6JCNwkNgAJ+k4OU1nERsiIMYqHOIOevZm79mJwsBZ6yCU4lhBc'
    'OoYXxAH+b4ByBgl2Eo1xsAsbCoXB1IvpqRfTU1+nGlp8Gi8KcPDDkEA4CgnYCOBSGuDSNq7G50aA1DA4LnWk/QdDzEUQS2mIpTTE'
    't9t73ElAFbEAAJW4ckkQ5VJJSsoJ8EkpyyJIChLIEyWJf4++JElV2FEGUGEnfRELUMAsfNSyw2c3SoR18e//+j8CTIPXKJ2ICtn0'
    'YlSymKpvYGubrbq1s9QVwcXtm3cjUc7X4kIJ6QTKpNf8bPYYnmSz1eQ6f6CFG7LkEKkkuc6fMjUeOQPZ7v9g081AFKEHjd6FYJdc'
    'c1xD1IR6oOpUhmNrbdjLZFgXI9JwdrVAI5bheZ8PtkK4YhRo5UALGW585BQgDbxX6WeGnGxjFhm6H/heA+eQk+45frQVGt2+SBez'
    'IM79e639FraW/2Br5O69Il4waL/XxkvYRnBB3gdbIhFRoFckMMq789NON9b+YGPoyPleE/cf5Sr0JEd4jK0YXQr1Lq6l+1L9KLUY'
    'fnxnx3ttsUdUXkyy62JyjUB7i56Q1YO1LCFrhUchk4EJSHzoVMCE6NISG4+J06MyKHiQE8Y7lCQ5vbjK6cWVR8NVQ50ScZ7EJxvb'
    'tpZYYKWCAIsqqkioiZdFIauLs4JcKIPmI5Y4rlwWFeUHWrmO156CeOZhnPN4VF09PCYZrJUFhtzDu/OGmLEdmF9wkIPrSNMWkqQA'
    'mrmeNG6TXA+a0GfIHkZ4tegudSmsffuK4ajS0/j8sYb2MjQZETMnkwgnEMQOUOMw6Rm4E4ohHs/dbfNivIVVRFfeKGAG8RXWvV1e'
    'wu8oTkoa+5Q09pF7K5LinAwCW0mQRIGTQeTkZTGLbZwsFMQD2CYfZ/uJ4Cun4Sun4cM7MFLCJl8usGW5xLFsSWEVQUiBVi4XJJ5V'
    'ZFGSpVJJyRoMlI+YpejlHZCLXMYRW9UyZmguY4c+t9dJeOVyQeRYSVREhSvJcllOwsvLSqGkiILC8YJcluRPgctlwMWbQWJos0bA'
    'jBUwuB0kAbHCF1iF5TmRE1mZFcrlFMCKVJBkoSTIgqTIculzEPMZiMO7SmKoM2YlLmNXiq4rScDN83JBUkReFkRREWSOTyNtWQHM'
    'ECS+DKBzsvgpuIUM3AScGOiMhYLLmigAjTzmvxCBJwE3V2YLMPUl0KJ4VpRFOak+KWK5AP3hJanMgx7Iy+/S2k4LWAxjRpXmMro0'
    'DbEdAydy5QIncwoiAuiipRQysLwCSqjMi1xJEBRRzFIbJxwFXUA/JKQtbkQREGKIM7o0l1GmyW0tSXMiGg25kgJQi2X4r5QSIMtA'
    'bwqPCnO5JIH+rHwOYi4NMb03JoY4o0tzUpZB4BUuVMwGdBjQq6ASyz1bEEVA1BIv8IoAJJfoAPCRApCfAro0y4pl4ZMdCMiJOB7G'
    'u3dM6FyYTCLes1Ai7l5GmuHkLMOm/kxJJsiVuAJ0CGalDLxb5EtJ2oSpKgAnB34icSWJK5ffw/FDFjhjNg7BA9hd7MsJeoJ8o/4H'
    'r44+/mWgeroknhbLr0WxUnlsT19uWuPKeeWxAm/wu3JZFMf153a3ednnztsd9uWmU+3CtypkqF9XyJ/HVaVy7g+s1qY71S6ua5OX'
    'J6NSh/qgfJVmqZxPnoXmqnLMH2i77D+T39B+5+6x8gP+mNOXfvMVnxT8cdHaPNVMFQGrEfBaVvh+S9+N8P2Bvgta/ZzFpy593/Rq'
    'N5f49ELqm1iZdyPz/jqs35DyBIjLtT+o915j+Mg4NV6eSr0uGaUx/hhW6o1Kd3xer1Rvnp969jjMPZBg6C9fOaxpSsc7HGdjBuPl'
    'i11sScU+XIefLtpY/mECP3yvnKovNd7988lwVo0nA0q+zOD7w60Fz80nSKqWMdkZxPCfH+7PRYX2pzqsDFbny8oV/K6cm5jefjxf'
    'VK4albsxdPryutKoVNaVy0GRX53D+HUvzxHZVt0q/K6dP3avzler6/PVsH6+Uu4uVtNG9VFpVyfVh2qr2qlNVv3q+lGttaqtq4vq'
    '89WE1eprZVRdD42bi2v95nyl19cyrfuxC/UNoT7x+qIi6rXzarc+EfXv+y8Xobuti8rlqvI0vqy0YfQnAPq6el5UHitXK0Jb0Dak'
    'pf40quePz/XKuF5cVyq5KtLO6hHyPgJ83etKSDmt2qQyblSr4+7VdafWGnZrF2MVELPVMBr8zWY6qHZvLm/a4/Hw6ZptVqeL+ror'
    'PKywbUAipMcapd3kn+oFtFU7Hw+vMV9zAt/HVYDxEca4UY3aPofyYwJnG9o+7z7V1uOXq8n5Gtp26y2x/XCunD8+NdibjresF/kx'
    'TOWqiv2/rD5WipV7h7tyWuO1dPv25lTLrXn3uXFV7ZDE1XProauaV5fnk//YXx67z9XGtTNvtmfe5dPFxGzfSK9dx61w48a1FSRX'
    'VoZuc7fqqvl8efE///cxfL68abXsy8cujEh741f5cfO801Unk/8QT0X19nYuTR3HeXJ68rRV725yDyt3MRi1ObWtzk153r1fiPKr'
    'Nzi3Ve7R4HIzvyv37h/4Gb9ZNy9eheF6KbyUumtW897Y0VNHV1t2s9h9EZam/erkhKchZyjnVn/ani9ms40FgvNo09hYjvaU82fX'
    'xnowEq12RZltluqDa0oOL4n269yY3RRXF2/3nCffqtpg0uu+9YS3B/m6pJfZt2nXLrvXPrea33WUt17Jqpeerpe5h5e508m93HMP'
    'b/fKwwbaW5iqKnXnTn/Z6spvDVbgZ5Lz7L7m5sad+dBZCS/KzetEqr3e8a2VbD5IjbfWg1V31+XOmw/TptXe+hc3rU5v+qw9PFuD'
    '3kC5eWTvHfnOXiyeZ56o9BXVnbDrh/sbyXnNtW5W+sjhipVFTl62hA7bEcIBn4kvY3vGntu36mu3cZ18qjjzi6tql1L5I2DJP55e'
    'YUIn6hwwocX1nlqX8jP/0PEnd8trpzvXTL+5HEiXFa7fvdUeVvKi19vYxoucmz9c6edTUW/e90a2ty76t83y+qnemjz7Tb/a0XTe'
    'H9U6t5UHs3+3kRcvI3cpOFqvu3h5eLmrzWDyDWEwadWBSa43Eq6iZs72zhuj63Z54KiCVr7QJ535ZbVkrMziq+vf3c9vPGs24e7X'
    'vN+TenNz4RTP+40u1+I7bK6qjJQKy+YWYu1+MOEel4YjroV1+e1VIz0ddS4fbrq7udP5pNYkmboN99+BP3Y07Y51/GlPN+fdYpe7'
    'u+Kk4bxtXS/YO4m7K5pFfuj4606vb9+3ag/N1sOk1u082APrRXqGBYJrlJfsVBhXHmar8lOw8sxbt/NeSy91n+vrac8ZrGVTzbnt'
    'ubl5a/WGiy7bHZZm16/L24HZ7bJvMK1jUSAg1Tn2bX2zC+DaVeWZsrTn5vljwNLwHXKpFbZ2NW5ChiZmgNfzyT/0+wVf0/r1jXq3'
    'tFu6sHkwIf1pCHi2GTR7s9KlMzeerYU17t/1NnOuX9MayrNpddm52bvtXbv2Uh03e+v7Z/P25lXovTz0+uIV9zB76PvVpdQ0uecy'
    'f1/PeeXqmiuO5tOyysoPfomb3fn1B+d1Pq1U2DUKexVOuBfKDe2ueVt8cuVi5aIh3CzZ57KjSpwyLd9aDy+1zaKozxe9spQTyxf8'
    'Oa8tXhYvnZnwXOz4G1FW7dLdovRWqjfktup0XvmbtXSTu3fZV2V2j9yjWVEvBdOybm/8inrx+ng1DtgKfICVaPAIafAbP5B1ygZx'
    'dxC+hByILlVYQbCA/fvmOJ+Js9HQvzZr65prl6WrJmbico7aN1Trpfxmdlu9jrQWOm/jzbB/t3w29eLLvDuT/Bf9YSi7xvVy0uNr'
    'bK/Wgv/3OjdWV7r+0veW67lkPS/fOvVeo9XLlW/Ysqvycudi8STO9E0vx86K7oKXqvpiMbPeuivldTrQLppqS5WW9cUjh5BfNtgi'
    'r0qjV27dn3Jvw35L8fTbYc553mhzb1a6klXHsDgrp1eWwp0pLXVxPl9KgKOks+VLj3c1w7jTFrNr59WsDq/HpdliPi/1msgVoxG6'
    'EDfBSv107obojl0hRABP51PbXj3jP5zUc+P1fLz6j/+7Yq8uL8hc3zaubq961xbBy9WzCRzw+cqrUV74P/nTeWv8SMlujqh91a+2'
    'kXE9EcZ1AzPZo4xrBvPbI4wLv1eHb9PG5eWo7GzkptMt91SWL94tmw9mua90VPnutu9NRgu2YS2f1wN+9Pr0oFRu+lX9ob65aCrQ'
    '0n1jo/vepFfUlCuuVZRvzXmx9dov1XujhqBvZuWB55Q3vLUectqb2rmwc08v1uJVtgeOdAXlHxp3VlNZ9ou1zf2jJap88XEtz0ZW'
    '/8EH7uUWa9q8L85uen7v5bU0GOaGl9pDD5G0dLvoTeevd9O+WXS73dJ9p+2ypRpXU7pu1y+uzjm2qFRqUnEMLbHY0q103yndvuYu'
    'pw3n4bbcU95uvPKj8qYWJ2+yUXxt3S65xwU76D3d5FTjWVmummz5DkapXuHvvfuePZDaVn3hlKXJku3y+g3nq73pRrmaW+u537te'
    'Lvqlmabyk9XAulCd1+Wr3Bg4HHId7v6Ge1jxj5u7qfsy77N9tdcRysKyuX5ZPLncRf+uuTFKj0u327ue6yJvWreeIGqLxY3sXJAF'
    'BaevVsrO33vz+53fIe2qOsIOuCEv75CX8/n9szQR3ddb0xdcgTVL9zlOzfldy5KqsN4sX2qLt86yf2vW1ergxm70H0qX56vbpre8'
    '8Z8Wa9Z5cqVNrq1J1uVwzY02V89z9tmSLTUnuZwrj1rypXU7hz8m/H+aOzrX6+lcx2osVVVo3cvPzmjwcPFwZ5UrmrvpP3Fzs2aL'
    'xdrc7ed0mb+Bqosleyhv6t2Hu5LrDDeSq10AR8/Z1kLulZ35aliaSr5Zqr9xm8X8vlqB5lz4a1eaw6w9qrtWAD84mb/jNlxPZHu3'
    'Rk6cXTzPZ7N+5X4sFueyOXyZDzbsS+9CN/yrebH5YJTY5ZXWH/bNO3ckrG+Ly7L/UHKUp4f78WBwxb011rmr8rLFddZl/Rlk0562'
    'kAftkuo6i+6d0OvOpTu5I6uXmzuQ8d+GF6L5Vt0MTGfUNu7KvVHzvtSZ524koSUNRjei8AK6yxOnqKOpwy5u/PqroNcE8UURlZU2'
    'Rfx/Pd8onXvP0dd35Zr0unb6C4Ut1/3G69PliOVYrrXsbsSLG1jJLxa4HjxRHNGAzQSY0acrA8EXujJ8NEf9XutqXf7+QVg36k9l'
    '84aHiXUHfdGtFx+bD1OpbDyX34ThW+Ot3r2c883BW7851Na1y1JPLlZ7dcfvar6ae2N11botP5YH/cGcey5Wu65qy+aSc8ovo5uH'
    'Vsnlc601TO1CHs4X/VtpLkmmPgetrNczO/1SDhZqn30uXulLu3jT2Gjnb8ve8no4NntWvag1NH09r+WW3Sk3ulmqQ2mpuvPK0Jy+'
    'NIWbuSD7nem4UvHesWP6k9JTZyJMl89+bvE27HDz2rN8OdEXtdbtoH/LN5etclPt+IAYm+K1OL16MV5yLaMt99ry/evmXH4Yvyxu'
    'LL67fNZbg2VXN9We3FVYmS0704Z+K/Kt6bPP3S2a+uJJZcuq4XT7Qr2jdLi1JUpdXpG4lsneSJtRzx2Ua/fOuunc9UYXxSv5of/2'
    'CjJi7cbosM3x2lk0JFfsN1Wr7BRfXCPnjDp9wqJKj35Tu+11b0FctaVbSzVmOa/UnBcvfa71MOzVV6tnNLEoZM2d2RyIVN5VoGaS'
    'T4/45fWq9GDe34sbE1jbrc+b/YXT9+d9/oa36sobB3qe33MNT7utyt3cbGFLObVbbBavV0O3qwxqr+W2+8q13q6tsTbZ3GsTRXvO'
    'zd6GhvHWkuoyN6nK3H1FepUWm6E8qK+a3uCq7z05RZdzlOrk0oJWNw3her5pzMt9bcFp5V67WGxMq52p/8hJ5em6WVuK6uhpVOJr'
    'jU2lolLTW06VpDvtntO05q1+O1+dlyuru2JjqL10JL7X6i4nrfKgfHm+1Nqif1d85O/89WjZbFvrG+HlfPk4dHVptpkvPU/nWrmb'
    '3jzXmgiLQem2VJz3nM4K1N8LbfOoeZ2F4PZcuS23Wrlbp3p/uXjRe8McuxlwfetpPr0YaWN5voRBtGVlwy7NblGq3uZ0cWMtllxP'
    '710Uq+KqKk8r0qbE3Yyd4qW65EasbYzmbZBDvZxr9GuKNH0sjUmue3eujXqraedtMVKq84XjvXJDlbVm87larcpeRTDK7ZJle0/V'
    'slFs5HrS9I0rbjztQerlXpzHJl8ZmLqdeyya3kju5Z6LyxuruHmGddeHpXBWEZ7PF1MoxBY3ijbCQuUb7m4G0/bqlq6Xb82r88UK'
    'eE+581J3nzlndNN7zLGS5Zbv6+2lOSyK9xpWwnL1btkfiUrbf7j1i+OeI5mgmxuewCrT1sgY2hfNTUV7bXHna78/6g8dRXqY9n1l'
    'vfZHGhBA7qbWKXcmK8xVHLw12iI/673MRyv3cdme967Lt/Zcv61bNzmWA8ZbbrZZ92Kqy+dS4+W+ZpUWtZ5vvGjSWgT137iTL99m'
    '3OZKGxQr142FMr17mtsvPddatG1Z5prqSLc74sXsdn6jNeaPuv886tebT9XW3VJ+mNrWS9F44vuK9NT0X0f85IlvNazX22mfdQeL'
    'pWx2ROu16c4H1x25f+X3bspcz8m9zJ50ZwhqXb++YEeT3u1yOrgQ5gtNLfXeHkbrnHNfvpF7qiSLT3NLKrt3viveDVojtrvscA6b'
    'm2uLluYocrMlci+l5etgmbPbk9GFX3t8u7tvPS9Hz4KrvSnN9u1Ld9B6MR/ur5XlprNs615PU5WKpelLQDKnU1sqlb5QZRemW9vI'
    'hiP1HMDhka4PKs6cN95uSrcPlQFrDUqjst0s9XqNzqur3eqTga9yeumq2GX711pXKc3mC37Qf3H63OCBq3Z4h88prN24Lc9nfV3s'
    'CTfKfZ29HlpyD/4Ad2i7MDeguCzVuSVWngOj/LnbsKz7e69Y2gg95U59kHMit+hwzR7vvD5vbsRe/3Y5tt7utXPQgiqD+nXJnQ7e'
    'ltO7QWflO66cU1YDc1Ma9tVSv/e0fO261urCua5UquMP7Vpt3Pr1i/8KQvOCdcTBvVW6feFe53fT2/vNUrqVc7emWX67ss4vjEet'
    '+SzN/PmmrzzNZ+qtVQZ+XWwqA31QFnOv/ZXb6paLw2H3YqZen0s3g8WTbN5zoCT6D1dm/8FTJNt1fW7Q7XFdV7TdK+1Veds0rcVG'
    'nbPKLUjxff/2xT7nxfuX9cKZs63qpqHOXJmrdfRS50UU7oeaLtcWrtpfLa6FpWzM1Jfx1du5Ai0tSh1/4DpuZ+30Vo+Xb17l6nv3'
    '9S4lX7iVtSfow3wyujKfzpXxuF7kH3/7jW6IMicr3AWX2OBtgnujInrb0P1bskXappu6J+2TPecWqGdz6AsYHUIMXZmCPd6s49wp'
    'M9iQqBXocfUl5bjXi/J+JccSIGMcPNxiyO4sjfwduhUXMFDFlGmTMw+Q3s/f4b3kkXM1PV2Ize5yueMyXk9cxu2JxgKY0PsS8eJR'
    'cuZlMRolt60FUS6UZE5QMAR7uSQkvR/KcqmAvu5lkRVYATK8t2v9Ab/2CX9WTRz1C93O6P0fk9inOHGQlPYHT3wOSCwD0qFELIPg'
    '7oBwTgZxJejXRh+Ns5TvrxF9WJxF4XlCB7OzhEued+Ylo+4EWbyzwydPo+A4XuSgn8wAicH9GgTw+Cxfysttf1ryFGEq0I23w+Ou'
    'Rhz4dMfbf8LumLMGhGp2Hzeo26vvPGxAwqzs8I8Nw68Qf8hkjJXj3G/TpJysOPgS0XYqHM1xlWP8ih01Y3Lo2Aj10aA/n3HoBVbG'
    'eO7wt3/+Tx+P//Tx+E8fj3+Ej0e1WtErWz4edUJT0Nwq6+MxvD5/fCY+FBejYrVSZXGUL+Ed+u81Lh4fz88pHYR+FvVq63rSeBx3'
    'HnvVbm09Nnoz4nPRtTvaRa/W46bS09or19vsuvvaMG86zzO1Lb41N/a8/foo3F/4D5foTzIgtDxuUJpP/DmvdM8rq+eL8yLAc2m3'
    'AG54r15eAKwkfyWGp/rYbT++VK9g7CeNXm3NtnqdZxh9b1h9un69fns07ybKZX89tG+Nx2IR6GoF41+5qD42WpVLpbK4qlyu9HHl'
    '3+/P6HI0WA4G9cHNwNTmm9upcz2VpZaUW1c7+rzcvpnPLaHW8WSl//bsrF8fLmu3c34jLLXztifVes03K9fbOFL18bXfW82rDXkj'
    's/UWyDnDoWBVe5xfbOnc1Oy/mpUn/eLl6Wm+4kx1XWP5Umm2ul4UDeP61WSVhTVtjITHYvl61O7nrsfj2r2cW5SLq1b5drJpsbPb'
    'laSPcuzSZjvLOJ/GPhTbdRa01Ovr81eHG5WFFUC/0ae6Uyy3lY2Wk+rFyu1jbgr6VPUeXpxLqV1cA6Jq925xkbuo8x32lXsozvsz'
    'UvPqklbYmKj33fOXkjRx75xndWEY/deby8aUfyt12cFCsexbBbSR3MIHIEsWwthezfUHgHHO98deU/TNsj/VNn7tpd5jp7N5c/ri'
    'rjuGYS/KNaWN46q8Kv3e1dXwpcs93DTk8pVw0fJqnborzG8XJbdYnd/O9UHXH/dr7vB2eXmv5FSpbLP+7UIfvM3uJLZoF9Ux8Lju'
    'j8Gi20b/6kqdLWqdDne/fFi3Fy837pqf9rp93ixtFsXbykZyb9tS7+ru7qHicbXunc9NuwM9NxmxS7YjzJVe3+73+0aPt1mnM3bu'
    'hpq7ueUuzEG/IYFezCvPSs+al3NtUHe6L+Vu1PiDLrQ6HeFiNnbY3otz8+S9tqocKJbza8u/ezO1XKdsCk+9puAoPWFmji5b3Y1z'
    '02ptmuyT3hHcck2Q7/TbO9Z1nEWrvT4HualtXlxOyyXFLanSpL0YzGpXM0W+Gi75Zb0ne5VKzRh2fwwxza/nt4YzNxSor9lZXj3l'
    'zmW/4XGDyWb61OpxPfZ2MeltJEly31RnPjrn7cZieS4UK3d+K9cQvCuHve1IQm14MbrsDaQL/plzbkZK5Sb3YlvqeCMp9VFO7o5e'
    'r5W38qo+6VzkLudt8emW04xew1y9XJSKL1W3/HRXv547dnnjrFXLvsldz0pdYTHq1kF5LpuNljx/7by2phw0JLL1rsy78+ZVVWJn'
    's9x6M+i/NdXNBVZfu7qcL8Q+z2km19BWowsOq29e3dSv5jf2enOzHi6dm0u5e9Xvj+WioL4qL2O9/SZb3EiZb0Yvj1PP4Gy21H32'
    '1/2KWp5rcpu78i9qars9enaad6WZoc0v79yVVlxdYM8akxdl0bjkZ5pXrk02r+3WUr5z/PmgpftNv8f21zNuPL2ddPpPtjvusuXe'
    '0nFfzKcpV9yMZsDX2xc/lkNe3Cx6TejQuTJfF186VW/aGc4HwsP8stR7zW1m15yQ61wv9A7wl6n0YNynuw+5TQtyF0u9aW4zuXmp'
    'OblOdWgvFesJVkYg3NWHwHm4Wsylp7Fzc7vw58+qar121NHdbfnKV62n+Vybz/Ur03HUmT1t31/dGJv2Q3/MzYGP58bz2sx8nYki'
    'u/Q8D0DTvIk+72p3rs25+sV9797cIPFyrFibODlrs7zxb8S2/NQZXG1Mra2+Te78l+erxdvrpuj8/+y92ZLjxrIg+K6voOqce5IU'
    's0gC3LNUkuXGPUkmd7JO9RUIgCRIEDu46ZZZv83LvM+M2czz2HxH/8n9knH3CIAgM0tSd9+2tjGbkikJBGIPD9/Cw3026TXU2skW'
    'lMq4ut3IhpXJTE61U9k/3Xf3Bac8VEfjh0wz8ygWs4fJZqJlxtkiwHotW7HV7GxZyymjpN2tzd39U6ljp0c1fbScle/HOzXZBW61'
    '/Cim8ekPcndfK052t07DtLx6O3x6kAxPnD4ka6OFvT5NX9qzZa57qHREw1NKVlZ4Kp+ms+G4UdQLm16hYe82QnP+UBlVesNJb5hr'
    'qo2SUVScorvdqrNCoyclC+J2cnh4St8/Kq4qKGnLKnWyW1PpToabRWc/OHaERavmmHZnYo1sO3s0d1pj2Zn4jqR4I6WzkNaGo62a'
    'q6HcmAOn9ypdM/a99tHayUmzq4+7xeZU32hzfaDmy6+LprsQh4eqD8zVtieXjEXJ6JWAhV/ISSetjwfF5jPm3rjJfHmSbrqGOGy0'
    '6l73OF3rlfSmkAX+uN/fXsPQg6lKYrPhTO6PGbEwmhZsxRdadUFNrmf73nNBnyx2heeS9SBU09a4smvuRsVKaZJ93p68JiLgZk06'
    'TZ2Dtnsq29vxo+sPB7NtaSrWnWx9N/SPWqGVH1QVd/JU228X+dXhUcJjPx+G1JF2LS2pN3zjsTnZLQ7H3UbRB/mWaK/LhcG8fEyu'
    '2sa8sj+UGkZyKnfE1mqdGwA8vHTqgwcnKYpmOaM+lU7Z8nbe3ekAWYOZeJBfFo+z9Lb25Gm5afL5lMbs92Huw7uZa9Ygl9577foa'
    'wKgHBLeyWamaagzkV/WpmZ8XloZwWO8X2+mioZ0O4jHnHFvNTKZUGTyKkrFdA/JKHsvrzahSKtTM19Zy9+yNVoWcpwpFIyNr5qbU'
    'rVQGzsAePar1WXXQe9E1eZ3Ler3TpLEfVXJNRTDH/rA8tjr98anZlXb2bip79lY/uU1toE537ky8f1D1cbh6kmXcJ5XtuFOvDZOC'
    '5/T8nmKUBeVZSR9GfaOhaoXMsHL0dKAgli88DPe71WbgSPlKb+E0pzlhn5VfmrmV3erJ9Wy90FYAEbef9fVkmYd5LvuTUWdZWG/K'
    '47V7sorJTKHWa7rKdtRdiNvK/UPGWoS8RrU8e+wPXk5T134tTTq6lO94u3ZXaM31l2JtdaqW2o0HrXoc+6UXkAzHTduqdnui8TDq'
    'jYvl7nRm66fuqe5udu1RO2OPRt30/XOhACJ1urQRd5KctlXAQ5Jt9De+Nd0Pt+Z46PiWN8y37PGj+NrMjx39fpKsVD1/pHvliXVQ'
    'nvOZvlNQrO50DnJ+2m0P7PV8Lc31nr3rn2Y6oIjeYjr0Br2iXyvIyYfhKePnV0mjuxzcP/Wd0dZZNnPtwbb0+vramWS9/iEzNgx5'
    'a3ht2yufPG8/94aVvdX0Oh33+TRJ31ear5L+6AzStYpz6D0bPXsIe3Y4Xhf299J6fC9VtoftbjVoadupWDwdR+2DPvP24+Q2o7zk'
    '24V6XrTN9VgybckRWqZWkCrzUl8GfKer5dO8+zrenvaFgjeq64be61iTzmQ2SQpPs0e9ORmvj/lG5fQ6fJnoD3nftu1tazg4NOb2'
    'REnnVtnX8Ty7Usq14S7fcwvt+sEzd1uQ3JWH2U6tZDNKP60/+Us3u3ssFjrW4rjKSK8iIPMrtmGkF81Wu7j3k2t7UjIP1aabdQ8v'
    'w3Gyk81mn7szpV1rbk5jZTUstmumBsNwp1qp1ioMBhM3D4hW2/qu227uJMVQh4VSRjR33ZGou1csg5Ev5EYn9fS8383zrcXUfS1r'
    'w8zGPnVmYmWwE1S7rjl2WXP2wN287KIDfDXHckFp9+aTYXsE7eTVUbP0nLG6XeBfS/vhy8UQlExlW85NFj2hlRzO/XW/mZ73Fi+V'
    'p07h8aSWWjuzoKebnbFsdtuCsxnJ43q+Y82VfkE9vijVTdurlIAH2TtH052LSeV5JzzM58LAzlcU8+Sqo+fCsHdSy+XWqFXLD/JO'
    'bniqWVnPLZX0rjwd15Pq0h72XOe5MGlnst254wuDg2Ru7aqvNIdqBrjbbfL+XjDM+1LTds3CqA2YdLkcOJtNbydsnx15Pp1aw4nk'
    'u0O7PGyNFuW+9Czt1HEZ+JGtUKkdpJ5vjQXJSU4edvue+9p+dORMq1e1rf6wPRm2BF8cN8qSU3x6EHwJBJXe0Gop/b1UqqiOYRtC'
    'pT3Jj6RJL53cTorP2XTt0KrqZrs8TPfWB2lSAk6ikje6m8Vay8k53z86Va/Unz8pT7v2ulvxDgv3VXCPi+Mw06/v3MHwIBy8Tt2q'
    'z1qWLDV3clZ28pboC5mCIGQLtTosjLKyy6498ga61jpm13Zhkyx2VeXJqurHTBKAyTochXV1IfklEOY7tY55pm5d8T577E873twa'
    'jSbK2hsshIY/EKXnek7xKpNFy6m8Dtcj0QAgSm4L7V0/v2gU1YdpX7OAjq9XVr1afBm+zKdiQ6hrUn3x2nn1nGH+6MjdUudFbZ2M'
    '3GKYr+mDycp9tRb2ycguTuUn4f6hXO+0z11ZlcbTqbttziXvQbUbeq8KewIY6epuLBznmZf9k/Aom+2+Vno5VQda6aBWX0/jkiEe'
    '+oNmYbPzDsv1aDSq9l9mdVttTWS1JpfHp70ODNA2rQ6kR9Ub7yrJXV7ttcfWpJ+elLRnP1/wjFVrlHTayZJyEubdxzEIBfNyvm3W'
    'LLWUXpQq+aeMoSyQZ33Vs92RW2pIO2G2y6591Znl+gKMaQH83325lTWK6eWurm6KTjl9rPeLhi2qz96k4GaLp05OOnb3KxCt9N6k'
    'NZpIPa1gHk15Pd1VbGA7nXwFREe78fqQN2w9257K2dL61Bq2QFbOu7mp4FTb04PdloR21eu1n3sds1Swdcv2u9uCbayMWbJYP9Qa'
    'hUp3+PzUmoxfS1t7Mmmt78snUbfl9vBp0sn5y6nbTJfuH4btge+/is9NvTLWbEd/9QvP8+ZmvXjNtxdS338cDXbO1khW57mNVslP'
    'rPRqe9zpQr6r7KeO7ql1ezzrqp5dr/WcwtguFtaj+WpT3j7NYeIHYlkfuI6/6I9ayrCkNe1W8VEwG0J30rK7Obd7mOjL7aug5tdi'
    'buGXNDNdGJwG+13W3SQbzcZaSW5Os1ovOZd6Y8Mal8ynWmXjOVbDmi8m/eb2AOzzi9byJFktjXZP2jjTHJe8asG15cy01X0aHF4P'
    'Y1GbeU3Brjv5Rict55VuXlm108PdeD6xR53cYN3U3HK6PBFeRuX+amh5nY1bzj+1S7532OlZe+4p9nHsOrbdmzUsqyLI5WN6aLxq'
    'Db/33HvO1g73z1Pr9bEP0rZUes5tDu1hbnBY9OobQVyCrDl5aOSrHUsyeore1p2NVJSE7Lzfyp7GVmZ7nMrHjNd5eqnm3MNsu5JG'
    'tr+fZcfHzPDJytc3tm1VJuWp5srC0c3OdSEzsruTgbzKyxljeVqu7p/dcbc+qY5OngJMNPBzilsSMrOT/vQ6gY3TtOyqsxvMZjgE'
    '025Zjr310697tQbTNJqouZzhORuzqIynkpUdVRZP436nJx6FyqS33QvHzmg4GAHJ9e35qZOt7apPr/v5fCbfZ7XiTJ44NaU9zDy1'
    '5rO8iDrGddZ6yZ/0qdY8PEvOaFCeGpWj0nD107F7GM3lhnvojSeDp1Lb23j9SbNd0sf5tfU8bs+eV9J62/D6trZwLegk7Ni29fRQ'
    '2bcPx7En7H1x5hle2TbnlYmwOVlDzSpmnwtjbWE9l0f5gzMcjTK9yqjdXdRX2+JIn2tGVX2Rx72MM3+SzHl3fLLk5iqjZco7K2vV'
    '85VZLWvb62dxIjUsX9KkwnyZb3Sd6uPLflDcdpfqZr87Tp12YyiKp+PEmhfdjq9Uxc5I6D3m3dO2+HIaCuphKCrirrfPVh3vWD34'
    'XhtD9B3awN+2xPHx4PuPDbmiFZJz6FzpXs/57t4yp3X7YVe9d92X19zOq+x3QIMlpye1FvXNaDDJSjbwhLOGXzxNeiOhmN/1ivmO'
    'e/Cn/kOxuOyUXW9UXi9HmUxrVlBVY5M/VtW2AhS0BvyW0FOb9Z31evJanYelAML0adLZueWMVTTmTXus2wW116hb02xTOI16irpM'
    'vlQHD/Psw1bp1N1RTlk71Y5Z6FtTYDafpqan1Eyj0nYmsi218uXOEpiPbXt+yjqzOfR8Yq57p3Hy1HtsdHoTtZrZSpXBzNoW5dHR'
    'nBQfm1u70ara3V627IuG0TJrD4XVceZkK6fOsGiP91m9V0haSna+ztX6Y9Eb2pVmc/269lreAnZnvWfJ9znLqeSPY33+5BQL6qy9'
    'mNnWttBq+rZst8ZZqdru6HVTUIqjTGPwkAO8qrStspzJq62SW5V2zU7ZSFbs7nLXbViViq5Pp0PBntlHa3LY9Wz1AFhvdtT2+spf'
    'Z8bVzPBoGw+zaim3A3lWeBEfc6bUng67x8LLqOjutKNvF9aKsDgItUNn8/zy8tTWqs1OYzc82HXD7ZxETz2MuwDW/qA3HLWHo6dN'
    'ZbPZuPXVbK4OBnNBP03t5Gxmzw3poQAc62pUmdrp/aOg1jaD3lNVAfBMtvPp7TBZ2gwrrVG+I81GsNSm0yq6Tr5d0QfCNmkdxKlQ'
    'W2e7+Y0SLXJZvLortgqjgi5P8sYuk18k3eRjSev4wqiXrpbSp+ZC7USe+82Hsl5ulvt+q3QoyDAHFWM/2fQE0Qb0nTWSs0HxlLFK'
    'TmsqFFpdueD3dv111ZPsJBR+BJHwRRoaxnZ0WGxrjpIU1iAy7OqH8toVPNdret25PXNbo8yo6LeAc+rbzuFleT8ZNfVH/eHVch7H'
    'sEM7sr0xmvOjeH8/fzr+uf5JyzaLVkNadPvFU79ergrDSrtVc/Yj+9Wb+aWxUyklLXXjQI3y83Hk2V6y02w2Jv1hs9Ef2e3B4tT3'
    'R+Nu6aSPYK/m1Xp22Jhu1Rnw6fv755IAYvCpnyn3asPXflfbkoDqTkBCBRTZ1MqPpjVd6NvJGN6Mh+fRoFOQHgSn7yye7UJ70cwP'
    'RaOpKU1za2jZgtz3l93WWre2su7IR7c92s78WbLysncb2X52kJNWVmEkgKTngChqdubbUXEjH0biRjGLS00ejiqZl/XqVBnX3Em+'
    'MFuLhdOkqk/KL+NGs7oyRoX60dZnNbczssudslgcaGtlmK28vqqdecGdveRBQq9WWtayuHHyS1FKKusDrEDB0A1raomD1sAb9x+q'
    'ZvlUGdkgRo0URDFDIbd9yg/dtbAf6aNnRxef9yXh2BayklN7sHfu63JaHT05x+mxvziiHf7+kC7qvXRZHerSYf9ymKy6nUFLFEZ6'
    'uwKcwaE1HCndp1ZzI50Onl217TrIZcBvWZ2e6kiDiWyNzMfhy64+aHWmGzObe82/+E9Ntdh/Hb14zmFSa4wPr31vO3+2u4ZaaEmS'
    '7cl23dcKTRuEAGlbzB38al3a1YbVtvs8Nlp9xz3ZvcZ2avhzvd/fjuqClN+sRYCaSkYA4m48KJVcc+g+rLdpwAvj8THtKt4uORJK'
    'h4lUfJrKg5xpz/MvBdtqHt1FpTd050ahOJ9mu7PsVjPtZl5xempXLdQOJcfXFfmlPa2AqLkxJS3TNtW9f5Qahdb9xtea6yoMuTjL'
    'TNODtWXtJkPHfmquVnmYQwT9h5bReLasWalUHLRq3rzdHggv7laTygW3tZ0nHbX8WG6M05v+tLk1YTvKcyHTP+z8pqINm525ae+B'
    'kyknd8N8oa7J3XJb7diVzePDRN/OPM0HiSBjmP/Net/aepzx2uOMLNTGrz0QgjqHaX5qVc28I9o4Fa1Db9idguhfKsnLubDquFtf'
    'rEybWlFsFPzFSZ5XQBC1nOQRBPydpMm1Rj5TGC3Lw5Ft41SCdD1MD1+FCZDr6sNLf9Dqqm5T9G1D8cfz7XBW3+lqtncsqe5m71d9'
    'u5eTO7l057WSdcf513xlOvPmRUOVOy9WDnizMUhTjrSZlAVHVbL2KL/Ttf1pIb96VqmZ6yuv+2NHbKrbtT2zrEYHhKMT6q7lsa5L'
    'o/mhvR8/e8Xio79rJddSGzBU1gd+vvOYU8fZhr8/VF6t8fRkVqD3I5wYZdA8uP3FqSMBk5/dTAbHba58KupPuXq63x4lpdeCMK50'
    'gGkxqmXFyDSUhm899CWpvC72V9NWQYlm7uTLx1XpeWGhWX970Z9us9PZq1spX3yoycn8a/Kxm1mPFtu19dJzX8zxY9KIJm/t2VI2'
    'nh5fvKo3WTXF1mBwsLJCM2nrstjrPgM3NwKcucrrSk9zc/O2MvKBp+ufihVRby8Hk1mpNe27Xll50CaPA1tstsVDd7CzrZxVVSTT'
    'mViwj1t+Q9x7m/Jmrj1mXb9t7jNH4FZOW0duOtIUoNI+FvX2qDWURhN7LG/6mZ09yohm92mcL1u98jPetIUd4uefX41u/VR/LE8t'
    'Z9o6aAXdbo2m446U3s6G447qDgajZ8moOJWs5APr1FPLhYzXXRkt496v5sen8eQRpIiZ2OmdZv60VwI2dWl3FTvffbG8XtGQ285z'
    'fz/slEpSU7cKzfXStPuVTaU9OHiapk236/GLBH9MkALqWl3dP1QBsv97/nVqvnTQdmoeqOfWtm3Yofe1hrmVqjN9u58MfCsD7Kxi'
    'tIW1Ne6kZwVd3e2GpUll0HdFt1AHlOe0V48j1+vtZq1JQfLWE6tnjHfrXFWbSbPZ5FQbzZN60Wu1B+ND0fP7li6M++bEnjmHkl1c'
    'A8boT/fAG5fV05Of3SVLfc0vD/XO4mWsiZaSzC+yy6n/+FQdz6tNzxsthkc1qe7U/fDUtXvdymHoTnRDF2ZyZSh1lpI+kg0vs3Vq'
    'VvZYltqDrDOYyu1xVZjKeFnCLVePWyuXybVz/sSRd5VRabY5dkFW6fuV06gB+G3upw+ltTKVJtXsoiNMvIGaPpb2949G63wZRqi9'
    'tO5H5mHRbxZm9lDYT7P9pj3dpvf36112U69sV4eZrmuwNSeZkrEDYFzZ1cXQVlvaSloekvVWa94qz2ethSKN9N59ufMITILgTcyh'
    'JhRnA1Wo2ZvRqGyB4JY/bstbKZtcwB/9tK1J7uS1vRyNM8pJyo77W7lYdpyRVm6qmeyrM9hW9Lz6Uh0tCkNvA0szFzuiWdC6o0a9'
    'kt5mcupkObf01TZbG8mCJA+Pbc3ItjVHaVd3E7MHQiosn6/LXndqlwftimPL5iCvFcen1i4LvMnufluvPdXa0MW2vN7aW+A/CqZd'
    'a3Ra+/8WKCx0dE3yj4We1jRenU2ns1il1710tv7yctBr5tMpn6wl27X0fa0e+TTrFe5LyeBdsra1LVDGqlieNX3F6413g/Kg3wOh'
    'YFeS0r6VE9pecz10BkOY+ZljC+bQ9OXsqi4+pieaKDbFfrZZEGSlNeg1siBeHCZ2r6MvnkfWqX8a+eJLc1U23Hmj0Bd2ituoniaG'
    'ZECfJOURqs+fHrPjwvRwGh/6R2N6yBQFJWlZppBZWWJZKo+Lml08Ll7skjMfLAsVfT40j/7uaVMsmLKhHtSGptT0nNHbe8V5v25b'
    'k2R5mG356d1i31kYE7893BSUp6LXVZPp/dNOObQbx+1x1Nu1J0b1Zex4J9NRd71cvrtPbgy12d4M59PcFtU29fXYG/SeB3bvyX3U'
    'dq2Cpw7Ewros5iuCNFaamZWbEYrl4v19fdW6xhDuutrv+evNVCgCZsg7G6E3LOivq8VLsdmoyXlFbvYKrZ3SerUyyU631DUb9oNt'
    'Z6bCSOtVfKejK6+ipJUyo90xe2r528pMFO1Se2s7kiAe3XlZVax02d+9GkVbXxYbynyhOkpNbs1GQM+79W3+NMq1BPgvtx7KR9kr'
    'TjS/IUwGpqj5diPrFodFcQCY3yrtnlcdcdKqqONto7bvTguVQic9zpS0wmHgFTKFcvZhWJeMoWe4p0KunB+8OtnqFjjwbNZW8+Vs'
    'ueg/SHLVmT4fTjN5PGz2h5nTtOlpC8ce94718m49cAYHc94+ZWAfVGZpedVdd150/WVXUMaVMXDe+UEn1zG6r+nDeJGtd9RVWnPT'
    '/mu5BlJg5IPsbdayv55Vm7uhtpx19vcPm7+yV5LVdFZauQpM3062fMlqjtuTY6eweNYUyfa1Oogz5qh/ejj1D23N9tSNMmnP59La'
    'm9p9YzPy853HnbzV/Imo9J8t2U7mB/up7JbdtZp3lclwt9F7nafNutd+npx2yHHWi91N2Sp3t+pmMAZRW5x2XoVC2paLp+faquWV'
    '/df7J/tpy4+bNOSaWqYtV9rF/dNW1xaP3qQqCJOW7MiaddIbw2Mz3zaSvWPBPixmgmmZy/ZIWg2cg9jcyKaYkcr9dUuydk+t01TZ'
    'VR4WxVY/q4r9UrEvtNqeBoydlWnS/wVzt3lZvurHwVzvdqdOVjL83lTqm9p2XciMe7W6rQ7KY8MabjNJaVL2MuOc0R8X01LX1Ney'
    '0vByAmCI+/L9/fOrvnw72/sH0XRqM2CRJ4+98VB4OUkqntMXy8+9LsgLWiMndP36Ij/wFu3KrNidj5t2b/RS2jjljj7NSBr6Uekt'
    'XiVbGGwL8w2g41yh+6qPoBO92rgjH9zXnGHPxoreH7b9Ubbg6yvFtazMHKZA3ulZpV+XpvfDZyADpeOslLYFW5fGwlAd39+rT0Py'
    '2lEZVYSeUnnN3T/44kPp6PamcyBHfWHo7b1jK1tuddITJV3PK6N5eaK1WuNOYagUvHZbaS1aJ689dMVcVpJaQjiv61drO8gfZ/NV'
    'uzttWXOrZgOmtgEdmHbaLUot29gIMycvtKoH5yh6q/Iqo66ywsBQp9uSBciyId8/zGvjPwXq51HJWj+55dweOMfCSNttvaF96kpG'
    'qXKUupPBQQIYr1sjYM3KsGU607IN3Gy71kbVRsfqP8l7eZUr2LbulOojud3yHK9jSutRXSyr+3J7NEjfV23DAJjuWJnuqDB6NE6V'
    'WW6cT7/mjbHXtEdWqdwbT3YT4D/vN51BY/HSdryqKFUKylw6tgai39lJs1MlWc+lJ/XFwRiom/lAcNVmRyk8oF39flbbNx6Kg850'
    'd6jVCvmn5ItiGS+T3Hpdllfparfftgpit1LtLCcTOy9Xe6XHVzVz2rZKvUPSf02va9EG1pm1pHrrw2uk9qfZZret5wvt8fHw0lss'
    'WuPXQqNQqyanD8fK2HDqdrFSnj10DpqZb1a3o5GUV62i0Ot2tMaucBqMBfVkHkRjOCh13OxQafoF19NfpZJqnnaN1b7YldzqqJ2z'
    'TWGt+xlncvBG7UpeByER4AuIY3lYyGQmVkPquPNqr+et11MB5EegL9IWWFL5GSjMouv4eV0WrNFsfvKL4+xo11v3x7n7+/Xmen89'
    'T0vm9nCadB9fKkcglmpSPNpJEIFHk222rnUmp+Z6NDnUrcbhUD9sNnMzX22rh2MTNVujSk9tNleOnRGGy9xO7RXtpaPpzU05318+'
    '53K546hvgoScfRRGlfu1MDrZfXM0lIRFvlbXCo2cXm5YrZL1oniKqVuaaoz1ScUqTiqNjmAf1Jfa88hr+TaQi+kcJizzWi2V7UnN'
    'OLycBL9Vei0O/W5XmxmODIt8OFUmZSdXdcz2qeBPHrbr+6zh9XOlZGOreoeFVpP0Q740eCnPtfRzZ2qnvcW98uAvRsfcS2Z6WXVP'
    'XB83BxFWWpGmW1jWbMfOec/lJ2/QfRktxN2ys8x2EYik+riT77bXuqc+1bKP5tw9TpoTY1zf1baiZWYz5dJuM3p6yFWO42IVICQN'
    '4sTDsD31M3rlyXYmLcsXsy3LMYGxH/TU3UAeNIVnSah6eMyQ6T3n6oNiR9QfivLJbFczR+DvT8JoquYXw/z9w6zWv/////2BfiKd'
    'nv3zQ+CYOgxoHl75objmGD4Eb+KYvnd93Sb9TpmxOufxQNFXOcZ5CcKUSSwW4j8/rDzPcu/SadVI7bWNZqmKJqVMZ5nGt/SLZij/'
    'upUs6JijSgoGUPO92BZSY5Aa3J+RgtBlPLSNSVE4E9c9XDlX95eY12xZ9zE+yh4jaeH9JRYaBWsZmw452w6iq7578+vKn7Rw5VA6'
    'i+7WW+Sk+x9sLqLOjwuZVCYjFjPFciaTKVx4l87lyqm8WBZLpVxRyAil3H+gl3Xxe/fAqKNvr3v1WWwvKRpfD6f44pZe63xfi3sb'
    'xznkEbfp1htG8tBZXFoWr+QctI7c8N7GFMldMQfniul56ttLY/NfJIyTEXG9LnlBRFnVUC5dt3srAAfjHHgFIxD9+3/+P+8tSz9i'
    'B1gkROYL/t//8/8VY3HyLpJjFEHrHC0qhCWaq807c0XJsbWpGecuG0cKRcVD8EQGhRGvYnTbLaZoCxAnMKDfOcJRKnY18zzgW1Cx'
    'QgHP2NRuYjDTiq5eBFGk+GFv4wqwm49XsYXfRG+KXKeaswt459BR0aKpWBA3j7oBVWPo16OuBqHuLqu9CqXC8vP4Yu/GfLvygC5e'
    'eUB/YjBDYar/2tbKl4VUIZPNFtEnQ6n0xq14sIf/muN2avjsBBgHztwAY7c+0E3Y81iu/KOLV/7Rnwjqr8eCwepSYiafyebLJTGf'
    'jbpozucLqXIun88J6EM/lxf+fCx/4GP6e2Ohbl2P5ToY35XXdApoE8V2AvQ/VcrmczkhWxRyhQtX0xjVKZcViyI60s4U/8I4/sgv'
    '8+U4CGWQ53fjzSCuvKiLV17UB4hCrtejWM6lCmWAm1KmkCmJgbt4No5CKZUp5cqAtMWsmBfEPx3HH93UvRwHBYIgT/DYq+uRXPla'
    'F698rTO8BFQUkBrbvWc8ExlbPpdNlYRCCSOAZYRC+WLfZHDchWIxmy1kM9k/H5q4KKu53NXQcucuXzlbF6+crecoxq60A+S0QJL/'
    'j5i7ki5i7RbyuVRZzJSEvFAQobORcAeiIKRKmTwsQV7MwifhP5B+fucedRbD8gBxC4hCNiQKPBiHGwTsCZEhDyUeCWWn6RjmFuN/'
    'UojeFYW2O4cWuQ2uybuEkakLIRMTYOJI6PQbN2ZIWxXpGIXpNq0YUQLCuvRFe8PKQcenGEBF14AIOse3w4nGtcF45m9C2tDNZ9br'
    'oCPEW61oMemKNRCFnabuicZJDgAlLjExiopLsUwwLLd7G8atCy6Nw6jDG+Ns+O90vw9w8s5CvBdHJrh3HO+2q4kIaWaRT5ATAe4P'
    '+YpjDJ3T/1EwF+IX4ynFlA/RmvawW1fEL9HAAq6yappLWOAnU4b1joRExGUN49PMVYr6uWJck3sbWXR8Ysw1ZZHwDv4f9S7gYiNR'
    'HM9RaC0dOxAJjoWffY+iy1wyVY+mdYxGXnRCFwwUdjEyqvcDxfxJ8EXxKpyBeBXOgMezwn3k/scgggDr/OUIMuJVSALxKiRBDZbj'
    '7gr4kzGXoPx/WJf/OBCHeOWfQrzyT/EcyjywC24ZiP4jtjX/o5Dt2w6/T73PHb4Sq8QrsaqjI89MyDLmWzDFCskYW1fV/wcCxvuk'
    '+hwz9opTzV5xqvV//8//xxbYZIzYzfFalD0Ss5nvcXnXwmD+T4kZtvGGmGVkAJPy97ywVM7dckEWQu8fc5U8e5C0cDwjKYYRMMAv'
    '7nsQ6TDkMIVf3VMAdUT1lk8UZ5uK3fN41m/8umCDb526XMeJVreWx4MCsypQbqGgwTz+bCpGwYyxiQuXLhS3mAc6szAStblgIZF5'
    'WLBLWeMHWsQPTERny/ghe8WuByCycMxtlMUyz5znNa/JIeOKVw54J15RCChmhI16h/vmlV3HJs5eVBb6nsHKCnxoP3z7Oe3KjmZ5'
    'v/zwc/Agm4brxf4e+xxzY59/CSPwpWwfUBeTPE0n7iY+8Zzubgl5/x6/+ZssGTvJvUncIr3WFZ5Kz5joeuhfhyXSMyZivHBYW5bK'
    'Xm7Cqiud9gA+3XyUQDhXP7pH11O3t7EHXI4XSe7TewWW9xbYhaWpxob121jPBNnWvI3VcNN7mizF2qoP/MW9o0k69EIy3I+u6miL'
    'm08/pNOxhyAUOwVvQ1LMA76xMG13GLcRwQ8VFgDh6MQF2YAtvCwxWiAI3yrWO9exEdhn2hIat3zHQvHZgp6m+Gi6963nweAZBvTl'
    'hlOTm9vYDcfS9MjwHz0yrEKPjGGmR7ZX6VEoFwVZpMf8IqvILENZzhbmeXqURTGfl2++BrPZ63QG/1qpt1o4pZyFvQk+9gedHnbt'
    'hrGeHzmJutsJYZb6S/Vf+/XZcx+y/R7rg8STuY29IIqC3xaK4PA7aSHgZmLfzmvYe7kfvK05rBZ69Pyvo+dev95pQ7bcJwBTWJe5'
    'v7VgY2puLI5oRSJnUOgfBzfwS73aux9AgX6CVHRIVllMVQlD4bnAPDD+jQf4/uEHdPQDqIG8vnwmzMjbiUSsJkVFXINOoVYR8EKA'
    'MxI/MD9BxuYRY+25uIRfeflA0eLeYMxArEZmeXDjsa8SoFQPA5LvyScVckcYcBKHxdWKC5gQ+HZupyUBksV2fv/G26HOaUrs4y8c'
    'naIWR8dssT3wh1i7EYv/Hjvcxo6wAW9jq9g32F/YGK+dNQhbDJ5ZQ1iaAvmGMxIZEGq8XJU3oSHTiXXsHQ3wjkHlATXc4uxBcVh5'
    '5NsJMg6oBIkd6e8GwAMQVGypwmTgaCBJUx5N3/D464pFzoYeQPG+6sVh92PlvqGYfQ8jJuJk31L41Og7OgAaoDOuoPe3FPI9fOED'
    'Dd914EefgNGlLnrQOQRRbAjZhRopycK8mNRGKSisWXOA2nyOLSTdVRGTAQ80lhxDVYLETz9wcFbUheTrHq5dPIEIFNYEiNVKcjWX'
    'x7SCEooaPBMzfRe7YVEcYePuHcmC9y0MwN/Cu+R75gCIKisAixpsnHHvvkujMYi8wJBSxdsYK4e6GwwRCc0IqTzgr8XiLlY3QJrS'
    'YCDh5pzrEu2HsKfo2KyuUGlX9XACoW/BkOKJWwbqd7Ryhqlgz3+PZfCPptCCI1cDvX8Jw2reXsAD4004axJDtgSHCpkhH3EkdxE0'
    '9Q3/g+Gmf4p9DP8RfHIBmQnDAOJbyWPcB+P6KKh9hBc8l0YaOFIdVwNxFHALrOMxFiftB6EW6PQZtcQAg4BwhhzEjhchYQY7gPME'
    'U8Q4IHTgRj1hrs+wjTl5IfMo8Dzm30tH6BuiLgWwAesrsHw+IamgdgwmCDWrCmsUNwT2KnFHih7YSDGQFiAL1wYEq3VeKr4mMG2c'
    'JQLyT5PzIf2BN/KB1SXGAFUCgFMYQVgW3Xf5PN69QdTUWV6ccePwLxsLmUJd26lcXf2Bp32IxYEfQ24SuvMh8YmmySAPaIhXI3Jt'
    'nEFEBCBY/fCPwUWCmkfG9eNCNyXa00HLbwvHbjAncBABzwbr4e2BTMe4uj2sndfxKWbBUOkQgmmnKdwpr55p2lgPSH8BNeJYQGzH'
    'qKySDvwUKiRguBfKlbARxDeoTrllyrW95iLe5toXgICFBxOCiPw8I4lUrIcqGBwnnz+AIoC0rSohNCJYh/XLpqVBR4mFBWHfsgBN'
    'LnxoZJfloB+hZqhroEMWZMlJT2C6hNJXTA105Oz9xjD3KdZELhYoE2DQMqCZI0DtByIJMGZ3ReIh+kLEmMQIwCH1gGH0QwA7j/4T'
    'ZeDAFA5jaZLAhvuJj4g48nN3+BGfzqii5NJ5whygzsLtpERHGXp0JDEDm6gbrsYEQZohKRS/gahJOuxM9/tbiSM8wJjQYgVmNI1k'
    'HR8AG8N6IG1PxX5K/yADfXGB09yrDn59BozsAHUHUgm7mb39/o1j3QiK+UwsuwA4liPgVCql3IZbkTFPt5Hdh0QdSohhCZrE7+bP'
    '3oYoXUldjxHTzuM9Y3aqEjgBVOghbkMoQewGWw1VYlyOyiS4HorFol5ojhs5pWIAxHfSXawzXwOPlcLJe4ZaYInjPEnlr9A9wl3/'
    '9m/QhURqK1nx+JcNdP8r0iYOKpjQ91CJF99A8mfgKjM3sV9jNG/GH5EXwIl3WBfNHpvD7PWsh7OWoxxAJRe+QfGXaTNxuhFXEtCe'
    'oyJ1iDGvjinNrRueulSduPJrileTgH4pwQs0Dl/YCH8FTA7E8BPIX2H9Ww0g0lPj6EIwQTCBrMkOuYtoy/j1E3zUFrH4LvbLBe+c'
    'iKHvyz2RjUs4jN8Y+H4TKfpzTIjmD7KZ3nl7sOwssDiVuGzsd6RkEnTwDM1fdl95F6nn+BiM/xOdSWDbP1JygGJhtb2jpeK+jSb/'
    'iCtrEoDc/LV+8vXAWj79EGy0cK9+5p1F3TDsFF07qRFmh5p+Z3Ng8hU+uLvoZ7hpKJGeb5mKmifRc4RlYzgEu8MB77sbNzrZtwif'
    'sEFYbQjtQRtBAzHct4nv7ey3GCDcl3zXnQeS4vguETK0rXr7+V/7g2mLBL8vN3QojwImO8ukJ9JF3ABXft/rdcYsnwE8DH4EDIg/'
    'IPE7Hj6AdL7CrOP606DGsqLmBj+xxcEnOstC0TXcIbIO9A+tCeI6Ah+X3ZBA37gUsf6O80+m8ZEzrLGdBEI5s+jYqJb3AxJMHJLM'
    'BCsOkXrsH/+IjjLFD07cuJ4iniCRiMnsCcrxtIvCbNTRcsSRUzl6onL0dFGOTUG0HB3mUTkW3x3L0VMExmUEcBh9T537mq5ECFqc'
    'ZE6JcAYTHOhkCWgPSlMx15AsINReAmZDJRpJM7ZXdf0jAiIQUjZjqViFmAeg+tgQnSSwqo0jCZ+MgeU6E0C7wEhQmHpKDo+iVGLI'
    'kTgH9JfLwDfI8Dgb3yIWmmvusCWgyCDkkMddyf2oQUfONjm4gnhIRvwGScDYmCuBRAOMhXKhBzjeOGrAkzhcyFaV1BmazmhAYeiW'
    '67Jwa/4abh1GjG7RvSv7ECFRAa8dQBKrAHhcFKd2KOPp+pyJqxmSrkJSUUEhTI0ndwmEgR0hOyRY57cbpGnJHezqoJZzCyv1AFXK'
    'WGP6P/3tS+ZjWfq4+Pp74dvf01oKFQ1xmRAiCv5xVuTLRj0iIUX26IrqwsgSCX6SzDJrKNKyvsahHNXFMfcbYqfB5MFkQJGfQZ6G'
    'px+NCEY3rtA41A+z6qufIq3hyePn2NuajRQj5YloZpmzS9QhJZA1g9ZSBBjEE7jEIuAk8lTgApggCusDdR8SJI+yl2PiltcZcA/Y'
    'qV/ZkkAm3pMgE5dSYRmgLL0kqB16jLHCsJBGisQRmgESSSDTWbK9C5SBX2Du/iV4SemqsfRWX1lT384zD3UiSqAaPwdVf45WzR8C'
    'budc1EiRGhM6EsLYG0DkeQjtsNyfY0FitKbweI7aRm0EloikUlqk28HKoKdv1t+5aSIeR2jgqfxztB0eljzaSJB01cI7Q8HjWNpY'
    '4bNMv7hpdGlrxV8kb5UC8dxQwuy3sY/AKBcisP7lxtJ0nZGrA1ExXddgkESbAKJuvp6xNlSCQg6jEiTu4KDoKVphSDdhExAhpJDt'
    'lxVhNHeqBx+oGny4mJvtEgeX/k9nZ9P/TMctY/lv6HL635ba4t/26txKBM6nv0gfT4AjkunPX5MhhqBqUrj3+UTh6x74yUzkfYXv'
    'iXDDydQ0qpugHG4LXsVtbH8XVnEbW92dy3MIZl0Ptcdf6DN6//+aYLX22fKE6azYt7dwxI64L7Y4bTVKx8p4hiApijxIxP8cYSMM'
    'ZHXUKH7jW5ejSEB+QJExC9+X2ACvBX9YQSICsIu/Yt2f2LkKsibkOz84ctr62AEUUJkOSEIs8VEHaqUHWVBhgyLu0kS6TOCJ2igJ'
    'WRvrE+mDuEysuiAVs0bigHGYlpYrQoB+bjUX5bWzcHZxshgDKWNFNJJUVXRQZ7pe6pJgGBFKwTiCOI3zilS46oXiFhdW+conlGpD'
    'Gcai5WD9+wRvAbX7xL7Q9FlfA3R/xu+4IMFXJCrYWGoluXELexFWGaquA6zIUeGnmEIWhTG2zJ9ic0eVNp84VMVYdZKiQHVncAtl'
    'lPfGnnJhOuMGCRFh4xHSHUXLTHN15lOZlkEiIHA9Ws1QUr6mvYSfttIh/lEgxj8KjrwnKBwz1AdtJGPCW1D8PUIg/4OUsQFwh9tp'
    'c2Z+3jAb+nvMBjBQrBiT8f+7+Y4fdcZz0Lh1Ui58vUjxTHpnn2hlMO19ToSdc3wO2Ak9xRMu+QmenHJUS5dkNZ7+p5tMLwGZx24S'
    'Kci1jQOcAKVS4zC/ggj4E1kP1g6N/WJ9sFt3vHuwWuYd9Y9WPSruMPkPOQ79zHH8HiwRTzsLgZiZdR5zsafLj4QdQ/pK2TAlOGFg'
    'ea9XHECyfgGffwqbb8CXZuASfM+MLRNlwwUAYOEplyvAZd6/tgJiJrICXHxiQIfzcCVPh5PEdhMXmsPhIreIIgAXoQUYHpuSJD7/'
    'wJBKIH4HaOx88uOmgmdCgewkiedi50FuCn/ffuUnRC4hsjP5k9AUjXi/80vkHIkXZqdJII2T9IlsR3iwdIPnQ/hrLhZRNsRNYSGE'
    'MfYUi5xG8VrPZ1JuKngO4Ymzr7dnpMTVC6R6O2tn8LRXU7iNQSrEXoGuRCIOiJ1MXeLjMHuoV9loihvWBgUBBoBx8lCQeIOvAXkE'
    'xTS3Z5pEQt7F6sEJL1lHAq2+A1oaom0ULC9Ia1gnodvv1fmubHDuD1nb/IWyn9+UxY6dDx0v5oB1CQmY48Xj0m1szo77JM7t//pr'
    'TEohTv0Yi8/PaXNMS0RUMDARnUXcQLLG1YJhFwOqnsCux9oR+S3YdqQC5Erl8MJITGI1o30Hqf0BBdIxPh3Ja9zw5x31MruYE9j8'
    'wJ4KzX74dMA2CCcDj6ij8k8cEgi8VRTwaOLiiS8Z2AJKZLSKankrNlo67EZB/tMfDPz3t0NXkkkYdaibvND4uv7cg/UjWvY7R4HI'
    'AH6O0SY4M1Aaa1gDGRsvWDFeFN6TyUSU7spIcHEfxCHXF+0rkFfMbvnuKi7jSoYrAcnYE77LjOWTtljgXIWAcR4wIT9p7sYlgA34'
    '+C+xuBj7iSV36+cqFZAVeCLMayQLFFNQ9/3pfOZMUhhXkoRNMiyrGfH57RnjwtcdAiBAzYskuzE82Pr3//V/5/YPzFyd2QSxb2gF'
    'yk7igNrwiy8OnvHgLbEjwJqMKiR2LyiRiuxXFCzT8PNvWncFvBn8SEqai0rSTltKnumkgNx4qCVDjuKcCu0690umqQhUGlBTE8gd'
    '0jIcm3emVdjDf7ILaUSzYDTMng1o11Wm/kpbeP9kpO3f/5f/G3K+zRPUcbaY2kTaZSP79dyhuIfE0KMJvWcCkSbj4UZgqeJaDoik'
    'UatwfrJogZj5CS3mPGnDz3uY8i/I4PoOySx08AYUMpxdrP8zMzaHLv32M1qL0VnZ5w+a/CEmOZr0kZmAfP6AxOPDLz/jUtI9wA9/'
    '0z7+/Xcs++1D+pef01D2l98+/XBlD8BU6HQu/A88JIWu4HMkBx7PMRwpe6g8C03aZAAMT33WVXyL3wT2a6ml6j0CiwjjiN+Iynl2'
    'SfNbIXM1RrcID2eIhVi4ZPoXW+zRMAq56wOZ8MWsI1rfEXPB8gthfqHI8heC/EKJ5xcYM8Jy8VrzYa4cy1XCTQVr+bhCNbCMRjUu'
    'My/64DL0+YG6TOIg2WYSaiWTR3b6zo1vuIb2rMkJLM1T3G5KflJVixvssG9hQlRFjz1oIgpirP2Fpc+ndy193oqdRLkC0YDpPN6g'
    '2qDiL8E3ZKnj76TCVs1EJKS/KJS2QSgMBVJSM2FCODuIr9lYSIA0GHKNyJdcBYCUToFpUkn4R1mfJHjgAWN8eVB1jhfmaEYDysfJ'
    'A4IaU3zDrqSzbR+l/73BLkmixB5dl09v1+W/Zm4/h3P7nmw0hxpZ9UT/b4k2hPTxI3+cR2b63JkvyEZ8jcoNb77BKoGoqyQCeeNP'
    'u/1jZKl5BX86Elx2HIfBes/7ycl5G/gevuDvEfY5AcX8mrBznl9+f5iXHy7HeOaEmPVpcKZukhkKrCCaWO+v2c0Is5lgsGRwW2zk'
    'nCKnG5G1+gNejfFCxvcH/oesHFufneZqcxLb3uE7iYv9kW8VVN0Y1xzlQjv0VR3RBa1rhFFLBN2OFEe2LcENDhkTF25hmtBHvGtO'
    'NjYSGSwQXRPEmHkj4xfYTKRWw212ntf424lFY0e2Hu/OLlV2jy3Q/IYCLJKFgEUG1iZknzzJEPGcATaKk8KDmNSBHg+4XwI+KR0T'
    'IzIqcOnXvBZmjr6/4cUYUI3ZyVgwABeNi+TzvGzRcB/TcNmYqBqZFW7hgfuPJiggAxHzJWzDUYEVQqMvbgynaA7HWlgzByPL1Igc'
    'oY0cyLMGA1gUVRUFMVtkXVwPtd0oneCtJQcr04+JyIy7e9hI78y4dQWgXH3HxDpSFAZHptElO6sclgzZB+W/s2jWedEsXLSP0SwW'
    'ZVliFouyLCFLZCUjWenRBR5XSnAmVzaBs04kziLx/NjfMwR+5sYjg5ew8cj7PORM5scOP7j5r5TviIHoM2DAe6DMdpKyIBjo0hHp'
    'DvfuQAqIVGyMxoUo9n/Eyx4xWvcbxhWSZazCK4gTf4WGXtAGJZE4J9GFU4cs6hUWhFdaLpFJ+XRtJheBXBdFOlwm/ciMnQMWkyqm'
    '0ycm/pMMBCNj4i7qCgK1zFlV8Ws4YXfBnIdTiQqecDItVNOpBxQcInLKWTlLjVnYGsd5G+oCzCzhUV6SNF78Szj9G0KGjGTiGuDM'
    'sV3IxhkdPJss5FLpBBztstgM4xoh0eBnlHTaTScPAVKP4FpAcieVRkY9Bpx77j3NVTATKaj1WZJX8fjmNqZxkXATHg1qn9A8JCrL'
    'sqrvAfdDSVllWzRCxa0IFccNSrmQJLIOpFgPturlHAV0KHHZdQa1335gJhCuiVe7QoQHMKMuFoiNdiq3CkH7zoC8wtQ4Gp7a7zUj'
    'apNJDAwsxZlvDmyeIxOI1V3iHwI60tnEydwL7boCtgiNcWQmbJwBMFQBAulVgvO2+FtuBphW+PiJ8ZEPxAt4Ibdwg94bDrchE0lM'
    'Ih5XcrNJ0iIS7aMTVrrTu/R1yaHxX1ZEXi1YM2wO4sitZwIRkGldsG7Gwd7CEPmngLMNGFb6nmA20fQx4G0opjFxrqwdNND2ARiO'
    'UatNEGxVZtuL0Iwz/QmvfLDQ09SUw3loR/3IGOIA4WDt0px7ijgvDUOjMMkocMEs/xhdqJA3OzNKIZcGayhEtNJBJSJWgkv6ayxO'
    'lf8CSfgMWFVMAP1mqfRyFyO1M0kU5xMT1blE7BIAXHwOJQCt/4RieZTdjmj9fg3lTjRWCaRCrC4u5GFFcgkmH0YOtukjCJe5BFYt'
    'BILjZRkUISmlfBsrcXU/t5tzAzrIqpunIIWzGpa5jwsprIQdnjNwjRDVxT481I8eMYBMTNYUYTrpuOFDjj5E2FKkTFDJHZ9tVhCT'
    'zm1cHbNjH+Jn4ZrO7FFrTWf40a5FT9UjhTKkRafz+YiUToeO2AN2Yo8VsiP7SI1o3gNzk8b+udFDhhiZEsqwMi6uDuBRsmC4i/34'
    'Y2DgcBtY32NvACgkV6Vxukxz7sFOuLuEA4RNtoawhClcQ3d/lYVbrVAuMQUrK/KzCVx/Pm2oOyYjBshfiN1drrR1gJXecPB4p0D+'
    'TYEjFWCa/bNBKylirvg1vHnGsSjOFapjgNaQguC3v//eCqw8YMb5E036zTf8tth/i9Gv+w26+Pff8W7gt98+RY+nxri9WqnzmooF'
    'BJ0gBUFDzGIKHQv9hHlp7VopnHtKwTs1Xy5QNp6AMMQQWXZ+EhML7TF+5IZGv8a+fIUGsNAA1Uc8GYqjARL2MVrL6nKbtdg2E1Ji'
    'KXoutucGBy7X/UIj0TM49gk5DB2xCk0qn33qAgE6nY4FxoV3jLSQcnnPLm9pK9Iy/xAxMzmrpXGk75hvUL0vN19j6cghWWAHwm1A'
    'gE+gJiKjDKxNfoq5+HX13tcV/3o+fVxKiDyhrn/843oySsGAuH4Za9SQmmOZ5GXun2DSg7GH/ZJVTY+HQ/Bws8L/Z0CCcbZS72wF'
    'BKUc6ZdabNvAXoth6/KKpeHOEINJPdeH5qa8vh/D+hLn/mAvoANCPpPgLEAP5wZ4XLpNIANDHl5EYr6bXH5bkcQpVMki0MW3putx'
    'zotdCHKRN5R0Dr5kXoIokqg2awiPBNklDs4yAVui6ZynDPxEMZUvtaFFrBpeAMdEjT25wHCmyS8wQKAbx9UfADRMHYjCt+eTh48s'
    'BSY0WNMECTKweT7GcMck6PPdGXovqn53rt+kBtZdlyYJPVxKGnMP5CLfjf/OEOJdUPg2phB6gVWnLYQH7MRjfcZBQidZ1z/GevDB'
    'MekKZLyHAiQgm5/oC2X/iYMJ6z8lcd6QCpEd1jV0nCEXEARTDbCqScq0gZ3HsolEIhGxShpIS5dbCf/Nw2eNLTY3oHI1j0EFmiyj'
    'EYTm4bk44y3ZDa9g5VOhjvMYc2VJj1zkDzlxBoXs6o63Qh2L7UuOx8GVaSHI+g54xrm2XIa+w9wYXuvkSdjPMwxRrz/TD1e0MDNf'
    'lnQ++Ufi6J35GJw0Qbh9B9tmUsUcbV1cKiR7knKJkTyOlIX8W6JVAN7k779736NJ8gqgCi/SYxcJRXvc7t8js7nzGr7B2jd/u4FV'
    '9QKkDc/YsW+JUMlBw+VA/gtvIbRTw3bZ0R/ddQ1uwM7xDPu3JPQ4UvjjReFvv/1Zz/6s/JsuX87HmPAj9g+Edh8WK+7629uYzHQd'
    'PjpFkZGAZELtGK4drCgrFDYqJAKONLpMGeCKPkWBpRY2d4lrLte2kCeqeIslqkRpLsrARpTfLZlJ5fOJKO6JFqNzgljyc1Bpkvrz'
    'iRODP8f/bLbOxAXFhQs6RGwuI0NCASAjpiJH/W41ifMFnIsqrhHfJU3cM25EhNKriw8r+pDNX5hnb76D1ldHy/TiiKYYHn8haWnP'
    '91v8uArTCF2eGRTW3w2At0B67Dd927zbsU3ifAwTtTL/GCe6fLEaiSvFK10Fa/Fb2fADeB35gT3D8MgZ4O92OSVDb/h4ZBbfyT/k'
    'OBhJ81Z3bz8x5pzAhi8V4S2CxBr9nQYtvO09Teg3rvmtAoJVjuQqi/hP5ugEmGJLO+CtSdrJzBQ1OBFHx1uXKBsRWyIFE2qAiI4H'
    'dYxVCO5fRLQhIYvr0VVoYm0jrD43ZfiK0o0XHkm/QSYBgov9/JmquDq1siRHCviZlGsBPYrf/JNZVoaHOtwkN7Cyi5SmqYDSWAsv'
    'nY4l04mIUXMo41Mtv7KfJLLL8JfK39FP1JIZBwQdJ8MQ1rb36XzYFFqYBqxIxA4jYnAcC8pGa+dHHsQ1haidaS+oUSofuf3EL2ZS'
    'P/GgIjDsPS/pHTuXBGIbXrYNbEqirXwMzsMivdDetn0mr1oCVXkfP55LXQzyIuOnWMRqmn/Rwmn4FjH2fjtR385bE81WQkW56sqB'
    'gxr3bBXx5R8///LhK1pFyJzO3vzjBiTIf0hb6xNauv1Mb7pHL7/Qy5K9fKAXdFT86Sb27Yv8NREqhJ0lKmTo3s0voUyEFxwBrly1'
    'bnhomsnHhVaBgIvDo7Ivu9gvMI2F2xg9lGL/iIn5PL7Rw1eyi4ncAj1gXbfIHnjk2yK6pfBwAvqCOaCVOX/j+WCfodgT6qgZlZK+'
    'aF9Jy4S/H2P4Srqm6AnFb1jL339fxDOJb7f4K/BfMfEt8RtHLvfAo+FldeSPdACz0GUBih3MFIQUEUCMltru0kQEoEfVF6g6JJUi'
    'KijQOZyqR7AJS+CDP1+A/QINwmrOv0aGTnzUDge6Q/yXz0cI/vYQJX68MBpqGmG6ZkTSycIQCiUhR4JhaQXZvy2e5GyNQFJcMSHZ'
    'lUgbqKAVqoL0SgjPgkBQQQ5cJ8bkgiNQlASVx64BxXVQZxhfMnOqdAy//gspYfj3JX5HpaDDPhNrfxeLO3i0FCblIqowETcC9Own'
    '1p9MSszTEsPo8JOO6w9Mbh6+6VeKRtxD7wxC5KMAGRwmhF03++kqI1DafyFqLibogUrARGOL+CYHhJVbhTvAfC/h/7mAa/nli3yL'
    'nmoyQB++wK/MHzP0eOCP+IFnyPBHmR4PX79+iTOJfaGbphNf0Swix1igp68R+GacdLQDZwiKbJUQOoTbC7Zzh8BBk4GglvJMfv8c'
    'dnkK+Ns+XmuNwzTdZIAspdDDc/zmJjiNrbDzNPLCiPI5N/SgY/6taQLmJXcldF4aGoLc8nNYJcZPVL9/WJ1CAYxd0aStpqgWqQjo'
    'Xif3xqBo6J1dVgMzLwAVVv/d5VEASlGBUZfvMSsTl58AcG/Q2NIi9NR9tZtREUAlYEJWalgoxfyc34bnh8yfB4mUEhXWDC9igiZt'
    'aUDBvJBwSM4p+CWKreQBI8RMACl9q6peig492iC1asyrvMrsZZAZIO8ugfMlmEgXRq/GE8y0KSjGTJuw0b5qM4PL8LCClgcNjGEe'
    'jyAGa7avxiTZMd3QmSmvnc84WsuhHaK/nRuShscyppmInJZBm4NLxegiYo90YZ8R3CvEtPNdDPjAO/6FKjMtfoARIJ0fF6i0WqQc'
    '3LPwk2EX/gP7DX4uET2ifgfy4xHunR1/L1LyAVV7R/Z8TPDaiXmPtJZIBBtgEB4iBUdwTHkU+FjjZ0QGrhteeye9EewOdNtF3vy4'
    'aTs6MIINtPLnqauJpLGfrVx+1NyaP49HrAISf2LIcrYyWEF9gdHMmTMMlissdalvDy9+chLGE5CMnc1kNGPTMd4yEe+Rt7AZQOTl'
    'MqAdBxAQyJmlIjwv6VkQUGMxR/6sQEcXfxMKQlGYk7b8bwv6d/OJGwdyJ8OhgzuLKXG2sDHleCImKZLluSFuCjBAnDk5kpyPcx0v'
    'MX9wAFt9CL4yx0jMF65mkC/c2NZU1NCodlB7fnkOvJtQPjy2mi8j/UNOwkL/epEUmCZ8F5WskC3dkG8xes8Xsur8hvn8wgRlrhap'
    'AC4Zer5KCSK7Y4BfC/OiWMrwuwryHeMFZXTMgJed4viEBmCkcECOCxJSxRLMbCpTQvp4e+4SmrqpqsVLRUtQrgz9A+GZLjvgNJyH'
    'KeSEvFCKDlNYiKJYPA9Tzal5tXweZkGVSgs1MkxBzUoFNTrMXP48TKkkLebS9TAJNs+YAoFDXihZNYPA8SeTUEB6nhKCOeBA9Sdz'
    'EMwUzgH3qCZZ1gAhLGpqGzxwY9sUXl91AXF7LCPqInD+6D4Le4AxEuQwN42PTPfskCI26psPKRejLOiQSHJCk5J94PIOXukzXg4i'
    'L3vhHYGIbjeGrBcMbfk9Rf/yHc1LfBk5WhKQTysmguMxRKh4kEFM5TKloTpEFKkipuagYdUABwLBjMXRbV+CsKDvkQY9Mj5J9lAa'
    '58O8ZbdD0dEg1/2TXz+myDl7/cba44a6ZJZan7liPsHJMUn0eJCgHiS0tgoJKvSAKBtkOalO1OyNN/+koVU8MWfHKAlDWyr08seM'
    'GABmDtH7A0g92L17vCh0Tj9S+jHUai7fV04FZnERigT1pzF/oEeCeuk90CFFNYRsLfa4DqvEJWPqXOv4l1CXTVbizJor0FoBqrax'
    '6wqz9woOJZxrQsp6F9JRG5nXRISw2kdMOCs3oWsXme1jgpSfH7FqZtbozzU59vBf/p+TBjuAe5eU3NgXcqlyS6oHx9TRvjR4BJAD'
    'PvBrAOhR04NgD8fJUaOUOpB8SORdQus22vxH/HJkX4705UhfSJt7NjNVT/devBtKbGcxlY6fu1+Qp+9+Eb7ekjgyP38Q6IPIP8jn'
    'DyJ9yNKHyMzSV/oTDOGWpc1JYMBXL3Fx/kzqngf19D+2e2czoKvOqUHSuYPbIAktyq7G9+UL6w1UAF+3KOlsKZfM2vv69az6cP05'
    'jAuXE4eGOmuGxcMRXww9k2ADJA4QUZaHTJrHWLbgEe1VoH1mhyZLhnEWWrhB2i4QH5AhogdzL6FPfo+MXm85/lgEzB6/e/4LKgTi'
    'FJ3GUReAPZSoRRohGpSloKMLdhsWb8GexX+MBsAbDBWDgfpKoCtRn2O5Er8LFT25C7uZROcZyJXCC0KwBsOGEqFyeRGPAHGC+nvW'
    'DpJ20URFD/QDPZWSqi+4sxl0ZsPEhQ1OMPRlQ30J9BF0qzkOlSShOEM91+1uyQyQtUxNQAJX5VPj9BooFTm8rLSojwQ+Td6Vwswz'
    'Q+UN8gxISBw59IeIoYeYHIjhFMw9us0FAkEyFlDM3yDpt9h/+d+Ym1mmJYy72tJA9z4bbntFBCWCD8w9+cfl+wBeL4zlEKmGiIYT'
    'ghC94H4OlTQBhsdMCW46b9IlNW5DuzTiVPtPV0gUSQr/oKNr5pyYiWqHAve0cYb25ojv2AEtUQ/swU/YECHAOMOAc0R9DNcTyQkz'
    'MYOpYANLtyEKACAWIWM2gqMiSfOvF6uCJJ/57tW1jRqRyINrv5IR639kO5Bkd+5XnRyIOg7p2s47lTQFoTk2sQAuyvEkJLtMFA4s'
    'w/EsFoUt7ozUiNENYYwpEdhuh8IXWRtoiMQA6IPU20CUwGbOcUWYK01mPZOK1blzdcc30IPwSqOm3oSYChQkNCPB6QQpdZVY/De8'
    'dGb8doft8J6FI94mbulamqNxnWM/EogKna4Sr8QDZAH4o+kkMYYL36E8pIzgz6h+jlCQKCwzcZ+BM+7f8D2qeLwCq09R4CC42x5C'
    '0vrtMmnOkuZfozYv2yOrNAqGbyulzQRVbM+Vzi+SGMSF4yIv1egHO27dxgIrWDpw2tAOxDMbrrAnp2hPz5X7YWvQJ98N15SUmrN4'
    'cxYfRJBu8HSDpaNtSZT3izAdv1wkBxzHeecyf6vutTntdy7Ef/kiaVsWaCp+hZOQFWPDpiMGVDt+JRx6B6UuVhx7m+BqyYsPP/Iv'
    '2a9fr06r5sxq4gtI6Lnb2Ef2k0ll6TmLj3l6zONjiR5LXxPB4NjJx/e7jnjtqvOFgIuM4D0hw1yw0H0nVMMFPqxdGQ3MP4deoK/9'
    'dnSRfXS9r8xVLHUpesy2Ysd4mVtSCwTWYldEWWT3lLOZC5ocrCIq1kKyh5Q4KyQuyClfbOoBQeW5hjdihhnou86nbeFU2ARZJkLW'
    'zxEWXiCTmkiuI+U6slyri1xRaQfYGxtB2WZZS+wCoOfiJbArtzLBL6AqFlrLZTGHzjdy0LpHlyxmTgNTCXQVA+Ix/skw5yZgPlfl'
    'kTPuLpz+sAuWqYs5ZdejnsnzTbTP1mWfC0hFryS4i+/RA84fz5XCTBBeYOb5Xqgzx/nzaJZtNstC7mJuPZpbXrmAZsgINTBhEbaF'
    's7PIXhNwkaFyBlaAAOynWA6fESTP7Bpk/pkBMq5BANGu/CkA9e756J/jSfzAKW68EiFf3INNcC02dNeHRCKViN1zesgOzInsBAru'
    'gG6FFJSrylVlqQI61raBiTyOQw1Lc81nKNUDX6foRDyZ8oJuahFDxrz2S9wLlGmogVk9kUcK1sZAijAqhyvmn5Hs4BnvHQ6UTO/x'
    'Bg7r6C13Z61GlO5YD5FoLRiMc7Y4pEOGkFkhSho5wECeklsjSh424wLvBthK5ZfBuU4fiTHnNGDoPp5y8JssRI9iMrmxiksX66OS'
    'yv08lCizecaT3QusGCVQHtsXdO7M/XCSXsFQbsgv0FU6eSaFfnl0qPNOQebD9LtFQ+07axiPznldoQajGzm4sxiRxbuft1xAQd3w'
    'D+8gO8gS3E8IDKshCa1NJR3Z4nfVJlxxdaHSR2T4MVSDcOwb2r4AzWY+8rA3iB2wXdzk2EzwlqQ35kERU47cUVDU7Aq6FMzir2yg'
    'xGyw2wtvOQZvTgVw0oLs6Mw5zH7BSHCT2EBzFoIQD7zBldMSMn8E4CFA8e0Lq8+8kCPkoiNUdm0mFdJMQ7m8BYgCOKEzlP9RUqGE'
    'Q5BwfSMwkj1znT3zld8OfNtKeDsQP0UvCNJ7hBdCW/XLoh5jmTwSozy2Yp7EW2KF/IAnO1eL1SRjvLXjXezcgcgXXJ3d+2U/frfs'
    'x6AsX6rgTirtaB60LvYbiCm/ne2YA5cwXuw377dQBRmg1bP9J76Fm8ajyByRbRNK7Bkursej2+dXAH7YQWT9n7z+tCI5M5NJvMPW'
    'ZK7ZmohAeSXcR2ks6yMtB3QzhUZ8qOCgxcIENA/fJsh36q9c1geIZzqAgKWI7s3LqlYaTf1ldVD4ejeql7sRJxA3oxfIDx93fHfB'
    'A2wvchEC39TonqRCGOoIBuRTjvnlHZiI2K4yAFRJLlEZaKoSE1+y0bsCxAi/A+aBgKMGPVSZXLWjYW+oryqTinY06E0o+PC2/WhO'
    '1gP/nFOdR7RpFyIOiw3jqCriHbp0dRcL/XbyICuBX2syW7sLfVZjxexk5lwydJD9Z0XPznHII/S/Vu4fB50e6w2Q+juyM73lTosp'
    'OAv5x8bYLoVzWd+gSD78KCFyzKhfLhD7jtD+6QK8SLtBc0bKEIx5wI4QOwYP080uFbKdSvaF/NkgYt4fVblbZ3SUhdPIOZtAf/Ge'
    '8iDQHBDnwOQ6pmYgc/LfcEp/ww+3AfsTP1eBTBJJ9QEB4FfZo+oFjKfxzCKBA/Ni6ZJhsLMRftfdM0Omi2lKuJnBim4YXmpAIuoT'
    'rlGgIyXme5oiMkX0LMRxBQdTPJBmMCV0/IIMPS9P596aw653IE/JXaWcTe4Du3h0wC3h3XhSIJ3nmDv+xiW5i13PUDD/qDoKDsVI'
    'd3Sp5r1UHkVYLWzmLImelSB/Kosn3lOPzdESLKIeY0lR9diVNPeneoL/T6phUOnXChgjxrtyr5vsKuAtCuFulJ39nW2AMAoVW9RA'
    'vGcCM9ff+No524qwwg07Z2aBzs6BrFT9kTuP/EztnbE62sQQNf/pAil9Ic6XMBieV/xP4LD/W5RPgUKkG7kjtEnEMHwWm0Vo8Ht6'
    'sUAfRrSJ1PJd8kN9sScizC9s6Xs2sg1WG4wVHonhsBi7cX3KfEsFHy4K4twGxYzvFWMX46jQr0Bf76KHm16Geood+vXitMVG8vBd'
    'dcFHrJQM7YTE5d06T+AVPvxZhcY7FQq37F60EN5hYQdQyAGlMmf7pJubSGy9APN5po+mc4HLP4ykBTuIr+sjagHoXCxyKBb1mU+X'
    'elBdxq40lELJKZvKh6kC51e7TNqPasTjnmaRWI82Xs1EBGtiXDnEuCqapdGdKYMoAXleQe06oWYUmKm2j+wshTVECgfOAEMDSOG9'
    '84nbjRvxrMJVCmRuBlnRhhDxPRGnyOkAi0BGAjZrwvXY5fnQLpz6h6FYmVWBTtqmwMqO6zzwji4Qv426R4eK4ZajMQMqbDIDZfON'
    'vIqTFKj4muzU044mhBADz06oS2JcicPEFo32s8MEGngh6MElCNq8lFmR54lTIaaKovAD/LX5Bab2pxgKX7esLqaSCvIcL/IwdXOE'
    'bw6sKz7T4p8ljS/0xhhy3lLIkiOoRJhxkpqPd2Fr4QfMlzwXQ1Dk/lK/X2/yL9b78arer+9JYYxPkSJilxRzgTlCnsFQr256nrcB'
    'gpfnA9BecyaxOMUzZy2FR1rMZygeoa94UC6Ns1Lo19xCtZMSXKl09TBIV9gcU8idtxr2nC6k/sDdauvsIiG2iA6TnUsl2xl06WNn'
    'EQqOKp0JvQVgR8U8j19QOkeouJIF0ZSWiYP0hKfPwXPyM1pCv71XQh8juPKR48oI5DNtNTTN8SV/IcjH4pHu3pH2IqKq5UDKT5Mf'
    '2Z6jGaMXtmNSZKUaf4OjaSrOWPoXDBV59pnkRXW1PI23HobOIRqViKLfR2arzeYbqQAh/cS5ANeHXRYJ8gdU5/bitj2AOWMzHpnp'
    'hWYF7MMjWU0AvLPv4cAFdtIDH4Kc4adMUDfzuWOdIWvtk6UmKUOJ1Q8BkcsGLKJNoIy3TDqvpUCPAQZP/dm8/CkYsLGeIYG/h2iQ'
    '3VjN/9V5/SvtUcmLFlnK2zbfWRuc9t9e/v77I+m28OIIPR2/xR7xUQgTBUrEJzFME8O0bJiGqDh6hxaF6PDuEIvBxIwFSbaGrfUb'
    'Ul9Yi4+YhJ6Sjp8//P13pOjZlIi146OYyn378Fvs7m09LHTVd+pBtuS6hpsoF4oQUmPcRUglgsusv/1s4emO8vkDzA+hdBwh4exv'
    'sRZP+mPqERb4Y+Lx/eqSf626S5rxbfaBDPRxHuVvH/i8XL59JBHg8wchTMCZxesPnz+QFP4h/Ut0FcnNts2mRdYcGeMJHrBKAEOo'
    'VD6y5yM8O8H6Can/l7t3a24ju9YE3+tXpGgdI1MEwYsulkFRDN3KUh+VpJFYLjso2kwASSKLuBUyIRKm2HGeJuZhHiY6JmbmuSei'
    'H+Zn+ZfM+tZa+5aZgFj28TzM6baKyNy573vtdf3WHvs7P77x+gNx5YYr93KAwblFZOwMSQwQkFw4oTwtyxQwdk71ftm0o+xOuNTo'
    'VsT+aSv0UrKMiTezYajo0oR2SKU3jVRA7im5/+h+zU0cu3KqEhdpJbFDb5fcvR7YgUJT5E+8EdRq84+Z2ox+fxMsQz+dmVUgqS7t'
    '5yVNb+c+Zs1uYHSELq3bNd9f0XZxubJhqo7O0Y3uAm3N6BPtuYmFvhkarhJwIgcVEg1NvJZJql13Os2guk/iFWlo/8oqlWCaSkFF'
    'F3nya+aFM4BKTEF9ahzswIN2dMl25YTquXtN8viNqAgPNohzL6bzLhsIs7k5MmHAo3MVAt+kgUB6TaXEm4wGFrDX7nQbnqNvhUcT'
    'CWE6KRkqPvedXRTHk65gQYarg2+yl5ok6WB0PYO8qZ0VJzV09jmS0hW+bk+1gggVuJzOGap4Oh/kE+RF70SL/ECgoLzAQSS/MLnR'
    'NdTQ98zhCJ5F3o7Ue9x6nPvqEuSclziEYy52ItTIQhT7i25wSPHMpir3srpBCtApakYthq+Ek9OhwLf4R1zcCzPab9KeoUDSWOsa'
    'sF7BvZX4k8DtfzWKrwuZYQksQLX1ip5pUUQYieXx8BB6lT4JJ3OwCv1lV8BM5ztdn6noGWzTtrr2zZFfLZrvasJ1ZqcRKOSFaeJ3'
    'O6oFG3ElFjY1gDHhmDHE6ciWmQApkiNTWOPJNnoT1WYCuPZFoZwyrFZbmT4IzxuIiJDz7Ue1+lhyqMPlumFBIGNoEZ8VkDg2YgNg'
    'JplOjGKuJmLwJXKgRVwckUZvaBjHUQe94hiLaZCjysaOOZhj4yINXK2jTt9mpUvWrX1tgduMmc84XPh98/XutVaEP9ELYcrUws1T'
    'glQ/J1Whh0mEe40q0dDdaw2u29w0FclUFsSDF178fqNn7UH0SD1rpTgT6EIA6s/oEIHgxhznthkGorHNZxtRodu87/i6ms62eGT4'
    'yk5bNXxLPkuSG0OV8X+87tw4tlU6+oMLD0RlOW4Ks+N+nNBGPNhAgoBPdAdn7yc/FnR5CNeDSDrL9iCUzvA90smndLVioDdPtsOG'
    'TFcCqex0MR/Fv5EZllnnwO3I6T1hvytUC8weRma+11McBdKdJM0EZRCEfHQGAQWhNX8rDg5n0/6iOEoFJ80C97h8M+Z94hfwA/ga'
    'iipbNqQjzMdY/GHoW+6CDJfWKbbdOIxaT849Zmj38cZTQZeDLdgq471mWQkseCCBGyQ0v4z9KpnFoHQ29KjtIfw/skiCgImEmrEb'
    '7Zn8OdcRbi/iBLrRKSKhttBjLD9mEmLGDVuog95vn5sOh3mZnN8mrzYxCi8kRIQf8YO3kjfdUDAog4QY4qXjDwxXapKee0nYWfsK'
    'XprBRaGXsTKxxA1PJgaNFNHGA/GllSR1PzEvwasDRY1ds4z9ctFE1mdQVsUD7Zrm0aZd2HOvnyV8iZC2HoqNlpf8JXERtdgpNOJF'
    'LhAW3h6spIOhn2/ZrtKQIcaxRfzAQXrCvw+TOsoGxpFsbgAPJAJNLHqKuSQxyPnZWcYXuOTkcrk0ADlsQ2LNTZYrXqpD+xV1My+l'
    'hFkQ2wMXM9FPSCjyxgvOaUGMP7OMHC0NLuuZid2E+770EAlSAITroWtx7WIRasghMKqnBQQTo1m9KtmFgDgNTxBBOfZvQLloNJPa'
    'Yaecvp1eZvMXaaG8lcL+UCmsHP9BnKPrGlXnfphLxuRTDdKNuU8M0Ekt12p4lnib5Kzllg3k7ZM1Ax9ngr3otovkdJNrWmoiXs1/'
    'zcpH89I67I7MQQ04C/GDF8teb3olyJMC+Tjx7fxhCF5o3PfMYQzwZZJ1Sp7OAKXLeKjagLFZOgjBr3faLu5CjK2pONm2o57aXiUs'
    'z3hGcTYfNeN6BbdcQQYLS3j1761qaMkNDc33Yo8dNjQkhmGv4JYrKA2FOvGRQcWX+AM9n+dTxF+wZZxdNbEtQa9aqmz2AaR9d084'
    'QDqttTQk8lvoy/uFww/EWYFbbFuFvFrul+rKIE4Epl9FXipSMrBXVMP3nd6HAyUp3oc45mOmNTmcRERRzup6deosvTwHSSc6ZZ8L'
    'eEv4wRZMXuxgFLU24ySlU6BLQBmvqlSlhuKU4YiLGK+PT3wXyGkp6XRitmEZoC26UipOXYEnO368mPID35l9BefogrJqyvkdNv7F'
    'F4xgIvC6Wy5qlAHFLmTXQAO688A3Z2mHSxWk+JD9oofsFz5kwAK98Vldgxq70+D0zhDpbJQG8ZsxbWHUB1yvvmf1zGWPeBIZz/b7'
    'lSJGaKIixq39fiLtGx9sZ+biiRQiYzH5SPIQ60ifPlWCANycKdIkQ7WqAH1Mjm7z1YNEv5BJuBc92vGDF0pGrnmYhLYN2FjsanMi'
    'Frfy7Bhu9sU8hN3SL2kpxT3fj5WTcXKsBT4OzYniLB6YAX+e9gq7bW97GVqMLjkN51MHve6cgNp1/x7vlkydysHdJ+LfULlH3J2Z'
    '8pXSa+bWrYMIXR2arGDKFiGTrCDluAfzqxemXldfE+ck8Y7TWLyL4YUchBA1Ms2Yh1peU711Gp0tD5y3pQQg6Ip5R48jSGAD0alO'
    'S6F4MF2XGUKlnUmQ4UUym4ZVOGRNjoe/g8EiTYTjUBhx2PEbJgNswLacBJlkOWBY9TKHEYRLm7e1K5XLU/yJR0c8PYFklbNrqWVH'
    'qAupJAZlXoJ+9txP9uWLm6QsrNG3Ba1eYxlvW1FvEidTVeSohyRH7YdSlydNuT1y+01B4gcRkr3OQyctiWclJxeNdPXNnqsIUijJ'
    'cr0IUs7pqauigGP3sUj5wDlBYSEgG9ysGTqEsDV79pHZs9SCwV+l8dW27SNYJ2VQ6INtEsTGfDeyQ8V0YEfcBFC+zpmQlZrwwBQl'
    '8ZQIgVrgK76AHCApzoBJ55+V/ivJd9r/gEuWqWqFQ9W3CEPTJH+wdMFMMPPvN03JxRrnGPOAZTAzoSBGlvUqDCqX7F5mwhQnGQKu'
    'pHizbBgzYBr3io8MdLJ6oTkKcyeW7ckPXg3y0m7QGlwlqx4Z8AaG0d2H5s5sQCauAxN7ZEq5EQvkqb1pR7u/w+yVl5Vkzw5ofj2W'
    'Z5KEDYW4reUl57x5JEjpdajUzeixYCUocxhyhjwhgkk3ZkZIpYklPwDbMzT4HobWi/LjeNQxmbfh7mk8MxsYNRHBWMl3HjXQlBW2'
    'm7vX2D6HUSskjprB4OkTOHJFrPuD4o/1flD6OTMe/RhmOKr4NYQ+8MrZkUj+UXFGzEjGHHrU6Z0HFtpmIscXjqS7HfUb7HgrvwJg'
    'zW5nj5WgNtbSINxiK8SlSRF0+oTxvrnT444bJOAK8QnWN84FzApDQOktaOmhiBUJa4OkIxpqOim34HqKVmie4Z6djjYYm3brLB3n'
    'I66Y97Q+BY44a08L8+RSp5LOgZstjP3p3eus6NNmvXmyjS48PXWofUB+9Uj8jbh7+icVN+2ag9q436oXAMbPMvgOS+A7LtG6vWhk'
    'E+IxMWsVxYqErYjGFZ6V+JnKzxD62uhxzJ/FatNVY9CZAvlcMTadB4Yjp23S8YBwBCQFPI0DUUtc3kVJcCKbjnFTjbq0uGQ0LHff'
    'nktqFvEF5sALsNKat8V8t++qkpCKfbHo415gGZPh1uJ+YqQCu4x+9ZzUpV47QILE6CKVnnfoP4cVrKc9UecmpsGjDiCyGETrwcOw'
    'WVv/UYeRwCrV7nYemUroEaebCStj/hBzpJXWUJIUPdy20/LM0q2GqTKNuZmQrDbcMl52/R7cT/yGZesDn+yIYWfFDMW55ewo8da/'
    '3OdXdYgl/z0P5RmbzgTxg8FgCqbLNLR5yuqwpAbOZcIclSzBk0IfqY1lwqqogbOzTFhlNFha2qobGr+X8nuovw3FOAuIa9HkfnFD'
    '/3A/bxyN7MJC5Ai+6YYliIOA9FM3AuJP3bBdnF/9E70JDDLiCnAgFmPN80uLGSYf2/9O0rfCRuRfgWLfEuuEyd88mQ4ydOrW5p3K'
    '5fjYXo6eZdHeRN7Wcr3x53QreuSmVH74MwomgyHzdeCHCOwH0FF1qtcVrFzBc6zko7bAjOEziaJd6TbDd25tlfY2GjzNHkUPnKFR'
    'cuRxb2gyzhtyBVw7nIFntbzN6r/NgDKWOS3KVHLD9Bm3SXnS0FnWO5SctkJJx4EhHkwieudRV1+BgAcpNkDPdz01jlk5PePxLjwI'
    'd0zGq6LgCtrBtnhIPBMuYvPJwzZyxqz5gLZR4mt4hEB6uXaa5q/aMerTfUV0BBq4BurR01PXEq8nIzGSYKlNNtTjhmfnyBMoTWql'
    '0Gbu37G5XrK5uWU38XB8/ufqpJ4+6RO5+8AIEnQ88cMcUZ/dzC3lyStUJ6+SndzQnUecb91UH7B+p0/yMfBtJUM7NzimGZ6DrfyH'
    '2kMrW3C2OthgO7Y3jmQD2FZFRmzTs2JGI/qIdKIHG1c/5IM/0/8iBl1358bHlVjueNNXgkLQrgjEDUUIpKeezGDK2BSYI5sCszb9'
    'jt+dePwu9Jq51vsvYnPPO3VGl58y+T/38qjpdyKxyGNDde2tQne+ZYtHji3WKU185qya3sQaKCH6cpogT93d93e1JDPxRDOPDcU7'
    'UCat30twMFfMZiZTRL/OJcBTTZkSvM+2VU5RCWd5unY8NGmbxlkF8AqYDNWjqV46cCM0jPKxPDlhON3Hjx5nv3/UYknflgUAs7n2'
    'QGfksUOj8e7Pu9e2/lO5S6kZTDumW14lK4XK07r02Lc7zW7u9PzPPMcmJYh/6riF6rlDQY8J8r7z3GwDXoMG70TIQOh0vAeXEc6Y'
    '7oBQZBTK4Q5M/4oTmqBv2nJtSP+ys1N+Q0pU6WFKZ8EcC7uEAiavP7vyBwtr9txAfjx1OwEDPTAj3fQB57kjXsqiajKMZkZfLjSf'
    'jlUvk8UyJHz8H2MF2qtfIqyiuto1HDNvJLso/HgBOn6153hqv8SeLbHOTRzzDukG4Yx0Nz8RpxjIUCsdiCtUHZ6lKcAfxOxZZXni'
    'jc2HGyZuGi6ySB+YRsUYdsmNv/8v/23DoLNb3+vpLDMpzjvRc2DZlNPzc8MJqd8caJgMGcApD9pwnDiIlm4qHa9WXQjRGNDCbWLP'
    'xMWiV3ICWk537N1BVCckwl3WkrBtwerDfldfLmXIpaseU95MQHzK0WODe3DeergXd3d9gtHzicXenlCJ3d1VEQGNtGCvoi7yT37v'
    'yjX+Lzniu3uVw/27hsMtR5tnu+HgeoqfujxSF5qSBt7g1y5TmROT/vSFbmvdltQzfhxGTPScRNtTv8HdHV8lyHqGb8VtdB7VFsmj'
    'BLxXHoCKKw3oORrQw3nQd3v23brG9lafcX/W1wiBLFxmg5zxIXzphxWW8GSCu3pvWpbT8dYoOyuTLqeVF1YgL8V3voY7Sbxmnx0g'
    'FAZs4vlONIlFQ0MOSFgYGkIAYXArur/yqLJJEsEGK7cBO3EM09xthJfoe63PeKKeJNnYbI5wDYOdMnQ7ZXjLndIssjbtlkVhhIDf'
    '5DxG5f+HgWg+rMjmOJ2GuvBJ/TWCc+fByjCXlUFIjRtsmBbvkPKSjVuBLG1SXkLEyfsw9Sj3KVtrLgHXrM3qil1Zl4aqlDSaUayf'
    'pLNZ2+0wWjq+cBi0NNxVk/CSob01ue3e4hZvTV7eowP8SfPmcXfFBIv42LJlfE3seKv4yFvF38sdcf+fJ0HHWwDI3AW2phgXoAw0'
    '1gWfT2HqZGnTxKrUlElhTPPcOt/Cr+dBYsmVK76+dw/XcCbOZuB1P7AdBOoB98ZDJozZmxx6S/xB1xH+Q7cR/zq1vslqFOC6EA/k'
    'QeDNZqPlH/PsMvbjXtj8xzpgeETEd6+/UAmJPeS/ljeJZGw1ry7UW5xjcxCS8qws53lvQR+LLplEtXFLEprcjVu/EceeZStZX5Zq'
    'nE2LHD2FmWQ6j0OE9nkG7xfturSdT+hYvT764S2DOiLIByZ/rsobK34Wy0n/aDod9dK5e8BH+kM6MZE8HKmAHmP9fsgmC+qycIgJ'
    'l3+rj6V0OV/CIjylqflEvSUCgPG9KbNx/Ono/cdX7ei/fHr/rlNw+qf8bAl3n8TkqOakRNfSYkFfZz+l8wmzhJH3k83cyBFYTtOi'
    'jFs0AkQHMqFflNMC6RgNvQG0IRH+v//H/x6B0n7iVI1TlnkZXiI9QyJ6YEdhT2zfi7bs/xEbjEaX/qN72x7u+nQ8zstYbAaTvBg+'
    'm+RjmgT4I00/QU8oZvXm8fIFbQu6NIUPdxKvgmKYn5UxZ7PRR+qPjliwl/m8XMZJkH0HrpM0UfHPxXRS7xmMCh8EUlIIN8wzxlwp'
    'XtmABsbfDJJFnKB0n3P0SaXa94r79x1x9k6E3WAQJKodMcwIaQt6a3Zs0G8MmaeyyDIiCPjZ0pbuVKfJBOt4s7Jups2UeMsyncVJ'
    'dd60fW7R1Vtt8VZra1r0umdbrOwxZcZwqc1T8fwPtxtfpxvDRQ9klLifwkYLqKd7V13WXXozBuN26c0MMvnS3LEI95o4rCp80yrQ'
    'ECcp2mY7ls1gBKZwyWomaI2APtGOss55R/JLLXqMQDabZmN1w0M4bwFoeeSnsTliOJ0UthUuIesRszLybl+GPclsaiubuMrz9w9d'
    '/aMUmRXFpyQVrZRGEahoi7/P1H2HHf/Bu6Ih+ZCk4QUtm0nxhDzAUImhScZ09TEKTMtFhqSoZTZaenGVCENgBVg8g19UdsUWHP9u'
    'KXJ2huRwhGyAYonxJbzABF0Y70H9lmWlphRm8M5J2XUTVR7jH08k9tP3Gcf+OOYPDq0Df06rdgUfSHrs3Ovgv7sJxW6Dp7+kyUU6'
    'HF6QlgkTpFUJV4TzovMg27JHBXNI9omgwMnSmGQ7+7IDUSvvR4MoD+hdIdkSDmIWnLY1nwl97B0Kbzn0yfckwcRU8ZuBS4yRGy9i'
    'T4vKxh2zMlLe9+a6aA4UvQ6awfol9WS2LlukWY18c7M5lqIaDolwQEQoeB09R0cvEIMrMcWiWW7qnN+1c+ma2tTtB1F/Xy33WuDG'
    'uPJc1IvI8JgL473wMdMFEUJkF9VuB4m7UVhBc6rqS6RMjNwA3GrLMiBWaJULDaxQrH4acgtXlpGBotMRsTDmZAnVScLpKM1Q7KXk'
    '81ZQj8EHjbEeiYU+nwhS9rHqKvRs2ZBmiWGZODMH+//xV86QOxEfF/2WY7b3V/qN+FDFk9DJupYUKnoiwMSwqO6YZBsVQHGTKErK'
    'wvp6/7Etyqq4G5t0k5NMyEXCsRiCpg2a3B/mI0kJ3fUQgmea/VJ8JtqGBQO6NsaVKjCXOrTPBEJRaIKfwhae5e+IQZ01TLhCsULQ'
    '450/61RJ553qdPNmlWy3Fw53nQF/L9j3ZgbntQtW2c5oFh3qvwAEb/EHH96INbGYzQWmRJ9a/ljvtFlS9wJ6R90MgsPr0MMz9QKi'
    'nsxUeYwUhtXWRM2tbsJX6sstMMNaohLUOLO7aVbdTTPPy6koMw4eRvIiD6aJnjwkflCiP4DQBBnsYSLFpXW637YG1bM33+EoDDMj'
    'SCWxdx+m4R3885j+efC7HZiFjnd/Rz+CdyfJynAV9HCrIVJFfb0zJojct6oKeQDnFxS4F7nVxJC+a8h6MEiB4SRTX3XZ9aMKdOIH'
    'afgKlFICqGcuZcLDHRsOgyYsWm+aSEzMYy0/NGEyYVFAQpuiD8PmcBRmbE2Y24Abrljcy2ZswLCvpKIwOqSBxCWrxs0wbrTzlMc4'
    'dGFlnU6HnuOUZRy2ODl/mZ+dwd0uSxKbzY82qJ/9GFONMTnnW5YsaPp7ENV3s63fc7gKe1HYKJVrTprH4XYVfRRHotSCUL4L4Z9l'
    'tvaw39S5ehM5Eu75FEXHdxPcBgj+egHKJ3xdWjrHqusbnz6JS/dMbxYJRLKWFgxokNHuziLv6f43RHe6j8WWOzBpg6uYJYsJfhdi'
    'nfUwBBBNA470zWBzsw1VAuNRgxI4Ssv95IJT2grHxuMSo4ROv8sB75i6aWF80ukvECsma/QzN5gzXWH15dgHnDA2wczAAjBH0OUC'
    '7/EnF+AgBplSZj5ElMwHHhuLH96S0HQEK+JAdW/FL3jTVFvcpBFgBPqFoxzptK49OdY8jd1CnTMOXzX1UxEVI6R16I+m/QuOeBTZ'
    'wyJgSnQNOh/z7IveJhzxJ2I2AEYWSBS85fqLeSwXmJ0YpcIFlqOAWNGl/9jb6MbJWVYU7JpIWYm+jsocSaSILcfGu+QEUDTcLX6c'
    'CzanF8ApgDlzTTbssf2dYAw/UGvxP7RakCJ7velVjJRV1Q3uRd8yy+n5VEEfSttLFRNMqcbsf9+RooeH9CdzZpuCrHqL8+CidImg'
    'PBKC4mk+vAMiVxhN4YA+RpGWPS+WUddTUd/7/8gubNxFvNhg6LbORtOU9Q6iEuh6oavEpLnNILoDrDUKa9K0vFRQMOCfzhZliIFE'
    'q/s9DLS/+jRqzg/rt2LdT0rRUNLOJfZaWs7Gs3IpGW68yGKFrSz61P6kInJJxrriC4k8I0CA/AT9tKatE9Uu+GDR5EriOlf2Nevo'
    '/cJLV9gISimHU1YCbiTDE/3nCW4c9qOzN27KaIEpEAJRYhMwmIlUIzlE5FrnzvQlFpW7cOOFL30SlVBqcNvYQJzXlDsWDcE4M06R'
    'JgYmDFFWAb0tL/WtVRR1Vt8ktzwgMsQl/7HqNGA/Np4GRTRVh43aqVhDJOfZmKSMT+qhEIiVcvU6udJoP+8YHKAAZEhHzabHYy16'
    '4hwWRocdzGGiiujTIxiy2LIouYN4Bx8f372W+XyXjhHMx9Gmyc3JiVkosXfR5t2oleRw1eRmw8DqS70M6LqYjLKi4DMo4+WgqVPr'
    'FK4HyzAbDeOoqX4dLVF1ZyBMFIK452t9RelrD2+ReB9K7BsT+oJDJQ3pVeaKgwAcTKqo8p9ZsLNJlgHFnzM1ysXobegVd8O5AkbR'
    'dfYpK62rSMF0vSKk5CzA4ovEnyK7oat53bDTRidetDI8KfJKuDIrYahKhnoz4BVw1nHPsPb1NdEGZX+bCzrQS/jkPcjQmymL1V+j'
    'Panvcn+D1HaGr/Kp7YnKjvC5jio1t8tPMqNX53deKEm/rkkrguY9ZU1hVFOC+q3JcVkJ2fXgyjKOFNcPTVtz1lHNuQ4gi1Z1Ppwb'
    'XbSKFs0Zyqqq2jJnrr+fzUpPVxkoKtsKCuHpK7Uvha/y0v5Ib3jlBBAwmKaqXjJU9zWrhG3VF3ao3naBYTEt47PJrS7ntYscnWFp'
    '97+9ReeZ7Geh1hzx4vOuEwOG2Gaj67tYi4C/KwSHl4+xylMOv0/r4rtIDtSkg0vFQpo6kwjNkmcRYTvYDL5rk7pziNlXMyiWGcKu'
    '4KhabtqwlU5wkT6grwYN5ZnuDK2PAfPszpRMbGLJiPlVxZyDaVStmOxcWMgNvpExhxiA5Dtxo/lEfat4qxgLVhJsORHSylBI84aC'
    '3ERqDfAQdFh4tGIjlywSzVHPsqFoIjUpMcuIom+s0l6e1wG7KNPKJx327hxc7csvtvUPlvtqk92OPjJ4G0lIdNmV3cB0cC4A7Jec'
    '0Er5P3XemdEiT+fYgfStil/KwcZeyj8N/GZ7A3VxDP1HJ3rl5/jFlwxrjUxp2YTNQAA4RdYbBkdAAd2Veqe7lAO5Zi4smJfmZlwt'
    'HOeMr2UAxD5wz8zbaTQkoZ4K8KbAPU+bhM2FokQVhBj2uII6Drl7sG39pDN8HL2bAQ/q96dMrfMTcGfa+qaD29XtC54/5pmW7D8T'
    'kMkIPAjowfc5WOUX5Xy0uUMVbZ3RdZ5xvPc8+2VB3KYht2OqR015ImSqnwPbjXibRTEJI2qGh/aYw/FBq7wRatdndK9B7jBZWQyF'
    'CYBKq0GbVnO/FnZU89cQkxWgV85JsLZHvuZJC04wzRnBDex5GgGBYmQ23T4vuu9ny9OnIEFKF0Q5wAniO9/VAtCc1UH132x38MLS'
    'EgdtxQNry9mk43iS1AVlsTDZO0gHcxgdQ1Fr7GG5HxsLomW+czC9bc0Ih0hayMX32RSx+9jPIC4upfZjzOyxQUeNuS2PclktI9Xu'
    '3hmsHDpVF+zZBIWh1Csqf4Gupz7Kfdm1f5rEh+nojF1d2VBkjrou/EAXwp3isUjCWLUzML/8paSvVkAql/GplunjvB2NkyDpq1XU'
    'jhMJnjGa4rri15Sw0TVaubS9unb/28tazX7bMAPtPXBVf//sXcXm8JgPT2Ci4Wsk3aH/0ZLPZx7OwzNzBM5SOsrY/3SciRWe2OvU'
    '+CUI3RCzoEmgKrlkWcLxguvsTW4akUQZ0RDYfRNJHTYJbvxhiut9tGTJAVb/y6m9hQXoDxT+fFpKfg/v3rCXgMNpVS3aO9lLgJEB'
    'NGq6Ez3FZHmJs1hQjlPo/9NdTXGVIoRqzDB+mFl5tqvPNt0z30h8Yf0DlDFi4PeL4rb7/nxmDD82vTNIFucw3KnZToS3rJlNilk6'
    '4eHIYLFZ/Jao1yWUmUCZSBFqiOJsJbNWpws/u7TRh8xnmB1OJHE+471rf+qvOJzvw+gxQkkfuoDIQLM3N3nl9XvaHHu+wcPaKNDB'
    'tjNEwNTiQDZgATxgml63pozpVoOxUN/XTCpjW4scDeG8oTzTaaETYoukHOhID52HYwVQRQB5V1ivVTn2DZ8f3Ip69pS9VBY24iEw'
    'cnIQXu5tOHpjrOK6/S9ckEwThI2gaMJJ9J5HNcxWKcQJDPPt7d/S7N+yYf/uO4wx7U07sMMClpjbFCiPzkOv4eDVjrWHQoH9gygg'
    'rFFGOQZwxqP0ipWWyvwU09GX7L3yWB7rEILiRY9YnwcOED6Q7E3HEHmrK/CUCVfQF++wRiEMfFGb5ZXFiAdbjdLMVcsj8NXL+kFm'
    'xtqTlzoc2RnvJt/mtK03x7M5UcnzLCS7GgbdZ1lEWc1ySsw3BCfJoZWyHpmpKqfpArzj1JkEFGqVDVTIG0m0AsgHYHXMNmVMN989'
    'wEYRFL7JxNMLzzrR98IPxciKiSilxOs0O3fNBVQx7THHbvJo4/62qSY4ZSZUoJJTif286OYYZlfpOUsPQxrRkvhl32nF21GeMDsu'
    'nPej2Whj65T1BNZdpyJTizHDOXDaWp+T6nQ6ZiXHvpuD8Ex3KjkFmNdTLyFvF3my9XntRvAdSXzI+LGDjB9D073pF2HEU5P5WhxG'
    'ErZwe6wJxyFZkCAmAAoUxH8znJWDY2VoF/mG6GRX5yPmsokm3jL5p8weOICR1UG2pk3uFFKl86nQ31eJc5cIclDGcRr9m3d30B2B'
    'ov7v6vt9m5z5LQPmgaT4h8YcEe9cSPrUvpfttLBAzbLhObHpCO4HS1OUNrHmoaMRkMxUcqbYywz7uumc8c5WVGrpCVIuLWaSor63'
    'lP/izpCmhZeEPrnj5ZoJlKnHYyXkvvCAr19NWEuzEtcXG5NhfY/fxTUkRsa1qwAxJidVejkGWaNT5FGz7yoeF7pnEs73yTKkAZu0'
    'J1Ng1E2XO2ejtPwB0RHIPdo7kctoOqNepIIpPGaQFqO5lVe9hK8yEovkKwhH5s3Kj1L3UY8Wjj86PgnQW3jj0AXM4hAy6lg+b0GS'
    'xzGrFZkSSj/paXgqqQCzLVNzgOlfLo+Dh5dLfqlH2r5cCpyo51dSxVKVDZg0Xn+7ewYSVrUEBmkcO0d3rvDUdMBr/jPBhb5JFfrO'
    'OY8Mt6SraQDqrP8GnfE52LCk5vVifDpqJcT5xYbi36xMUK7gpkKzFSTPlvsZYivbiOnPWtmfvemgQdNHdJpLAPz2svIyg9v15TSY'
    'iplFjT3OTwQZV3/+fMJA+PVkYzOXZWwmeUFSdvWZi7lwDhP5L/LL96sxWB5fv1K1T/HRJsryzydOPKTnW/R8pQ+QlWqp4L1IS+Ov'
    'Hryh6I+BZcFx7QzNCIpf5mXsQ1K776XKe/LfKu7d2Lk4ufEnpjQ1RbzU2Pk6xW5i/DKr99MYNTOqmvcl1yo5h7fMS9s0vfQyHrsC'
    'TV9vNn8d7MGaq1vRF7fHlc5uU3ZSlqE4qY2ZWtmP7Ig6q6Sqm7rdM3WdfWJ2jmIHr/T96puVlMD7WsXmfjW1m/uXwcJpXPGU71N7'
    'idNvZAjLtu4H3l996hFPANuCdCaKvnX/moZ+X/xU0urA4Kx9QJMhFDNxLTOmnZd6p9OoRVZe2s8qeJrMgqN+xxUxC86PlJTWWfCB'
    'z4OrSwlLUdUsUNeWvXcs+cDnydUNQhhcucbpxwiZZQHSWwNiVow8XP9zu8X4LkoHA+mK57UNQw1Ji2WJTD2TEc2CJz8WUcwcC2si'
    'TYoIBAifFxyKkZdJNJjnZxBWWUEZJhmW9G3fKXIzywoShGKdha2Ng8sOwIFcDqx/Qm9KdfL1A3kDFhDxR8rgJJX3O9EPAY8PrTSU'
    '0hrpEgjCRsAQRqdHnBRx9qyq7kTPrCOT2gWCGQDtcDLCd5y+DpDzl6kEMGgSYQgTdNpkNH1MURYa+qxs6YkJSLjLnngNMr7DBvW5'
    'nNAWVn5bInBan6sdj5a0BdLH/bza9f1q6fXuWj9b2d9qvFkvZEjDVv0CETZAQCT2+SpIYXW1KyU2vRLLoI7lTjuETESJoI7lbtvC'
    'dpgSQZofuKkUbV5qOCvy0sDYiKRc1Ef68Eo0d5KeK2YkoqV5NA/ydF3tqmi+3GWBXAsNrhiVcrB0sJTOSYKXXgj0Auu26KArSV0u'
    'REFOtismB/nOAiotTEjvgraCe24CReRj9czJkZnCZ9v/0xl2nmCzH32OWvvByJpsqNYHkg6NeOWYx3XslzvhGQFjErzruXcuY+ud'
    'UVGN0fPCrP6WmZgzX4J1uZYgyrpfTqatYQDv7lUAgFX0mHKSu5GCuHrjNmq61KSHIKoB90+ksOLjJHFqgDbxJDnWakBRXcOxH61b'
    'MTqqA4luOL7gZUJAQzmV6G+7WJpbRmOuRVzhCW9HgoMavuaYMwHlCdQFmFXw0ZvyV09wiNnjfeR7hLNvfw3dWBFgDcYxe2IzTKA7'
    'JWbxxgtccwygx8mHQ3qIW+hADwVPvj0Qcg/yR8RSm53vs/qafTpHdoP7O/xXPbPF9+A1zs6k8qlXOfsRau0iaAk/iiy36jlo3rKk'
    'JZwo58C9sTD7qebNK3OW3G2SVf40GxiVuXfgZXMZtel1BYNrkUYHwWFrRxxw6Z+d/co3X5i/Ebnx7Ox40TvR3DI8KDxJWXHzhZke'
    'ESG1nKSGWXrlljVh5Qt/yv5Pu9WmOYc4LCI4QccXJyY1iCv3vbQOZoj6uc2Sxdm+PmYeibrlP5be10pLZ4PSBiUqqaXK84RA2Vm3'
    'kgHDoj/7W8mM95nZqyzkPbe/IOPxMjzv9M06/CzL8AxPZH5ztwxUbunKLaXc0pX7dctwzvmJnjH//5z/3d3dQRpjV5Bd2qjYUygK'
    'rmlG8+o84y1W7/6+vA2nO3j7c3VFq2/DhfXe3gTQXqtvw+ug43f0cvWuhkC0DGfqe51oGUXSZl3HmEa+9xCQbA+pV2OgsrlqzOKg'
    '1zoz96KLfbsY9vmSn1c2XsCW0Cc2ZYrVJ5q0RKo+ZG07fERgcJZcRIZXHuIfIiRzzvwGEAZig8VhY86O3pMFA2DE6Yh48MLlRGNt'
    '+HSiRlEWClwGWX45z4rFqJQugN1NmMs27m3IGgyeF+HeIi5Qs5DJTN89lWK/f+mlwxJ62jM0ByTAaG4laXrcc7/4nSnpaYQliw1f'
    'BuH9UGTnzTfzsQiKjuwFnIe6KztiF7xdWrm/V/2+53/fq37f8773rlyPSbfTBRJEgpA6yUY7K1M4YIghgbq2llb+eDPY3VSadiKn'
    'kqdp1F+imXevlsGrZZ1CVkif34VGwncsi53Tf/LeCXsQnzMNPJ61o1/oIcI8fzEvfj4JCU8uqXjyGaiX+fEL/+j5b/THL3XdhUa5'
    '9S/drrsXuZ+/QP8hbvl9DjmlLqWmiPzscZHELZBL/XRTP8ZuGe9FD+Dxv2lXg7kJo44YmxxPVUWu6k98xaxyDHToRABVZ29uBQsD'
    '/0XJXWZ9k26T6MuuaTmHdx1vO/6zsIyVhSUh/k4AgCrPmTI+AFGkPSn1PNFK9LfbFCbWlJm5Rs7NV2TdkdpodStEXM6fBNvsuIQT'
    'xvTEqkkAx+517v/+9zS5Ug9S0f+uZr+RpGN7D7FMv0cMYCyl/y1yYJJ+q07TDH/Zexqc4bTL+tT06ibQ8QvHavhaYRITgfwHGYvp'
    'vWd076/J2eV0YXRpWA+ClVciiYhWlcWX1D6eLL0nS5O60BP0F5DzuU7RX5lVqOkCWACtqLPQYqDQQoP71sRs9C5djZPz3KzVUTNw'
    'COxEH9QZl910hmqfTnnrnp/DNY0dszlGghVCQ+QQ1EztXLxVMHQLxwd3vmNfmAlnh5JUpC56ybowW//oO42xV6w3nwOP3fEWAdiO'
    '89ibs5AIQxrsTaLyqbrmHVvfvJPE98j0c1FMf30tVaeDY9xPJ+J0wMEJbtUOIm/FDqKl7+hfQgkzy+bsPT7pZ50J0BqI1Vzw+Xm8'
    'E8aSM37QZfVGLn1FDvwEUWaL6mad+GJO9WUSGb9rgoRn1Ax+0NreT2qqKB0RhK5dGRMSgYVSnNVNKZbQZJV6+9j4YxzwzHTOszK2'
    'XjARq6UOIlYPGa0Pjjo6vM/6poOIFUWx1QTpy+CKMPEG5pBrej1sxQ67ycKUKU6y2EUMCPQ9nseYVv2QvcKD3auEX59d0zRAv0Wf'
    'ddfVVglv9jev2/uoM9CsYPlHlepc/7+16bgkVgmVv6vqwZu3YGWojUgdAhBqcD9ZCxZJyIIbStUjvhKrdKsYxap/7AGAr8JHrLYa'
    'ZGfQWdejmJtDJVTNr7GhRSuSWO6qkxfj4JQuX7Txo2wZx0b7IXh1P/7Pej6K/zl2kAkYbwzRBSTdaGTmc8DQvL4XOfcWeLz84h8F'
    'aZlYN7fERXC4mPjvHCywQDfL5CR11wDxt9GoGCzzuOMv9DhYMcaOq9Vtp3BN9Y3hOJ6Jh39fBE1frGx6RUSvT/fddjmT2eOd8m7B'
    'sQ6en5S1WHDMivqQwz+WrTbpFYmMEk7HMh28pNRdfz9q9uLvuHY83DC+Tk3utjBqxm4xSdUmJiJk0jxL51swv9hi/B7eXwUc+dHO'
    'LGWPgAmcAHuIwHLtsGcLibxIckQdkwh0ZIbzDFEID+5EH/ksQzQWnzRrX8J4Bt7O9tz1xun8PJ9wFrggHqnwvevbNsObS/g5EaQZ'
    'm9jPyyG9LrNfmJ+vKcdfPb9f6CXCNiM46C1ZzYv0hrzPutH9+/g+/qth+sI0fntJUM8Vx/Eo+/0Liv9CUjU12vB8GWp/r6MJCVFt'
    'lIILYzdAALlCNNDVbjdwYuOHy0rJJT+slKSHvrUETBqvngnpqFCP6cpci9MVuRatdWoqGlLJIGVc72U7tKPhkB8PK4/Vf6gaXDrt'
    'OGNbNa8t75zQPj/qTJjeTHFPjDoz94PdfiRGVCGiHH4YC4CG6mvWW/XeMmzu5XRBpIxFQw0f8VqdsrbikriNUeeKPUCmmvbvKZ7s'
    'yhP2VhhyoeWOebSFRygFE1iVdeIluhLRkX0wmnIy/8JT0ZmVRV09MMXHlz4mzC9WpU5yMKocDsPXRqceSvhU0RN1bqGv8OcqXQBK'
    'UhlnvvwCiRHz8QTHgOTZLQi6nNQEhQGDtx9CBH0BQpD9Nb6iteJZ+OL0lDZtWdDGkttYVtpY3qKNJdpYhm34uZrvUAcAw0kFa+Ou'
    'SWzYardxShiHMtx46do2B9PcaM6RXQkFF6iEgYZe0aJ83n28mvYGWorAavOwarVpJBbNarPJLdX6kxU6fefCNhF1fk/+hC7/PDUk'
    'Ro0w5z3zIDDB+A4mRq1pvEuM0jMsyyeF5oxjec57nUsD24Zp9DGV7MFB4aEUHq4qvAzAoG5ziOoLHzhq6emiHU49Yd1a03mKupZi'
    'uA9gB6QeNXykByR0R8JMK71PE/1cf/cS1VbtdB62o6KnImVhobpSMWGMoa6np2LKwgbX3z2z//G7ty/6XPO+V4VBv8NzkgSgCTWg'
    'V0731ADu+pJIOuNIs48MNjEN7vHOzuxKAtDHPfj/QtEPpPLox49vo/jDuz9IbFMuGhFJJTXPiLFbAuYYrvQmeWF/mXS+S4HTHHkn'
    'MR28wTcxMTQBMuliDmGFGun0qVCZicmZfktJC/DsO6aMz/ValCqNeCvprKDpm48UIeUyzbl8Z5D1pwNbVI8+bmO8nKQ0jelIAFpo'
    'KzI03GQYvlVIFvO6qOgWaAJpx1vmYnKJGkImKMjLu9v2XduoK7TOie+92FBoKIX2K0AzxNcvYAzRGXw1YtNI3CKe90taANS4L8Zv'
    '3Hz4MTTRkMOgqpITPkIP8YKOIGznrb2BydEGszpiYWXKaV44YdqOZOENeUauhopTRVz6JW2j2Cvcwb7yQsRGs2FqiWhIQO+rf+yV'
    'I6AMWyN3yewK5vYnUKfiHjEVCVR3jybjouaJQxukqwUPaazlFJ3Dbmvxlt6eTc5bIBYNr36eZefILdd5zGlgbfJhJOSa8EG45n08'
    'z75ML7x9TLsxEUVk5VAUOj8c2OjORfN2l61cOUdOr7NSEPbhE+Rmlfro332nKVihJ7D0xn75Kf+bRZ9pcU8Av0QEA3jnqidl1DF4'
    'wmhkuhRTTCXZTzcWeV2resHMJNA6GYBSotTxXat57uj0c7XvcKotOt7/F5PYAMp3zdXfJKun8dePt0rMJyzGMtpSxqj8q0DiLUpR'
    'XrzLLs25AjgqDS5VvCEDAm4wlKbz/Lyr+wNt6NdE5ibprNsEoC97n0UgqVh9rVQPlXiVcWJfLmNQlKZz8Smy0WUo5r3UMHWPsfI1'
    'mXTA6OLhlVd9qX7Gqd1i/wkdMQFlopn5iM0Z+80rUWlHDQ+N24y1Osu0SIIOXJt4Rp3y+c1q2gSnCbQ7q+oxJtpifd0JPRob8HjF'
    'Q0BgwDw9fXBpIGtYm7MYJu3wzpGw7L0HbQH9vxddyH0Ts7HQmqmk6GzZjh5xvLbXUt/lKKtmZTyUrGVdK8jCY3ImjpMj9YuketSl'
    'TBDbzWowHljbMtZnZTc6NfkvqKmJeDmYrPE3s6tTBCjPXCl0qL/UQkNbiOvjq4+LXsqXcv3xk6E8geMdKBs/Q5JG1ORe/aQfIFGj'
    'FkaH8cBlbJS/OEejpDJoSfOYpNeuRZ4MW/tM4DX5TW3udTgYSvRYh3OTNKjQmVCJnjwEo1i/93D89OW+RxGM2rt6Fg3/HWxc2bJ6'
    'yrULh1HWAUGhqQgO1jyTANvtz8Xm3e020qQYrYvcHIEoJSZZqrhDdGcs7oF3giysTLI7TKhc6ske8bBTOG+DPxR0SWDviHJQsxIU'
    'bALk2EsB/XBucIknnIgl4vrbFojAYGAFVrlcjTZubZqLaqKIwF2HxfqJoaQytXKniMD/nViL9L0/Y4eyMADH01vMTrPOm+RD4FKM'
    '/m8rN3tHi9Hc14ol7PQbJKfIOrgvvpU8hKaDpu2n/CL/mJ0VsdTW1gaSfU+udzSfDdTS+6RiytA9Rifp1Rea6Ld5UWYT+q6VT2aL'
    'kji2WI3SAZ218+nt0CBTCNW9subeaDG3FfvMwrqPLrIlzCn0XWYUtzRfRMY+0P5Mz3lvucFmHSovhoJXJK3NMk4Vn3VmuP0m5cvs'
    'LF2MBBTLtW+ge328M78iJJVqSUo2SfTy79nyFtWuqfIo7a3smIfk6Ca+WrFnlnMQsgNhgmgyKmwQQwINs9EsmxerGKBy+hOQjeNA'
    'zITVGPCaJJM8hzBFnXnBSJsf6TYybIVzu6AhChDnn+Ax2sGVtBK10xT9MxcFlEIzZKdHtgVO1maF+GfDJdaADF3/KqD//4TwCa7n'
    'PyGEog5S0fOgENUjHd7ob+HdXdih1ocg6q7emiE4VN1VESCiIuut6b444PVWd/+D6ucv2BhTJKGguyuC7t6OcaxzTtuTi6g3veQo'
    '10UpaF25A4sDGzrL+7R1WcTylvsXdrfxjDJ7OyuXWXTgjxpn5xeenUeN8yLK8UeNM/ILz8ijpAkS/Uq8qVDFZTeyQS3Epqk3gxwY'
    'zM5Mskd9z9pY5Q48/qcMopx8rOaf9Mh76Lvt6HXwUHU6W9EDNiMETf1kNZOv+S+VByCyWZitJfUv5txEXpLrMu0lcIOACCpKaLrt'
    'DQKIbcFnx5RG+AqlzoO2m03g1bfdS6Tjjns27wYGxQ+G+kD5B2WfMRJhx+NwnxN76QQJ5aIPuK494wrrNnRQOMjp5pE1QJnSdpvZ'
    'FET1zCUm/AzqrDBriX7yD6YtCUyG50EGklnH5SvxrW8PKqVcphLfGPfApSip3EUa36dR1uArvUCayuWEjYzyP0x5UoRR5P10HUn4'
    'DCc9vYERHVlAh9NpYfBIqilEp57TBJhWOG7H6vJFPKdUdS68fEUWkFIGkjUEwhU5ualF/opRHm6RHccbpT+0ruuV4CqXyNPXH5Ec'
    'CA6J40Vb+DaHAs7y/+Yjq3J6wWk5G6cliolRYoRE5teTViW1Dj/lydKbt7IeDb0SmONKx8JUin7+BLDZvjqAOCI6JNzkzKdSKctO'
    'pn0Jc1tf8+mTGW3UaHCw8cPd61SSQqad5U309u71TH7SBr5ZmZb19asfXn06pnN7NMzG2cmKLK0uceYghUPjPF0ebPwuerg203dN'
    'GuXxGr+4wCExGLHz7ZI1MWsOp0PFeybay78O1HXQUUxEE3uHDd4dvcyE/gJLDRo1RBkD0dEmj5MA45R4KDZYD/Kzs4whNEfCQ4hz'
    'ip5rRvLFFcw3rcHtEX/oIi85K7nAZrlQic7qdA9NWOYWidnq4eTA0KAN+LiiZYNvVnmy5pQWmbPxloffiX4sBEsJPifE4k0WfChE'
    'NzucXjLu+nR6UbSaqNp4iqyVIfXChVmXZzRJbVWmEQFBw7whLe7c3u8NzjcusWfNubVJDp+l8ofdP2aTWR4qIKbiQgRsGgZhhJIA'
    'H1ScRrOOINN2uEeY22PO2ktLZewh/l4nQXuzZKtGkZWS8oIprH8phcjm7PG+qhWbd/rEUcJRISlJDb3fHBW2QVveINMzh0NvPsgK'
    'vUhnYA9pVXTJ3gwawbUn64bOkPFehyal5M7EntycuNFzuTrQO1IoSwJQxm9vaH2WMyDNqvaJMnuto7C0X34Ppe9Res7PbDeoeGMr'
    'o4tvTLw/5xc6RB3J5ugimPPgSK6FLVeVS3OrwOE98W9Wb2LpOJsWUewWAPo2b4+Am4Fid/FV5W7PGeYeDnpTp0Y+Xzf/7O/q9bNk'
    'BVDFDXazPHdLwK8a5+ObZ6zNvmxOkm+Le3f0Mi3VFbxCXledQVds0Bupl/gWZ76BGbzD8bgPORzHPsvFP1Ny13uBMr5KwBa+Qm5S'
    'J//b5wxz8kjc6uWR+El3uR/iO0B9aTPVJ4HIVs5ykavSWlnos8DvbOCg9dXiY5IsVnLlenoV5g5nppxJmzJLnGjDDoyFprHohsAW'
    'DcQs7AnmK+ukI6NVEmzWUbnJvK2AcHhsm/HnxM2seGTEnHznVKd66TXvdyln6aGXloNffJsAfnM4ZrpXdqaGleGUaoDewr3erWLJ'
    'R8Lo815YcrIRCE0t2Qc8nC6cHcUeB5gFRtnjgIu8rYCK+t/lSbLGPtcWv5muMf+peBV0yEQN+ZMaaJWrfaXLlrpahPu18Dcsgou7'
    'KnoiCrhrJMsbu2J1vp+qnVj2Ggtxm+WDTLaWMcH4q4yJYw585tzRmVDyqDIueNbBVIjuE7NhNokVtrnMF8jZPr3gp8XVvpOzpdzS'
    'K/dnW04dsXwxu5GLqNLIgQGuMhVhPzl0fJZwvRfLYLAd8bMKad6AP3bSPxG1B/6seB86A1EQjdHm3HkcisGFjeVAsUEPIkyVBw96'
    'EGFOBkEwEEgo4+/A/4oTfLyTtTDgyE2JXjwgeU505oIaiI9sIWCReOM5rCG5n5NBUWul4SFrgu7Y9mEGsToO7oHJtSyTMZ0d8Z0G'
    '1xr6lIrTf0xqZddnk0/i0LzuNsWaJJ6ei56+pI9jT5Y3W/mwI1u1GvikHa3sbRMFRF0rzU0XCqK0NvaBnn/1zPmHRPDg9q+xzd/i'
    'lhuPot7neoj2DZX6lhAfUBk+znKWsTZChTn2c9CpOdfJ2beLW7kfVm73hr3ub3Pnm6TJSgYcUeca0hnRaf+YbaVlSaJmNnCE0l74'
    'zRGDnDBp4G+5O1b7g5v9b5mkFAkLGX7A5CwxKq5C0gAWXXZXaUleeEhQbEStHgCzHBUT4eA2JsI1gUtrSf5iBoIvZ+Vb14Ns0VuU'
    'vxxmUs5Z7Wq2rltJpzSl7wFc/EPab0NXuEWH4ZxITtGfI0MbcV4z4NfbnGhUDnfAPjDJBOaSOLgJQxr3keuCO5YAPf7v/+v/tSm1'
    'RH+bTsdFx0uH1Fd7Hz4BZyK/xlmZKpumV9cW+JdBNirTP9lryj37837jdeQR6W9Y2NrirVu3q6lXbs2K5k76xR58C0bpGNBCfAup'
    'o0p2NYu3TAfht+tGeSjwN3DI3dnZfQjPStGi3w9144ymGPO/xrp3Dw0aw513YzMyY8z/GvNeU1Hs54u9upocbmIzuL18yZQpi8TA'
    'uR29ZAcFcdeVBEGGtAJkWjIPOhwn0VoYm48UhAc23nSKWQ6oODi2gQ5D7OZkiUIU65sbtBMqR7u/Gy25jVwbkwchqDySdU0w2p21'
    'mK+i0K7GtdVNZ984jbdowAuW5s0HwfEILsxn2RxBVxmwhy1/dFa9Dc746hA+qvgpL4fGSbRVsblWWTThKAwToRQeDw+dO6gwBe3o'
    'DI6ogaMjB5hyNNSZz6yjR9ufO3/LZ3e38w7QmqmD8LGgziwm9Dg+SzrI2RPnYyQo+iPmKemwS2KczecCRIxbZoP9EsEeObfELyjd'
    'jTbAqs7nRDmKgvoj7AQ3j032PU1ZfKZsS0Wl2J/OiOxw1F1Wd0fntD0vUCg3GDAqfwb5rBryohEfwz557D1WtCWrYducDCDuIdzU'
    'JkHydLsGGZfkzaQjPfij9I9zjbLzu0YXmgyfYZ/25aNPEPfcp/CQR0scMXiZFl4GNzqLALmppv5y6PCLXiFuikUnOkKI5CifCdAO'
    'kYqpZp2is0w1TgDXRc1MFyXUO4xCYPtrRgEyIk0RGeJ8nTJZ4gNlvpVpH4hwjsUUWDBbCePZm/QpdK3Ipn7x9s2Hvx79+cMr2DxA'
    '5fI+33nbV1tCf7Y0p2Jrny1fGIvFBsGPI/G9Qc5ObuooH0uSsxAaARvnOQ+rFl/dBFHJrmgkCOQDP2xOMobNbVS+U3ci8SJL9p6U'
    '7SNMkkC94K00eAFgTripAE1tIpflHKgWE7kk58CzUHPaZD9AlZMdtxZKjyM8Gf/wzoj1p7ijZRxBWsfqUwAhOuzEam9Hir8oc3/N'
    'WTi6rGbggbe1ZzemkK6Jboz3Z2ayDMwMFQmMPX5BgQDbCSy9x63PZQs+f1lKrC0nWXG+vr4v4L3PE/pn+7wdtaJWYnzXiBVv/f0/'
    '/kdLcnR76aB4xAw96Hog6U8GHLSTnAieYOvzpGUCmN/oqdHwxbhMewUuTL5UCzUH0W8D3dqjfYgDB6ibxbiXzYtEs/TRQeMZJbJg'
    'D4UX6ZvPkDeScQfZmc3bqyaotzL8OQ+cxl3QMSql18GeGOmMmNQaO23EonlwlJ4TrrXphqpPs9OPT1jHZFluAfjHgy6JLjxHUESd'
    'GKLH3INDhvSDTSXmOow31TPJ9Yi1j/hMvmO2/4IV5hTVbuSlLDn9X8tI7r5KTf3zuBaZAfftX+LjrXubf/+P//73//N//P3/+H/+'
    '/h//98nXz4PN405yknwuNrd1Rs187e7sGNcXsa/HPGijLqBzJb9po27topfR0wMdR6Kv2C8z1PjpPV4EfZcnCo5sshO3Pfwgl5M4'
    '6MNh2IXdk8gkLdbE9bnD8C6cNOWvWhIqh4iFLmwXw4RtJp2lkQWd6XXmIS3tWh1ugcuXUxrOZMW70Xkq2hK6QfWWgxrXwEPgkpHr'
    'npMY0qEqsn9w7mxm59r8scr5ph4ILW5RNJQkKl3mznxQiSpvpoddPiSCTg19lukE/nZ5sFE7NrNJnfrh2dtXR0evlGWsNGEKNzcV'
    'Vi95CocZHVElNHEO1dWS8zAbIGu51/WOTRwTAaxr3O2SoIxlgJxkRVRXQySYkHA2Myl8mZBIlH9e8H/j/qFkJk5W0JTe8s2Aj2fB'
    'QKl6vaGDrzRNcczviI4fnwjRvmI19tUhz8TViY8PPAg8o69lnrrcSKwpkhM7bfpU7k/aAW0J0nBXvn7hQBI2J4c2aD4kiZVrWZsK'
    'zgsq5xt3YusQYB9ug2GV9VypPq3fmUvmrMrEVfaFFKvuiWqHZJRmS/Y7HIWJVvzd2VdvZn1sd9IHPoO6k+SYitEtitGprnC6mDbP'
    'zsOipNOW5gx5AW6WwcknyD7KmZrywWCEnHUIkiEe6j06poyjnnqHbK5tDy3DCYx4P7MRfSYb0uTrbdtKpU29SlkT4HavXYx+1Z3p'
    'nRqztL1lVlozaJBvmYTHolAhRMRCwZvhLvlyooSWmq3lPNiqy75fpcB2cg69r1eQY60D6VqoPSeAepR51UBzN8tp6almvYHcGjGH'
    'L4NA2SmqRM2T7GX8NCg6De+Uv0D73D9RbGhyAZVWDCQQY0f4PL1BHYOJ64I52GAaOaWcuSHHqXoaNvlCG+ohTgtGF486E+b8SeqO'
    'BcrM99BJ1lblzLB28aXCJggQvuzQ0rm2BAQ+SMRgyhk2OuTbJ4kYA8015z5V7Wx0eKh3n8m34CWRZ2i/2XKfJ0XuUvxuckgeyZiU'
    'jIrts6gJHPYRp5G/rg6s6tbU5NjUMMiRDhLtuCFqu5CW/YfwJbNXr/jLtzUXnbdRD9xGFXrh4asd4wk7vz7YEXIivslyX1sdSlhT'
    '4FEeVzyJ1Uu2GhGgPtJxzcXYK+6FBfhmjmrj1j18LkASc3YP3xHoUOiL4SMrQ4Q+lsOiOQwakHH4m/tCwil8yj2boc2CVj0uHt/U'
    'lNBNVoPTQNAK6fl1wvfEZXDkoO7SszY1TmuQV12M+5JMHZXO+1Umlbl0eiwlDDaXBLN4pEGfEteIG61l4Bcs1hfYVx+AYlKtMPFy'
    'rlsH7K1dlkKNmVHJN2fPGxuSwhPALIc+l1rosCpe16bDceYdZ/vEBf1OyXWOtbTJ1l2q9f1av3mk6HcxTGGbjlr4vLVvErxDJNX1'
    'Md5BmvWE87s7544Ica0HxkPfZbRRkeAeHRh12298Z0FIfReCEJuq9A1bwQ6QN/tuVjA+V84sCWiN2KwMm+BtPMWxpqEZRa+nx/P1'
    '6l1G8WI4a7hx8oXJxVrIzT4CJFhMZUcQlYeLHrOAhYVD0mlNOj4aTmyX6sBbLM5pAIy2iY/RhiucC+vNkxevFz24CB/y+F7wq2B8'
    'EQC7+BOX1bU0ibveZYwcfEw7VBaFN6sM6CQIJfRAYFLJMeTcA1LJMFQ2ZRhidQfXd5u0nmGOINuVpjtoImh3g8zcz6zDJaF7OenD'
    'XZBByRGeZI35+Tw6Pub75eRE0txHlt0pkLEHem8PBFHJlpXBkiY3nmqk4QqkvDCm3wtDLzRlhbBkfPX6rgigS8yKD+hvxaWjFT3V'
    'Z3evvS9uzFhOjfLqyFnaU5Wqz6eGp+562mnipNUMVOHoMaaJYxONLtuoc0UFa+y2aqJxDmTC+mGIbKQYWW8FJ08uSlXT+gqvgk+8'
    '6Gz3PYMk8iKv9NqocrfPjJireIIp+y0CnWjiJYvtCkeVKx68mhSo9jJLB4arx34oOk1OZfj4iNvzNM6J51BGewEqasAkiinpk06h'
    'Ta5xVhr5ZlFGbI6KhsielY+Qiq/0Ffq+EnWwEOV5tnbmvF4Vhtp5ItOIIc0FiKhgIoJVI3FHqWvbQkB4ZQrndnETatx1JoB1ECgw'
    'J574o0u2FSFwT1BkZau9g9U7EJJYVXtRk42h3/UklZY7Pqd3rzGJdGZeLEq+yl+wDNe6iTbuXqO1G/yXCpyyBEd/m0ODx0/lvBX8'
    'JX1jbDCn8luOlcnuqkvy5nwynYuTriS2IqH+1ciEvlNXTXQ8/qz4rR524tZv1PTEEccilNPMp209akSbIRmwCjrntMXsR2txe+pG'
    'TqxD1Xet2ls4A1F/zGa+44Im7qCob7Js9lhgk7tUCagbUDyG6rHmnXbVsZDrXfstsx7bRP9zeAoau4LaBdcNmCO1/382Xg5fxDn9'
    'dxFqNYZtzTSIsP7tiQjcoYAvasiTM6f52jXgeB1Ux9Bm0ze4hhgFDsXsrQq7Ezm8nORinbHbGsRXBYGbHE7GuK0m7DONKWfzoHcT'
    'M24PP/HgEaR759XlEiKCL9kFwUDseCpwMSGEn/srJjW0nBbJKD25B/w5HOWMbs2ayQ5Fo9atoC002H+6ajhbtScDzZd3EbOZ324d'
    '6iV1LVD9NZvaL7KlGI1XxMZP0i/Wp3PFfdOQzWHQlMdhXbx5qBphBrZJNcJ5iCTCvLD5hiRSvEBeIZP49QvgXwYQ378A42WABNvZ'
    'fGZTcAO8kouwbw4XufK8HaUaE83LXz61GWB3Ow+bO2cSgUrBTfnunmRrM4lDUeIJzQ+nS2DBFY9ssoSJw7JAeTx1sR2c0zOE3qpy'
    'lCZ7wacx3ZlDVq9OOA/3KOfs8amgLIPhLzynIQEyno5pmXDZcBRy0Z/D4yFmYmHse0Nwz/1hTiJ/R4mVuKvVTfEh5lKFK1iR7120'
    '5EygG/w3j/tXyHcI9QzgUw475dRA4ENodokFlMUa54Ot1KVxSPMx70OTx4wktyExe5KVRFq4dQB4m/MyQTXUm5Ylhyq+pp2EcExM'
    'UdFKOtOzMyJhNl4cGEpNSEysK7K4RXHfB08QvCWOrw9KbAYlXF1LWxfDLfV9AAWpa7lbLbEZlPCU13BUAXM/msIHibGFoTi9YmZ/'
    'mCN0ZUqngp4gy2wO7irGfzalkMaEU5lNKi2/NQP3NOohVkEhvRUEuIvqnmhF+Jfr76IlaeRQm6IH3chL5sCyKfeWdVvAHxgjlJ86'
    'laigKm+XnAOT38qiea77AkwLGveNNAKBe6bO1JVdH4Q22Alur0hJ8U/nodjjEP5vJaGwDouF+Msj2YPnm1iI0zw/rcUOiEjujjbn'
    'gKAVWJepoRsmevC+XpstwnDWEvv1nLHuDUwOpq3UqH862D15iUhUEvA7Z8CK/h1AdnGt+bW8EYitVfXk5vUd+3eQEMGrT6AYwBE0'
    'VaTvxNE01t9U1Q5Ud0Rit+4zKFe98jX8XAPmTzO4D3asrYcmeL4UEXNKlXQQw9slESM+FonkJGE3wyBeNvDIFaBlX4ixR8FFReD9'
    'DMiMQ5KiRpnTb1HfCtvRVcJOK2mokt9gs9ANt67W9dKUEZoEv6khT+14KvGUxtmX61GPZqHLPMGGIKA49HA+CNIqdpVH8H6WTZSh'
    'o05J2CqOhAtibZhvaiVUnHOoKbKivp1eIoipyHxIzZF2528ruxJEk8FbnvsAd/rYZhi2pgtT3bK1mhFf+2Gft6DVjFhd/UrliEBL'
    'WI2y2naXqvyAtylrP4qK8qOx8avmxj290n7zh19a1kmFgXBYOyY9GEx58yGmPy+g9gK30JtPLwtgR7HqQYP5ORp8YlTgvsDmlsBC'
    'Qa8StkJHRk9hJFSrqq5ZxerT33vWWWnFUg1WrrGnTlq50MXtNlyRfsmeybbHn2sqnK6scMrnaOWH2e16kl3BZ/m9OPtxh+TJh3d/'
    'aKhc695eWXclYnl193rfqAK325rP8298Ltfa6hEccDiS/thcc6w5KfLuynq2vvXp1upvd1Z+q0l5ckDCaK6YAGrZt2zaJdHYExch'
    'vEZhIE7lFo1Pq6oqf+TWVHuzvpQk3wG192by+z3+FV+EGvqgZ1aObeqfRtdbh3C03dUkg5dzudhcqu34E1xM29H3e6yr5O6wNlH9'
    'zPFHkfieaXjJmGZmsEitXe3rhUSt0f87jOL6DEjKa1FugHu5kItDoXkb1mYdjJ8NHzcKgiDw7Fa3KlXxSYLH4hXfv2Szn79Qz9P+'
    'Bfvnrtm/vip+Vc264PorWk1zGER13RAdDGMYShyg2LjPzhSYIglQKkTnbnJ1+AASq6Edbhr782xOl9nb7KxczcykX9h0vbNiRFzD'
    'R4i0a6v4Vg0/ztZ+ToKaJTGN3wMd4Vs11CtYc35X0qyRCSLQ5WZABDWOiIlLHOnoxKxCoKTLECf8t0ygOCbPxFyJylJz4UgwF+dS'
    'GMBNqhb2AqueiZIo2IbStawyW1TE725o/O544OBx2K1zIjmU+xlfzgN9je+tTcx3TCcKcZSXo8yDpAbRKPHMWtzsE6vTzcWe4zDY'
    '9IHnxN2JZfRffy6mk+Tudm5hfVU9RMXBSRlbn/WPiMcy1aBRP0643UHoBQ97rbq+W9AZ1GYW/skBScfWx9J/IyYgeWSdwGkPamBA'
    'O2Ki2GKKjJRyUlJcryH54mfoy3sqhievuj2/thtjiPJ7AeRmxqI6dXJxMVqcW0k2dsviZvT4L58vP29FJ5smLsBHTeZnWwiS8IUK'
    'nsNK4A1NGW8yGIGRflszdfeHvIiFpOgVULcuSka7nej1+09HXeM9/CVPebt9ks39Uq2w6WwGuHDE1C+QvQ45NDnxm+bwRkqQ6BPt'
    'yWhb/kP7dzuCQIXdPpqeI6pIUrwJK87+o9FeJ3oxnE/H+QKnAcFk0aclscTj6Fm/DwfNZx/eSMn7negDdPecmnA0TRH0IZ7OkBaj'
    '+Pt8np1Nr2woR9DXru2TYAAwNBTM6qOpRDAZkzimAtkyiAGZXnY+fXjz8tXHv+KhUSXQ9x9yDqS4w2WJ/rSK4fQS9aP7eAnGgzoq'
    'lZgPZ/ziaDmTiIzraJAV/Xk+Q+vdqKXTbZaxHaU0/lnZJZIWRFrhuLW60XFLqU/rBLfEiWnl+zdvX/3109H7jxyiFe6NLqZLI7Pw'
    '54eU8eNF13+Zzmn1X5q5rSNuujDtLwr5AHI7wBPJFYVZYCswU1AHVWgf+8pjUSnROTgU0oOtbKiMkgYmcJELKHOgED2m59DSUgWo'
    'CsFCk/GajCgFQ3bA1bP8Zim0NBlLEOk76WdrQh3Aw5K9dNiii5mjtwLpVobF6UFrnx+HH7T+/h//3bzgUR+4gQpOW9ES6CAaoiEA'
    'zIMRTxBPxuzfE8ucH0bHVA/CRY7Voz6YENeAwjZMFX5bxGIzrVAf271wGJ1+nty9Nr9vxHKeKGqdTJmp1vYCY4rE5s6xXivW9HDV'
    'G6HIyCLiKmmFxMfa6XDiEjUV4uSOPpXTOSJ+YWUkohG77V8z6V7bPd+2bbd1/94koR3xJkhPyiGuEy4+84+MKLoipzGxg9Wt4Z8y'
    'fCkPXpvP5HsfAMGqVvwbXE5k3BtNe+JzUUWUXLWdU1m6tEOXwdmKXEuoFXx6Z+BOvvQ9haWkr/iMNbVGU74baUgUGTueTpiIfc7x'
    'HRppKDVUlqec8jQLgpHM767V39oa7NdwdHpOfY+Pg9rj5KTtUItqdJO1tpWEMuksj2e8K3pTNjNc3wQm0lKwMA6qm5I5NPN2vmCI'
    'kY5ceJDwznFV0aHjCBXhHVsm6cHcGbznNjnNWYaAOenJdTTO6BZDlt4PtOVbbTZxZfOCrwOlJ1u4S1pNwyRe4U9b0tutI1oiXBg4'
    'OsQ90A9k78RQa+hReJhwNhu2pGveGqr9k4ySVRh0WV/y7L8iDn4e6wR4kjqSeqTlomD+/MHO/eTX1GGEbLxkpaIaLKkCw25AvYcr'
    '/AK2FKZlZdqzy/WzS/bTwVzEJtpdOa9rhLJP5127cjdeYM+8M70Aafq5w4WSWk/1BcqYYarXh2UYf1bnvVdguahn6kKaon+TTCNo'
    'sUnKacCimOEVHDyS0na4pG1PH8H3zTqZjYwHHBwB0UwMTbX4u6IxuL9Ct5B0ojdnQf1asYRBSmF4BJYAX+T+xBAihGXhoB9WgXOG'
    'oO+slndMnBZVNc9M0oy2ZMihygrwmsXU+N5x2vc0Z3ATGimuOIkOnAJ6VblSnRKRZ6giDjonPpM6xl2SQ9RbUlGQJlWwZKOzdjQ3'
    'YYjpxGwQK5hZRKe01/HFLdR7QTyVhrdzmJLwosDDn/DUsEHdNce2CeNCKaZyaukPU87PqvIjPfgoE+JBL8OHAWH/DaHtPOZns5ky'
    'RLYcdhkE10/TxZzY/tY2UaZtfnvI5/YAl3U2QTq7Hz++eUGLQd0gOu9Otmxl/qRD73irHtgsGJJk3e9swsRPGhJ0jOCwXDMpUMXX'
    'OQujVCGHeKURbdb+YnboX5X+KbfippkuOjKVtp2+0E2pQRKTYYttKLbMDa3UF2Kh4eOeVDirjdXEmZdUpfdLVvxfTucXVVKNvWmo'
    'CdG+OSIZI3DmSziFV3cQfA86G2G/niPHWUMGK2X/59Mee5Xw7WPWhKcWfTV7uAdnDZXEuGOHHAgKigaqMJ7iameLhu1sj8SeeVbd'
    '/aJalEsG6xD7t0xru9Xm/DZEGRiJcIvmap7hfkyIBrpIjW/MeuujOcPUMoL2/WCGNUnVouhstCiGnknNB3e0tNQKZ3Igzfub0OUr'
    '4E54mr3A75sK9xK+r2WXgx43O5rGwpr5fMClvVjknXJSP83Fr1P6JgUuO1xNbDkT1iyad96eNryl1igsps9b+iDPn1hKaKnU+06c'
    'F+qpBdlkw/0WTT0e3CII0KXNM3w2JFvDv7oMxo5fcaSjEIifa+Zxux6bDf+7blRh0JjBMCOf66DnHXzrjAC1MUtBa2swWqrXuk4m'
    'yYDMsS6iV8BPxQfgm8Qm5POQbVjudPn5MCzNbsjKAnE40sssEgOIl97C2M1WLAqb1H71sigPujgnybCUNFlGxqDl2f6sSgCH/mOF'
    'qkNXssvap5gFK6M1CCWqa0csgtidVau9lRa84LZja9baj5WZd0RlPjJYxyt2QcPy65sbpQDfWMo1RilV4ASDbt4/8quu3Im9gb9j'
    '/a03DxA9iE33tT03ie1O2G1e+rmMXtXivem8ZF6zlQSOBjcsg6so6BGWtms7ICnhU5mfioqHRHfzt86y22fdNe+wi6IjPQYkPaTs'
    'Gkfngm9K1TICS54Ve1k0na/QJ8r+rymehAeoHSKxKVu+orZx12xZfNrSlFPhHkST2iPahQLZUduNTUv3D+w4qyp8r7BZNVXh6oN4'
    'PDyx46pXEV+bbfefp1YkGZIFKNUveifZXs5u6qRj+p8hvDl5EybCL2CXDsPbzd7k/9SBAHfCOs3E6Soa942ClLHWqNrrM9vHM3fH'
    '2K/98rI9bqEIUjF/wL72CHufh1esuuV7ju6lkSIjKa+E/o8kKiE5HD4Arjirt/746uOnN+/f7ftVjXPqYSkO802XnW9ntluXZTWc'
    'BZLV3mWX2RzTxHOtK00U4shTFrJYyDH3bOpiKZ26+kU6CYkvPONQ2GcpEYLFjPrlwxK2tIFutHEEfxxFLAFvnkZFsGU3Aqv1yosy'
    '4CcroAYQij9I/iWvhGRlRNy5KJ545tRUqEYrCRxsihtcEyso8KrPRiOjzQswTdVjoq5VDFg+EiKy19Nx5mf5kH1xGJ2+F+lAI6La'
    'OrsDgxGjG8isSsyGD6OIgteBCMwcKciOkAmrebVWYxXjk+Sdr4bAHdZXO/hIH1RRXfssnKJ7ZLL/tlr7JnzERxGMTPSMqi0GiDph'
    'q5AVqELi74vTev+9gUcCtRNXBV/ImLcSedvI9A4BQeQzwd60ihT1IAu0UJmn3sGdJuajpjAfukSJfrtpE2dLpDXM+XaFPdv2NRgd'
    'M87cIeQck+X2dBgt+F8SE8tC3XfhpXgWUptAdX5eU50nyb4L7fFU2Gcd82PfV3XL43esNDbmoLMO/7VfldXUjZPdf1W2I+l3aNHC'
    'foPNcBB3NpO725JVqr4P7twZWwdPQ9qIStFwlsZk8qkEMRTiDBQp2xhO2sT4fUcVFmELbz1BZpDVdC3j490TcLUCqsn4mbdgIdpR'
    'gLVZA9OEwWHllhHxfsHcUbhtZLJVTBOuv8n7ocGXQfzoutGHd38QjwVRf0A9b/AhQ78FhX4aTXtH0+dE0h89QCAL/TS6+A+w4dLW'
    'msO6+TTgxvAaS/eRVdgs7iOiSZg9OXb0Fc0d/UtdNp4A7RbQ0Lg0IEmfFQji8kwWN2LpFrvuRIek6FdIYMEGaeZRxf5sDdtO48qK'
    'ksucDcGGue40CW+vuHLPBAOQoslgDTf6TTFK+htKUV2vbiNRyXf+zMsEfEO0UgnqlZmVQIgK3MfXSVTbiwkIHN0idIFxzP1X6Tfz'
    'm4mROv0NzeG7qN8pqLC35hlf/RUhgK6lbJIKHioV1jmBo+c3Gesmu5inLQkGrmxdkGWqxifOJudsUJrOyqJmBZqJyR8XIpXjXGp0'
    'c/BlxipwJoT4siM/4Ggo3xwIUir89UwWtkjEQ0/AhwVwMeMwMjr0sWqQuaqKdqye7XLG5wgxTD+ZaJN+lo80TyTe3ov2Eol/8t8O'
    'vbdVsKvTJ8WX8+hqPJoUBxvDspx1t7cvLy87l/c70/n5Nux721RiI9IMcnevf7rZ0PTq+PWafiFE5fn0Cj8lESs1dhPhx9L9+An/'
    'UOmngELAHNw8QcVIL2fRhsbnSkQkjlSUJuPzjnS1xcdEwlLpy03q9D6xJnTNlQeL8mzrcXuF2pw+93R2qFDova/JCyiboCM4PABw'
    'CYm5kj+lZ+k8p2EhbMwiERtQWpZ///gHp8AViw436AeuFXQv250kP2gnbbIWFr/cnuuvsfsSIfiSFuqM1eEl4mSg96R+OggdWSoO'
    'dzNPbSf65RUH/BNjwJpeEo5aewMvN2MsGx2g2SafxaE9Gu4pWCtBIJSYlfIKjALxHUseo6YmLCUvYe9835Zg3Hjaz/T/tftt22Vj'
    'nKSig3kqCNkxLR6Xbv7Aqehqy9nvlFM+9LSYGto8UxTyGn3wfM9dOM8qccS7NGQnGeoChY1TxqExankmwOS1JmEBvWWD7tLRnZt+'
    'yc9T5CO3ERiqlT7GLLywkeVg/a79wXddX+mOOQlzUYBhUGA9JPswtbQCmfPaSxiiUNbQp6Zf0nzExJ4VqdCsQkvEFzjV23Jhr7DZ'
    'XQ6nI2e5iy24nMLR8NniDCxICw/TCDuWtE0saMG3zkQ0Vorq22ZsczRAN0H/gi9+5qJ396Jpi591YIKjqWRnSgUQEvxfNKF1W/gU'
    'uKOpT4PNaesC/+KJc3QM3fkagY/9fdoB0TuMJFMK+8cc8wKdsIuM+RsuiyVtG+aD3oewKBwXy7ZZmRaYj+zM0fG089SJPgnIa1fS'
    'WXr4j96QDZR6rZpi0bMzHg/3kk70vYOfKYBertg94CIU6NxMcg8zLijnQAwtjAnYfKxZPWmj5WUn2hDE2w30C8ksid4i8pnr4MBn'
    'GPFkTbZ8Tpa9B39i27qrmE2YI/axxz4R0/tlivBiqgW+yWwSZjf9XoZA8MIY7F0ePWaIChw4Bn/nrRQ/i/7+P/+36HmXG6HeCwrJ'
    's/0IL/43vJAnzxOOXx1KawbCEU+kS5Op9sO9YHs/7fWNcrohrbFNdgN/bjh5UMx/nhMwxvmJUeNGgesQV0+SWEf+on369s27V399'
    '+er7Zz++PfrEoQXyzpB+/YRjeCYDq5EDMFNHMpgCtI+2Nc196+Sk4TM2/4Yf4gPz+eoPMQHfarAdra7uV36YT/i7m3AWRd9f2Eh4'
    'rXQ1xPsoLX8wOO3+MhgkufiYzsUJy0CcKZDTD4qzdHxMAoq8OkbPThIx6epLecQ+LZYOxe/iqSLsLKxnNXzyRhoXAuSc+O61/rxJ'
    '1MEvacJ3f46TVQRem2PPobsdjUlYQwb7ceB+jaD/O9ajvM3qsILRFEYOQC8vQCUAbrsofUjyNOovCsThswLYEF5Lxhw7vijA0sSQ'
    'QgRHF3nuiCNJFB7egEn7BQQxF3/TPLg5m3Aoh6BNKxSvlvFXHI8Ujw3gzZ1Oh9sLEP8NePxBxMj4I6KrANFIkYjbBoZ7EBp9qEw9'
    'gHtwSdzv1igHpgxkQ61EaF+XK6MF5aesD9I2437HNgm8QW1WVeWWc+MlM3KqNMUTS62NoairY2pf+H0cGyg111PoSy7QUdPDnaBb'
    'gs/vhXEEEIFhD0Rdc63r5EUuNEB9jxk+rnCOCq4341pvjMvBqlFVRrRXHdJu85D2nPDsaah5v1vEXn+cw9oYW++9lCCwqNa77XX6'
    'jH2qUH1lo5zZjcIw6c3dPuNu73or4egXHRj1WntmULkKDemm6+YHEswgbQvEXCFHR5RFQnoExZyu/h/5qrJMgyRmcRyZnGc0U4yJ'
    'HFBRU7Uts28kplQ7TkyFvlLUMsnGrTkZGEpA8iB4UDfo+NHU1B0PyzHPufTb+mfZbtHl8pvf/KZFW7Mq9TPYsMieL9//8AFCJYnh'
    'okQF3M8ndp2MT5/Ac5JE2CKdEHv+Nw0cR7sJybP88rQt4JzbeEo8Hx46yvH87fsX/04tbf8l/vD19d7X1/e//vj26/u3X9+++crv'
    '/qcf3x+9+vrh46uvR8+ev6V/X7969vLr0fP3L//89ej79++Pvh59pIdfj15+ff0xubvtqs6K/g+SJxfByDwF4ClpzRxHGh9//nx6'
    '76/Hn0+ePP16kjBj+vnz3V0/nudynkJBESNLuUfOOCcz1wrCbyCRHJifD6xDF1oKABLahz2YM0ur9o2JHU6oF8XnTyf3DhP+qQpg'
    'u0lTQJLgf/lA/+pZBx+TgII1lwcG4930EdtILppWa7+RCAfwzgaKFQ+PTM5PAOB0jl796eiv796/fGVjzx0iJTE2y0gcuZbgjNnr'
    '7H2PNnNOLKX4WRZZ5uW6ZWMfdWvToOv9EfxDPewnstFR2/Hn48/Hx3+hf08+T0426V9aLWUXgJvAC5NH/xbt6SLz6sdlYmKWWpYa'
    'RhXsIxN0Xhv9HTP6V29JYH9nJqD6tZN7+sjBLd71+WSSORdEWR+qu4+Ihnc8574Os9T4Tw7b1B+fjj6+h2xoZgrbMG7du9fSyuMk'
    'CbB1vXre+PW8+qFWxy2q+FTpypt/f+U/efnqbbXW//pfb1HtC5rBlvOpgtZJ5s051+2bas2R5UJd/k9HJd8ibp22WOF6esp6Ti4D'
    'afH0lAXFU//haWvfLnG1Q89abvPbFKgSNMB6oGclneveoszoFqPHiKQxUTg6Vk+IDXa26X4s5Tnddo8hRg+khUOE2Ak7CtYUz4Qv'
    '5VgCWx1sxafHWpJxP3hnc6GbE/3QC6aLk8/FCY5PXfOXUP3VPV/bOz94e86MoXWsej0Ww0/vHKPd6vwU837Lb6Fa8/OPDRV/FuTq'
    'KKI/ah8Sefzx66cfn9P/Pnz94dnHfyfSKHp3wGlWqtLlQP+e3L0uw3jBG7qjtADdSw2vw15r1fqFj0zh8w0BCZasIFHseNakiolk'
    '0iEJDLlQZ4gRuzXSPGL44Wwk9GIOLBufQo9yQ2gkJv7tm9YqsgTdMhMiqsx8w6vx/m1LdmC+uXnTYXFoC4muF73IJALiA2XzWUlN'
    'RuDZ5BgVvyXJ9w5sReqeo3MnRvLpM8xo4+3i01f27qN1BxNgl9sS1sSRFmF+mBnEKLjHN6JMz+ZQrivRpX4ltWxKnydy1U/EwauX'
    'MEhqjVvuS8InbxnMtlzVPb9b2BLAOET9TZtIivqZu4Idxd61vHLVjcRqE5lrWtYAOgneF61y3kpO+G4sWdmLguXcjuLESuflwFWt'
    'wJTZSGgbz1058G+sWynyrFmOz2ViKsR/PLbrL1/pLqcr/PNXruLu7ufPX1tVP6tjfMQSp+Tnsdj0xOrHm9S3kP70pyMJYwSR3E2A'
    '1Juw3D3C7a9n7sbPCX0HE1nNMWI4JXNDjQofFp86wx9hcnlu5xbh3Bik7JTPvb5zPVuudLVflpu0/QiboarjueFloq8050ll5/hU'
    'xvSi9ZVvx/rHfLS/tgI285iXHM1CHm6bj13/Tae3thCPXa+Nh8vdlpDxXU3VR9VWMtQF+5wVmSZvV3WrWzWJpZgjdkl2z1REHKli'
    'JPGN8KXbyvyZ3ahyLyVOYQLzilezwfVvYpf9I7GKcW5kHVlQYKGmTjaupXVNXwKTrSHn9qbmIcbJWraz9OMMm7jOhpOq1/MHjy+7'
    'UihYM1NX3kxdJau5qdd7PpP4+n4Dc+VVbd9UmzBX+hWYISOs8mVlfhGhd42Aj/iNwb6+e33F0bun9+7hz3v3HGFf1WsnZ7a8Tsi2'
    'pLWwO5fzFPo5C20iSttjye2HrjyVczHyj+lKtpjE229wxf7VdVeS/e3XJ0xZZeKKT+VqMyzw5wk9aq1ZuR/f+iv3/q0/E+Yea60Z'
    'weuPrYYFbDlfGp4UphyrqmD53q9Fwkv6lUbta2RZMGsUXK/BQWlg2PSRfszg7IZJeT6dItVWuOYunle4jLfKx6lbLFFXPm4MjNy4'
    'PaB+njFsAzDqRyHlrmqf47NxgEHvU0BWs411vsYDe7w8MtVjBV+oyE4qXjmi4DqIekywDiUDBWcRqiiQpEBHod6vI6eR6jFAtnRk'
    'lLccAr//YrgnZ5OVTF2jbKpQMJMttiemA5cd8vTeW2MG695j9wkp4GGQiBbfJ2Z+86Je9TZU6zd8o/XUV63VsBeD7gffosXf/MoK'
    '9hpqWF+FKx051ptGDh0n37Nb3udhDhhMo9jPsJpFXroUdPncaSanc5tR2XPSyOdG7VhMjaKRUaDFBhnmtWE2p6GDgVRQnYxRHuBI'
    'FT654LOhQ5OXmvJHUqO4SRGq5h3D2GTATjnfLgoocQwoXXO7/FuLNzWndXvV1RT5v/LkNU2dCluHh9FOcuutbPfPga3Jwu3KOz1I'
    '7ejRDnjTlRstmPzKvpJu+OeyvmqRzKucU62kelBRLmlVqvVoj1drbW3XkCNPB885MeszBvID0mP72vKnom4M8Cizf+Ne32/fqMDI'
    'rxT+XvabGhA+MT6V+pCmRfT66Ie3bd4fJh2gOJ3j3DGbxtkB/zCdnpOU93LaB2jQT9O5n7RUa0NNsQuugB5dM4mzZ+FBtLXr+TCN'
    'hImlupkR1uy/XBJuuDiDXMMmVfFke5Q/fbK9GD1tCXTl1hY7LlcQ79ft7HU3CiA1fbuAv36JR7q/dRE8mT19kj91t8GT7fwpXQhZ'
    '0Y/rew0KntlT/2bwDtMdR4lCNjo95yxgvGvoy+EukCe6kdjEhnv4ixjNm2Op58RhoyKklbHezKSy9ik9h8ZJOsgnSrRO8ph7TBws'
    'z8PN6X5FdXPjdVrI6lNem6Symk8iey/4S0qL+YRWVRd0c9Ng6VlKKH023+5Xd4N8K1+YV95ADIWGcd2s8umTQf7lqRnQk2388hB0'
    '2G3NTpQ7b6gdhwcu2tj51jk7jTqDaf9K/HD+JqnH//TDW4mw60TPF8SsARwBcSNIbI0MIW267QDTgNym8IySawyepxiJZFKawN2m'
    'N08R4S5R8Ow7g7bbwUmMFzP20qZD9HKef0HsBLX0lr7N3p+dkWzbca7hLz6++CuzruAI46TuDQUj2o902O/viSi99/CRy7WJAz2R'
    'bIdYUXpHf2xuskBo8oTsu6IXUvSCij6m/6Agp2iNfsv4bztXr14+f/z4/t5O9Bc6vNHTp5zTuhvpn/tReTzhhJn8eycI44UlNIkt'
    '8kx/3r+/h+O4LI1nu+nRztX3+n/7Ppm44pxpy9IkE7Ezc0xd+UtEEt5vaYAPT1zfHru4Zy7iKk5sBz0OmbYCu+dppCV7YnuTnU36'
    'Ot1wb3jF6u+5OArPS5MMnkH705H+YuR6MXMKhLBbuVzQjKaXUDO9ni7m8Ah58iTa3Y2+msc/0KkVpGx68dA9/yTwJTFGEe0GWWkY'
    'yEeLfU8c15+zFFrrrWj39493uJ7fUz2mxA9EGYZ80+xW23AdZisfJ2vg3fFdg+0cE1ah2BLCQnPWEUNBrEGAbRNZh+nFtx35LT5M'
    'MPviVg2+kyC9rhZtY+tgj2EDubg8a13JJPwBQLxtYlPPE18HqVlS3KKkjOiPH3x6ni+AosIfO7nwC6LR5IhBN0h1eonMPCHwixLY'
    '4NYBHBV1Kb4PN9qrnQc79x/0HhpObGRq3n0UPwC8k6k4ePOIv3y80/z2MftMeP3xX+7iVc6qm/qXu3u8GA0vaaC7D3iim2vG+8ey'
    'kpYPbKhjb+8bZagTe48kxqBSRjMs0MFSXtqEh9QWvG9m+IHM097OrjfD/ZUz3A9neMWbx7W571emN5z8fmV+g8kPXj6oTH7fn9xH'
    '9cn336OzTRMblHnwjTKY/MerJ9+v6wGNREhAWESInWoVvViRyBAMutzv72igiLPteN2yF7i46WvCCK2X7t0FccgxBDDJoQhtcwd3'
    'wFvtsMn0sfY47+2ZlGPBQaaFfbTzEJvFTk4WLr1wBJUJzCoboKlQpTHsBCFI1Tp0sWuT6znWCxobUpHiOLAWXCeIhm5R2VjxYRRJ'
    'V+PRqwIHg2/WwjPf/vbJ0w023/YVtav1WyCd/TYdz/bB3z7hX6OSfzzlH+fyY4N//LKY0k/iVPuMjVjxqwdbxd1FHPMHsen6V+hP'
    'f333CbKFRr4U/WE2TosOOEnqsggwBUfCXBLTNJtPgVRKV8J4hNCYR9ucT9jddx9vXd2U2aqXGtchlc2zEccuFkjX5NU6X0yMW8/p'
    'k8vu/Cn9w1PaZfDsgw0wgYDuQXCNzHTMHDgVe4p/536UDS1ayvcRojPaSEAj/o0HjMiobczQxuzDHK5OHMVxKI8lpOOy+yUdIdyH'
    '391sbCv3Szw+18VNy9fUd9OXmd+LcTbIU98h9FrJ6TzXgDjvFCL+gyb9I89DLHcuawMkv1TN8Ixi3IBnveWaMcj5m8Gb8TkHi9nE'
    'lqfsZ48skx0ewo2ax6US9TCt9S/UuNql0d7Sn7OuOioN8qI8OtjY2eC/ntu/3tq/PuKvp6d6f2+itlmXegJNSZ9Dq/pXNxs0WP5z'
    'iTlHCdrfH+ZRPsDTCb1HHw82dKNz2kwt2H/35Q/zdDbM+5zMh9bmSdo99568ZaPUZPqCg72fFbOsXx5s7OLz7cbv/b7aqrxaQfyi'
    'xTy3YWVrToNOmTlV6nyx8fQJ/dWdoVr8MflCA0PP8YM6pCPfMcM2mUO3XQmUxwj8z/2O43kPKf3y0Qh9x9/RvMug3qiQVpvrS7vE'
    'CgJQC3+ayCVU7L3YDiqrtlLMZM6vzuZj/JcIQHTFnV/iX24DWpJVi73tPp3Ni/IP2XQc4Y+DjTl1ZQPP0y9vC+2UKaK9ksa3zWz6'
    'fdsOFuyp91sWXnYwkxG7sR1J8cyaumiNJ5Suyw/zJuJC/3rEwp3zhkNepyG9Rw9UWJNgxqcsdj7mi5a9++O0JNKPlPJhpLFeNjAU'
    'pvMXxNM/K+OdxBOGzvLy1XiBoVy2oyFnUfuJ/32deJLhFfvI401/aWzm8+liMojxNLoXIU3bpepaqchTreFaPvXK95HsCy/pAxrq'
    'vlSIB9BmWPcAyaanxtrQhxfeKEzE2owaMxHHW5sZt1AvXqsJL6diOF/MFM0e4T6sEOec58bNHbVz5B3molcjtBKxaZRg9MvzNaBf'
    'K3wMvLSAMtEI6+vQTOM/NNu7j/ceM4O7e/93u48cOkOKtFD0/V4+Idl7t/Mwn/h9EbXyQYOpBpsuR/BPd5SdcdgqTHxv+AOrGHLX'
    'WEDWdVvHZrPFGpCatE1oapA11YtR5Vg/KGTxByr+eZYhCNAcCfQKFzijFXY5TpQI7h5ogfXvOa06D4ANYaUhlkImHj53qmn8NVFo'
    'YruiD7zkXuYM67cSkKFBaOpaFTiAvTFzLno76tL9Rzu0lZ1uXqMaHqtIv4kCJtsjXIK1DbXFcGnWUU0WRIIhfHfoqrBtslsugp9/'
    'v7P3yPT7krilqJeVlwBUfPYA/TzPJ8V3OCOChaDqWoRrsd7NYB1UNbHQkGiswLvF2LmuuVIfmYcQh0kP+8ByFtDZMtJ2oNJlM5G0'
    'YpgJZiO4nhunE5oDgsZbbGK230t3ap4e3OIe1ez110gwwTMxMgxcI7YNGNGg9Ms4RE/zuukGEJzWKRKx45OyYGlhX6aPk9SW6QWV'
    '//DuD9v/5cOrP7APNPWMqioB/S+J6KGAddQELRDnVahwBH+spCnVLMcP+Wlm70yMCj1UHHsfHrdxBZzg81AFbz4VB3R4i20/AdWi'
    '0gcb8fFfNk42k43t8yT0bDFdBWQJh4+vcjfMx5WIdXqi4er0rykrAC0m/NxFn3txtHX3F5wH8W7Z/oujKp9BVtQNDx3z6EtYjIjN'
    'YbUgEyDN+2jVXl4/ebJZ6V31YrlVELoXgk6jnKS0k9IR52QNAtHdO8m16vmp1yLRg9BvifxGDjTpOWK6DVSIH9O9r/PGE1N1hrFL'
    'S+ItJgbiKhP2ruUnRIen3MdltzoYNpRUB2GlAWNjo9MFeYVExhmdiVxSx0vU5lyt1HKahC3mnJv5HOEtVuz7wOBgYXTDlRfbwN4R'
    'nT5HtV2JRYMYs++nCFWlC6Xo58R803QW01FabNCj4bNJUXnUL7zf20+Dmntetb3Ku9x7l1feFd47aFAvskoBUEKvTH86QpZfESp3'
    'Hj66/2K32hXcPd4XQ5ryEU+7frXMRqPpZfWrBWcfqDa3MB9BkB9l1Y/gEcyfFYuZfoWbGpTtGbU5cdKvlKVzRf8RJD6+5um7bK6/'
    'makI+Ikr5UfmzPFeMVeLvx3rYYhzv7zqerFpYF0Mk4OdhGuvbYLBOMuL+GTrjetcVxB6/1qDu/e270cstBe8ScNIqj+NRxpCRU0n'
    'FQ/cf3l81L80QspTpRRikBjgRJ61BdckqboFh0FE3wwjul0gkRfi4Dszrg8I2ve+ck6cZleyiuXDPD6j6f3HlEKrYoQcxfxH44RW'
    'uGxeSN5N30sz9Iy8TXAQ1jFGTSDfnU6HFrJnHCPMmrpabx0v1FBtfvtqf1xb0eL2Ff2aYKSGlopf0dKP4TT/+GFtzceVOJKT27eE'
    'cJa1dYPE3746DaxaXR2uxdtX58fqtIwir8eqI/xorf7yWSs4kEM6IHNcONG8K2o5FRvi5vCqhBGRGvovOSfD/vPptS3457c5qqlO'
    'cYRfNSwQMtM2RjXVqE4+tqP0lDTEBDHDBFG4w9wS+m5EepHoIdBbaRAPSTz8/cO9hzom+vXo/kNitu4/evg7yPpJEwHyg5S8uTqr'
    'LuxNaP9UJ9iKBfQDh+0j1KmqlmJ9lFF1/7/Evc12G1mSJrjXU7gYqoJDBAGSUigjQZEcSSFlqFIh6YiMjMokEaITcJIIAnAEHCDF'
    'JJEnV7OZXsz06TNVi5nNLGox8wC9736TeJKxz8zun7sDpCKiszOqRLj7/f+xa2bX7LOSfsrquDmvr46q8onqpePCuaIizmz4urfQ'
    'P8lJfCygb9AIDi4Gfmz5r/h0tvaHUs3W3Y6uJW5Wn+Fo9T/LAcp6Gr6PeQ2wo/o1bQ7VCqx5KokYwwYzwPKtBfAWiYFJWMvJ2vE2'
    'zcl73vE82Ja/w9Pcpnjdc1/4UdSyJveR185f51GlvTRW6DzDgaXpnVa58abixQjesWIt3smvKhR44XGEyyh2pLJeQhveHr/NUalB'
    'G75esIkueh1tONeaJV5d5jaWlsFUTNJH8G6jquIpAtas1yvqsdB5J4Msm8SxWzw8Ri1uCyP2TASdGcfBP+UFmYEe879urzzmH8Jv'
    'rbM4BVFme+X5K/znJAurUOVCecxr02yMW0xUi7/H2XSaAba7NuForYxMA2vlb9zPP9XEy429hqQsyzPW/gmwEmmF/7cjCtgM0+PB'
    'jvyRJU8/vqeGX/JVA4bnIY/AHL2BHnV7pfcpYZUkCyC7ppDXrE/lbPhQSq/U8shuilWT87kMApWowyFMqfsgyd4kV2i1KfWk/ynt'
    'yWakjy9I3vs24Q5ws7glX60XG4GTXMXE6u+tsLSWGZiKZv9h0u9Rm/F0Sj9fZAN/2FjQM5bJvIRMrzjfUQU1plVNtAGLvMIlO1WA'
    '/KYg7DHVDM4LlnqYdyvtC1boxXrFUcjkCxRYGLOclYvA06NByIOTI2wtB3ry6qliL0b+SeU2ojoDoi5jeY7Qruv16HiSJuc+s8Ht'
    'WYURYFlaOmPCU+pRkJI7obzYtMurpasLvVtc56OKRT7SyLJmmvdA7xzdD+662ViXlRxn9mzoQmPqUQKgheMRd4bbK6828R/ogpTB'
    'S6QbrDdZc3rEBf6ogAmlCq+dpEOF4Pwz3YFR3RPYn9SqbhZwryCW6VKrz9TOwxnfkml4yhMnD2x5eefBnVduNE07No8+A+ux0FMw'
    'XrwBZHSnE0upvmFgYc2P1zUzF9w2GU9PsC2flLb/RAZrPNDsprJ4wCqOVuvAGQvcFExQ0orjlSnTNrNr1sGc09JkPXqybjjg7Sg4'
    'gwonRoIzSHLJcIyf93y6V3EqbWx6x9JX3mJ89gT/6XRwObXAochepPGNjqX2haszpvbhXVnBtkTBQHb0xy6NsvLb6A77s9SD3D7f'
    '2ih5vC7yeTWACFSpbBfO2LCjde2Ed90pIi1Uu75+hvPrb+D+WpCvbmWSqSxfU2TAd0In2juqcwqOtZV6mkqVjKcccIPeDUjU7WO/'
    'UGZd6kzrFqfgzFRUjX3mec9ec8XL1EIq2qJE269CIXbhluUIVak+uLYH3qNG0JfdaJNa8Ihh+VBsftY/4dvZ9TpfNvMl7/yozu46'
    'NJrSkIXi7xIHXjTcuIaaKfAFhoUOuAuH9zZf3JLfJ+xhBZQo7iuhKupQbMxfX3F5HShq7qTFHBS0mFWIR56sGFCeX3paC826y9xU'
    'Oxb7At36sj3g6aHc0WRIvsgI1UT/iUfzN6pEEY/mF3uzxDMZDVG/ZBUjtyq1MoXlV5JVCzRngeha9lQ2wzUPrpHzdyfGBuJ+0QWL'
    '/d8KNiD3JMaNveUoOtbZO5ayWYi9YvHcDT3wxa/q/lULA87RMr4nMEa31rfe8ND8XDHYDLDjIXpR5WC8ETncQM+AIRiTgksZD0pg'
    'e1XF8Xwltie/2oDGqczuORGKq1RWrs+iWXDv9+Xv8Z+uU8PxVVMC5xgXBYRgQWW/tBpLcKp97lzFniYQjIwGlxbu5rO8CnECs4FP'
    'fFwvufIFfrGGcnNd5jiu7Su+ZujQWjJ9tj7UzwaXiOULfGQIyc74A353dIYgyC/imTL48SWD0zCCPJuPnSDIBRvccDAaD/9eDXCa'
    'Bf5iPDr1vMPETC+MJ2bgyK8lIEIby090IR4EfdvAOnJT2nTIIpRp4lnX10usTa/kYENVNY85ubEuA+C5xN6OzrJBL1eDqE+002H7'
    'Yku0Q66GYWM4mdcE392pv3sXUIJZg3p4GflvNiGmffm7RxtfwmD/yeN1eHQsktw2H6+LLuPHrj24YMU38QQUR2lN+zzjPVjurRoi'
    'IQ9KRe1CixY6ZU7rrsgALIBBHrDslBPa4JVXCYkQpNvkdDYumHwLtLI1Nks/WqyZLdJi0OEqTe1GpYr2l4yQZ4yuZjCsT9slEmEC'
    'cFF1zfUVgaGjbm6vfLf/ao3EL0Re6yWDbJTCTiFf2d25BytxUwzH3hDRGd4IJDrLmwnefPDfXI5/gS116LfwtXw0JSa/oEC4PJj8'
    'tAd+lXk3WBq2F8Af8H7AjVctweneX0WlsLHx+3Xmbs7o95OvHn0lEz0+/TYBWZ9mNCwbjx+zcm8icUnMozBM7llOL/Mku3175Xfr'
    'LCSfELvhPZ7OplYNgDVkmtbSRrNFtE6ib5V8kknA5CpbnATuuH3fFMe9SZN8+izvJ8FLNs/RR9Umqx5ejDh+3RrUQkorcEfWp0aW'
    'yvUs1ccda7yCnvKk/dXst81NmZv8ry/y4rtBwjSN36WjtT889w/hVrGGcfFpEcOCWe2jW5tPHpuHD7NBqsy88r1ah19qK+yjHQ+r'
    'uRrbSyJ61ZN0yltzwte97ZW3WOUDHjB2JdH+6Wvu90+veCfoIkLG2+qypfN5Xipc3nLZgP7uvRtVVTuCDdzS5iweVj1wWjaFMkpu'
    'or+smGh5583o53XWnCKl/prAFBu/ZZ8RI/EtrJDCAZAQbNsrjzZ5ZQVG2ZRQubc37iyqHqjjMn+78erRV7RCW+E4PqoYx0e/yThu'
    'LhzHzX/gOBK9XynIF5XDuHHXYdx89eXj3z8pDuPmkwq68+S3GMZHC4fx0T9wGDee+MP4ZOEwbt51GB+v47/SMD6uGMbHv2oYw9v2'
    '4ljia1S4jF8yoHehXaZXXTEjniWDPUkSngSmF+Zn7h/hHFWML2l//vv/A4Hv53/7D/7zf/6/Nc8h4GQoKAu1XtrtUyP5OhfGUW9S'
    'sA728UM2TEZ+Rk3/RrwdtiPPYwmuRZDZ29HvobKMPxq1Grhh4YHBCrN5ghzU7H0S7CPmd18Np56lKrX0AGjhjzrKJlMZ+97y/Ccq'
    'DgqNedN+/hcrbIBrWvEHPVQFqMtH3/Pw4PsfOBIyD/LoyXrhHKbii3o7c2XyjxkS8TepHIoH1zz9peH6nzIe1g3mV3J6rpxKZi85'
    'RnT37vTtDNpF7+k1+1ciCQcU4RXLtxSGGF4RZ9r7Ft946tRQAJPIKhKvqEA/s7TCjc+tMNhPS+sdcX0jv56g8uKxPvLy+141UHn3'
    'e2YRBqXSKuzNF5e8wS3+jOX9jiZ8AtVK9TL3PgcnqZfTX1pz2yv3TvtX00+yUHxhYyJ78pcvwA++Z3sh2uQSuZEI9zm8Osre8dR/'
    'v8wIAz953eMLmnwl2ucTScXnVm7ecmDq7RV5hmMZxqqqHJqxYiF2YFw5gY8aT6v4i2NxDGUGS4VTmiY7FReKZ/cVVzQX1EJi49Ls'
    'z6FCajnAzcqKBpUVWfNRV5m7WWkKyr759G3Wo5wvP9FhNuIzOFxIwawGInBfZNMDXlniOY9odnqf9BEtyjsYtZoJfvvL1xYX9gvX'
    'VFcatAYOBmtKpcEIXR5JQ7D2VyJtuQxlMh4P+hJmunUx6hVqWdMamsGCXdXVVlEDviyuYHG+MdZikM/6QC3IAf+vyiz8gfJYYkI8'
    '2fQtO9WzAqllfb+WN7ZiNATowuYvwmg07RfolcwoLWyHt3V/01ZIubdWH+7437QFtuhljWC4h2yc08KdpJ/fBrMykXvNeaaZGlu8'
    'lXaO6BgKN+5HbIIWFnT+G2zYf9RhsFEkfSHmiqN/5RW+4FjYNCX+mta2huk0wRi2CtPgGlSeZsxOgdyWZqmU6zeYq+64jdLe20Yq'
    '/9gdf/YgLO62FNlzquTxbDIQxXG3lYqbad7aaG60XFo6koZ5ZQb+YlN+yvsL4lpvtP712zd73Pi1/gid70LX1uu2+ZLNXf+5+HQ4'
    '9Ox3pGRP2GyyEwY750Tm01Ntq7xIexG1yJjG6ZfvH734ev8VLhwdMF9zmr3ee6dudXUNMABIhN/X539BBUGhtDpKM1WxQkoL3a4Q'
    'extRmcVRXZvBOBFWJQ+opM3hRJDKTEJj/MaF9IZ5UM7ZKdyrSoRAMEx1hb7yAHtM8cJQwfRBWCpT7LDpYfmo+UEBdrH2G51wAqxe'
    'HWz6nWKh3yH+s9U9aJR61QKRcGtihpeQ0zMNTuaiqnpRqy/AJfylPw4DVkexjWjGCepNGhVoNPCnHgSzQAAdWxUAt3DjJxe6Fn4L'
    'DcXD+37XCxZuzCQsppgPCW+BxNqRDwEPYwZ2Hx0qSjLbFfEbhkc2gOteD9HGIBg3lgGV2cA/i6Jx/+Yz4uJ2B3PDA+bu5eE2jgjF'
    'EjYyCHFtgo7ms8lF/yK1MMslXGXaGgKsLEX+kjDh9rbbc9WtmChBavZmyksOhOpCMTJBVRPO4P6lcuyEmoJclHIbp/yFxChHjHEM'
    'SLpwOKwprw9nfuvocOBYf1kW69d1sjhWugFR/8UR07V2EzXdrlKsWa393ZgZgyCE77L12OCdWdq3aK63Uz9kl5ThrN/rMeq2+QKf'
    'bv89YgB/MlmZWBRToJb7ASEyyY9fuK1WzLFdyOF1ndGVv01HM+1x8TSwxLjs09Sk97NavU6U39YGe6sqY50lxRwkk36ydpbk42w8'
    'G3dQ4DEgJTy3J05B5J32btoD6WS7FTkFaJuj+TkgnU9dQG9xVkl7pyk7W2iYguk0G21Fl2ep4EdMs2wAa0aEIcyjOKHFy8GzL/sj'
    'ood1uAkkU1puI9TC8ZOJpQOgI+dmu24pPMqJfUhHjN1CDEaPQ50fE88me+iin1564Oy4ong32uMsMQZRhh6/RHxqspEOTkVr/aTq'
    'I4bjo2TE3D4H3hVRLVr+NLBAUeMA02wxRMm+8m642Vx2m0NI0Y+nJtGu+bFmPhFz0JSRU4tzhumg7zZH1ds1m6stIMIgy1xpfVGn'
    'jviBuPD0X+MH15x2Pv6ECIB0hPR6Ly8YyZ+IEMLo1SYp7IZo4o29+ueu0jZRhvhAVmmnjiUWzgEIgh9QZZqdEtHjbXE8HdnIpWyS'
    'RS8BL47fylHrYuNrE4X/wkLzEBpHQECjkpq4yFK4l73+8UDCahATJHppHixp5ZZBPpe9uWXWh6MVms2Mtz6irTn6VON+M5uGfIxb'
    'VF54ApKDli3fcco+m0p459lBL0/YOOvDqoqZCgZx3dE4GvfhewXRrMmdy6e7TZ2iNWxCzIzfa56Ve4o9Jf9TC7sWcZ2T82gI1C7v'
    'o8VW3//m5bcvP+7tv/sAdPVazmLFWk/EijYbxdW8Cafe7+MdIsJO6C8YbCVnsjmJc+UEeIkht503P3RWmQmm0ppTPzW6boqtK4jR'
    'IOsmgz1aptAjUA5mF7xms/GhO+3mhs5zM4jC804E2wA3Eeq0MTnGuNQES0U4umGWaei0ID/LXnoYnWXDtPi+WNzeZR8NYbg7zACG'
    'nst3H+yU2FPJL9hvcHVPbMx1ZHs50MUOVhvge9/Qy7huMdZICBrRUZ8TMQBijRB0lMjix6gn8Tfn9xiu6lsILXEtHk/SE5Ld1/gK'
    'd40FbuKR0G6iChULucsYnnYNq10qOGJ49gD9aUun07wLpvW0PK3FOeX+cua6W4Vp00C67ZoZ8Ew4+fQzA+H1Pr+iZg+j2YiErTy6'
    'yma1Cwaig4kvHVz3KjYTsiFiChOJtpTC1DPlGOHnHPSHDzskGuiF/TQLU4r5X2Ef2r2FrKKP8UQAygvjY2JmJPzTP/8ztpSYBx/o'
    'x44Vsq6jczqSeQhG54hecvxjuyI9XLzFCKkdvXn99uXHr1++evbdm/09TufjwTHSJYfUtdW/RZt84ZXjWt3v5x8yOjzyOrviaDOm'
    'REERmZ4dLnJtT97kQbq5YSedRS1BVvbk4cVjYZ3Z1n9f0LZGfBHx89//rwfXEg+NWecRO33XZiPeoED0sqqMR+v1+c9//7+PtkKW'
    'FhPrsXbOMtqfEbNT3TvQAOeygqMG7ms1lFbjGOjn7NcmNu00HeoScMTzadADH1zbHsVv42mTRogv6er1OYtgVd+nWV0Ccx3xkqRV'
    '5qeasuV/XQCFTYuVPw7bOzVm+jXhBKLErFDIFLyjK9d0f8rLnaQOYtyS0ZUkoDfoZrNohA5GcTnrwS3EBERE309xthXZYiqjIp+w'
    'DzVr0n7c7PVziDQ9ngw1vaUTNMlzkKqmsCtxLcNpe5+mixaujOkBajBHEjSFHUSLolNKV2f5e51n9ti+vLBGu2bMnxPr1j3zZQw6'
    'xXlNsGTCe8Ofow9pzouq1AmT4GvqfCjmBAXyIvPTv0E869uSz4PDHQsqRv8aEYttt+0IpspTQ3+EbgyHfe9raRv4OItcB3/zhlqH'
    't8e9jWR6+N2WyNHeG2qR1XYEUnYQqJUBbmRbMOlpRJK7LZmNK9AdG4QStD0227vjH2lZNs/Tq1yCsdpYXl61OnzaC9s9+33Lxspy'
    'h3J4OGSypOK7zEp5rS2aJW+z9dnlPp8dI4NSErDEJqyc19o6HQT0pblgjGlQg366xFuLOwlHGFmC/0PWndfRc/TzoMYCFwRllmfx'
    'gz028YM5n1pxHZ4b8Hh8nk0gGbdFgGW6mEsE+lp+L1o2y0HnfxWlRGFEmSoYMhBnJ1MYWrodFQULR0YFJ+G4bulAkeY1QnJXJXRQ'
    'z5IhHxNnwKBnKWIRv8NpU73BuLvWk0fYKYdQRo3RUz4tQQztj8azqTD3lFCOBIF0iGrSjtoWf1ECELkrGHnP7qjw0hGEFs47PSP5'
    'VjtZM0UbsaD2EpIdloWU34gQjgIHK659Bs3oTQpVW38apcPx9Apf2E6x7wvIuKGmTZkmEpyBu15QIulLzhNTA7S9JzQQuWm8MKAu'
    'lFEv4z3L/LFvQ4HhpvcQfx22AKYEGfzNFpkijB7LDytkh7ESXdAEirdM2eb6uvWS+URZhtkFj3qhs7ax0iJuIx3fF0zgcGOmIy9Y'
    '1O6Td5fG+0CphFD7euQy0lESkiz7acttWD/Om9+M+xeGM+ccYVW3lwcAdSyp2IFvYzDK25pOmEBZIK1p5tNsjHu45JTvjGLPly/F'
    'qaS4g1iRNbOvYi+Kje2PnzrvJuPUJVdpCu2rL27g8WA2sQoov6K6iUPnS1WqVwwJBFYoq6z3+8N0EmiboMce5qfF0wGkgD+CiE0L'
    'XC4fysiET44XpKbHNYy73i3BLxsVZjNioW3tyGQfWBaamkTSRb9IXbtaKq/sdS8iTX4JWfUFzhU2Vfrw7t3+x1ev37xhL773z968'
    '3N9/SUwFeiNp07ygDvCLYFssgdzhCbPF3WMp46mQ9Yibt70iOSNxpQIRX+uy4el8RS5Wt1dwip1ycIC2vOe1ur2yz/6VSodquZ58'
    'bQVRZ3FB4OiZYgGibUKpj7PLlZ1v6cfTljSEjRrbC9r1mU3ihx1Xsm/HWhi9O56MXf9kNGdcV+Mo8InIg85x4wMNKOTHfVnGAdNS'
    'FJx3VW62WNg8nSyAnKbZ8CAnNqsD4jUkYg8nz7zuVFGW8fdEA6MY2HaSeXw/RwlxP8fAQxSnl5g6OgiMYzZWyoZXNMPl4oK0WkgS'
    'l8RxOoq9PDQUg2ScFxokld8/B1AVCd/SI5uHYeoL6asKDPduvtvs6jfG5nnJmlYWWW0eW8p3o15WqIJWTrY3pVXkhdritB/SUtpJ'
    'Wk77GdczTVl0ci2zUOTkGXdclOzcvMnMps/jnHszvFT1Y3rEJXydQX6UWwS3d3ih7Yqmd+/AKGg7zW5sKkbI9PNdeahOOTh3SWv+'
    'XRq9+5avtwpLAWfi4NwmZDPZckL+9r7frSqiUjQ5qH1x8py4MA70ffJ6mtBmlt97iD4iLhCUpH96an7vneEY458IkyO/RNbGz/6z'
    'Xg9s/gMWUCrXp9RYXzyrb9DdN82Ty2hnO/qd8jOcU1t4e94+J3QZpdV1y4/STsjxSvgbm4x7FKQCkEiYiHtYoQcXAHvGR4lzjqWC'
    'LRZ9EKbt57//B++zSB358Wyb19/DPVNpKvsf+AQszqSN0+Jn9ZpMX/GSW/2tbXb+cjg+c6YbwpPjAgDCQd4krvksyft2kvJXSS9d'
    'nPyEvtqkz2bTbHFSeHHu9wUinJNzqGyvyUFqSGSuEd/z5Ux1SlzcOG4g48hiiMmRXjSikxFzE7IIS2eWpvCOnVF6+RmCE0OhCDA6'
    'YiY4xpRYxvcp347ar9Rk8PCDZHSOx5xlrfVAagUQg3yb0vpLY1AnRDkGdGRmmFg1OnibXlo5EDYGL6aTwepfIO2cgs1DcIIBa91Z'
    'iparaqxNOplSFsjNce16TGkkBc4lPwmHcDYfYcjgf8TVQfDxWV78/Cy3CV4A5cn/LtwezQx/ibszgD7Y5Dhv/dSUDq/MdyOmeikC'
    '4deW80r05eVa8SF29cGGQdWLpdQwJdrnwe/aVLjxFv7dFTGb+nm7s6kktQnew7alXDybvMCUJIbVSUOejWqmVAsX8sd+L//sgozQ'
    'IOV8PRODuKBBPfPSzavcFRemQt+6woSdCmYDdGtP72lsQlABP9mUnt1c9aflTplLZdohNbdR5jYT8yheLjAo9iMzJUGrvI9iWcYH'
    'pZeEmVjvFj5t0soEZokMJAaw6gw9xr41ZVHZRCncEx0X7sEd3PzoDnx+NEc3HnAXiR0ZvPg2m6Q4XakPIHWf024ApFBiKJNyKkni'
    '+7DdSgJ5eaL2AjG60oio0TTXKpzgl4GWSZhg6nV5zncXg/55yvcWxOGQQINi8uaya/qCyCCCclGNxrfzTQbk3lHLhkZkRZFI+UN6'
    '1ee2msOSfik3UnWnL3NvLqhKM3+9bAy3CpdbhRLPy6uX5Th8cqTGu8jwkvvaaD+lZavcElZlop+qvP9spCm//+GmDNuvhPMXbAd/'
    'NwVZ+c37t38IiGxAIunZ//7St6MtF6UfguIqEnuWnyapZz2HhOZqvWx9RxmqTPJcjSoilUZahsh8Dw4WefVMGOWl8wNLmMHA5OjF'
    'tWNeDykHZpqXisSBmH9+oSy/hiWKFPhLmmgsAlxZH0RXcftilHThKhTDjIWHgFjPSDPEXsFZxwQmI2KwAG6bXwV1iIBeqsMTzKkE'
    'bqqycFQMGCF9MuVYqcmeZbwE8NYmceJUmOi1kU0kmSdphW0S87N4bcOr1QpilUm9lFZMC01JxOQ9Hsm4jlQI8pQ1wmqT6IDAk8T4'
    'pgg254o1It/yUllounuhJTKn6s6g1PJt07FOQd+Os5rr1XLTeTTEu3Qa8YWTq5lFuVK9LFYNT+E8wJImfXMTbz6UxsCovk78jrMD'
    'wsE6rlrDsWD7SrEjh8DqqbZYOyaQVjlwsU785SvS3q3jbyTA4hQEfVfh8pZhNyPHMmfwtMfxBDW835SDzslfdO41lJt+dSIklket'
    '4qrR8QLqZUBsSpr+FURUlexyZ8iXBdOsl1wR1wH4OCoXHMcWm6eLLpUNJkcR9JmIPsrWk6OeGNKVRdTgPk8qDyU1k5DvGm3XWLKu'
    'XBBWMqwStatqq67LLQARy+9eF+T0W+pxZbO0ffeyIYBXLLHbeiDi/92rYY3A0nrmwt7+EevhPL0So3zmaUkMywHIyGyv3APOcnOf'
    'qtclHqtaVkMqnqDhP/VRLgDto96GNmnnvExIOgSEJ250yqzvcYh9//y7/f13b/nMGmazPJ2N+dSyA6NsZPGS5LiJayEIzNRxrPUP'
    'TP7fHTPu5URTjUUTQXIVlc+SE5UNT6grxk+s15uZZIjzi9Py1bOGE01GRJrca1xvoY/mqqKbjBhsMZrA50XymJCdjQjqsXoz4rOT'
    'dihJCYJXSbIpNNDTs0k2Oz0rBPwUXxEqN4GFIQsAbA8/SY9nfQPrqH7fIsDk3QlkAeodiQXiyAfCqx9J2IE+hO/kqLm1aZQPZziH'
    'UQ2RBQn0l0NxhBJp7HsDhPig8wYs89RVFl+e9fnSB+AwlOE47SZw8mCjrmQGZm0SPXv/Gnbak5RGCTo71KLuAf2ckTZpRFQJKIPC'
    'scp7NB5JLoExv/vwJmebfnHDJzHiCkvuZA0NSXB8Np3FMQ/1e54m0RqO5ApCLxteBq+fZySB01zjTpBfvMomalCq6c3NnPfqBe/L'
    'KWv2FLmT339gizY1R/VbAz7Korzfdw20NuaS9u27/Zcf95/9YY/tXcS8NjmN1nYES5ovg+uQPfXem23eKQVby61H8WwECtTWc8At'
    'ipzj28KW4z0HYHr+Qf7wvxKHjn++5n9ffst/vpOvJs3rP77kn1+/fCOvvtPs30mZCIbGPxDGjH+8/8B/qdZvNtoMm0nrf5M/ffNI'
    '/jzG+0d4/6X99cT8+k4qeid/3kjjHE44Pz6Tdn8r7f/mg1bIaM/8imOKyC9EU5RfiKgovz5oIvkjCb9+/SdqAuj+3vtnbxnH+NW7'
    't/v4cW9upurrD+/em6lq/RDLlrnhm5Gb/glJjumN/Jux5dYNL+mbKZ108LW4GWUmx8XpDW2fsxtQzhu+fryBW/ENbmFuABx1A/bj'
    'hinqjVDdG6G2N2AtaLskNxe0w7ObZNbrZzcSurb+oNX3LxHLsSv9q0QO7nt7IEx4RTEMKgrYMXEx8SD3AbeFw1S9NAdFWGRH0+tf'
    '+L6YlwnfVMWgF5AWvJAUfoxlOB8QB4xUldENJAAyw1Uvi2ZJFTTpPKBjQpSwhUbC+hV5XFHFGJezzfX1YzZEqeEoqgiBXG7JwkAL'
    'dolJrIWRFy9nYfBmkIvtyE/anGbfUZc0umEjmszYFMWSmgNK1wmiJSMFBgNjr+FAaOCDzghtmo3OR7iOp4kQyjPGEZacKgHCbT2W'
    'gVc2N8+EGCwFCOIQ5Do8VYEFTRh4MfAJwzncp00In/h8t037qT+YZu16qy8jxwgwt/SogDgcNBaRB/m+MQxHDZjkG8CM3Jz2T24u'
    '0+NxfQsb9snjxkGy9tf1td+vtrYP887qA9OQip5xbELt2KJJ5YNswYbBfoT9Ms8qGpvzbgUHxe/amJAwwmWApB3OCALp5eWRFwP7'
    'yjkxYTu2ylknKQvGowzaAjpCRxn7fExgIrS1eKTr5ZIwSJVtCCM7BkXtSyQp9/xNaKCZiMhsArkhSFl2yT875aUJqzOmh69HVbOI'
    'yNob64UVecFhl9hM7Cl9XS/3K2lEFyWs6wIJUk8I/M9bvfbt3Fhz8UeO/U301XeeoEffr8fcDpK8JUyoejncNxHp2c6j9TQmefaG'
    'oyTcnE3qh8d2CZu49TS2+tvRv6cHP+x0Hu7c/PPoOB9vKR3UFSJ2wqDt7lhyaiQAj0V850XyPSwLA5+vpXePJW7Kt+WT28U+C61s'
    'A6csHq5BQ0NZ9WHnumkIlFVs9nM1FkGFGA6zOEwCYwfpR2Qub1fmDFnNp7aSoPhach5rWfzZmKN45nARrjJFCGPbO7UDI3GMi+Vb'
    '1UIKkrOkyol6DRQ9jY0u77p4e7tgRI0dZoFHLhobG6GTgeaZBc9GlS5KcZ5cGLETwkh/WsvhAoKXYHFHPTk/2HJSdezN0CrqrW2m'
    'd0V93zco8gxK5dw1bVeDF5gTvbWveU3HBWckedy2/aZCg3VkXJVcsDhbS+DSZPObm3yVLTj2QcEoCe69ZX+j79TfSEewVl/gV5On'
    'KQ+dSD3+wsfFCy220CS+uCsWrwiZ9X4v7Biy7OJt2y6IJWOx6w+Fl8VuN8+GBMMQMq6W+BgbIZOtG+5RzVzDomX9gbip2xwl+Y29'
    'epPJ+ff9876MUjhIkouVEIhiex1aczoxkTZiIDN6igo3pI3oMSx4It4t3wORwW0XNn+UdcAO684GshnBTvKkPxEw15H400Omji76'
    'eX8KERsbCRe+JCCnY2+3+NMpfP/dmn+HCS0vbtmFoecEnziQE7aLM1qcd0jpojE1JxRQb/C3LSXMsdz4V9tTnmu9ZoUEmnVxpBqx'
    'PjYkCPfD1RAaVZdWiljDqxcQVsvX/cn0yp0dI9X4jsy5Ss+hwbd+4z2pBMztyRIh3fc8HGhyj1PQSz1rexD2e5mYpLDtSr0N7gY2'
    'L7ORuMASayhYKrQaEr6YB/wHv/JWF8Q+Wjfeaikb7dx9wYsjbvGQiGCY3Yo+GH/uS0YEYQXFbJIDwjkR9Y6x10YTYIYuKDGsumL3'
    '2UmO7qQTtN9Dl+AhWXrBnpuzsaBJDO1pw0PUAig0WZHORqc+a6C6pzzmqON83D6bxuv1JtZQNno26hLDlE1eqIpqwiJIoCcqZQRS'
    'mWUV7BkH899cbPkD0+AJly87SXNxhypYE3v8SdVVvXCfl3Zg4WhFeRVfkjtWxFVQhH3BlxfDXtwd9tQtMDJXP+G5Xs2QuU1dMSIB'
    'RkD6Ke1iS9OqisU36/v+9OzF3p5x5rY+3YtycRM1qTgwulPFnA8VU2f5blm++KannJDFHTsGNUmBr2w1VlLc+Cugm1DfOfBSyTa8'
    'vJZFxdmThect6d3SOmQzDTvt3jFttBeygG7Tp2hlnNDF/PVkE1dUaS320jpHN+ulnod2mf3T8S0i5txqS801roHc5NGBuAYMex3n'
    '6cvRO50kodAC/CYsVtfF3hQQd57d9bBXxBdY6imcjQoheY5Z7+XP766zBDrbbERnjxoSVI4dsxvReJI689kR5/HsRFHcLv711EKe'
    'SiBihWcFbJhbrnwBmwuAnL/WSE7MbWBTbwpOWCEnqVmy4ghKsrRy7Do1D27xoOsAozCBuhMMK5KdenLze1L3x9MhZc0GgjaFlBGD'
    'oDEWHic2qA5cqvGXDTegfGPoawEdhpEyidEMSd2kH/MV3/uDIaXHO0+PgXE+3qmFXCJROrFt+kyqpR4iIuQsnvWkRk8L9WKs/Gq3'
    'WjWz1WcTsFvjSTYcTxGManSOBhKFzNkakytzDBtSg2lCJg5yZYrzGypFApjSqeBuU75RappgyYkHYvW6g1mPllLtfxE3uvvhW1SJ'
    '6z8ph9l3rzGrKGoJqUdzCrIwxl7tc0rTf/Q0Yb0j5jvNu9zaOWAr7cPTVrIj+gyJtcX8nCXWIt2rsRvSBwuCZ/qZtMOYCV4vb7sk'
    'kzmQttbCgHrw4d0WtRbWK0eWPnr64JrezHVh6oON3f4IvXAxpJX4lkaCW7vzdIqbCIQyzS5hYcSw2PLu6VRV/vKpx7Dd7jcl0yhS'
    'WpLbKEcF6obQ1osX+rQHwC9c2BlpDun9BAkLwHb54bOFKFHS8H429TlMWDtocSxD+ZcM04lW4Z1SHIIcdK0YiR5xLj+9O4m5zgbH'
    'ujfJUHrFYTOd1OqdqvmFR3hhcpfcjKCYLXfzgS3eZ8t5+vPUj2Jv3IuiPiKcT5bdaLjCaQLrd0p5PLEa15gqdSNWDGL/8tnX0ELL'
    'qEyfZ70+G/6IUhbv9FIFN7B8AgWlwZ0E6/M5h4uJJ43oLpXFxdrgrkKzzV1ilSUzlVwXxDNnuG3hHYqTRMvATpLvSq+oIXk9cPFb'
    'MGp3aDq2GsN+AmMx6n7GXNAUB2PVbURuMRxgGa9GGx3b+y0Fb6zsLQmq/qqkYbL+0ksz3T5KYZNoYoKCK3YHlSr7nNV0FZvLEYq6'
    'rii/yAJLDt9gcxiXxUOxV7F2N0V2XmywOJFldpU6Q0PHl0Mp8371yGC47qm1TawftkoKJrbSWdwmlt7Y68MYfS7QXd1STuAwfV1w'
    '1fnMNlV4hyuyXtZjg6TudDL4Y3qFKUubuMemh0Z0zt8oc8h1OvO2sk/4NWUglhbVK+o/+wUFjTftFNsfWdeVjubsls6sRiohy9FE'
    'egzEp+Kz1fq+ZC1X64fD/GG8trZ2c/gQ/918/PixTq8etITP8fP6+lwrUlT1h69RV6jQFbHK45bCaqfXv2CrHZh6yfmwoHiLSxmV'
    'JMhs0v8rBKoBYgfW7D6zI4Q544Vb8t+vHnz/3mCrsqhzvYK84/x5k7Gr/lF8EODnLVWcL6zCMuGL18N+clwrTrfHXQz6IpJUlW7G'
    'OGh6LZtNETaa6bfEwa5Zbc3izRQ6WritBOy+bTS4ajPVjbz8LSUjaT21uwj57jbuyighAw4jDH46fQVys5+cxuY1ZkIw7UAg5PUl'
    '/dKBNbeoVYAviePNEr5PXNCXRc0V2FcGJY8TDuDSiGof2WXQv1FuFG+Ul4/3WP3N7HhXVF2O90KMHZpvoI0RbXlXrJjRl4NOvYMn'
    'YKOcsK3wEjHXXjIyorsRSEvseCBpl/TnhbZAIMTf2Le4MRWJoU+B0eeXZUnGO84at1QiGNZ1tfhdPOC9SXJK5/HEjHkFjMgt+bNx'
    'eX8UZgaH6z4D2qaTXzsx96tmZqt6pSwCRdHA4FkecIOgNO+zvI90sKl6D1zWXV1ZlOJfdczp558hVSy+QdamUgXYPbhOnu6hT3jT'
    'zE5O6FnkF/dsjkqjdp4USGPYTE5l21gPsy5LWt0ZbvCita12yopvoUbFeTSc5VM2S52mycCX4iyqtBge3PulKj8H7FdhkiyWxz6f'
    'U57+0O3xV6gbj5ccDM4RBzs0VC4a43HV9FUYj9udLe4LJh10BaHh+BziuTNHH+0z173QneOiwvJ8oS/HRT1QglwEFRV9BPXott95'
    'sVR7o/CAvh6elt1R7JfF/iiGeoROKQtdUkqLNw96wUw5Tr7A6c7ySrLCvyZSGNzyMso3o6IzgBes1aP+dIvTMEScmEzLhVnaa3oW'
    'wnsfv69AUpYlJuhyW/dEnao2lJR6tRINV0tTCeey7lt+CMiHNGWbyliNauNPtUCnbSdCrO0rwXCqAKhvOXohw2GNXXhST1Wbvk2m'
    'Z00GIIm7g2Q4jgNI9PTCUaPNr9YbPmD6w2i9+bt63fXJVT4bWzvta9WWoT3VvVJ3Ifyx7qTVKWc4yGZjVZwswZ3WKWn45mZV/WeD'
    's+IVA/dj4RyErV2YzDUVa1yaWn2BpviVNtjtXoqAudQhd5tWG9fCRtJeeCYXujjdYTCajK7kPpi46ByI/Uzv2YoZlqVym56fQdOP'
    'M2GYnEuSY+gVYFYocS5ShL24EpTE5r3bmRHjZR3yDxw1b9fTRsP5OwehrmIBMEC3sC2/US0YN6NRiM5onvI2W3t0EcqLnUEEIz4X'
    'CtI9y/rdtJqEfPP67f5eBQHhUgtQ7N/gXQwTIZFiGUmc01UBzlgkJVxpcaYtL88+pyrijVEqmA8xXMwnuWCJvsEqsN5KkKrku/Fk'
    '0mR7NoWNRVO9p7jHDVNXbYPltPXCwlRUEK+lZV94OyLV42CvL72RYMvY0Enc6Svs/rIFV5Jpbr9YsVDjg3swm9E6Hhe9lgCSAB+b'
    'Nrx5qDJrUTICMDk0DMeTZHJFw5MmE3HQKXg37fvOPCckmuWBU1FeLApSYw+mGmOSOqVWwVZQIHQW3nrY22ynos5NPWoAimaLJlra'
    'NTX+a7ANeRQb78XVSG3AkMWiMKzBIZJd3Vn9KBD0CkzvuQYJnL2HtW9cf0zTjZsPZ87VK+LbZFyGu4/2/vSHaExjMKZjaHU47Q9T'
    'rWTaH/C9N0NcasG7TdQGWXjsiyD6lT/yrdffcIU5VuxK/6sVStrR2NujRNPiafHqH+HWiOW8pGOsBcvjdToOp4AC6Utw74Mn63AJ'
    'TilHr9ZpRPI87I9mJB/jefMxPRPFnfDT7xpwG7/i34+bj74EiG2anvPzxiZy0ro/48fXI1jnTmk11a5oOdU6HXMbCa6xiLh1AK6h'
    'waikHXDQ3MAAvTl6GiGN07GPzLk/TD7F8DrC75NBlk2It3SqjZHVr2svMbY/zthV5BLb/+jB9Wge0T8IRUt/2FYboRqYNtTmGNgj'
    'Y6R+EbW2uR3GlFYYuktagtkUm8LsqUuaUxVPEOFdDbpSXF5AuzfmKymx06uxF9tUUIk84yu7vlhG8meW1VdoOD40sermN/rAqw9P'
    'xv1fsNnZHp4XcvMsyeNz1riYWzJ5DywcvN/yqgE2q5z5jQjQgY3IQO41IrEHZnyO8xezyQWsGfGbkcBzYUA4MMPFqWLo12phpDCB'
    'f4Igx9BOwz6N3DSN/2Xv3VtxOZKf4sbQP7mKpbt0KvbTS3bwLMWdoKUjuLlCjuBBOBtTsT0OXpXd0yBkryaCqZuG8wV3SA2gI3bH'
    'I5Cs6K9ZxkQSTofJRM7YhPb2yJFQ+NKr82ViYpM5HR5zknk3HRlT7gbDIx8fZ59g5X7pr+TjJhhsbMMnj9fp41n48Uw/PrZItlIN'
    'AImPm5/oKwpoRZu00flvI7riT1f86Uw/8V/J7+bn6Cn95sBIz7NPHDgZ++IK/1zin7P5CmxL2C/2WT4mofYDtB3bK5++7ff+TP8f'
    'DdN0uhJJ8CheHtsrMJXELbqMw/xpi+qQ62fv6PKXCO80oh3JYIDzMP6Fy0+xhVVFqWs8lzXeMDUGoSXkVYXlC7gFARv7TPizcryg'
    'IIiKb3JsTiERH+sVKZSo89HsHVt7/EIUffLR4THrsw/JzLqtb97t7VvzpuC4kyVhyyayNMtri24ZTLI/TPpF0L+jp73+hcFdRZo1'
    'Rp5e2fmzzx1AVSIbKKetlqr7chhuFF7ZUfz0eCfkUddormefnraOd8A9lD8Pky7bLtIuRqJ6E/YHr0dCdI28QFwIO2nnU2BygBmh'
    'fc0SCTgSnM30PHKocs2nLepWaDzhR2JYMmamyyYKxqs+W9UKt2QGAbiHZpI0QyHQjuNu7bSJeVQy7se1Fv3b0i/GsUr2WJxOJmbG'
    'b2lpy/jyUb0sB+qtFpXQHKZ5DidtdINXqoznNDlmcjlJeQwLE6iOCD5fiCHwyqsaz7DbniWNg/6jYSjuJzHMNj18JdwnS8xBbAox'
    '31YmbZICLZ2DKwFj2bowHTQfru7+8OB6HtdvDg47h4cddmM6PHzwzzXf8vKsf3rGqDoxBhJM6mSovAvOP6Osz7v8vRgGQcLVSRZN'
    'ij+2GQJhcPry0zjmhsZcUJ1OhtppH4YxQ7H+AX0FmSUKyz+PfNqGEtWU/JkCmqWfuulkTAtHcFun1qNAKQyaRO3ENzWwNujz4srp'
    'e+CM+iS+V3RfAWZxzYvxRa7SrS+GKMG6WyMebsDTs75kiAz31+ewTlSStcKZqu6qD2DUdb5rShBYbx13ALCLSfgCVirrb2ldU2si'
    '44wEJZvlj/xgf0IUvBOZjmJKvhZ9ibM6ZQBc+dYf8Xho8Zxqletcjb5a9+cmljJpRxkYVBZqObMw/5yAS69XwtwDVBVVP428GsMC'
    'C6Ev3NZy9okewQmtEX+qOG0UdF/x9YNJ1RVAmX4i2XBAByO3tW6uYJ5n2SBNRnbyzSWOEXHk4gV2mCdO9WY8FQ3fK+D288MRfjPn'
    'Lj8xAPOj8iozUTzQsibLoTFvdyrR6V5ofdhJd4ehDXd1QmwDglC3pYOmP1O9UkKDwoqDks20zAXVvmo09Abhai+bTP0xB3qctd+F'
    'JMMAnxriCa6jxwLd2TStYNVB+iIbwtSImEZ933COMA1WGIxwC3VBQhqtEbgrIxitRi12xSI7SxW0yhPzm3coT1SOGMR+ah4jTiu/'
    'aPdJlyRRwUUunPUQOXvJISUzIMlNrCuRgMzbOYgGi3ZKtyDaMSK5PYNzEu44plvEcb2WrnGO5aVjc3RrsUeeLS/JA1jeblkTR3sC'
    '36XC4gYVLfQM1/FKW2VpW+ratkyYCWc5TczWYBQ7lWLdi7kX4CP6b/81OhLpFt+74Kjn6lxmX5R7xXuNdbBUMMqwL+YiP/Fvr2CG'
    'D/cT84s58+nue3n0VPDmTFBr6KLTOGN2SwZMJsYZZUIa5iIx4O8TIYTGyFlF+pVokjHmP9/9rYB/4VNke2VdowOgFGMILGXW/ZAA'
    'fAZDt2M+wlJYfbP9RrHYAenHk+VhHQsuUpMvbPNTeKCbgo6T3imJUQweQ8wZSVH0cUe7YyoOox1AeZwMtD/ysLBHe9CH0uoQdR0a'
    'LGpWeV4DV8dWvRoEoaKnMPe1Q1AYBNSBMh2jZAmSLOdwRMLcWNnGChu/75zYzI/0oV7K9+Cad9xuuIx0v4XNxctCW4/Coed3nnQw'
    '9yJHeRu6LuSgORuxzVBcjFDR5YjZ6eUK7VORm96mly/opZsSaFJpLjysay82xQLrBamUnSmqCOciWY3EWFbWmriXTCUxtEspJZNK'
    'IykZirm4CicBCrN5lU6bRnTggJmsGoYUSJVJ/HBAp1Gb+l2oCBoQ7FhnTEVl0PmMriAPql6aJUQW6RappmMIJyopEJt2jDsx0/y6'
    'fxRViLkysC4giBFbtLi4iu+y33wWGUBe21bo222axon5iuOGjgKqUL1daXVEwRbA2td1psQAF39rktrSBJ8cTLOxygHimN/PS6Th'
    'k08QlB4FwVGiRWJYqCc43nkTTkibp+zBNY8J3FmCLuOIsTFbTgbpp7VjwAW2sSZWdkbZKDW0Ufam6bjZT896vVeFnuiOAqyztoH4'
    '5pDWlZuwI2s/7bGgElyC4H4ZfB+jSc+OtVuFRc2Cst57uHtPtsOB0hKdF5Vl04ytB+d/vp9p5ASHJNaDBzLGi9KQIDeMa6xqMa5E'
    'RlF5Rqe/8QoWmwhqGR8rRh3NrUmudg9H8Z9VPwJXYhM8nQ96QIs364EUjA7tZ7OJL1J4DQ0hGAZZ0jMxBThmkkRVmk1gWhYyexB0'
    'CwqF9FMyHBObK4Ne80MAPBuZr6bHbZXZuN2WBQK4FyvigX8YiQjchVnMZd8EsS8oAdE/2Dex2MTHp+1n+fiGfTFPiJUnwoAFy0fH'
    't9iYVGh40BTmUGpg47n2OYKYeYM6UXZx0pR4cBM58StUQjpyvnZHXHIL/ZdlrMY7KAxh8BgV9HouQ+EU+1VNd1l8gWzSlBB1A3G5'
    'd1qtyVYhwvTc0xjf1vQCxb6zva1wSZV2rAceG9VxZpXyQoxXyzaA3pxJQjthba3LGnJp1SQYchfRKQHPLvbQ3mxtWX1FubVfeKxD'
    'zRNqvUgeoYSypM9ortdjpK6Hu4GvPGzwRl5nbDBy6zQs9CH4/CapbXHR0J9tjO3LaLE1920dUpPiBUfa3VfYcOnq8s5lf5EN6+H2'
    'CxS9rSCbv8KG3upCEmm0x5suWDj2jJTwyAsrpl6bWn3IX48zBAC1+tO43RykM8j4xjyvOtmt8VlMQIhFIVo45n02C9DB+VzYJ75h'
    '0k8GfswAiWV8G0p7RcT0eoR7Ic5uPvn2gaysltOp2E60zcKwf5MOxrc21F0WeSnNKRN0uxo4/nNx4v0idfVXDdFtqvf7SxNslfhn'
    'D50eHQuGRa/lKIFeA3wGhVl4j9ZY6sC01E9pkW+PPe70Ps5Eu478Z738DA+94oWeet2FzMS80rOlpa5ossPZhUlKW0QBb7s8vINP'
    'la1tO6iNr9wz4THT6DjlW3E65DxeQa4etgNZKyoRe+MzQWkLRxC/K55Bi4bmGQIwf41lsaTRVUO0uHW73hwtcqwq4CxwU7LasgPJ'
    'Ab3g5uYdbie/TeDTmUpgYgfjDQGYrdCi+Of/9O8skyD6FVxliWkfJz3i4XNGVa57FzcMeE0lyp15IJECRDCt8D3Yn6Tp9/zN+QqA'
    'qWsw5McrVmo397559/1HoH80dFMk3W46ZmeEtmAMjnwvWHv6CBBuI/qCuPIB4tZ4uMzAC3M1vHr9Zv/lh48fXv7Lyxf7RKTKn569'
    'ePHy/X7D6mKspzQRGeD3aw/Z95eRXInCCWSTYrlCF5vR4PwR8on3vniBB2C7pSb/ByxVwybKC+zsAYzw6hyYYL7mV1C9/bzl5/CK'
    '43xh3Oggt5/U3LAWg0YsiwUua+v8mLlJDkYcKuSxlr8GIY/Oi8YCP/+n/69mDXVSLGCDgUV7ImxGPr5bOxibE/B749CC1Hu0F2VY'
    'VNlggFtotuP5b/81gv1v5MWspE+K+zkmyf3MT6qZs4lkYvpVylgZbjg5zQvGk1/wOyvrMwyBAvjlBh2ew0W9O877JL2O2rgfEzT1'
    '0QyWu/TjYwNXK1R3i4HGGc2bRN1TmMs11UTzSuxbSdIfs1kSbn0mHn6c3uA2NIJVyje8GnSGuorEDNgCkix6N8ho8PqkgxcqgnsM'
    'TuouvtWeVIEH1fQtEQjiWHJBCjxNYFdFYwkjohwxyhtsHEByU92zzNx/9geYIcQ/3Bwc5vFOo1P/Ij44HF+/mdM/b+cfO/7DYWut'
    '87DeOp0ZNG6q80XSPUsDg0027DxRt0Zr6uKBc5zm707ikY/WsmsABlV2OrD2i1MB3eBa2GrOYBE6lW8I5aBxPxZhpNpo5faDB5oa'
    'vifeUV7/szkQp+rAgr7uUVsYfQK3wHzCYtPQcNY7rEFkS4HhwWanAALs3OM+sSqp9cPBYY/GddU4NH+qe4THdp0dVXYk8rQbEEaH'
    'M0yPS+uGiea87ow8xAJRbRM4eAIWDY2q6KJkhcr64m3TVqS6T9PSoiWO8Lw/ZqA76IA1a5xJeHtNimpGKS3aY/pIs6vGfDZiw2Ry'
    'ZUNgUEOSAdCErqK+gNIlvKPULHCYDhCIesR+BrnBZgxWlUTPDg5WwTy/ntNGGNn43Nee28kILxKauHrxbjVpEtuxFh03FbHWhz3H'
    'jh3l9bLZhFnadRoJrfBg2ol2d2V/YM3UWYCNNSq4NagYaRhehxgm63j9F9TtTjrqP9VfxLdWsX+Q5ODJGYAJK9lrcaeZs2guQciN'
    'iYe1teAfyXFOCdaiPnHxpjd6k7oWFVLUo6eITr1lMb6AKshmKAVklXNBVjmPnhbLhAk3Mj3l70BYEQga9CJmDMhoNTqvR/9UyEh1'
    'a2VLEv3aVnhDxya/v017WN2ptdlcnKk6vcw2pdGPB8iiGPO6nLiQ1WijQBMoZ4jz5vmlTw3KmyXojMZonyHswKJm6uHVVcI778O3'
    'XXRsR7gDxdb/4sG1+TZv4wKat6ISSGZe7bp2Bh62tLo1P1AvhSbOOXPMHVWyCmx6hda1oxZS/jgbInYTUzElTCEn8a1eyEG3m+tB'
    'rWZE2HYgkKz1ZQ23fZ9A2d3Tt4YNqTs9eC9XS697BtO6Ga2AaVnh64jc4yDy8JBvCloFjvZEuYTTTMJLEaMTz0bQEjHa6AnbeaY9'
    '/7yXvqvwJw8Qw+XXa6iPgm+vJaCQSfCmn4ff8cL4csibb9TZoeMKJQonlCzU7/dljdzBzJdTVljpem305Xr98lxGzy9Dklp8ziI4'
    't2tSqU6xYvRLcegnTm3v1+odQz+xSUqhrQvsubrmmPJONM+/HRAABjveR92t+azLXXmdkuWWSgYwJepVgQvy6cN7NGS6xO9D1ytA'
    'lrBfQwkcGN8jE4tcvYdY4zVTfO2adzyIMZM7H5jI/lS379fltZX8fwrwBb6oeYipU7GNY9u+DdUkOprCxxwzYp9YroLVoqnk0Zar'
    'oDKHXymbs5mcm8aDxebHAPnJf/JSP96qSivGfMSUH659bMUd2PRx1Zeo+rJQlt/oisIs5fwpaGSYkpdWQGf91N5EyCswBfq5J9YO'
    'B/xAklLHspz6uWi2BjgyEqwUlcxbNcnBRqfuuAjvy7H3xdvQSm1MPTzL641oY1Ou8WWekNWnAZYeRR5ZC4RbV7gYkZEk1S/ZkIlk'
    'uW3VK4JcJGjrNdqlcCmLvS68jU3KukBHupUPV8ucQ4GP2NybvepUfsQesVepgR0ai7jb3glp+/9Iuj8tWzFMT+2FvpOt2w+uu4Z/'
    'mW/xT3rVH52/G8X2A6yuvlBTB1gjVBkhVFuLnfSoMGtzRqw4jMJYoddnvE8qOGhjL5tWN3L/m5ffvtw7MEr0TrMb52dJLxW+F8VI'
    'q0ILgqExUgrIU0iQ3nsE6Ts7LbabjOyYz4NyefpN0XK8m+SBbZI3QIWjIp38IYv7/kExCtbeQb9jvVrM0VSN9A6aKbc6AbS+ZWjH'
    '3jLdoiezUrf4y9t4XDcrkwvnF10H3nmtvLbUUPfjI4pyKcyw5bXFWP+bkCA04j2ou+UqpyKYhd7VSrwnI3zxxaOpPQh9ec8/VxcD'
    'zHknM+woluapuMZYijljgKPqpfCwoq30aIyB4mMN4gJQ4tXUXVT31dLB0q36VlVxB16Kzm5T9GivSVbm+IrXgldMK3uUJoBArbEF'
    'w/zzYeDClXjLHcVCTCyz8sNuLSrM3R8sL9CQdSukejTcHigbIVO6CpmU5y++rQXfjT+rfnFW8L+sFeqa37oOAwDBUujNa2N7yHyq'
    'dYF3WPxEZy4MZGW9voChndNZ+eV63baFl9Xd0EQ8w5NFd+x9XCXJrfqtq2F14la9oEiXI4EeHLARc6cD2UlY31BWexNqdE3chYMD'
    'EH3JVlIDi110fxoFYT8i2DsSBWPE0JgIKruzSkE30PiOWNNIZUI/LO+/yAX7uEOcSrR/Bo8tKVztKbPAtQf2Zg1eEClDaUPbRnNi'
    '3fIFA86hLrUNscUb2yMTsAcVsRzYjBhTEip0hIgLq2RV9WxM48BaZVO0RceRrBBAWQOX9tnNGvgefATDpIj2EQsT1KtT4lI80fL7'
    '1398DV3y4cHhQXzwwyHcuEY3X3RW6/Fu++CLm45513lY36W/ndap0SO7k9nJNrsSwrko2xzmDw9H9I8TYhQSu0IKY+637MvNPHGV'
    '9OU5Ct2qE2yiGlFRLBN7QEHg6G1gYJ1hITD93rJOwQUjMMrl5fEgPysApH9D5PTUmKtQUb3RsSHloLb91sC9OEc0WcsMBTZSVw5Z'
    'it6mtAGQKmJGmZArwcWnBF5S3agdEqvlF2NcO6H1wA+I9VDTJkdGEs7CY3vx3vd/4XZvE3FAWFCRwJlail+ELZinYdCU1KbUghQ8'
    'MDEvhVsacFvZDBH9YQXggJZB3UZ7t9UcDKi4olBNdAcxYhLDfd3ncJos7GlrKAULpxkqKRRWkMQ5oBuSQOH3ure6umW8/zUTZWGY'
    'gT7iaVBFbe4i7oYaHhVSzym5KfiQ0o5hTb8hjrMx0WpauQcH7xAHQEgR88DQ1XNMMdDeKXzGiY7IyullwBE6nqSJD7wwQeEpoC4/'
    'pCd5nA16+3xdRmuCncZ9BEKZQvDbmuxWslDnSy/JoyXenscZ9qNCRkHO8McuCsRDLTruTcwlmPqP1g6J2OH/8occHgFzejdvV4Ds'
    'IFu8u03ZO0RB6zV1QF2ijmFh34USnKRh3EAGLUybxHJOnQDsB00q3JdBkK8dHKDpHLJTlwL7rrgdj9NHblrVbTUTnxm+Xu31cyrr'
    'im9N+SbpqkaDJNbQuC5lVRZ76fooax8R0Hjvs86Rm8++vaSevOAbK1abegAi6qyul7bu0pVWfyOSoNsIlifqVklDJC8dAERlms3Y'
    'Rj3mkKyU457cwjOcRSqMWE6EsyfBnzRMFGvkZxK5L8cBOMiyc99uxIDOhipF8d8QPesdzEcU7LPacCQ02SABERS02mTDW3xDVn97'
    '4Xjt4eKmMbiMwhlTl4aLwuia48y0gZHD6qx2NJT7MHa/tU+0BIcH6x3r3ItTou2fWGp04nHv5VvV4cGjTv1utXN9m66+ZW3hqLso'
    'u3Dsz4u3rlxxoAEoQIC723BF4X2xt7fbtAuQlbwadPYbawrA8on1M62VqdLlQKmSzQMd87Cf51h7FZ9Up1R4XxVjxluXtwZT8EBU'
    'Ix879aQpcVVPRJ+pcTqnL4mzcp/giq2BD04UN5lb2fY5vRPBSKZvl4hQpz2Uu1ZnhUNj6g0pX5TX0I+1S5igXgKkf2ESLbJmh29Z'
    'YmpgTQbTjyonhJPoJg0lyKZnLMLYpw0sgGR0VbH7GXLawhzI0AjKrDmtbgG9dRrx8e0IuQsgZU1kqfGuh3i7pe3w338W0O115bq5'
    'M86tadRktxA/y2uY+fbOa50fC2vXX83C2St4sRS+vW1jZmmZO9tm0Xovn27rcvViZzEvLaEJcOrBHQnbGPg5gay68kW0EiHcCx81'
    'K2vRisphKxtN+i02SXS66MsdescRqIB1gGtEqse7fIRl9Vb08OExMUoPHzaih/1pMuh36ddRlzpyxCf33/4GtKfz9G9/A+82sm0T'
    'aCUS5cUfkQalGZKtIM5C9yzAQWMtX3VAv/v00Q+ABs4Kr4JAQSW+isN5DsJIaQ076cU5v7c01LsNksZ1V4c/Kwar7J4ZfwZ2+NKn'
    'w9n6erJeCCPDerYw8poqYJxmZNxAkIFGZGKJDfphPDETW8NX9BsgDCm/KnAbf2GMeknjB1HY1Xdt88YvejxJbyHXlMIRbEXHQBhV'
    'fQ9aLeRo4u+xoP1MG8CRZirD+vI8D6RhweHOp5fM9+8vG0YEC1BDR+XZclm7CQwWu2ZbMEoIbbuE+j5aY9kDizoz0R1kiXEQ96j1'
    'wxfXG43NeWR4himOk4MCjnPtbLPWobFE6keNJ7emfsSp9ajeiWpVidz81zrq5IwKDtYernb88iFi6vigFEFI/m7EBllpj+/ipWkb'
    'B8367TnfFfI5GA5xF5uF4dLUP8afZaCgFGHbnfUp67ZIHMwh95GYIkICIKH6ijLzadoWfpo9HtMCklu6LKA31yKuNhEjDLoaGwxG'
    'ZizLXCAqXnFch6Rzy7piAQO70d43ehmWr3dNJ3K/jTPuO+FZyiT2zcUojWFIoWUBiBoaCbIQTokvWlw0c2mqga+DMD8byXglJ1Pm'
    'PWg+4BU6nWR0HsFjVcwvIMjYnXWZCSw8ny+jNFJTjUhBv4DVDexYxWUU29gqlXUlnjHWGfHUFruYnzdgNWcCJxXjAs3rVSBWof1n'
    'MMzuZrQ8aUoHE75Ivo5qD2ttYtRaiDVD0udDEjNX63h40MJOpe2Kph6wxSx9PezUNV3egXjKGR7Kc323rtn6lG2j00E0DSn940fK'
    '85HL/vjRK7nD6t+odiTJjijVEac64kQ4uzUdMEs5zd/+Ron+xon+9jdOlUuSaH7QPeuIV3sRARTiPTGgHL6SMUDR//AwGxoUKZbr'
    '4olvD39/WG1TOCmFK6hg/znU7S1bzxOycIuOU2pXRD592Y4YhtsWtnxbSrLqXWmv6hZGEUNQFiNgFgzuhwfStE1q0EbHr8zA15Pk'
    'rKHqbewW3nhlad0I2rWf//6/2cMNakAN25wJRqjoDRoBbLecJ9iSpplcScz/VpEF/tCwJpmWFw5jd1kN4B+ywu1I4mQZtovDRca5'
    'hriO+bz1TBjghSQtFad3VlaJuZqcDWEcbC/4jdPfF6EejW14Udm/yCxcbTVczHSQly4suOzc6J323ZSpWGuhMlVOM7EF/NTmChki'
    'dBMIolf6AsCgG5vrDDNPU99W2GMaul5bzD5qagLWjj68e7f/8dXrN2/gfZeM07Yo92uim72rIrBCp+7bEZVvK0alKLUwA6oImy72'
    '8G/jvhHP1bbzW2i4BMpR539FAX9XXDxKkROmn2MNMBVVvJWmF11dGcRtvhITfkOagcMt1kuKBJe6lK3Xn4iYAkQ5WMTnYpmKSkTf'
    'h9svWtW4W2vIVRu7g2E/gN9kk/QY5vnsonLSn4qVp90pwpkIYHGKOzQcmP/935qoYQUwGCytnf/89/9YMYmPs+k0G6ra3O8B26lK'
    'UcdXMlMk2ED5fDzrD2CSBPAV4H2DYJg49IzMHwCselPZwDrqBrdkx9knNfLkIeaEXtRPTs+iRvbpDhfPoTQFu5VrzunbW8EZE+/M'
    'DfAJx7AXF03nfm8DseZLL3IGyRSOKHJ3Qu/2+jBmG9grnviAxNcOcyQQyreDu6P4gCgrRLSJpDgYuGeTYhAm8cmMzA12RUbLgBcZ'
    'cNea8guXdUBNYR3SKOUvwU2T5dL2UpLHNeqOnf42Tb6WyRfyfCXjLy9dJZjhHFLPz//rf9YrW1rE+ua/gG8E8Agghv6LD56cX+HI'
    '1zZDWkFOdk+mXLCM8j5xLwT1kD9Rkv8c2KbBd4z7x3dju1HMHWbTNuqUXCx496bCN+LmQ+4R6VGDZAkyeHWut2Ih5OWz9481H7at'
    'yihtNChanfUnHuhY1TCwIUjuBnTRmLzNlLygCay6ys3x6c9TjQMe06hbYzqV/VYRD5tNsbVpg2MDLca0B+3D3d98JeLlb1CFBk0h'
    'TXJlDvxo54goeXQyatiaRAtkbDlTrYi4xhOIkr5nu3OsQiaowzQZAcFnJWhuiKx1mmlzTzMUx53m9u4cHJRM8XTqQ4PIeafjkLYW'
    '1kMMnVbUC0ZFO/K1sZfQtq/s/Pd/81CUCvhhZfpjdmSRWhXW0ZpirjGdlGI5PLPDqppLF1aLOREMhlahzDVAk0YDOhBE8YcHPrcL'
    '0+hOjLZReDiDFueIwDZYVDZ6xOBOUryUiM7re38cPIaiD4YC/a4IqkWrkbEqDPhC3xzKe/BRS/R8xCGizloSSEJdw3y/WdY6MjiZ'
    'f+HlCsa4yME07E4/0awwTTl6sr4ebTwaf4oeXL9693ZfQffZiqoiUlE37Q9izk9LN59NmNGWstVpAJC1/Og77mohxK59ZQMW+dc3'
    'mAFWTYP/iAfW9R67nDdKIizJGo8+jslJRqOSDrLRac637e7SUQ93E6YK8WMMG+JBog7a/t0/SYDiordaPKiDVTzfuucFjDIp7gyh'
    'cpotMe86zTpQQ/TSZSg+9NVDVznN6qVYuMIKrp5mtuGnWYkprGYJ83RQNNyj+tyVAg0ag9OHk7Xa80wse1wE23EISoSpdmB4U3tM'
    'm1BTsh1EFaGNXzYHfttD5ustd6DBFhdi82Zxb26ZrkLg5AK+TDkwTnHPmsSqTLlDjS4ssl0iQa2QlfgUBAmj05eLFHpTgKET0yqw'
    'Uu4UKEH0iulVYMaejXnjBUfelA+iwMb6bt25u5HvZxm32uG4NTbyckvbYGjNWmLCWi9Hy3NUoTpLZ9dnDNSrpTLmXkXzP2d5ZN6a'
    'vOcr/025DSOHL98wJoZKsedKYs0Rc5mIzr/n8Z2DYDyKA9HgeDjGAasK3tvYBXquJOue4otDUl/w9UqB3RKiY+ziNQajSbIdXeiw'
    'q0WYfvBJQyE6fHFHia1bgP3pxgOyNnrcMGIhAgDjpa+FgT9g5svC7FHIWpOyK1dpjGBzc3ADc5sHPFae5aXx2mJLqyqFTFG7Igqa'
    'zGhoHK4yS07qKblA+XJH9cswVL4Mf1vVSyR99XQfd9d+ROobxpOcGetF7rQD3C/1fakFHzLD0I04Qi5wbvzPfD9c0bpUW5GXduPt'
    'Yn3xJFu6o70zTkl0wbLb3IMTdScKmLcRVg/A7Hy5MOSfoaX3S/4uwfhYqhlbuaoZPSvaeB+n3UxjEOGFxeRgKAEAbsDBN4lWnuvv'
    'lXscrCXnaypr7tawltacmPspzHoUr/B+bkMj/w4CTaezUrjir8FIDvfytEXSQS+vsyYIFak3ZA5uCxbq02nSPWNrsVZTYBq4hzBC'
    'ZxUw1y54nIgRlFHXp1ccmpitOAzUSENMyQRLAfXw2IoBmgR+HKejXIBGZ2NObO7MctYsvR7KGMM1WvICwBO4vQpUJz7Izb/2x3pH'
    'g1rA1mYccSuZutbpDHj0iMrBqZ32nOEobASdYpm2mASlY/HR2ZkfP3l8fCVWi/QTq/g7klW/Iuk8uWI+LU6m2XFM3+BOyxAGze5Z'
    'MnlBNIOtB+rG7PwqGQ72phD1OObpUe3BtV5QX3g31DXQu5VabaU+rx15duY8JH/pj+NqDbWx01OEoDw5EXmXdtQ+BMZYvQAVb9XY'
    'WTcY2PTdieJWICKyZyFdb7g43B35+mzqm1AvNhFdZsxeMGOgbeu3OLBvv5PjnDsTjGdwgpu9c+d2KprKGB1gg+lKrbNmPnpwjfwA'
    'Wj5fXTW49JwV5l0VWbd0EA8gwnfU5D+8J5RdBr+tfNJtcANL2jzow+ir3oC1fgBFa3P08sNWPB6d3vw4Tk9vTvsnN5fp8bi+hUKe'
    'PG7EB8naX9fXfr/a2j7MO6v1B61+4e6sFPdCL6E+yZ3SRqcKvgyVSUC98SnGu5yuNOxm5JrELSNWx6IpoDVkZ2HhuJtC3PAjm5kB'
    'rVyw0I2BJb3nCA6yC+Ytn7TpqUht4mG12zpm40uPN1N2o1649o2OqkrbMuF4OfoOC+IsZ1udv9GYymV2P3eGt4mg4Dg1nfV7caJ6'
    'UAQdrk0PRXWUjZbppYdWJ930lIbcDMzqddRsNgfmRIfNv5zoInqqLpk2WYqoinOa/kH985zz/R3RMDEswEUYDwDimrzQzqPmpzqz'
    'TsG7q7rlkRSxpuI2igHODmrgrGDdwuYp+MGsFH4ggB/bvdCyYNhSNk7jJIhnjTfD0z39iSOTkShtbNeOXnIdnHccGCg6hBf0fGBA'
    'T+QqjNVPMJqSX/f1jkuyNC1e1JTj0XlUUACXD4KyqF2OS+PgRrII5VOTSYnsBg1uhNRcD+glUm9xwbJDju5DH5pM553OEa9xExgp'
    '8m/xHJtssGk2DM/piuKU+5kxNXSXfXYj3Wej+Tj2iRgIVWfV0C1HtmDyUG+d9htwfaNFSf3yiKN3le2NAPf9SPehIdWWO3aOVbBA'
    '8jvu6emhipVx8PhkXVN9Duyipk7OM1hGCl+tHZIblNoXX0SGpaMlRBuME2InMl9wBJdCiWRDO6OLnYEW+W3wcaR4iy9zFGIzK9Gy'
    'e42jzAvaJpwyNwyJLIWgdkGXLbLjrhEW3VS220wT2+Ir0oZTPQfI8DoDArKgM2D08rt0x6NZ8bUSI5Alai6Ax0bU/DSG/opexAMl'
    'B7u8PZhCmFegVtdzm04vIa4DdyNJQvNf15UQNEyJKqPXDyxAxI61X2DRHN2yA817TkPeSI9Dq8dszDxUjcQJmYC4Csbh4EikAyJo'
    '7WjFG16TGEO8cgTjuYMOdfBIuHIgGSlvWYyqylFV6jj1tOparXOXk1P3VXPYswcmd0I1X4cjXgu8vNwb7xQdXT9qzMXJaMSf1HUC'
    'vkajWtlfgXj65wPiojXIQg3opf0uq8Va9K2AZmBZxan4GUmstbLz5sHhYav9cHfl6c7NFz8QORK3p7Va/W66GMRy40jb8ElLeip7'
    'AI2JAWsAHJni+pd+09xM+qCdfD9/IDDdbGl7HM07zSLg/mxEBZVC/x7PTpS1dhJGLCj7HB03wYvns5MTyNh1US6x+ybND7veUwHN'
    'Y/5ebygRcdCGEsAOSax/+iazZsqY4buBXruA/TMa8WgzZiMCFqd5qa5/Wn+y/uXj4y/X6yhybc0qLTlKHeACz8BuoGEviYmYxCv7'
    'EM3ULBMzzb1ZsXY1cBAoVAjdyRMjxPveQggNuA6egINYuWwbT0y2dSv7Iy4gJ6SfgE67DmNqnTEUtF/C2M/f4FDQhaYhxaZLgT3y'
    'ht3bi8VsfuW13uO3J0lF4keuRCiu0lLXONGmTcQh4Cpa9nizolIJYMHTgZuor1MY9cHRt8e/eM3ks2NeW1IKDbz8RRB26WG90j5c'
    '2oH20z9+e82HTTOHi75/ZfuEONuyOm1j1PhbaluVCOGeXIOOwftBUZhaDnRX/b90ircZOQgHnhI7tzXbPCxMeA6oAR3H8/swz66c'
    'rxaWI7tU/DHzMY2SBPf0igZRThGcoTnuj9N92iOz0zNOhCkZMmwqkYY9SVVTyrJGealj9Saq8VzPhFehadoO5ol+ySJbNSupGnlP'
    'g4UOYSVt3UWAhok4N7TXFAFA/UM4+nI+pT9sNA6Uz0Q0Kl0xgZzxA9jrlvDWLfH0aKAeVWDR7jSKp6bn0kmzewVRSC5tWSOjuhvJ'
    'FyIK1Cs8Q/azb6bDQTzs+aRUVV8a+NXf+Why7jHajPjqzgM2gYUBLE6FmAQh4USP4Dewvg7gop45NunLWrQxly9Hno2a3BQZxiLg'
    'iNnDtHMjzqWHN3hw8ARS4QlX2DpsGpF/15P5SbYXI/uTOkf3ApvP957p8Djt4ZrqxAQ1XOE4ZkfMRTBnVtUgaQAz6gc/1Fl9QH/p'
    'Td00Zyb9r6hpxndhpVLj3af379e1p+DsUfjZdDrOYa/MddwME+K2MvNYl9pqT5PobJKeUNmbKzsPNp62kp1auXxjKa120jdi28yW'
    'zabNVumEEFTE+DPsF1ALKtsrltWX1rJaLLDj3fuHD+vw9T38vu6ZT+P9pR2d8QbXNt60NT64Hm/A2HO8OX/a58rpAZX3qyoXa2q2'
    'pZYhyLnj+Y7Po2xvUyIISdvbkkjiAW9oNOACFtY0dHZZX48Pe9Qh/mma3dfRwWpWSKmuXHF0gCrFr9V4cssLZDbinTPseTVMDke7'
    'yudRkwVGjn+XGZC+QUFThgPnM5dpuWh/n+r+5QSKTGWD2Y78O6k+riusdbgnz7Z+ODo6Up8U5KkXL4C64tRFLeRC9NuC1rGwVSyS'
    'B6zOBQlN0Jerqx17kHD77LFx9JQovTfkHvuMkcfHo/pWwdp9bhVtQzcOQNLgFlp9YQyHoidz2lOrcfMh0Yo6D5Ct2zdof7odbTIF'
    'OdtEsDQml6wKQyvoHdOOp2ePKj4+4hYuGfb4MH94sPbwY6cOKYAeHhRmwTWp9vRsslNbXtzOsjn8ySPlS+cuLEcn7qfirHkXkDuH'
    '+W6rEQoUPxwe0O5fPewcrK51doHlILpCU783zc7JCpG7w7Pqp8Kse2kXTb4MBSAkbpr0/8VBlR7yZzSrvbvGAljQYXC3HXd9HG6F'
    'FGDy25FBABFJyOv3zc3hjb2JVbRIUPrDw/rhTavulBy6Wrpmh9qxMYbxCdhurk+aDkZ91WqJC2a3d5zaReOi08zWcXJm23p1l1ZN'
    'HXM3O0+naCv9mQD8hn56ihz6Ri+7NHX0w7MHwYvJDt5KVoXO4fqRe6K5UeQkKK9nyuuVyyu84ELpL7fyyB/fxasmZue+GzoJ4KoH'
    'CrFsU/Wn6fDOo3+HCnga+CIHaa83iSjslT5TUVyvBa6ul/R/w6F3IjiyR9XXy/UrCXQaQWbmAaLDtSgT30vHiKfFWueTQUbi6pDJ'
    'pDvhpqIfgJuUVQW1ok0ccKIdbBOz1jO4D0wljXnAkKEafOpxEH36V+L1hHIMNxkLadNBoNaiDkdDqf387/+7aNl+/vf/A1Hg514/'
    'RDJBJw78AQMz2hH98qr4D6+6sfJtJ8yhZHSgwdTDsB8bNJZrAB6eSl3slLG5pRlI22nqcKD52UCwdgc1VyWOLwGeovXOCJdzIEj9'
    'iLsCWLvZhLrWfqS1FvTPLJCDHztNbhfUFdpA1zqZ52JCm05bf0BSZoNRyjssdlKn4x8bhfKJNGmD8cfDOz5sDYi1oxmkUqDSeopn'
    'nGI/KmJ6+SiT/3FxqxgAFGBOVlsro9PMubQjKszNUeSVYmJWSFlUVMsbTLthreUIhv1Hh2G8cHi9sUHJdxkcSzKRIej9fAlNMmoJ'
    'VoUYCrOEvhTWsPJhyusc5jfEkd3s3FSSoJvgXKiXDwa0YgHjpjoG+u7Gpzq59stn8WhuOS0ovEyyIeGIaMxkfLxzVC8L5wF6K6Tn'
    'VxMaQjjbQc1rHY/zPodBXTlPr9piobii7DlbnwOH3QdROHGFxNMCylXB77L1w9ra2uEoBhL0Xufhbv1wxC92W84jx90oH8BmgIEJ'
    'PddWVXZL3AssPygP/ihQeHoD7aObgc/PTuR62ZMfCjhjtPaK7C7N6VqRzpu9LwuHq+WJQ5sO9EVHpgnJHKiPR6UPVmqdG/xj+J16'
    'eTuXu2Rvji5KbPnB4WW0RuJbG4u02Nr75xdF51Z9zcFcrJjjaqQvrtnhhXyhoyrclBpPc3IhBW2GR4PwC7Xmw5rhoi6o8gvWNSqm'
    'eSNa2/CtVdRcZaWIidT6YaX5cMUvRkLfojC+pGCgQfqwZUO/XlfUZNosHVvc9Q4bPYb76YAzyQLVQj1H33qH91hBMy/WX39iw1ir'
    '1GdzXXmAekd+mRujVOLqQFHQqseHzUwNsG4OqaFJflY/bOkgpBK8zjPXMXBoVUW2DpvDntX3+HnVsX/qSc5G9pdIyW8zA4pGRchN'
    'j2JRiR9s7Q6BigXWxNVBZ+jjdb4cuG+iUB/tg9iIqRYMPB9c+xnmkYYEyrMAFHSYQMUX5YPsshm9QFCeKBvtHoVRksW48YPoH6sL'
    '/vnv/3HkDSXCmisICeaYtcOOr2oxWxV+VWJDn4AMb66FpTTulAEI5brZyVNmJtX8Hhx/Bo256KBhOEuPu/wvlRraGnp1HF+ZCjSW'
    'lVkFODW4ooO02NLmOBuXgzikHX9RHV+9dzr/peUuLQaWta/6DFUST9KThkJQWlaQ3sFqlG8Rvvvw+kVGO2cE/3X6YFr8BY9tcHnQ'
    '60+U4/O7Ze/cQFzkDGwV9FrSLQ7KFccoZZfL4mHn2cMtA9VdGB2WO4K8bnbumBfTxHm9ni2Yi6LOTFXeMFtgOsNzcaW2sEIQjaEC'
    '3yBAB/8axhKSkNX+AYX0TblgveGqCoU2HxbcwKcVEBcMeQRGd0fmxHIJ0pqU62e21DqusxZKrHnc0Sc90ddyUSxX0zTQHrH3v1jQ'
    'Ktc5dzqpMQxaFlw8ie+04y7sTU/iYpHOJuxnm6rF7hhX66A/p/Ac4MtaWwzbohLX5Zm3gOHFrbZjB774IoqNVccNm1AQTxTHu+21'
    'iDjL0W4dII9D0aueyU2Jzq+p5+CswzwBoNf1itnxOUVPFOODzA4STuwz/RSToKqW+mCgP9wXOFDIgCbXZ8GBdvj/8oe1RQYyKhgV'
    'FFuCAOxgTW1qY5a6CGGm178wtUjawIUHlZXMvnAhQQtbk5cdB+n7gbuw6JR1XkLAMDLGdJxTEqFjdCa2etCTG6QhEnwYxQEEZRSy'
    'qCdzA3sduwgHgGwf3fzxSTCL9JbV1mK/JUGy8GsrkkmCy9ezKQ3i8Wya0sjYLtRckGCXMq6YG7XAW3R4ONWGMBglix0xQmGbYIWA'
    'FO6rZq1Tah1jTghDE9gTllMs8+UI0J+ArwCAxXMSKw2wq5rNqz1339nUW/hX4+npu5SPFU5SbLP7uVhQCNVhcETT0KYiOvrdk3dV'
    '3eIvQXduPLcUEzqngausVp1tcwphU97IXQY3z4eMLokeX6g+ueSeZjPRkQqMXHNIRrUweiPXBB5Nf5vZh+5KOBguRTeNj9VteSUO'
    'LWQ3IVBlnvV+pOaNptiNce2YsaJSNrYUUZfvO6U+X7KNQk2b+MqAGjXsCmtYGtkwd855MupP+39NxbS9SAzgqDMEBioVs8tGjogN'
    'Z/ajIXV2U3qGRrTKnrNuy+NF24XTIlfIm7OUGIspfAf42lodHfItNdQNnDx8F4Omx9jLLTPkY2MWht/93ruTMHqpC7/4umdsLQ0m'
    'GcfeEpvZdaNTtJwpW9CKu9EiLyOUUOFl5HMNDEmhE8VALX1eIP0pR0X35ITLkYCHgX9mwt/3UBOphjxwgOZf+U+TaRzqdIvAUOdQ'
    'KzEilKRTVjWughkPHbMwkoyASk0tm+RjpAOaNuRecqfA1GEuRgVnrqGNAKBF8givDpufWHV9Hv0T97MePYweba5Ha9Lrh9GGOn1R'
    'Sg4oH3vK5POopZkQ/IMSb26u2wkZqsEi5SnMTWjfTFL/P8TCeXhwDqWBtXEeyTNcBPDDU06Y5WEsJZM875+OgO5yXfBwK/izBWoa'
    'hxpE0qPs92tDBuzXeb3u4Yab10ExgZW0nMLhAaxpttz5O1IDaXowGgZrkGlcwEfNj9gMVKfGtPScAAsocP3eK4ZwYJZiR9YmBAZ1'
    '78Hrom1ihYOjOUluvui0IDdVKjo8CY0mm2mG8MJF0/zQM4Abb+GaqGO7TaWhPTfhXOABf24KLZXOKjDF3WoI1Xac/aMZQl08VQov'
    'qtLyHdD0Y0T9l3XTzIVf1YoYlr5uKsspbRSpURNLtRQ7z1AJnKKSpK5J4bXMJLW0RY0Sk/KaA60pCFEMh1fyPC3pMtciEiji5sPd'
    'ehtawvqutRUSCxpaEBpaYDh0AyC3TT5zyaEbZJgA4J054+rCkDszC5+0ig8fJH6zAgZeLwSpmK+IZaWw1bcXK8IYowuFtTcQgiDh'
    '/EjbqLUcDgJW0Xz5xtba4uAYDQPgdc+y2zMJF7dDtvamnxWG4e6tNfx2XPP8zivbrhtdz76XcY8YxffEFNF295zySNxhBdJkSPT4'
    'rynIG480+B7GzyNKx544PfHFz3FymYBjbT6c5wK8mSsf0RC0GY8PUKJ6OzxbBayacN9BSBUXpWeJHZ5FVBuy1y4Tq2poNTbA/WO/'
    'l8cFXmKQXMEvWG11BXxwPBEza4nVIIpFStRgIR6KQLRFwxcB1IRILPFjAYDbiTjEI6IwOEJF9Dzr99JvwN3UPe3iu3EKd9AH1z6L'
    'ospFAcNaeXBth1n8qef3MuK6vzijslhHzOeoYpmIizP8kjnT1/0JPJvx0US5AYwcso6TU4QgP09zXjfjVJW0iNHUpv5Lz2Fs3hCf'
    'Vx325j3kfjmoAEToTZJTEgcnRZAOiI/7RPryk3Sy24S8k+96elEMUg7RuAoVAgtrSYXZuIy+cMJyZ1gpd223SWvEYbr5yt6KqjUd'
    'Sag0Bs7msakOg2o+TyfjWTqKPZU9jTcT1HTClhYy0SsvstmgB+tzXl7sKMwj3I5WYDA7mRCpy3OaEzlc+SSQkMEDEd4NKIU3rxWQ'
    'NgxkWR4Sd3GAcEsW8oJHRUIinajLC0SWdnTSvEyPz/vTD+kggQ88K3MRDkZ5UjE4PgFjJKNXBtawFvmi9zWXBFV3G79+wCrc69kP'
    'kgm4HzENLtVidwwsdwXVyEYKLxXFK3D3xlbIJiuNaEU0RL0VGIejGQpPl2pMbAdRyBeiRKvgHknlf53N6MOahKpOFKeCdlHOyiGw'
    'JBDqxKpcMQsBFsUG2IJjJUctIgqlghWqRyUa/NyCFfIjokZnk5ofDwxgxQoo1QO+OMmOycC/cQ0xQzRAk1g2Fi9gFsaotpUzi+MT'
    'XociVBUd3QlDqJ2bKSwtTmyIO/HbWNyy6gxo8VZCSzU/1WHzwmKOl+LKS3HFKeRgDaUCM26ClgURYZCeTNnd6KKfXnI9ELIeRvx4'
    'Ph9/OsIMjF2SK05yFSTRc8+Wbta/jjjMbq1P267uCpu4HNzbfrLhur13uRdgQNCFw2ptgJbK16VQrDSVskKgbnChWLxJNRx5MTxB'
    'uHZsBkWaKdT+WYAz/ooyK6c8XBzGUZvLuhLcs//WIDXzYNHO79lm/MNwlfw5MkgivwxZyS+J15pFOVrSqyAUZ6ktlDe/OK06ko8H'
    'C3DVBudLINMY/8JdCQ/OF6JNWcq2Ojh3UEeU3XaqcBAQQ5IzRAhxidNEeDhQXxPQrXQ4sLFRc3wF+jwc5wrMyU51DM4xoaVCtW4J'
    '0c9mgIbtZkgPxNFaL72ocQUjBvgQ11NwxlqhIeXP3r//+KeXH/Zev3uLE3NzffNJc2Ojub7Z3Phy43c0fkjw3fuvn+2//PjdB4aM'
    'ZQ+Gdqs1SS6bp/3p2ex4lqeTrmpPaZW3nifQUv4lnZw/ftKSS641Zdxa4JNbPZqpFtEhKPySY2Jsn43HLBLpMLX9djVMm9sGqL6b'
    'jF7LMNpXOqywQeQ3IL/Sw9dv9/afvXnzcW//3YeXaH/YoPYoW9PMaxkcBqlZBUuIQZb0nqGVXrCob97t7RtDDq8Hom1Jxv241qJ/'
    'W/ypVi9c7fHuMbmaZgkg8kZhtImc+BMEwsIz68ggPaFaU5aOn2xIk5IZtnTCCxZ0LwBSRwF0KHxNy2SQjdnlDsuIL4MvoGEvlu2V'
    '+Iqo42cV+CdtXlW58IyTX1/TcMTFz0S0G6rj19pfnKW0w+uOJN8vDqnCUfwLjMXkVa+twI+MZkqzPurl7J4BBNQBB+LhSHq4U6Gm'
    'z5hfkm+MQkGTDLlVmCbWcjO7Qn3WxeBfHvH1gPEO3CPuiPhEKMNek5QV05x+3Hv58q0R+WLtZ27ycVgNagKJPMyBsvd2f9oWmFEO'
    '9cjR7IBMfQX8DOoUAILAE65N+0Pi3qxKSYvcNWVjIZXGvx3d58wfZqO6GePn0xGLbgbYEKAjtX6+RjVbsBm/d3mhd41SNXIN4e8G'
    'AFrpwpADCi90f78TF19DkYsTbNRJJXitLtbGd5xID5tGtPnl+rqF5J++xrFH3MGSDE+g336yvp4+MpN0wjLoNDlmxk2WCt71iOYq'
    'aL/Mvel/Bb3RcVjL0xT6Myr1T2bmE5327/ZfwMNMLl0wlQLQdAnsKKBItSOfTj/+8hEAp6OVzehtdsGfVjyTR39TXTTcqqzVisaP'
    'MCDvXT+e1w+b9OOwZ/+2OGwILNScSdnQraZV43udxvinSc2PV6GtanA8Pwn/vSqBAFmFSwsmRUpVCts4euCIaSgRMH1G65f19kMi'
    'LCQL1lhUouerNJkECTA+f6H1Dxyk/RfQrKsF05yPFxFGB9mpGoQIyfbfemYZWPX2U0jZQhquKgzsz3Z0SWIhg4zpEYSAlayPURsz'
    '+Hwq/aElDFQbdgMn4p2likYmr/hgN9tR2kGSHHohuV+PTjJlSs2huDdFqQIiyUvUe41hgFYGS1sC6ClUNq3Y2knSB2JUCE9vt6Hv'
    'iz8dqZxn6AE8kd0rVDVTmHpK6xGLaXZ6Okjj2lmSr0mzqAn377u+1G89nbx+05ki+5OFYD5PFh97n3+koemsUCzWemQOrQfX7r3J'
    'OQeQEbeHMZdlBcBjbOVP5tgyx7uZZaHbK0zorIfiizPi9ojTd6TOG6XwVGGxe6n1CG3yJUmOkWC8JAEg0ZGGIYgXlsInqDkDOCAB'
    '5l3t+Go0PGbKNUVhYu84qop5NV64LJr5bDhMJnzdWHvGhMgshuwkUoi3r1VpqG05zcLGjkkQpCJoB9GXsCKwed7KGym2/NckaYEr'
    'xDFsy1yM7WwgH1nc+JZohkEklmKfJwKvPBvpAeRFWsLIIor9qBcf07RhVswZNrUfsk96qjJjiZ0XdGLpNlmh434kIaU4UkzCFqwc'
    'MBqhEMaz4wEHpWLrVfbshzxhFrXE4G0ybCMYiBJTSxWwbSyLJqB3KFlpYSFzQNDQQku4MAMv9MEXYn7++3/UFmVW+oYGWCUeFxhI'
    'QdGzSSpcH/sm7C5si4kxsPJnifGBwMEZH9LNFWsxSyPvmFHAQGNXv2U/edF/eOoLPnoM7cNhw2qG7LREEXDDY44kZ7jqkwTBoFi0'
    'U+lrvztIsaPPliQ7e3wbXRgz5vjdTNd6ZXIAzPma+RouUJ9FSS2jiC2d+iSaMyqJDkSJQirRS/iLvcSE2ktycd5a1KN0CNmN0hQa'
    'XHttznoiGj2zDzlclV6inhVypIZQVRO0VO/1BSiak9C8mYJp853V/b7pLZaXZByaCNMXCbBglxWUGP1slmvfNHKdt17dIjNrldmc'
    't+llCmMCQwecJgPoGLhe5ZhSEmAKdNvtDNYmGxZolGHERxrzp4QDRIQ7nYTshxOz/UC1RQlbdmqrK8KgtRmdNJMLogDwDKVdO3Em'
    'tkF8UynMIAul0P8XJPBVXrxoVfPHPBvtTrex4JjNpcMAl5TUOGLbwGyNsjUGRAIPWufksc8xT+yS3Amkeq95NOSFcfHlkmEymhkF'
    'eoH7s6RyqyxOFeVS1/Fw0BVe0uc05fLYKmUmThjX1Yx3/gksCInOojFsJoqr8QHK5NSLbcl35pL4636OOM8ISVs8In3JsTgCSu9F'
    'uWpGqniLc4cDQHdwYRTnHhduG2iV5sJ5r7xJEPqjoGHo0w5hlVxJFmiwxK63zP0uI2MiWNBlchVy5d4Q8ETi1JAigGNU4pnvyFq1'
    'w+/+LCa38VEC9+na8Yes1Io7ck6FMnr9HFu2599HFJKULyxcAhqjihSlTeVxWp6gcxEylnapMx8cNuLWW6kiJjFriQwxs+FK5Haf'
    'TbuZP+omctXIDICyR4g9okPGS4UmhsFSMwDBssRBk+lcD0IXZoCu3ZHKhVqKte7ZJBumWd6ExfnuBVO9i8XETkCZQoOaZBlTUrOJ'
    'k+aZ2J9TQzSZ3JrRswcdhRo6aABu7tWMroXGcQO2qBg7TtvLe1NDYrVGMI24ZUvZZUvyeARrCTsXyyqSi9orWNaa/LlI+z0TICmF'
    '/RBfrVr/cJIkSpdMPt0r0rRgeUgfFlK1YuRWhH5xO87Udttg8N6hZQ/22x4wiw5m4Bde1bR+6QPu2Ou2J/4l+tatde/bTrJe9LAm'
    '2OhNEd5K5CMIY0e77s+YDON/1w8t7TXorgkWf5qpyEM0W8g4Y7eb6L2iDIZfjtEE39b0D5LWGzgqwb30JiAE+RP8vq/WA/A+B7P2'
    'nhZZP08FUcNThE4acFM03ieq9iowAEIMaq3aop29paGnM45+riRkYvygnPkMENwv5jX4LnKs78KFx/ye6IlBfUnAwXKNnQ2Rpaue'
    'CZEl0ZTMS8RHbNnU6HrxGcBjWnFyy/u5KZ4mHlcKUBOVSjc7LKZEfTFfgw5sMDsVHE/142L0Gy5MFWVeQWqJJBox1gCkze5sAtPM'
    'fRMPaIHKXb1bnNbdNdpegpSa7LON5qpUdZaGM8EVh1n5HPZybdI/PYOqbDKCi33GoWKjy/6I+m+s3ozNFnP/msJsp5h3C6oRRgZ2'
    'iTaRFzO0rhgHenh6qmo+96p0kFixan+lE7vLw0UVnZJki0uV53DqpeJeDPo0qB/o/IihCL6OuFftiB0nvkdosYb2V999k3K3554u'
    '8vtJMoYVMsc0k1FRk/5h8ine2Gx4pUVrtB8kDcKcuJBl1aVphNGq4rQhKE9ThQXO7ymqIi3Ad8eyYGN/yOrwuMbr2Bsbmnj2sZhN'
    'effdklEGGdQgMY5XuSAFN9ybV+yS044OajIZtQ4vybL+a5Kq0X1QmVz7qq6UN3SRkUZkVWIYiZVO8vMoOQWXxNdu5i6Eaa9Q3pBV'
    'Dq+NeAWxU0nmqhBKyG/u36+8mgtujIt3t+p/ecbxRa1ewd1IsyRj39s7ATGiFtvgoOvsojSbmvWCCdCSgqtNVGgYSfyuF1NXnjm2'
    'HflVzrgR/39t17bbxpVl3/0V5SQNkg4tK+geYCA5EhzbCYw4jmEpY3SrPeOiSEoFUSyGVbSsdhuYp2Ae5mEuD/0H8zKf0X+SL5m9'
    '1t7nVhdKnpl+MEyRVadOnbPPvu+14cp6zRNdqefs0PsyGkr+YfZMe++CSVCHYdtwi4q6olZN1mQczND+VcEpamuYokps7C5zHrtb'
    'P1f2uvp/eGySsmrPbnBpq0z2pd1Bo24qN4XbIvPVtPfbSZjuYKZLvd26QdHmzKZ3sxfuBIz1zdN1C1mBYZ8G0TLfdoR0yQeJ0Z0q'
    'bkEFLVwyRjMp0iXDNNe9V4w3uELvEmZdo74ou4bU894ZpU4Outz6VZqp0fvgRm6PHN8SikFnhmc9W92fXN/H/8KKqgoGNTI9V2s0'
    'djr14tMaDvE64Xqqg4J4S2uOwd7zC4gI9bGdz1xzywqPojY4cwaGjHzhT0E5n2vHzwKF4zMOPXgnT6bHrkaJgyoMVSzPdaAFmbmm'
    'DuV4zlyESW5V47Vi92LQJdRBIT0cPpRCAxWcbQNlWYQ5EufiomCCt+tTNJ/NLJX9Yobn56oNsKHZJiTfKcM9/um4N4PHrf8gyj3l'
    'lJCV8QGDHe7gb2YvzIizYqM+efr8n75/+nvkSlY/5KfEG/vX/1ZHBU20gXv+pnAQum8fTlwj2U2BRsK14qm6K5GbzEoSXKzdLWLA'
    'JuczwB9OA7KGc9ZbIS49ZlqQUjI6KAyTKgNfHMtHqoanOzDfrBl/pmMVdf4lsJvZZKqkvcRNoHIvOppoTLhUnsUMA9snNjxasC+W'
    '4SPP3ucAW4oUNlnaoxn6cTYyCcI0RdnaRX2+vQ2/248ywkk/2hdkOrzkEl2GdiGDHyD6ZbNztuELo3goFoB3oszcGi2hUxJRaIrq'
    'VVnWwyVH5NIt2ysWjxJ8OpzTrfOP49IXuh6tsUlj9n/+c3b3MiaGkXtPue7leVmXInuQ41dUUXYXpqntEl5bygDPONic++ISxRP6'
    'BTavQPgOIYFK2xsYnFh75R5mvx1lL4a4naEmmTj6Ufm2LHjySes2Rc18hleKYFawwbtECIm3WUHhMPnn4Fqco+P7j/P1ROhnWpTv'
    'ZX2SqXKzJv2b9VD2Kpn4JJm4PPPkhiEaL2H1O1baZ9U4o/1WKY2vlxk8Eq0M1TnghXYoXOEzDpiydpROLBW+LGZhT18eYU1ksA+u'
    'gGnwerbQNnllQyQPxqorsCp3aFDFqwNGVL3UucoXTlwYP2Z9u513U5bBg6flmLJET3NN3RpuOtMIOqUSitjNMSUPDiIqFURqU+ok'
    'yHA6ZVC5PJ01ZM8OPDKc3FlJEBItUBAOhKw2fQUMmi80yeJCzIJ0To4X18Xqs4NntRUTUa/KvtrNLovlhn5+9xwxSuXxeO/ltdoT'
    'vsfUFx82ot/99S+D0UcVfubdwaFaUCPxOpZeeihXOnvaWlPV5Yrze5t9HCd7zFAolatLzxUAHw/jX37+XLgyKpY79/sp9tNcjd7c'
    'VvNHp5RnDycHflyII2faX4oFgc6Mz+DGcqtYWR9lwsxnE1QLTHMG92TVFKMv3XdmUMoj4loRPkUoNnJXW3PHKr92a1GccsPXSNp5'
    'V1TUYZi/qEUmDy8m0wMmoD98gI8YTxnslk1+bPUsoe7FF7Ts6IhH58W8/jIe1xbLN2yl57yYhibu+xn6gyv4/pUY7BUaulqCAvdT'
    'd2bKRDOfz9Eh8HwE8maRRtiilEq0ybyy0YQ8JuR1PfTx2lGwJwG/xeN4pY/zia0HIrNKw88IbAFCRg6h7LEi/GB3R0wujWYEYYcT'
    'icMsi53SyPH1SomAoCuEi+jc477l7BTuX3Ut0CWSDiehvVS0ShbW3rZO/mU6lygmmi2LZM9JV2lZmtI1M29F2V6l71EqclZiFX3K'
    'ccQSiB4n4wsnn4V3xGO2HIgXaHnr1EXho9o67xRQ2lcFkuOZV+gqWjEz7VPqfHNrefrE+OptN+a3zY35TkwVeTeK91uSrcOSIl8+'
    'B1v2b6EzKwhJImaFnu9SS8u5YqF5bEpogcT9rujCIsl03d4P0BPW+6rkZVxqu9b3J9RnbdmAb5zs1+ypvhdhfu90ncunCdFcPCKg'
    'x+Fyrxcx+SW58i02h9rvxJsKkxv03eYG/lBCLirt4KHQeAFbMWPSPD2At5NWP1Xqo+N+/PrLv/36y7//+st/ysGxjdEmjGgphj2C'
    'c9vWwMrKVKQF7m7NhVvchpyI1okTZ3aPSaQqICNlxyV2WVNcVHBBPuEoWAR1jN+nUcGkv0oH3dN9Od2sK+EKC9YNhG6U2DfL7XQy'
    'luH+pvqEorKEio1wtms1ypiqU1s/OS2nqCfNtcIypgyKuT1r9ZJpHmAVemNiYZ8aroxaTMgno8F0ougDaq8C/VDJwxEbR2waWey8'
    'B7Ziz2GjdH609q9p78f2b5SQ6GzbIEW1vU1TEHose+lw4i79fPITr+ukSOMfXmVo8IwvPpgf4GPE+Ln18nKq3o2gQVUJlzXHY2OL'
    'X5TgxSDNolZUPV7H5zyu14sv/9B4Bl5Pj4Q842lQ3KH1yi/mO8FVy5lqpWEs1XPciOvZlG7TDl5hKFt0gqDd7EAD0APF6Iy+52K3'
    '9gNhMV00MX9m/ZuB65SpY0Ne4mL/AcgHt9wel4Tay+T58o/1tff08lPRNfnyut6RBeQYv+FqJf2XMgtgTpvcBYRnWqUT6920E+3D'
    'PwTBc1a8oylOSW5SRAxTx+bBW2johCGim7nIGns7LxdOlvQIsDaj4HBPbLjpRrsHssu6vUHQTaDdKk1BSsr4S3BR9lXnek6ddeHS'
    'OHRudM1jewzrC2FFFLTB/aBKBhkdi5fqsrwFOSpdtfnAOj9Tz2dlkul/JZA4THL4wevX5SojO2YFVbzHwbK5b82qi1r5OUIEQYGk'
    'bM9dAb5yCIh5T7Y06nMaFp3coqXFmdgXqVWoCLmULXoH+OJHYu3fx7fWVt69DdgEwdApR88WBdDWyHdYKkpBKBsEg8QPofp7pA7S'
    'oi8okwZi9eZci9Wm9vJp9j4/rRfX2jCez7zK0U2QDDqYXEp0XwKBg/PBWsHm8+4R7/stIma6ZU0SBIPZ5aqGFQxjs2mY2O7gxYIu'
    '4TWCbSJS8ZE+UUhaD9JPFZPuWZSLUdNT/4vKxtY5AAZOtln1M15cAE5rbiMkGPSchYTKqKrKWfCUQcpHpifrzUD/6zVUppgUl7Mc'
    'pEAOqw4UOmim07HSIJuBMr3Je52D96USAtDzhDjIOqZEtbSc40tMLfCPBl9+racIt42jm/D6kStG3gSyYLNi1IP1CpxidRElb3U+'
    'zvwPmkulcyWfVgJMHraFapFl4WJqHDVfyJFV5VMWXTSEK7ge3OE6m9VWHKRFY9q+ANxUtM132l61qsVIOzu/jWivOT+CXkXfslJt'
    'GpFHh5CHTVj1Ell1hbDY7GYhbgpA6VbajE2uxDB8IS82LX3ylciJxSRfj5x4hoNHr6N4SUWhW8qbmep3EMSRYuH2HU4YbLrNTWPH'
    'De6tzi51GZmJjMq+AvSLs7OUQ4mw2JlIphWp3JYwm+dTZVFyBOYmNBfyxVW+nlbOZqCxR8tcnyjclMD1kCg3Hguc2lc6J3uHKvb6'
    'UeHgggsXr+ys2uKZcHCvpL17bkFXhA1rk823gPQiglcv5cy/EWtX2NP8GcEY8ekILmgYwPJjcXamn46AkIgP3yqIo1xSXnGAV6Jf'
    '1D2E9xzhwxxRLShm5SlirOtxTFTYJZlj1SUa9mLa2SwO0I4Gxnk2DMrUNyrXRkYmeIf452f2M7vVuKHY1QY79+jXf/kPbJv99SU+'
    'g2oqXQEc7glXgC/WPcYRUofcjTStJweEk+SeD1cF6kEn5ftxNlssilWl6VnaI4VNTnJjaXIfgnq4jU96+EBeOVJ72YGALLy+Kney'
    'xtPN98XNsDWtnSOYdOYPGmmsLg3vrc930RaUXPm7AbZPxKEuNz+zDbF+wsvrR7xPiyhfmn7fIEkXkW6TaPFoOo0prgBEqJBi8YrZ'
    'd30OLOPg9F9h6rmzLGKfVcQKHQh+4IXum+IUVUk5/XbgfrLO9hK//vN/BXthckBmovvesh5Gdg0UMF4CtR4Y+l5+qLrb9t0mPIMh'
    'xWS+RqGBbDkbzUysblBrSz+KPBlc81ABGRjkcYVDtycRQpw2Yysw7Pq1I/u5cwuBVuojTcIvNAygdf5KzOMGXlasC+jIcjSivYg8'
    'yKOOZY4SIS1W1eotPCG7dCCHbDDc6Br8mohcXr8yTwnLS3XfMPyWTfGdjpELULmMZ2TWy5tMDj4n8di86Bm7z28wP/557x7meO8e'
    '/d9uOvL9yQnCXG/eOAuKcGYt+2rsbDBCmLtra7X1SA57GSHImWVnmafJrVjcB2biQl+rGM1zzOdaQxDgYvlZH2Vp2xiog5qY0aY0'
    'j8lrH6O2Zyf/ePDm3oFDq3UB/ZZkFI4QXBhX+fU2z4kiEP+fPCQxZfoBU+J84AgTWXZzmWCldmLDThuraiXPy6fgHrIPOB/Yjkus'
    'NF3lClexOUWuD96uQewapjOpw3HcTm+WeDLPE1I74x1alUgjqwNuY3tbPFgzGintYKQ4n7tDhbFLmJe5ZbTm9lHscf5UyPv3DtCr'
    'Wyyu5t6hl5D85UM+Izu9ZWqZYNTYLKmS6SCMPbV8HmDCQCEoiSXrArlraNei56jsUCfk5ICORvM/qVJQLMcmpnlgRL292MI4TItB'
    'TQdTiSKtHJOF38upmxZlNReJN9NVzhCI9tY8f2FY/mahI3Qw1G9HHtKxsXvEAGSI/8pFELZv4UWvegnQV/QYaA43xosym29aIDsQ'
    '1rw7j8RNJPvCPz0uVv7aOCYN8jBimKrny+VqyM6RlUJ8mn+qVJAiS90nHI1m7nd5tMTuTY1YvjDSHExwuKOa3LTFa+KQ/OMd8Wh8'
    'blO6juPWG7IDP3TnYVQMy5tPoihuDWvV5u8C9wqya/mIPFN5pW6wQ2o/DokzTeaJ0KW3vkacOxY1GUK3hzdJLtxY4fwxQArpH6WV'
    'pQCZHqhfIaNzg4zei0J+J7tviGWOZuv4/+N+gnuZuU1pErry64BCmuZV0CO+qWZbOJRzeiuPcXC97mQY5CXwRWPrnqpWSx/VQ0eH'
    'UX6t2DiW72oF5GKBjxUjuCts53BUW1inNIniJJZRMnFDYmVC6sPiIKCwomf9TX73VhRJvWBVHKDEtPrYXoq0HREVOaG1o1YpIIbP'
    'YkfDqPx4xUIUfvR9FAxDsiPMS5CpfElLrzsXaUL3SDeZ/LicMf0+GD0V+L2IDz+WbA121WXGmaeQyUDMJt0sQVH0xDXSK8bZ6XkJ'
    'JVZ29Yc4nWmsyml+q+SSLa6goo7c97Ryze/NTd/JAuGR4zsXncZeAjGHV93GJJkUFJKDtnBFd0V3tN4P1VQwo4Yr6f59y5YTnfv3'
    'iE6AcCcPzHxRwj9iMkUMg3Hk31pwR1QbxmGlMEOoAJXtwC+GQ5/5cTdv6reNB2Mn3fGrmAKJcH3/Jnox1ggG2DGH0Av2UMwXLB6f'
    'PUHYJ4971XTJS9osLvRzWz2lqPB2lnLcG9umVRDCk+m+3ey/v8F/nTgQ+KhAqswi0iqDkG+kNgBtwVorDWJDi2GAlTpzFGJeT/C5'
    'XHgtImrSFTf1z3/6fsXYojqc2r5JPBCvEwVr6TjarLbxWnuvODfKin5CU2CXTmOGS+S2PSvLqZn3P28o8OThhFK+2QOKtdrjSWwH'
    'zvkbK8zaLtI/lAiiMny+bJzTos+r+cUHX5FAV5Cl5GHN/lSWl96Erk7Xpa0vVH6nNmIdzzRiimIGZKyFC20MbqVmF41DVLQ1AG4Z'
    'fPSpOhqH7d93pUu8WGp57joXFTJ61i41WQ0Il+0U4pZ+R7qJwCCol1FY12fxRulFujjMCvCjNiPSTabNa77WXhT8/LHbqoy2Hu+q'
    '9IAVmvZYsiz4zCfVUIG7swf2MPl4Hx2RDrLdnd2/g+jmlefXq7IeGiz4fXft+3FmMOD+q+sRG9KO3OODLdyZghxV+CS0KAoHeNZg'
    'm3LIgDEFsE92ViBMVBAR5ERI6KdllWMa9hCVL8AKQtGi07bo6PF1+BZ54Ty35gdvIYnXFlnO3TB5XOevRTlau4/HQYOhMkqg105p'
    'njiL7kIfU+yppmWSv1M23u9cnsg1TIRB443Yy8wfHlW9LEBPUuJ8xx1N7++RO1rKBpMEQuYryH1WOam7wZdXlnhtgVkyYq201VR3'
    'MATimrsipWjpv/hg6C5vzampU0UpXmdGvBIJmDHy4xbJDK1gzc2jmuVrdRRcwpFne+n0MAJa0xenOfZ7mEFCBgR4YIVTUWncNUA8'
    'FFUPxkOurtMpkV0dSB2dqUgbAkpPxV0mvO6CKFdVPndRs4/dBPl7JnBhJIbZoaTkjvKbZRachV8C5xi/hUjCkG2B85Q9/FrahX59'
    'e+VCr0+cULOZWmNurjSWXZKQleN1RNRIgi9ffOdc2OaAqq1A93d//UtWMeAC8tM4BUB11xfhWCH7RH2SNfqpWPZELKbSyJlMTp5p'
    '9Qyqa+IovEaY0KczDUH2TGf6rizh/nxSnrL3jJjm3kcOk5VAPVrdwFmQgkM+mfosXDJZR2gtLWBAOp0GZgufMW5ubhGiq0mZr6fj'
    'ACvKkM8tiIEx/lnY5HY+lbySSPHpbDu7khPdKwj8ac9XK15nYJIyMuuVq82SGsdlWS4jXqC5FGylVF8BV1J3mVg4blI7GeKPrpTb'
    'MkVUJVATTWTC/Fah6pov0Hx9B90IDlTN6s/6XpBpvEEnvZs9YqGX5aExL+wSbWjXXZTeSELPp9MqyololRjY75WWEwRWqKosTF5m'
    'pGjjZmhsTTIPp/UIAMmnQlVtFmxwEuTCjDGZTS5KEmlN+9DIvf2jd5c6ubqaOilIoxjpii+7LCDrLdrNCKOsCw2erk04Lb1HgS5l'
    'FSeLsmYixXyWa0anM1RiMoF3T+kcJPEmLhPG045t4hHu4N3y4rh8ZfGe0a2LQRPYLxUq4a/g0dvSIW2yyJcX2rdroeA/7U5ioTCx'
    'v7lXqFnEOskbojB4uJs2YIl/KuIaXiYEfh0qFk8K35qH1dQKL68ILw5vSH6w71kpyQpu0XzHHIwu2+Ued/VoVsP1qWfX2jfwRgUO'
    'VCSWLVX7vhR8nBmAeDFqonQQJkOeC6YwHYU6ZUVpxffY+MMdzDpqBzS/xKzP1ZpX86su5f/v4ec9B57MuQPqqNHXoQeMTn57jG5v'
    'LTwOPpq+ZmGVjuxAGSumY0OfwWagExvAXz6Csr/44LfBeYTEXvj4Vi7QV/R19jImJJr+NSIbDg0TZE6KjKQ4NOoy/DobfrW7m93L'
    'CjFHhl3PGRF/5jeDaJhjsNPuVyOnjS9VUJK4g7kssU7bMKSiq58AFHLURj/z00/bPRQUPbvRFU/fi27QeF685G8fGgfTVuLL6def'
    'GUv5THUf+0vUBV530L4e0N1xEqW/9K1HAbbSbS1Htpm94EJYP4pXs583BfLfKhbrK+pfAEjYU5yOcikqz2aJKq5KS2fp2mCqbsXT'
    'A3ebbT2r97VWAFBkS9aZ95Pe954BE9Z4L2sR0pHMBT/YIgP5+PkMgvGsJN4xX2jfPSrCXbt7l2Oxvhch12Rkf4OD8U3vBmh7GV4z'
    'n5SqOJ+KTY/MpIFfY97XRpp3SN7jLMyi2RMSrdbmAZjw541IQvUnlOtHi8VwsCP7df9MTDR2A1x0QHGFC/ZjXqMqFN46/pNFn5af'
    'PvqUiUSD+GayyXTYjCOdi11hXY12FMLlsAf893DLWAZSqdF9+vwgte5DId4z5W2z0ggk6d9A3mSE50KwnHsqa8g4ALkYZCxkBNJU'
    'RXCQXICRgD/C1kVy1/8Ax0rEuN1I4S7+1LyVDwgsxZrnhAOqvIdyON0Jh4ffOE4ngxeittwFlgFu5YfvkM5a8+PL2Xout98dvDnB'
    '04vsN9nv3ujovSLjRSdqoD9o6VVtpMPGKA4nu+Pexq67Q/M3PyjWCRnbgDVxW0PZDw7VbOLyISgcyoaKUaqysJU43HPoPK66TdzZ'
    'xUiOnV8UHeU1ISZyz0W9f9jFqDRf1HB1XIsOQtZXNPvP1rNrLZNXV7tj3fR9Kkj+HQN39eqwv+gqh95m2TK0mney4U+s/yLYAD4s'
    'ruBGI6TlKMKNePzji+NXPz4/Yv8tsQsZqcC5G2f2p0ZA/J/FcgW3rnPrxRHx/eRQhuMa6X/sfHwSMSDV4nbouRrDRsS04dJ6JbMe'
    'vHGBK7XE6AtN+d4OwmlD38HpE6gsfvtGT216Jb7u4njGvnLFsKpcsb9mu/migMC9uM1jnwZuX/oLA3yODSSUgAKY2TSajboSOB1I'
    'p35WC+pivG+gkyUSUNdNDUZUXhiLN3hd7AUZQBDtQMwPqyE34Jsh1wkoBMgc7xMFl0oduIl38XX220LHiVoc7XI+h6i1mShUWMzz'
    'RWPqsK0+yYJwNk/EHJqoXOPs762x0yczL7zANt7F33s0/gSs9W/EMTusIL0wNYRS68dg7hy/b6OQNqBHd9Bk0bWl9JIU9OSEaLqR'
    '+wkTVvFmjNiBsjlt/fbPbg95vzXkY9B1B8RboKud5CjIpsyL9eVQNNfciswdUz784/KPS2Ki4FtGAtHlAHwZaatClEsHnRMVLzkw'
    'GPWTewAZjwpz2AEG8xl2Olm+O/E7qcnSWqcEW6mvXaUMG3WrvDtJWkmnj7Q2cL5VJWrW6bgzi0e4EA78cam7wT4yYupYeHnY3dxY'
    '16MFevctuxKvN0s2fFe+qSGhphf+Gg5HS8eJJabV5LN5+9JC/b7xN/DhXJ+6oEXpSYm+74b2bELHsQmbArN1Xu+OV6cjonOwNozg'
    'HSw93QmjjGjY8kn7DWNdY2DmKu1GtmVGdlqZnlztLNFiZmQeJE3mBEhxlU4DPx8eBhcT54W4lrwP3FnVTi4bgPK2EfMj/jQDz7JW'
    'rVCs6O/1jt9x5rq4uk7zcoQRYhwawut6VgkfPI7YuL5r/H3nK/bwNUzXbzB3LN8gBWCK0B/cYKOmO2//ju9TGx7qyku6RsCXwen1'
    'pb/pTap4hh+cpuEs1KhCVjsEzudhDgya9UxcRneeO01OxJtEYIkaedoTNfKsWDbRmO9EHUr37zx8UJ2ui1V9IJ8m5fQa/wOO/uDO'
    '/wAXYYsY'
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.11.02.1517'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = 'https://raw.githubusercontent.com/BannerZerk46/spider-diagram/main/dist/'        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
    'zip': ([('Zip archives', ['*.zip'])], '.zip'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
live, closed_at = 0, None   # tabs connected right now, and when the last one went
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.startswith('/api/alive?'):
            return self.alive()
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def alive(self):
        """Each open tab keeps this connection open. Closing the tab (or the browser) drops it, which is
        how the launcher knows when nothing is using it any more, whatever the browser."""
        global live, closed_at
        if parse_qs(urlsplit(self.path).query).get('token') != [TOKEN]:
            return self.send(403, {'error': 'forbidden'})
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        with lock:
            live += 1
        try:
            while True:
                self.wfile.write(b': still here\n\n')
                self.wfile.flush()
                time.sleep(1)
        except OSError:
            pass
        finally:
            with lock:
                live -= 1
                if not live:
                    closed_at = time.time()

    def do_POST(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def shown_version():
    """The version to show. The source folder counts as a release when it's exactly the last published
    version (checked out at the release commit, with nothing changed since); otherwise it's 'dev'."""
    if EMBEDDED_HTML is not None or VERSION != 'dev':
        return VERSION
    try:
        git = lambda *a: subprocess.run(['git', '-C', str(HERE), *a], capture_output=True, text=True, timeout=5).stdout.strip()
        released = json.loads((HERE / 'dist' / 'version.json').read_text())['version']
        if git('rev-parse', 'HEAD') == git('log', '-1', '--format=%H', '--', 'dist/version.json') and not git('status', '--porcelain'):
            return released
    except Exception:
        pass
    return 'dev'


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': shown_version(), 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION,
            'summary': str(info.get('summary', ''))}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        # Stops a few seconds after the last tab closes (a reload is back well within that). A tab from
        # an older version, without the connection, just checks in now and then: then it's IDLE_EXIT.
        global last_seen
        before = time.time()
        while True:
            time.sleep(1)
            now = time.time()
            if now - before > 20:   # the computer was asleep: give the tabs a chance to reconnect
                last_seen = now
            before = now
            if live:
                continue
            if (closed_at is not None and now - closed_at > 3 and last_seen < closed_at) or now - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. It stops by itself a few seconds '
          'after you close the browser tab.')
    if browser:
        def open_tab():
            # A tab left open from last time reconnects by itself within a second or two: then use that
            # one rather than opening another. (Opening a file always gets a tab to open it in.)
            if not args:
                for _ in range(30):
                    time.sleep(0.1)
                    if live:
                        return
            webbrowser.open(url)
        threading.Thread(target=open_tab, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
