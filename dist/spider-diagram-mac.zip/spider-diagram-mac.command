#!/bin/sh
_=''':'
# Spider Diagram, all in one file. These first lines are a small shell script that runs this same
# file with Python 3; everything after them is the Python program, with the app packed inside.
for py in python3 python; do
  if command -v "$py" >/dev/null 2>&1 && "$py" -c 'import sys; sys.exit(sys.version_info < (3, 8))' >/dev/null 2>&1; then
    exec "$py" "$0" "$@"
  fi
done
echo
echo "Spider Diagram needs Python 3.8 or newer."
if [ "$(uname)" = Darwin ]; then
  echo "If your Mac offered to install the \"command line developer tools\", click Install, wait for it"
  echo "to finish, then open Spider Diagram again. Or get Python from https://www.python.org/downloads/"
else
  echo "Install it with your package manager (it's usually called python3), then try again."
fi
printf 'Press Return to close. '
read -r _
exit 1
'''
__doc__ = """Spider Diagram launcher.

Serves the app on localhost and opens it in your browser, giving it real file handling that
browsers like Firefox can't do on their own: Save overwrites the current file, and Save as /
Open / Export show a native file dialog (macOS: Finder dialogs; Linux: zenity or kdialog;
Windows and elsewhere: Tk, which shows the system's own dialogs). Works with Python 3.8 or newer.

    spider-diagram.py                  # start on the homepage listing all your diagrams
    spider-diagram.py notes.spider     # open a specific file
    spider-diagram.py --install        # Linux / Windows: add to the app menu (Start menu) and open
                                       #   .spider files with it when double-clicked
    spider-diagram.py --uninstall      # undo --install

Installing and updating also work from inside the app: the homepage offers to install, and when a
newer version has been published (see build.py), the app offers to update itself in one click.

build.py turns this file plus index.html into single-file versions (dist/spider-diagram-linux,
dist/spider-diagram-mac.command and dist/spider-diagram-windows.cmd) that carry the app inside them.

The homepage lists .spider files found in your library folders (~/Documents to begin with; add
more from the homepage) plus every diagram you've opened or saved here. That list is kept in
~/.config/spider-diagram/library.json.

The server stops by itself about two minutes after you close the tab.
"""
import base64, hashlib, html, json, os, platform, re, secrets, shutil, struct, subprocess, sys, tempfile, threading, time, webbrowser, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
# build.py fills these in for the single-file versions; when None, index.html and icon.svg next to this file are used.
EMBEDDED_HTML = (
    'eNrsvcly60qSKLjPr0ApLd89SokkJoLgufeqmpSoeaRIilJWLkACJCGCAAiAk/KVWa3Knllvul+3Wf/B2/ay991/kl/S7hGBkeAg'
    'nXur6pnVGSQSiMEjwt3Dp/D45R90px+sXIMbBRPr5A+/4C/O0uzhrweGfYAPDE2HXxMj0Lj+SPN8I/j1YBYMCupB+NjWJsavB3PT'
    'WLiOFxxwfccODBuKLUw9GP2qG3OzbxTIl2POtM3A1KyC39cs41cBGwnMwDJOnl1TNzzuzNSGnjb5pUSf/uGXfygUuJbW40xo9jv5'
    'WfTnw2MuGBmcDz1zmhcsHG/MaT55prkuLcUVClDdMu0x5xnWrwf48IDDwcLniTY0StDO0XJiHXAjzxj8eqBrgfY99eb4T9IpfOTg'
    'o+3/+idRHAWB+71UWiwWxYVUdLxhSeR5HovDSw6noO4ssSDP8Zwiwz/4/CepAe3oxsCnnwAkQ/MuPE03YZo4U8cKgWkZ2MZSINXx'
    '4yr+uBTjp+SjELXrB47LOYMBLkxYBp8V+o7lePjoT6Ik91V9MIDPpdxKQm4lsaxIRi+uVEoDzh7G4/KMfsCR0YsE0OgTxQP4pBDo'
    'RoY5HAXxd4/UEXCquIFpWfht5lnfAASclcMYgiEXeJrtDxxvQuYMv1haYHwTRE4Qi+VDjqDVN6GoKErlMNmg7dgGHaXnjA02wgGZ'
    'E/asEIEpFoXEYxx1X3PxhefMbD3z6t0x7eQ7Cmnf9PqWwfXp0Mgs9FfxZzLFUjywjcWlYjkqD6PaUIOuOq1R3aO8UKHNMpCqe3Wi'
    'fKGOvBMuVwtGHKGAO1jEaqdcFO4EuahyAl+sWlKxUhCK0p0g4RO5KFsifIAvd/BapE8K4aMqPoFaXLlY5qrJTkpD9hsJVWocULbi'
    'E45TGDl+QFiF3/dMNzj5A8eVSlzNda0VYSjwH7hMzwCsMwCdPD/gXM20g+/AVibGpGd4hg6s0QEmd8wZlm9Q1rTyA2PCAYEFpj0s'
    'QqOBt+L+xgG/nU2Aeorhh4Zl0O/AfaB0kXb3K2c5gMrPgeMBPyoOjeAKmvv2E4NZp1zyOyn80yG0znH/9b9y3yZa0B/dGfD620/f'
    'XOBqhudTmgaGi2W/c7rmjQ9/OiySoobP/SP3Ez76ifvO/WQhYf50+DP3z9BiHwt8BmJWHWv/Ugon8xc/WCEf57jvnuME3N8IrIVC'
    'b/id++NAHkjG4Gf46mq2YeET8gefAN+G78IA+JCK3yezwNDhidKriCr/M2sGKRAeGpIh6BoW0/p9A9fmj5R74aORMzc8bFsY8EYf'
    'n3jOQsQHvYE2UMOm/ABmOnxawWK6gw3pVV3pk2qOTcE2VIMBCU8YBL1qv09rwTMGuy4betQ8LAosZmqI9NHaSANH84P1J6wcq85a'
    'HVFEHPa0b2K5fBz+L1YPyZwZ9qzgjzTdWXyHDUng3SUn4Q9SgT/Gv0WhfBi25hBAyiov6WQkYzbeykChEwdP2HirA73aE2nFNIIR'
    'LMAX/xwu+l8QUwoETXCX9cYHf03jgSAIwP+TeCBoQl/kYzwwZKNsVJN4UBWrqiZl8EA0JEFSU3hAt74kHohlURWNBB4IiqAKvSwe'
    'CLJQFtQYD8QetF5O4oGgi5osp/FAkst8ZZDCA8AMPl6xCA9gcRWxv4YH8UhDPMg8CfGFzlkOHijHonosiYAE4v5YUM5ggazphson'
    'sUCAaRP0NBaIA6Unl/OwAJc5RII/AxfpOcuCb34AL/wOnz1kYvCIcpq/jExdN+y/IrMxfdfSVt853K+5fzAnKFJqdkALFs0+lCH7'
    '9HdOUFyoT4WJ8NvAMpa07s9k5w8/0/36O9efeR6gxSmC+nNq3//OiT9ndnyYT9zTf87u9tFzQKfABC5d0ADn4XFBctmIerMgcOzk'
    'eEwbqxcQwJ85Ur5gAkf3ASYAyABo3md+YA5WBSY+xy+GCEo50zRMRRGmep6YDzk1H+TbRPOGCDBPYMNfYtgOSvrHsBQ67kpRuUQD'
    'PP8n1iMpQ9a4p/XHQzL679xc874h/QKOkaUPnwB6wiOktYGFGEcXl+LIwLEZbCWhKHMFENYto0D3ymOujsL6ndZ/Jt/Poewxd/Bs'
    'DB2Da18dHHNNp+cEDjy7NKy5gVPP3RszA97UPNApjkEfsP2Cb3gmo7Zo9um040/YOlFONVGZALBnEzvEUtR0QAH5W84gCVeCQUWI'
    'C0swgXHAlPqOZeqsGK4w2zyLwFqSy58AYOHheuLPDYhA1humiCNL6Gq6TqgGMIDQbqKDo7AfBhhI8BuhWh8Vcj8GLhv7SIC2cI2Q'
    'VIFchHIaiVSCQwSFSKkFw5UKD4izGME4QKjS+gaSHR0gNv5HEBxQR9xIDhPTDomQzyAT4faHP6eAEtNAyQQohT5cRtTMk6nKBQq4'
    'gI9dBMYyiBYVtZqZzwgtmnQxXIbkQDbxq8xwi/YESqwRAum2ED82LMt0fdPPzkO6LR1lpxR/YzAWLGMQfGdAAs6X/kzkz5nta3ND'
    'L4DObg9BzMP6sLOtfNBSfbMHEvrIWRgABAia9pBUIR39uZTo9jvZMqHfHAJfxydSmCGUabuzoAi8lq47pXvTHgFtBjmrmV603LVN'
    'LQl5QhduHeHp1n+Yv7KbiTuPic0CutHFq1vEym5mKTJkvpmqpcRICh4lHiUecvhIiIeXeLSR1xCQvlsoG/RHpqXHDIFVZthUJHTg'
    'RcAL7DEIPNk13kh3KbpXkO4JOkd6+Xdu5rqG1wfN4GfOAu0HoMBuydIVedmYZAcrpnc24OKGhZaEvyV2jAhz9kLENLveNHd0Q0uj'
    'SCWFaYh9VXwSMgwXdn+ymLlsJTlXuNBsX6HDoqT03XaCb98BXTSgQP0wd7NJkhGrG1YI5yZ6gPwFJzcA3CvKMaC6MdBmVpBspEjk'
    'kfXuiDAbE0tqgplYmyUOKtmmQCy6ngnLusrtIiJI1sofif6T12FUch3N1vuKuFOyx1DrSpZHyx8KOTF7lfi1ha5EOyvKy0XkqlCH'
    '4ag2CxxE50GCmEgxW/PoDhxyMCXaof9IRnYHpeLXtJ1EL6YfJCpnwCKcgfANMQMcVjuJpcw10ZEIGsDuvSCmAj5NKqlNhGA+ky5S'
    'aFwsJ9hzLBLmgJG7GusYnahZHPci0ZPtYnR+9uNEa3CMvIjx0dHuForCnQYRIGr0j6iPpddNVFOCVzFwHMunvRN5Dkq6jm9SsdIz'
    'LC0w50YSDc6cYLvmkt2rcKbDsYgZ4GP+tkzodfgXh7lD6gvnk8DmL5gVKCHJDD0TdBv8WYAdzEX7aoFKyj6OzTW04JtyDJjuLg8Z'
    'eqo4gjUkZPiX3LhT2Ei3pAUzM4UzLSbnhn6LWuB/t3lKwMIY5VodMaoTM7+wykQzsRKZNDpXMHzoHpXKFOlnwBfITp9ii0k8Fyj5'
    '5TNDS+sZFuqA/fG6prFZBCmv0fj+O1zcrT/RLGtvoYHiGtpV2K6eRyyRTJIWg9fl5xDWoacxo02M5enthHR5uFaG+Higa1gEUN6H'
    'zJ/xjdYBQfkQ8eOY+hpcDQ0G+GC9HTpExFGKqGzDpyMtwvLbgLU4SQmAe/AoOSFF3XNcl5aLxE3U1XXNHxlrIi0rUqC+m+9cQYm3'
    'G82ea36CyxBunVbnIyzpWU5/DLKbM+uPoHW6FnRLmPkoslE5I6nWsPaLtqMbiUFFGBOxTsdbW2WtB3QJ2PEzrDedNdrwBuWI2VMY'
    '3iYEtXUa3yTs070sLcBvMGFQmLNCTmyUW+MgCi64vMmMSrB/oE1Ma5UQXFP05HpGgVJUOAHMKqDZqwVUgJn5gJ51JAgxQiu08flb'
    'ppZuoQJjs8xEQb6FOkSFyhd0xQqg/UGD4VJEmiNA5EPLoXRh+hz8xBekFaogcjstG4TXKAnutp1FpMZYhCqW5vqA/oSJ5qvZdDoi'
    'GSg7Kspvo60DSUrNsj5xI3w5QoxJ0CzRNYNtY9Ht6kcWYdNKrpSUSMc9PdKhgf2TXYObmYWJYzsEo4656GOuikSAJsZjaIcs9MBc'
    'EnXC4SaG72toIfBHIMiypR45E8NFdg2CTrjiMcqRysg8cImJ4YGiHtmME5pg7J8twKtjrqASkSHSWPgEmpf5lPmmr1n9b8Cz5guu'
    'wEkiqbeRNawtABlqlqAj4/lhVuyVcwQwNW+bJN2RUbGZYEPhiqJ/HI8cv24gM4bnsAKtNVI7ZlTLCM0ZkKVYwATBwnwDrsqeMOcf'
    'FAdeqlN3I+iVhn94DAxE50zATZRMmS0HOnnJiqhsBUO+kMMyooVBlwezKxEBP4kexxxMOnsWAL2hFTbutR7YnxFM1q08/FeolXKI'
    'dTUgXNjQskYBpFrLcfj1LxoMoWAsgbJ1Q//1IPBmBjqrKO7pRt/xNDqDZOBIyQwvo+/R1hw5A8K5KM7Rc0sUgQw/Y0hfSYq+lU1a'
    'QaLJoukXbGORlcN2aNGZynlgMfFgiyqfbGik+YWZqwOhZyFxxjuhSFT+FCSkac0GWY4uCNR9nKH3XSgqPmdovgEYXAABAPbgAUYd'
    'sX3jfxkbqwGQD3C8qMrfcGZTthTE+gQno2ElxQoOnLYyQSc7F/nYPUOf9Q0dWHIo1uJ3NPBsH2diAGxriyaHaaCEy4bKA6XQkDn+'
    'iTviKEsNzRoqH5rBQzQCYfpbGY0SxzFPHQFPxZKHKT8N7YOQYkLBRlDRO/AZSk54KaLqJ2nnnaim1Dx1jbRTiBY308vBjTWHRboK'
    '26Z3iyHFnMqReJFjpsipnLIoxdOAy/kcaMHMz/hXpI0sLVONQBTR2H5+rTy2Spy/grjNfM68u4f5W2IeIW50Am4ZRC+XVWyrEK4E'
    'xTtQUAZpO1e0cJYz/OQcJUzbyYVJtaihr9f67OyvtzOS0/7WHHMb2UYixY3wolQT5APoCZ/fXncSgZAhgnR3xiTCX4zqQZ7lTTQr'
    '00S+ySLfgrzTHh0iX9oXynPrYLrpec0damZmZTazINscPGtzg2Pesn884Mh4V84MRFt8oYVSFxNvyNMza5gnVZk22f+T0q2s/pw1'
    'sMHnvpFdqeR0JJVLqRwSR9jxdh9kUSegMWaLe4AspfeASK4+/PlTCK2m2Ql6hEXCU5RQPv6Uh+1zOlLIuGJlnC1vHOFymJiAkbiZ'
    '1Ih4tVH7jprYB6mSzUa+YlI7Pwognke2qZAtXl2viY69RdZb90cQtNeMAGl5XuST8jz9FqMiH4kLsrImLqRkBKZ3ZUSET0RWJMWB'
    'GGeUCGfU/zA4k5IhcrlwOdTdQtEvoa0q6Lcmwh5ZnNASwydtL6k1od9SluHkKsjKfJScMTHSUtdxjfTZwmD5jGxBEYp5eGfBZ6S4'
    'nWgubTZLx33FpplNHoB1vW2jLESa7Wno4glnKc9vIubLKKEHat3emGrbzJEu0wbULRpR0i5AVpYrimU/JtpwjUJ2QjTcDFsShUhk'
    'xBqgWKY5EPytrJWYWXlF0uEhIr9WzTJjsTbES2mtVDEw3X2kZ3mtZmy1SmFNjNW74jjS9ExBjMJ78rTj7WsfrbStzWPcXFMe0qYh'
    'JTmsexjWBtd7OXZL2A5aqQDJkCNHnTqDQVrBTAU35tmKUgUGphUY1IWwYmccDjPz3SvOzHBAKarcPCWf46TlPBFsc9QXwHWGw/ii'
    'jPpHQdEkWdvEZjYGFif6DVsKY1lTGPBZsMIxNZZA6Bs29agg6WVokd078kFscF2k1jnr3yF4njASQLsX2CzIrnsaOcIakY2D9cAm'
    'J+HkiowPxMXX2OXJSXgothp94edhNsIrR0/eZN1NmL3RKJ6OIVtzs2xx4Wz0+3zJv1StVtcdTLvEjNDLMTCJ2XTz3NKYhX1M691v'
    'bIKj5VB+Tsr9ZTEl9/8JxDp0XR0e7hK8fg8pKy8oODEhVxg0mHVgrltyd4TfxhuMkBKbNsQfltf04l1hZTlRgWwAtzScJynKlXkU'
    '5bJWtkyd78bEhV3huzYIWLglC6H46d6BraoH+43PkQM7P637cDO2HXkvPT+2Sww+ZdpT17dIOTd+IF8pGui7wtBCmFjAa4QKqYgZ'
    'fpNtPBmUGbVEwnD3ji7YGJ27cacjnRDFce+AiNy2PhMpHOsechSThWAEw4xMs8Eak5LC8lwN1bXAFIKzINyYfRIvtKZ8JhhVRKFk'
    'Q9yPbaEI9WlDRC6ihtwP5ogR0mbXIuGFm1ziZFbpiCNenedk/lKU//bjHpFmHC2USh3Y5H+ux5JRxW+hSUdxn2xr3F93ZhbMpG5M'
    'VA/G6MPZTPsCUsRNv23xBbAmTkLDPqNs+JsIvqSheVuMKOgMLhKXd0IqF7ZKMnwocbNor6jFzPojhwlHw8d0Y/hbgp9CYqajT/Ao'
    'MXbphF5CwNyf9z/asnuPZyrixijpeABNEryTIv5s+EmBoCaRX/iYEcQ2JzW5WwCUBRoQlIwEiNfZ8D/te1K3uzv2ObtDxxqZVMJV'
    'Xj/x8ptsHnSYNKD0b/uF1aRt4eonh7j1IFAKnHUDjhxG0azFUq9VDqP405UjDen79xHMJDkr+g2rFRbW4UY/dm6Fien70O7hpk13'
    's8uexdZtaDfQhpsh2RRpmBJf6DTgYTZ/v7NZ6bVU80Ox8cFnNkg5a9uVxD/lS6IpgIu2VQgY7u/rLlonjc8fCskD5Lfxb621HOF1'
    'QrdIxRivmSU/HS9L3WJJnRbZY94oh84nwzey1aPA+20xKusVAW2yZ0eT0nOOOr7n7BZ1Y2NkcMJ6tGbOLmfYSNzatmNoaxVMpkRu'
    'UfmkPVS+lF1kXU7Keb0hki86rrZ+um8d7jAcKefNwOnPEuwkBf5Gzh6FtuadZEtNs9WzMofaUiLHn/bDRhh0vADhxrkF4ni7rdOD'
    'yFGlLJ+Kt3Q59BxlB7WGTFkPTnmHxy+G5C9MKsf5Q2vvrwcDzfJpKNjmcI2oeqjPs6QhCYVeCwLvG7FaEv/vyLF0Yy30OKKWjVpJ'
    'Ys6y/oHIj5goQxyhSTdD6pglccjxCStnoqKUUScrqYr0eKacU3FmHSe/OlYelBkXRV475mSY45NJoGY6yj10pdGOVBpDmEeemW7I'
    'IqeIi8Qfkx2VfMqcgUr1kDzkkGhylJqBQE/sN7vEACUUs7IZBkCISDESmc/tOdfCwqS8/D0pUZ3M8XTmBElnFZvKtN02KXTSNZQ2'
    'WU/3IBqMit/SYywV5a3nxuFuiLtniQgkkoigvDmYOgOitlVETRLO18+iUapKcdcByZyTxo/1mKUt8bG7e6dx7c7E2DOiReL3lkY3'
    'JI0g48MemVv367kSMjqfyOILfv5tMjlEIK5lR6ikD6sTZZN4dHO1vc+psGtdp00mOafktptMQlU6jMPcTJDY6bOheeRUXp7ZVBT5'
    'fWzqmxXUlI1xl59h/4wjOWb5eCxb5aeEkyd76g85Gs1sMzGX30yb871h7zjjwRPLf0odF0uhzoDs8X6SfreiKGNc+2HoXvaCzabS'
    'fJdACuwi/fC5XDY5kadM+094/D7nYWIOt80kvRn0dTsGn448+GQoSroT2wk268q4Hj3NN/3U6emIrvc6QRwXz6VNNHyumQ2FhCmU'
    'VN9gYNoVxJ22pJGoLX69WfrZjyKcQ6aRVKrjOlG5/Mb3810ljaxChmNigOX+ugTplwqf2TPQZB6UmHoyR5uJdXX7QWnssICZqI4R'
    'YpBbv4ll4pAVBt5hiE99zdM3rP+eW+zmQ7KRgWJN7vsd/L/J9d6ZuGPtMFXMfLmiUE4fqBLCSCoyWZGaTL4Qzl4I09r8bae/Is/E'
    '//qtwIIdcxRl7KXIUod9fgeJz5qnN2Wy6sVgNJtgLLzmu7CoBWK6QaTjSkAVP+862fxbnGpeP9FMVWz5c1bz1Hgwae662rblYHKi'
    'BZaSbN2Gz5Ds0+H3OYYXBmsyajJlvlwTZn4TUz/tleRM3tdR/Bv269um6xpBHPRHz29mM46wYx6f0bHWoF4Ps08HDcNk98ZmQDMA'
    'hl9oVJKlTXDdfk6WKTieSdhuqA5vDORkGKTpw01eqjjWmmqs6pqxLm/8TPjY7liv5Afb5We/SYDrGXNDs7bBqyQCiTecE17bIJOn'
    'bHOPrOax1BCYNGtdmMEIJN8Y0KTDNOaQ9CTi55zdyW2cxYaxqWcnTEJXzU5y2ZApIxOXFwGaUqekVOpE+i2dHFIoKkkJg9j3sgk/'
    'BODZhaTUI/ORmP8pczrQ5zib1mgwMHhFSURHsuSwefHPCTFXSDvEd0mavoF8O3YfhQ8LJCQwnrAKv/fJ/rjhfHdivDaWnViRdIoc'
    'auv4bELP4uaUnmGHRWwUtwDSdl5rKX2SpuxAYzfAf5z5vjFFRt9zfJAJTC+xFNtSZEShA4T4k6c9ac6dyAgjxH51qZyNE0jFuQhK'
    'lMDkR45uiLsPbHxSbuT3iBsMg0fw4Y5zT7Se0f/kMT01TSbYwFGqsf2duKxMJhJlP1FDSley0zZY/tOZsQq55492aOxrNoR0cyEn'
    '+FzCoa8AnhO580uJpRP/pcQupkBpEbOMg8BJ8/cf8AfhDQP4kZT/9SCis5DMDjhy1J9iEzvoj1nKf/FXk55j4a0MByaeK3QOonsd'
    'DkgaKBn+HZz8Eue5PxDEA0xyT357vx5IB6Xc11KxTN7DXpIpIfK0RHXDe8zXz7qobmxE2aOMnNMPy8B/8Jvn38fGS3Q612cWt9EN'
    'MxsDVOZEYV5QNbRxEGWqIBSEUUFOPuCEuZoahgRAaCInUuWLIyMoW5WCkngoFhWOtyqcUks8g6b4eTUuVYBPl+Xk94L4sXVQwA6d'
    'XYOqwqxxMle1yoVyCm54NoLpK2s4ffifgoXpXi4FYWu/nrGz3wlMJnQMnRayHYs8V72sZjrmWcfS1o4xA7WH16ps71vhqpyCfwvb'
    'kcK1Zv6u+YNhiCNBRmwtzwV5a3vLnRimErgE9Q5+WeQWka0N+jP70+xAzhKZOCd3XYg8/JaLVYnDHxaoSQLqSkB+laICMOHPxFOE'
    'bSTiYpHfSlGSWZlComq1yFdoe/HTrSOaODuXD4GVNJwnihZV9hexUyhUC9W3rT0Q58M+pH4ZUyiPtDcXEg/gNyy7mHxQEDuVt/Tk'
    'QrNzOVMJUAVmU7pUye8K/kaEV7cCTYwpG4Bm99wAn+dW5CfbeAQ13nnws4ecPcOAq0kGLCaBnyD/KRekooD/kzMB7JW/VYA/becB'
    'mmn3nMWuiRYBjyqagN6qsH34gYQAj6M1LsCS8zid8DCGROb4rSBQk/hOCOAZn1lHNTnegjgqVIpJRgw7VbVQrN7CpgI7TbUWV64g'
    '/UiXchZzpDQSvO0Bd8FxjT04GU5KsQyrUk3sHbD1wWP+UkzuPEKxCtVh78ENSOaU1ICqZWwmATjZXjrl5CYFEyEl5wG10CrsykUV'
    'PyZpAV7ATFwKarI6Mpqt4x4bq54DCvEOPBcJnssRnosJCUtQEngeLbHCqaMiLyChsQ9y+EFlH1RkY+SJGH1Swk8V0FdgL9wKPCpd'
    'O7kKHhrTYFOLsKUswz9LKiSeAq7xFfIDF6oC4BQrQpatCEKqQlkuYDsFwL1U88B8SUPYRCFsZ4u4sMcgJoJaVGXMMCMiylRE0u4O'
    '8O9AjKtgeGaFYF9F4NKV8kCFJRHnEuwz6kgia1GFb0IVl0LasRJ+sGslJE4hKyuFSwwfQkSApZYoPtDf6kjY3WGBKGSGvgcKQPsE'
    'FbED+kHFDzK+mMt3SLi4ocLjS7mPEqWIPKQg+ShtIqkXti+jbs7NPfgeGTpIGkABllxAGZDuTLCBw8cC/N0ualmG5hXQbaHtnG2Z'
    'q3TkkaDAAsK+yo8UEOChP1hgHndaoWwBJhBRAtADPm7tGD7tnGVCuVUNBxVKreplJRLTBZxJ4G3Rd3wyqqTLb9+PA1Aw+zsXu8rJ'
    'o0KVyAH8ZRnHClI1fN4ltdMw2d2jlOdKQhDCTbKDCARTLCi7BOX+eI+dESVlASiZyeibcc4J/N2SaDkliIIit0Ez3Vygmldgs1Jn'
    'WO6n5WPK52P9qMiDcKkBZ2WoUS6qQDp9FBTgIf4ne0YFucdWaAJP80f7MCYgSsAcBbSJjPJXyezOCnKrjpzZo+Xspkt4jDBX6MYx'
    'V3btY8ZuehaqfRk4U7kAW2uh4gNV4+987V4I1fvyBjNDOfl+s64TeOZ4t44ORHEZLxcRVyXkbLhlZRiCggMRs6TyC97Kx24aNTwC'
    'B3BUrm9pvv/rgQci7QkxOSafkhsv2HN4E6aqBYB6l8SwwMqxOz/R+PbrwanlkMv5TD9K5oTpMocOFzgcprNeOTMvfOXDINGoFDWU'
    'azD6ZQYt0ttD/8hsGmRoMKBfShSqCEhyXA1BZJerxHAxz/LAtLDJEhZkQy7BmDeMnosM+vnzcA6tYQrBEG7Ndx135jLIuUyiSxre'
    'HEJ0byyOORSHyQThRTIHJ9gel54SDtX/PeYltBJsnBocGwI9iGBmfRBLOUnvj966A+bsC+tlRgxQRyN4xgANTuPQ1cNW9ODkPv6S'
    'BSHT1ANRBVhbD2Qi8PYUckMtAknSseqeNuQw04RjAwLFuVoPD06wyt//5X/QNWdjGfcOTk4Dzzp6YEu8AwZMSBaPB5OQJVH34AQf'
    '5XfwvH8HNT/ThcMmjSIjeab5G4fyPDIHwcb+kuj7A5jcYNcxfAWTTx13dcy5mh8YBJf1mQtyBM0nSI7VH5xg8783YhvREL6C2DiI'
    'uqfZ/VFqXPSeUXLMztDZeMgg8VqnFbpshyw/rxnAekGN/EU83Q9dTmfBft1j/uEeAZfmI/aMiQNoRICYBfkwdPeD4REXMoKCfOMW'
    'Iy0gmfr6jmsCJJoPKEz7DzMmZ6A8OCE18yHpfAKSG1P3M9A4Nrs2NkzbYBs+9hwnSmZgAuM4RnIbmiFlIyuJbrX2Zz2fuqp8Bm7Y'
    'Emt4G0HuOYazkBiiMdQQutWGaVtbXBvTDsEQcGWjtvLhOvt9WURN17/KIaBqtFbfcNRjYwUY5BncdGb2x+jKxOvHcewN9GoBd7+y'
    'fcP73XmGFo7pSywD7wFLjTGiCbZXrdHEp8UdYq0Ph8FRBrW2+jB3e+5GZg9E4WEWZop5IaalAAd6+WGoWa9rYJOl3g/wO82MZYWa'
    '7QCMHkdSBIC4oB1zGD1DyMZZ2GwNDP+HAb8LO9gB3blnJMmbzSe+pRD9MCDYAWt2bRbPnBk8LvSBM4x/XwZwRqWirzKBZ3pNt88N'
    'HMqkFyPHMmJZizX/e5O8nhxFiuzzKT4xS2GswkH8OqcAGe7Bya0G+2WQmG9WnPr2WQVmsmAz1DQKmudhdtzkHQQkoBpzk/VBf1px'
    'NH8R7sXAvI45lHrwNNUcdrrwIB2HgjNQMMpjMeuhZ0aDlWuwfnvO8oBMiV+DHg5OOPwF4OurX0oEyhTcbmqQ6HA6OLkxDNePODse'
    'oQQASXQkQNbHgNSFCeCY9MILYk0kkE80eqXCpPhLyd06mbFqukFqoyNGSo2lhHPHYgJazCM4HVkD2UgZl2DzQgpHxfx1Ut/Yac2y'
    '8roMd27MIoziIcblMaYayhqkdMim9uixQUgq2V/bHmR7BIZKiqGanddmBhWzX7+K588Y/PEpNK8zfAlQqByh9hNOBREJ0BYKUhuG'
    '1OtEJGDh4rBKeNB3hNNqrbYjdGPiwnxwl2HWiWju8zB7C6gNDTZzCt1PPgmwmYFyCtjrUy3OdwYB1XwseLDQPN0nCGbYur8dwnNo'
    'BCDEX6xdGD25JjbGi3VQ9yAPWimc419YihDSJ15REg3t0lmgsykWoodGwLHD1BhJSQKTfKp3U3WVWNFOfnFcnElurlkzaIZezgh6'
    'P/n9S4m+zZbCdL4z4PF35PemUgjOwckL/NxUwhkMoCuHwIYXesXlSnSgJzmzFk3KLQwgMyXkUULlsm14BeyThDStDbY/8+aGjioW'
    '/t4EpB94GiId0gb9tBeY6zT0SWbYDL3TbDQXVOsxKHeLaIw5sUOsO0b2TFjzF8SU0CEeSSrNdON78KENW0vTCKkiZwTAC/7+r/+d'
    'AwwYR9AnN5yB50zohTmOW+Tatu5wQIi0KWSbYdMYYZneglLA7Zab6GW/aFDcLFblC1NtEsaUZ0Il4H4jGt3b4RfWhARIbRSDUghj'
    'bIIB3zAYqLb7JUhIyFQ+JD9kq1piKteUAMduq/2KWEpbIxYNaB9DUlB80igPZFsP2Vqd318dNdZHNiFffjOp9IoM8Nvj/cXhl/gN'
    '5VrPmKEsxUcxXXJ2Sj2DhIEC31tjpMLBifD//V+bGKh4ECmgJ+LmYtLBibT5rXxwIiff7rNBnDK+kByaaw9bmPx4bQywA8GGRm5W'
    'hY+bwLDoTnCb3gbSZUhW5ZMz+PnFjSJHgtkmfOCQ4hNqIIUkviWizvcWQFI66ZA+Yppo1sSatm4CGqIcBbqrS4NkqAU1JI8cql+n'
    '+LA95FUNZk2HdtGcHrXz+0i+D5Q5cN90pz+b4Pmj/ba2BhHaiVKiYeYhnSTBATnMApWNHib1ub//y/8ZCa0glvUxawR671CDLnJX'
    'dt+aoRQa3+IY7o5fUakS6M443vkknmqyouE8v8Bmy4UD9qkDC7ZgfHzMXTjOEFT6M6fvE8n91ux5xsNgYPaNTJfQaYYGnP4SZD9s'
    'vZRq51sRXx1ulCx1JEJvTNS7b8WJvrFksARUf7RQkiC8/VsRnmws7fR8ExRwYF0P7BO8mVlY7cN042rpiQyp9kfFuo0EtU0rdVcM'
    'I9NExlb0k4QWNbWN3qhsEFId6yhJeZ/lWqHvdvlo9ptk2Ju5GCt2wJHHsFWEVAGbt2v2gxkoMunbHPc0a0St3xNyJZNIdDxiuppo'
    'AVJrSIsEzynpIi3DJCeRFyQJROk1mtzUK0Ex0m245dc4lmABhkKifI+JD8MlKRdQcWPGz1iFBnhopjBgLn/5C/n4179iojrAW1BO'
    'qUqNZIszwxoHmgjRPL7fEqbMHZHQBHJvqZ/y3QMPCkgzVIrmQGwj2ZkDx2EQpekGsCJ78ekPSd7bohNIhEyeWNti92fi6XzNszlM'
    'TQsrhsLaM3U8n4X3fsJyu1xvRX5/JUwBYdhLCKfCRS64zzCPaH8wgoUB60UtGcTDiocXJ47+Fds8CUbfIZTHH9JRIhxJRfG5WJGW'
    'qcdcA79wFrGMfudCW2fGUveTHyOzbWiBtaIo6SKaRcogMdYBPEMDfQEHJy1ittwyz+dm7FqFz5F1Fdbf73s4v1Tf4Q8xDiPYX13J'
    'H/Y9jcgPgz0cxj2oF5JSLmChA+P3yHZ0HPIszMmAmdLgd0S9ZPx/DDRgNxTI0Ev26dWnBwUidZ3A9YNDHdRJ8GIeAuMbBnH9K9CS'
    'sMh9qGhwxWIX86Cg7xgcV1+Bg0VG7gXJ80SDzcDbQNH0JRNACEAFAKj29//237c2WjeHw01t0nfJJn/FJo9ytczktpPSsLOeQrR/'
    'fdnTM9Jc6skmJ383BQiQPn4nlTqhVPvxULLuHo5ZL9f06z20go3KUEqsocIbnZCkmD0gjzImcdhm8WFWFIXFDD1Am6RVF+YZhFsT'
    'Lf/5JVBsOqk7y03vaY4L1E7oh41StIFiNLkMCcMwNiusa/LeZybsHPEmNV/4JDtdAzLqz88WOVgMq4K/No7TtHep7SQZCOgs+Ou3'
    'mIe9tOhB0/CNRJAQCjLJTeWnSEhF39M36kzB87/HFLuOyawdooEV2kmU3aQtb3ccpb98hsOQBABfDzkjnpg1zsIikjwiAYdTit2R'
    's9FnThDN6e/Pd/rxAD/LdwjbWqBpKeWc2DLmg5PfZ5VAwfpy0E+khTH/749Hw9ATg5H08rsvoRuO/t9k40jMu1nT9Xz7C4bsAH57'
    'BsltnKH8cMK/kVA9QH1YEIdFZpJgWsdF7fHwx6f+kfa0xcr2yR0ya1E28Ukc98cGhoxsjeM/Q/WJtnnru9vld7zFaA1vuHHP60KB'
    'biFTZKs9OU1FZpNEZya8KyRYk60WsmL8/sMM+Ed8KrfkkByDD7/kBieiK9hecTT8ij2LorSxArJdbgTsII5/6jue/TVdhfDwCOMQ'
    'qK0KHrpyvyyxoox4zBGipiYUIKz+2DZ8f43hMjf4F0ZjpEbzu0f6W9GE/C6+pKiPFhIGEZZsYy9rJ8zl8ICjGdqBJTERPSMBRRmR'
    'ohCTzQZQ0tQ8FOyiRaViXnKWrezhYwlP1eVPevL40qUkbdkv8kChObUiWM7o198MmDDnEnaDdpTVrwcKJ38WRgdNmTGM9OvvCSNf'
    '5AVODg9FJQH9GuKw4JNNiFMj9LwP5mB6o4S1hnGCfy/kMexEXDFCQr1CKNFrC20VxzdgEiDc7wfEZY0M83sUh8RCzhw7ZN+Hv9Fw'
    'xDgXDGuKKGL0vcwpVqFSkOfqxycHTfK9bho22ph/A/DVaDXywRcB+i8B34M9MQ07bCMB3s01CoPBfgvYPzP1nx/h12iQZCzYTIOt'
    'cCPdhwzxQE1sLMYvvyU3IlmqUvnrhE8uM710KMEoyNd/Jy5BRJTkbP0mJLJtur7OubfEraEIkTl5RSLXqFuAuC6JAmn60emK8ACP'
    '5Tgw5Jrr4nkghwWU00K7o2qx5bQxpU48DPQEBF1p0gP3jbJWqk0NHYO5vFgwMcHzKDo0tKzs1/8toZHIt+6ZJGTbH2H4DNWSHDZ0'
    'BOCYM4rDIvdf8OKQnxeONwZpFDg//U4F8cRhgEggP0T1Btra4Jhdh+qMxI7HcgENJY/A4L7RJ1+R6el58UgMZk1bObL93qGCEdjU'
    'Xfs7ORXDOcmzwEcTtOs4F/HeemvqxG84o1s1pDBwPR21nqQs4sBG/3LoWwZoZzTU3Ay9C6VD9InTlnb6D5Pue3LcNTqDDEPr9w03'
    '+PWAHfo9Lr77jn2sufSQGyjZJXyQVFg2NEcczGemd8DRfMY0A6WDTkV4YbqwDmEbmxsxJ8M0WMTiUfpz3D/Nh4jH53/5h0IBfWfk'
    'ml4Sxk5uOSXXXM3D0xkeTF/o6oaJJaEJ+ncWSw2lfBjhMdM1MVJhgE4cB++BCTTLKnKFAnQU6nLkLtXIyBc9ZlcFH0S+WmI5NDxo'
    'vq7F/iJa7IDzHFx1zTK8+KRLbCOl9VrEwJ9jeaavU0FcZ87CthxNzxz49zMnucMzzuTg4/q+EQE+c2FrM/IAX4OVFt0IK3194ayF'
    'r5y0yRvM3Z0b/UIr3sJ/D7kmOaC2EV5c3Su6XJsgpnTxaVsBpsQMSfoP6cwGiU5Tw/9DltwTBeuBvT4T7F2GhPMbYBMCKJ+auW1V'
    '7jeEFp859k8Ybgvb6VAzv3I2bpnL7ULSyFAInsIxzqxhio0kWL6OryhdYE5/Z8gAmDi6ZqVsR2Q/tgy9t2KttmgYIJ2EkRh3x14A'
    'vxDZW/fkakC4gk5Gj9kejmk4TX+EMRA+5wOHoFsIwEVLkNMwluMHcaDMWtaO1NZNhmr6fRLgdRb1FGPwXh4m0swpbAcovdPfuaRC'
    'ytEEClnUetbyzJkbVgiYCj2YkuuTSPaIXA0x+fP2vU7Ibil9UxMfHmr/CWNMshYE6AeT/8SzExEfvKEi20nOUcvkiHbY3ZLriL3h'
    'xhLLHT/OLmgPsFwn6bgmADc9mvOZlRxMUlpKT/wpjc9jgyDfSDwLm9DtMSSsjWdyKc3G0xLJ2NqXaG02tHWLlJqYQaTcjaiG2zW2'
    'yBl4novtvYz0dDxjvzB8zA3j+QFJ125ovlF0V3jCkhwLQCvLKt6riRtI66ENnwbGkaOMdMP2+57pUhcGbZ+wFCpsrIk2J3/4yx9I'
    'kvIDBtPBd+5A5EWlKAhFXi4Kilg9OMb3/mxCSAvet5sXjfsWm/jvnEugDcUGuhMDjz7mQFdJLz43Jsc1h/QcbkQKxJiEMirKJeR2'
    'OpibCzO4nPWKtHMaNARdtzCWEiQcy3END5aHlkKJyZnZeJYPQ5UNG6YQk+/otOm6ZtuG92Z4Y1lBAefljj4pci2ENV4NQCk/iVNo'
    'QCGqGMAFK+GhMf7b0AxGAFjfmZTChkpU1Cgw+eOwyD2QoEbWMvDWAMMJSAfRESDW4DFe6QE4scASfuC4HOpVJPE8zB/GMTooKyKg'
    'FCrCxReEt+KBucGM+KUYxDgkg5w0JVJReLUs6bTZqJ3dNahFK1IyEyMLHKfI1Y2RyZDM7xs26gsuaHSmTxKNaCFu4gLD58AzYZbM'
    'QbgOOP+grqMKWDz4A/fPx1uRi6+WK2vIdUsvb2YRh5GiHSXacMKYtREeHUTlFF2KA0pYxC9EySQRo0f2CdhiARXYyW+T+uf9LHq9'
    'jLDPhcMm7t0x10E4pl3hBATa2PCj87zEgIFUgDfwAUSoxQCQcYIWsvIUQhKfuiC0oXl9cpazP3Kc8OTYYsTGjrZWWPk+bJWwqcDq'
    'mvqKLAQaAig1kRNgZGAUaFLXDEi0op8XqkgQi5ZNzCbLC+TNbJh8ggNJJ5u/czmloiCXlbXlDAHG6RpoQApk8iJ/MYUMMVwjJz44'
    'PEsO4IX5uYgEMplBFXL0FogOhhWEIcYkPhPVHYSaznEG6PTyNnL69l2PrBeAYGICqAE6rSksRK9ianRqXfFQuwk7JE26FpU2kgkh'
    '6ByzE8UDzaM2FVxvVpbeLkJXb4ix27CjwgrXw8hTmk7HRmWmT3KaaYTNr2CXCCiK+6DZecgREotMYlRp+XC9kcEAmGTiKcokMLY/'
    'KnL0VGrPIBKJid49rASYR0vj3sKRxJRk9MkJpnBoNstDRNmcmUJde6YPSb4egI/MikYtatHC+WzlojQgGBrrGD4yOCTAYrh7+JRH'
    'EoMYNhIEJHkDqq14bIgEk+MGCiLXhAiyq58wHBwoELdYkA6SKZNgr1pFnJGQd3x4k5zm3AfhBWl9c2yx+PLwIhREfLIe6eh17hso'
    'IAgIRv8i7RHQD+MtHrZqFt0OjaRy1sF8WYRfo7L/E37FBnSyb+Ttl7EJIF55FnCcwGrUjXFFyA/CqTBCP4q1v3AQWDIwNprEsQYW'
    'sT/ApcMtIIQoVC0AfFwKGDGCOaJYGQ6coBcZfZEj/Bf3t+h4AEzDMTZLfDN+NoD/ODEX0cxi/ZHGjhjkgEPOG9NNt08El/AYAbWj'
    'OFwYuwJqjLeCLneiglgUysL6VlaLRAsirzFko+EITG6LNQB8nRIOySkJRO5w4/dj5CC8pI8HikmqIFhYxl3y1j9skCGkbwYR4tMb'
    '3wrkLpoQsG+ZOWaaCmEhuomC22Hi6IVGx0b2syDu7JhbE9AZr+AioZTs2sTEHgq8XG1AOWQo6pg4OaMwh4KB185zPWsG4o4NrCbG'
    'lJAjkr0vUR0mWCMg4yKDnGTjmRIjyngIHIBZY3APWFHhaRbaZ9CMQsiXFCQJyEKRKZxS5FO01nN6RejqRok3MNvUPlgkl6UNAhE5'
    '+A9tj6mKzqylZIdh0gQLHSFITGW8MA0ANapSsSfFuEM+wygaEMOwBnQSCQ2QbQTRJdDWJHEKFm5uuqct7HzQvsfs9blAh/CN5Dag'
    'gB3HeBPBSjdNn6oIh8mxoYq65/gYrqFkRVO1OURWZjt1WkYgy4ezQJYapElE6gEeOSKuaz+R7yY9IdzVgHImrEIJRMMXiHaIlcc0'
    'AQA8IAjkO8fRySfC+Fm3xAiFoVhjNjisEZ5oSoodrJ5Gk0/tg06SvI5Op5iYzseN16aSKRPvkT/ihVYAK/dPB2dUx8IjlsRm+k8H'
    'FPg+re0aDtq0ezOTmO+NCSDOPJLGGAWFOwmsSt7WlOnCDLEF54SSTx4YdD2ZjPvT5nGkwAUBhboUAFw/Ce83F8QBx5boK1C4D1ND'
    'IPIKkblgOwBxBEe0IC4yHBAyI9dzhqg8FbkmU4xYJ32qxlosVCJW6fdZNyF/3VbsFJIfJJQRas0n6S2RE+MD35y4eMaDZYthj5He'
    'URbyKIlllyPd/neOJo2MZjAUzgg55qSe5L6xs4HhIaLEMcDQ9QDUTJMvhocZoRqT/ewkTVJgk5kOwwqEoVJLQTJLIpUrU21QkTov'
    '0WKRttzlkFsziM7ilKGMNUaHopGd+2zSqTSeZBw+tZFqVOzNrAVlLYlVINKIRpPekNRuoYUrpnLq+Q2MaMGI9jROpbkCqSDNw34K'
    'l3QbavFFUQA5JWeHqYWIgYfr8AZq7DoWsciSY2LgY47lRMT3oUkHx7WGTK3N7X3f0RQIxuSGtWi0lBfgouMuCjjEQiXZvBKUZcG5'
    'GF5cQONHuL8tnAgGsjmmJhoEAbpCkaSD5XCJHsKkyH//X/9vCtXxmoRDcTRfyCFohx50mnCMSFzUWpcS5IvcHbAObUjMGvSIayx+'
    'R0ChWWafhZXEtYU9N5cGhSYt1IQwhiY76vpjtopebAGKzslmlhfa/b6l2awnMR5d1j9JcnECd3VmmI4sdJLmgXBIlyoNMQp3PpMF'
    'yV7LTtfiDjwwbbIb0BWhhMe8RxyNoN5rVnPMn3RWM4fygeU6DJ1pDpXcOdtVie4rVCIgaUrXjzBTlnFMcN2lNjnaGGYFoINl2U8w'
    'QVG6PkwiEp9PtBucCGJG6lHCcUmyTWYXjFd+9xzJorw2R2G/9IJXem78e3yc9JieJT2m2VdxrWiitSiPQqTgZKdxR8PIhcmzMGMF'
    '3YGYShPr3gy7aFFyqSVj9GQtdJJBLYz+GR8ycAkO25xjx6lkaZyLQ5MbRIpKcoOEikOy9ZWwCBvpKtrp1kfMREmUM6jhLGIrGexh'
    'KEN2qwlFud2LJfJKrsmCWk5C625kf/+eteCHmBMSIvYeKWuoPqzj/YaGM0ZqZKJ0yv0VMOnJMY1LIT5Pn2kB4bG6OHMYliloC2Ql'
    'aGnMqDW7YYUJ+8Nf8XIC4jRJ+ATpzYX5HltyOTDsFZHnVTj5MY9ZZpL9X0rQJG2bhoqEED0boNOMQm+Oz76RgzgjkkcBk5ziQ+p2'
    '9I8jTMWxkzVBHsJx3wAdDw/IjKJNFUN/aG47zncNyyKeitCFucFPtvEoBwKKO+hXj0KwTPyRbckhFoE08tPk+7/n+YVsPubtqZjD'
    'MW+9ToBoAkD8ZBf8QthB8gazCHVIR9j8D95EgCPokKmNc1V49vrMxwk7SFrGiKWGp7s0shFF/g8Y6eGXh5oYZXYf3DPDcGaA5PKI'
    'Dflkci+T+MG0yRvvovgcNd05Xjbw7/NkFaYeOYaNQ0OST92PYpk9D2aDre5XMleTy4p+Y5JqAZdPHOfEVCiF3qpAUqNEwh41mqDt'
    'lJqaU7tvYivQnR9No8KFc7iblBp0jjP8wF6b+yh2j6p1DF48Q21oRI8++NG9pZHucTfo5wwFomO/1DFJLeYMP4jwTvcfGgL8Izfq'
    'ZIn9No2LX6b2/zCJbfID99g8P6L0eZCSLUIijKIO87LhkJIsHU6qXRbkkirnpwJfksdcSQ0nce7lOVJc1865ekafpOtrkt/WKgxg'
    '2XRslVyAdHIPP/NOrebNyYVn6mnIhx45QpcfuTUh8Xt/SGTawDPC9JYrWDwSA6PZcw1HTr+CgmWR9obhE9S4LW3FnoURTL9gmglA'
    'ci262cXxwvXIkZHSMlhrRbKPEJcsYC82HTaXCCImIWwo3jZ2tj7RlpZhD8n9s3i/V6o3Eg8WB8eTDlPziun8okmN8vUd5BANlGw5'
    'w6GVzKSC+jKLtgivEo2VlS9QSXQfaSz9hq1l9kgqtYx7Or1fAj9EZysSEadxMXafAynoszsf8ks+o9udlcTF3VDsDCMPSSGazX5D'
    'sb//6//293/93//+r/8HqNysPD1PnVs6zp/Eyto0B9LmwiVWEPnChnJREdPWtzV1ysrFTzrsST++RGlbA2fhhERXwWwp/MYKY0bg'
    'beX4CPrESqxzCByc4WUCGWNioq+v8HuGRM6J2h1lvQoIfXLIno7R5KInY9BYijuP6PyfV5FiQG7NRMD8WkQgCYgIQ+iNiNcnIn1Z'
    '0q40MZPCTcNP5iY4I4ffHUx3S7MT5G0XpGIyzPMHM3fFQZzkeRRxnB8KTsqQq/m23dpHzTE/mGBsuccWnJqTVEq5xM5o1zEiJHHz'
    'k6fRhITssPgfctOIuhikjie3Nm2KI/Hg5JLmbtxYRDo4eZ71RplS+R32EEo8gAUgPeGvjSmaPJJLMpHb/g/rKUNTR/z6Ezy04yTu'
    'GPod86mt9xxeB/tvk0Vtvf/ElbFxZnT6hEHR/mJ6dNbsvoDQSzpbI8+ZDUcJhRWfBuzp5+FgV3/uvRrEYdO22ZXMhLvF6bBI5mAS'
    '+vANL9IqcdRzh5+JIwC9aV9LwQHdfA7EhxwA72eTHj6keufXwIguo94ODmEdqWwmLGMOFZbZKXmGQDc/nJZkNxJbSVhY5pcwO9Wn'
    'UXePvskEkDTvMelSZ1/kG8bc0lsyBJGQsC+dzMlPEpSVKxM8voWZLmMbiUZvi8zntOSeM2po28BiKQJGd8eRNJo72Dc5BIMYgifb'
    'YdfffIUJSO60JHyYTWzOS6WGy28dxFbSATsguuWCFChJOmAlaR9bCpOxRcVzRrprX6Fzdel45odjA2NuzhILcUZvW/9qqpvwsvZ9'
    'iYReXnnOrl1PZbaL89N9AY7Ude77WQaITFJ3MGUtCEgBCUIwyfSGVr6k+Emf0FwISYF3Q7pXGryi+TSkWqPmMozcKnJ/+Qvq6X/9'
    'K3PHBM5aUAbKwxzxg4UXWR6nnXbovATx7Y9haupjrkD47TH35z/jxv/nPx8WD042DJnEkx2kJTMCylZ5duDgKakM7P/v/5OAFb4Q'
    'Tks9dYYZxp6CLmWhbyjAEg2/nz5Wn8rZvf0oMQHkajLMObe7dvj3lxIR+yMtgB4MQv/bcAbPdeh65nHfmJHQz5wrKeDb8Kwy+n1Z'
    'JIJE7P+H9DJn4sUN3XkzGqYQZWuJ3Lr0qFCsgwSzIFcDCQ2e4QlEc46CpGORvJOZFYE2mH4R6wbw7BRP5mROsq1dXpOvNWDtzTrD'
    'rcHCh2NTcJR2DjYZYs6H5Y0G/4/Md/4bKRW5WIlzQDyDv5jhCOrka8lMVBhJ4cv4oKaUIgl8xc7WZqkFXp2RXEHRkeTPMiVykC6R'
    'w5A6h9IH8LKDsrV5+qwnGRnm+8Cf+Qc8M8ubworGMvC03NOf8PKeDB1/Zmc7JiB2zG3DuTZ2ZH3mnQFrPDj52x+4A8aFv3MHaapC'
    'f3XCWy7hVxZ+ig5s4kw3Ju4IOsbvOKPEw01CrrA5dicXeUjcOPCMXTdGnqEFgeQgp5Wpj/4ALzu90rFDGb+GF1WzDnn2gTswsQx/'
    'TD6T1LfQuoA8i/qriCuRvl3GBVfxR3bFynfOBhmdPhqDOE6AROspfURSheKzP4o9UZdF9piagaO2Iqf+P814XuqPxJMXlBomJPoh'
    '7cOmJfD8Mf3knpCzdjRBCvGGmhiRg0t0TGImgzjCCh021EFPAvsS7hwkb98gdX3oNn5I/TtF1qvLOp1Z7INlRvfR0UgCjj7vndCD'
    'EcBWWNXeSSZOnxyMYmEmcVYTrEGMREyWjO+CpgFp5EBd2Edsz4g6CSEFwCIIW+T6AnSshBUHJHAwOtwT12aLz2Ys3IwDjIodYshb'
    '1IIYD4sGoLHrF8KjDRyNiA6LR2dgtgLaWLqGZ5Kg3IFnGNbqe3qob3GnaPijAbhkrajAEBY+N4O4ZJj7njnDEotOwqHW4CjB4h4A'
    'Vv4zoTEhTS9Cml7I1c7kJG2YrDammIJYlKtipSJKolwuC6LCl42CIMd0VBDK5SIvCJIk8BWJV6oZuuKzFGTwkiAJe1GQk0DQU4Jc'
    'WiLTZainBHmL8JhCMRhhPJUouyXvggYKxXlE/yIelACsDaulkTKs6NhG4tbvXFRduSG+pVF9vUEah1eMSrAbW9Ll2Ome+JbH9eWO'
    'pgo4iUNs9tFcHcczRfCLRAnT/R+2B4J22cxEMKwYZr8fQ9In6Qb8mJPEOCamcUxM41hohCXqNcmPWwC1QUvhmsRXiqqiCAKvCtWK'
    'KEgxlklSsczzVUkVKtWqpPDSTixTy1W+n8EyIRfLkmwwHDSCm+ANCayj5w6Dn1NZgzjG5Z3sQuqpdrBudOxFwwTtRh76nNFAEdZn'
    '2CAGHyZAYtpHDBE98JbX3gvywbCZ6A7huC3gc9+SQcYgKq8dBfzk3cHhiSMc/5CGYbLhREeXFw6N0vajc3A4o0RN28HNpDSmSWlM'
    'IzmTSBZG3Qg000oxs3KxylcERVYkuVpWFTWBYoIiFoF/8TLwOVEERlfZhWMDXu3zfAbHxFwcc9NXCodH/qBUeJ4dViG5g4bLdXQf'
    'r1NP04eUr3A+5lOOCv39v/331Gpq2TRXhMJzdt1SYs98IbJH4qwsySpFrgsih5dsYiPk5BjFQ5zBSNrMLc0xONgKOyRLjwGw62rx'
    'amHA/xVQTi/BTqI5Zl7YUChkSy+nl15OL/0l1dDi029RaqzfDAmkvZCAjwAupwEur+NqfE6DHRCmgav/xhALEcRKGmIlDfHNuo87'
    'CahKcmKUhWpZkivlspKUE+CVWq3IICkoIE+UFXEXfSmKpvKDDKBSLn0RCxBjFgFq2eFnL3oI++Lf/+V/MEyDr9FzIipkn5eimqVU'
    'ez1HX621rRO7YyRQlGJuF8sJYWN6XCkhnUCd9J6fLR7Dk+y2kdznt/RwTbYcIpUk9/lj7lxEzkDc/Z/s+p6JIvRgz04I8uSa/Tqi'
    'JtQtTacK7NvqnTNPJgQ0Iw0nrwea6xbP13yyF8IVoxR9W3rIcOM9lwBpYFejX5ly4sYscdQfuKuDOpSkPsfP9kLvRSrRzYzdkLSr'
    't1/D3gqf7I3c2lzCq6mdXX28hX2wq5U/2RPJpVdiGcJ2rs9zurPnT3aGgZO7unj4LFehJyfCY2Ol6DrRnbiWHkvjs9RiBvFtb7v6'
    '4vdovJRk16XkHoH2FiMhq7O9LCFrhUcPk4kAyM0iqQQFUVYTB49l06MpNAGRN85TkirpzbWS3lxFNFzdaWMizpNEHkPH0RMbrFKU'
    'YFNFFQk18aosZXVxXqoUq6D5yGVBqFZlVf0NrVz7a0/sJpzwhpx4Vj0jPJbI9soiR5LO5N4tOHS4OHUMu8g+bSFJCqCZi+3jPsnF'
    '8gl9hvgwwkvp89SlsPXL6LxSeDY2avQ4Pu+ro70MTUbEzMklju8nEtwwNMrAnVAM8Thsvs2L82d2CUNnowQVJDbX8POicncoTmoa'
    '+9Q09pEbz5LiXAUEtrKkyJJQAZFTrMhZbBMqUlHegm2V/Ww/EXzVNHzVNHx4e1pK2BSrRb5aKQs8X1Z5VZJSoFWrRUXk1YqsVJRy'
    'Wc0aDNTPmKXotW9QilzjFlvVMmZoIWOHrjvLJLyValEWeEVWZVUoVyrVShJesaIWy6osqYIoVapK5UvgChlw8U65GNqsETBjBWT3'
    'yiUgVsUir/KiIAsyX+GlajUFsKoUlYpUliqSolYq5a9BLGYgDm+5i6HOmJWEjF0puuguAbcoVoqKKosVSZZVqSKIaaStqoAZkiJW'
    'AXShIn8JbikDNwEnBjpjoRCyJgpAI5/7L0TgScAtVPkiLH0ZtCiRlytyJak+qXK1COMRFaUqgh4oVnbSWq4FLIYxo0oLGV2aXs4S'
    'AycL1aJQEVREBNBFyylk4EUVlNCKKAtlSVJlOUttgrQXdIx+yGUI6IgiIMQQZ3RpIaNMk3v+kuZENBoKZRWglqvwXy0nQK4Avaki'
    'KszVsgL6s/o1iIU0xPTGwRjijC4tKFkGgZf/UTEb0KFHLxFNbPd8UZYBUcuiJKoSkFxiAMBHikB+KujSPC9XpS8OgJETCTyMvXdc'
    'GFyYfESiZ6FGPLyMNCNUsgybxjMlmaBQFoowIFiVKvBuWSwnaROWqgicHPiJIpQVoVrdhePbLHDmZBiCB7B7OJYDjAT5TuMP3l1j'
    '+HNP8w1FPi5V30tyrfb0PH67bg5r9dpTDb7B79pZSR5evj6378+6Qv25xb9dtxpteNeAApdXNfLnaVGr1YOe3Vy1x/rp1fno7cWs'
    'XUJ7UL9Bi9Tqo1fpflHb5w/0XQ1eyW/ov3X7VPsN/ljjt+79O35S8cdpc/VybmkI2DkBr2mH32/odzP8/ki/S/plncdPbfp91Tm/'
    'PsNPb6S9kZ35bma+v/cvr0l9AsTZMuhddt5j+Mg83b29lDttMktD/NGvXd7V2sP6Za1x/frScYZh6Z4CU3/2LmBLYzrf4TybE5iv'
    'QG5jTxqO4Sp8dfqM9R9H8CPwq6n2UvPdrY/6k0a8GFDzbQLvH29s+Hz/Ao8aVXzs9mL469vHc1qj42n0a71FfV67gN+1uoXPn5/q'
    's9rFXe12CIM+u6rd1WrL2lmvJC7qMH/tszoi26LdgN/n9af2RX2xuKov+pf1hXp7uhjfNZ7U58ao8dhoNlrno0W3sXzSzpuN5sVp'
    '4/VixOuXS3XQWPbN69Mr47q+MC6XFdr2Uxva60N78tVpTTbO64325Ug2fux/pQTDbZ7Wzha1l+FZ7RlmfwSgLxv1kvpUu1gQ2oK+'
    '4Vnqz12j/vR6WRtelpa12lEDaWfxBGWfAL72VS2knOb5qDa8azSG7Yur1nmz3z4/HWqAmM078068Xo17jfb12fXzcNh/ueLvG+PZ'
    '5bItPS6wb0AipMdzSrvJP41T6Ou8PuxfYbn7EbwfNgDGJ5jju0bUdx3qDwmcz9B3vf1yvhy+XYzqS+jbu2zKz491tf70csdft/z5'
    'ZUkcwlIuGjj+s8ZTrVR7cIULtzlcKjcfH26j2py2X+8uGi3ycPHafGxr1sVZffQf+81T+7Vxd+VO758n/tnL6ch6vlbe265XE4Z3'
    'VzZ7XFuYhiPcaIv717PT//nfD+H12XWz6Zw9tWFGnldBQxze11ttbTT6D/GppN3cTJWx67ovbqcybl62V0ePC2/WGzwL2rM2tSrT'
    '9sNMrrz7vbqjCU+mcDQJ2pXOw6M4EVfL+9N3qb+cS2/l9pLX/Q9+8NIytKZzX2q/SXPLeXePpJe+YKp1uzt+ns4mk5UNgvNgdbey'
    'Xf3lKJhcmcveQLafa+pkNdcePUtxRUV23qfm5Lq0OP14EPzKjab3Rp32R0f6eKxclY0q/zFuO1XvKhAW09uW+tEp25fll6v50ePb'
    '1G0dvT0Ijx8P6uMK+ptZmqa0p2533mxXPu54SZwo7qv3fjQ1b63H1kJ6U6/fR8r5+63YXFSsR+Xuo/loX3rLausjgGXTzz+6p9fN'
    'Vmf8qj++2r1OT71+4h/cyq0zm71OfFntqpo34pePD9eK+37UvF4YA1co1WZHlXlTavEtKZzwifw2dCZ83bnR3tt3V8lPNXd6etFo'
    'Uyp/Aiz5t6dXWNCRNgVMaAqdl+ZZ5VV8bAWj2/mV257qVnA/7ylnNaHbvtEfF5VZp7NyzLfK0fTxwqiPZeP+oTNw/GUpuLmvLl8u'
    'm6PX4D5otHRDDAbnrZvao9W9XVVmbwNvLrl6pz17e3y7PZ/A4ptSb9S8BCa5XCm4i1pHjl+/G1w9V3uuJunVU2PUmp41yubCKr17'
    'we3D9Nq3JyPhYSkGHaUztWZuqd69awtNscUfNdSBWuP5o5l8/tAbCU9z05WX0rL68a6TkQ5aZ4/X7XzuVB+d35NC7Tvv34E/tnT9'
    'lneDccewpu1SW7i9EJT+9Nm+mvG3inBbskpi3w2WrU7XeWieP943H0fn7daj07PflFfYIIS76pwfS8Pa42RRfWE7z7R5M+00jXL7'
    '9XI57ri9ZcXSjrznqbX6aHb6szbf7pcnV+/zm57VbvMfsKxDWSIgXQr8x/I6D+Dzi9orZWmv9/UnxtLwO5TSavz5xfAeCtxjAfha'
    'H/2bvj8Vz/Xu5Uq7nTtNQ1o9WvD8pQ94turddyblM3dqvtoze9i97aymQvdcv1NfLbvNT63OTefKc+ba8L6zfHi1bq7fpc7bY6cr'
    'XwiPk8du0Jgr95bwWhUfLo/8amMplAbTcVXjK49BWZjcBpeP7vt0XKvxSxT2aoL0IFXv9Nv7m9KLVynVTu+k6zn/WnU1RVDH1Rv7'
    '8e18NSsZ01mnqhzJ1VOxLuqzt9lbayK9llrBSq5oTvl2Vv4oX95VnjW39S5eL5XrowePf1cnD8g97mvamWTZ9s11UNNO358uhoyt'
    'wAvYiXpP8Ax+4wuyTzkg7vbCLyEHolsVNsA2sH/fEvWJPBn0gyvrfHnuOVXl4h4LCUeu1jU1+636YbWbnZaylFofw1W/ezt/tYzS'
    '27Q9UYI347Ff8cyr+agjnvOd8yb8fzCEobYwjLeuP19OFft1/tG67Nw1O0fVa77qaWKldTp7kSfGqnPET0reTFQaxmw2sT/aC/V9'
    '3NNP77WmpswvZ08CQn52x5dETRm8C8vuWPjod5uqb9z0j9zXlT71J+WLiuaatmAfGbW5dGspc0OeTucK4CgZbPXMFz3dNG/12eTK'
    'fbca/atheTKbTsude+SK0Qydyiu2U7/UvRDdcSiECOBTfew4i1f8h4taN9/rw8V//N81Z3F2Stb65u7i5qJzZRO8XLxawAFfL/xz'
    'ygv/J/9Ubw6fKNlNEbUvuo1nZFwvhHFdw0p2KOOawPp2COPC943+x/ju7GxQdVeVe7dd7Wi8WLqd3z9a1a7a0iq3N11/NJjxd/b8'
    'ddkTB+8vj2rtutswHi9Xp/cq9PRwtzICf9Qp6eqF0CxVbqxpqfneLV92BneSsZpUe75bXYn2si/oH1rr1Dl6ebNn7xWn5yoXUP/x'
    '7ta+V+fd0vnq4cmWNbH0tKxMBnb3MQDu5ZXO9WlXnlx3gs7be7nXP+qf6Y8dRNLyzawznr7fjrtWyWu3yw+tZ48vnwvnattrB6VF'
    'XeBLau1cKQ2hJx57ulEeWuWb96Oz8Z37eFPtqB/XfvVJ/dBKo4+KWXpv3syFpxnf67xcH2nmqzpf3PPVW5ily5r44D90nJ7ybF/O'
    '3KoymvNt0bgWAq0zXqkXU3s5DTpX81m3PNE1cbTo2aea+z5/r9z1XAG5jvBwLTwuxKfV7dh7m3b5rtZpSVVpfr98m714wmn39n5l'
    'lp/mXrtzNTVk0bJvfEnWZ7PrintKNhRcvvNydv12re8PvodnF40BDsALeXmLfKlPH16Vkey931iB5Em8VX44ErSjoG3bSgP2m/nb'
    '+eyjNe/eWJdao3ft3HUfy2f1xc29P78OXmZL3n3xlNXRs67YZ/2lMFhdvE75V7tia0eKJ3iVQbNyZt9M4Y8F/1+mriF0OobQsu/m'
    'miY1Hyqv7qD3ePp4a1drurfqvghT69yRS+dTr3tkVMRraLpUdvqV1WX78bbsuf2V4umnwNGPHHtW6VTd6aJfHiuBVb78EFaz6UOj'
    'Bt158Nep3fez9qj2UgX8ECrirbASOjLfuTGP5Mnp63Qy6dYehnJpWrH6b9Pein/rnBpmcDEt3T+aZX5+oXf7XevWG0jLm9K8GjyW'
    'XfXl8WHY610IH3fLo4vqvCm0llXjFWTTjj6r9J7LmufO2rdSpz1Vbiutina2ugUZ/6N/KlsfjVXPcgfP5m21M7h/KLemR9eK1FR6'
    'g2tZegPd5UVQtcHY5WfXweW7ZJxL8psqqwt9jPj/Xl+prQffNZa31XPlfel2ZypfvQzu3l/OBrzAC815eyWfXsNOfjrD/eCF4ogO'
    'bIZhRpfuDARf6M7w2RKXD3pbb4sPj9Ly7vKlal2LsLBeryt7l6Wn+8exUjVfqx9S/+Pu47J9NhXvex/d+76+PD8rdyqlRufSDdp6'
    'oB198IZm31Sfqr1ubyq8lhptT3Mq1lxwq2+D68dm2ROPmktY2lmlP511b5SpoljGFLSyTsdqdctHsFEH/Gvpwpg7peu7lV7/mHfm'
    'V/2h1bEvS/qdbiyn50fz9lgYXM+1vjLXvGmtb43f7qXrqVQJWuNhrebvsGMGo/JLaySN56/B0eyj3xKm56+Vs5ExO2/e9Lo34v28'
    'Wb3XWgEgxqp0JY8v3sy3o6b5XOk8Vx7eV/XK4/Btdm2L7fmr0ezN24aldSptla/wVXd8Z9zIYnP8Ggi3s3tj9qLxVc10213psqW2'
    'hKUtK21RVYSmxV8rq0HH61XPH9zlvXvbGZyWLiqP3Y93kBHPr80Wfz9curM7xZO795pddUtvnnnkDlpdwqLKT8G9ftNp34C46ig3'
    'tmZOjvzy/bR0FgjNx37ncrF4RROLSvbciSOASOVfMDWTvHrCN+8X5Ufr4UFeWcDabgLR6s7cbjDtiteifal+CKDnBR3P9PWbRqV9'
    'NJk5ypHWLt2XrhZ9r632zt+rz9670Py4sof6aPWgj1T99Wjy0TfNj6ZyWRFGjYrwUFPeldmqX+ldLu793kXXf3FLnuCqjdGZDb2u'
    '7qSr6epuWu3qM0Gvdp5LpbtxozUOngSlOl7en89lbfAyKIvnd6taTaOmtyNNUW71B0HX72+Mm+miXq0tbkt3ff2tpYidZns+alZ7'
    '1bP6XH+Wg9vSk3gbLAfz+2d7eS291edPfc9QJqvp3PcNoXl03ZkeNUfSrFe+KZemHbe1APX3VF896X5rJnkdr/JcaTaPbtzGw9ns'
    'zej0j/hVT+jaL9Px6UAfVqZzmESnoq74udUuKY2bI0Ne2bO50DE6p6WGvGhUxjVlVRauh27pTJsLA94xB9NnkEP9I8/snqvK+Kk8'
    'JKUevKk+6CzGrY/ZQG1MZ67/LvQ13p5Mp1qjUfFrkll9LtuO/9KomqW7o44y/hBKK19/VDpHb+7TvVjrWYZz9FSy/EGlc/Raml/b'
    'pdUr7LsBbIWTmvRan42hEl9aqfoAK1WvhdsJLNu7V76af9xf1GcL4D3V1tul9yq4g+vO0xGv2F714fJ5bvVL8oOOjfDCZbsaDGT1'
    'OXi8CUrDjqtYoJubvsSr4+bA7Dun96ua/t4U6sugO+j2XVV5HHcDdbkMBjoQwNH1eavaGi2wVKn3cfcsi5PO23Sw8J7mz9POVfXG'
    'mRo3l/b1ES8A463eP/Pe6dio1JW7t4dzuzw77wTmm64sZVD/zdvK2cdEWF3ovVLt6m6mjm9fps5bx7Nnz06lItxrA8NpyaeTm+m1'
    'fjd9MoLXQffy/qXRvJ1XHseO/VYyX8SuqrzcB+8DcfQiNu/s95txl/d6s3nFasn2+7037V21Kt2LoHNdFTru0dvkxXD7oNZ1L2f8'
    'YNS5mY97p9J0pmvlzsfjYHnkPlSvKx1NqcgvU1upereBJ9/2mgO+PW8JLn801WdN3VUr901ZeCvP33vzI+d5NDgNzp8+bh+ar/PB'
    'q+TpH+r9881bu9d8sx4frtT5qjV/NvyOrqk1WzfmgGRu63yu1rpSg59Z3vmqYrpKxwUcHhhGr+ZORfPjunzzWOvxdq88qDr35U7n'
    'rvXu6TfGqBdoglG+KLX57pXeVsuT6Uzsdd/crtB7FBot0RWPVN65u6lOJ11D7kjX6sMlf9W3Kx34A9zh2YO1AcVlrk1tufbKjPJ1'
    '7862Hx78UnklddRb7bFyJAuzlnDfEd3319W13OnezIf2x4NeBy2o1ru8Knvj3sd8fNtrLQLXqxypi561Kve7WrnbeZm/tz17cepe'
    '1WqN4ae8Vivv8uoteAeheca7cu/BLt+8Ce/T2/HNw2qu3FSObiyr+nFh10/NJ/3+VZkE01VXfZlOtBu7Cvy6dK/2jF5VPnrvLrxm'
    'u1rq99unE+2qrlz3Zi8V60EAJTF4vLC6j76qOJ4XCL12R2h7suNd6O/qx+renq20Ka/egBTfDW7enLooP7wtZ+6UbzZWd9rEqwjn'
    'LaPcepOlh75uVM5nntZdzK6kecWcaG/Di4+6Cj3Nyq2g57lea+l2Fk9nH37t4kf9emdKIN1U9BcYw3Q0uLBe6upweFkSn379lTpE'
    'uYMFesEVnn0boW9Uxmgb6r8lLtJn6tQ9eD7YcG6BRjaHsYDRIcQwlIn5eLOBc8dcb0WyVmDE1bdU4F4nKntIjiVAwThZt80R7yzN'
    'tB2GFRcxUcWYeyZnHuB5t3CrecM4uJqeLsRu80LuhEzUk5AJe6K5AEb0pm2DXPjG+cFsMEi6rSW5UixXBEnFlOfVspSMfqhWykWM'
    'da/KvMRLUGCX1/oTce0j8aSROOoXhp3R+zZGcUxx4iApHQ+e+OyRXAZkQIlcBixXf7gmvbgRjGujH82TVOyvGb2YnUTpecIAs5NE'
    'SJ5/4iez7rAi/sn2k6dRchw/CtBPFoCH7D4LAnh8li8V5bb5WfIUYSrRjZ8TcXdOAvgM1998wm6fswaEavKPG1w6ix88bEDSrOTE'
    'x4bpV0g8ZDLHyn7ht2lSTjbM3kS0nUpHs1/jmL8ip2V8HAY2Qns06c9XAnqBlXG+1//1n/4zxuM/Yzz+M8bj3yLGo9GoGbW1GI9L'
    'QlPQ3SIb49G/qj+9khiK00GpUWvwOMtn8B3G79+dPj3V65QOwjiLy0bzanT3NGw9dRrt8+XQ7ExIzEXbaemnnfOOMFZeln718plf'
    'tt/vrOvW60R7lj/uV870+f1JejgNHs8wnqRHaHl4R2k+8adea9dri9fTegngOXOaADd8b5ydAqykfC2Gp/HUfn56a1zA3I/uOudL'
    'vtlpvcLs+/3Gy9X71ceTdTtSz7rLvnNjPpVKQFcLmP/aaePprlk7U2uzi9rZwhjW/v3+DM4GvXmvd9m77ln6dHUzdq/GFaWpHC0b'
    'LWNafb6eTm3pvOVX1O7Hq7t8fzw7v5mKK2mu15995bxz/2EfdVau0nh673YW08ZdZVXhL5sg5/T7kt3oCEGpaQhjq/tu1V6M07eX'
    'l+lCsLTlOS+Wy5PF1axkmlfvFq/O7PHdQHoqVa8Gz92jq+Hw/KFyNKuWFs3qzWjV5Cc3C8UYHPFzh2/N43I6/1h6vuRBS726qr+7'
    'wqAqLQD6lTE23FL1WV3pR8plqXbzdDQGfarxAF/cM+W5tARE1R+80uzo9FJs8e/CY2nanZCWF2e0wbuR9tCuv5WVkXfrvmoz0+y+'
    'X5/djcWPcpvvzVTbuVFBGzmaBQBk2UYYnxdT4xFgnIrdoX8vB1Y1GOur4PztssOPJ9P78Zu3bJmmM6ueq884r+q72u1cXPTf2sLj'
    '9V2leiGdNv3z1qUnTW9mZa/UmN5MjV47GHbPvf7N/OxBPdKUqsMHNzOj9zG5VfiSU9KGwOPavw0W3dx1Ly60yey81RIe5o/L59nb'
    'tbcUx512V7TKq1npprZSvJtnpXNxe/tY84Xz9m0gjNs942g04Od8S5qqna7T7XbNjujwbmvo3vZ1b3UjnFq97p0CerGovqode1o9'
    'egZ1p/1WbUedPxpSs9WSTidDl++8udcv/nuzIYBiOb2yg9sPSz9qVS3ppXMvuWpHmliDs2Z75V43m6t7/sVoSV71XKrc/v/svVmT'
    '40ayLviuX0FV91GSYhYJgCRIZqkky4X7mlzApbpuCxtJkNgXbuoyO2/zMu8zYzbzPDa/4/6T80vGPQIAQWZK6nNvn7ertq4EgdjD'
    'w/1zDw8PtdNlXNsORuPjE+Cmsf78squWKm5J5DfjQDLqDaNSbsh7bt8Uyt7jY12Tp/+axeS0nI5mO1oFyutP9o1Z9qns9zxW2px2'
    's5HACkwn2Agnnufds2g7qyfO6gX7p0L+seuPsr2C17CZzoQv1OXn1Ysg8c/cgrXbq8pjO7u0THF94ivNVbY8XW1blXP10NxMnrMv'
    'zrg467CKJvT0w/K5lF/W3Oqs22w5tlU92UfRtNrZllGaFoLVtAnKc1XvjcrOdrId7VioqMg0p2XOdfqNGs8YRvZ4kubnvnh6xuLr'
    'jRcnKM45VtHZnnJYPbNYfL/RbjactnU8tY/y3m6/lKeN+XxdzhfEbWW5VsfnssmuKs5ptXzdeRprMaXpwj/OH8Wqo5THbMN/rovj'
    '8Wph97slQ1Ocl657UPKHZ+xZb7OsBL0XzlC8an1z2o5H+3LX9h1ppPp9X2DmR4Nd7zqbyXxmuespUxX2trvUZzs2f1oZwNfHz/9a'
    'DvncDoQ+dOip4hzzy0nN201kRyoMnZeSsM2ejBZbyE5agToB/rLjh9rguvuQWjchdb4k7LKnTXtZt7OTmmztK+YMJCMs3MN/qjnD'
    'RuDws7Xd7gS+sxBFczsRV91OteGL5sxxFMdRG7pti4a1Gw8abe00Hs7XrAN8PLt26oa+NYpFZu95HjRN8TaqM1W6rsW66vNAGOgn'
    'XLwsU6xv7Kx52rf9dnFcnk2kxklXxuJ50/WXi0Zw3p7y9nI+aqvNs8Mq9VnD2MmmzTDzc/NcDc6PwwPvVqeqMHtiOswzVy4c57u5'
    'xswKZaD1ZqHuqIXlullUhKwzbEre4aUycPJCUxfWy+rjbK9mh4BWq89cHp/+IPXwte4W9ts8DMurv8enJ9H0ucVTtimsnO150esv'
    '18XhsT7gTF+p2AX2pXpeLKezdlnndyO+7ex3bEd6qgv10XQ+mhY7artilhW37BmGuuTbIzHLc8b8+PSSf3xWPJVV8rZdGRQMSxnO'
    'p7vV4DA5DdhVt+lazmBuC45TOFl7rb0ezANXVHxBGazErelqm85mKrclQHqv4i2wH/VP9l7OWkN9Nix3FvpOk/SJWqq+rjreipse'
    'GwGAK2MkV8xVxRxVAMKv5Kyb12eTcqeGqXdetlSd5zueyU3b3ZY/PC22ej2/4wuAj8dj45aGnixV5Dptd/54YjheWPCOErDdFqtm'
    't8vDqMbr89Wer1XsJ7aRt2f1fWcvlOuVeaFmnP0OMuBOUzwv3KO2f6k6xuzZC6aTpVFZcC230NpPg5PGd0uThuLNX5oHY1XaHJ9F'
    '3PYLoEsDcd/Vsno7MJ878/3qeNrvFH1S6nLOtspPpOopu+mbUv1wrLTN7EIecN3NtjgBeugNWpMnN8txVpVRXyrnQtWQhnsdKGuy'
    '5I5yb/W8zBvNF18rLrK1cx6TP8apj+8mbtqTYv7g91tbIKMRCNz6bqNqqjmRX9WXTkni1yZ73B5WxmLV1s5H7lR0T90Ow1Tqk2dO'
    'NI0tMK/sqbrdCfUK37Reu+t9zRc2fNFX2bLJyJq1qwzr9Yk7cYRntbVsTEY9XZO3xYI/Os/bB6Fe7CisNQum1Zk9GM/OnaG4d/YL'
    '2XcM/ex1tIm62HtL7vFJ1Wfx7Im2+ZhVjNmg1ZxmWd8dBSPFrLJKTckfhbHZVjWemdZPvg4SxA7Yp+lhv9lNXLFUH63czqLIHgpy'
    'r1PcON2R3Cq0+L4CjLhf07fzdQnGuRrMhcGa3+6qs613tstZhm+OOp5iCMMVZ9Qfnxh7FWONRnX5PJ70zgvPea3MB7pYGvj7/pDt'
    'Snqv3NycG5V++0lrnGZBpQea4azj2I3hiDOfhNGsXB0ulo5+Hp5b3m7fF/qMIwjD/GON50Glzld23F6U844KfEh0zPEusBeHqWHN'
    'pm5g+9NS15k9c6+d0szVH+fZesMPBN2vzu2jUisxY5dX7OFCAj0/7/UnzlbaipI+cvbj81IHFjFaLab+ZFQOmrycfZqemaC0yZrD'
    '9eTxZewKhrvuFPsTo/L6+jqYF/zxkZmZpmyYft/xq2ffP0j+tH6wO/5g4NXO8/xjvfMq6s/uJN+su8dRzRw5U1iz09mWPzyK29mj'
    'WDeOxn4z6WrGgiufT0L/qC/9wyxrMEqv1OdbJc6xtjPRckSX7VoaL9alylgGfqer1bM0fJ0Z5wPP+0JLN/XRwJ4P5st5ln1ZPuud'
    '+Wx7KrXr59dpb64/lQLHcYzudHJsS85cyRc3hdeZVNgo1eZ0Xxp5fL919K29AZq78rTcq/UCo4zz+kuw9gr75zI/sFenDSO+csDM'
    'b2CDoJetbr98CLJbZ16xjo2OV/COveksOygUCrXhUuk3O7vzTNlMy/2mpUE3vIVWaXb5yWTulYDRakbgef3OXlRMdcpXGM7aDwVO'
    '924gg1nii8JZPdcOe6nUXS2816o2ZXbOebDk6pM9qzotzXWqmnsAdNPbJzv4as1kXumPpPm0L0A9JVXoVGqMPRwCfq0cpr2rLihM'
    '3agW56sR281OpWA77uSl0apXfxnwz2e10t1bvJ7vDGayNeyz7k6QZ63SwJaUMa+eekpj1/frFcAgB/dkeRKXVWp79kmS2IlTqivW'
    '2VOFGj8dndVqtSt0m6VJyS1Oz0274HuVij6UF7NWVl0705Hn1vh5nykMJTdgJ0fRMpxGoHSmKgPo1sg+PrKm9VjpOJ7FC33gpOv1'
    'xN3tRnvWqLmytFjY07kYeFOnOu0Kq+pYrIl7dVYFPGKw9eZRHAX2jBXd7Pxpfxh5r/1nV2a6o4Zjj6f9+bTLBtysXRXd8ssTG4ig'
    'qIymdlcZH8RKXXVNx2Tr/XlJEOejfNaYl2uFfPPYbehWvzrNj7ZHcV4BJFEvmcPdaqsV5WIQnNyGXxlLL8rLvr8d1v3jyntlvdPq'
    'NGXGrb03mR7Zoz9o2a1l15bFzl4uyG7J5gKW4Vm2wDdbMDHKxql6juBPdK17KmwdfpctD1XlxW7oJyYLxGQfT+y2sRKDCijzg+bA'
    'uki3IfdYOI0XA1+yBWGubP3Jim0HE06stYqKX5+vum79dboVOBOIKGvw/f24tGqX1afFWLNBjm83dqtR7k170oJrsy1NbK1eB6++'
    'Oy2dXHlYGfTU7tksrqalpj6Zb7xXe+WczcLqXH1hH5+qrUH/0pRNZbZYeEZHEv0n1WnrowasCQDSjf2MPUlM7/DCPstWf6xVeufG'
    'RKsc1cbreVYxueN40uF3e/+43gqC0Bj3li1H7c5ltSlXZ+eDDgDIyKsT8Vn1Z/t6dl9SR/2ZPR/n5xWtFpR439x0hazbz1aUMysN'
    'n2egFEjVUt9q2molv6rUSy+MqawQs77qhaHgVdrinl3uC9tAdZfFMQt9WgH+e6x2C2Y5v9631F3ZreZPrXHZdDi15s95r1A+D4ri'
    'aXjYgGqlj+ZdYS6ONN46WfJ2sa87ADvdUh1UR6f9+lQyHb3QX8iFyvbcnXZBVy55xQXrNvqLo9MX2X7DH/Vro4FV4R3ddoKhwTvm'
    'xlxmy61js83Xh9PaS3c+e60Yznze3T5Wz5zuyP3py3xQDNYLr5OvPD5N+5MgeOVqHb0+0xxXfw34mtTZbVevpf5KHAfPwmTvGma2'
    'IRV3Wr00t/Mb47TX2dJQOSxc3Vdbzmw5VH2n1Ry5/Mwp81tB2uyqxosEAz/hqvrEc4PVWOgq04rWcbrlZ9Zqs8N51xkWveFxrq+N'
    'V1YtbbniKqhoVp6fnCeHfcHbZdud9lbJ7s7L5igriaOZac8q1kuzvvNdu21Lq/m4YxwBPve0ri/KakXYv2gzpjOr+A3ec2Rm0R2+'
    'TI6vxxmnLf0O67TcUnuQl0vKsKRs+vnpfibNHWFQnGw7mlfNV+dsT6iON1PbH+y8aumlXwn8414vOJKvOKeZ5zrOaNm27TorV0/5'
    'qfmqtYNRbVQrNI+PtYX9+jwGbVus1Iq7Y39anBxXo9aO5daga86f2qXGwBbNkaL3dXcnlkW2II27hfPMZozTQj4x/uCl1yh6x6Wx'
    'EQUnOCwLsxMzfbFLrZ3j2PV5daF5MnvyCpLOMoIznE/kTUlmzPV5vXmsebNha94Qzr4CIBrwnOJVWGZ51l9e57BwOrbTcPeT5RK7'
    'YDld23WMIP96UJswTMJcLRZN391ZZWW2EO2CUF+9zMaDEXdi6/ORcWBPA2E6EUDkBo50HhSa+8bL60GSlvJjQSsv5bnbVPpT5qUr'
    'LUsc2hi3BbtXOusLrXOsia4wqS7M+klpe/r5NDwKktz2jqPZfPJS6fs7fzzv9Cv6rLS1a7P+srYRt0bbHzvayrOhkbBi+/bLU/3Q'
    'P55mPnsIuKVv+lXHkupzdne2p5pdLtT4mbaya1WhdHSngsCM6kJ/uGptjLKgS5rZUHvybMS40otoScPZ2ZY7G0Zjqnu7YLdK9WWz'
    '4DjbGjcX23YgaiIvrUvtodt47h0mZWO4VneH/Wnh9ttTjjuf5rZU9gaB0uAGAjt6Lnlno9w7T1n1OOUUbj86FBquf2ocA7+PV+Id'
    '+4Bvu9zsdAyC57Zc1/isBI2rPOrFwDvY1qLlPO0bj57Xey3u/fphDzJYdEdid9XaCZN5QXQAEy7bQfk8HwlsubQflUsD7xgsgqdy'
    'eT2oer5Q3a4FhukueVU1d6VTQ+0rIEGbgLfYkdpp7e3Xs98dPK1ZUKbP88HeqzJ22ZQ6zkx3eHXUbtmLQoc9CyNFXWd7jcmTVHgy'
    'lEHLE4rK1m0MLH5sLwBsviwsX2laZr3vzmVH7JaqgzWAD6MvnQvuUoKWz63t6DzLnkfP7cForjYYQ6xPlrZRloWTNS8/dwyn3W04'
    'w1GhGnCm2bWaT/zmtHQL9fNgWnZmh4I+4rO2UpC2xeZ4xvlTp97pbF+3ftdfwepsjWz5sWi79dJppksvbplXl/3V0rENvtsJHNnp'
    'zgpioz/QWxarlAWmPXkqAl9V+nZVZkpqt+I1xH1nUDWzdWe43g/bdr2u64vFlHWWzsmeH/cjRz0C11uetIO+CbbMrMFMT475tGxU'
    'invQZ9ke91y0xP5iOjzxPaHs7bVT4PBbhV0d2eZxsKv1ei99rdEZtPfTo9MyvcGZ89XjbAhkHUxGU6E/FV529d1u57U2S0mdTCRW'
    'Py+c7HLpSKb4xANi3Qj1hZM/PLNqczcZvTQUIM9sv5Q3ptnKblrvCqWBuBRgqi23W/bcUr+uT1gjax+5BdvcFoalnZLMcp29sS93'
    'eYHX5XnJ3DOlVdbLPle0QcAKo3yjkj93Vuog8TzuPFX1aqc6DrqVIy/DGNTNw3w3YjkH2HfBzC4n5TNjV9zuguW7Q5kPRvvxtuGL'
    'ThYyP4NK2BOnpmkIx5XRdJUsuwWVYd86Vrce63t+xx9KztLrCoxQDrqAnMaOe+ytH+dCR3/Wn15t93kGK3QgOzuzI524x0fp5fTn'
    '9iet0CnbbXE1HJfP41a1wU7r/W7TPQjOq78MKjO3Xsna6s6FEuXaSfAdPzvodNrz8bTTHgtOf7I6jwNhNqycdQHWakltFabthaEu'
    'AacfHmsVFtTg85ipjprT1/FQM4iC6s1BQwUW2dGqz5a9WOnGfAa/zKeaMBnw4hPrjt1VzeH7q05pypkdTelYhqkVeHkcrIfdrW4b'
    'su7KJ68vGMtgma33Dl67MC5MiuLG5gUWND0XVFFrIBlCeScfBW6nWOW1Jk+FOtPbbs71WdObl/jlluPP84Y+r/Zm7U5jYwp86+To'
    'y6Y3EJzqoMqVJ9pWmRbqr6/qQOK9Za8EGnqj3rXX5Z1bWnNiVtkeYQZ4Uzfthc1NuhN/Nn5qWNVzXXBAjRIUZDFTtmi8lKbelj0I'
    'ulBzda52qLCnPlsQ3eaTs/de14uG8OKeFqfx6oR++IdjvqyP8lV1qovHQ+843wwHky7HCnq/Dsjg2J0KyvCl29mJ56PvNBynBXoZ'
    '4C17MFJdcTKXbcF6nvb2rUl3sNhZheJrqRe8dNTy+FXo+e5x3mzPjq9j35BqztBU+a4oOr7stAKN7zigBIhGuXgMGi1x35w2+l5t'
    'ZnbHrnd2Rm1jYQaSPh4bQosVS7stB1RTZ1gQ7uaTUi92pt7T1sgDX5jNTnlP8fdZga0c52L5ZSFPipYjlXq8Y3dO3qo+mnqSyZel'
    'RWG4LBia5XRKijtShyrfPFbcQFfkXn9RB1VzZ4ka07fUQ3AS23z3cRdonW0DulxeMov8ZGvb+/nUdV46m00JxhBJ/6lrtmu2vaxU'
    'ypNu05f6/Qnb8wxNrPJe15Cyrlp9rrZn+d140TEsWI6yxDLj4z7oKNq0M5As5wBIpprdT0t8S5OH1b46cOq756e5bix9LQCNgDGt'
    '/2G7b3M7Y/z+jJHZ5ux1BErQ4LgoLeyGVXI5B4eiexxNhwtQ/SsVeS2xm4FnBFx90dHKXJsPVmdZqoMiarvZEyj4e1GTm+0Swwvr'
    '6lRwHBxK0K6n+ekrOwdx3XjqjSfdoep1uMAxlWAmGdNla6+rhdGponq7Q9AInFFRHhTzg9d6wZuVXkv1xdKXyqYqD3p2EbDZDLQp'
    'V9zNq6yrKgVHKO117XBeya++XekUx8rr4TTgOqqxdZa23R6AcnRG27U803VRkI79w6zml8vPwb6b3Yp94FCFAPD84Lmozgrt4HCs'
    'v9qzxdmqQ+sFHBhl0jl649V5IALIL+zmk5NRrJ7L+kuxlR/3haz4yrOz+gBAi9moKibTVtqB/TQWxeq2PN4surySTDwoVU+bSm1l'
    'o1t/fzVeGIXF8tWrV68+NOVs6TX7PGS2wsrY2r2R17Nmz1kz+dpwlmvZfHnu+Q1/vulw3cnkaBfYTtbRZW40rAGaE4Bnbkq6MtK8'
    'otRXhAAw3fhcrnN6fz2ZLyvdxdjzq8qTNn+eOFynzx2Hk71jF+2GIlru3IZ13A3a3MHfVXeS9lzwgr51YE6AVs6GK3dccQFU6ZzK'
    'el/oTkVh7szk3ZjZOwLDWcOXWalqj6o1PGkLKyQo1V7NYevceq4ubHfRPWq87nSFxWwg5o3ldDZQvclEqIlm3a0XxACg00it8ow/'
    '3Jhd8zFolGbn2fwZtIglNxidl8FiVAGYunaGilMa9mx/VDblvlsbH6aDSkXs6Dbf2a4tZ1zf1fuTo69p2sLYznoi/GOBFtDSWurh'
    'qQGU/T/z36AZiEdtr5ZAehqO48AKfWy2LUNsLHXjMJ8ENgNwVjH77NaeDfJLXlf3+2llXp+MPc7jW8Dy3P7mWfD80X7ZnfOiv53b'
    'I3O23xYb2lJcLufnpiBl9bLf7U9mx7IfjG2dnY2tubN0jxWnvAWOMV4cABtX1fNLUNhnK2MtqE71wao30zhbyZZWhfUieH5pzKRG'
    'x/eF1fSkZtW9epieh85oWD9Ovblu6uxSrk/FwVrUBdn0GcNt2oVTVexPCu5kIfdnDXYh42EJr9o4GXaRKfaLwdyV93WhstydhqCr'
    'jIP6WWgDf5OC/LGyVRbivFFYDdi5P1Hzp8rh8dnsXg7DsM1e91Gwjqtxh186U/awKIw7zsLIHx63+8KuVTc2x6Wua7A050zF3AMx'
    'bpzGauqoXW0jro/ZVrcrdavSsrtSREEfPVYHzwASWH9uTTW2vJyobNPZCULVBsWtdDKqhljIruAf/Ww0RW/+2l8LM0Y5i4XZ2JDL'
    'VdcVtGpHZQqv7sSo6yW11xBW/NTfwdRI3ICzeG0otFv1vMEU1flasvWNUWgKMivK01NfMwt9zVX6jf3cGoGSCtMX6LI/XDjVSb/u'
    'OrI1KWnl2bm7LwA22T8areZLsw9N7MtbwzEAf/CW02wPuof/ESrkB7omBid+pHXMV3c3GKw2+e0oX2j1eke9ab2cS9lmtt/MPzZb'
    'iU/LEf9YyUa/RdtoGiAZG1x12QkUfzTbT6qT8QiUgn1FzAd2ke37ne3UnUxh5Jeuw1pTK5ALmxb3nJ9rHNfhxoUOz8pKdzJqF0C9'
    'OM6d0UBf1QT7PD4LAdfrbKqmJ7X5MbtXvHbjPDdFE9okKs9QfOn8XJjxi+N5dhyfzMWRKbNK1rYtltnYXFWszsqaUz6tek7FlSZr'
    'vq5LU+sU7F92Zd6STfWotjWlqRfN0cEvS+OWY8+z1WmhG+T3q8NgZc6D/nTHKy9lf6hm84eXvXLst0/GSRjt+3Oz0Zu5/tly1f2o'
    'WBoesjtT7fR3U2lRNNBs09rO/MmoNnFGL96ztu/yvjrh+G2VK9VZcaZ0mI3HsOVq+fGxtenecghv2xiPgu1uwZaBM5TcHTua8vrr'
    'ZtUrd9pNuaTInRHf3SvdV5vJDoaVodV2nhyHWbCCNqoH7kBXXjlRqzDC/lQ4dwOjvuQ4p9I3HFdkuZMnVVXFzleD/atZdvR1ua1I'
    'K9VVmnJ3KYA8H7aM0lkodln4X3E7lU+yX55rQZudTyxOC5x2wStPy9wEOL9d2dc2A27eraszo908DBd8nR/kZ0xF448Tn2f4auFp'
    '2hLNqW96Z75YLU1e3ULDAAReKDhqqVqoloMnUW64i9rxvJRn0854ypwXHV9buc5sdGpV99uJOzlaUv/MwDqoL/PyZrgd9HS9t+eV'
    'WX0GyLs0GRQH5vA1f5ytCq2BuslrXj54rTZBC0x8kP3dVg62y0ZnP9XWy8Hh8Wn3z6yVbCNfEDeeAsO3l+1AtDuz/vw04Fc1TRGd'
    'QGuBOmMJ4/PTeXzsa46v7pR5X5LErb9wxuZOCEqD571saMGcU8Y1W3aypclhIXtVb6uWPGU+3e/00eBltx31a/PzHhFnqzzcVe3q'
    '0FB3kxmo2txi8MryeUcun2vNTdevBq+PL86LEW43aYiaupYj1/vlw4uha6tnf95g2XlXdmXNPuvt6alT6pvZ0Yl3jqsla9nWui+I'
    'm4l75Do72eIYsTredkV7/9I9L5R9/WlV7o4LKjeulMdst+9rAOxspkP+z1v7XW/9qp8mkj4cLtyCaAajhTi2NGPLM7NRs+Wok+rM'
    'tKcGkxXnVZ+ZFc3xrJwXh5a+lZW2X2SBQzxWHx9rr/r67WgfnjjLbS4BIs+fR7Mp2zuLKu7Tl6u10RD0Ba1dZIdBa1Wa+Kt+fVke'
    'SrOOMxJ6lZ1bHegLRtQwjspo9So67MTgpR2w4yI/fNUFaMSoORvIR++1aDrLmaKPp/1AKPCBvlE822YkGAJ5rxeUcUtcPE5rIAYq'
    'p2Ul77COLs7YqTp7fFRfpiRqR12osyOl/lp8fAq4p8rJGy0kEEdjduof/FO3UO0O8nMl3yopglSda93ubMBPFd7v95Xuqnv2+1OP'
    'KxZEscvG47p9tY1J6bSUNv3homtLdtMBTu0AO7CcvFcWu465Y5duie02ju6J8zfVDaNuCuzEVBdGxQZm2ZYfn6Tm7E+JuiZU7O2L'
    'Vy0eADnygrY3/KlzHopmpX4Sh/PJUQQab9kCQLMqLJnBouoAmu03+2jaGNjjF/kgb4q84+hupSXI/a7v+gNL3Aotrqoeqn1hkn9s'
    'OKYJND2wmaHAC8/mub4szkr515I58zuOYFeqo9l8Pwf8+bgbTNqrXt/1G5xY5xVJPHUnXDDYi8tzPdsq5uet1dGcqDtpwnpqZ6Dw'
    'T+hXf1g2D+2n8mSw2B+bTb70ku0pttmbF7fbqrzJN4bjvs1zw3pjsJ7PnZLcGFWeX1XmbHQro2M2eM1vm8kKtsxWVP3t8TVR+sty'
    'tzdaJb4/Ox17o9WqO3vl23yzkV08neoz02055Xp1+TQ4alap0zAEQSypdpkdDQdae8+fJzNWPVtHzpxOKgOvMFU6Ae/5+qtYUa3z'
    'vr05lIei1xD6Rcdit3rAuPOjL/TrJR2URKAvEI7VKc8wc7stDjypMRr52+2CBf0R5ItoACSVayBhVkM3KOkyawtL6RyUZwVhP9qO'
    'Z8XHx+3udn3VFhXLOJ7nw+de/QTCUs1yJycLKrAwNwotbTA/d7bC/Niy28dj67jbSVap0VePpw5atoT6SO10Nq7DsNN1ca+Oys7a'
    '1fTOrloar2vFYvEkjC3QkAvPrFB/3LLC2RlbwlRkV6VmS+PbRb3atrsVu6f4iqXbmmrO9HndLs/r7QHrHNVesyb43cABcbGQYMCY'
    '10al6syb5rF3ZoNu5bU8DYZDbWm6Mkzy8VyfV91iw7X6Zz6YPxnbx4Lpj4uVbNtQ/eNKa4r6sVSZ9KqSlq8NFk7eXz0qT8FKOBV7'
    'zOK66BG3Pe2OHMy0Ii4MmNbCwCn6teqLPxn2hBW3Xw/WhSESkdiaDUrD/lb31Zdm4dmSvNO8MzdnrX3T4GyrwFQr+53w8lSsn2bl'
    'BlBIHtSJp2l/ETB6/cVx51074Apd27UA2E9G6n4iTzpsTWQbPm4zMKNasTUpDzj9qSyfrX6DOQG+P7PCQi2tpqXHp2Vz/Pi//vsD'
    '+0Q+v/zbhygwdXyheXzkh9xrjteH4EkcK/Bvj9vk38kzU6XwPlCMVY73vETXlIn0LsS/fdj4vu095POqmTtoO81WFU3MWe46j7/y'
    'Pc1U/m6INjTMVUUFL1AL/JQBb1PwNjo/I0ZXl4VX21jkFs7MbQs37s35JRo1W9YDvB/lgDdp4fklejUKljKzXBJsO7pd9d2TXzfx'
    'pNmbgNIFDLfeJUG6f6BjkQx+zDM5huHKTLnKMAx/FV26WKzmSlyVq1SKZZZhK8V/YZR17vfOgZGGvj3uNaZ3e4nJ+/VwiK9O6XUv'
    '57XCaOM4huGN2+TUG97kodN7ael9JZdL60gY3vuUInobGuBcsXxffXtoTPpZxHsyEqHXRT+6UVY1levQ7f4GyMG8XLyCNxD9x7//'
    '34+2rZ+wAfQmRBoL/j/+/f9J0Xvyrl6nyA1al9uiYloiY7V7Z6zI69TW0sxLk80TuYoqvIIn0Sm88SpFTrulFG0F6gRe6He54SiX'
    'uhn58MK3qGCFXHhGh3aXgpFWdPXqEkVyf9jbewXoycebu4Xf3N6UOE4l0QN4l6ujkllzqejePNIMKBqvfj3panTV3XWxN1ep0PTh'
    '/WLv3vl2EwGdu4mA/kJphlxT/c8trVKVzfFMoVDGmAyVypuw4tEa/ucCt5OKL0GAseM0DDA26wM5CXvpy018dO4mPvoLofrbvuBl'
    'dTmOKTGFUrXClQrJEM2lEp+rFkulIosx9Isl9s/78gcxpn+vL6RZt325vYzvJmo6udAmye1YaH+uUigVi2yhzBb5q1DTeKtTscCV'
    'OQykzZT/iX78UVzm634QlkEiv5tvOnETRZ27iaI+QRZyOx/lajHHV4FuKgzPVLgoXDztB1/JMZViFZg2V+BKLPen/fijk7rX/SAX'
    'QZBI8Niq257cxFrnbmKtU74EUhSYGl29Fz6T6FupWMhVWL6CN4AxLF+9WjcM9psvlwsFvsAU/rxr3KqqFos3XStemnwTbJ27CbZe'
    'JHfsintgTisU+T+kvI14ddcuXyrmqhxTYUssz0FjE9cdcCybqzAlmIISV4BP7L9Qfv7OOeoCXssDwi0SCoVYKISXcXjRhT0xMwyv'
    'Ek9cZafpeM0t3v9JrujdkKvtLleL3EfH5D3CkUkTYhATceLE1el3XsoUDRXlGLmm27JTRBIQrku+aG+gHDR8gReo6BoIQff0tjvJ'
    'e23wPvM3V9qQk8+01VFDCLbakMkkR6xBKOw19UBknOgCUeIUE6CoeOQuE7yW27uP762LDo1Dr+MT47T77zR/DHTyzkS8d49MdO44'
    'Pew3MgnRTG8+QSQC6A9xxSmFwen/6DIXghfTOcWSj8mSDrBaNwQvkY5FqLJhWWuY4BdLhvlOXImI0xrfTyOp5NbPDUVN3n1i0vGJ'
    'gmuSRMQz+H/UugjFJm5xvNxCa+vYgMTlWPg58MntMteg6tmyT8mbF904BAO5djHRq/cvivmTyxe5m+sMuJvrDML7rHAdef8aRhBx'
    'nX/6Bhnu5koC7uZKgiZMx8MN8WdTHqHy/7Im//FFHNxNfAruJj5FLdZ5YBXcUxL9IWVY/ypm+7bB70vvS4Nv1CruRq0a6IiZCbNM'
    'BTYMsUJ0DMNT9f9CwnhfVF/ujL1BqoUbpNr6j3//vwyAyXhjd8jXkvCIKzC/h/JulcHSnwozrOONMGNkIJPq70VhqV+a5YEuhNE/'
    'JJVE9iDawunCpChHwAt+cd2DSodXDpPrVw/kAnVk9XZAJI6RSz2G91m/ieuCFb4N6nJ7T7Rq2H54KTAtAvUWcmlweP9sLkUuM8Yq'
    'rkK6kHuLw4vObLyJ2lrRK5HDa8GudY3vyCR+oCo6ncYPhRu4HpHIyrWMJMSyLsjzFmuGlHGDlSPsFBYUE4qVgFHvoO+wsNu7iQtX'
    'hcWxZ7AwPuzad99+ynuyq9n+z9/9FD3Ilun5qb+mPqe81Oef4xv4ck4ArItqnpab9jKfwpTefg1p/5q++4ssmnvRu8vco7zWlfAt'
    'ecaXno/xdehL8owv8b5wmFv6lv64i4uuD/oT+HT3UQTlXP3onTxfNe5TTzgdPVEek991mN57gAtrS01NW/epkQW6rXWfauKi9zVZ'
    'TPXVAPDFo6uJOrRCNL2Pnupqq7tP3+XzqafoKnZyeRuK4vDCN3pN2wPe24jkhwYLoHAM4oIwwIAfa7wtEJRvFcuVdKwE1pm2hsrt'
    'wLVRfbahpbmwN8PHbm0yqUGHvtyF0uTuPnUXcmnySPkfeaRchTxSwEwe6Volj2y1zMoceSytCopME1TlAi+VyKPMcaWSfPc1Gs3R'
    'YDD5e73V7eKQhhD2Lvo4ngxG2LQ7Cj0/hiLqYc/GSVq9xt/HrWVtDMl+S41B42HuUz1kUfC3iyo4/J13kXCZ1LfLHI56j5O3JcfF'
    'Qotqfxdqo3Fr0IdkxU9ApjAvUmDYsDA1L5VGtiKSYFAYHwcXcK/VGD1OIMM4Q0x0KFbpnaoiXoXnAXig+C284Pu77zDQD7AGEvXl'
    'M+GMYT2JG6uJoSKtQaPQqgh8IeIZme9onCBz94x37Xk4hV/D/JGhxbvDOwOxGJmmwYVHv4rAUn28kPxAYlIhOsILJ7FboVlxBQMC'
    '3y71dEVgsljPb9/CekjjNCX18eeQnaIVR8dkqQPgQyzdTKV/Sx3vUydYgPepTeobrC+sLCydVghLDJ5pRZibXOQbj0iiQ2jx8tSw'
    'Cg1BJ5ZxcDXgOybJD6zhHkcPssPMI24nlHFEI0jqRP7dAXkAg0qtVRgM7A280pRnKzD98OeG3pwNLYDsY9VPw+rHwgNTscY+3piI'
    'g31Prk9N/sYAQBMMxhW1/p5c+R7/CDsa/9YBj74A0CVN9KFxSKJYEcKFJjGSxWnxVR+1oLhkzQVp8zm1EnVPRU4GGGgmuqaqRC8/'
    'fReSs6KuxED3ce7SGWSgMCcgrDaip3nhnVaQQ1GjZwKmH1J39BZHWLgHV7ThtwEdCAz4LQa+NQGhSjPApEYLZzZ6HJLemES8QJdy'
    '5fsUzYe2G7wiEqphcyXgX6vVQ6plgjalQUfixSnpIlkPcUsxsFlLIbk91ccBhLZFXUpn7impP5CZMy0FW/5bisF/NIVMOKIaaH0v'
    'vlbz/ooeKDYJoUkKYQl2FRJDOoJIHhJs6hv+D7qb/zH1Mf6P0GeoIFNlGEjcEH2KPijqI5faJ7DgJTfKQEF1PQ3UUeAtMI+nVJpY'
    'PwhrgUZfWEsKOAgoZ4gg9mEWosxgA3CcYIgoAsIAbqQlNPQZ1iGRKGQ+uXge0x/EE7QNWZcC3IC2FSBfQJhUVDpeJgglqwqtFBcE'
    'tirzQAw9sJBSoC1AktAaEM3WZarCOYFhCyERiH8yOB/yH8JKPtCyuBSwSiBwco0gTIseeOE4Prxh1KSxYXaKxuG/QioGhbq2V0Nz'
    '9Yfw3YdUGvAYoklozofMJzJMJomAhnw1odemKUUkCIKWD/9RusiQ6hG4flzplkjWdFTz28ypO0wJCCLCbDAf/gHEdCo0t8elh2V8'
    'StnQVbIJQa3T5LrTsHhqaaMtIPYLKBH7Amo73soq6oCn0CAB3b0yrsSVIL9Bc8o9Na4dNA/5dmh9AQpY+TAgyMgvI5LJpUZogsF+'
    'huMHVASUZqgiUiOSdVy+bNkaNJRAWFD2bRvY5CqASvaFkPQT0gxtDWSTBSE5sRNYHmHpG2oGOoXwfmdahxytopiKjAnQaRnYzAmo'
    '9gMRCdBnb0PUQ4yFiHcSIwHH0gO6MY4J7NL7TyRBSExxN9YWUdhwPYU9Ioj80pxwi0+nUlH0yH6CBFRn43JSkr2MIzoSNQOraJme'
    'RhVBMkJirH6DUBN1WJne7y+lkOEBx4Qa6zCieRTr+ADcGOYDZXsu9WP+OxnkiwdI86C6+LUGHNkF6Q6iElYz/fXbt5DrJljMZwLZ'
    'WeCxIQPO5XLKfbwUKXi6T6w+FOqQg4tzkEH83fSF+5ilK7nbPuK7S38vnJ0UCUgADXrI25BKkLvBUkOTWKhHMZnQDkXvol5prpfY'
    'paIEFK6kh9RA2gLGyuHg1aAUmOJ0+EoNf0LzCO/6xz+gCZmcIdrp9JcdNP8ryqaQVPDF2EcjXnoHrz8DqmTuUr+kyLiZfyRegCc+'
    'YFlk9OgYFm5HPR61IkkBUnIVmOT+ZbKYQrmRVjJQn6uidEjRqI45zWuZvrpW3bTySy4sJgPtUqIfUDl8oT38BTg5CMNPoH/F5Rsa'
    'UKSvpjGEYIbQBEKTPaKLZM349RN81Fap9D718xV2zqQw9uWBiI1rOkzfmfj7LpH1pxSbTB8ls/zL8qDJ6cXiJMd1Zb+hJBOhgRdq'
    '/rL/GjaRtBwfo/5/InsSWPf35HXEYmG2/ZOt4rpNvv4eZ9YiBHL3z7UznA8s5dN30UKL1+rnsLFoG4aVomtnNQF2SNXvLA58fcMP'
    'Hq7aGS8a8pI831MTdfiKPCcgG+Uh2JyQ8H534SYH+x7pExYILQ2pPaojqiCF6zbzeyv7LQeI12W46i4dyYX8LhMD2m6rX/v7eLLo'
    'EsXvyx3ZlEcFk+5lkidii7gDVP44Gg1mNJ0JGAY/AgfEP6Dxuz4+gHa+waSz1sukSZOi5QY/0cnBJ7KXhaprvEJkHeQfehOkdSS+'
    'UHdDAX3nkRvrH0L8ZJkfQ8Ca2ouglFOPjp1q+9+hwMQuyVSxCilST/3wQ7KXuXDjxEvrOYIJMpmUTJ8gX/juKjPtdTIfQeQkH3ki'
    '+cjTVT46BMl8ZDOP5KP3u2M+8pSgcRkJHHo/UqVA05WEQEsTnVMkPIMqDmRnCWQPalMpzxRtENR+BkZDJTKSjNhB1fWPSIggSOmI'
    '5VJ1Ah5A6mNFZCeBFm2eiPJJAWxoMwG2C0CCXFNPXsdbUSoB5CicI/kb6sB3CHjcXWATCB1a7rAmkMig5JCIu6L3UYOGXHxycAZx'
    'k4zgDaIBY2WeCBoNAAvlyg5wunPVCJO4oZKtKrkLNV3YgELZbWjLwqX5S7x0qDC6x/Cu9ENCREVYO6IkWgBgXFSn9qjj6bpE1VWG'
    'aFexqKijEqams/sM0sCeMDsUWJdfdyjTsntY1VEplxo26hGKlLHE/H/7yxfmY1X8uPr6G//tr3kth4aGtEwYIir+aZrly049oSBF'
    'eHQjdaFnmUy4k0wTa6jS0ramIR8pK+Tcb4SdBoMHgwFZfgJ9Gp6+NxMc3bxh41A+jGqgfkrUhjuPn1NvSzZzVJRnkonlEC6RBimR'
    'rhnVliOEQTCBRyACDmL4FlAAVURhfqDsY4boo/THKXMflhmhB2zUL3RKIFHYkihRqKXCNEBe8iND6iGPKZoZJtLMEXWEjABRSSDR'
    'RbN9iIyBX2Ds/i36kdNVc+1vvtKqvl1GHspElkBK/BwV/TlZdPgQoZ1LVjNHzJjQkJjG3hBimIawHZr6cyp6mSwp3p4jdaM1AnMk'
    '3pJ3iWZHM4ORvml7JctCPo7UEL4NPyfrCa8lT1YSvbqp4Z2u4HYsWVjxs0z+4qLRRcNO90R/kwP13FTi5PepjwCU+QStf7mzNV2n'
    '4upIpJiua9BJIpuAou6+Xrg2FIJKDpUSRN3BTpGnZIGx3IRFQAQhubL9uiC8zZ2Ugw+kGHy4GhtjjZ3L/7dLsOm/5dO2uf4Hhpz+'
    'x1pb/eOgSnYmCj79Rfx4Bh6RzX/+mo05BCkmh2s/HCj8eQA8ySR+b/B3Jl5wMqkazU2QD5dFWMR96vAQF3Gf2jxc8ocUTJseW4+/'
    'kM8Y/f9rhpY6ptMTv6fZvr2lI7rFfbXEyVIj77GwMEH0Ksk8iIr/OQEjTIQ6apK/hUs3ZJHA/EAiY5JwXWIFYSn4h2YkQgBW8Vcs'
    '+xPdV0FoQmLnR1tORoANQAWV2oBE5BIfdZBWepQEDTao4q4tlMuEPNEaJSK0sT8Re1CoE6seaMW0kjRwHGqlDQ0hID8NzUN97aKc'
    'Xe0spkDL2BAZSUxVZKPO8vzctcAwE5KCIoI06eeNqPDUK8MtTqzyNRxQUhrqMDaZDtq+T/Arknaf6BcyfPbXiN1f+DtOSPQVhQpW'
    'ltuIXtrGVsRFxqbriCuGrPBTSiEehSk6zZ9SkquKu08hVaVocaKiQHEXcot1lPf6nvNgONMmUSLiyhOiO8mWqeXqglOplUEkROD5'
    'ZDZjTflW9hL+ZIjH9EeWAP8kOYYtQeWYsj6oI5ti35LibwkB+S8yxkbEHS+n3QX8vAEb+ntgAwAUzUZ1/P9p3PG9TjEH6bdOjAtf'
    'r974FvlNP5GZwXfvIxG6z/E5ghN6LnxxjSfC1zlXtXVRVtP5v3nZ/BqYeeouk4NURhroBCSVmobxZTngnwg9aD2k71fzg816CJsH'
    's2U9kPaRWU+qO1T/Q8ShXxDHb9EUhe8uSiAmpo3HVPTp+iPhjrF8JcnwTbTDQNPezjiQZOuKPv+UNt+QLxmBa/K9AFuqysYTAMQS'
    'vrmegVDn/edmgGMSMxCqT5TocBxu9Ol4kOhqCpXmuLuIFlEFCFVoFrpHhySLz99RphKp3xEbu+z8eLnombBAupMUpqL7QV4O/779'
    'Gu4QeYSRXcSfiK5oBPtdfiT2kcLMdDcJtHGifSLsiDeW7nB/CP9aq1UShng5zIQ0Rp9Sid2osNTLnpSXi55jegrh6/2FKYXmBWJ6'
    'u1hncLdXU0Ifg1zMvSJbiUgQEN2ZuubHcfLYrrLTFC8uDTICDQBw8lGReMOvgXlE2TRvZFlEhLzL1aMdXuIdCbL6AWRpzLZRsbwS'
    'rXGZhN3+Xpnv6gaX9hBvm38i7+c3ebFhl03HqzGgTUIB5vrptHifkuh2nxii/V9+SYk55KkfU2np8k7Cd5mECQYGYrBKmyjWQrNg'
    '3MRIqmew6al+Qn+Llh0xAYZG5fjASEqkJaN/BzH7Awsk2/hkS14LHX/eMS/TgzmRzw+sqdjtJxwOWAbxYOAWdVL/ScMLQt4qKnhk'
    '4NKZLwwsASXRW0W1/Q3tLdnsRkX+0x90/Le3XVeyWeh1bJu8svh6geTD/BFZ9lvIAhEAfk6RRXABUBqtWAMdGw9YUSwKv7PZTFLu'
    'yihwcR2kIdUX7SuIV0xuB94mLeNMxjMBr7El4Soz1y/aaoVjFRPGpcOE+YmSlxaBNuDjv6XSXOpH+nrYuhSpgK4QvoRxTSSBbAra'
    'vj9d9pyJFhYaSeIqKZfVzLR0f+G48HWPBAhU0xNlL4UbW//xv/+fof8DdVenPkH0G3qB0p04kDbhwRcX93jwlNgJaE1GExI9F5TJ'
    'JdYrKpZ5+PMPbbgBbAZ/RCUfqkriXluLvuXmQNz4aCVDRHF5C/W6j2tqqYhMGlBSB8QdyjLsm3+RVdjCv9EDaURmQW+oPxvIrptE'
    '44228v9GRdt//G//L6R8myYq4+IxtUvUS3v2y6VBaR+FoU8G9JEqRJqMmxuRp4pnu6CSJr3Cw51FG9TMT+gx54u7cL+HGv+iBF7g'
    'Ep2FbLyBhIxHF8v/TJ3NoUm//oTeYmSv7PMHTf6QEl1N/EhdQD5/QOHx4eefcCrJOcAPf9E+/vU3zPvtQ/7nn/KQ9+dfP3134w9A'
    'TehkX/gH3CSFpuBzIgVuz1EeKftoPItd2mQgDF+t6Sr+St9F/mu5teo/A0SEfqTvOOUyusTyWyfualRuET7MEAix8ojrX2p1QMco'
    'RNdH4sKXsk/ofUfABU3PxunZMk3PR+nZSpiepWCEpgpLLcWpijRVBRcVzOXzBs3AMjrVeNS96INH2ecH0mSiDhLfTMJaicsj3X0P'
    'nW9CC+3FkhN5mudCvyn5RVXt0GGHfotfJE302IIOsiAK7a88fT696+nzVu0kkitSDajN4w2rjQr+En1DSJ1+5y0sVSahIf2TSmkf'
    'lMJYISVmJnwRjw7ya9oXokCalLkm9MvQBICSToFhUonyj7o+0eABA6bC6UHTOR6YIyMaSb5QPCCpUcM3rEqytx2g9n8w6SFJ1NiT'
    '8/Lp7bz8Z8b2czy27+lGEpRIiyfy/57Ihlg+fgwfpcRIXxrzBWHE16Te8OYbzBKoukom0jf+tNnfJ6Y6LOBPe4LTjv0waevDdobi'
    'vA+4J5zw9wS7RIhCuhXsIeaX3+/m9YfrPl6QEPU+jfbULeKGAjOILtaHW7iZAJsZSktm6IuNyCmxu5GYqz/AahQLmb/f8T+EcnR+'
    '9pqnSURtewd3EhT7fbhU0HRj3iLKlXYcqzqyCzKvCaCWiZqdyI6wLRM6HFIQFy9hMqDPeNac+NiIxGGByDWWS1l3Mn6BxUTMarjM'
    'LuOafjuw6OxI5+Pd0SWFPWINZHxjBRbFQgSRAdrE8MkXTQ73GWChuDnciMkdyeMR10uEk/IpLqGjAkq/xVqYOPn7DRajRDWjO2NR'
    'Bzx0LpIv42Kg4z6+w2mjqmpiVEIPD1x/ZIAiMZBwX8I6XBWgEDp9hc5wiuaGXAtLDsnItjQijtBHDvRZkxIsqqqKgpwtMS+ej9Zu'
    '1E7w1JKLhemnTGLEvQMspHdG3L4h0NB8R9U6YiiMtkyTU3YxOawps4/y/86k2ZdJs3HSPiaT2CTJGpPYJMkakiRmMpGUPHqAccVM'
    'CHJlC5B1JnNRiaXT+EAZ+AWNJzovYuWJ31KMTKTTINy4+U/qdwRAjCkx4DlQ6jtJkiAZ6OIJ5U4Y3YEYIHKpGToXotr/EQ97pMi8'
    '31FUSDxjlbCANMFX6OgFdZBXRJ0TyYFTl3jUK/QSXnG9RpDy6dZNLkG5Hqp0OE36iTo7RxCTFEx2n6j6T3Qg6BlVd9FWEJllLqaK'
    'X+IBe4jGPB5KNPDEg2mjmU49ouKQ0FMuxllSmY21hTxvR5oAI0v4aJiTWLzCL/Hw7wgzpCIT5wBHjq5C2s9k5+lgIUolO+Dol0VH'
    'GOcIhUa4R0l2u8nOQ8TUE7wWmNxZJT0jLQaee2k9GatoJHJQak2UN+n07j6lhSrhLt4a1D6he0hSl6VFPwLvh5yySpdoQorbCSmO'
    'C5SkQpFIG5CjLTDU6zGK5FDmuumUar99R10gPAuPdsUMD2hGXa2QG+3V0CsE/Tsj8QpD42q4a3/QzKRPJgEwMBUX3Bz5PCcGEIu7'
    '5j+E6IjNJk3cvdCvK4JF6IwjU2XjQoCxCRBErxLtt6XfohkArfDxE8WRTwQL+DFauMPoDcf7GEQSkIjblaHbJLEiEtlHdljJmd51'
    'oIsu6f91QSSqBa2GjkEa0ToTqYDU6oJlUwR7D10MP0XINgKs5HuG+kSTjxG2IXcaE+RK60EH7QCI4ZT02gTFVqW+vUjNONKf8MgH'
    'vXqaVOWGGNpVP1JAHDEcLF2UwkgRl6mhbBQGGRUuGOXvkxMVY7MLUIpRGswhm7BKR4VwWAhO6S+pNCn8Z3iFz8BVuQzIb/qW/HhI'
    'EbMz0SguOyaqe83YRSC4tAQ5gK3/iGp5Em4nrH6/xHonOqtEWiEWl2ZLMCPFDNUPExvb5CMol8UMFs1GiuN1HlQhyZvqfaoSmvtD'
    'vzkvkoO0OCkHb0KoYVuHNJvDQujmOSXXhFBdHeJN/eQWA+jExJsifk9s3PChSD4kYClKJijkIRxtmhFfXeq42WbHNqQvyjXZs0er'
    'NdnDTzYtuaueyMQQKzrZn09o6WTTEVtAd+yxQLplnygR3XtgbPLYPi+5yZAiroQyzIyHswN8lHgwPKS+/z5ycLiPvO+xNUAUoqeS'
    'fnrUcu7DSni4pgOkTTqHMIU5nEPvcJMk9FohqbgczCwX7k3g/IfDhrZj4sQA6fnUw/VM20eY6V1IHu9kKL3JcCIZqGX/4tBKDDE3'
    'eA1PnoVcFMcKzTEga4iB4Ne//taNvDxgxMMnMuh33/Db6vAtRf5636CJf/0NzwZ++/VTcntqhsurm7vMKccj6URvkDS4Ar4h20I/'
    'Yloyd90cjj15g2dqvlyxbNwBoYwhMe3hTkwq9sf4PnQ0+iX15StUgJkmaD4KX0N2dEDCNiZL2Vwvsy5dZmyOqyT3xQ6hw4EX2n6h'
    'kuQeHP2ECENHrkIGNRx90gRC6GR3LHIufKCihRiXD/TwlrYhVubvEm4mF7M09vQd9w1Sbu/uayqf2CSL/EBCHxDACaSKRC8jb5Mf'
    'Ux5+3bz3dRN+vew+rkVknlDWDz/cDkYl6lBoX8YSNZTmmCd7nfpHGPSo73G7ZFXT03EXfFys8P8LIUE/u7l3lgKSUpHYl7p02cBa'
    'S2Ht8oa+w5XBRYN6KQ/dTcPyvo/Ly1zag62ABrAlJhNCgBGODWBccppABkAeH0SisZu88LQiUafQJItElzYszw+RFz0Q5CE2FPWQ'
    'fIl7CbJIIrVpRbglSA9xhJAJYImmh5gyihNFTb6kDi3h1dADHpN09gwVhotM7kEHQW6cNn9A0DB0oArfX3YePtI3MKDRnGaIIgOL'
    '52MKV0yGfH64UO9V0e+O9Zu3kXfXtUvCCKeS9HkEelHgpX+jDPEhynyfUgh7gVknSwg32AnG+oydhEbSpn9MjeCDa5EjkOkRKpDA'
    'bH4kX0jyH0Myoe0nr0JsSDIRP6xb6rhQLjAIahqgRRMt0wE4j3kzmUwm4ZU0Edde6CX8Fx+fNTrZoQOVp/mUKtBlGZ0gNB/3xSm2'
    'pCe8opnPxTbOU8qTRT1xkD9G4pQK6dEdf4M2FicQXT8kV2qFIN53gBklbb2OY4d5KTzWGb7Cdl5oiLT6M/kTGlqomy99ddn5R+Ho'
    'X3AMDhrL3r/DbZlcuUiWLk4Vij1RueZIfsiU2dJbocUDNvnrb/7vySR5A1SFB+mxiYRF+6Hfv0/c5i5z+IZr3/3lDmbVj5g2PGPD'
    'vmViIwfpbkjkP4c1xH5qWC/d+iNnXaMTsBLuYf+ahRYnMn+8yvzt1z9r2Z/lf9Pk6/GYEf6I7QOlPYDJSnuBcZ+Sqa0jwKAoMgoQ'
    'JraO4dzBjNJMcaVsJkKkyWliABV9ShJLM67umtdczy1fIlLxHnM0iKS5ygMLUX43J5MrlTJJ3pPMRvYJUtnPUaFZ0p5PoTD4c/5P'
    'R+siXFBduJJDBOZSMcTyQBkpFRH1u8VkLgdwroq4ZXzXMvFA0QgHuTdXHzbkQ6F05Z69+x22vjnZlp9GNkX5eI9oS4dwvaVPm/gd'
    'YZcXgELbuwPyZokd+03bdu82bJe5bMMkvcw/polcvpqNzI3hlRwF64ansuEP8HXEAwfK4REZ4F9jvSCO3vDxRD2+s3+IOKhI8zcP'
    'bz9RcE7IJpwqwrcIJTbJv4uohretJwP6LbT8NoDBKicSKovgTxroBECxrR3x1CRZydQVNdoRx8Bb1ywbGVsmBwNqgoqOG3UUKkTn'
    'LxLWkBji+uQoNIG2CagfujJ8Re3Gj7ek3zCTiMGlfvpMirjZtbJFV4zwTM6zQR6l7/5GPSvjTZ3QJTfyskvkJkMBubGUMHc+lc1n'
    'Ek7NsY5PSvmF/skiXIZ/Sf4H8ifpyYwdgoYTxxBat//pstkUe5hGUCThh5FwOE5FeZOlh1seBDXFrJ1aL0ilJH/i9FN4MJO0Ezcq'
    'Isfey5Q+0H1JELbxYdvIpyRZy8doPyzRCu1t3RfxqmXQlPfx4yXXVSevEn5KJbymwy9aPAzfEs7ebwfq22VpottKbChXPTkKUONd'
    'vCK+/PDTzx++oleEHMrZux/uQIP8QTTsT+jp9hP5pfvkx8/kx5r++EB+YKDiT3epb1/kr5nYIOyu0SBDzt38HOtEeMAR6MpTW6aP'
    'rplhv9ArEHhxvFX2ZZ/6GYaRv0+Rh0rqhxRXKuEv8vCV+MUkToEesax7hAc+iW2RXFK4OQFtwRRQixT+CtPBOkO1J7ZRUyklftG+'
    'EisT/v2Ywp/E1pTcofgVS/nrb6s0k/l2j3/Z8C+X+Zb5NWQuj4DR8LA64iMdyCwOWYBqB3UFIYYIEEZrbX/tIgLUo+orNB0SkyIa'
    'KDA4nKonuAl9EXb+cgD2C1QIsyl9TXSd4Kg9dnSP/K9USgh845gUfmFmdNQ04/eamXhPPAwhUxZSZCiXVhD+GbiTY5iRprihSrIn'
    'Emuggl6oCsorNt4LAkUFEbhOgMkVIlCUDMmPTQOJ66LNML2m7lT5FH79N2KECb+v8TsaBV36mUD7h1Taxa2l+FUxYQrjcCFAy36k'
    '7WFyXIlMMfQOP+k4/wByS/BNvzE04hp6pxNc2AvQwWFA6HGzH28SgqT9NyLNuQx5IDlgoLFG/CVHgjX0CncBfK/h/xKLc/nli3yP'
    'kWoYkA9f4K8cPjLk8Rg+4ocwARM+yuTx+PXrlzTV2Fe6ZbnpDRlFRIw8efqaoG+KpJMNuFBQYqnE1MHeX8HOPRIHGQwktZxvhefP'
    'YZXnAN+O8VhrGobpjgGxlMMIz+m7u2g3tk7300gURtTPQ0cPss1vWBZwXhKuhOyXxo4g9+E+rJIKd1R/f7M6hwoYPaJJlpqi2sRE'
    'QM51htEYFA2js8tq5OYFpELLf7jeCkAtKnLqCnzqZeKFOwBhNGisaRVH6r5ZzWgIIDlgQDZqnClH45zfx/uHNJ4HUSlFklkz/YQL'
    'mmiQDkXjQpRDEpwiPERhiD4AIeoCSN4bqurnyKZHH7RWjUaVV6m/DIIBEt0lCr4EA+lB79V0hro2RdmoaxNWOlYd6nAZb1aQ6UEH'
    'YxjHE6jBmhOoKVF2LS8OZhqWHo44esuhH2JgSKao4baMZWUSu2VQ5+TaMLpK+CNd+WdE5wrx3eUsBnwIG/6FFGbZ4QZGxHS+X6HR'
    'apVzcc3CH4Ye+I/8N8J9ieQW9TuUn06gd7r9vcrJRzTtnejzKROWTsB7orZMJloAk3gTKdqCo8ajKMZauEdk4rzhsXdiN4LVgWG7'
    'SDS/0LUdAxjBAtoEUu5mIEnfL14u32teM5DSCa+AzJ84sly8DDZQXuQ0c0GG0XTFua7t7fHBz1CEhS9QjF3cZDRzNzDfgoj3xFtc'
    'DTDyahXYjgsMCPTMShme1+SZZdFiISE+48nWxV9Yni2zErGW/2VF/rv7FDoHhkGG4wB3NjXiGLAw5XQmJSqi7Xsxb4o4QJoGORLd'
    'j5KOh5g/uMCtPkRfaWAkGgtXM0ks3JRhKWrsVDtp1nq1KLoJSYfbVtI60T5EEjbG10u8gWHC35xSYAuVOxJbjPwu8QVVuqMxv/CF'
    'IqllkgGnDCNf5ViOnjHAr7xU5ipMeFZBfqBYUMbADHjYKY1P6ABGDA6IuOBFrlyBkc0xFZSP95cmoaubqtphrmQOkooh/4HyTA47'
    '4DBcuskW2RJbSXaTXXEcV750Uy2qJbV66SavipWVmugmqxZEXk12s1i6dFOsiCtJvO0moc0Lp0DikFdKQWWQOP5kEHiU5zk2GoOQ'
    'qP5kDKKRwjEII6qJtj1BCku62kYPobNtDo+vesC4fZoQbRE4fuQ8C32APhLKoWEan6nt2SWG2GRsPpRcVLJgQCLRjV1KDlHIO/hJ'
    'PuPhIBJlLz4jkLDtphB6QdfWv2foX79jeUmvE1tLLOK0cibaHkOGihsZBFSucxqaQziOFETNHKRbTeCBIDBTaQzblyFcMPCJBT3R'
    'P1H2URsPu3lPT4dioMHQ9k/i+lFDziXqN5aeNtU19dT6HBrmM6E4Jho9biSoRxG9rWKBCi0gkg2SnFU36fYWVv+ioVc8AWenpAhD'
    'XyqM8kedGIBmjsnzAyg96Ll7PCh0eX8i70+xVXP9vnEqcotLSCQoP4/pIzsSlEt+RzakpIWQzsUB52GTuQam7q2Nfw1lOcRLnHpz'
    'RVYrYNUONl2h/l7RpoR7K0hp62I56iB4zSQEq3PCFxfjJjTtKrFzyhDj50csmro1BpImp57++/931mAFhNElRS/1hYRUuSemB9fS'
    '0b80egSSAxz4NSL0pOtBtIbTJFCjmDsS/ZCIdxG928jiP+GXE/1yIl9O5Aux5l7cTNXzo58exhrbRU0l28/DL4jph1/Yr/dEHZEu'
    'H1jygQs/yJcPHPlQIB8SI0u+kn+iLtzTdxJRGPCnn7nafybmnif1/F/bvIsb0E3j1OjVpYFG9Ao9ym769+ULbQ0UAF8N1HQMkkqm'
    '9X39ejF9eIEE/cLpxK6hzZpy8bjHV11nMrSDBAEiy/IRpPkUskWP6K8C9VM/NFk0zYvSEjqk7SP1AQERebAOIsbk94nT633IP1YR'
    '2AvPnv+MBoE0uZ3GVVfAPZSkRxphNKhLQUNX9DQsnoK9qP94G0BYYWwYjMxXLDkS9TlVrIRnoZI7d3Ezsxg8A1Ep/EAK1qDbkCM2'
    'Lq/SCSLOkPZerIPEumihoQfagZFKiakvOrMZNWZH1YUdDjC0ZUfaEtkjyKnmNBSSheyU9dzWaxA3QFozqQJehKZ8Ujn5GRkVQ3rZ'
    'aMkYCeEw+TcGM9+KjTeIGVCQuHIcDxGvHqJ6IF6nYB0wbC4ICKJjgcT8FV79mvrv/wcNM0uthGlPW5sY3mcX+l4RgZLgB9aBxMcN'
    '1wH8vHKWQ6YaM5pQEMTsBddzbKSJODwmyoSu8xY5pBb60K7NNCn9xxsmiiIl/KBjaOYixyStQ1F42jRlexLyO7pBS6QHtuBHrIgw'
    'wDTlgBKyPsrriciJE1GHqWgBi/cxCwAi5iBhIcGjEq+kr1ezgiKfxu7VtZ2a0MijY7+imRp/pCuQ6O5hXHUSQNR1ia3tslKJpSB2'
    'xyYQwEM9nijJHlWFI89w3ItFZSsMRmqmyAlhvFMi8t2OlS/ibaAhEwOij97eR6oEVnO5V4SG0qTeM7lUKwyu7gYmRhDeaKSqN1dM'
    'RQYSMiLR7gQx6iqp9K946Mz89QHrCVsW99jI3JNjaa4W2hzHiYuoMOgqwUrhBVlA/ug6SYDhKnBJGmKMCJ/R/IyV/Cr6v+K8bEJw'
    'RmvDalDveQDlVF9B2aTlqCOp1AcXw13BOOHWNeqCKfRoJedTk57syQVCbQj3KWJWBBWPrhZkD/RLgo/g2nlPVov+pyQJEuo2jrEA'
    '/3b9SqKvpK9JzxrjRMp+K+3fK5usXCjJuJQtXb2i5B33l4TExqDbafs+Fbnckt2tHVnuuEEU7g6QCGwvtfrjtDsZk0ARt2KbVGeH'
    '1dlhX6L3ZvjepO/RkSUJNBOj9vPV66jDFzZBg7t6t767v3P6/ssXUTPorVbpGwaIuI92m+xnoI3zK2HYD5DrihKwtZnQBnr14fvw'
    'S+Hr15utMYm6aHxhcngc8CP9w+QK5LmAjyXyWMLHCnmsoNcgsNKP8O/XTNRPuuPy+71AfnrTDz5Crwl+yzI09As5Z4Xmvyh2tiej'
    'Y/vnOPr0bbyQIcJWz/9KQ9SSJiW39zZ0+5C5J0st8lK7AQMcPR9dYK6wQDShaNCLxS0igAKbuRLj4byTFhACvZTwRr2xIjvbZZcv'
    'HgqHEJmFRPZTQnVgiStPItWJpDrRVJurVEktC2CVg1Tt0KQVevDQ9/Dw2U04m+gvcC96pZdH7zq6nARCryJdtKkbDwwlyHO8iI/i'
    'NtOSLOC4nhre2PFwFWyIHuzMXY0pPZZVIxF3km22r9vMo/S+0Ryvvic3Vr+/FAojQVgEPRbgx7Z6HD+fjLJDR5ktXo2tT8Y2LJxF'
    '92ekGhiwBFwKYTTCekJcxEGagRkgBPYjhm3B3XagydAIDMIrgYgj8UVvVySnCfDOyoPleirdfgVJeE6OfYw2oc6f6HrAqYwWhid/'
    'ilbM8OK5EHJe/BAChnQ9IX3DADzRqd442iDKuFwm9RiKc7rfT6RmZJ+PxG4MAEJLv6qsVWDwmhF5+BPRFucODbexUQJgqaIT2U9t'
    'L+SgGcGT9NIBMQxiZZlqdCqAjBi5a46ODuHRIXnS8JLEjZ+qDnFHyckBPEBEG3ofRuNWE3sGWA5BGFrUGffiMEn2SGKsRYBAYv8F'
    'IXHoTCn6WI0H0BOYnhqeZQ+3JFJE3hOgBF0PcJMmPIhDJFxKJlG40uLV/Khkx+DSlSRWvrDb4RVzTYo8ny4vsm0ehhElZhFTuSNh'
    'jW7ek8CqiCbIntQ7GWkI1t/NGm8e0Ipx5z8sKzbADBP7jjYV23h09T7Ur9C0/d07PBOSRMcrIr9weIXOsoCkMNF7Vp/Q7na1I4E8'
    '9WNsxQmZeOy6AyiAhvjD1iCTwXqRV2A10a8s+UUDQOKbUxjnKOk1hoAoHMVfaEcJfKGHL95iEF8iGXDQouQYizpOfgVNQo/eyPAX'
    'k1B4b0hoWxcRuxICjwkqXL4w+zSIOlIuxnGlp35yseg1letDjGg/IFwRzReoaJEXx+jF7YHGRHLmNjnzNTzc+LaW+HAjfkqebyS/'
    'E+gKXe2vs/oUhPlEC/TpjPliWBPNFEQo71IsFpNNhbWdHlKXBiS+4Ozs38/78XfzfozyhlMVHaklKzq8cy/1K2hZv17csKOINn7q'
    'V9AdIgtqxFYv7qv4K140PrlYJLFsYoMDE1ob0snl8wsQP6wgcnghe/tpQ9Rkhsm8g46YW3SU0IdvbBNJUU3bSKYDmplDH0S0z5DJ'
    'whfo3W5kSOjXX0JTBVA8NWFEyCS5Nq+L2mhk6K+Lg8y3q1G9Xo04gLgY/Ugj+bgPVxc8wPIiEU7gm5pckyQT3tQEHQpICun6CE/C'
    '6qBSAlSJpqNS0lRFagQoJI86EGj9DplHKpMatVClituedHtH2qpSfWtPOr2LVamw7iCZkrYguKRUpYQx8EppolfbuKqKfIecGXtI'
    'xWFHwztiorDcxOvuIQ65jQXTjaVLzji+959lvcT2IQGt/15/fJ4MRrQ1IOofiJvsfRhzmdwtQ8J749U0/CVvYJKLiMKdkMQuqX49'
    'QfQ7UvunK/IixhkyZsSWg1c2fAtD3eCY0OUbBsjG2yNQgJNDxtRkiSYE5SFh3QgDT0XGl98zsiSdmPC6zIvqRGV5FCHpn1ElE0Yk'
    'Cf2lEkYk+upiRMLjcUkt7f/n7t2W47iyLMF3fYWLpTaEE4EgAF5SGSAIo5hSpjopipVklToHiS54XAC4EDeGBwhEsWBWj/MwT2Nt'
    'M/M8Y9YP8zTfMJ+SXzJ7rb3Pzd0DoFRZPW2d3SUi3I+f+9lnX9f+fEE3Ns3XJsao2GzLR/HLRM1qkxIppKCLclY2KqNSvTEmSpVD'
    'bq5EOLk0UorQYlMOvbtDPZR1mMHvLDudVad3KHvQTl3fM5+5TCJq7U9VNba+/Lofm9sUGqdCrqkxEVvJLoLHnJ8RpHxFHY8uovrT'
    'TMrpQJU+nnFeavOD8RnjuqUD6n/STSBYh1eKXIQUB1fnF5a0RBr58Syo3q0VmuxkypfdFInJ9m8isNE5hbmJZOYqoeYi1J5aaIxT'
    'sHFpqHpMvG+8b1EdT0S3mwwAuDVWJ1U4d0AydH+h4sZ7zd13XPI2zet9hyYQ/V+sHuraNB9mTcWNU3twcRwgbU3LEXR9VHQcH+NL'
    'ammg8/ky+eV+fB3/2E/KfZ382j85Se0fyAtmHkqYNo5W+PlCXVekGaE2Op7+JpVkBMCqBxOCChGLwAnX0XUoN9ieUJn97wl9RiAW'
    'fvr34IjzVJLIbMqOjg71QST46ht4MaGfRrMUVTlQLcUzcUFD6N3Agy6XIvm9DKfaDqUebpxf2e/l0k4x23CuZvRycyphfbvKPEjK'
    'tP1cVB2ntor934F09UOxQOK0wfqtByx2T9swmlANZ9NQTDDX7lscCX+2ZAP0ej3/6jx6xesRqtXZSSMXABEtLivuQvdxunkMAqsE'
    'c6z0gekOWeKyqqNIRjdz4TBSutQnEznFSxdaZBCKDHyRvOG5z5m4jBTgbz0CVUKF2L2cbKvNDUb3FghNhAihavNt3tCqmC853KPm'
    'tITZNoguwUVmR2EO30ndjYglOMo679UdcZJRoJY7UuYemyVRrfUij7/6MWhzm1io28Q1xWGnOURmzQs+ufBPAhFbUDP6x5hXcmEX'
    'rfiRh9n+k5oIEFSjf1TV6P6T/KBNqUnkmxcZJZCaJpOr/CK7iAIdPuQR7qXiTYZuv4RFdVXJunSzb+zvv4edfXgdnBQ0Hiw1dnSG'
    'wTyxUzNWyDtXcoOpOHvZgp2JIj9rkZ+lyDe+yM91kzLusZfHJfxKTvT2kl8n6h3wzfHP9nykv04CVZRRhSE9zMLPkYpOiC2TZ0Na'
    '/gtXRH8OWMTTTJf7INrIlnvStvK4MiXCWwvy9HsZDK8xdzm4rcBsrbOE3SIFOop9PBq0P9q9N7uxX70qCJzGQFb0Zi92x2+8Xje/'
    'dvoGXLjr5tfhtbtz9Qy03LhzR0xbNVKRFp8ht7wXF1RWq3cnccTP2+Hw0jP6rH5En0X1UvK7llW8YRj5nJsUmRZu9vQ3xMALeb/e'
    'db93MkT9rPfqbWOkuChfLpfFmpDhnU9mmUe2Z/BUnX9yeD2puWM/v0stsG8HQhHYzr+ffTO/6Uhr3N78F9YJ+dt6r39s6x/sb9cN'
    'JP9Fe1XxW0y9JX+M4dkdJLQhOOoqZo2BeyMz2evd7GH39HrrPSHHryblYjGm7VUzeYLbQWCzNBpTYT+2QqMMEEjAerqc7ZqnwrDm'
    'qeBpj9t5q11V1Kz2HJxgcs12sw/G6e2MeCGiuhta+PD7Zk9rx++d0drdmGstsObuZ3OBtcP6LJSBc4B5HxL6oBPcCEULjm4fZDMs'
    'DqLK+PVqNz5n8ChauljS1V58Qld7fFXzMtnFxbLas4X9cdYiUCb0h5rzd//4e0sBBdErMHQdJ1q2ORo4LwOq6VU4UJcEhp6fQqg8'
    'xYuuszV06oIrdKambTXYu5j4Iffmt0QHhqVApPnZTP0oDRdvNfcWDvWqsJCEC6IRpd4SkauFSaN0P9U8VczeHPlk0LzhnFipRQhT'
    'QldNyHT2fd8YV8Z5QCQ0WNUQnu/YYSTrKhIcPTBFr502Ww0OlulB4We6MMAmbOwnnUif+VgXx5l21VhqZvyrMhS7oCpnS32bNbl2'
    'SJ48nryyhAWHbC+SysCNQAX7MNEkHdNcQbUTfOT+fzCL/BofBEcn3ka4FJc5OVmdRWlwk3uEc4vgYeNJTD6rccLHJ3HMu2yTlzrK'
    'S5R145Y/A5951PBy7vLDb5IPMc/us9mmzxSYhR8dZY8BrhP1ZZcZm9Cho8Tb7wPuqI1m4x1UykCvvTzFdiE90o7eU+GspcK9ruJy'
    '7XkMBXWABBns7Yb4mK2tKLe7O02r+RVCtxzkPDI5y2myNX4FvQD9MiOnzDhnG0ElnpEXQOT819709Vhkcfd0zwwOb9VcG3tkdVbl'
    'gnZZxBj9MY+UbBO6GtnlScyOGakLkT/h3UVCDBUWa9tRjkEbosXYLBjSAFS0q6B2EqE5IHuaTVjl73KBGDYQbhK8yDtNM2DTQqpN'
    'VCsFb/Nxyezfen5lXu0Teh040duM1sCIEoJ6Ob4GoL8/fhyzSAh/1ADZecPgiEmK5BmonxIBx+8Y+XtZE16XancqebaXapEqTYDF'
    'Erg2U6MjlNYdfqQuCUx/Zz//eCxT+zB7TKaXdalrgiuzTsooSxuJSc67/5CLH0xFx/ylFhVrydtUsFUiawrNnuu+b82/QLnt8Bm2'
    'ouXr2Fzv9mfWu1Or96TNjKZ3XxHZzYqskgsXN/VsXEMaCscA22t1JZu2fttlneuL0u0571KpOSsgWl5YUujSrmfk1VqAURw5SJ9q'
    '4pNE++bUoyIcNfScgEhfWFqniQLZoEWvIQidCluXL38885a/MXXUzQ28HKPMq2Pop7Eralw7QjmVcedf8H52f28fIhK3iWvAlxGt'
    'fGW0Mtr5KuBL00Yv7Qd3Pj6Putun+Tly2bFNat7Mr/TMccb4Q09Mj1GSnQaN5lQEKv1CSODTSIKIfXbsmbXu1cS8o/KY/L7SWGGd'
    'b9wCJPp5+MAcGtJPXHl363QTtDfZ5spyvFLX/3LhWIlX9NqX/a7v/cD31PlPXriS/tWuq1sxXxdhZ/18xUhBii9kH/1GNH5TM6o6'
    'Hf9iTn/hIBzhNN43L/duAx1r2An225NBRUx6+rnz+jnt8cukRX3SbLNlbTDtpz989ekVlQsALuBf69vsFf7c8w/3+BB/7ftn+/7Z'
    'Y/8MpDjGcIIV1GNXaA5gDVajcVSO1iluX1mLHTwCUu/68MFXn3CjP+7to3b8ud97cvvgNOs369HUyRvqAVtSr2Er5kixQ/6g3IW/'
    'JZzy7PT5AqrI0eEDmR+SdIyQNPs2e22P7r49/Ad3Xx6bq9v+vOrSO+P2f3rAAHHM4/D2gc1L+muH4sDhgz3/ADOL8PvDB5TsHjx6'
    'Ea8i0zx90GkZlssh8tnfoErZhlLpcK1/r+XvpVu/vd4+422/vo36A9HllpVHOagRXKFy2xhJ9ACIVQVBr1itCsCoB9+p67Yd5XfC'
    'taErAXvGWpGXmuVao2kdQyWXJsz7JslZpDxyH+v9J/dr6XDUjFNVBbGXyo6iXfLVp5EfKEz98cQ7oa0x/5ip7ey3t8kyDIuFWwWR'
    '8IphuZLp7T3GrPkNjI7IpfV5zQ83tF1db2xYqpNzdGu7wFpzDiH+3HSUvjkabtJwrgcVEo1MvJXJ610PTilJde80Ks/R/o1VGsF0'
    'lYKKXpX5L5mXlYiBlVp8mlMTYO+ewKoA/+Jc6vnqk8jmt+rjcfhAOPdqvuzTw3O8dEemYSSxUBXwTQZEYddUIbzJZOQTxvid7uEh'
    '7K3yaCohzGcrpiorYzQpyyMhV7AikzeTPzBKSpNEEt3dZX6wzmqQFDr7DZKiV7G+yDRN0Alez5dMlTNfjspZsQKa/VV5qFDEEXAN'
    'ki9a2nAHdRMHcRBB4qrsZha97COeY9XJe3mucfDHLGbWZ58iJ150lwcDzyBu17OKQwqwKdpsNQxyOjywPP4ui0cwF60mdhTIW2u9'
    'I1mM5l1R/IMk7HxzFpkA2UAJLMmqEhU9s6JAuFDXUWi+PwnJ7iNxhpypdV+TaSx3+0374jLYF5c0JSz3+tmuy0dMoIpI44nf3awB'
    'dsFKfNqOBEaTmCXAidAtA38ZRUagnpFO1g5VxQGIHKiSsiCsc9eYPgjPDxCRr+c7RlWKscxRR8i1SkFgTGjLmBVQHBVhA+DnNp85'
    'JV1DxOAlcmhFAo6FoQcYjMD7HnrFGP95kiPZY5eENDsuRBe4zu97Q58VPb9r7RsL3GXONuJA4/ftv3z1ySrCn+iFMmXmasApQarZ'
    'k7rQQxIRXqNKNPTVJwN32d52FelUVsKDVxF+XGtk52H2zCI7tTgJdKUJ0s7kEIHgdoizsp0CodBp7xFQiR5x3/G6mi92ODJ85aet'
    'Dh+in+X5raPK+B/XnY1jWxWT3wd4GlRW4qZwO+4fZrIRDx8gQd07uYPHP87+oZLLQ7keILl4tgdQLo7v0U6+kKsVA719/ihtyHUl'
    'kcpOr5aTzt/pDOusEzgsCzpQOGBWphFmpEm6d12emdTIT5eKTcQukKXIT6KN6owSXILeKCEzsjFeqxv72Xx4Vb0vFMzbo8uGpKju'
    'fR4XiFFmWooa73Yh55xnXaMe5Ft2QedEFrPju3GUbT0/jzimva8fvFAIdHj8eu194l816xpoZRI+B/MBE5Ro+mtoqR3R6kZp6J55'
    'uHvkMoAusp/tuySvn1Sx1w/Z4M7NxSKHtp9a/n52CiSPHQwG2wdvIabc0kU5GdijczeWNK9wCAXkbhFGQ1ff/Bjw4DWQawMFhDJJ'
    'iSleBv7CcbWWbta5xNF4Au0teHEmx4Bex8vUins1m7lsGkDLGmksqCZZ/4m8CBeOUaFuOcf0M0QT46GGAWk+i75rHm36NT+P+rlC'
    'MMm1fArFyFaUvDQPiFDYRDLiq1IhGKPtWUtnKj9f00bTkuE0sFV8EFJSIE4MkzoZj1wk0dIB9imCirlHKWawYmiVZ2djMgCaUzp4'
    'ICJljod0cjdhafk+QrYaVVdzKdX5TNgmeGWpfkOhtB68Yk5GERzIchLtC1zaS4c9hPBz7SESfCKRS4QOzdrVutSSA2/STGsPJsiy'
    'Utf8mpAxCaEAmqUnvkH1orJM4Ee91fz1/Hq8fFVUxpsZbK2UwsrxD+E8Q9ekuvDDXVJvX77+9v37b4+TdNnhEwfU+R9cQXtwkp4l'
    'bpOSWnLdQNE+uWPg07HmDgjbRXOS6zWvNQmvF7+m8tK99N4YE3dQE85E47jVSjiY32jmBE1ZMIudl1IImdS7OzKtEaCacC4XiqZz'
    'e5CgTLtIR+9LtChGafKm3W4waqtzfqHuHN1sYMgACivjnNeYjdYcAqKCO6Egwa5zrv7DTQ2t2dCF+17RBS5aGlJPg6jgTiioDaU6'
    '9YnL6qbx83Y+z+fAD6AjNmP1nL/1VuXciEMCpDjeDxFwQeutDan8l8aEfmT4vAVDosWuV+ibvd35Fqlh2/WrKleW6QfYoaYh/MKu'
    'ypGRlOhDHPMpaU2JKAFVtFPdb1F9qyhPX97LTukHAAt+DBZA8uIHY1lXZFuWM/XwgzLfVLFGDdVRIBAXNYQfn8QxcPOVpoPt8Kp0'
    'QNFypdSiepKIaPx4NeeDOCh6A+cZQEUayv1dGg87l0Tg1PQwOwH1iIDYl7proEHdfRKbw6zDKxPEeMg+2CH7wEMGv6bbmFV2WU92'
    'W4KnmeKLBm56lpC2ELUQ12scobsI2Q+fZ86H6nGtiBO6pIjzqnqca/suljeYyTiRSmQ8prxILmpdGcqnRhCA+zrvghd/mD02gHmS'
    'o8/56kluX+gkPMye7cZB8Csirz7NU9sIbDR+tZlINKy8xhfbvlimsNH2pSylhnnHWC86TnpZ4uPUHKnRwokZ8ef5oPLb9nMvQ48x'
    'rafhfB5ShwXHlG7T56TmL9m4T9RXonaPhDuz4JUyaGfkvbOJXB2WbG9Oi5JLtlcwft79GiTyp/NbCQ4Xb5iG8U0HYagJKkUrP60B'
    'K/KYqiFy4cJP3W52qzsM4XYayG4rFh09uubBhmJTXawsqryi1XwZmxQJj6mB5IFDtuTu+DsZLNIcBg6FGXMCv2FPU7blJP58QsAr'
    '0+scZRBO7Rc4SFauT/EnHr3n9CRCV8nYQs+OIPaAq6K8hPwchJ/0Vu+0CWBYo/tlsEFrmWhbSW/yIG7VRKynImIdpAJZJGiFPfL5'
    'm0LEDyEk+72nQZDS0Dr4RJoLVdhzNUEKJakXUEEqOFD1TRQI7D4WqRwFhyosBGSD2zuGDiHsjj37zO1ZacHlD0GQQX3bPoN1UweF'
    'PvgmQWzcdxM/VEwHdsRtkoomOLhRKcpwPCqZ50IIzIK/OR4v76Xk7C3jGZygagQtz+85mm3DfOtPphsiOejbuiqidYToBSbB3dYW'
    'Z+cZn8phOuveIQtkWXYgXmqCcM8Ekf0xT2185BLvmD9ZON9fdnRz8MG3o3Llt0cj2QEVh4RLhVlz76m7sVry2jTT2kREwngBnwbC'
    'etPN9n6DmVslaUiSNGV3Z4LI87ShNOvH6poZU83nuploYzv7WpH2jDVL+bKJ6i7g3js1T2yy2Gs+UNfrRy4VUxapHo4nplZXNCWH'
    'eNTCJqkARBXdedZyojdYXr76hO1zlG2lpMny3714DjesjJo7qO2otYPKLhjh5IcI7HJQ8OsC2rybYAUS6cOECTUCOWPm+97gPLGv'
    'tpMYkntQFjntwxYr3MavAHe619unCtMj5rj8KNgKnZVzWD99zmxR7PS0FwYJsHt8gvXtlAqFjCGg9A5OO9SoKt88ENlEhlrMVjtw'
    'IkUrMs9w2C0mD5jZZOesmJYTVsw9bU+RhYq6z8o9ubaplHMQZgtjf/HVp3E1lM16+/wRuvDiNGC+I29IRGBv1XEzPqm45+44qK37'
    'rU5+MX5KwLuUf82qAaLqybxuQjyeNcK1FDVAVaHwi8TPQn+miZOcFsX9WXXu0cW2w8DeENk8glLV0zbrRTCqGkQDjiJAcBsVIEY7'
    '02PqpmPWDafHrK6JpRxuu3NN7KlevYx7ByNrWT/ddwehKo1oP1B7PO4ESngE6+4Mc8eT+2WMq2dK0GbtgJhVk4lWet6Tf45qSMH7'
    'qmfNXYPvewBYJgTzk6dps77+9z3iSNeq3es9c5XIIyYrTSsjd4Y5skobGLuWe8q3sxUZlbdapso1FmZCc6KyZbzsxz14nMcN69YH'
    'uvV7Ji1RIxIzk/tR4m3MSS5vmgC98XsO5SUNX4oXSSjRinRZhrYsqIzKG9DODmXGyBL8IOyRWUhmVASNgpVkRoXNaO1pq21o/F7r'
    '7wv77SjGWUJcqzbniVv5D/t5G2hkH/adQPBdNzxBHCWkX7qREH/phu/i8ubf0JvEUqKG/EO194pYXI2JEJSmrj74gp/QwhNfgWqd'
    'UtsAIHqqCq4MozE69dl2l9rl+LW/HCO7oL+Joq0VehPP6U72LEyp/ohnFEwGE67ZwI8AzwaY3PpU31WwdgUvbzRarOM+UxCjjU4v'
    'vHMbq7T/oMVP7Fn2JJgJNcM6eyOTcd6Sae5TQIujXt3W0wGP0vt64pAayJwSDQH0fkjUX+NJU1fX6FAy6aGRjkNHPEgiBudZ316B'
    'gCcJGkHP9yIlils5O+OdPfj/7bp8yYjNlQq6ybZ4KjwTLmL3ydMuMo7e8YFsozzWryiBjDK1ts1fvWPSp8eWDwC5pAwnRZ6ehpa4'
    'nsTxF7HOmmypJwzPz1EkzrnEvKnFO75jS7tkS3fLbuPh9PzP9Uk9fT4UcveWwcpyPPHDHdGY3Sw95SlrVKesk53S0Z1nshefP3LV'
    'J6zf6fNyiuwoF8vxmdGEqczwEmzlr2oPrezAVerwAa3Q0TjyB0BGrsbCNr2sFjKiPxWrcn744OaHcvRn+b+MKbvCuYmj5Ria6qZv'
    'BQohuyIRNwxfXp5GMoMrI1zSt8XwotOZOP72U2P6A787i/hdaBVLq/ffic097zUZXT4l+T+PsnDbdyqx6GNHdf2tIne+Z4sngS22'
    'Kc1j5qyeHNObByH6MslspGwexrtaU2FGolnEhuIdKJPVH6XHW1rGH5IpoV/nGvJnhkTFTqNlE23T1V2unSgXkZlrvQBegwSVeixR'
    'aA9OgI5RPtYnJ0zG8vWzr8e/fbZFSd+XRfoed+2BzujjgCka3Z9fffL1n+pdKs1g2jHd+irfKFSeNqXHod9pfnMX53/mHLuEkvGp'
    'Ywv1c4eCERMUfRc5ySa8hgw+iJCJ0Bl4D5ZRzljugFRkVMoRDszwhukw0TdruTGkf7ezs7pHSjTpYS5nwR0Lv4Saisx+9vUPCmv+'
    '3EB+PA07AQM9dCPdjtOVsSNRwtt6KsV2Rl8vtJiO1S+Tq3VK+PiPB59oXiJUUd3sOY6ZG8kvCh9fgY7f7AeeOi6x70vc5eSNeYd0'
    'g2BEuZufq7cKZKiN7r81qg6/0ALYe2p0rLM8nQfbTx+4SFpCxIjgUmTVFFbBB3/9n//XBy63l/ecni/GDgCml30DKNHV/PzccULm'
    '1wQapkMGbuUTwtMcZuswlYFXqy+Eagxk4baxZzrV1QCWF3W/ie8gqRMS4R61JNTse33Yb5rLZQy5djViytsJSEw5BjR3J+dtgHtx'
    'by8mGIOYWOzvK5XY29vkz99KC/Zr6qL45A9uQuP/Lkd8b792uH/Tcrj1aHO2Ww5upPhpyiNNoSlv4Q1+6TKtSmHSX7yybW3bUnrG'
    'x2m8wyBItAPz+tvbjVWC1DPcF3XRe9ZYpIgScK88ARU3GjAINGCA82Dv9v27uxrb33zG41m/QwikcDkelUQMiKUfKizhRwRn88F8'
    'tZpPdybjs1Xeh/3hXFmBcqWe742sBcJrDul+YCjMs8hzoU0sunDkQISFC0cIIAzuZI83HlUaBBEqsHEb0IXioijDRvgd+t7oM56Y'
    'H8d46jZHuobJTrkIO+XiM3dKu8jatluuKicE/F3JMRr/f5GI5hc12Ryn01EXntRfIjj3nmwMUtkYQtS6wS6K6s18Bf/UvCZLm7TM'
    'BJDlEKYe4z51ay01XJrarL5adW1ppEoEX4+rrGOfFItFN+wwWTpeOEx5ke6qWXrJyN6afe7eYoufTV5+RAf4SfvmCXfFDIv4tWfL'
    'eE3sRqv4LFrF3+od8fjfToKOd5DxYA/JEtS4AGWgsy7EfAqpk6dNM69SMyaFWTZK7xULr5onuSdXofjdvXt6B2cSbAZR9xPbQaIe'
    'CG8i3JUOfcGht8Qfch3hH7mN+OvUOw2bUYB1IZonQiBfLCbrfyzH1504aoXmP+qA4Y/Q+erTRymhkYP8a32bZ9WwmPhXl+brzcga'
    'BJS8XK2W5eBKPlZdsohq0y1Nh/lVZ+vv1K1mvZXfXVZqXMyrEj2FmWS+7KT5vZZj+J5Y17XtcibH6g/vf3hNTH2E6MDgzqqiseJn'
    'tZ4N38/nk0GxDA94pN8WMxeHwzgD9Bjr98N4diVdVg4xZ/nX9lhLr5ZrWITnMjXvpLdCADC+71fjaefd+x//9G03+4/vfnzTq5g8'
    'uDxbw9kmN+34kCltPxmIonw9/qlYzsgSZtFPQl8A1mc1L6pVZ0tGgNg+Evqr1bwqPo49vQGyvBD+v/7rf8lAad/hnZSDzEtwiOJs'
    'vEWMtlvsiUcPsx3/P2GD0eg6fvTwUZS1az6dlquO2gxmZXXxclZOZRLgDTR/Bz2hmtTbx8sL2hcMSe6f7uZRBdVFebbqMBeqPTJv'
    'cERy/a5crtadPMndCsdFmajOz9V81uwZjApvFdFfCTfMM85cqT7RAOjF38QoFk5Qu88M71qp9b3mfP2lulrnym4Q8VZqRwQyAtKS'
    '3rodm/QbQ+ZUVuOxEAT83LKWvqxPkwu1iWblrpl2UxIty3zRyevzZu2zxVBvvcXPWlvXYtQ932JtjxkzhkttWajffbrdeJ0+uLga'
    'PFCUxcr76pufed8cxkNybKZyCsmxXV4rDwiKYK1ZQHDGN1sVGmKK20e0Y/n8t2AK11QzQWsE7IhuNu6d9zQ78dWAmFSL+XhqTnAI'
    'xq2QmAzZTX2GUSYjxrbCJeQDVTbGzRlcNfBBTTD1aY8jb/vU0T4rzuA3Rp+SQrVS5sNvoi3+PjPnGcM5nRMuWT8UafhKls0lCAby'
    'F1RiaJKozDHCgGu5GsvBkOthso6iIhEEQAVYhxCj4xtacOK7pSrpishggPGICKPOk+8SE3TpfPfsW8pKbQmw4ZlTKBivVHmM/0Qi'
    'cZz83bnVdzr84Mi7z5eyajfwQJTHwbkN3rPbUOy2+NkzEvb3SKbKBdmqQthSuiIVfYoxyK7uUUUM0n2iuGC6NC5V64HuQNRaxeCz'
    'yHyiJFuDMdyCy7Y25FE+jg5FtBz25DvgBErF349CWsXS+fBGWlQad9zKaPk4yOqyPczzU9IM1i/fhD83jIIcyu3t9kiGejAjgvkQ'
    'HxB19JzQsIig1Yhg1Sy3dS7u2rl2zWzq/oNseGCWeytw61x5LptFdHjkwrgX/jS2BVFC5BfVbweNejGgOXeqmktkTIzeAGx1yzMg'
    'XmjVCw2sUMf8NPQWri0j8/QUE2Fh3MlSqpOn07FyQ/GXUsxbQT0GHzRC7QsLfT7TREUO6dvOlg9I1giSWTBzMCyPXwVD7kx9XFIs'
    'yE1+I3GmmFnq4txIKZw917wwsKjuulSNtbRQLs2wloX19fHXvihVcbcOFv87wqLqRcJICE1mBJo8vCgnI4IA96MELYstvZccKrOx'
    'YMDcxrgKg9Uyd/KF4uWv64kB6df9RhjURcuEWyYMCHrc+YtenXR+WZ9ubtacctBlyJ7FfCuXDrW3K7vcYfuG3G2an2WHH7z9Xq2J'
    '1WKpICP21PPHdqct8qYX0BvpZhLa3cz8sjAvIOnJwpTHN2DNaq2pmtucdG/Mk1qzvFiJWkjhIkVVjnfTIvJyqlZjhv4i9W0EsiRP'
    'ngo/qLEXwFeCDPY01+LautxvO6P62VvuMgbCzQgSOuw/hml4F//5Wv7z5De7MAsd7/1GfiTvTvKNwSLo4U5LnIh5Wo9JENm3ugp5'
    'BOcXFHiYhdXEkL5oyV03KoDApFNfd8CPffpt4kdF+gqUUsOfFwEa9+muD0ZBEz5ZSpFrRMrXVv7CBamkRZGRxxV9mjaHo7CgNWHp'
    'w11YsbqXLWjA8K+0ojQ2o4XE5ZvGTRA22XnGYxyFoK5eryfPccrGDBqcnf+uPDuDu90YYPd9v0F9kiWbaowpON9SspDpH0BU3xvv'
    '/JbBIvSi8DEin5hyncFuNX0U40AaISBfpNl3dLb2sd8MuXI7e7KL+PRAUWx8t8ltgNCrV6B8ytcVq+BY9em2mfphYTeLhgF5SwsG'
    'NBrL7h5n0dODe0R3uY/VljsaGehiHXHkaobflVpnIwQAxLKAI/1+tL3dhSqB6YBACQKlZT9ZcC5b4dh5XGKU0On3Ga6OqZtXDvBT'
    '/gKxIlmTn6VDjOkrq6/HPuGEsQkWLqifHEGfBX7En4ayz12EKSXzoaJkOYrYWPyIlkSmI1mRkDj2s/iFaJoai5u3woNAv/C+RDLm'
    'T5Ec6552wkKdE0Wvnji4yqoJsuoNJ/PhJeMNVfbw+JUa24LOdzj7qrdJR/xOmA1AiSUSBbfc8GrZ0QvMT4xR4QrLUUGs6Ms//ja6'
    'DXKWFwX7Lk5VY5+zVYkUxMKWY+NdM32wDHeHj0tF1ozCJxXuRvW7Qo4D299LxvCDtNb5VasFKXIwmN8glURjg0exr2Q5I58q6ENl'
    'e5ligpRqSv/7nhY9OpI/yZltKy7qZ5yHECMrBOWZEpRI8xEdEL3CZApH8jGKbPnz4hl1OxXNvf9rdmHrLuJig6HbOZvMC+odVCXQ'
    'jwJHhUkLm0F1B1hrFLaU2+XKIL2AXrq4WqUIRrK638FA+4tPo6Vc9H4r3v1kpRrKPhNJa8vj6WK11jylUVyvgU5WQ2l/VhO5NN95'
    '9VFEngkAPH6CftqSnqtqF3ywanI17Xko+wfq6OPC61DYCUpMXj2sxRRpnl755zluHE1y4G7cglh/BfD9UGIbIJa5VqMpHPVaZ2cU'
    'dH3JLtxGwUPvVCVUONQ1GojLhnLHYxE4Z8Y5snTChKHKKmCvlSt76xVFvc03yWceEB3imn9sOg3Yj62nwfBIzWGjcSruIJLL8VSk'
    'jHfmoZCIlXr1BrnSaT+/dCg+CUSQjZqmx2MrGmVLmBz1MIe5KaJP38OQRcuipm7lDj4+/uqTzuebYopQOsZ65rcnJ26h1N4lm/dB'
    'oySDRfPbBw5oXeslHOvVbDKuKp5BHS+Dpk69U7gdLMdstIyjofoNtMTUnYkwUSleXqz1VaWvP7xVHn2okDQk9BUDFR3pNeaKQQAB'
    '5FRV+S89VNlsPAau+wpERy/GaENvuBvODe5JrrN345V3FalI12tCSkkBFl/k8RT5DV3PY4CdNjmJYoXhSVHWgoWphJEqCdTmoCPg'
    'rBOeYe2ba2IN6v52F3Sil4jJe7zX5VJQFmt4h/akucvjDdLYGbHKp7Enajsi5jrq1Nwvv8iMUZ1fRKEkw6YmrUqaj5Q1lVNNKWb3'
    'WA8DlZD9CGxszDht+9C1taSOask6gAta1/lIha9Mq+ixmKGsqqstS3L9w/FiFekqE0Vl1yAZIn2l9aWKVV7WH+0NV07h/JJpqusl'
    'U3Vfu0rYV33phxptFxgWi1XnbPZZl/Odi5ydYWkP7t+iy7HuZ6XWjHiJedeZgzLs0uj6pmNFwN9ViqLLY2zyVEDfs7p4F+mBmvVw'
    'qXhA0mASkVmKLCK0gyFTClNp15xD3L5aQLFMALqKsf5s2rGVQXDRPqCvDovkpe0Mq49wd35naiJstWR0+KpmzsE0mlZMdy4s5A5d'
    'yJlDHLzxl51W84n5VnGrOAtWnmw5FdJWqZAWDQWpYc0aEOHXUHj0YiNLVoDRohICsqFqIi1RDGVE1TfWaS/ndUQXZVn5vEfvztHN'
    'gf6irX+0PjCb7KMMe0rkI7nqVv14WbdqR576ZZcZ3Weuu1rFSUh8Xsuzgsie+tUXdMCW28aZzM6KIRWUXrtZriJwpjin+QWwMdFg'
    'AnyepFNh5nUa2Fxv6STFS7uEvQwCIYRBvlgjz56OQRoczVNmrgI1H9tsxDlNVjx40R2AB82bUj8MHgHh9HovdPC1Njpw9x0igWrm'
    'lxnGz47j5H9Xgil+tVpOtnelop0zubjHjOxejj9cCV/pCOtU6jGjnYqT5tFACxE3VNYRscMM7tATM+wdVCkaoXV9ITcYJAyXScXR'
    'kgRQtB6e6XX0d8KDWjpoYadijLWW0CDweUVJdDSsWpEB3WHi6MsBD3XsRatrrQA8dupV9L9GGFHvi0Z4WbApmHabVoUo6CwPsFHH'
    'mu1vZjidcRIUR6/UfuRvGBvMUXYMNayzdpVx5Ouc6Q71uwCh27V024iThdT7mIaGva93oy/VYdR/jNk8dsilHbYV0SWvQ5TawzuH'
    'Q1OJlEC/JagDtV5V6CusvPRRb8O+/9NllS8mZ3RkpRnIkWJb7JEtREjqMdXjhlU7A2vLLy1vqII9hSzHjSwc511k//amhVi/O801'
    'NMbpgZtqXVfCx85Y5ZazdGPt8bfXjZrjtmHk2X9i8/K+JheGe+kCSE886er6GIipQvBrkBDPq1yeQvNIc0ypJdNFGIrEiNNByokU'
    'MM5bvfFO13FFQPLL6nPX/HzhTBpaxUmIjy5q5hqnaqbhxNVUqU8Ktq00HVE9ReKz8+0Vd1eLuqHh0qfkTFXjiwIHZj+yMTxMuq8N'
    'KihDgcg8fECjkjfSXIbxxOaEAIjG3AnnC26JbUulcG6/YFfRbWOPHmWd/Vjx73X1aLkbFPIwOQSwCVjCgIrbYlSYCsmHzUxfNwwL'
    'U1+HXK3GfYZnBeP7pOXg2Gc6jO/CRd1tpp9Ormnux8bV7PDllY/i3awsXAnvwHKZd7WhoHUNfglytqcAmdp7svv//j+0VYYT/t3L'
    'N4ntTcoosetm795/+zZ6561Jpm9azq9HBrt3rtB754P0EBeGmmdm24KH+HzQu3bW2P3UcFsY+N3alb/Q8hfeevt1aB9T8Jb5IAPe'
    'QZxAtp6fvduWLnWl2UCJv7Uv/wImxuc19QgxYAD29nMvHjaSnKrYJD35QIjW83QaPvQi63Wgk18nY//Qi8zWIb0kBxwEm2JGzpbZ'
    'gTYQHRKRSNwItCRJgvnlZVX3+4qViZbcOlDmO4/lk6dGYzyLV2p2KMT9gxXA1DuEVBei852igmbqccQjcKZpUUCp9GDAA1oE9o/A'
    'H4MUU06VUs9nY8Mp9Xylnh1tWnjLyjUzGFcu18+cADtI0W5Z+sz2TO7543g2WcteGuDX46dyUApIR4CvjphsoioK96pAs2elIfTE'
    '+XpkTqooiXLYa8xkT1Wp/vmcCX34d4z4N3VW6ig+Uvr5Mcp8uim7p19Tl/i3FsQYiDDyfcaEWJsB2S6FW5lWlvvWJWRL7MIY5TQ+'
    'bgn91iRC3EDYH7JVZYNMo8NDvW9Cc10ZalETcuve0BAaOkK9S+7yBkylq6HHzz3Bgh4aRKqD2euGgbOcApYUqw6aPRc2YgraDZIX'
    'mkGl5J8P3AKwfBqBp72RotPELQ0OBUJbE1C/zO2R2mT1er3LKnhv2Nz5y1LPOzmdvd7efjN++aoiO93oQze7LmarOKmn9KgbWsd3'
    'wuxe1sOcHz+V/2AqUlh3ZwgO5V8Q4aTDVnbYDd7ItQr9HiIO8ToIq8af4UJTlqSLE47krmBHr4GbDI7V/JgrVZYzqZalvBw5bEJv'
    'RkGVea8OGVJprxkncFkP0jZ5iOmzuNu46ts23IcZ9gtHSD5m816P1mtaZzVmdzEas1/KZjjlbqw4uoy9hEp6CcX5NOpAW5pJWaro'
    'keXt7Mm3k2KFRPX82G7XzpsOtRUegBy/zNOI+XWO9XK7DBmdLp1wFrlxfYLwIY3J9AFgGs1OXUvHphyxSkw5YvUwJbE7+S6+XFl8'
    'J1PT/epiPhlHHpq8CqKg7shFk3fGKmKGma0dOa1MCX9ajRenrh3g9NeujjxixRo7UYG1g46Et+EEl8zaWZyJN35mYLseoRbMnAaw'
    'A/3aMejXVzX1TMUrEHNaORHbWU2qFeLaDQVXjpgXuoObJR3rO5UmqpFhthwDh9h8fAw+ZnGiSaENzhkecvHVVssUEineFWmVXNRx'
    'AmBvegn9fSIbBdVrQYON010XY97neQBMdSIQB+HPWITB0DjebmTvMoPewPFuXCWFocj564HSy3iR3o8oEZ7cdbPv7Yervatywb4j'
    'qlHXsntv0IiqFHkeILY2+ELN7vKFSo3F4VsZ8bse7sFq5p7zQ/+ch1i2zrGiLp1wgju8yBWwCInskdcLOb6qGe/xtXshlW7rm6E/'
    'wg1+4p2IxhMFDJS2wHTxcB56QoRM0ivhiqAxh/8Qv8He8d/ENdOXE9baQn2Y5GwJw3gsW8yc4uUvVnMSsxVeLXTJ2kGmNJkhme6f'
    'Ndc6d7Y9Pp7LjtbZ+FJZDenjzyddz28TTRjcBaJH0Fs6z5JyUmaAwFD7RMhr1KFMEwKg09G32gn+tj44CWiA8r5qbTxXMtMhkaAp'
    'XeWVWbMhzsmdDeVJ362BeApxoOaXNb4nMEu6Nnbk8Wf0sU65P8r1SVdygm96tTk7ibsQExQWnpY+q00W7UC7m9gdu2ASrDHVdRjN'
    'e2HUQTsf8Vg9nBJ9tys//A31tmDmgoba+3zej6DZIYtH6XLNjfgMqotI6ggyhqPAoOVkjmPWZDe/X+LYo3sGxsbJr+AGKkxhixjy'
    'N2BVvcfjZ3X7NrncMXHzqQxlVQyQNnihl6fq1yEsIoh2OZdbkcO9Ytb5RGxTbT7sX8w3GMPMzZl0K0BRhelQljnCI5Q7IICgx664'
    'uMSPHz/tZvvPutne1wCrOsm9SLTaNNqRuwUswgxNr3JIC+wVHUKfaYwYGnbFD/wcAkecR4vxfBtmN15g9ekeL2xQuoP9IcNPd2X6'
    '63HTOfxk2vUbOxh6Dntq0xrl5Gaj57BuhVRaceACcyltCF0gAYn1p15PETSupm64JygMxpRKxXbTm5mNU+X+ZjzFXd36RPdJ+TFF'
    'D7qpihd8jLA+38/a32H4WJ0f1DskssJUIY7QORRMY/Eqz84LkAEImMg+O40Ydu/eJzfxZd9Y7L6XCKaJRDBqiASwKdyCpfBmmK7a'
    'mroZ3Py88Yy+vWaOgq5oUtzQ980sa9V88nH8o8Y72CiuZity1Y0JpoPJDXwId+llkoKh2MG68Vn/IBSgNC2tboftyMeN00hja2RD'
    '95N0v/XVR/hoeo3V9dyz9TSrEAJflZ2qesJyaMoL5dyTwLmQE6O6LjWnhhxIJ5kwEI8294aIwsthAGSZcyRFB7+v6TzYISfZwDnR'
    'MlsrerRMIJVkyqJ5UQENxb2t5k2lM7ZzoKCRE4jcRucM1zyjmDKFREL1HBRkACaoUN9ZwbhC2eVC+aBXHpe8r6htY5CCWRdgwj1w'
    'khSYMcpTV3AJNjmHptZUzabJleI0jHZkY5+KJFFiN7tamF8UpNi2lDPDuvpXmWkE79446eUg0/1344XebKjsxE1QYZkxcnjiCZw2'
    '8Pr7H75/n6rTd706HeDZNIukAToRn96N+fkYoNfYb7T5GrBCjTx/CT8/QBLEKubkB+v83iOjhLemNPBTZwrlPMb4fU2/R4/v+xr0'
    'fsa74TUFFCcVUCg4YCm8WtsrmL4oFdgpjHwwrpiF+Y7xRvptHzoUp3N8HdI5voZK/V/+BSmsSVpCCVyNuF8HayMxnegL9+pXz9u9'
    'VMeslT/AaO4VCbzCBrgAHXnRSHZISeao7Fx48uwU/oOn/uCQshB1irSnjFP6eAoCimFvppFqIRCLzyJN2pMOI42v59aEjiHn8lkT'
    'ds6hPWlq0UlUysorSArlh02Hj4RGvexPY1N2XIzxtbbkfYdAOEbwqvCKeaRDLmdR9jIsU9VlD4jIH7KYBELOAU7HSJgMElesvqj7'
    'VvX95c+B612v2TVdcIMw+XkvStDJRPCWkwrr1OW8/EgbFO/WxhmGDuJqwbx7hdqCh4PwaKCPSpQaFnKvz0bfI6zZrvbhIIQDOh8B'
    '024U4C53cQZYSEOhh8VxWZzkBn0q7yyI4o17c0f45mv1ltNyXbkd/E+KRPLoG300OG5pkUUSSQuL7qnV+awDStmJSOQ37lhKxeHw'
    '7sRU9GUo8tIXyfXgJwjTRUouikAuCn/4u9lykBYbhGIDXyzJV3O1SqMdX7PYG/nXrhF07TWriR/eOFaWSm6o9MxfWs5GjMhccjf9'
    'UQhVYuicMc1vfb7+GCbjj/F84SamHS0OGeGdFWUus9+oeTsbRXYb+W4Hjw9SOZlxh9K/zstutsOlfMj9DkPAElq05QBM5mhgxb7p'
    'ZptKJXlpxmcMi0SZRjTdskieDfhsoJ+jr7Id7O6Q8gf66Bv/aBAdDncmgdKPFsly87qXNl5gHxxlLzWkyFdAzLAkTLmlFuy8Zq+3'
    'm72Wwhbw6G6EV2A2Q9yKeWmKNLyA/+dE7g8aLwP7OVNqm3KgzKuCKJb5lfCIA8sSn7ucxlADKeM4n3cD9DOumWxVTsHAjuWJo+ND'
    '16fiHDRRiR4vDV4XvazzNqL64A3ZDsgujgY7AYvpxXiysJ73g9Yasrxsr6VahVa97HsM74xaEepJ3BVxxqAK9J59CRne1HDMXkZZ'
    'Kp2TM4zVZILJNAs1xU17JpwiO1+R7OuV5kQX7RKivMbVKsrU6edBTmNEwYMxdmXWWLoU7PKvWKtCKytvrcOYrrabc2c1c64v8zPt'
    'tIjhkj+Tcj+3mX0L5tESuV4zcsmfVJ4VzhpcqOrmfOAeDFLTsJE4ck/tXhw7bU4fcreu7ZOmI0f6ifP7SPXy0uILxeWWiuwvrL3d'
    'qp5kzW/QFBwR9mHIteklfFKLqfZLFki9HmoMqMt306kl9mtZuc0pMmoJi5M7NmQS3hSFrPG1kRnkZjc25C6UwcUk3yT5zaMX69oX'
    'a7LEeFH7wl6kHZipB0gt/1oje+c8yd45p58+cwDqnwtN0+YQ65znywsMx974ZCGAkZPdLOPhG4dpF75Z77o3PpuIfbPeO4g0u1xl'
    '9N9rjgJKCSkGnOFxiM+YwJ2k52rmKGgyC2/TLNUwQ6Di3JnFXgKSnzEwSILF1vrZ/lPkBev8k9OrJamm9p8EZXW0eebcPKh6s9fG'
    'vOmxcUGCk1CSdlqirlYipqyMmOiX1fj8+9k3c9kFKyUQ/BcnFLaL+up0m0vZba5Ht7l4tYONtt1ZntGKsL9ryqc7D3CSiJzFQv5D'
    'I8yRzomxiRRmND6Rfz5XvyuecAb84CnmI67AokhbnUh5R7l8qGY9dn57WecONUqXLuvBVQG1ox11WYjUTzM4VA6ALbSl9VcOT6Tr'
    'bdHsgIpA8lVTgdLR+JxZsQQ4HJvBpYfaAL0mt27kx8SrcebUTKrQYjC3v0gv5td0iicCHc0YywR/KFWNOsdRxu94beZzoD4Eomt+'
    '1L9aKVLOzubBreOyLk3d5R3Rqgttsf10NviJNOBV6CrqAFboVponqVTn6hd2UW7Ip6pxehosUjv8sSdfw5GvVs1xJbS/WlO1enyM'
    'YPAdHONj/wceuSd7JydtluhRizyhRuUKyppOONR7u3kYupqkqxstcu2BeXI/IXDSSgyFk3l8PU3mkG0OdI783XRR8mnDinjb4l+C'
    'GuTr28SW5wtcmgOK+gXTNFggOv/W4QFtYuIe15m4uxiBGtHFHm33yNPJfskEVGdzUt5v3A9mPiMsWfR93WVaTVgqKn/Tgwvcyx59'
    'MSPnbFTRiX/HF+TL3gVcHb7pyTqY9WkTL/ITLjot/hLFXxzKZ+FrkZAgHkW+USo0/9SLDkQ3w09/WHJDRw9RF7tdui3s9naf5RuP'
    'yE+9EFE1MvWaJw8/YQKos/PGgu1ICRq9dtvHolwVy6/zE/qo28L3oHkXBSQWx0h6S7cZEryqSJNOeHJOkc6uEU/ZndLuyny0XXg/'
    '7J3COKyucWfgVrDyJYk5oQH6KtHI+whnzhmOTSdh7g56QTCkGvqFOZ2DeCUE4xlDrtTaFAckxXatX0DYlf7Wo5SdRe9OSszJN7OX'
    'NRtofMcd5f4vIe41Q1cSbwRbJ8ppAinhDWbkXGFmTGElqKnlVBMlkjlITULvtAXsmZFIndPCPPuAyBUNamE90MapWq1PM0YFLCNd'
    'qPejDqI4Uq6fZaez6hQtOUWA6QUiKMcp9ckXNB194aTyM7VNVTHrK23l3aA9NrZGvRVA9yoXno9e069h2UcXnfLA+X13aehS5EKC'
    'ariNjGEH9sZEcsIaMoYrqJ4tFE8D9Hggium4l50iUHQ8OpVWv3CSP9kVz1XZh8K8hJWSFbHAF9OMXOYugHl6RWiwYm1ee6v5vGfB'
    'GnqCCNGoh0hVBlCOKEPWxYCdO3pw4KPje2pcs+jbXvb7l2/VqrdU+rCIQjOT/vqgylOmNpQB8406GOqOMs02P2NNFqik8HQAGe4o'
    'GvmN842fTLj6Z7bMc9KVEHS55bezRUAy3E/1Ity0fjy6ZoynjyiFHVldga51WFgD+T9dti7GnyEjL1qflKM0upHAAvwooiyUWvTz'
    'JpEpqIg5rzGP53bRaEfAnZzbTWRPIBybe0v4Vu+sekn9Nq4t//XMq1Q2dDycVReDMNDRv6jMY4d/CfuhfwXewd3/KtfApU3n7KSe'
    '/FMmRxqVnuMP6mCZVLRKJdqqE6JGAUdSnq009Z/ZUROfW+fkWnlbC5WKIH9KEp2eTq/NFewjlv947B1WDxyFqp1Z144atuH/AwlK'
    'qlG375Lt6jmGsxI4YhcBUqBsSf2LOcCyrXT7u1iNoOL58cyh9X66W/dCc6TNDY0xMzXGLGrusFH0keZ6UmIEjysEgUYhScCJhGe8'
    'Lkmos6EONFZ0BR5t/4mFKDktzAesZRyltP8k9qiVRiFl8zqzrhxp+MUHZdcvDLnmgzL4F/LPrXTqQ+Rwawh89C8yb0t6Bn5QFVPL'
    '83XT+1tKQIHVT6D0bioqr/pJ4mg+XNdKrvmwVlIe1nh92Tu/w0XJzTUJm1kYTUsXCstOdNvZdTA3kAKvBCcvfBRtFveBMNwTqito'
    'SXaeKbstYmKqszHtnepTRqlSBYwvVXj+baxf2ds1PZ5qWUapqoVv9+K3sdZlL8F+nPSklefoyL/8SyY/dqGE29Mfa7xZ25s13qz3'
    '2sx/7VLOhH64wSfSpVsnJoupl1iGYo79ZSqmG44eY8RIgs0x1v00+3Hb0L3+njLvZmIIci9EEJOEv4q8kSrd8ZVyAg6z36vLcMTB'
    'KgoEr/EqUYuSfnyJ0ikX2ZnF505m1t1iiWqA+8LhfdpSh5/cFzvR670mPOhGRcI9CoSaQhkLkaRuFhqQapaxTLNY/SclUhXzereb'
    '5npGiaSO9V7X5xtzJVJKAx+8AAXtnHQ4gAMX8HXTiDgwnx0P+uf2zA2de25lFyAstmreawYdBGYkb6hjdbWbOpmVRgd35r10Wu2s'
    'E72P7ZGur6j6/0T6F690P1nofrrO0c/YQ92qrVBt1+r00z/oYRETpW2dwkqRvZoSt05vB731bk2pW6e+UmSvpuTNI/V7uqDT9Wuz'
    'pijLZ3gM9DCNRTYV2dOFJaKWO1lxAQtB0i/1Ktf39TgncqqtHdDFrSFP1PYVG9Hqfb30FPT8t3A81TyGQSJTvIXgNZMoOinXYrFq'
    'IUmT/pX39cvQiHFHRJ8cU06B/TS+vhL4FWXTdVBbWlfrR44L8gZNMk6fH0TtWZ57WBTPhNT5kzgQtMkXFOpicVPfuNHzdVp+TZeM'
    '+hb1z5PIUYtjnI3i3WBKoI/F5CpBOtPFtxA1Y5KRQ8Dw6hCqFj8F5tmJ1yx0jjFfGi1R8CIYgN2rs4oiYL7mUh2yV21f+/1PnyBW'
    '5R8NAu73HZ/Ihuc7tD+QfXKy4Yzc2Y0va5VCLLuvHx3G3wyobuU+s012myeniQ4K4NV5d3dNeEi4NvW/9X5fqs0YRy4Q0f6msgOP'
    'TBgOLakY4h0lrDbj9CJXmyokmG8NJRvw6rzZ1QinHUi1Mi7elvKfbeXh9CEvSOb5JetmD1FyvacPraSZW49roWl2M8V6+uiWGlAH'
    'pXeC7V/zRwShB8S0mllxMwijNlDTKsg33q3t3ZrvNnF8tSYnXnPEHZMH3tK3NklamyStTaLW2vkW1GdLBGbbWJcdLMeOrMdnddL2'
    'O65wO2DpFMbYl7oxKRUVPY1mUzTPnub+IveQGC6yjYwCnRb0tGOw0TDmd3Q8u2MmLEdKYXkNf9XE3EZ/t7DXcYH7OaAAQ7nBKm2u'
    'G8pizE2Qec69IWyQcSfu+QvuEj5fa/kLV369657vhOcvdOfUzRS/jAueJWxwgos/sx0AZzkHWzJTh5d5cHiBFivG7pi5rYKv1u6r'
    'CxtQ9FVtjZKVob8Cb8x5fs/S8AwaX5VvcCKoHSPKrCRom/bJpjM+/u/njNPokuoCazs5+DspurDX4q39Dz3QrsRlfOQvoyN/D/fT'
    'EgT8C7mgWp8nKm7+t+KJvqgRhC+NHWaoJz19/PpIx0i/PHtfgyFALgj6ADpH399Lw1Pce1A84sdyl+AKInf/Pr8bCYo2Ya0tgZig'
    'mRPV8Z1aSJNiO2owjZ/R1Xi6y0xPLpNJQMJqOll04wiWNJVr+fm9uqsbUT6VluwfDRWL+a0wN8lv+QfiAeEHdyTHROp7BnWGhxIX'
    'qe2ZnB9EI+7D4L//13/9r7VNpjlCNmUIMRB2uovLQmwzaQUP9FyOM8mxvHxxmNH0617KjxdQgTVpcnCYmJIBkjO0/KH0IeYtQG6d'
    '86ES20BrNyHCoeiFyp+u6NcNqJrhPMSw0ucWXz6xXVAzc5kP6mBp8VXSUWFBn2hwFPTMo/G5Rg82gteXxuwugV6zzVZBbgP9aWJ/'
    'OLiLUUyYGiAgCoORRM0nqOuYzgPfJu4d7qcjbqveUrbIkk4ae4a9/mzX7xYMrzzXVDKGhuTMw0yErlEbVe1a/xLccadYdZZ5b0Rg'
    'd/61ztvvZNvdLLXhrmaj0N3BA+wJQmjRDmJY+eaFDhIbzTdt70IPwgN0JGrUvUj61B6XHnuIaoqVTQxF5HrAaR7dJP4G+mx94O0F'
    '1VhBgXnf2Be8bqwklreR5eVL/3X5z+M8gSpX57TlEsaROmwqwe2HBNPFtUMbzPlYvcLgUo1gaoecBbWCD083Zy+DRGGGFcB51SC8'
    'nNU6yW/lY2mqOOdHlNhg0cu+U8hPSGbcXXnUadqKl/DSnmSKvuXsvcRcdEbitTqkj9UzzWDDJuvsYnxTnM9nxSS7kBGth/NpnHUt'
    'irqNIgfvDrtt9WdYFqPyqnLIV7Eh4hfE20ZKqw3RbE0frzgTWhziNg0hbtMenZ8TM+Z115NG9XDKmaIptp0OLwjCzX3J8GJjlPRv'
    'ckGGWSMszycI8fpNl4SO86FhycJQnETAgH4P0AwWFEpFWz4wrTIkBbPfN3nI98Ux+EzInaLu1XSv15OPrFAlBzxa4kPjjkh0LsrK'
    'DT2A/ahOzQ7KnHbQGrLP0oLtCJc8pstAlV2Psa/bzhl3NmqVb7UnY0QgLDQ+BmF8jIZTbCFpWuFSkRAhxJmN0mwAx1OD/ozxcfH1'
    't6rz+pvqumrB3VNKJVUcev1FLWWY7RkYUhYKjRyYaatE2WDXZQ9KFauVhKJILwqNXZviahi51AP6apA7vZd+Bc2Xe7PxoyJ8RCUZ'
    '1WVpoBo3zmE29zo2D+d6Ne1mx8TFJyXUfsrT9FRKAfICc3eAITDSMeSGOL9kAebuSPuXa6LCxonRolmnG5JuwChA5FJZx0vDtbxU'
    'o7EyvwbDyH1uO1fhcOWANxLAJVCz21JhzDs+c9eoraaKOlECMjnjYE6WeQOqyCUla5RQvwnP8txu9K3Urn9egEyt7M/RdMig5SM5'
    'zXK1jGKHu4ZHgFZCG+aH8BORNLUQ5A8uz6KDRFN/R4Ye2nAtwvCD/opNUaMQkQle32Lj9OfzwMkyAg4xc5uS9zngZkLYWWmNN9um'
    'BDDy2Lm4di58/OWH5arjb7dd9tq+1yof6r91O8s05OgL489daURTi0wYkvV1wsTEZTbvpylqvgDfH33JWnFh4Ym99E0jgPvWuK7p'
    'TSjQ9vV2+9fJHmzkaqyGmrdzY7ZG1aDpUNKgINuPFLYXNQ+kedg989DZ527nUPJ6ujl5oUcCoFTTaVTs7ldXu7t/cYmCvnXmvE/9'
    'JS6/AWMw3nmcGEyH0iNOAKFqbCaqoc9fOE9ZWhVLjozZcH1AkzoTjpAK16KodNd2p8uoFRJ77T9b1+JPbzJjuj1XRK8MPjJS2gzi'
    'H8VR/JYTrRHHP8pr/H6N1Wcov1nrlME1OOf5ZDK/zuTqYsR65kZp21lIzoDcwdJvMd5FxWikXYn4fGaFGFytVnPF3+jH+DZV1iHH'
    'Qu+V6wtpDm578JqqGHVSihQzWooc4T1+Q1S/d+EyP8pLygqaRd2jAniDC8uO1AzjE2wN5lInrx/IG6qXA9syRpa/ctjLfkh4fHpZ'
    'Lq4s60ORAPU4AUMZnYFwUhN1Iqt62Uufic9SsyUzANoRZAS0o9C814Vm4CZCEHw2mVhNR6OOZWmmGo9qE4kJVzO1BbUBAinu3N1R'
    'J6vPjTr523iC/A/hB+Jtw4zWwFIj2yaXhqBeSHBHy9vNnkFbDZHHjia2tXu07McUVbqvOELrPaIHWSEoaHZVA7Mbh4GQDHDplUBf'
    'EfGuh67kTbkQBelHqJk09DsPnXXlQgCvEkgt596iH1tqubIGJjP5mzPsnOA24671g3HAtDfZA8YB05mJ4zqOy51wRsCYJO8G4V0e'
    'pnPSBjbu0B/+eezcMGMJ1icwoSgbfgWZdjpc3ciUEuH49NnurrC6i5vsq0/f/fjm/e1pJLprrMykahiojQckEWVKO+C0VRZ8ocGh'
    'yIEyGE9iSc6jMikJquXS27hiQOzQGIbjy56CqFzKwpywV36xcvVcy3ugpx0VVzjhUN1j/OlrJEHqsYcpIgFmFXz0tv41YMbPZ0zZ'
    'PIlTGjM5NSfS8oa8H9+sZMNolb1rJJCkfL0LGOc8nBK3eNMrXHMOkbVOD3ELHdqh4OT7A6H3ID8C3LJ3CfjMICyfvgC8xtmZVj6P'
    'KmciTKu95+15jC/as9SX7q232+lb9sVl15oQwmpVUnJ3ugAd63jk9PjRgdfN5bJ71B0HrorsMDls3exqkKXHra7D/kj+RuXGs7Pj'
    'q4EOR8Ps+aSg4uYjmR4VIa0c+TsdnpVbN4SVj/w0BkqJXCHoBwHRYQ5zzYnN0JNQ7jttHcyQ9FMxk84O7DF5JOlW/Fh73yitnU1K'
    'N/A624RA3VmfJQOmRVtxEl66verj8fQXZDwuwze9oVuHn3UZXuKJzm8ZlkHKrUO5tZZbh3K/bBnOGWXwkvz/N/zv3t4uTD+p4QbF'
    'aIn5JDNa1ucZb7F6jw/0bTrdyduf6ytaf5subPS2rkzfdBt+Sk26drkmiAwtEbc6U9/ZROso5Ka7pFL2BaLuj/CfR/KrH8+iWxz0'
    '2mbmYXZ54BfDP1/zeW3jJWyJfBIjtbwOejmmsgsgWmVFhpxxQJXnlS/wHwU6GfWzlXCmGlNEeoIaZlejc4aTTYQHr77w1kpqw+eE'
    'uhdOl0LBeflxHEKjgFNyNTFcfbC7eYDOR5lC7QVTeDdSXJBmx4pnwr5HKsXh8DogV6k0ZvhHhZJQp7kFydzBO/+L71zJSCOsZjhe'
    'Bun9UI3P22/m48ghh8Qr4TxiD53m27WX+wf17wfx94P694Po++jKjZh0P13q/u+yvCb4sDUSJUNsDwG2j7eT3S2lZSce7yl1sV+q'
    'mQ+v1smrdZNC1khf3IVWwnesi13KP+XgRGEhSAOPF93sgzyUf8oP7sXPdfj0glxKuSDEif34wB+D+I39+NBmK2Sa1OF12HUPs/Dz'
    'Q077M/J5yDPtUuGK6M8Bi+RhgTR98wboiLCMD7MnSFm97VeD3IRTR0zh+EBtb02Ra/qTWDFrHIMcOhVALVsxW8HCGOaIox4NdRJ+'
    'vNKDEot1MZhzMdFtxz8rz1h5n4Rn8AzYE+JXe07K+AREUZGgpZ7nVon9roeXGTPXyrnFiqwvtTZEN6REXM+fZovfrbuMaNhep5SZ'
    '2+89/u1vZXK1HqBG/6Zhv9HA8v2nWKbf7oLIaOn/kD1phhrd9CNNMxK+PrTs4kG7bE/raSVijtXxtcokQu6Ep6CsTkfeR/BhUIO5'
    'hWPeg7CIkS5MLg2fC2zjlSgioldl8ZI6wJN19GR9EAMVGEcJOZ91qv7KrUJDF3DVEjl/VbddX/VcRlKYmJ3epZ+dI5l7DBFroaZJ'
    'nste9tayyTKm78Ls0wW37vk5si+GdBVUCCEdn+Ue1OJbxGec0yuh9wVzPczKqfeP8eqakIPXB45+CUkLFmJeZq4A9ebL4jzmLTQD'
    '8EupOEZipr4rhIeoyqeeffLYp580xHnL1hljtc5/eS11hORj3E8nipDM7Nox7nYCtr2OM1WvoIRZjJdMfzwbjnuz+TVwcUdXPD9x'
    '8jZMMPoJ+MD0Rk7SBSEVJsrsSN3UiV8tGXVJ2+6eg/BaSDP4IWv7uIkzayOC0LWnY1rN61LcLIT4KHbTJvX2sQOPPuTMML4mippU'
    '9Fmqh5zWB0cdHXb4s1QUdbwmyF4mV4RLmO0OOaHccm7FHrO/wpSpuV+xiwpsye/wvINptQ+Z1jjZvUb47dknmQbot+Sz/l214aM4'
    'tXW0ecPeR52JZgXLP6lVF/p/36ZjSawSKn9T14O3b8HaUOO04yF77/z8fDJ+ZalZqQXLNOd2GEo9pXM0qnvyeIf0v/UUsIfZl/VH'
    'VFuNxmfQWYek9OXornT0pubvZ1t0Hdnir6oBQj8i0HyIxXeA4FsB+8M+BK/ehjFF+AT6vkono0ZIe2NM7PHq5WTi5nPUQdE4OTJ7'
    'uyX7nS9+0RTWYe1IyfKQgtzPpKsVTZC/s8nJm64B6m9jad2xzNME3X+arJjz603r9lN4R/Wt+eQjEw9/XyZNX25suvVWyRO6H7bL'
    'mc4ed8ofIXnp1jBYLU3zFOfPdjaMEn4c4wpcI9R6DgssxpdX2OKALi+yI6Fm5oSDN8dVWPQ7adorZhVBIjVFbYggnS1MWiTRiqRo'
    'kyVJISNoTOpbRioXT09kUpEou87Z7CzOcgpfL0RY+bBq4IbO1lGaYZ0kurAJs+zTk3OOKnterZrAJ/XAtxGfBqZeWh469DXyIs6Y'
    'ybEQaSTKmBwdvOhs+RwGBhF6mH19F/b825e/w5W46yAu6plK61ADm9EFq4abeYtUqS7mZbuLeYoy+OsD+D1PLd1a9H10ZPffN5zf'
    'S0eM1jJFy8a4foP+7CpcRi2wf1AP7OfOwt2YH2Xgv5GkYAyklPlZ0LWwmRIOW+VioVbRcHKwWeY3QVlyYdFiEwqqc4MFmNdhAWqg'
    'AIMIFEBVK/MUFEC2k9n8/OsYFYCv17um8N1BezEsgL7ei1/HuADyOjA3fwtYgHa8yb8tDEC91Vu/Myysb0LZe4p0oC0bxDQDRw0t'
    'F1yIERaBUAo4Icq/i7UpvajJMpUXdVym8HJ/47mVSfIiV9XYbYrpvZtiyl0w7ZFrRW+nXPdpj6GEfLDWEmRd52s80BIMIZyvG4s5'
    'TVZzmiznNFnP6a9Y0E8NJ7GwqoPwiysb+4w041ZCV5uxLqHjLfErfhjNmBc3qLr8kOjGdlUvhiG16sMWN5zfBXX/qkPkvoifrm0x'
    'PkRlOWZf/sO6/mYdrVei9TL8eQ6d4wg70RRhLSU+sI1UN8aP3Ct8oZ95ZVntvavMtGctMVUt2rP0DNouRvYE2/KqMespBI7sBixU'
    '+AkZWHegPpn2NANLEqFbWI2EIzdqLkLNlh2vFI47zQG+Kfu4B7rWCBNPhjeH9dXSkYcKLtIK4gg/o0o/XbDn1AE6Zk+5wFPhPk+F'
    'IiqqlkIdxf46Q0ZDF2dnwiP1Y5WL5QY4JUj6qaJ4hXsIQX8EVOy885lWpVwNv/rfwccEmCtsDxIWncFdcs+NQn47kul/J24ojeTK'
    'dFwmc6w7xG5fi9eWC0RaKdCZAu0VoD2I+Wew5A3MdEtsqoLhkiTp+psBk+vwniGTJOjLlPtyLpGMsOhHwDMD+hO9CwH4xC5EPj7l'
    'GeItrh4vag5pe75Oy1+E59uN53nejfvEEFHNrcnT6wPRT1xHJ1FH9fyHrk6IWTIhLMmEyCO4p0ITTEjZTxMVp8gflVMC2Te3MXcA'
    'zDL1TjxzApAeQ01gUCrQ2AAuvxHT8LEfF90kdnhgM23KwS+qpOZL6UdK19IipXnCBYA0b0i0YMzsR6SjcTypcajzzCGjWULsgxCQ'
    'IBKwy3VvnWdaBJIhQ1+jgFiKaFYAZGE4X5SWtTiMXxv6iKaQdEJe5r3s3Wq+QEpGYEfTeXxITwieDKnhdFJOy9Vpr27z8+Tok48R'
    'CrvGpXK97WYf4VU4LWPrR412DYOZzTiPEYR1BQUdQnt9mSNcjNXc5RBXx0+Ig/f1PukYmRpwn8It8+nu7m7gSocORp5S8vV8yZlN'
    'E0y63LUGTEPK2FSONjqAc0YPLFTRW2iA5arq4Gfcob1ah75oC+Hm7N49YFauwsvORzAD8t/1Z7fiZzUK+vC1apdNffhLuh02SH4/'
    'MsIkmqTJL21uWm9OYX2F87DeT1mVsfTJM1S//xm12xp8VsVyDOhCEq3A/q9a5jvGNam3rUJKy+K3NR3/imlsiPm6S70S4eQTtHEy'
    'B7qvpi93CrBpsQJlVnRWQM0aelKUW0ubcMFlDe9b6vcSmOHLuuftpeLV1DDioti0wnned83RatHIODUIRQa+SB6Aii8DnGMIlMdR'
    'cWHysUoEuzrVuhhfZQcLifeSB7uwG56YF2CSPEiulHIElzxLCgA1XNdieisDhN6kyJN1sexmsNXNoEgzzR70b06NwotWlY9A53R5'
    'HrV8ovpraPyCvDBXJNKqvoaKvVkF7M0aqHgVwiOqKLimFltYhcXxHyDqjFm6Gno13CPPLND+yT7+QKx0cqKqc6rBDUq/qWQ+3u19'
    '/bSLJIPIe4z/Pm4wwANixW6zroebw/CR8LkeSIW48Ms4iIpQhpU5six87PhlHEZlZdZtwVRp13/Tzaz/rvP4z1MZQdqZMPtUflwS'
    'dsG8KeOAHnvjG05m+rHDNNh/smtz/Xg3b9U5fG0qh7QXo3giymQan2hvRvE01Ev4XjmfLqmcLrjBLVW4ERjfEi/yQJrp7wEvUSMg'
    'V/LcnLxpV92RYt4SGMnI5LA0r2Xl4VjU9v8ZseatsSfu1L/MLq7Ox4aTJYdyVBbny2Jq0qR5gZWAla7WShLG0hpA1IEuTk8yoPeS'
    'KS6ERtwgnHUKZg+dEQ7nUtsxxzTvdqaBF+Vo7VTt9EVzrVvhVk810nM6wcDlbcV9sbt7X+4WU8YDtko/e+HfRgkaDO4vSgWbYHX6'
    'lExN07xxbLP8JPgAn0mHL/rO1AIbS1BIZGeTcuHgveWmexfnc5wU1cW4ociPLu5UXmoyarM6U2jaE6J2tfM/jAjUhvXEIJhVPjuJ'
    '7NlfugLO/BVBItyf5QoVzmgmtmrS0DZbl+dUdSZYCxZehX56sc1wlJM4RudIlYl8OCmBQw7xxcVa48hBKe+AEQHRfj+cih1Akjv2'
    'P6/5oNqeqPLNQCZpbE/1ubE9voVR5JH1eLcxYNtfLl8AwDlMhtMMfleLaqzQCGp81Mw/qwvkUNW8elWtw+8a8LXXBYag2cmjSxap'
    'EQhtgEtZ5qA+8sV8PmFd0DF5iS623nysAglto5k52hiMzzROkI5UrhpU3q25i+WtsFQfsXwfW9HInOxoTWwrhsdRj8kKj47kzs49'
    'Wa5Dlem38YYNKEHI/kfpeEAPJp0hEj3VRo7mCBl2YX4GMMITsLMTt0PSr3Tfz8lBE1NNoThbpseJxwjF+OhuGR1sfTis5HnbBCB3'
    'WmPpqYOVfeFxUyzy6mNXu3O7YRiRwHA3mMqXiqZSP1VaFYM0WR//Yp3213pzFhj3lQGTkZr4gE396UBX2rFhf01WlzdY1gT4xIcg'
    'Mj+nBjFTbqFaoLgpK6YvtavPQHVQ+0GcqcJyLTDWMQ5IrOaTj+MftbmqozEAe3fYoDdnMHr6b8hg9G9NQfm3SEAZx/k673IX5Ot8'
    'z2uwqptSVWIa48yxdyaprBdeJ5jR0oZLqyw1KPmob/K2THZRvDyqwMdHQBulGQcHFX66ZKJp9N0DcNiuBc+HDxCOJT1q+WjNj2pR'
    '4Zhpu+KK3D6334PcnIaFqRXKNjDPvqpwVRQaSTJlzvbiQCOKDtEh/T1Q/lTfDw5Ua+zeDzYdrxTR6ItHD7Md/7+snBZQb0ZPHj76'
    'gsbe61k1LBQ4ubCMSV/v7i5uqEkdTwfgW6FaEAm4yP7hT6+zzts3v9e03pZ0nHVDbzmRZ1ew1IoAO6tID4drYUuLaj0bZtFJLEbf'
    '45uOXPbjJDx4iVtRGukNpdBqrJF/8ltLYmwI8Ug0FNNzu5S1SseVTc971RIaTqlTHxXXRcnyvZGw6iNf1I4+jNd4OStkGovJT4jT'
    'w1YUJlrYm4v07R/GFNDd66rm4ikTKDveX+eza9SQuo9cJ6m6ujHCgHRF1jmPQSRaCl1oobhODHc0H14hJsVm8NsJI1Q6W3K7fiyq'
    'LeHBhxqDiKx0+HGhQznMLpKqVjhOQ7CUr+QIIoRxa3+05Zpb3fSQp0SnXOaliwMl/18GepECvLAaKS4VsfTvZBt1osI97KvAKReT'
    'xUXhiWhKQB8bTMlNIKA4Fk/00lrcIOrxObzaIee5ikgoHBdSC4iWDdK3gkcy1tUcncNu2+KWfrSYnW8xpUjz1c+L8fmWyvi5jsTM'
    'JPAB5EH4xH28HH+cX0b7WHZjrv7gtUNR2fzwjg3non2761aunaMgjmz0R4w8Ek3y1frkvwfBYXODu6anN/7Ld0RSW80L4a622BOo'
    'OYVg/PVf/4tzV4cqjAHJ5jqnxVbCgw2Kpe6nW2H94DL0yVX1iuy5iIAcohqvOe1b7XMnp5/VvsGpXmACi9V/m0lEMNqri3IyCs1+'
    'YvW3+eZp/OXjrRPzmeYjQx5RdFMOSUrY/czgLXdUWb0ZX7tzBSuRDK6Y6PTYSI1Tha6xPO/b/kAb9rWQuVmx6Gf/8d2Pb4RhBqpj'
    'ebaGP6f5mVEm04ot5N3cgfOoMqZkZJkDa3q+VIHdGbNZLHqpMmDMWMUO5XLA5OLhypt22D47E0JoYHT2RI7Yu/FE9aZ/wubsxM0b'
    'UelmLQ+d5sIH/+m0DK+WFXKRqRApnYpds10Qx7esLvYt9zurHriv9nx7XcuEwVB9+n1oVHlnZoGaH8vxde8yCpdILo3zHoZ03ptc'
    'gEylb4gI86Sb7T2l2/6l3jcdxmz5aCEtCg+XZ0QJjVoagoFSY78UUSnB5PEjaXK1FtIZXOhQCf+ZBL+ANFukW6bVGv64jrE+W/Wz'
    '068+cZhg32YabCpV0dZ+u7g57QKLLJRCh4ZrK3ThC7E+Xn0seq1f6vXHJxf6BPgHoGx8dt47Q0jbZXj1k30gb66tMDqMB+WqmJRD'
    'GfyW/rUlE7A1Q+zIZKvrFWl/CC1yMnztC3W75ZvG3NtwMJTsaxvObd4SyUBCpeEKzWRwm/cejp+9PIgogtP71M+i47+Tjatb1k65'
    'deEoG/dAUGQqkoO1HBPCp/PoL9X2V4+62ZbeBbRLW5ay6MRrZJxU3BO6M1WUhi9nuIOcYESS3SOh8khkxUB42DkwdMAfIiSgn42W'
    '84Xay2ZMf0CzikFgskcRGkEeCScaEPLp/kCQJG7Dy+16uTqH3wOwaYwWwt4AnASJqrysxh3Ea71bFcPL3mK+6HgZ+zYEwcwcJdWp'
    '1TuFb3Qu/Pt4xo50YWRHbtkt5qfZ5g3UxT4F+Q6Vu71jxeBpUi+WE3vFdxx60nEP9wXvQXtuaU6mxfLyd+Vyte7oJSnT9lN5Wf5p'
    'fFZ1tLauNZCHKL+Y5tOvQHuf1yJKbI/JSfr2o0z067JajWfy3VY5W1ythGOzDNQpnfXzGe3Q+P7GQdtY82BytfQVx8zCXR9djteI'
    'apHvxs5eJ/MlZOyt7M/inHsrDHbck/Iar/GtSGsLYQxkCOPeArffbPW78VlxNVlpwIRvXxOtcvK4N+oVCVe/3OJBkpahO/rjeP0Z'
    '1d5R5ftisLFjXtvkyQx9FNOKo+gomTJlrBjDJkyQTEaNDQKxp5oWCcQ2MECr+U/zpdSSiJkwgFYfzyGTfANhSjrzalJKf/8kt5Fj'
    'K0L0qwxxyNf/Cb5lPVxJmbauuHZ6A6vRzhX9M4si9ZaVXIeStQC0wWB+Y+zB38KjsB5nFJJRtnvOtzAWeub/Bu6DrOdv40J4+0XT'
    'zScFBgIo0GuA7FR+qM0hDMyFdfMQ1KVvcIcH5MC8WDd3X938Bpu7/9aMVZeaMbRmq90z//Bd5x8esHNml9lgfk2z2RXieEaKrBuF'
    'CS/KoWxdiljRcid5LRnOsrtxmRW08Vnr7Giay2et86JIkM9aZ0TzYT7zcxGfrxu1UqCK637mscWETbOgUj0wTOY65mn9jtpY4w4i'
    '/meVgM0xaxwPV5cJ13Hk9XRSudPN/pA8NJ3OTvaERtOkqZ+8ZvIP/Mu5q4nINilKdeZYS//k/J/3iJB+bpmXi0GOaFSIoKqEltve'
    'qHpoIWbHjEbECqXek8g2tEuHAv/yJ4CODsjL7+0D1vEP+uDCHhj/YOwzRqLseCfd58JeBkHCuOhD1rXvEEnChk4KF4vFZP2P8rMW'
    'mjoTkUy220JuuJvh5Go05u2v62Or71AAoc4KXiu8VPSTXjnjv5YEsi2woo2aJc4I54kHuoKpzOjCfhjF/zyplVqz1NpKuTifJwee'
    '667dRQazaGC34CsjPLPa5WShWJc/zDkpyihyP33KFMUMAfbC0mlyxuHFfF45b4CQ5Y60YDWPYlfBtAI/p2OR98JzalXnysvXZAEt'
    '5fI9ukAF1UionNzWIr+iy9PW/fGv0SjjofVDr6g4kJ6f4+IUORAcEmE7t/BtCQWc5//dR17lJJe2MJWt05J1hFGivy359Xwr3Zz6'
    'lJNlN29tPVp6tRxD0V7r2Fedrb9TC9Z6K+/Rb/AP7394LdWAzY7VAcIRySFhk4uYShWUnVz7ijZ4d82nzxeyUbPR4YMfvvpU9G5u'
    'u/hnfZu9/urTQn/KBr59AA3Y5PDBTCSgB3Aqm1+ODx989en9H7794dt3x3Ju31+Mp+OTnuyTW1dghwLy4YP93lP/aFQAV2JZrA8f'
    '/CYLjyHLCi96+ICU7sGjF6ct0ijH6+AJElyIZMQhxF7XxK05sB8scaXQXv46NASHQDHhMRkdNjiRDMYOgTXY9OlgrQQabg4anYtI'
    'Nfpxj8qzszE99ibKQxw4N3Gc6/m1tqOGSZc+QWFpKrkhyGkSODwgVvVqAeARB4wY6JmIHN+PFFTHYxoacKXq4fTAyKBvLZ4ec2Mq'
    'WpMnG9gAmTsbrzn8XvYPlXqvw21VWLzZFQ+F6mYv5teQdifz+WW11UbVpvMr+TylXrgwm/IMk4SPl3WZRgUEQ9uFtLj7+fADQPf/'
    'QTpshtg6xkibHL4o9A+/f9wm8zxUQkw1kgApAuhdCyUBPqhhd4x7QlhFVOixR5jbY9gsdmSpnD0k3usiaG+vaNWoxrCpi8RNChtf'
    'So4LimBJN7XCbQHKfhIo4YSebIHeb08q36Av381MAMSCyZu3ukKvigXYQ1kVW7LvRz5/aAx9Mrtr6ML3jKuoQzNC9eie3J6F0bPc'
    'QbR19a6bC+fzBq86FVA2W1pflMwLsKl9ocxR6yis7a++g9L3fXHOZ74bUry1lcnlPRMfz/mlDdFGsj25TOY8OZKR6qDZqqlc2lsd'
    'j87HJ/HNGk2sHGfXIoo157WlVSc5MMcMKHYfX9XudtAAQy0IauTzu+afsCNRP1dUANXQSLZX52EJ+Kp1Pu49Y126MAdJvqsoO9nv'
    'ipUh8tTI66YzGIqNBhMD6xHWTeglzOA9wqI+1YR77lmpMBnqIhj5YcUqAV/4RihfJP/75wx3fKboRvpI4Wr67If6DkhfuqT6IhD5'
    'yikXhSq9lUU+i/WedFw0Ps4sPjLTXkOD7ePfe70KucOFKyePiQi9yINowyBJ3S3jUT/FF28hZmlPMF/jXjFxWiV1qp2stsnbKhZ6'
    'xLaZwydvZksLI8zJF0F1apde+37Xcp4eYhqV+OmL+wngvcNx072xM42giaBUQwYU3Ot97+ro4xg4GdwL68WYxoLReEv3AYfTzxbO'
    'HgdvR8bp0bm2ZGBOji3Hf9cn+R32OcsA3HfmPxOvkg45v7R4UhOtcr2vctlKV6t0v1bxhgXGa99ET4Cx9p1keetXrMn3S7Uzz15j'
    'IT5n+SCT3cmYYPx1xiQwBzFzHuhMKnnUGRc862EqVPeJ2XCbxAvbLPMRcnZML/i0ujkIcraWW0fl/uzLmSNWLGa3chF1Gjly+UNc'
    'RdhP3s1LJdzoxToZbE/9rFKa5/zrnfQvRO1JPCvRh8FAlIBiCXUDJBbYLRZ2lgPdysDBYurQA9vTwMJi+tDk0hYS+oO6dZYV/ui8'
    '0bVwYWoGW+RMkVidvcgBFd9H2FLqdToAb7w8Z4xORI1Wmp7QA5MA98q3DzOI13GwB3ascp2M+eI97zS41sin6lLunMxDn80kJETC'
    'XvfbIL/ySM8lT38nH3ciWd5t5aOebtU6/px1tLa3HRgb0iC7my4VRGVt/AM7/+aZ86tE8OT2b7DN93HLrUfR7nM7RAeOSt0nxCdU'
    'hsdZzzLWRqkwIThHvYZznZ59v7i1+2Hjdm/Z6/E2D75Juh2kP7gEQkM2IzbtfxrvFKsVAoVHgVD6C78duFFW+Q2r9VvuS6/9wc3+'
    'z+MfzZc5LuT4AfRkEeVzglEB9ffprrJV0dEHEhSNqPUD4JajZiIcfY6J8A78uDtJ/tUCBF/Pyn3Xg27Rzyh/fTHWcsFq17B1fZZ0'
    'KlP6I/JH/lAMu9AV7shhgD98NVwK/wzOS4pb+kmoE6Uc7oADpIbRbGPCwc2YWXK4Wk622bEccYJ//V/+j22tJfvn+XxKHGoNyEAd'
    'au/DJ+BM9Nd0vCqMTbOrawf8y2g8WRX/yV9T4dmfD1qvo4hI32Nh66q3btOuZl65DStaOOmX+/AtmBRTZHjgLWSOKuObRWfHdRB+'
    'u2GUR5qFAA65u7t7T+FZqVr0x6lunEmtOvyvs+49RIPOcBfd2EyQ1eF/nXmvrSj28+V+U00ONzHga5Ufx8aUZWrgfJT9jg4K6q47'
    '18ScRlqR63M8XazWUToN1Vo4m48WzBkuWmS9alEirheObaDDELsJcaJEsbm5QTuhcvT7u9WS28q1kTwoQeVI7mqCSYe8xXwThQ41'
    '3lndfHHPafyMBiLMWm4+CI7v4cJ8Nl4iIGkMrAHPH53Vb4MzXh3KR1U/lasL5yS6VbO51lk05SgcE2EUHg+PgjuoMgXd7AyOqImj'
    'I3E+uxAQzmJmHT169JfeP5eLrx6VPSTNlA7Cx0I6czWTx52zvIfsxJ1yupgvV/9YMHaQLomd8XKp+SBxyzygXyLYo+CW+BGl+9kD'
    'sKrLpVCOqpL+KDvB5rHJvpMp65wZ21JTKQ7nCyE72PyrcdMd/RVI2SsHosEoD5M/47xWMYiPQ/4QPoY+efQeq6AiWOEfOxlIfATU'
    'T+KDfBFg6SKbDeTNvKc9+EftH3Ek6fxucWNmYq316UA/egdxL3wKD3m0REQihIkFjBI5i4jg9GxmBCGpSXqvBpW6KVY9AwMoF5rv'
    'QEjFHAmEgXaUIe59hqwpAGG8Wmle+Woe+utGATKiTQkZqphxh5OlPlDuW532kQrnWEzNzuIrYVrhyunZe1/opn71+vu3//T+z2+/'
    'hc0DVK4c8s57dLOj9GfHgle3Dmj5wlg8RDt+vFffm62trjb1vpwSjKCGUI2N8w2H1YC5bYsmpCuaobfUg/aWHhw5qDvlRFUGJ+Cl'
    '7DjRlwjUV9xKo1fIjwY3FQS0zvSyXAJcfKaX5BKw4mZOmx0kyX10x92Z0SjC95lQf4o7WsdhcD/KmNefIh9VSGFV7+3E0mDp3H8i'
    'FkqfagYOvGs9u3WFbE1sY/x45ibLoVVIkcTYExfUTCy7iaX3eOsvqy34/I2LFXLGb5ufDx2vYl/Ah3+ZyX8enXezrWwrd75rwopv'
    '/fVf/+uWYjYw5G5Mz6AADhF6cKmcM4N2HKDD1l9mWw5H9ns7NRbV3FkVAwKc8lKtzBwkvx1I6gDgDSsWmV1NBwR6GYwBpCEHjTOK'
    'ADp3KMJ+lTffyVIx/ROd2aK96gKqa8NfcuAy7kqO0Up7neyJic1IHkArnu7uRlnBIidcb9NNVZ9upx+fUMfkWW7Ns4wHfRFdOEdQ'
    'RJ04okfuISToiiOvQTtc8HV642k9Btwji4U75tF/xgrnSLQRRr7SJZf/bTnJPVapmX8ea9EZCN/+587xzsPtv/7r//nX//2//vV/'
    '+7//+q//18m//GW0fdzLT/K/VNuPbEbdfBHBRutW+3qHg3bqAjlX+ls26s4eegkIJB1Hbq/ol5lq/Ower5K+6xODWaBSklQ3xOV2'
    'DSWknyV9OEq7sHdiUnFXo01xcH1EbxWkqXjV8lQ5RKgp18U4dN95pFL295K3ml4XUXj1ntfhVrh8iwntnRNFKjsvVFsiN6jdciGm'
    'Xy8Zve4JnSWHqhr/yrnr85Zomz+qnG+bcFDqFiVDybOVH6qhkkdeSO30sM9DoklCoc9yncDfFu5Dg+uCKcKH8wmzv799+frb9++/'
    'NZax1oQr3N5UWj2p1auLsRxRIzSdEqqrNVF8XD5Rvdftjs0DE4GUo7jb5djiTsdOBwQvqhuPEjo1LmYinC06w8hP/CXs/b2y4r+d'
    '4VGPnc030JTB+vsRj2fFfHV2vaGD387kuMod1+E7oePHJ0q0b6jGvjniTNycxGkaR4ln9Cedpz4b6QytI37a7Knen7IDuhqkEa58'
    '+yIAU2zPjnoOTCAlibVr2ZpKzgsq540783VofgW2weyWdq5MnzbsYeGbE1fbF1qsvifqHdJRui057DEKE63Eu3No3sz22O+ktzyD'
    'tpP0mKrRLeugU33ldDFtkZ2HomTQlpbAyCQ3yxyxhGwkqng5Gong2UM7QIsizJ4xjnbqAzi7tX3hGU6k6o08ZfCZbsiu9bDrK9U2'
    '7SqlJiDsXr8Yw7o70xszZll76/HKm0G9dE0yJZJCZUKIioUK+88uxXKihpa6rRU82OrLflCnwH5yjqKvN5Bjq0OI/7G0FwTQiDJv'
    'GmgZZrlYRarZaCCfnbiAl0Gi7FRVoj6LUkD4ZAYt74y/QPvsnyo2LMezSSsuMwOB/2Ke3sHOwMR1SQ42mUZiA7obclqYp2GbL7Sj'
    'Huq04HTxqDNXzD0DUOkmHjr5nVUFM6xffK0wDV2PLju0FEG1UCIGU87snSnfjiAvdMddc+FT084CiULvPpf22jpmnkSo/ICToncp'
    'frc5JE90TEZGHbpKXeDwjyBt1IDiWtya2hybWgY5sUGinTBEaxfScvwQvmT+6lV/eTjJ1zbqYdioSi+iNDfHeELn1ye7Sk7UN1nv'
    'a69DSWtKPMo7NU9i85KtRwSYj3Sn4WIcFY/CAmIzR73xgOBk6E10D99VlGroi+Ejq0OEPpZh0QyDBgY6/mZfRDiFT3lkM2QW9bbj'
    'EvFN8TI7xGFdDWbjBgyNnt8gfM8CUh+DuleRtal1WrOI8plxf9a7LAlWJbSvzqSSS5fHWsKlSNFglog02FPhGnGjbTn4BZ9yBexr'
    'DEAxq1eYSyGHjegdsHf2KIU6M6OR76lCdBtJ4QSQ5bDnWoscVkubsh3SaXLH+T6xYNwpvc6xljPPYv7pxx/f/9N3379+fdDoN0eK'
    'fhPJFnoVfL4lm0L6O5hfQyS19XHeQZZ8HlQ2cu7IENd66Dz0pcO6WZxI8FAOjLntt77zueBiF4IUknAVG7aSHaBvDsKsYHyhnFsS'
    '0Bq1WTk2Idp4lk5UhuYUvZEeL9arE7FtxayicOPkhcliW0Dnncyv5FBI2QlE5YurAVnAyucismkl+JqPlOv4pTqMFouppQGlOYtT'
    '5eAKZ2G7ecrqD1cDuAgfcXyv+CoZXwZ8Qn7ih8ql4iK8GTOBI8AudVG4WXVAJy1g3HQTKFb0EwjuAfJgzQctIOVUd7C+yJwZ4PRi'
    'ND1+a3uD14/vStsdNNOkQ3DI0F1NHa4I3evZEO6CzA2L8CRvzC+X2fEx75eTk4ymvMyzOxVwp6H3jnJRGdnyMlje5sZTjzTckLAo'
    'jemPwtAryxyuLBmv3tgVAXSJrPhI/jZAV1nRU3v21afoi1s3llOnvHofLO2FSdXnc8dT9yPttHDSZgaqcfQY0yywiU6X7dS5qoJ1'
    'dlsz0QQHMmX9MEQaKSbeWyHIk1crU9PGCq+KJ151tgeRQbKcdaqNXht17valx0FUFKiCfotAJ4JvsxNS+spRlZaW10wKUvtqXIwc'
    'V4/9UPXanMrw8Xu2F2mc88ihTPYCVNTIVqWmpHc2hQHfcOXkm6tVRnMUQdHhjk+gvUihHytRR1eqPB/fOXNRrypH7SKRacLMsg57'
    'LzPuUMQdn2vIQUBEZargdnGbatxtJoB1kCgwZ5H4Y0u2A6zWmSbz0632BlbvREjyOL6pbAz9biSpbIXjc/rVJ0yinJlXVyte5a8o'
    'w23dZg+++oTWbvGvFDilBCd/u0ODxy/0vFX8Ur5xNphT/a3HyoFL2pJ8fz6bL9VJVzEIRaj/duJC36WrLjoef9b8Vo96na2/M9MT'
    'I45VKJeZL7p21IQ2QzKgCrpcFQPzo/W4PU0jJ9ah7rtW7y2cgaQ/bjN/GYImvkTR2GTZ7rFAk7tWCagbUDxC9XjzTrfuWMh67/yW'
    'rMcjof8lPAWdXcHsgncNmJHa/4ONl+GLOKd/VKHWYtjumAYV1u+fiMQdCvm4HHkK5rRYuwYcr8P6GLo0fYNr6KDAkZq9TWF3ooeX'
    'ucbvMnZ7g/imIHAj5964bSbsM4spd0kJ3E1M3B4+ieARtHvn9eVSIoIv6YLgIHYiFbiaENLP4xXTGraCFskpPdkDfg5HOadb82ay'
    'I9Wo9WtoCy32n74ZzjbtyUTzFV3EnbwbbR3ppXQtUf21m9ovx2s1Gm+IjZ8VH71P54b7piWp9qgtnfZd8eapaoQMbJtq5OMNATJu'
    'HAr3R4cuQ8TtrqFBHqLcQ3Ct2yghfyGx03i58Gjlg6qjReibwyI3kbejVuOiefnlC6sbubKftndOM54cWsFt/e5hth/q1RLPZX6Y'
    'tZqCKx75nNWzgGVBVN9xFQXNGP5mGsKRcpQONfPdVO7MC6pXhcMrKpeJr1BsTDD8VeQ0VEFQGc6nsky4bBiFXA2X8HjoJKkzL8A9'
    'Dy9KEfl7RqzUXa1pik8xl2pcwYaERKolJ4Fu8d88HsqKD9dQzwA+5ai3mrskNBCaQ35nB+1bjnaKkE27KKfch+qwUMId8UKYPU0O'
    'ry18dgB4N0N0IlRDg/lqxVDFP8hOQjgmpqjaynvzszMhYT5eHBhKbUhM1BV53KLOMAZPULwlxtcnJbaTEqGuta+LcEvDGEBB61rv'
    '1UtsJyVaUNMnc/ggyYDLGRSnN2T2L0qErsyR9a1Aj6eAu806+GdbC1lMuJTZltL62zLpzAHr23dArJbBpY/qnltF+C/r76MlbeTI'
    'mpIH/SzKqU3ZVGFtXTrDKUL5pVO5Car6VpMc8q0uWuS6f0OtEGjcPdmcE/dMm6kbvz4IbfAT3N2QGfzfnA58nyH89+UC9w6LlfrL'
    'I+d25JtYqdM8nzZiB1QkD0ebqbhlBe5KmN1P821HX9+ZtNtx1hr79Q1TDjuYHEzbyqL+5WAP9CUiUUXA751dS69+A5BdXGtxLd8r'
    'xNamekr3+kv/d5KXOqpPoRjAEbRVZO/U0bRjv6WqXajuhMTuPCYoV7PyO/i5FsyfdnAf7Fhfj0zwcq0i5lwq6SGGty8iRudYJZKT'
    'nG6GSbxs4pGrKPGxEOOPQoiKwPsFkBkvRIrSDMqq35K+Vb6jm4SdrbylSr7BZpEb7q5a75amnNCk+E158+qYzjWe0jn7sh7zaFa6'
    'zAl2BAHFoYeLQZA2sascwY+L8cwYOumUhq3iSIQg1pb5llZSxTlDTS/lWns9v0YQUzWOITUn1p1/3tiVJJoM3vLsA9zpHSBTZLpw'
    '1a23NjPid3445Bb0mhGvq9+oHFFoCa9RNtvu2pQf8Dal9qOqKT9aG79pbzzSKx20f/hxyzupEAiH2jHtAXIhyeY70CwHpSbxGSzn'
    '19V4adkxLZif0eAzpwKPBbawBB4KepOwlToyRgojpVp1dc0mVl/+3vfOShuWarRxjSN10saFrj5vwyG13Uvd9vjzjgrnGyuc8xxt'
    '/HD8eT0Z38Bn+Ud19mOH9MnbN79vqdzqfrSx7lrE8ubuDe6pArfbHZ+X93yu19rmERwyHMl+bN9xrHFPdfY21rNz36c7m7/d3fit'
    'OkmclYCEURSmFGo5tmz6JbHYkxAhfIfCQJ3KPRqfVVVX/uitafZme3mCp52E2kcz+d0+f3UuUw190jMvx7b1z6LrvUM42u5r6G52'
    'vdSLjdkogSmSdd7BxbSbfbdPXSW7Q22i+ZnjjyqPPdPwkphmbrByozX6eqlRa/L/jrJOcwZ62jiVG+BeLvXiMGjelrW5C8bPh487'
    'BUESePZZt6pU8U6Dxzobvv8dzX7xQn1TDC/pn3vH/o1V8ZtqtgW3X9lmmkMQ1buGGGAY01DiBMUmfHZmwBR5glKhOnezkCYAEpuh'
    'HW5b+/NyKZfZ6/HZajMzU3yk6Xp3w4hYw58g0t5ZxX01/MPizs93/z/i3mW9jSxJE9zHU7gYqoRDAsGLFEoleGtKokKqlESNSGVk'
    'NsUQHYCTRBK3dAd4SZL51WpWvZhvFjOzmNn0ohczD9D7fpR8krHfzM7N3QFSEVHVFZUi3P3cjx07djdke5tXH9ER7mqh3MCc8zsT'
    'Z/WNE4FuNwdEUOWIqLjEkI5OzKwIlHQZ4oT/jhEU++QZnysRWWqKWHHm4lwKXZhJldxeoNUzXhI561BallRmjYrY3Z0auzueOGgc'
    'NuvkEhzdiFPQ6mfUtzox3zCdMMR+b9JPvZDUQBoTvLMaN/vGynR7os9xMdj0hWfE3Yxl9jd/zUfD+sOlng3rq+KhZMB2lkbXZ+0j'
    '4oEsNXDU5yH32w2t4KGvVdN3G3QGrZmNX98g7tjaWPpfRAUkr6wROMGgOgY0IkaKNcbINcSX5pJieg3OF4+hLe+RKJ685lb91m6N'
    'IsofBSI3cyyqI8cX5/3pieVkY7ctbkUPfv5y8WUxOnxs/AL8qMn8bhFOEj5TwWtYcLyhJWMggxJYks2NNAE3S/klQZDmsUTJaKUZ'
    'vdnd228Z6+HzXsLgtifA/cpkoxuPOfkxXW9TpCPNEGOc04xKgjqkBIn2CCajJflD8LsUgaECtPdHJ7nJZ6mkONuPRqvN6OVpNhr0'
    'pjgNcCaL9q6IJB5E250ODDS3P76Vkk+a0UfI7iPw1f1RAqcPsXQGtxjFr3tZejy6tK4cwVhbdkwSA4BDQ6WcRFU8mIxKHEuBbBlE'
    'gIwumnsf377a+fQVL40ogep/7LEjxQMuS/inlp+OLtA+ho+PIDxooNKIqTjmD/tXY/HIuI66ad7JemP03opqutxmGxtRQvMfT1qE'
    '0gJPKxy3Wis6qCn2qR3iljg0vbx++27n697+7id20Qpho4XlUs8s/PyYcPx4kfVfJBnt/iuztuWIm85N+1xDPgDddvEGsjLCsrQK'
    'rAVmDOpCFdrXvvBYREp0DrYE9QCUDZZR1CA5tp1DmQsK0WZ8DiktNYCm4Cw0HMzJiJJzyA6Yek7uLIWehgNxIv0g46wNaQB4OWEr'
    'HdboYuXoq4R0m4TF6UVtjV+HFWr//Lf/aj7wrDfcRDUreU1CB9EUDQJgGoxogng4YPueWNZ8KzqgduAucqAW9cGCuA40bMNIw28L'
    'W2yWFeJjCwtb0dGX4cNr83wrmvO6Rq2TJTPN2lFgTpHo3NnXa8aebs36IhgZWURcI7UQ+Vg9HU5cXVWFOLn9vckog8cvtIyENGIH'
    '/iWV7rWF+Ybtu6Hwe1sP9Yg++BIJBxfXIRcf+0dGBF2Rk5jYySpo+KcMNeXFG1NN6vsBEKxoxb/B5UTG7f6oLTYXxYiSs8A5ka1L'
    'mnQZHM/ItYRWQac3u+7ky9gTaEo6Gp+xJNaoyncjHYkgY9mTCROy77F/h3oaSguF7ZmMeJklgpGs74qV39oWbG0YOr2gsccHQetx'
    '/bDhohaV8CZLbQsJZZJxLx4zVLRHrGa4vg1UpBOJhbFRBEqm0MzXbMohRppy4YHD4/R/dOjYQ0Vox5pJepA5hXdmk9Mcp3CYk5Fc'
    'R4OUbrEuzeEjgXytwSquNMv5OlB8soi7pFY1TaIV/rwoo13cpy3ChYGjQ9QDPUS3MtVS9Ci85Py+YjWseWuo9T2ZJYsw6LK+4NXf'
    'IQo+i3UBPE4dST2SyTRn+vzp8pP6t7RhmGx8ZKGiKiypAUNumFTnZ9ClMC6bJG27XX91yX6aWIvYeLsr5XUNV/ZR1rI7d+s59mTN'
    '0RlQ01+bXKheGql+QBkzTbX6sATjX9V4bwckF41MTUgTjG+YqgctgGQyCkgUM72cnUcSAocLk2bYMzLrGws4GAKimxiSarF3RWcw'
    'f4Vsod6M3h4H7WvD4gYphWEROEHwRR5PDCZCSBZ2+mEROGcI+s5KeQdEaVFTyOspSTMakiGHGstBayIZvdjeYeOOkx4HN6GZ4ooT'
    '78ARQq8qVapLIvwMNcRO50RnIjkthiSHqH1FRYGaVMCS9o8bUWbcEJOhARDLmNmITkm76bNbaPeMaCp1b2c3JaFFEQ9/yEvDCnXX'
    'HesmjAmlqMqppx+xAza/Er34JAvihV6GDQPc/itc23nO2+OxEkS2HKAMjOveaJoR2V9bIsy0xF+3+Nxu4LJOh0hn9/nT25e0GTQM'
    'wvPuZAsoc5UmfWNQ3bBZMBjEg8HWGflJRxIdIzgs14wKVPB1wswoNcguXklEwNqZjrf8q9I/5ZbdNMtFR6bQt5MXuiU1kcRk2qIb'
    'ii1xQzt1TiQ0bNzrBcpqYTZy5i1V7v2CBf/IyF1E1YBNg00I92XwZIxAmV/BKLwIQbA9aC6E43qBHGcVGayU/M9GbbYq4dvH7Akv'
    'LcZqYLgNYw3lxHhgW+wICowGrDAY4WpnjYYdrGbtLUC/iBblksE+xP4tU1uqNTi/DWEGjkS4SGuVpTVOyz46c54ad6x67ZM5w9Qz'
    'nPZ9Z4Y5SdWi6Lg/zU89lZof3NHiUsucyYE0329Dk6+AOuFl9hy/bwvUS/i9lF0Octx0fxQLaebTARf2YpFvSkn9lIldp4xNClw0'
    'uZnYUiYsWTTfPJg2tKW2KCSmT1v6QZ73mEuoKdf7QYwXyqkFWWXD4xZJPV7cwwnQpc0zdDY4W0O/1m14DEevONSRS4ifa6ZxWx6Z'
    'Dfu7VlQg0JjAMDPPdNJZE3WdEqA0ZylodQ1GSvVG98kkGZA11k30Cvip+BD4pm4T8nmRbZjvdPn5MC3NbsjCAjE40sssEgWIl97C'
    '6M1mbAqr1L55W5QGnZ4QZziRNFmGx6DtWfqiQgAX/ccyVVuuZIulTzEzVkZqEHJU1w5ZBL47s3Z7Mcl5w+3A5uy17yuTNUVk3jex'
    'jmdAQcX265dbxQB3bOUcpZQKcIJJV8OPPJWFO7E38Q8sv/XWAawHkem+tOe2bocTDpu3PpPZq1i8PcomTGvW6oGhwS3z4MoKeoil'
    '4foOUEr4VtanIOIh1t381lV2cNaa8w1QFO3rMSDuIWHTODoXfFOqlBGx5Fmwl0ajbIY8UeC/JHgSGqB0iESnbOmKEuDOAVlUrWnK'
    'qRAG0aWOiKBQQnaUoLFq634BxFlR4a6GzSqJCmcfxIPTQzuvchPxtQG7306sSDwkM1AqX/ROsr2c3dLJwPTPKaw5GQjrQi8ASk/D'
    '283e5L/qQIA6YZlm3ckqKuFGg5Sx1Kg46mM7xmN3x9jafnkBj3sIgpTN77KtPdzes/CKVbN8z9B9YrjISMorov8TsUpIDocKiCvO'
    '4q0/7Xzae7v7Yc1vatCjEU7EYL7qsvP1zBZ0mVfDWSBe7UN6kWZYJl5r3WnCEPuesJDZQva5Z1UXc+k01HMZJDi+8IxDYJ8mhAim'
    'YxqXH5awph20ooV92ONoxBLQ5kmUByC7EGitZ16UAT1ZCGoApvij5F/ySkhWRvidi+CJV05Vhaq0EsfBKr/BOb6CEl51u9830rwg'
    'pqlaTJSligHJR0xE+mY0SP0sHwIXW9HRrnAH6hHV0NXtmhgxCkBmV2JWfBhBFKwOhGFmT0E2hKyzmFdbNVoxPkne+apw3GF5tQsf'
    '6QdVVNM+G07RvTLZf2u1NeM+4kcRjIz3jIotuvA6Ya2QZahC5O+z03r/vYVFAvUTFxlf8Jj3YnkbyPQOBkH4M4m9aQUpakEWSKFS'
    'T7yDO03UR1VuPnSJEv52yybGlkhr2OPbFfpsO9Zgdkw484CQc0y225Nh1GB/SUQsM3XfhZficYhtAtH5SUl0Xq+vOdceT4R93DQP'
    'a76oW15/YKGxUQcdN/nXWpFXUzNONv9V3o6431MbLex7AMNG3Hxcf7gkWaXKcPDgwcAaeBrURliKpnNlVCZ7EyBDQc6IImU7w0kb'
    'GrvvqEAiLOKrx8h005KsZXCwcgiqVoJqcvzMe5AQjSiItVkKpgmFw0yQEfZ+ytRRCDay2MqmCdVfZf1QYcsgdnSt6OOHH8ViQcQf'
    'EM+b+JCh3YKGfuqP2vujF4TSnz2FIws9Gln8R+hwCbQyaDc3A2oMn7F1n1iEzew+PJqE2JNjR7Vo7ehfGrKxBGjUEA2NSyMk6XYO'
    'Jy5PZXErmm7R6w51Shr9CgksWCHNNKron61i20lcWVBy0WNFsCGum1XM2w437qlgEKRo2J1Djd7JRsl4Qy6q5bVtOCqp56+8LMAd'
    'rJVyUDtmVQImKjAfn8dRLU2HQHB0i9AFxj73NzJupjfrhuv0AZrdd9G+E1ABtrKUr/4CE0DXUjpMJB4qFdY1gaHnnYR1lV7Mk5YE'
    'E1eyLsgyVaITx8MTViiNxpO8pAUai8ofFyKV41xqdHPwZcYicEaEqNmUBxgaSp0NiZQKez2ThS0S9tBj8KEBnI7ZjYwOfawSZG6q'
    'IB0rZ7sc8zmCD9NPxtukk/b6micSXx9Fq3Xxf/K/nnpfi8Gujtbz85PoctAf5hsLp5PJuLW0dHFx0bx40hxlJ0vQ7y1RiYVIM8g9'
    'vP7pdkHTq+PpDT3BReXF6BKPkoiVOruN8HDlHn7CP1R6E6EQsAa362gY6eVstKHBiSIR8SMVocngpClDrfExEbdUqvmYBr1GpAld'
    'c5ON6eR48XljhticqnsyOzQo+N6X5AWYTaIjuHgAoBLq5kreS46TrEfTgtuYjURsgtIy//unH50AVzQ63KHvuJbTvWwhSR4Ikh6z'
    'FBZPDuY6c/S+hAjOk1yNsZq8RZwM9JG0TwehKVvF7m7mrR1EZ3LJDv9EGLCkl5ij2mrXy80YC6AjaLbJZ7Flj4Z7C9JKIhCKz8rk'
    'EoQC0R1XPEdNTTiRvITtkzVbguPGEzzT/+vwG3bIRjlJRbtZIhGyY9o8Ll1dwYnoStvZaU5GfOhpM9W1eaxRyEv4wbM9d+48s9gR'
    '79IQSDLYBQIbJ4xDZ9TzWAKTl7qEBvSeHbpLRyE3Oe+dJMhHbj0wVCp9gFV4aT3LQfpd+5NvubHSHXMY5qIAwaCB9ZDsw7RSC3jO'
    'ay9hiIayhjw1OU96fUb2LEiFZBVSIr7Aqd2ac3uFzu7idNR3mrvYBpfTcDR8tjgDC9LCQzXChiUN4wua860zFImVRvVtcGxzdEA3'
    'QeeML36moldWo1GN3zWhgqOlZGNKDSAk8X/RhbZtw6fAHE1tGmxOW+f4Fw+doWNozlcZ+NiH0yaQ3lYkmVLYPuaAN+iQTWTMb5gs'
    'TghsmA7aDcOisF8s62ZlWaA+sitHx9OuUzPakyCvLUln6cV/9KZsQqmXmsmnbbvi8elqvRm9duFnckQv19g9oCI00LlZ5DZWXKKc'
    'I2JoblTAprJm9SRA602a0YJEvF3AuJDMkvAtPJ+5DXZ8hhJP9mTRp2TZevAn1q27hlmF2Wcbe8CJqN4vErgXUyuwTWaVMJvpt1M4'
    'gudGYe/y6DFBlOPAcfB3BqV4O/rn//q/Ry9a3AmNXqKQbK9F+PC/4YO8eVFn/9VT6c2EcMQbGdJwpONwH1jfT7C+MBktSG+sk13A'
    'zwXHD4r6zzMCxjz3OGpcPzAd4uaJE2vKL4LTd28/7Hx9tfN6+/O7/T12LZBvBvVrFfbhGXatRA6BmZqSwRRB+wisae1rh4cV1Vj9'
    'G1ZEBVN9dkUswF0dNqLZzX1jxd6Q692Gqyjy/tx6wmujs0O895PJexOn3d8GE0kuPqBzccg8EGcK5PSDYiwdHxCDIp8OMLLDuqh0'
    '9aO8YpsWi4fiD/FII+xMrWU1bPL66heCyDnxw2t9vK2rgV+9Kr77C5ysPLDaHHgG3Y1oQMwaMtgPAvNrOP0/sBblDRaH5RxNoe8C'
    '6PVyYAkEt51O/JDkSdSZ5vDDZwGwQbwWjTlyfJqDpInBhUgcXeS5I4qkruHhTTBpv4BEzMVvWge3ZkN25ZBo0xqKV8v4O45XGo8N'
    'wZubzSb3F0T8N8HjNyKOjN8nvIogGgkScVvHcC+ERgciUy/APagkHnet30NMGfCG2ojgvhY3RhvKb1kepH3GnabtEvEGtVsVlVvK'
    'jbfM8KnSFS8s9TaAoK4cU/vMH+PAhFJzI4W85AwDNSNcDoYl8fk9N44gRGA4AhHXXOs+eZ4LFaG+Bxw+LneGCm40g9JojMnBrFkV'
    'ZrRanNJK9ZRWHfPsSagZ3m3EXn+ep6U51na9lCDQqJaH7Q36mG2q0HwBUI4toHCY9OphH/OwV7ydcPiLDoxarW2bqFy5unTTdfOe'
    'GDNw2xJiLpejI8IiQT0SxZyu/s98VVmiQRKzOIpMzjO6yQeEDqioadqWWTMcU6IDJ6JCP2nUMsnGrTkZOJSA5EHwQt1g4Psj03Z8'
    'Ohnwmsu4rX2WHRZdLt9//32NQLPI9XOwYeE9X+2+/wimkthwEaIi3M8em07GR+uwnCQWNk+GRJ7/XR3H0W+d+Fn+eNSQ4JxLeEs0'
    'H146zPHi3e7LP1JPSz/HH2/erN68eXLz+d3N7rubd29v+Nv/8nl3f+fm46edm/3tF+/o3zc7269u9l/svvrLzf7r3d39m/1P9PJm'
    '/9XNm0/1h0uu6TTvvJc8uXBG5iUATUl75ijS+ODLl6NHXw++HK5v3hzWmTD98uXhiu/Pc5ElEFDEyFLuoTPOycytAvGbkEgumJ8f'
    'WIcutAQBSAgO21BnTqzYNyZyuE6jyL/sHT7aqvOjCoAtkCYISYL/9br6q20NfEwCCpZcbpgY72aMACO5aGq1tUokHIR3NqFY8XLf'
    '5PxEAJzm/s6f979+2H21Y33PXURKImyuIjHkugJlzFZnu20C5h6RlGJnmaepl+uWlX00rMcmut6fQD+U3X4i6x21FH85+HJw8DP9'
    'e/hlePiY/qXdUnIBcRN4Y3rRv0Srusm8+/GkbnyWahYbRoXYR8bpvDT7B2b2O++IYf9gFqBY2/E9HeTgFuv63nCYOhNE2R9quwOP'
    'hg+85r4Mc6L+n+y2qQ97+592wRualQIYxrVHj2raeFyvB7F1vXbe+u3svC+1cY8m9gpDefvHHf/Nq513xVb/8Y97NPuSVrDmbKog'
    'dZJ1c8Z1a6ZZc2S5UIv/NJXzzePaUY0FrkdHLOfkMuAWj46YUTzyXx7V1uwWFwe0XXPAb1OgitMAy4G2J3Su29NJSrcYvYYnjfHC'
    '0bl6TGwA2Wb4sZTndNttDjG6IT1swcVOyFGQpngndCn7EtjmoCs+OtCSHPeDIZsL3R5qRc+ZLq5/yQ9xfMqSvzq1X4T5Euy892DO'
    'zKF2oHI9ZsOPHhyg3+L65Fmn5vdQbPnFp4qGv0jk6iiiH6WKhB4/3+x9fkH/+3jzfvvTHwk1itwd4TQLTel2YHzrD68nob/gLd1R'
    'WoDupYrP4ai1aa3hR6bw6YYABUtWkCh2NGu9GBPJpEOSMOSCncFGrJRQc5/DD6d9wRcZYtn4GLrfM4hGfOLfva3NQkuQLTMiosZM'
    'Hd6N3Xc1gcDe48e3TWaHFpHoetqOTCIgPlA2n5W0ZBiex+yj4vck+d4RW5GG5/DcoeF8OhxmtPJ28fErW/fRvoMIsNttEWvdoRYh'
    'fpgYxCx4xLciTE8zCNcV6dK46qVsSl+GctUPxcCrXecgqSVquSMJn7xtMGA5a3j+sAASiHGI9quASIr6mbsCiGLrWt65IiCx2ETW'
    'mrY1CJ0E64vaJKvVD/lunLCwFwUnmZ3FoeXOJ13XtAamTPuC23jtJl3/xrqXIM+q5fhc1k2D+OORXT/f0F1OV/iXG27i4cqXLze1'
    'op3VASoxxyn5eWxseiL148c0thD/dEZ9cWMEklypI1JvnfnuPm5/PXO3fk7oB1jIYo4RQymZG6qf+2HxaTBcCYvLa5vZCOdGIWWX'
    'PPPGzu0sutLFcVlq0o4j7IaajjNDy0Q3tOb1AuT4WMaMonbDt2O5Mh/tm1pAZh7wlqNb8MMNU9mN3wx6cRH+2OXWeLo8bHEZX9FU'
    'fdRsIUNdAOcsyDR5u4qgbsUkFmP22STZvVMWsa+CkbqvhJ84UOZqFlDlXqo7gQnUK17LJq5/FbnsH4lZhHMl6ciMAjM1ZbRxLb1r'
    '+hKobA06tzc1TzGuzyU7J76fYRXVWXFS9Xr+6NFllxoK1qzUpbdSl/XZ1NSbVZ9IfPOkgrjymrZfil2YK/0SxJBhVvmyMk+E6F0n'
    'oCO+N7GvH15fsvfu0aNH+PnokUPss0bt+MyaNwgBS9oLC7mcp9DPWWgTUdoRS24/DGVTzkXfP6YzyWJib++giv2r66Ek+1srL5iS'
    'ykQVH8nVZkjgL0N6VZuzc5/f+Tu3+85fCXOP1ebM4M2nWsUG1pwtDS8KY45ZTTB/77ci7iWdQqf2M7IsmD0KrtfgoFQQbPpKK3Nw'
    'dkOkvBiNkGor3HPnzytUxjul49QslrArHzcOjFwJHhA/jzlsA2LU90PMXZQ+x8eDIAa9jwFZzDbQ9Rp07fHy0FSbBXyhILtesMoR'
    'AddG1GaEtSUZKDiLUEGAJAWaGur9OnISqTYHyJaB9Hs1F4Hf/3C6KmeThUwtI2wqYDCTLbYtqgOXHfLo0TujBms9YvMJKeDFIBEp'
    'vo/M/O5FvOoBVO17vtHaaqtWq4DFYPhBXfT4/Tc2sFrRwvwmXOnIkd40c8g4+Z5d9KqHOWCwjKI/w27mvYlLQdfLnGRylNmMyp6R'
    'Ri8zYsd8ZASNHAVadJBhXhsmcyoGGHAFxcXo94I4UrmPLvhs6NTko6b8kdQoblEEq3nHMDYZsBPOt4sCihwDTFfdLz9r8arutG2v'
    'uZIg/xtPXtXSKbO1tRUt1+8NyhZ+NmxLNtyufNOD1IieLYM2nQloweIX4EqG4Z/L8q5Fsq5yTrWR4kFFuXqt0KyHe7xWS3s7Bx15'
    'MnjOiVleMaAfoB471pq/FGVlgIeZ/Rv3+knjVhlG/qTh7wXeVIGwx/Gp1IY0yaM3++/fNRg+TDpAMTrHuWMyjbMD/jganRCX92rU'
    'QdCgn0aZn7RUW0NLsXOugBxdM4mzZeFGtLji2TD1hYiltpkQ1uy/XBJmuDiD3MJjamJ9qd/bXF+a9jdrErpycZENlwsR7+dB9rwb'
    'BSE1fb2Av391D3XfdRGsjzfXe5vuNlhf6m3ShZDmnbgMaxDwjDf9m8E7TA8cJgrJ6OSEs4Ax1FDN0xVEnmhFohM7XcUvIjRvD6Sd'
    'QxcbFS6tHOvNLCpLn5ITSJxkgHyiROokr3nERMHyOtwerRVEN7feoAWtbvLe1Au7uR7Ze8HfUtrMddpV3dDHj00sPYsJZcym7loR'
    'GqSu1DCfvIkYDA3lutnlo/Vu73zTTGh9CU9eBB02W7ML5c4bWsfhgYk2IN8aZydRszvqXIodzt8l9fif378TD7tm9GJKxBqCI8Bv'
    'BImtkSGkQbcdwjQgtykso+Qag+UpZiKZlIYwt2lnCTzcxQuebWfQdyM4ifF0zFbadIheZb1z+E5QT++obrp7fEy8bdOZhr/89PIr'
    'k66gCON62RoKSrTPdNifrAorvfrDM5drEwd6KNkOsaP0jX48fswMockTsuaKnknRMyr6nP6gIKdojX7H8d+WL3devXj+/MnqcvQz'
    'Hd5oc5NzWrci/bkWTQ6GnDCTn5cDN15oQuuxjTzTyTpPVnEcrybGst2MaPnytf7fmo8mLjln2tXEJBOxK3NAQ/k5Ig7vdzTBHw7d'
    '2J47v2cu4hqu2wF6FDKBApvnqaclW2J7i50OO7rcMG/YYfF3JobC2cQkg+eg/Ulfnzhyvag5JYSw27meRDMaXUDM9GY0zWARsr4e'
    'raxEN+b1ezq1EimbPvzg3u9J+JIYs4hWgqw0HMhHi70miusvaQKp9WK08ofny9zOH6gdU+I9YYZTvmlWin24AbOWj5M1MHR8V6E7'
    'x4IVMLa4sNCaNUVREKsTYMN41mF5Ubcpz2LDBLUvbtWgnjjptbRoA6ADGAMAOb88q11Jxf0BgXgbRKae1H0ZpGZJcZuScER/PPDp'
    'eTFFFBWu7PjCc3ijyRGDbJDa9BKZeUzguSLY4NZBOCoaUvwEZrSXy0+Xnzxt/2Aosb5peeVZ/BThnUzDwZdnXPP5cvXX52wz4Y3H'
    '/7iCTz0W3ZRrrqzyZlR8pImuPOWFrm4Z35/LTlo6sKKN1dU7ytAgVp+Jj0GhjGZYoIOltLRxDylteMes8FNZp9XlFW+FOzNXuBOu'
    '8Iwvz0tr3yksb7j4ncL6BosffHxaWPyOv7jPyovvf8dgqxY2KPP0jjJY/OezF99v6ynNRFBAWESQnUoVPV+RyCAMutyfLKujiNPt'
    'eMOyF7iY6WvCCG2X7t0pUcgxGDDJoQhpcxN3wDsdsMn0Mfc4r66alGPBQaaNfbb8A4DFLk4abr1QBIUFTAsAUFWo0BkgQRBSsQ3d'
    '7NLieob1Eo0NqUhxHFgKrgtEU7dR2VjwYQRJl4P+To6DwTdr7qlvf7e+ucDq245G7ar9DpHOfpcMxmugb9f5qT/hh01+OJGHBX74'
    '23REj0Spdjg2YsGuHmQVDxd+zB9Fp+tfoT99/bAH3kI9X/LOaTpI8iYoSRqyMDA5e8JcENE0zkaIVEpXwqAP15hnS5xP2N13n+7d'
    '3IjJqlfq1yGNZWmffRdzpGvyWs2mQ2PWc7R+0co26R9e0hYHz95YABGI0D1wrpGVjpkCp2Kb+DfzvWxo0xK+j+Cd0UACGrFv3OCI'
    'jNrHGH2MP2YwdWIvji15LS4dF63zpA93H/52u7Ck1C/R+NwWdy21aexmLGN/FIO020t8g9BrRadZTx3ivFMI/w9a9E+8DrHcuSwN'
    'kPxSJcUzinEHnvaWW8Yks7fdt4MTdhaziS2P2M4eWSabPIVbVY9LI2phWhpfKHG1W6OjpZ/jlhoqdXv5ZH9jYXmBf72wv97ZX5/w'
    'a/NI7+/HaG3copFAUtJh16rO5e0CTZZ/XmHNUYLg+2MW9bp4O6TvGOPGggI6p83Ugp0P5z9myfi01+FkPrQ360nrxHvzjpVSw9FL'
    'dvbezsdpZ7KxsILqS5X1/bHaprxWgfyiadazbmVzToMumTlVanyxsLlOv1pjNIsfw3OaGEaOBxqQznzZTNtkDl1yJVAeM/Cr+wPH'
    '+zZS+vX6fYwdv6OsxUG90SDtNreXtIgUREAt/DSeS2jY+7AUNFbsJR/Lml8eZwP8JQQQXfLgr/Av9wEpyazNXnJVx1k++TEdDSL8'
    '2FjIaCgLeJ+cv8t1UKaIjko6XzKr6Y9tKdiwTe9ZNl4gmNGIBWyHUjy1pm5a5Qml6/JjVoVc6F8PWbhzXnHIyzik/eypMmvizLjJ'
    'bOdzvmjZuj9OJoT6kVI+9DTWywaKwiR7STT99iRernvM0HFvsjOYYioXjeiUs6j9xP++qXuc4SXbyONL58rozLPRdNiN8TZ6FCFN'
    '24XKWqnIprZwLVW98h0k+8JHqkBTXZMG8QLSDGseINn0VFkb2vDCGoWRWIOjxgzF8NZmxs3VitdKwicjUZxPxxrNHu4+LBDnnOfG'
    'zB2ts+cd1qJdQrTisWmEYPTk2RrQ0wwbAy8toCw03PqatNL4Q6u98nz1ORO4K09+v/LMRWdIkBaK6q/2hsR7rzR/6A39sYhYeaNC'
    'VQOg68H5p9VPj9ltFSq+t1zBCobcNRagdQXr2ABbrA6p9YZxTQ2ypno+quzrB4EsfqDhv45TOAGaI4FR4QLnaIUt9hMlhLsKXGDt'
    'e46KxgMgQ1hoiK2QhYfNnUoav8ULTXRXVMFL7mXOsNYVhwx1QlPTqsAA7K1Zc5Hb0ZCePFsmUHayefVqeK4s/WMUMNkeYRKsfagu'
    'hkuzjGo4JRQM5rtJV4Xtk81y4fz8h+XVZ2bcF0QtRe10coGAittPMc6T3jD/DmdEYiGouBbuWix3M7EOipJYSEjUV+DDdOBM11yp'
    'T0xDiMGkF/vAUhaQ2XKk7UCky2oi6cUQE0xGcDu3TiaUIQSNt9lEbO/KcEqWHtzjKrXsjddwMME7UTJ0XSe2DyjRIPRL2UVP87op'
    'AEic1hESsaPKJGduYU2Wj5PUTpIzKv/xw49L//px50e2gaaRUVMThP6XRPQQwDpsgh6I8sqVOYI9Vr0q1Sz7D/lpZh8MjQg9FBx7'
    'FQ8auAIOUT0UwZuqYoAOa7GldWAtKr2xEB/8vHD4uL6wdFIPLVvMUBGyhN3HZ5kb9gYFj3V6o+7q9K8pKwFajPu58z73/GjL5i84'
    'D2LdsvSzwypfgFbUDA8D8/BLWIyQzVaxICMgzftoxV7eOHmxWehdtGK5lxO654JOsxwmBElJn3OyBo7o7pvkWvXs1Eue6IHrt3h+'
    'IweajBw+3SZUiO/TvabrxgtTNIaxW0vsLRYG7Coj9palJ0SGp9THRas4GVaUFCdhuQGjY6PTBX6FWMYxnYmepI4Xr81MtdRymoQs'
    '5pybvQzuLZbt+8jBwULvhkvPt4GtI5od9mq7FI0GEWavR3BVpQsl7/SI+KblzEf9JF+gV6fbw7zwqpN7z0ubQcttr9l24VvP+9Yr'
    'fMu9b5CgnqWFAsCEXpnOqI8sv8JULv/w7MnLleJQcPd4NU5pyfu87FrrKu33RxfFWlPOPlDsbmoqgZHvp8VKsAjmavl0rLVwUwOz'
    'bVOfQ8f9Slk6V/RHIvHxNU/10kyfmagI6IlLpUcypngvmarFb0d6GOTcmVy2PN80kC6GyAEk4dprGGcwzvIiNtl64zrTFbjev1Hn'
    '7tWlJxEz7TkDaehJ9edBX12oqOt6wQL3390/6t/VQ8oTpeSikOjiRB43JK5JvWgWHDoR3elGdD9HIs/FwTdmnO8QtObVckacBipZ'
    'xPIxi49peX+ZUGiWj5DDmL/UT2iGyeaZ5N30rTRDy8j7OAdhH2O0BPTdbDZpI9vGMMLsqWv13v5CFc327t/s57kNTe/f0Lc4I1X0'
    'lH9DT5/DZf78cW7LBwU/ksP79wR3lrltA8Xfvzl1rJrdHK7F+zfn++rUjCCvzaIjPNRm19yuBQfylA5IhgsnyloillO2Ia52r6pz'
    'RKSK8UvOyXD8fHptD/75rfZqKmMcoVcNCYTMtJVeTSWs0xvYWXpCGiKCmGACK9xkagljNyy9cPRg6C03iJfEHv7hh9UfdE709OzJ'
    'D0RsPXn2w+/B69erEJDvpOSt1XFxY29D/acawRY0oB/ZbR+uTkWxFMujjKi7JJ+yMm6u64ujqnyiuum4cK8oizMdvO3O9E9yHB8z'
    '6Cu0gv3zvp9b/jnfztb+ULpZu9/VNcfN6hscrf5nOUBZT8OPMcMAO6pf0+FQqcCiJ5KIsWwwAyxrLRBvkQiYhKWcLB1v0Z585BPP'
    'i23pOzzd2hJvu+4LP4pY1tQ+8sb56zyqdJbGCp13OLA0vReUG28qBkbQjhWweC+/qpDhhccRlFHsSGW9hFa8M36Xo1KDDny9YBNd'
    '9Dpaca41c7y6jDaWwGAiJulDeLdRV/EECWuW6xX92NB5x/3RKItjBzy8Rks8Fo7Yk0l0ZlwH/5IXeAZ6zP++sfCUfwi9tczsFFiZ'
    'jYUXr/Gf4yysQJUb5TWvTUZjaDHRLf62R5PJCGG7axlna+XINLBWfuN+/qkmXm7sNSRtWZqx9i8IK5FW+H87pIDDMGn3N+WPgDz9'
    '+IkGfsGqBizPI16BW8wGctSNhe5lwiJJZkC2TCNvWZ7K1fChVF6x5ZE9FI9NzReyCNSiLocQpe6DFHuXXGHUptXj3mXalcNIH18S'
    'v/c+4QnwsHgkz5eLg8BNrmxi9felsLUlszAVw/4x63VpzHg6oZ8vR31/2ZjRM5bJDEJmVlzvqAIbE1QTbgCQV7hkpxogvykR9hhr'
    'BvcFcz1Mu5XOBQv0YlVxFCr5DAUAY5qzcBHx9GgR8uDmCEfLiZ68fqrIi6F/U7mDqM6A6MtYniO163I9amdpcuYTGzyexzACLHNL'
    'p4x4SjMKSvIklBabdBhaOgronSKcDyuAfKiZZc027wHfObwf6LrZWJeFHKf2buhAYuphAkQLxyN0hhsLr1fxH/CCtMEg0gngTWBO'
    'r7jAHxVhQqnDa8fpUCO4/8x0YFT3DPYntSrNAvQKYpkuvfpE7W2442uyDeu8cfLAlpf3XtzbyoOmZcfm0SdgPRJ6AsKLD4Cs7iSz'
    'mOoNBxbW+nhdM3vBY5P19Bjb8k1p509osMYLzW4qsxes4mq1DpyxhJuCCUpacb0yZtpgcs06mHNZ2qwnz5YNBbwRBXdQ4cZIcAdJ'
    'LVmO8Yuuj/cqbqWVVe9aeu4B4/Yz/Kfbwe3UAociq0hjjY7F9gXVGWP7UFdWsC3RYCCb+mOLVlnpbUyH/VnqQW2fbm2UPF5n+bya'
    'gAjUqRwXrtiwq3XtmHc9KcItVLu+foPz62/g/lrgr+4kkqktX1Jkgu+ETrT3FOcUHGsr5TSVIhlPOOAWvROgqLvXfibPOteZ1gGn'
    'xJmp6BrnzPOeveaO54mFlLVFi3ZehUYs4Jb5CBWpPry2F96TRjCXrWiVRvCEw/Kh2fy0d8za2eU6K5tZyXt7VGd3HVpNGchM9neO'
    'Ay8GblxDzRb4DMNMB9yZy3uXL27J7xP2sBKUKO4poirKUGzOX19weR0Iau4lxewXpJhVEY88XjHAPL/0thacdZ+9qXYs9hm65Xln'
    'wJNDuavJoHzhEaqR/jMP569UsSIezi/OZo5nMgaifsnKRq5VSmUK4FfiVQs4ZwbrWvZUNst1G6iR891jYwPxoOiCxf5vBRuQ7yTH'
    'jdVyFB3rrI6lbBZiVSyeu6EXfPF53Ve1cMA5AuPvJIzRnf0tN7xofq4ZHAbY8RC+qHIwXolc3EDPgCFYk4JLGS9KYHtVRfE8F9uT'
    'X21A40Rm3zkWirtUUq7HrFmg9/vhD/hP4dRQfNWYwDnGRQEimNHZL+3GIpxqnzvXsScJBCGjyaWFuvkmr0LcwGzgE7frJVe+wC/W'
    'YG7uy1zHtX2Nrxk6tJZMn60P9Xb/Arl8ER8ZTLIz/oDfHd0hSPKLfKYc/PiCg9NwBHk2HztGkgs2uOFkNF78ezXAaRboi/HwxPMO'
    'EzO9MJ+YCUd+LQkRWgA/kYV4IehbJqwjD6VFlyxSmSaedX29RNp0Sw421FWzzcWNdRkCnkvu7eh01O/mahB1SScdti+2Rbvkahg2'
    'hpN5TeK7O/F39xxCMGtQDy8j/80q2LQffv9k5QcY7D97ugyPjlmc2+rTZZFl/LVjLy5Y8WUeg+IwrRmfZ7wHy73HBknIg2JRC2jR'
    'TKfMSd01GQQL4CAPADulhFYY8ipDIgTlVrmczQsm3wKpbI3N0o9mS2aLuBh4uEpSu1Ipov0lK+QZo6sZDMvTtghFmARc1F1zeUHC'
    '0NE0NxY+779eJPYLmde6SX80TGGnkC9sbX4HK3HTDOfeENYZ3gjEOsubDG8++W8uxr/Aljr0W3glH02LyS9oEC4Ppj6dgV9l3g2S'
    'hu0F8Ae0H+LGq5TgZO/vIlJYWfnDMlM3p/T72fMnz2WjxyfvE6D1yYiWZeXpUxbuZZKXxDwKweSe5fYyT3LaNxZ+v8xM8jGRG97j'
    'yXRixQCAITO0JR00W0TrJvpWyccjSZhcZYuTwB2355viuDdpkk+2814SvGTzHH1UabLK4cWI49fBoDZSgsBNgU/NLJXrXaqPm9Z4'
    'BTPlTfu7OW+rq7I3+d9f5sV3/YRxGr9Lh4s/vvAv4aViD+Pi0yyCBbvaw7RWnz01D5+m/VSJeaV7tQ+/1aVwjnY9rORqbJVE9Kor'
    '5ZS25oJvuxsLHwDlfV4wdiXR+elrnvffXvNJUCBCxbv6sq3zfV5qXN5y2wj93d0dVnU7hA3c3OHMXla9cJZsCSWU3Eb/ULHR8s7b'
    '0W+brLlFSvM1iSlWfss5I0fiB1ghhQsgKdg2Fp6sMmQFRtlUUKm3d+4uql6odpm+XXn95DlB6FK4jk8q1vHJb7KOqzPXcfU/cB0J'
    '3y8U+IvKZVy57zKuvv7h6R+eFZdx9VkF3nn2Wyzjk5nL+OQ/cBlXnvnL+GzmMq7edxmfLuO/0jI+rVjGp79qGUNte3Et8TUqKOPn'
    'LOh9cJeZVUfMiKdJf0+KhDeBmYX5mftXOGcVYyXtP//tv4Lh++f/+d/4z//x/9Y8h4DjgURZqHXTTo8GyepcGEe9S0E62MdPo0Ey'
    '9Ctq+Xfi7bAReR5LcC0Cz96K/gCRZfzViNVADQsNDFKYzRPkombvk+AcMb37ejDxLFVppAeIFv7kUMlkamPfA89/oeYg0Lht2s//'
    'apkNUE0L/qKHogB1+eh5Hh6s/4EjIdMgT54tF+5har4otzMqk/+YJRF/k8qleHjN219arv8p62HdYH4lpefaqST2kjayu3cmH6aQ'
    'LnpPb9m/EkU4oQhDLGspDDK8Isq0+x7feOvUUACbyCISr6lAPjO3w5Vv7TA4T3P7HXJ/Q7+foPPitT706vteNRB597oGCINWCQq7'
    't7NbXuERfwN479KGZxCtVIO59zm4Sb2aPmjd2lm5dzq/mn4SQPGZjUzO5C8HwE++Z3sh2+QcvpEQ9xm8Osre8TR/v80IC5+97bKC'
    'Jl+I9vlGUvZ5KTdvOTH1xoI8w7EMa1XVDu1YsRG7MK6dwEeNt1X8xQEcA9nBUuNUpslOxYXm2X3FNc0NLaGwcWn291BDarmAm5Ud'
    '9Ss7suajrjOnWWlKlH3z6f2oSzV3LukyG/IdHAJSsKsBC9wT3vSAIUs855HNTvVJXzGi/BCrVjPJb385bHFjvxCmOjKgRVAwgCnl'
    'BiNMeSgDAewvRDpyWcpkPO73JM300vmwW+hlUXtoBgD7WKGtogd8md3B7HpjwGJQz/pAzagB/6/KKvyB6lhkQjTZ5AM71bMAacn6'
    'fs0fbMVqSKALW78YRqNpv0CuZFZp5ji8o/ubjkLavbP78MT/piOwTc8bBId7GI1zAtws/fYxGMhE7UXnmWZ6XOKjtHlE11B4cL/i'
    'ECwBoPPf4MD+R10GK0XUF8ZccfivDOEzroVV0+KvGe3SIJ0kWMOlwja4AZW3GbtTQLelXSrV+g32qjNuobWPdpBKP3bG37wIs6ct'
    'TXadKHk8zfoiOO4speJmmi+tNFeWXFm6kgZ5ZQX+Ykte5r0Zea1Xlv78/t0eD36xN8TkO5C1dTstVrI59Z/LT4dLz35HSfaEHWWb'
    'YbJzLmQ+retY5UXajWhExjROv/z05OWr/ddQOLrAfM3J6O3errrV1TXBAEIi/KF++5/RQdAoQUdppyogpAToFkKsNqKyisO6toJx'
    'IqwqHmBJW8OxIJWVBMf4gwvxDdOgXPOwoFeVDIEgmOoa+soL2GOaF4IKpg9CUplmB00vlo+aHxTCLtZ+oxtOAqtXJ5ve1Vjo98j/'
    'bGUPmqVepUDE3Jqc4aXI6SNNTuayqnpZq89BJfzn3jhMWB3FNqMZF6g3aVUg0cCfepDMAgl0bFcIuAWNnyh0bfgtDBQPH3sdL1m4'
    'MZOwMcX8kPA2kFgr8kPAw5iB3UcHGiWZ7Yr4DYdHNgHXvRlijEEyboABtdnAP7Oycf/mO+Lydgd7wwvm9PJwG0eGYkkbGaS4NklH'
    '82l23jtPbZjlUlxlOhoSWFma/CVpwq2223PVrdgoidTs7ZRXHBGqC83IBlVtOAf3L7VjN9Q05LKU2zzlLyVHOXKMY0HSmcthTXn9'
    'cOZ3rg4njvXBsti/wsnsXOkmiPovzpiuvZus6RZKAbPa++6YCYMghe88eGzwySydWwzXO6mfRhdU4bTX7XLUbfMFPt3+e+QAvjRV'
    'GVkUS6CXBwEiMsXbL91RK9bYKNTwps7Rld+nw6nOuHgbWGRc9mlq0vtprV4nzG97g71VlbHOnGYOkqyXLJ4m+Xg0no4P0WAbISU8'
    'tycuQeidzm7aBepkuxW5BeiYY/g5QjqfuITe4qySdk9SdrbQNAWTyWi4Fl2cphI/YjIa9WHNiDSEeRQnBLycPPuiNyR8WIebQDIh'
    'cBuiF86fTCQdAjpybbbrlsajnMiHdMixW4jA6HKq8zbRbHKGznvphRecHSqK3eEeV4mxiLL0+CXsU5ONdHArWusnFR9xOD4qRsTt'
    'C8S7IqxF4E8LiyhqnGCaLYao2HNPw83mshucQop+rJtCW+bHovlExEFTVk4tzjlMB323NareLtpaLQkiDLTMndZnTeqIH4gKT/8c'
    'P7zmsrfjS2QApCuk290550j+hISQRq+WpbAboo039urfCqUtwgzxgUDpYR0gFu4BEIKfUGUyOiGkx8eiPRnazKVskkUvEV4cv5Wi'
    'VmBjtYmG/wKgeREah4iARi01ocjScC97vXZf0moQESRyaV4sGeWaiXwuZ3PNwIfDFVrNrLc+Yqw55lTjeTOZhnoct6gMeBIkByOb'
    'f+KUfDad8Mmzi17esPGoB6sqJio4iOum5tF4AN8rsGZNnlw+2WrqFi3iEGJn/Fnzrnynsafk/9TCbomozuwsGiBql/fRxlbff7Pz'
    'fufr3v7uJ0RXr+XMVix2ha1osVFczdtwmv0+3iEjbEZ/QWArOpPDSZQrF8BLLLmdvPmhu8pEMLXWnPilMXXTbF2DGPVHnaS/R2AK'
    'OQLVYHLBGzYbH7rb7tbgeR4GYXg+iSAb4CZCkzYmx1iXmsRSEYpuMBpp6rSgPvNeehmdjgZp8X2xub2LHgbC4e6wA1h6bt99sFti'
    'byW/YX/A1TOxOddRbaevwA5SG8H33tDLuG5jrBETNKSrPidkgIg1gtDRIrMfw67k37z9jsNVvQfTEtficZYeE+++yCrcRWa4iUbC'
    'uAkrVAByh2N4WhhWu1RQxPDsQfSnNd1O8y7Y1pPythb3lOfLlesOCtOmCem2ZXbAM+Hk288shDf7/IqGPYimQ2K28uhqNK2dcyA6'
    'mPjSxfVdxWFCNWRMYSTRklYYe6acI/yMk/7wZYdCfVXYT0ZhSTH/K5xDe7ZQVeQxHgtAdWF8TMSMpH/63e9wpMQ8+EA/Hlom6zo6'
    'oyuZl2B4huwl7b+2KsrDxVuMkFrRu7cfdr6+2nm9/fnd/h6X8+PBcaRLTqlru/+AMfnMK+e1etDLP43o8sjr7Iqjw5gQBkVmena4'
    'yHU8eZMX6eaGnXRmjQRV2ZOHgceGdWZb/32JtjVkRcQ//+3/fngt+dCYdB6y03dtOuQDioheVpTxZLl++89/+3+O1kKSFhvrkXbO'
    'MtrfEXNS3TvgAOeygqsG7ms1tFbjHOhn7NcmNu20HeoScMT7aaIHPry2M4o/xJMmrRAr6er1W2bBqr5PRnVJzHXEIElQ5peasOV/'
    'XQIKmxErfRyOd2LM9GtCCUSJgVDwFHyiK2G6N2FwJ66DCLdkeCUF6A2m2SwaoYNQnE968AixARHh9xPcbUWymNqoqCfkQ82atLeb'
    '3V4OlqbLm6Gmt3SDJnkOVNUUciWujXDbPqDtIsCVNT1AD+ZKgqTwENmi6JZS6Cx/r/POtu3Lc2u0a9b8BZFunVOfx6BbnGGCORM+'
    'G/4efUpzBqrSJEyBVzT5kM0JGmQg88u/Qz7ru4rfBpc7ACrG/BoRs213nQjGyhODfwRvDAY972vpGPhxFrkP/uYttS5vl2cbyfbw'
    'uzXho703NCIr7Qi47CBRKwe4kWPBqKcRSe2WVDauQPccEFrQ8dhqu+2/Elg2z9KrXJKx2lxeXre6fDoLOz37fc3mynKXcng5jASk'
    '4vvsShnWZu2Sd9h67HKfT9uooJgEJLFJK+eNtk4XAX1pzlhjWtRgnq7w2uxJwhFGQPDfBe68iZ5hngc1ZrjAKDM/ix/ssYkfTPnU'
    'inB4ZoLH4/M0A2fcEgaW8WIuGehr+XfRvF0OJv+rMCUaI8xUQZABOTuewuDSjajIWDg0KnES2nWLB4o4rxGiuyqmg2aWDPiaOEUM'
    'euYiZtE7XDZVDcb9pZ68wk44hDZqHD3lck7E0N5wPJ0IcU8F5UqQkA5RTcZRW+MvigAip4KR9+yOCi8didDCdSenxN/qJGumacMW'
    '1HbA2QEspP1GhHQUuFih9uk3o3cpRG29SZQOxpMrfGE7xZ7PIENDTYcyTSQ5A0+9IETSl1wnpgHoeI9pIXIzeCFAXSqj7ojPLNPH'
    'vg0Flpveg/11sQWwJajgH7bINGHkWH5aIbuMldEFTaJ4S5StLi9bL5lLqjIYnfOqFyZrBysj4jHS9X3OCA4aM115iUXtPnm6ND4H'
    'iiUE29cjV5GukhBl2U9r7sD6ed78YTw4N5Q51wi7urs9BFAHSMUu+DYWo3ys6YYJhAUymmY+GY2hh0tOWGcUe758KW4ljTsIiKyZ'
    'cxV7WWzsfPzSeScZp664clMYX332ANv9aWYFUH5HdZOHzueqVK4YIghAKIus93uDNAukTZBjD/KT4u0AVMAfgcQmBSqXL2VUwidH'
    'C9LQ4xrWXXVL8MtGh6MpkdC2d1SyD8wLTUwhmaLfpMKutsqQvexlpMkvwKu+xL3Cpkqfdnf3v75+++4de/F93H63s7+/Q0QFZiNl'
    '07wgDvCbYFssCbnDG2ab+465jHVB6xEPb2NBakbiSgUkvthhw9PbBVGsbizgFjvh5AAtec+wurGwz/6Viodqud58LQ2izuyChKNn'
    'jIUQbRmVbo8uFjbf04/1JRkIGzW2ZozrG4fED5uuZd+OtbB697wZO/7NaO64juZR4BuRF53zxgcSUPCP+wLGAdFSZJy3lG+2sbB5'
    'O5kBOUlHg4OcyKxDIK8BIXs4eeZ1J4qyhL/HGhjBwIbjzOMHOVqIezkWHqw4vcTW0UVgHLMBKSte0xwuFwrSaiZJXBLH6TD26tBS'
    '9JNxXhiQdP7gDIGqiPmWGdk6HKa+UL6qwfDs5lvNjn7j2Dw7LGllltXWsa18HnZHhS4IckZ7E4IiL9UWl/2UlspmabnsN6hnmgJ0'
    'opaZyXLyjjsqSk5u3mRi06dxzrwdniv6MTPiFl6NwD+KFsGdHQa0LZH07h0YAe1hsxObjpEy/WxLHqpL9s9c0ZqvS6N371m9VQAF'
    '3In9M1uQzWTLBfnbx16nqolK1uSg9v3xC6LCONH38dtJQodZfu8h+4i4QFCR3smJ+b13imuMfyJNjvwSXhs/e9vdLsj8h8ygVMKn'
    '9FifvavvMN13zeOLaHMj+r3SM1xTR3h33R4XdBVl1HVLj9JJyPFK6BtbjGcUlEIgkbAQz7BCDi4B7Dk+SpxzLhUcseiTEG3//Lf/'
    'xucsUkd+PNvh9fagZyptZe8T34DFnbR5Wvyq3pDpK17yqN/bYec7g/GpM90QmhwKADAHeZOo5tMk79lNyl8n3XR28WP6aotuTyej'
    '2UXhxbnfkxDhXJxTZXtDDkqDI3OD+ImVM9Ulobhx1MCIM4shJ0d63oiOh0xNCBCW7iwt4V07w/TiGxgnDoUigdGRM8ERpkQyfkxZ'
    'O2q/0pBBw/eT4Rkec+a1lj0uIRsNoGHAzgbqh4CxRawGqT4hEE1jIDAkQkZ0yZGhc5mJN+3VjZnCh/TCco6wSng5yfqP/zP4oxMQ'
    'hkhn0Gc5PfPdotwGNNNdljILby54t0ZURkrgJvOLcNJn8xGmD/5HKBuCj9t58fN2bgu8RFwo/7vQh7SX/CXuTBEmwhbHDe2XpnJ4'
    'Zb4bxtYrEbDLtp3XImEv94oPsesPVg8qkCyVhvHRPi9+x5aCjlwoftfEdOLX7UwnUtQW+AhrmHLzbCQD45MYdioNeTbCnFIv3Mgf'
    'e938mxsybIa082oqJnTBgLrmpdtX0S4XtkLfusaEAAt2A5huTzU7tiDwhl9sQs9ur3qT8qSMGpoOTM2dm1tbiakarxZIGvuRyZhg'
    'VN5HsUXjq9UrwmSvp7dPmwSZiHIiC4kFrLp12zjGpi1qm3CLe6ILxj24q54fHYnAj+ayxwPQB05k8OL9KEtxH9McgBy/ZdwIqUKF'
    'IX7KqSXJCMSWLgk47EwtDGJMpRHRoGmvlZ3BLxOMJmEUqwr2nLUd/d5ZypoOoomIBUIzeXOeYr/AZAhrXRS8sT6/ySG8N9UWohFZ'
    '5iVSipJe9Xis5nqlX0q/VFkByN4blVZp56/nreFaQR1WaPGsDL3M+eGTQzWe6sMr7suv/ZKWEHMgrOJHv1T5/NncVP78w0MZjl8R'
    '5y84Dv5pCqrym48ffgyQbIAi6dn/vuNb3pab0g9BcxWFPVtRU9Szt0NBo4wv2+tRhSojPtejMlWllZYlMt+Di0VebQtpPXd/YDvT'
    '75sa3bjWZnhIOZXTbalJXIj5tzfKHG/YovCNv2SIxobAtfVJpBt3A6OUC6FQTDlmXgJibyPDEAsHZ08TGJmIiQPoc34V9CEsfakP'
    'j5WnFnioSvRRMyCE9Mm0Y/kse5cxCOCtLeIYsLDQW8PNSDGPNwvHJAZr8eKK16tl3SqLeiUtYxcan4iRfDyUdR0q2+SJd4Q4J2YD'
    'qSqJVE6Rns41a5jE+a0ym3X/RktoTgWkQatl/VRbt6Bn11kN/Gq5mTwG4qmphqyicj0z81fqlxmxwQncDZg3pW9u482H0hoYYdmx'
    'P3F2WThYhnI2XAu2yBTLc7C4njCM5WkSBCtHJK1jH3yFP7xz/Q3PWNyCYO7Kjt6x7GblmEsNnvY4A6EmBJxwmjr5i8m9hTjU707Y'
    'yvKqVSgnHS2gfglEpqTp34FEVSwvWkZWL0xG3eSKqA4EnKN2QXGssUG7SF/ZxHIYQQKKfKVsbznsiuldmakNNIDSeci4mYKsnbRT'
    'Y168EiAsL1nFnFf1Vt2XAwBh5O/fFzj7O/pxbTN/fv+2wbJXgNhdMxCBwf27YRnC3H5uhbz9I+DhLL0SM36maYkNyxHCkcle0RxO'
    'c6OBVQWLR6qWBZcagdDQn/ooKkP7qPrTJp2cnYS4QwT9hA6oTPq2w2j5Lz7v7+9+4DtrMJrm6XTMt5ZdGCUji2qVdhOKJDDMNHHA'
    '+idG/7ttjpSZaamxyC6Ir6L2mXOituE7dcURF+v15kgqxPn5SVlZrQlIkyGhJvcaCjHM0Sg3OsmQwzNGGbxkpI5J8tmIIFCrNyO+'
    'O+mEEpcgES6JN4XMenKajaYnp4UUoeJdQu0msElkBoAt6LO0Pe2ZQJDqKS4MTN7JwAvQ7IgtENc/IF79SMwO5CGsxaPh1iZRPpji'
    'HkY3hBYkNWAOURNapLXv9pEUhO4bkMwT11l8cdpjNRHCyVCFdtpJ4BbCZmDJFMRaFm1/fAvL7iylVYKUD72oQ0Ev59ictCIqNpRF'
    '4ezmXVqPJJdUmp8/vcvZC0Ac94mNuALIHS9iIAmuz6azUeal/sjbJHLGoSgtVD2xE7x+MSIOnPYaWkR+8XqUqQmqlje6PO/VSz6X'
    'E5YFaqxPfv+JbeDUgNUfDegoGxf+gRuglYVJ2Q+7+ztf97d/3GMLGTHITU6ixU2JPs3q4zp4T9WUs5U8lWD7uuUong6BgVp6Dzig'
    'yDkjLqw/PnLKphef5A//K5nr+Odb/nfnPf/5LF9Nmbd/3OGfr3beyavPWv2ztIn0afwDic/4x8dP/Jd6fbPS4kCbBP+r/OnNE/nz'
    'FO+f4P0P9tcz8+uzdLQrf97J4FxkcX7clnG/l/G/+aQdcnxofsVZSOQX8i/KL+RglF+ftJD8kYKv3v6JhgC8v/dx+wNHPn69+2Ef'
    'P767NVv16tPuR7NVSz/HcmRuWJdy0zsmzjG9kX9HbOt1wyB9M6GbDt4ZN8ORqXF+ckPH5/QGmPOGFZY3cES+gd7mBqGmbkB+3DBG'
    'vRGseyPY9gakBR2X5OacTvjoJpl2e6MbSXZbf7jU89WO5WyXvvKR0wHfnToTflQcOBUNbJpMmngQDcJdCTRVks1pFGZZ3nR75773'
    '5kXCuq0Y+ALcgpfEws/KDHcFooBRqjIfgqRM5gDX8/JfUgdNug/omhAhbGGQsJdFHddUMSvmdHV5uc2mKzVcRRVJk8sjmZmawYKY'
    'ZGcYehl2ZqZ7BrrYiPyizcnoM01J8yE2omzKxisW1RxQucMgvzJKYDGw9ppAhBY+mIzgpunwbAgFPm2EYJ4xrrDkRBEQ9PsAA69t'
    'Hp5JSlhKKcRJy3V5qlIRmsTxYhIUJoB4QIcQXvT5VovOU68/GbXqSz1ZOY4Zc8eMCjGKg8EiVyFrKMME1gisfIPAJDcnveObi7Q9'
    'rq/hwD572jhIFv++vPiHx0sbX/LDxw/NQCpmxtkMdWKzNpUvshkHBucRFs+8qxhszqcVFBS/a2FDwpyYQeztcEeQei8vr7yY5Ffu'
    'iUn0sVaumqXMGA9HkBbQFTocsZdIBqOitdkrXS+3hEWqHEOYCzJoal9yT7nnN6FJZyIss0n9hrRmowv+eVgGTdipMT58O6zaReTi'
    'XlkuQOQ5J2piw7J1+rpcnlfSiM5L0bELKEh9J/B/HvTat7fG/os/crZwwq++uwU9+p5ARp9I/JYQoeoX8cDksGfLkKX1mPjZG86r'
    'cHOa1b+0LQibTPe0tvrb4b/1g583Dx9t3vxu2M7Ha4oHFULEshi43V1LToyEUGUR67yIv4ctYuAlNldbWaKmfOs/0Uf2mGllqzkl'
    '8aA4DU1r1eud+6YlUFKx2cvVvAQdYjkMcJgCxnLSz+FcPq5MGbKYT60rgfG15TzWtvizMWDxDOgiqDKFCWNrPbUcI3aMm2U9bKEE'
    '8VnSZaZ+BkXfZCPLuy7qe2esqLHcLNDIRfNkw3RyaHomwUfDSqemOE/ODdsJZqQ3qeVwGsFLkLjDrtwfbGupMvZmaEf1wQ7TU2o/'
    '8E2QPBNUuXfN2NVEBgZIH+xrhum44L4kjxt23tRoAEfGucmll7O9BE5Qtr7R/StvwdkSCmZMcAgueyh9Vg8lXcFafYYnTp6mvHTC'
    '9fiAD8ULAVtoRF88FbMhQna91w0nhipbeNuyADFnLbb8pfCq2OPmWZ1gGULC1SIfY1VkqnXCM6qVawBalh+IY7utUeLf2A84yc5+'
    '6p31ZJXCRZJaLIRA3tvr0P7TsYl0EAOe0RNUuCVtRE9h8xPxafkJMRzccWGDSYEDdnF3VpPNCJaVx71Mwr8OxQMfPHV03st7E7DY'
    'OEhQ+BKDnI690+Jvp9D99xv+PTa0DNxyCkNfC75xwCdsFHe0uO/g0kViam4oxMnB35a0cAtw418tT3iu/RoICSTr4no1ZHlsiBAe'
    'hNAQmmGXIEXs59VvCNDyqpdNrtzdMVSJ79Dcq/QcmojrNz6TisDcmSwh0n3PJ4I2t50CX+pd2wWz3x2JSQrbrtRboG5g8zIditMs'
    'kYYSfYWgIWHFPAKG8CsPusD2Edx40FI287k/wIvrbvGSiGDKvRR9Mh7gFxxDhAUU0yxH0OdExDvGwhtDgOG6xJVh0RU73GY5ppNm'
    'GL8Xj4KXZK6CPTd3Y0GSGFrghpeoDbnQZEE6m6n6pIHKnvKY85Tzdbs9iZfrTcDQaLg97BDBNMpeqogqYxYkkBOVKiK2mSUV7B0H'
    'g+FcrP8DY+KM25eTpLV4QhWkib3+pOuqWbjPcycwc7WivIouyR0p4jooBorBl5eDbtwZdNWRMDKqn/BerybI3KGuWJEgqkB6mXZw'
    'pAmqYvHm+qk3OX25t2fcv60X+KxaPEQtKi6P7lYx90PF1lm6W8AX3/SWE7S4adegJiXwla3GSoIbHwI6Cc2dUzWVrMnLsCwizq4A'
    'ngfSWyU4ZDMNu+3eNW2kFwJAd8lTtDMu6LIEe7yJa6oEi920zvnQuqnn010m/3R9izF27rS+5h4XgW7y6ECcCQbdQ+cbzPk+HSeh'
    'wQj4TdiswsXeBEHxPEvtQbcYkWCub/FoWEji02a5l7+/W84S6HS1EZ0+aUgaOnblbkTjLHUGt0Ou41mWorkt/OuJhTyRQMQCz4pA'
    'Yw5cWQGbS8g5H9aIT8xtKlRvC45ZICelmbPinEsCWjlOnRoUL/Gi6wKjMQmOJ1GviHfqiub3uO6vp4utNe1LfCqUjDhsGkfP48Im'
    'DgS3ajxswwMo3zhYtoQphlkzsdEcxLpJP24XfH8RDkI93lxvIyr6eLMWUomE6cS26RuxlvqUCJMze9eTGj3NlIux8Ku1tFQzR32a'
    'gdwaZ6PBeIL0VcMzDJAwZM7WmNyZI9hQGkQTKnFaLNOcP1BpEqEsnQjuLuEblaYNlpp4IFKv0592CZRq/0kc7x6Eb9El1H/SDpPv'
    '3mAeo6k5qB7DKfDCWHu1zylt/9F6wnJH7Head3i0twh0aR/Wl5JNkWdIdi6m5yyyFu5ejd1QPgAI3ultGYcxE7yeP3YpJnsgY62F'
    'Kfjg9bshYi3AK+eiPlp/eE1vbhUw9cFme3+CWbis04p8SyvBo91cn0ATgeSnowtYGHEgbXm3PlGRv3zqcqBv95uKad4pbckdlKMC'
    'dkMy7NmAPukiRBgUdoabQ3m/QMIMsAU/fLZBTRQ1fJxOfAoT1g7aHPNQvpJhkmkX3i3FScuB14q565EZ83L3OOY+G9iO3BRD6xWX'
    'zSSr1Q+r9hc+5IXNnaMZQTNrTvOBI95jW3v6s+7nvTcOSVEPOdGzeRoN1zhtYP1eJduZlbjG1KlbsWLa+53tV5BCy6pMXoy6PTb8'
    'EaEs3qlSBRpYvoGC1uCAAvh8wQlm4qwR3aezuNgbHFxot3lKLLJkopL7AnvmDLdtQIjiJhEY2E3yne81zkheD5wCZ6zaPYaOo8aB'
    'QhGVMep8w17QFgdr1WlEDhgOAMaPo5VDO/s1DfdYOVtiVH2opGWyHtZzK929SuGQaGOChitOB7Uq55zFdBWHyyGKukKU32SBJIc3'
    'sbmMy+yh2KtYu5siOS82WFzIEruKnSGhY+VQyrRfPTJRX/fU2ibWD2slARNb6cweE3Nv7PVhjD5nyK7uaCdwsb4uOPd845gq/Mk1'
    'Ft+oywZJnUnW/2N6hS1Lm9Bj00MjOuNvVDmkOp15W9mL/JoqEEmL7jVPALsJBYM34xTbH4HrStd0dmRnUiOVJOcYIj0G7FPx2Up9'
    'd1jKtfTzl/xRvLi4ePPlEf67+fr1a51ePVwSOsev68tzLUtRNR9Woy5QowtilccjhdVOt3fOVjsw9ZL7YUbzNpJlVOIgR1nv72Co'
    '+sg2WLPnzK4Q9owBt+TxX734vt5grbKpM1VB3nP/vM3YUv8ovgjw844uzmZ2YYnw2fCwn7Rrxe32qIt+T1iSqtbNGgdDr42mEySa'
    'ZvwtmbNrVloz+zCFjhbuKCHa3wYGXHWY6oZffk/FiFtP7SlCvfutuxJKqIDLCIufTl4D3ewnJ7F5jZ2QKHhAEPL6gn7pwhotalWI'
    'mMTRZgnrE2fMZdZwJVAshzGPE0750ohqX9nJ0NcoN4oa5fnrPVZ/M7veFV2XM8QQYYfhm2DIyM+8JVbMmMvBYf0QT4imcsy2wnPY'
    'XKtk5BjwhiEtkeMBp12SnxfGAoYQf2Pf4sZ0JIY+BUKfX5Y5Ge86a9zRiUS9rqvF7+wF72bJCd3HmVnzisAjd9Qfjcvno7AzuFz3'
    'OQRumv3ajXlQtTNr1ZAyK4yKphIf5QE1CEzzcZT3UA42VR8RyXVLIYtK/FnXnH7+BVzFbA2yDpU6wOmBOnmyhznhTXN0fEzPwr+4'
    'Z3NVGrFzVkCN4TC5lB1jPaw6r2j1ZHjAs2Bb7ZQ1IoYaFefRYJpP2Cx1kiZ9n4uzcajF8OC7Xyryc6EAK0ySxfLYp3PK2x+6Pf4K'
    'cWN7zsXgHHFwQkPhojEeV0lfhfG4PdnivmDKQVYQGo7fgj135ujDfaa6Z7pznFdYns/05TivB0KQ86Cjoo+gXt32OwNLtTcKL+jb'
    'wUnZHcV+me2PYrBH6JQy0yWlBLx5MAsmynHzBU53llYSCH9FqDDQ8nJccI6jziG/YK0e9SZrXIaDyonJtCjM0m7TsxDe+/pTRexl'
    'ATGJR7f2nYhT1YaSSj+ujJ+rrSmHc1H3LT8kLIgMZYPaeBzVxpe1QKZtN0Ks7SvD51SFrL7j6gUPBxg797ieqjG9TyanTQ5ZEnf6'
    'yWAcB0HU03OHjVafLzf8EOuPouXm7+t1NyfX+XRs7bSvVVqG8VTPSt2F8Me6k1aXnOIim45VcDInUrVuScM3N6uaPxucFVUMPI+Z'
    'exCOdmYxN1TAuAy1WoGmES9tety9FCl2aUJOm1Yb18JB0lnYFoUubncYjCbDK9EHExWdI8Y/43u2YoZlqWjT81NI+nEnDJIzKdKG'
    'XAFmhZIZI0WijCuJq9j87m5ixHhZh/QD59nb8qTRcP7OgairSAAs0B1ky2/UC9bNSBSiU9qnvMXWHh0k/2JnEIkqnwsG6ZyOep20'
    'GoW8efthf68CgXCrheDtb/AuhomQcLEce5zLVYWosbGXoNLiSmtenX0uVYxQRqVgPsQBZi5FwRK9ARRYbyVwVfLdeDJpsT1bwmav'
    'qT5TPOOG6au2wnzacgEwNSqIN9KyL7xdkep1sOpLbyXYMjZ0EnfyCnu+bMOVaJrHL1YsNPhAD2YrWsfjotcSgiTAx6YFbx7qzFqU'
    'DBHKHBKGdpZkV7Q8aZKJg07Bu2nfd+Y5JtYsD5yK8mJT4Bq7MNUYE9cpvUpsBQ2dzsxbF2eb7VTUualLA0DTbNFEoF1T478G25BH'
    'sfFefBypDRiq2CgMi3CIZFd3Fj9K0HoNZe+5BkkEGi86v3H9MUM3bj5cOVeviPfJuBwgP9r704/RmNZgTNfQ48GkN0i1k0mvz3pv'
    'DoqpDW810Rt44bHPguhX/shar39AhTnWaJf+V8uUtKKxd0YJp8WTouofCdqI5Lyga2wJlsfLdB1OEAqkJ+nAD54twyU4pRrd2mEj'
    'kudBbzgl/hjPq0/pmTBuxk+/b8Bt/Ip/P20++QFhb9P0jJ9XVlGT4P6UH98OYZ07IWiqXRE41Q4PjTYSVGMxRtcBqIYGxzE9BAXN'
    'AwziPUfrEco4GfvQ3PuD5DKG1xF+H/dHo4xoSyfaGFr5us4Sa/vXKbuKXOD4Hz28Ht5G9A+S19IfttVGcgfGDbVbLOyRMVI/j5Y2'
    'eBzGlFYIugsCwdEEh8KcqQvaU2VPkBNeDbpSKC8g3RuzSkrs9GrsxTaRqESe8ZWFL+aR/J1l8RUGjg9NQN3tjT4w9OHJuP9LNHe2'
    'h2dAbp4meXzGEhejJZP3iIWD92teN4jmKnd+I0KwwUZkgvQ1IrEH5vgcZy+n2TmsGfGbY4fnQoBwKofzE426X6uFucUkYBQYOY70'
    'NOjRyk3S+F/3dj+Iy5H8FDeG3vFVLNOlW7GXXrCDZylTBYGORNoVdAQPwumYmu1yuqvRd5q27HUmUXjTcL/gDqkpd8TueAiUFf19'
    'NGIkCafDJJM7NqGzPXQoFL706nyZmGxmTobHlGTeSYfGlLvBAZXb7dElrNwvfEhuN0Fg4xg+e7pMH0/Dj6f68amNfSvdIIRxu3lJ'
    'X9HAUrRKB53/NqIr/nTFn071E/+V+m5/jtbpN6dSejG65FTLOBdX+OcC/5zeLsC2hP1it/MxMbWfIO3YWLh83+v+hf4XDdJ0shBJ'
    'uikGj40FmEpCiy7rcLu+RH2I+tm7unwQ4ZNGuCPp93Efxr8Q/DQasYooFcZzgfGG6TFIRiGvKixfQC1I7LFvDJhWzjAUxD0rB1KW'
    'i9e7lPb4hYjx5KOLz6zPfohmlly92d3bt8ZLwWUmG27bJqQzzWuzdAim2I9ZrxgE8Gi92zs3cVhRZpEjUS9s/sW/+yEIkeOR00FK'
    '1Tk5TD8Kn+soXm9vhhToIu3k9HJ9qb0J2qD8eZB02DKRzigK1ZuwLng7FJRquAGiMdgFO58g4gZIDTq1zG+A3sDNS89DFzOuub5E'
    '0wpNI/zMDHPWzEzZZMV43WObWaGFzCIgDqLZJK1QSLzjaFe7bWL8lIx7cW2J/l3SL8ZtSk5QnGaZ2fE7RrpkPPWoX+byVGdFLTQH'
    'aZ7DBRvTYDGGrOckaTMyzFJew8IGqpuBT/VhCbz2qtYznLZnJ+Pi/NEyFE+LmF2bGb4W2pL54SBXhRhnKwmWpYiezsmWEHPZOigd'
    'NB893vr54fVtXL85+HL45cshOyl9+fLwdzXfrvK0d3LKMXNiLCRI0GyglAluNyOKzzv8vZgWQdLXSRUtij92GBKg4GTnchzzQGNu'
    'qE54v3bSg9nLQGx7gD2BRAl/8s8jH3OhRTUU39ZwZellJ83GBDgSx3Vi/QUUw2BINE58U/NpE41eHDV9/5phj5jziulrwFkocbG+'
    'qFXS6WKJEsDdIlFofd6e5TlLZGi7Hqd5opasjc1EJVM9BEpdZk1SgkR7y5Dww+olYfWqdNZb074m1gDGmQBKNUv9+Mn/BCl49y1d'
    'tFR8MfoBN3HKAXHlW2/I66HNc6nH3Ofj6PmyvzextEknyoRFZZaVKwtpzwW49Xpl2HsEWUXX65HXY9hgIRWGO1rO+tBDOKGt4d8q'
    'bhsNwq/x9oNNVQigSn8jzq9P1x6PtW4ULC9Go36aDO3mGxWNYWBErQIry2MnWDN+iIaqlWD3t1+G+M10ufzEAtwelaHMZPXAyJrM'
    'ZcZ83KlFJ1kh+LCb7i5Dm/7qmIgCJKVuyQTNfCaqMMKAwo6Dls223EqU+6rVUP3A1d4om/hrjthw1joXfAqH79SUT3AMbUtgzqYZ'
    'BQsG0pejAQyJiCTU9w3n5tJgccAQOqZzYsEIRuCMjOS0msXYNYvqzDMQlCfmN59Q3qgcOYn90rxGXFZ+0emTKUmhggNcuOthJO05'
    'l5TsgBQ3ua+EvzFvb4E0mHFTvAXGjSOU2zs4J9aNc7xFnOdrLoxzbi9dm6M7mz3yLHWJ2gd4O7AmevUYnkkF4AYWLcwMynbFrQLa'
    'Fru2LBFm0ltOEnM0OEad8qjuxa2X8CP6H/89OhLeFd87oJdv1XXMvijPis8aS1ipYbRhX9wKd8S/vYY5nLhfmF/cMhXuvpdXT9lq'
    'rgShhQKd5h2zRzIgMrHOaBO8LjeJBf+YCCI0JszKsC9E2YhzALBmbwH0C98iGwvLmi0ArRgzX2mz7qcI4DsYkhvzEXbA6nntD4qZ'
    'CvA2HqcO21dQkVp85pjX4V9uGmon3RNikjg0DBFnxCPRx02djuk4zH4A0XDS1/nIw8wZ7UHaSdAhwjgMWISo8rwIqo5tdjUpQsVM'
    'Ycxrl6CwCOgDbTpCySIkAedwRcLagGxjY43f9y5s9kfmUC/Ve3jNJ24rBCM9b+Fw8bIw1qNw6fmdxx3cepmkvANdF3TQnA7ZIigu'
    'ZqzocAbt9GKBzqnwTR/Si5f00m0J5KS0F14kay9XxQzbBOmUXSWqEOcsXo2YVBbFmjyYjCWxtHMxJaNKwykZjDm7C8cBCrF5lU6a'
    'hnXgBJos+AUXSJ1JPnEERqMx9ToQADTA2LFEmJoaQaIzvAI/qFJn5hCZpZsleI7BnCinQGRaGxovM/y6fxVVsLmysC5BiGFbtLm4'
    'iu6y33wSGWG6NizTt9U0gxPjFEcNHQVYofq4EnREwREA7CucKTKAWm9RSluc4KODyWisfIC43ffyEmq49BGC4qMgWUo0iw0L5QTt'
    'zXfhhrR4yx5e85rAWSWYMq4Ym8PluJ9eLrYRDLAFmFjYHI6GqcGNcjbNxM152u52XxdmoicKQZt1DEQ3h7iuPIRNgf20y4xKoOKA'
    '9hh0H8eKnrZ1WgWgZkZZtRpOq8lWNhBJYvIikGyatfXC+5/tjzSTgosT1oV/MdaLyhAjN4hrLGoxjkJGDHlKt7/x+RWLBxoZXytG'
    '2MyjSa62vgzjv6h8BI7CJpk6X/QIHN6sB1wwJrQ/mmY+S+ENNAyw0B8lXZNjgHMoSZalaQbDsZDYA6NbECikl8lgTGSuLLrAmjpy'
    'bA/NVzPjlvJsPG5LAiF0F4vZEd0wEha4A6OXi55Jal8Q8WF+rzWfQMzXp51n+fqG9TBviOUnKrITzFwd3x4jq5DwYChModRAxnPv'
    't0hq5i1qpuRi1pT8cJnc+BUiIV05X7ojDreF+QsYq2kOGkNaPI75eX0rS+HE9lVDd1V8hixrSsq6vjjUO6lWtlbIOH3ryYPvGnoB'
    'Y9/bmlaopEor1QOPjDp0RpPyQkxTyxZ+3p5JQbthLe3Lmmlp18QY8hQxKQmNXZyh1VutWXlFebTfe6RDzWNqvcweIYcyZ84Yrjdj'
    'lK6Hp4EVGjaZI8MZm4PcuQ0zPQS+fUhqOVw042cLYvsymm2rfdeE1GB4xpV2fwgbzIUu7172gWxQD49fIOhdCqr5EDbwoAtFZNAe'
    'bToDcOwdKemSZ3ZMsza9+gF9PcoQ4aXVW8ad5qCciXtvjO+qi92ZfcWke5iVgAXfcTsFSVZwL+wT3ZD1kr6fEUByG98Vg70ig3o9'
    'gtaHq5tPvvUfC6vldiqOE2OzQdbfpP3xnQPlGVVHfP/WAO9+kwrYVbO/S6r+YG6BtRJp7IWVx36XLCLdFi8tRT+OQE6xXYTmzvBE'
    '0g3EfoXTJpH+omSnmbfoJQcuFrE2bddEuAdofAsUkGcjkdOtzOlTY2fFhFBTaXX4pSMk7zHtQNXBTFKQMhRUAXz4tjzhbTMW4uXm'
    'r/loiPibHP0MpV1OUfBRWy7TOsbwqn/ir7jVDdoCnGeo7gfzcKg/ostpQORNLPlVQ+mTTdCaDHMW15sdr+rXaVm8r6OhJG3fKH9Q'
    'PG8jvGAAsXRUXzMpsmc25401ul+yYS/EX9vmGG03eyZls10ptuLgH62o8P1VL8c1wEW65jeiSzO94jrxfIZkPNxGOBk7BldbMz1j'
    'ijBv8qwZ26NLidY3Y1ncYgZGg/f1iqukU8rDuzWC6gpS2D+dv0TjzW4EQh37IGggzxCN3kl0FKMpxN62OtogeXCxEG8v6324VeMu'
    '5o3BklOyJzFHoMOpviCsYslTMGvHSQ+EqmooFUw8esqZAaiyzfiVY2movknmTSyVJGa2+EvFpyKpYLsSlb1QacRu8jBU2K1d/SCU'
    'XeB9h+g0FcnYCnYHM3KzuVygenZt2kuJ4xHZ1JY2rkchL1sxbxutjGptv4EgnGn20JjrTTrXaXSWo6UFIzWfkMg9rDBxz2qJEvIo'
    'RfuLgu+0N4oldQNWlAH3Uak869jeZdpxD3/WAEG53hjoRyIBIOyTskUSsSDB5ZDlvkYKBH1UIsWNvxqVLTAI/K7IIcxamu0sG128'
    'AhTMGXTVEs0e3Va4JZVOrYUYNzyUUW0eu+CCbOGo78J25H0Cf/pU0si7FAo40GwBHMX//C//F0uMkHkQYQro4IyTbkTEA0e0r/uk'
    'CJINUItirxTICxHANa3w+9rP0vQn/ub8tMByNzjc0mtWOTb33uz+9BWRlxp6BpJOJx2zI1hL4rsO/QgE9nqVIOSN6PuLUdZHzjAv'
    'Jj5iNboeXr99t7/z6eunnX/deblPl2b50/bLlzsf9xtWUm6jVBAeRu4UnSHHXeAo2kSkSrg8jaMNKmREi/NHSI+890XzCgQVnetu'
    'dcB0GuxRmTY7NcyXb1qa9k3qdfMr6N5+XvNreM1xPe+5WNsvauxfigl75kxBrMujszbz+pw6PqRSAcuv+KY8K5py/fO//H81aySZ'
    'AoBN/EE6E+Ew8vH9xsFxkRH6dBxa73uPlhIGUI36fVxzbEP5P/57BN+LyMswTJ805vK4N4RhiiuqlUeZVGL8VapYmRw+OckLhuvf'
    '8zsrieUQMBo8NTeZOThV326bSLVeMmzBekEyWQyn8JqgH18bUHxT30uc5IEzKdAlfwJT5aaax1+JbwHRFmM2CYVOPvNid6p9TUOz'
    'B6Zsf6MJv2iqKMzBsoCSRSsCEmVNaEkIcL/jwNDOLElt+TXoq5odJxL+PZZaILdOEti00lrCgDOP6J5ssOkWUYt1zyp+f/tHGInF'
    'P98cfMnjzcZh/fv44Mv4+t0t/fPh9uuh//BlafHwUX3pZGoyIVCfL5POaRoYy7NR/bG6lFtDRC8w0km+exwP/UhZWya4q7I3B9Z2'
    'fCIBj7gXtlg2cWCdQi4kOzXn0qz41MbIxn3wAlaH74mzl9e/MxfiRJ0HMdc9GgtH/oGNDt+wODS0nPVD1u+wHdfgYPWwEIDduSZf'
    'sqB/6eeDL11a18cmmMRl3UM8dursJLgZrS4jmLh9y5E5DY3jyrploj2vOxM8sf5WYpYT1wBoaFVFUyAQKvDFx6alUUIvJyWgbUTE'
    'jY85yCjYdK0aI9oStaZF0c0wJaBt00faXTWkttlysuzKph+igSR9RHK7inoSEDThE6Um2YO0P8klcik60Li4AVRx+tDwYpV8E9e3'
    'dBCG8pkfPZsVvEho4+pFy5cE/OMis5HFS2iIEzvM62WjNgPadVoJ7fBgchhtbcn5AMzUWbwYf9x+t7O/v2PN3YaaNN1FaxQ4Xv4F'
    'fbubjuZP/RdzC6hQtp+whICD3wGSvREfNnMWnHLKX2uAZy3h+EfSzqnAYtQjot3MRu1cFqNCiXq0vhGtKJxidmORBSyuFKJanQmX'
    'chatF9uE+wwqrfN3RLeS8F+YRczxd6PH0Vk9+pdCRepbO5tT6NeOwls6drf4bcbDyijtzdbiStXlZbepjH48QBXN76HgxI08jlYK'
    'OIFqhjE2vZggExNh0yJ0joRrn8HswN5x4sUKrQytv4+4IqIBOYKFCo7+9w+vzbfbFsyD+CgqgmTi1cK1M7+zrdWtcZh6iDVxz5lr'
    '7qiSVGDDWIyuFS2h5F+ng7Ew8fZODSmJ92ouAc1brhe1GnmOjgVBsk6O9Y/2fQJVZFffGjKk7rSU3VztcL8z+QSa0QKIlgVWFuce'
    'BZGHl3xTIgXhak+USjgZiQCVCJ14OoQMnyM9H7MVftr173uZuzJ/8gCuW369hXA/+PZWkrmZAu96efgdL4wfnbx5o45mh65RwnCC'
    'yULta09g5B4CJy5ZISf1xuiz8frlhaye34YUteLUYmIEN6RSnyIj9VtxkaecUtXv1buG/sYGg4WxzrC27ZhryrvRvNgiCL9i8nb4'
    'Ec9rPulyX1qnZFernAEMPbtVgV359uEzGhJd4nOn8ArhOM5ryIEjvwJnyoQEVj03WQI71dwGNe96EFNTdz8wkv1b3b5flteW8/9b'
    'ENvl+5oXrXoilstseb2ikkKHU/iaY0Lskvkq2JSbTp6suQ4qa/idsrGxqblqvAdtfSyQX/xvXumna1VlxdSaiPIvi1+X4kNYXHPX'
    'F+j6otCWP+iKxizm/FswyLAkg1aAZ/3S3kbIKxAF+rkrtmgH/ECc0qElOfVz0agYoSCJsdKIkB7UJAcrh3VHRXhf2t4X70ArtjH9'
    '8C4vN6KVVTGykn1CVR8HWHwUeWgtYG5d42LiS5xUr2ThK5zlhhWvSNQ4yXRRo1MKd97Ym8KH2JSsS9heB/lwc89fZynODWqzR7Py'
    'jzgj1tAlsBJmFnfDuyHt/J/I9CdlG7PJiTW3crx16+F1x9Avt2v8k171hme7w9h+gE3s92qIBluxKhOxalve4y41Zi2CiRSHyS4L'
    '9Hoca5kaDsbYHU2qB7n/Zuf9zt6B0YMeNjtxfpp0U6F70YyMKrTvGhgT0gA9hQjpo4eQPtttsdPkqLr5bdAub79pWq53UzywHPUW'
    'qHBVpNmPo7jnXxTDAPYOeofWo9BcTdVZNoAzRWkZpDWxBO3YA9M1ejKQusZfPsTjuoFMbpxfdFzg5GultaWHup+bVoRLYYU1byzG'
    'N8ukY6IV75a0EEFWYTGdkVx7hvlisxDTe5B2+Dv/Xp0d3NO7mWHlNrdOhdZibrwvE7SvXkrNLdJKD8eYMKgsQZwREP5x6syIemqH'
    'ZvFWfa2quQOvxOFWU+Rob4lX5ty21xIrniB7mCYIP11j+7Lbbw/BGULiHTqKmfEIDeSH05rVmNMfzG/QoHXLpHo43F4oKyFR+hg8'
    'Ke9ffNcIPo+/qX9xJfO/LBb6ur0TDoPgraW0x9fGMpzpVBt+xOVBITxzbsIFi8q6gqC9pbvyh+W6HQuD1f0iOXlmgbMsoHpQJYnN'
    '053Q8DhzUC8K63IW5oMDdjE5PATvJKRvyKu9CyW6JufNwQGQvlQriYHFa6U3iYKUSxGs0QmDcbTmmBAqhxKQhm4g8R2ypJHahHxY'
    '3n+fS9z5Q6JUov1T+NNK42rtPgocL2EN3GCASFk/DGkb7YkNiSLxN13Eu5ZBtnhjZ2SSpaEj5gObEcfzhQgd6TnDLllUPR3TOrBU'
    '2TRtI5NJVTCgLIFLe2x9g9hKfAXD4JPOETMTNKsTolI81vKnt398C1nyl4MvB/HBz1/gZDu8+f7wcT3eah18f3No3h0+qm/R38Ol'
    'EyNHdjez4222WLRa4m2+5I++DOkfx8RoOoIKLoyp33IcDaaJq7gvz8DmTplgE92IiGIe2wMMgiAbJgS3M/tGPNUPLFNwiWCMcHl+'
    'Lt5vSr7ra4icnBp7FQqqVw5tOk+Ibd+bUFvOTVhgmcMwDtXRTkDRO5Q2+VxFvj6T7ipQfErSO5WN2iWxUn5xlbAbWg+8NFkONWly'
    'VjqhLDyyF+9970Qe9wYhB6RkFg6csaV4rdmGeRv6TSltWi1wwX2Tb1iopT6PlY3EMR8WAPYJDAjp6om13Rz0qbkiU014B/m5EkN9'
    'PeBUxszs6WioBDOnI3RSaKzAiXMyTRSBwO9t9/HjNRN5RStRFQ7x0kMuI+qoxVOEbqjhYSE1FxJNwaeUTgxL+g1ynI4JVxPkHhzs'
    'IgeLoCKmgSGr53yOwL0TxOsgPCKQ0x0hhls7SxM/6E2GxlOEGf6UHufxqN/dZ3UZwQQH7PCjv8oWgt7WYneihTorvaSOtnh3Hed2'
    'hQ45Av2ILf8MUCAXddGtOjNKMPXur30hZIf/zx9xahrs6f1iESDAGarFWxtU/ZAwaL2m4QHmiGOY2XdpXLM0zNnKAWPTJpGcE8cA'
    '+wnrCvoyMPK1gwMMndMlKyiwZ6E78bh9RNOqQQVG4tHI6tVuL6e2rlhrypqkq1omplhdVpeyKItjKPgRLr8imfzeN90jN9+svaSZ'
    'vGSNFYtNveBNGkpElbZO6UrQ3yAA7xHOY4Mtkc9yGUJ5aR8BrCajKXsQxZwOm2p8J1p4DiWUCiGWE+LsSuI9TdHHEvmpZE3NcQH2'
    'R6Mz327EBPwORYriXSdy1nuYj2ig5WrDkdBkgxhEYNBqkw0P+AYs/vZSodvLxW1joIzCHVOXgYvA6JpzfLUQn4zFWa1oIPowDo5g'
    'nwgEBwfLhzb0Am6Jln9jqdGJR72XtaqDgyeH9fv1zv2tuv7mjYUznqPtwrV/W9S6cseBBKCQfsFpwzUC+su9va2mBUAW8mrC7zfW'
    'FID5ExsFoFbGShd9xUq2DmTMg16eA/YqPqlMqfC+Kr+XB5d3JrLxAlhHftzq46bktD4WeabmSJ7sEGXlPiFQhiadOdaY9TzKlk/p'
    'HUt8evp2geygOkPRtTorHFpTb0lZUV7DPBYv4CBwAfvGmUW0yZpdvnmFaYA1WUw/o6cgTsKbtJRAm56xCMedbgAAkuFVxenncP82'
    'CI0sjUT4tia48wOOO4n4+O7o5DPCeZusfuMtL9r4mo7Df/9NQcavK+Hm3jHGzaCyrULuQm9g5tuuNzo/D+GWD81C2WvgeGl8Y8Pm'
    'K9Q2NzcM0Hov1zcUXL28hUxLS1oY3HpwFsUxRuyygFdd+D5aiJBqi6+ahcVoQfmwhZUm/RabJLpd9OUmvePsf4hEAzUi9eMpH+H3'
    'shY9etQmQunRo0b0qDdJ+r0O/Trq0ESO+Ob+xz8Qae8s/cc/QLsN7dgkrB2x8uItTovSDNFWkOOmcxrEoGQpX3Uy1Qf00U8+CcoK'
    'r4IkbSW6ilMp98MslQ276cU99xJVugSVD0oJKrnv6tSTxUTBnVPjbcbuuPr0Zbq8nCwXUnixnC3MeqkCGCcZGTeQ4KURmTyO/V6Y'
    'y9HkNfIF/SZMkbRflTSTv3B+ECnjJ7DZ0nct88Zvepyld6BrKuEQtsYuQgprfQ9cLego889YMH7GDaBIR8rD+vw8L6QhweFsrUrm'
    'Bw/mLSMStaiho9JsucBuAoPFjjkWHMOJjl1Ccx8uMu8BoB6ZzDoCYlO2AF36+fvrlcbqbWRohgmuk4NCDP3a6WrtkNYSpZ80nt1Z'
    '+gmX1qt6M6pVFXL7XztUPxR0cLD46PGh3z5YTF0ftCLR6T8P2SAr7bIuXoa2ctCs311zt1DPBUkSZ95pmKpSvRf9XUaMqmLKDGd9'
    'yrItYgdz8H3EpgiTgIB9PY0BdjlpCT3N/uhpIYpmOoeSkF7EETLi6K6uxwYHgjSWZS4JIEMc9yHlHFhXADDi5lp9o1dhPrxrOeH7'
    'VeqSBzGrLGYS++Zihtwwndu85G8NzcJbSGXHihari9GhmtChYOanQ1mv5HjCtAftB3z2J9mI7iPEExDzCzAy9mRdjCQlB98vQ3GA'
    'wfpqSEbkSYC/k8bEFdvYKpF1ZSx5wBnR1DZuPD+vwGrOJK0r5mS7rVeFGAztP4NldprR8qYpHkxYkXwd1R7VWkSoLSHPF3Gfj4jN'
    'fFzHw8MlnFQ6rhjqAVvM0tcvh3Utlx+CPeUKj+S5vlXXaj2qtnJ4iExG0vrXr1TnK7f99avX8iGLf6PakRQ7olJHXOqIC+Hu1nKI'
    'F81l/vEPKvQPLvSPf3Cp/7+3b1tu48qyfNdXQLQ6AIggSNEuRzUlkSFLcpWmbMkhyeWpImEzQSTJNAEkCgmIoilG1FPFRMw8dPd0'
    'RPUX1Mt8Rv2Jv2T2WnufS14A0X3r6LLAzJPnfvbZ17ULLdK6OTw5HyjmSBV9GeK9MKBMHUz8ZYy/fJlNHMYf5brOPPaHvztp9imc'
    '11LFNLD/TDP+kaMXCVmwouOWOlCRzx7utZgCwVe2/lhqseZT6U11KzM4IiGWEzArDveTQ+3arnTowSBuzKUOEck5HZea0oNXl9ad'
    'oN3++c//219uUAOqo8EiV3xm1Rv0SkGGep/gSLpuspEO/9tEFvii510yPS9czpvoNYC/ySvWkSTIMvSLgyGDN6vQ8Q7v28iFAVFI'
    '2lOFJOmG6F29G+RZxGFGiceC/r4adOh8w6vK/lVu4ear8VI1IV/KURDycgIPLr82ZtO+nTIVe62sTNXbTH0B3++xQcIz7wK9+coe'
    'AJT5we4OU3zI0u8Z5LxM3WhP3T7a5gK213r96tXbH7588dVXSF+QzNI9Ve63XSjp7RSBDTr12I+obq2Y1jKEww2oosMP/vAvO5kT'
    'z82382touBRo19Z/w8DWN0IuYJUTFr/EG2ChqngvTa8yXblsBzSJKb+h3cDl1jEjRQKjrnw2yuYqpgDvEx7xhXqmohHV98H6Jbsa'
    'trWemtoYDobzAH6TLukduOczROU0W6iXpz8pyploHHsKGxouzL//tY8WNgBSRGnt4uc//23DFR7mi0U+MbV5PAL6qWpVwytdKRFs'
    'oHweLrMxXJIQcIpcCyAYqmDkgGNzjAwwWsoe9tFJyUo2zN+bkyenmAWjjMssT1Ejf38Lw3NZmoLfyjW/jP2tEHuJZ84CjK3tIjID'
    'OIpPgl2sNeSMkwUCUdR2Is/eZHBmG3sTT+dQxNcBORIGXpdsR51DoawQ0eZa4nAc/nYlxuUiMZnRtcGpyGUbcJMBFbOvv2CsA6YV'
    'dUgI2q9amjyX9iYVedwynvnl30OksdZEgzxNMvH2sl2CFS4g9fz8l38xk61sYnvyr+AbAQsFALh/jYHriytc+dZnSCv4kgHz8hU8'
    'o6JXHIVi0vKVFPmXkm8aYsc4PtrGDlodDpiubTIoNSxEdlPlG2H5UDui/GkJCjUrQ/NXL9VDKPrO2x/bMahmk1PadFz1OsvmESRk'
    '0zTQEaQIE7pqTl7mRl7QBaquCnd9xuvUZrJ5mXXvTGey36b0lI5LrmvjoQN+JO1B/2D7u9locfs7zLdxX0mTmsyB3R8CEfUbW4w2'
    'jqbQAp1bftSu4mFyAVHTd/Q7xy4kQZ2kyRT4ahul7pZxD89y6+5Zjuo4aPZ3//Cw5opnS192iLwZDAIO4sp2hKGzhkalWbGBPHP+'
    'Etb3jf2//zXCuKugO9bpjzuRVWpV2UdbhohJOqnV3rvGTvGefzc6hM3ql0jEJbtQ1xqQdtOxXAiq+MMfvLcryxhujD2n8AgOLSEQ'
    'gT5YUjdGROg9rV5rxODteTwPEUORgaHAuBsSGspuVAwMg8bJ3KX8BjFqid2PuEQsWEuT+FhoWBw3S60joRNig1eoGPOiF9PkZPFe'
    'VkUxWj7f2Wk9+HT2vnXv+stXL99awhN6UTVkiTtJs3GH38vWLZZzMtpatwUNAFCcf8aBu1aJsGu/9sniYvMNVoCqafAfnbEPvccp'
    '50FJlCXZ4uzjmpznMivpOJ+eFbS2B6OjXe4uRSBydzk2JAKsHu/Ftn+RADVEb7N6UZd28c3DO1GyPlfi1gBXZ/ka966zfAA1xChd'
    'h7EmbyPsq7O8W8tDrqzg5lnuO36W14EqGlnCIh1XHfekvWBSkEljYpDyYm2OIhfLEaugH4eCQrhmx4439de0S/Onx0FVEdb5dWsQ'
    '973MfL3kAHr0uFCfN49K9pHlqiStr6B/1ZOSVc+sK2zKlFu0GFLS+y1SatWh7ZCEye3LKpXeVEBC1bUKrFS4BWoA6up6VXJjz2c8'
    'eKUrb8GLqORjfbvh3N7J9xc5t/rp+Ghe+vWetqWpdXuJhLVbz1QaqELzJ4ODmDGwqJbGfKcN3f8l2yOP9uSdWPnv6u05OXz9gXH5'
    'q6ojNxLrrhgA+uAKHEV857g0H9WJ6DEXmQvAakq+4PwCo1CSnUjxNYbc847mlQq7pUTH+cVb/ltX5HHrnU27eYTZi5g0VNBlqidK'
    'fd1KyMxhPiBrY8Q9JxYi+ToexloYxAPmsSzMiEJqTeqhXLU5gs/N4Qe429zjXEWely5qi55WTQqZqnZFFTR5twIDNlENjUVKrlC+'
    '3FL9MikrXyb/uaqXlo410n3cXvvRstgwLnLuvBc56JAOpTb2tR58+BiObsIRssIbF38Wx+Gq1qXZi7x2Gj8u1ldvsrUnOrrjjERX'
    'PLudHVyou1DAYg8pTZE2g8aFCX+WPb2f870mQqVUM/NyVb/1pOrjPUxPcsv/hgcek4NQAgDcQIBv0tr4wn5v3GEqrYJmKu/u1vOe'
    '1izMcSqz3ups8DzvQSP/CgLNYLBRMfG34SQHu7wckXQ8KrrUBKEhi4YswG3BQ32xSE7O6S223VeYBo4QTuhUAbN1BRxEfrZchr64'
    'Ylp4enE4qJGeupIplgLa4dyqA5om3Z2l00JRzJYzFnY2s4KapRcTnWOERuu3gFcGqrrBiGoMcv+nbGY2GrQCtjYnUFqyCL2zFYjo'
    'kdSDWzsdBcdR+AgGxbIcMU0ISvEx+JkPP/9seKVei/ITu/hbkVV/LdJ5ckU+rZMs8mFH3iGclhAG/ZPzZP5UaAa9B7rO7fwqmYzf'
    'LCDqMd/0cfvetRmo30UW6jbo3Ua7vdG9aR9Hfuackj9ms06zhtr56RlCUJGcqrwbECFV6DU0bOdn3SNo3KtTw61ANvrIQ7rb8wl2'
    '4PmHt08WsQv1ahfRdc7sFTcGObZxj0v+7bcKnAt3gosMTmDZuwhhp6qp7GAAdJhu1Drbx8f3rvE9YPAvNjdd1hB+Cveuhk8f2iQe'
    'QoQfmMt/2U6opwxxW8X8pMcO1rR50IfJW7OAbX8PiraXIRP80XZnNj378OMsPftwlp1+uEyHs+5DVPL5Z73OYbL1087WP25uPz4q'
    'BpvAA63YzmpZicwI9V5tSg8GTfBlaEyTmc7OMN/1crVpdzPXF24ZmZRWLYHsIb8KK+fdVRKmH5+5FbDGNVOFc7CU58yvo6fgZjsm'
    'bXYrSp84rf5Yd+h8GfFmxm50K2bf1nFTbQ9dKnTmRqMgTjnb6/ydxlSN2VkRHG8TRcEJajof9xJE9VIVcrn2I4zraT5dp5eeeJ10'
    'P1IashtY1etWv98fuxsdPv96o6voabpkOWQpMtreyPKPu78sOD8+ET2XYQhchIsAEK6JChMOWU74+y5Zp9Kzq67nkQyxpsEaRYCz'
    'wzY4K3i30D0FP8hK4QeSp9LvRbYFQaXpnMYi2U8sIdTljf3ElUkwYZ9Xe2BGrsOLQYBqxoDwQP4+dKAnagqj+glOU/rrrtm49JO+'
    'x4taMBdoRAUVDv+wVJf0K3BpTD2nm1Bf9UlK9DRY6jmUZjuglyj9kBXrCTm+C31osrgZDI65x13aulZsxQtsssOmeeB4zlAVS77N'
    'nathMPb5g3SXTvOdTkzEQKgGm45uBbIFl4fu9lnWQ+ibbEoZVzeG7W01zADHfmzn0JFqzx2HwCp4IMUDj/T0UMXqPER8su2pjGm3'
    'zNUpRAbrTOGt90MKk9L+5JOWY+lkC8kBY0GcRPIFxwgp1DxjcjJOcDLQo7gPMY4Uj/i6QCG6WamWPeqcfLyib8ops2Mo5CmE9Au6'
    'bJUdD5ywGJZyb480cU9jRfYQVM/0RdFgQEBWDAaMXnGb4UQ0q3NtxAhkSboL4LGpdD/tQH8lDzpjIwcHPB6kEO4RqNX1jS9nRojr'
    'UriRFpH179pOKHXMiCpzi4w9QMS+91+gaI5h+YnmmbOEZDristdjPiMP1RZxQheg0wTjcHis0oEQtL3WRjS9rjCmeOMYznOHAxng'
    'sXLlQDIy3rKa0Zo5r7q49azpdntwm5vTzlV/MvIXJgdhmq+jKfcCt1d4Et2i0+tPezcaZDTlKwudQKzRtF2PVxCe/ouxcNGWAqcN'
    '9NLshGqxbXlXQTPwrOJC44w0E2Y9ePPw6Gh77/7BxqP9D598L+RIw5622t3b6WKQabN1c0dj0pKRyR5AYyJgDYAjU5h/5beszTwD'
    '7aR9/lCTKNDTdti6GfSrGNjLqVRUS7s+XJ4aax0kjI4CTzMzeYIHXyxPTyFjd1W5xPBNWR+G3ksF/SHfd3tGRAK0oaYXRREfn75L'
    '1swYM7x30Gvv4P+MTny626ETAcVpbtWd9zuf7/zqs+GvdrqocmvLKy2ZQxRwgedgN9Cx58JEzDsbbyGamVsmVpqj2fB+NQgQqDQI'
    '3cnnToiPo4WQuHUHPAFTDIbPHnzuPtvxsj+ytrKg/AR02nU54+E5kZ/jGmbx93ILwb5U7hpK7IYSOCNfMby9Ws3ur6PeR/z2PGko'
    '/GmoEYqrtDY0Ftr1hZigs6Fnn+02NKrphbgcsEQ9S+HUh0DfEX9xzxTLIfeW1iITr//Kf2yE3Ub/cO0H+i//ifvrXuy6NVz1/td+'
    'TPPk0nan74w5f2trm1yOWK7BwBD9YChM2wF01+K/bIkfEzkIF54Ru3A09zgtJDyH0oFB4PljmOdQz69X1qOnVOMxi5nMkqZejqoG'
    'UU6Bud6fZbP0rZyR5dk5C2FJJoRNFdLwRku1jbJsybcysG4fzUShZ8qryDI9Lq2T/NJNtul2UjPynqVynsBL2oeLAA0TWcjkrBkC'
    'gMWHFD0FietpCAhQPhPVqJyoC+SSf4C93lbeelsjPXpoxxRYcjqd4qkfhXTK6l5BFFKjLTUyprvR78qIAt2GyJC3+W8Xk3FnMopJ'
    'qam+LC13fPLR5SJitIn4Gu4DusDCARa3QkcEIeVEjxE3sLMD4KKRuzblzVbrwY2+OY581NRS5BiLEkfMCNPBBw0uPfqAPwI8gTZ4'
    'ygaR5MNE/oNI5hfZXp3sT7vMvQg2n3bPdDJMRzBTnbqUsxvMMnlMLoKcWVOHtANk1A+/71J9IP/Kk67rzlLH39DSkrawWq2dg0d3'
    '73ZtpODsUfn5YjEr4K/MNj5MEuG2cvdnV1trP0pa5/P0VOre3di/9+DRdrLfrtfvPKXNT/qD+jbTs9n12SudkCBQGH/CfgG1oLG/'
    '6ll96T2r1QO7c3D36H4Xsb5H33Uj92k8v/SzM3vA1ma7vsV717MHcPac7d48yti4/IHGs6bG1ZuavtQ6BQUHXuzHPMrjx1IIQtLj'
    'x1pIs7U/sFztFSysRTnYZWenczSSAfGn63Zms4PdbJBSJ2riGABVio/NefJhlGZyypMzGUUtzI+mB8bnSZcVRo6/6wxI5lDQjOHA'
    '/cw6PRcdn1M7vyxgyFQ+1fg0tkllMFd47/BInt3+/vj42GJS8E23agA60aAu5KHIgr1nRe8obFWr5IR1WZHSBHu4uTkIeWTQP39t'
    'HD8SSh9NecQ+Y+bx8rj7sOLtfuMVbZMwD0DSYA+9vrCDgKLPb+RMbXb694VWdDlBvu3Yof3R49YuKcj5LlJZklxSFYZeyDPSjkfn'
    'nza8/JQ9XDPtnaPi/uHW/R8GXUgB8se9yiqELrUfnc/32+ur21+3hn+KSPnatSvXYwv3p+qqRQbI/aPiYLtXFii+PzqU0795NDjc'
    '3BocAMtBdYWu/WiZQ5CVTGHlrvpTZdWjsqsWX6cCEBIf+vK/6qTqCPka3do72KIAVhowuNtBMB+Xj0IKMPnHLYcAopJQNO4PH44+'
    'eEusoUWC0h8ddY8+bHeDksN2y4k7oX5unGN8Arab7WnXwahvei1xxe32lku7al5smekdp3e2b9dOadPSkbvZf7RAX+WfOcBv5Gek'
    'yJF38vBElk5+RP4geDDfx1P91KBz2D6+ntvXqHJeqm/k6hvV66s8YKXyL3t5HM/v6l3TYXDfB7kJEKoHCrHuUGWLdHLr2b9FA1wG'
    'GnJQ9npXiMKb2mupiu164OpuTf83mUQ3QiB70ny33r6RwKARJDMPEB22Ykz8KJ0h2yG1zqfjXMTVCclkuOEWqh9AmJRXBW23dnHB'
    'qXZwT5i1kcN9IJV07gETQjXE1OOw9f5/Cq+nlGOySyyk3QCB2m4NmA2l/fO//ZNq2X7+t3+WdiO5xEkmGMRhPGFgRgeqX97U+OHN'
    'MFex74S7lJwOtJwbbZmNcUA7agbg9DTqYhfE5tZuoOygb9OB7udjxdodt0OTuL4UeEr2OxEub4Ag9SNsBfB28wVtr/0oe600PrdB'
    'Dn8c9NkvqCusg6F3us7Vgr6c9f5QpMweUcoHFDtl0J0fe5X6hTRZh/FPhHd8tD0W1k5WUGqBSusR/sYt9qMhptevMv0/VreJCUAF'
    '7mb1rRKd5oa1HUtlYY1aUS0uZ4XWJVVtR5PpD6z3HMG0/xgwjFdObzQ3qPk2k+NJJj4ojf5mDU1yagmqQhyFWUNfKnvY+DDjdY6K'
    'D8KRfdj/0EiCPpTuhW79YkAvVjBupmOQ92F+movbuGIWT9aWZUHhdZEdCUe+eZLx2f5xty6cl9BbIT1/OZcpRLAd1Lw+8LjImKR6'
    '4yK92lMPxQ1jz+l9Dhz2GEThNFTSWVRQripxl9vfb21tHU07QIJ+M7h/0D2a8sHBdojICRblQ/gMEJgwCm01ZbfmvcD2g/LgdwqF'
    'ZxboGN0MfH5+qublSH6o4IzJ3quyu7KmW1U6786+bhw2y4VDnw7twUCXCcUCqE9EpQ832oMP+I/jd7r141wfkrccvaux5YdHl60t'
    'Ed/2sEmrvb178a4a3GqPmczFizmhRXkTul02yFcGasJNrfOyJu+0ot3y1aD8Qrt/v+24qHfS+DvqGg3TvNfaehB7q5i7ykYVE2n7'
    '+43+/Y24Gk1MjspopCDQoLx46BNzXze05PqsA1s99AGdHsvn6ZAf6Qa1SqNA3+6AZ6yimVfvr9/TMdYr9emuq39AvaO/nMUo1bw6'
    'UBRsdztH/dwcsD4cSUeT4rx7tG2TkGryushdx8GhNVW5fdSfjLy+J/7WAvsXkeTsZH/NY/8yd6BoUoVaegyLSuNg27dII++zQgbz'
    '12c7NA7clb6fZvNJ5/gtiI26asHB8951/MFNy1ICFXkJFHSSQMXXKsb5Zb/1FEl5Wvn04Licw16dG1+r/rG54p///LfjaCoXOVGn'
    '8QZrTO1w4Ku2yVaV3xqxkVdAhndmYa2Ng3IAoWybQZ66Mql9H8Hx59CYqw4ajrPy5wH/K7WWfQ2jNoZXrgHLZeV2AW4NNnSYVnva'
    'n+WzehKHdBBvquHVN0Hnv7betdXAsxaZOMEMztPTnkFQelZQnsFrlFaEb1+/eJrLyZkifl1euB5/wrktGQ9G2dw4vnhY3uYG4qJ3'
    '4HZFr6XDYlKuDpKvygzjv5x2rh6sDNJ2ZXYod5S+Datzy2+xTPw2GtmKtajqzEzlDbcF0hmuxZX5wipBdI4KtCBAB/8CzhJakGr/'
    'EoWMXblcmt0moS2GBXfwaRXEBUcegdE90DXxXIL2JmX7ZEt94Dq1UOrNE64+HYk9VkOxmqZloiNiH7/xoFVhcOF2MmcY9KxkeNLY'
    '6cBdeEtPEnKRLueMs03NY3cG0zrozxkiB2is9dXQF1W4rsi9BQwvrNqBHfjkk1bHeXV8oAuF8ESdzsHeVks4y+lBFyCPE9Wrnqul'
    'xNbXtXN4PiBPAOh1MzEHPqcaieJikBkgcVPKRu0ce7qNPY3BQL+/q3CgkAHdV78IDnTA/y/ut1c5yJhgVFFsKQJwgDX1pZ1b6iqE'
    'mVH2zrWiZUshPGis5vYFg4RsbCteDxyU94fBYDGo67yUgGFmnOs4SwqhIzoTvR7s5gZpaCk+jOEAMkcxyaLdzD2cdZwiXAB6fOzw'
    'd05LqyhPqbZW/y1NkoVfD1u6SAj5erKQSRwuF6nMjB+C+mspg+VLdhrWxjzwVl0eUR55Mhg1jx11QqFPsEFAKvfV9t4p7YFzJ4Sj'
    'CfwJ6yXWxXKU0J+ArwCAxQsRKx2wq7nNmz93FnzqPfyri/SMQ8pnBiepvtlZoR4USnUIjug62jdEx3h4+qxpWHxTGs6HKCzFpc7p'
    'wZS13aVvTiVtyldqy2D3YsjomujxiemTa+Fp/iO5UoGR6y7JVrucvZEtgUez3271obtSDoa12KGJsbo9r8TUQv4QAlXmyehH6d50'
    'gdPYaQ+JFZXS2VJFXdo7tb1Ysm2VNW0aKwNq1PM7rOdpZM/ZnItkmi2ynyz/eJUYIFBnAgxUqeaATo7IDefOoyN1/lBGjkayy76g'
    'biviRfcqt0VhkDfnqTAWC8QO0GxtgQ7FQ3PULQV5xCEG/YixVysz5GPnFobf2ejVaTl7aUi/+GLkfC0dJhlzb6nP7I7TKXrOlB60'
    'Gm60KsoINTREGcVcAyEpbKEI1JJxg2QLJkGP5ITLqYKHgX8m4c8i1ERpoSgFQPNX8af5olPW6VaBoS6gViIilJYzVrXTBDNeDszC'
    'TBIBVbpad8nHTJdo2oSj5KDA1GEtppVgronPAGBVcoY3J/33VF1ftP6B4+y27rc+3d1pbemo77ceWNCXlGT++E6kTL5obdtHSP4h'
    'hXd3d/yCTMxhUb6prE3Zv1mk/v8WD+fJ4QWUBt7Heap/I0QAPyLlhNsezlMyKYrsbAp0l+tKhFslnq2kpgmoQSI96nm/dmTAv73p'
    'diPccPe4VE3JS1pv4fIFbGUehvt3ag7S8ofTMHiHTBcCPu3/gMMgbVpOyygIsIICl42+JIQDWYp93ZsQGCy8B4+rvokNAY7uJvnw'
    'yWAbclOjoiOS0GSxSTOUF6665pcjA9h5D9ckAzvoGw0dhQVnhYd83VdaqoM1YIrbtVBW2/HzH9wU2uZpUnhJk57vgKYfMxo/7Lpu'
    'rnxrXsTw9A1LWS/ps0hN+9iqtdx5jkrgFtUiXSuKqGWS1NoRdUpM+dZdaH1FiCIcXi3ytKbL3GqJQNHp3z/o7kFL2D3wvkLqQSMb'
    'wlILTCZhAtTaFDOXTN2g0wQA7zw4V1emPLhZxKRVY/gg8bsdMI5GoUjFNBHrTqHXd5QrwjmjK4X1FghFkAhxpHtotZ4OAl7RNL7R'
    'W1sDHFuTEvB65NkduYRr2CG9veVng2N4eOodvwPXfHPrne33je3nOMp4JIziN8IUyXGPgvJE3KECaT4RevxTCvLGmQbfQ/w8oXSM'
    'xBlpLH6Bm8slHNvj5XyjwJuF8RE9RZuJ+AAjqh+HZ2uAVVPuu5RSJWTpWeOH5xHVJozaJbFqhlajA+7vslHRqfAS4+QKccHmq6vg'
    'g7O5ullrrgZVLEqhHoV4KALRF0tfBFATIbHCj5UA3E41IB4ZhcERGqLneTZKfwvuphtpF1/NUoSD3ruOWRRTLioY1sa9az/NGk99'
    'cycXrvuTc6mLOmLeo4ZloiHOiEvmR8+yOSKb8dJluQGMHD6dJWdIQX6RFtw3s9SUtMjRtCfj15HD2bynMa827f07+Pr5uAEQYTRP'
    'zkQcnFdBOiA+vhXSV5ym84M+5J3iINKLYpIKiMZNqBDYWGsazGd19IVTyp3lRjm0g77skYDpFit7G5q2ciKhyhwEn8e+BQya+7zc'
    'jOfptBOp7GW+SVDTOT0tdKE3nubL8Qje59xeDBTmDO+1NuAwO58LqSsKWRO9XHkTaMrgsQrvDpQiWtcGSBsCWdanJBgOkG7JQ15w'
    'VjQl0qmFvEBk2Wud9i/T4UW2eJ2OE8TAU5mLdDDGk6rD8SkYI529OrCG98hXva8zEjTZNv7jE9YQXs84SBLwOGMaQqrV7xhY7gaq'
    'kU8NXqrV2UC4N45CPt/otTZUQzTagHM4umHwdKnlxA4QhTSICq1CeKTU/yxfyostTVWdGE6FnKKCyiGwJBDq1KvcMAsBFkUHbMWx'
    '0qsWGYVSxQq1qxId/sKDFfJPZI3O5+04HxjAig1QagR8cZEdk3FscS1jhliCJvVsrBpgVuao9o2TxYkJb0ARasqOHoQhtM5uKkuL'
    'GxviTudlR8OyugS0eKmppfrvu/B5oZgTlbiKSlyxhF6sZanAzZuiZUFEGKenC4YbvcvSS7YDIet+i39e3MzeH2MFZqHIFYtclYrY'
    'vedrd/vfZhxutz6m7cBOhS9cT+7tX/l03dGzIkowoOjC5WZ9gpbGx7VUrLKUukOgbgipWKJFdRx5NT1Bee/4DwxpptL6LwKciXeU'
    '2zn16WIaR+sudSWws/9ng9TclDbtzR3fjf82XKV4jRySyL8PWSmuiXvNoxytGVUpFWetL/Jt8e6s6Uoejlfgqo0v1kCmEf8imITH'
    'FyvRpjxl2xxfBKgj+dwPqnIRCENSECJEuMRFojwcqK9L6Fa7HOhs1J9dgT5PZoUBczKojuAcc9kq0upDJfr5EtCwJznKA3G0PUrf'
    'tdnAlAAfGnoKztgadKT8yTff/PD756/fvHj1Ejfm7s7u5/0HD/o7n/UffL77jzJ/KPDtN8+evH3+w7evCRnLCIa97e15ctk/yxbn'
    'y+GySOcnpj2VXb793ddfJNBTbquBa8uYtm3wyNsjWaVtoUFQ9iVDYWqfzGYUh2yK9uI+9Vx/9xxI/UkyfaFT6B/ZlML/kE9AenV0'
    'L16+efvkq69+ePP21evn6Hu5Q3vTfMs+3soRLCjdqnhBjPNk9AS9jBJF/fbVm7fOiSMagWpaklnWaW/Lf7f5qt2tmPV4ctxXfbf8'
    'yLpRmWkhJfHigKhwVQMJlL/QrKvL5k8PoytJZi2dc7OC5pVA1FGBXAjPZIuM8xnD7bCFaAh+B+16te6oxi+FMv6iCn9v3WuqF1Fx'
    '+uuZTEen+loIds/0+9b60/NUTnc3kOO71Sk1KIr/AUcxfTTaM9BHIpnKqk9HBUMzgH46ZhIeZtGDPUW6viSvpO+IQCGLDJlVGSZq'
    'uMmqyJhtM8SGI5oGXGTgG+GMhEeEIuyFSFgdWdMf3jx//tKJex0bZ+G+Y0oN6YKIO+Q+GbmdLfYUYpRpHpnJDqjUV8DOkEEBHAj8'
    '4NYimwjn5tVJVuWBqxsbqTb/e627/Pj1ctp1c/zFYkqxzYEaAnCknRVb0rIHmolHV1RG16s1oyaI+DQAzMo2hl5OeGDn+5WG9zpq'
    'XF1gp0qqQWudYG98y0J20fRau7/a2fFw/IsXuPKEM1jzwefQbX++s5N+6hbplPLnIhmSadOtgmcjobcG2K9r78bfQG9sHraKNIXu'
    'TGr9vVv5xJb927dPEV2mBhcspYIzXQI3CghSey1Po3f7Dz771acAm25t7LZe5u/4aiNyd4wP1bte2JXtdtXxEc7jo+vPbrpHfflx'
    'NPL/bjNlCLzTgjvZJOymTRd3nXbwn750v7MJTVWPufw09femJgGk+lY2TIqSphD2OfTADctUIln6UvYvdfYTISwiB7YpJsnfV2ky'
    'LxXA/PxR9j8wkN4+hVbdvJdueL2oIDrOz8wZREl2/DRyycCu96/KlK1Mw019gfO517oUkZAAY3YFIVkldTHmX4Z4T6M/soWBaMMQ'
    'cCHeeWpIZPqIl7o7jtoPkeIwCv36xfQ0N4bUXYpvFqhVASS5RaPHmAZoZLC1NXmewWTLjm2fJhnQosrQ9P4YxnH4i6nJeI4eIAo5'
    'PEJTS4Ool7IRsVjkZ2fjtNM+T4ot7ZZ04e7dMJbuR2+naNxyp+j5pADM+2T1tffLrzR0ncrEaqvH7tK6dx2euy9vAGLE/hBvWXcA'
    'osU2fu+uLXe9u1VWur1BQuejE5+eC6cnXH4gddEslW8VitxrPUfkkK8pMkSB2ZoCgENHGcIPr6yFN6i7A5iMAOtuPnxtmR635Fai'
    'srC3nFXDu5qt3Bb9YjmZJHOaGttPSIjcZshPWwbv9swUhtaXs7zc2ZkIgVKFnCB5U24IbF6086aGK/9MpCxwhbiGfZ2rcZ0d3CNF'
    'ja+FZjg0Yq32i0ShlZdTu4CiLEuYWWSwn446Q1k2rIq7wxb+Rf7eblUyljh5pUGsPSYbct1PNZ0Us8Qk9F5lsmikQZgth2MmpKLn'
    'KqP6IUu4Ta35d/uEbAQDUWNqpQH6xVIsAb1DzUYLKx+XCBp66AkXVuCp/RELMD//+W/tVR8bfUMHvAKPFZYkoNaTeapcH+MSDlb2'
    'xeUX2PiD5vdA0uCcl3R/w3vLyswHZhQQ0DjVLxkjr7qPSHXBq8fRPlw2VDHkZzWKAOuOu5KC02pMEhR/YtVJlbfZyTjFiT5fU+z8'
    's4/RhRnxxm/ntjaqkwPgzbfd2/IGjVmU1DOKONJpTKL5oZHokihRKaU6iXiz15hQbyDXwK1VI0onkN2kTKXD7RfurheiMXLnkKmq'
    'zIB6XvkidYSqmaClZtNXkGgWkXVzFcvhO+/GYzMLVlRkVnYPljeaXMFvKygwsnxZ2Ngsa120X8Mmc3uVbM7L9DKFI4GjA0GLAWQM'
    'mFaZT0qTS4Fuh5NBTbJjgaY5Znxq+X5qGEBCuNN5mf0IYnacpLYqYetJ3T5RYdD7i877yTuhAIgKlVM7D+61pdymWplDFUqh+69I'
    '4JvcvOhV/8cinx4sHmPDkc2VywAGSumcsG1gtqb5FsGQwIN2WbwTc8xzvyX3S1J91D2Z8sq8xHLJJJkunfK8wv15UvmwLk5V5dIw'
    '8PKkG7RkzGmq4dgrZeZBGLfdjGfxDazoiMGbsdxNVNfmBUpyGuW1pL1cCz/LCuR4Rjra6hUZS47VGTB6r4pVN1NVC84tLgA7wZVZ'
    'vIm4cN9BrzBXznvjqwRpPyoahkxOCNVxNVmgR4ndLMzZCVExkSjoMrkqc+XRFHAhcWtoFcAwqvHMt2St9srv41VMPsZHKdRn6Mdv'
    '8lovbsk5VeoYZQWO7Ci2RVSK1I0VoYDMUUOJ2qGKOK1I0HlXZiz9VicfXO7ERy1SVTxiaokcMfOpStSyT7du8kcniZoZyQAYe4S8'
    'IzZl3CqyMARKzQECS4lDFjOEHZTDlwG4dksqV9ZSbJ2cz/NJmhd9eJsfvCPVe7ea2CkgU9mZJlnHlLR94aR/rr7n0hErphYz+TuC'
    'jUILA3QAVntzodtG59iBh1KNn6fH60fTRmHzRHCd+MiR8ttW5PEWPCX8WqxrSI20V/Cqdd8XKu2PXHKkFL5DNKv62HCRJGoGppju'
    'VWlaaXvoGFZStWrWVqR9CSfOtfaxyeDZkW0P9ttfMKsuZmAXXrWtfR0D7OtdP5LYgP7wo22/9YOkXvSorbjofRXeauSjlMJOTt0f'
    'sBgu9i4re9lbwl2XKP4sN5FHaLaSceK2u8y9qgxGTI7TBH+s66+1bDRxUkN4GC1AGeBPsft+vVMC7gsQa9/IJsuKVNE0IkXovIcQ'
    'RRd5YmqvCgOgxKC93V51sh9a2umcmc+NhMxdDFRwnQF6+7ubNuIWmee7YvC4uaN6YlBfEXCwXTvBf8jT1ch9yJNoKRYV4hVbdzO6'
    'Xn0HcE4bbm59fuOql4WHSQFqolrt7oR1pFCmrmvQgY2XZ4rhaTFcRL5hZaYoiyoyLyTViFEDkPZPlnO4Zb51uYBWqNwtsiVo3UOn'
    'vRGk1uWYbXRmUtNZOs4EJg6385nycmuenZ1DVTafIrw+Z5rY1mU2lfE7jzfnr0Xu30q449ThaUEzysjAJ9EXivKFdg3fwC7PSFXN'
    'e69JB4kda75XtrAHnC5p6EwkWxhVvkBAr1T3dJzJpL6W+6MDRfB1i6PaazFo4jukFevZeO3Zb1MO+ybSRX43T2bwQGY+M50Vc+ef'
    'JO87D3Z7UW2tLTkPWgYpTkK6subaLLtoU3XWEdRnpcoV3twxREXZgK+GumE78ZR1EW2Nx51obmThGV+xXPD0feRDnWRQg8QFXRWK'
    'EtwLT75kOM5e67Cti9EecEvW9V/z1BzuS42p2dd0pTzQVUYaWVWFYRRWOikuWskZuCSa3ZwthLRXKW+ZVS6bjbiDGFCShyaUEvLJ'
    '3buNprmSxbhqu7XYy3PmFvV6hWCRpiTjn3ubgDpQq19waegMT1ou3H7BAlhNJdMmGnSMJH53q6Ub7xzfj+KqIGYEVFnf8UQXqjk7'
    '8LqMCpN/0HqheXdBJMjDMGW4WUVdQKs6atIOZkj/yuBkC0uWokxsrC5zGrtbtytrXfwnNFtyV7W2K1TaopJ9WHfgqKvMTeaWyHQ1'
    '9fV2N0yzMdO53a5doGhx0tHd1kt3Ano68vK8BY/AsE7taJpvW0N5ytslobvMuAUWNHPOGFWHSOcIU533ldd4hSqsnMJWU60v86Yq'
    '9bw3WqlLB10+fVD21FjZcMWvR45vDsag0btzkc62hldb+FdIUVFAoIaX52yOpE4n/vq0ZEMsJ1RPeVBs3twSYzDv/BhXhOrYzlOX'
    '2LJAU+QGUydgSM0X/hTkp6ea7TND0HjKqtvvpGVq7BYIb1CGoYjvc61oTGKubkMJ2jmVyySxiPGF4vai0inYQdl6OHwIgwYiOFMG'
    'yrQIcSTGxUVG526Xo+g0Tc2N/SJF+4lyA0xmtgyOd0pw3377dqUHj5v/duR3yi7BK+MalR308Te9F1JirFitz55/9cPvnv8BfpLF'
    '18kJscb+z/9TRQVFtLZrf5k5+NzjR0OXRHaZIYnwQrFUXUn4JTOKBIU1s0UM1uR0BvjDcUCWbM7yKsRhx3QL0p2M7AmdUoSBD4xl'
    'k8rh6QqcLue0P1Oxihj/HLjNTDCVU17iIpC5Fx5NOCYUlbboYWDrxGRHY+bEMmzk9H0CoKWIYZOpfZMiF2fFkyB0U5itHcTm22j4'
    '7GHkDc79ozlBRp0Jp2gSUoW0v8bVL4udMAVfqMXDsAC4EyHmlmQJWZKIQJMVr/N80ZmyRk7dtD5jcS1Bp8M+3dr3OA57oerRkppU'
    'ev/hQ+vuJN4MXTdOKffNeb7I5e6Bf19WRN5d6KamSvjOXAZ4xkHm3IMJAif0ARYvg/kOJoFCUxsYlFh95h61Pu22XnbwOU1N0nHk'
    'ovIpWdDyYe0zRcx8gSFFECtY4B2ig8TLrIBw6PxXoFrso6P7T5P5UPbPKMvfy/yUusrFGq5erEeyVqWOD0sdlzYPP1JFZRAWu2Nh'
    'fRaJ031YC6PxsTLtJ8KVITIHtNAOhQt6xgFT0o6wialCl8Uk7Pk3bzAnUtm1C15qf5eONUVeXrmS2z3lFRiR2zGY4tk+Lar+1rlM'
    'xu66MHrM2HY778YsgwaP8h7vEj3NC/LWUNMZR9B4KyGA3RRT0nC4osoXkcqU2gkSnMY7KJ+epJW7pw+NDDt3lhOARIMThALBq02H'
    'gEqTsTpZXIhYUO6To8WLbLax/2JhgUTkq1oPdlqTbLqknt+1I0KpNI9xT69UnvD5pe5dL4W/+/tf290bvfxMu4NDNSZH4nksLXog'
    'JZ08bWmpFvmM/Ttu3fRKa0xTKJmriacKgI6H8C+vPxGqjGjlxvV+jvU0VaMXt1X80S4lrUfDfV8vriMn2k9EgkBWxhdQY7lZLCyH'
    'MiHmW0NECowSGvdk1hSfr7zu9KCUJuI4EbYiOzZSV1tixyK5cnORnXDB53DaeZcV5GHov6gBJo8uhqN9Op8/2sZP1KcEds0iP7VY'
    'lhDz4oNZ+lrjm/PsdLEZ12uT5ZO1UnOejUIC94ct5AZX4P1LEdgLJHM1BwWup67MiI5m3p+j4cLzFsiPX2mELCrvEk0wr2S0tD2G'
    'pHUr9sd3bgf7LeCXuBfP9NtkaPMBy6zu4RcEtcBGhg+hrLGi+2B1u3QujXqEyw4nEodZJru8R95ezXQTEHCFUBGNa7xqOhsv9wdN'
    'EzSB0+EwpJaKZsnM2uvmyQ+mcYriTbNmkqyd8ixNc2O6UtNW5PVZ+h3CRM5yzKJ3OY5IApHjpH6h5GkYI5pZcyBeIt2tYxeFjmra'
    'vBPAaF9mcI6nX6GLZkXPNEep083NpfWh0dXbLsyn1YX5jYgqMjZe77fctg5HinT5HGTZj0J7lhGORMQKPd+5hpVzxkLi2PJGC1vc'
    'r4pOLJxM5/X1wH7CfF/mLMaptrI+N6G2tWYBvnB3v3pPrRoI/XtH80R+DYnk4tEAPQaXG15E5KekyrdYHHK/Qy8qDD/C71YX8Osc'
    '96LuHTQKjheQFSmd5qkBvN1t9W2hOjqux89/+aef//LPP//l/8rBsYXRBIxIJ4Y1gnLb5sBCyvRKC9TdEgvXqA0pEaUTd53ZN3Yj'
    'FQEVqfU2xyqri4teXLifcBTMgtrD+1EULOlLaaV7ui4ny3khVGHMuIGQiRLrZr6d7o6lub/KPiGgrLSLbeOs52qUMBUnNn9yWk4Q'
    'S5podGW8M3jN7Vmal5b6ARYhLyYm9rlhyqjEBH8yCkyHijyg8iqQD3V7uM3GGqtCFrPugaxYO0ySzp+W+rWc97H+jjckstpWtqLK'
    '3sYpyH7MV+7DoSv6yfBblmvckUY/PMtQoRn3rk0PcBMRfi69DE7Zuy44qKJEZU3xWFnilzloMbZmtlBEPZZjO08X8/HmHyttYHh6'
    'JKSN54FxB9crb0x3glLTVLnSUJfyOa7GeTqi2rSBVhjCFpUgSDXbVgN0W/E5o+ec7Np6wCymkybiT7p6MVBOiToW5BsU9j+AenDL'
    '5XFOqCuJPAf/VIe9p8VPhNfk4HW+IwnIEX7D1CrlXmqZAXNUpS7YeMZVumu9ee9E6/D7cPGcZe8oivMmt1tEBFNH5kFbKOiEKqKP'
    'OclqezvPx+4uWXGB1QkFq3tm1Y2WmjmQGdZtBIE3AXerewq3pNQ/BRVlTnXO58hJF86NQ/tG1TyWx3C+YFZEQBvUD8pkkNAxeGmR'
    '57fYjrqv6nRgnpyp5rOwm+nfdSGxmtLhB62f57MWyTEjqOI1DpLNliWqzhZKz2EiCAwk7/bEBd8rhcA177cthfqEgkUjtahxcXbt'
    'y62V6RUykSV6B+jiJyLtb+GppZR3owGZIBA679GzcQakNdIdhonyIpQFgkDiq1D+PWIHKdFnvJPaIvUmnIvZcuHvp/R9crIYX2my'
    'eLZ5mSCTIAl0ELl0020CfYP9wVxB5vPqEa/7zSJiumZOSugF6WS2gBQMYbMqmNjqYGCBl/AcwborUrGRfuElaflHf+k16drivRgl'
    'PPVv9G6snQPg37SWs9WEFwVAaU1tBAeDFWehtMvIqspZ8DuDOx+enow3w/6fz8EyxVtxmibYCqSwqkChgmY06ukeZCJQujd5rXPQ'
    'vhSyAfQ8wQ4yj3eiSlpO8SWiFuhHhS5/p6cIn/WijzD8SBUjI8FdsJzR6sF4BXaxuIictxqbM/2D+lJpX0mndQOWGluza+Fl4Wxq'
    'rDUZy5FV5lMmXTiES6ge3OE6SxcWHKRBY5q6ANRUuM13mlq1WIiQdnZ+m6t9wf4R8Cp6yki1UbQ9Gi55yITFyk1WXMIsln78EjcG'
    'IHczbcImZ6ITHsjARrl3vpJ7YjxM5l13PUPBo+V4vZSvQjeVHyeqv8FFHDEWbt2hhMGiW9/Udlyh3qrsUpWRiciI7Muwf3F2pnIo'
    'YRY7k5tpxl1uU9g6TUZKouQInNqlOZYHl8l8VDiZgcIeJXNtUagpQetxo3z0WODUvtY+2RiKWOtHhoMTLlS8sLNqk2eXgxuS5u25'
    'xb4iZFh923wJOC+id63cOadfiLQr5On0BYEY8esNVNAQgOVldnamv94AHRE/vlQARymSX7KC18JfLFZsvK9gPkxg1QJjlp/Axjrv'
    'xZsKqyR9LJquhr147yzH+0hFA+G81QnM1Bd6r3Vtm2AM8esX9pqZalxVzGiDlXvy8//6Fyyb/bWJ39g1hc4ADveQM8CBNdfxBq5D'
    '7kOK1sN9QklyzTuzDPGgw/x9r5WOx9msUPcszY/CBCeJkTT5DkY9fMaWHm3LkCO2l9kHSMIXl3m/VWnddF9cDJvThVMEc5/5g8Y9'
    'tsgN622V7qJ+UXLm7wbIPrkOdbr5mymI9RcGrz8xntqm/Mb4+8qWdBbp+hbNnoxG8Y7LAA8qWzF7Te+7VQoso+DUX6HriZMsYp1V'
    'RAodAH6ghe5JdoKopIR6O1A/mWcbxM9//luQF4b7JCa67jXpoWtlwICxCNh64Of7+0PZ3brutkQzaFIs9dd2aNi27I16JhYfYWtz'
    'X4u0DKp5oIAMNPK4wKHbbxHCm1ZtKxDsVnNH9rpxCYFU6i1NQi/UDKBx/rqZexWsrJgX0JrlaERrEWmQuw3THDlCmq2qlld4SHLp'
    'AA6ZXLiSMfg7onF5/so0JQwv1XVD9WsWxWc5hi9A4Tye4VkvIxnuf8LNY/2iZmyLT9A//nn/Pvp4/z7136478vzwEGauwcBJUIQy'
    'q8lXPSeDEb7clV2orMftsNci/Di97MzztPQpJnfbRFzwawWteY74XKkJAlQsOVu1szRlDNhBdcyo7zSPx2s/o5Rnh9/vD+7vO6Ra'
    'Z9Cv3YxCEYIK4zK5Wqc5UfTh/5CGJN6ZvsLy5tx2GxNedqfSwULlxIqc1lPWStpLRqAesg44H1iOCWaaqnKFq1iewNcHo6tsdjXT'
    '2a3DetxKL6domecJrp3xCs1yuJEtAmZjfVk8UDOSKPVRU+zP3cDCWBH6Za6prbp8vPbYfzLkq9cOsKtrJK7q2iGPkPzlTT5dO715'
    'WTJBrbFYUpS6AzP2yPx5gAkDhiAnjqwz5M7BXQufo3eHKiGH+1Q0mv5JmYJs2rNrmgdG2NuLNYTDuBjEdNCVKOLK0VnovRy7aVZW'
    'U5F4MV3vGYLQ3prmjw3H3yR0mA46+rTr4Rwrq0f8P5r4L50FYf0SXqxkLwH4ivwC1ep6GCi9+UYZvAMhzbvzSMxEki/8T4+Lhb9W'
    'jklle9hmGKnmy/lqyMqRlOL6NP1UriBF5rpPOBr13G/SaIncWxZiOWC4OdjF4Y5q6aM1WhOH4h+viEfic4vSdBzXftDa91U3HkbF'
    'r/z4SRTGrSKtWv+d4V4Bds0fkWcqKVQNdkDux6Fwlp15ImTptcOIfceiBEPI9DAo+cL1FMofFZTh/CO3sjI4pgfpV7joxOCi9yKT'
    '3+HOgDjmSLSOf28eljAvW25Rqhtd6XVAIC37VVAjvizSNRTKKb2VxjioXncyDO4S2KKxdE9Wq8aP6qGjwii5Umwc83e1AHKRwHuK'
    'D9xktnMYqjWcU4pEsRNLt9RxQ2GlQ+qjbD8gsCJf/cf07jUrkmrBithAiW6tIntllO1oU5ESWipqvQVE8Bn31YzKn5cMROFPn0PB'
    '8CMbzLwEmUqmlPSafZGGVI80b5NX05Tu90HoKUDv5frwdcnSYFWdZ5xpCukMRG/S5RQ7ipq4intFr3VynoOJlVX9OnZn6ilzmtzK'
    'uWSNKihbROp7Srmm9+ai91th45HiOxWd2l7CZg5DXUck6RQUnIPWUEVXotla76uqMphRspXy+n3JdBON6/eESoDwJQ/M6TiHfsTu'
    'FBEMepF+a8wVUW4Yh5WXGUwFiGwHdjEU+vSP+/iifllpGCvpjl9BF0iY61cvor/GKsYAO+a49II8FNMFs8e3nsHsk8R5apruS8os'
    'zvRzWz4lKzA6czleadumVBDMk+V1+7j+/iP665ICgU2FrUovIo0yCP5GKgNQFlxopEEsaNEMMFNljsLL6wk+l4JXckUNm+ymvv3n'
    '72e0LarCqa6bRIMYTmSspeJoOVtHa21csW+UBf2EhMDOncYEl0hte5bnIxPv/7TkhSeNE0b54xpQzNUeT2LdcM53jDCrq0j/mMOI'
    'SvP5tHJOs1VazXvXPiKBqiBzycOc/ZTnEy9CFyfz3OYXLL9jGzGPZ2oxRTADPNZCQauDS6neRb1gFa1VgE/aN95VR+2wq9dd9yUG'
    'VpY8d5yKCh49c+earAKE83YKdku/Is2bwOCnp5FZ13vxRu5FOjn0CvC1Vi3SVaLNMo81DwV/3zRLldHSY6y6HzBDoxWSLAM+k2HR'
    'UdDu1rY1Jj+3kA1pv7XT3/kVrm6WPL+a5YuOQYJvubLvey2DAPePrrpMRtt1zQdZuNEFOYrwKe1FYThAs9rrmEMajHkBe2dnBcJE'
    'BBFBTmQLfTstEnTDGtH7BVhBCFp03BYVPT4O3ywv7Oda/+A1W+I7sywnrpokjvPXoByN3Udz4GDIjBLotfE2LymL7oIfU+ypqmSS'
    'vFMyvlq5PJQyaaxd5oMnxcqjryeopHTHF1Wt7xt3pJT8lRwH6acg31nEpK4CB62k8MoMsiTAGmGrLu4gBMQyd8FJ0ZTfuzZUl2NT'
    'ZmpXEYLX6Amvm0MBtsuh4klxYdoLbBYFrVX1N0g2vOjGpfEU1X4XaTKHMevKLbdj1Yh3TXVdC+YMMHwescGFTOzRTwjRi15nmhXN'
    'sQ/AcjyubDWCSDCKKivUthtgJLJiBY5Eok2NiB7rgPDYOFyTgARUcCcRwndMJK0iOXWWuZvmTf8HOomhJpry3XQ2Doe98NPnlO+3'
    'uPZQZf1Se84cgTUORh/fnoHR8iVFV5qqxOf6SoHcOSJZyF+D1Y7b/ZuXv3FqclNyLSwI+LO//7VV0KiDra62EAD3zi/C0YWHi+o9'
    'F8jXYh4a8VVYts5J56RNi5lQfhbH7juYIr3LVAdHjC5Tv8lzqFif5SfMbSPiv9fDQywmGJBGULAX3P/BZ031Is5hrcF8Vw6SgMue'
    'Gn8z75VuqnS5qGfDPJmPegG6lGalW2wG+hGkYZHrPlsyJOEURul6kijUY+Vl4ylLMpuxnAFWSs2MiS6WU3I1kzyfRnRH/TWYqmlx'
    'CexKXWXi7bhOOaKgDI95oyjboWKg3DuntzKHLziA6vAdPCToV5EuNlYNkK7Cge+923rCYDLzdaPv2QRpbudNO73i6J6MRkXkd1EL'
    'Y7D3hYYs6Mi92xjFanq9aGJocIXVbR5O6xuAMJ/IrqqTe4OsIMWnHcvkfmHEuNc0z418u7r25nAqF7uzKAW98cpqsmE7TyPLXdpM'
    'CCPPDjXQzu0inHqtBdXWehmN8wWdNU7TRL1GnTAUbxNoEHWfY0sM4lBktPbWOh5hG97NL97mr82m1L11wGkJWkwvlfBX0BquycA2'
    'HCfTC80LNlaAoXqmshD8uDp5WIiLxDzJCBF83NkpJ3iJX2VxnDCdDh+HqMjDzKf+YcS2QtgriozDNJIX9pzRmIwSF+66x8qoFp7u'
    'cVXfpAuoV/XsWooIfqjghIr2sgYZwIeb91oGUp51q0gghOKQdkEURt0QC61IsHiOhT/oo9dRuqHTCXp9rhoDFfEWufz7O+iSz4FZ'
    'c+7AQBbIHbEC8E7ePUU2uRrmB5umPltIpdt22BkzunyDn8FiINMbAGZusLPvXftlcFonkUlujqWADtHH8kuduNH0ry7JcEjKIH1S'
    '9CXFulG15ONW58HOTut+KxORp9PUTpcYN//Qjqp5C3LaPDRS2rioAp/EGdJlirXbhlMVlX4G4MluHWHNd7+cUiLj1bMTlXj+XniD'
    'SnvxlB8/Mgqmqcqno8cbRlI2lPexv4RdYLn9ennAg8eOmr7osUcatvBwDXm2nr3kRFjOi9fpn5YZfOwKAgIosmAAYdhTLJB8KizP'
    'copIsULDc6k+oTtwwdMDlZ4tPRECNB4BcGdTxrKv3nq/8wSY0Ml7rdpGeiN9wQubZKArf5XiYjzLianMAT10TUXYbnfvsi7GEMOs'
    'W6rZf+CggstfAxg+D8NMhrkyzifJnN5PbT/H/K6OZu/Qwnut0ItqzkmkcjsN4Id/WspNqDqLfP5kPO60+7JeW2ciDjLb4LgB7isU'
    'eBjTGmWhMOr4TwaWmg9895d0JKrEJ6stdYcJP8p9sRKWNamvMDEHKwCGD9bUZUCY6kFAvSJurS0wxHvGvC1nauXk/jcgOanhK9mw'
    '7Hv5riHhAKxjuGNxR8AVVi4ObhfgMOCPsHTRvetfQHkTEW5XU/iKr6qfsoFAUixBTzigSnt4D5dXwmHuV47TYfulsC13gZeAT/nj'
    'N3CZXfDnN+n8VD6/2x4covWs9Q+tzwZa+8or42UjMqE/aOVSdTTFSi0Oi7vh28qqu0PzX35QLNMylgFz4paGdz8oVDVRzHVgOJQM'
    'Zd0yy8JU5VABIrO58jZx9hjbcswuowgs3xHGIvFU1OugnR1MfVINu8elASEsfkGx/2yeXmkovqrzHemmflWB+O8YgKxnh32hywR8'
    'm3nkUGrutzrfMsaMgAb4Mb6Eqo6wmd0Im+Lpq5dvX7/66g3ze4lcSGsIzl2vZX+qlcX/mU1nUB071WFsdX9YOpThuEb8HzMrH0YE'
    'SLm4PrVkPciI6DaiGl5Lr9sDZxxTSYz61jLd68Nk1/FZon7BLotHX8nZTa3E4yaKZ+QrUZyswgEKqEedDzwI1IvL3POu5vbQFwwQ'
    'PVaR7AQE2aSjqDeqSmB3cDutJrXYXbQptrWzRBtq+qhCiPILI/EG4Yu1IAEIVztQ+cNsyAd40uE8AekA3umrroKJ7g58xK84nIf1'
    'S8ddtTja+ekprlrricKRxTRfOKYG2eoXSRBO5omIQxX5q9f6tSWP+sXECwNYR7v4fgXHXwKE/S+imA1SkBYsC0Jl6ceg9By9ryOd'
    'VuBN+0ji6NJe+psU+8ldouWFfFgiwnq9GSF2wG+OW7992/Uqt2pVPsW+boCRC/uqXzoKsiin2XzSEc41sUB2R5QPjqZHU+Ku4Cmt'
    'jcikALoM11jZlFMHzxMFSDnAGdXJe5Aajzxz0AA4s4GVLk3fnXhMKrLU5qmE37QqHaZUG2XDvDsspaouN2mp5nwqTMTFU3FnEo9Q'
    'IRz4t7muBnPViKhjJuxOc/JknY8asN6XzHo8X06ZUF7pppqdqlr4KygczeUnvjEt7p/J4afmTuATiwODzuXCC1yUnpToeTN8aBWe'
    'joneFPytsbw7Xo2KiMbK6lCFdzD1VCd0W0Tcll+azxjzGoM/F+WMZ2t6ZKeVLtBFf4o0Nl3TIKnDKICQi3I38PrgIKiY2C/YzmQ8'
    'UGcV/UQWACF0Xfpg/JSCZlkqWDBW1Pd6xW+v5bLEukz2coRhxuwYiuw8LYQOvo3IuI41ft44xBV0Dd31C8wVS5ZwMxjBvAg1WLeq'
    'znt4x+fBDY26EJamGvAwKL02/UeDMuMZXjhOw0moURSuZiE8PQ19oIFuVbN3R9l8cdVlzmk5LOHksWWn1bvR5obpWTat4z4vp0Cx'
    '9NkslmbtpTksEqNpwrgTZU59eOfRdnEyz2aLffk1zEdX+Bcw+ft3/j88INLU'
)
EMBEDDED_ICON = (
    'eNqNU02PmzAQve+vmHoPDVIx32RZQQ5VpZ5yqtQ7AQPuGhsZZ0n+fccmVN10Vyqy8MybN7w3Bsr5tYfLKORckcGY6TkIlmWhS0KV'
    '7oM4DMMAGQReOVu+qktFQgghT3GRwwNA+cn34cfEW6bhG697XY9QTxPwRslnMAMDLn0LCNUr2DnAd/F8HU9KYBlXyy50MKPwbLoM'
    '3DBQ0nVj6+cZddx1Emf2BeahbrnsodNqdJy21i/+qFpkNw2TBnaPafPUdp0HRjmG4P1g7ihxlifs5FHwfTdIy7r54JRKwSWr9XeN'
    'OpbL24oYLhiBS4TzE7iu2yVeM9wicriZLGejJlBdNzPjyjb3GyWUrsjNFwneZ0d37NXixi6Dt76c62CzXWrWGMD3E6Mjd194a4aK'
    '5OhhYPYA1lgjJ0oJdFyIipy12D3a4bxVpuzB6FrOndIjTm1DURu2i2KIYpp5MDe1wJTmeb73tqdIJZn1rtULQ98djnjL/JuLmEZ/'
    'IDtGU08V0eos2zfwL8Xlht+mbrhuBIPG2sapmuu64/kkaPm9ckIzV0eTd4w4XBnFX/V/Vfa23+kUHz4p/w9O+pHYVJsB8KM64qkW'
    'PzMaHaOUPkEU0kIkdO9HNDlGiUVSmooYA0yOWI5XxN+gwiLYBRnNoNgUyqA/PJT2tz08/AZluheo'
)
EMBEDDED_ICO = (
    'eNrtnWmUVNW1x6+S92K+EKN8yIeHl7WQsUERUeZu5qkB814n0ZWlGYAGGhxBGbqBAnpg6AbtRuNsgiZxwsREEkTRICgEYxBDHAAp'
    'KiAaoAfornnab//3ufdWVVdVd1V1lQxJrfWjDufss8/et27fuueevU9p2mXaf2mjRmn83k3rPUbTfqhp2oAB6v8v9NC0FVzXrZvx'
    '/ys1redcTfvud9X/135L0/Yv0bQrr1T/n/sN7r9a03qzDlaprdRUvby4YsLtinRfp2Zdq52Z2ePiYMa1WrZeZ2b1ZN97yrtQ3Iv1'
    '97iCx+nCdGW6nWe6GrZcIbaZds5U5UxfjbN7a/WzejA9BdZ1NVN4ZlaPah5rO3OQsTOO84zdsGW72CY29rzatBs0FPdOy/d6Po4W'
    's3p+hylh9rFeD0MXMmynF7YaNl8V7UtKvuNzB3N6o88w5k0mxNBFBmzeIT7M6WP51darYY6SoXn/w++9buW+xy9Cv1tzHL7QT/5b'
    'a2Df4GNC3+f2NfzvA7lb+TjUM3SJUK986qM1so+N7Gti//uAYcxxhi4xjhu+afVz+8T6XtJX+T+3z1XMDoYuUd5kviO+lkTOgTMl'
    'vcR/Pi9K+D3E0CVKyPBRO12i7g3q77xOayzJA1c3lvTdx9ClTd4+5Wsef+59tab5/bTGeXmgkPEydInjMXwV35vmwX95r2bo34T1'
    '8LkR/s/vD67gY7GdoazA51kTX2+aSvqockf0QMfcDuqJZ7vhs9Z0Z3/QhTnIUIfg8+vsgpup5aGfkev5VeR6toyaK/+Xmu66To2b'
    'qh7Ich/0hQ7ogk7oxhgdtlP52kX5fh3oytgZygjDv+ZVheTf/waFvW5SrzCFzp4mz9aHle0ydnv6+oss+qAvdIgmr0t0Ywzz+HTA'
    '3qNMV0Y7q9AZB0OZ0Z/OLRpBgX+8QwlfoRB5frchZX2eVzdIn0QvjIGxMGbm9oqvuvh+9/VAZxwMZcSd/cj1zP1sc8CyM+zjcyDo'
    'jxyCUw5qXjFRjZ9MD85520SRtV6sQ3RZigIyFsbM2F7lqy6+3zMA6IyDoYxgu707non43tJIrifvJe/rT0TOX7+XnJtmsd39k+vh'
    'NshA1vz78b7+uOiCTvOFseQ4Zmqv8hU+a+cUOuNgKCPuhv+/iPX/Kfb/jadi/Hc9XEzn8LeSTA+3QSbGf9YBXbH+/0LGzNhe5asu'
    'vt97A9AZB0MZwba4f7mo1fnv4XM38v/Qv+zUsnKSGj+ZHm6DTOjUsajzP6B0RZ3/GEv8z9Re5asuvt83EOjN9w10MJQJ0NlcWkCB'
    'j3dRslfw2AFqLhvFsgPa0DNAZCCb7IUxMJaMmaG98BU+w/dmRYf8F9geZ+UtFDiwI/Z6FfUd4N32KDUvuDG5Dm6DTKJrP3QGPtoh'
    'YzR3zHcyfNXF9wU3Ap1xiG0d4b4bqGXJcHI9Mps8L1WQ97WHKHz2VMQHdzO5+W+5Wc6BG9R7VBltkLHkua/3tVrRBZ0tS0Yo2Y7a'
    'qXzVxfeFg4DOOFoWDqKOYh4H0y/vljWx34NfHiZXzW3kXFdE7sdKBJRRFzp5OOZ7z/vK2hhd0J0VG9lXw2etRaG3ZMn/WNjeJcPI'
    'v+/V2D+F+i8ofO4M/zH7BJRRF/3y7/u99BUdWbdLfNXF9/tvAjrjYCjrsP3OiqkUdPydUn0F/3mQ+0xTvufCJuWrLr4/cDPQGQdD'
    'OeH+QeTf+WzCa2Kia51/53PSJ2f2KF/hs+ZcJOiMg6Gsw364q39A4YaTUQ56KfDBVvL+qlRAmax7HhJZ9EHfnNikfNWV74MBlwdz'
    '3WDKOuyD77UHYz5z3/bHybl0OLfdqOAy6qLPBd8fHjT8H5wLHIbPmnPxEKAzDoYyw9CL99b1S4ZSYP+2mPtAV8UU9TmYclxGHdqs'
    '+xzug74JdSYcKy0chs+aa4mgMw6G0oJ1uWB72Uhyr5pIrhWjuW5whEU3kYs/2+Cn70WubYf3ibz0jdbDdWiz5LgP+oqOaJ08howF'
    'HRh7cZo2KxyGz+z7UMDloVw3lFKH9SwvIN8LK9nWd/l7/QiF+L7V/+aT5F4znVy2seR5bC75/7yZws31UfPgY+Sumqp8MXVxGXXR'
    '9/3og2smdLhZF3RCN8bAWBgTY8MG5VM6touvuvi+dBjQ3UuHOhhKmWX54lv0vY3l4xefsp0fUtjrjL/mh0Pkf+MJcpeNYL9vFlBG'
    'HdrixFmH+Mw6478o/WIDbEnLdvYVPsN3d6mgMw6GUoKPt2/zA3zN9lBGL+4X5Gu+7/nlQlCu/5nrgi2wKWX7la+68n044PJwrhtO'
    'KVE2nALv/z5ig9dFwYNvUbj+RLx93IZzIfj3Hep+r9W5EPeZswxk0Qd9484HHgNjRbfBFtiUsv3KV118LxsBdO7v8LCOlFhRQMHP'
    '3o2c78f/QZ7VEyjw51/G+rF3C/menC9tHttoCrz1NH+xuZN/lpjjvf0My46RPugLHdHHDWOgDWNGrpXvik2p2g9flc8jNM8yQWcc'
    'DKVK8K9tf/7hM/8k79rp5Fk6JOa4+X61hEKH9sSe71wOHdorbTF+cF/ogK62Pn/Yko7thq+6+L58JNAZB0MpUTaMbV3c5t9scM/L'
    'LJvPY0X1w9jc11MxkUJH/xY5f7jsqZik2iBjyY8UHdDV5t8/2yJ9U7Vf+aor3/NBev4z3pVjKPjOc4mv/+yPd8MPYn2J6TtaPm9L'
    '/vBeqUs4FuuArtDRDxJe/4O7nhNb0rFd+Qqf8zXvCkFnHAylDPxYPY78W8rlfA5/9TmFHB/J36+vpojbRyTv29r/Q8r/5GONYJ3/'
    'J7oxhox16D0K8NiwQWxJx3blqy6+2wqAzjgYSgvDNrFh7TTyVk7iupGKpH1Gkq/2RxT+8lDkb5rLqGuvn4yHMTCW+G0c43TtVr7q'
    'hu+Z+x9DfkrHy//EXPb3cPz32leHpS01f/KpY7ZG/PetHAV0xsFQzuBxfeum8ff6/qSXMrRBRmRzaYvyVRffV40GOuNgKGfwZxb4'
    'NX9nBPxR32XHhciXu19kIJtTW5SvuuG7+O/nOoZyBXwK/vHB2HudzfcJ0fdEkIFsLm3xR/nvXz0G6IyDoZyxku8ZXymP3O+GghQ6'
    'sJ1CH22Xsnk/DBnI5tQW5asuvpePBTrjYChnrOb734dvp3DjyaR//2iDDGRzaovyVTd8B10DFWPtDOWMckVw64bEcwCuQ5spl1Nb'
    'KsYe9VeM7cpogYpxoAtzkKHcwmNXTeBzfDWFHTy/a6kXUEYd2pR9ubZDfO0ivleOB1cw2xnKPcZxqJ5GwZ//REBZ6tD2tdggvsJn'
    'LVg5QQtW8TGoGl/N0NeG2DHW4GscV1EtPrPvcgyqcAwmTGW8QZyflzbwsRA+K9/HasE1E8DVwTUT9zF0aTNhn/KVfV47VmKAQ1XT'
    'tNDaifz/iSX8HmLoEiVk+KiFKgut+O/gmknsv3AVs4OhSxT2beJV8lmvmRiTAxDi/4fWTQLDmBMMXWIcN3yTc731K7R+Avs+WQtX'
    'c/v6ybeG10+uZ+gSoV58gm/sY2jdxIQ5QOL/+sna+7Zifp/C8lOOM3SRcwK+PL9mpvgGH9t6QUaQc2HKMGYHE7oI/Q4Ztg8LG58r'
    'SOXFfSLUFF7FlDD7qKbQy9AFjhe2MvPE9ihf0nkZvluw3quZQqqZWk0bpm5nDjJHmWPnmaOGLdvFtprCqbA12vZwdWHGecCsU6MN'
    't8B/xfopGm2cdgWP14Xpylxznulq2HIF8Wdm2blhqrxn60UPsr6NYJrSfSFTMz11v3bi305Exn+D6r3Aq971s+r92w71/s2d6r2T'
    '+b5SvV9mvmv/eeX01fp4t/48zM/J/NzMz9H8XM3P2fzckQ08gPlp9D4R16a+T4TabwB7DZzH/R5kX4aeae130FDcSzt1u672BxAf'
    'ZA+FfKaYKWVsOabUGCuf7e7SYOxVcPoOvd1c/frZMfsTdGXKWMd+xnke9hzAmPthA3ON2DRbkfC4IwedOTm7G+yfznx4AeXKH4BN'
    'X87pxjb2Ejtj9weQ3HitZWZ37BMwg2m4AHPdYdNMZ/G1ks/fOCeS6910zyAzx30608DtdGEC28RG7dRdA9V+JCV5Ro5632sa5vY5'
    'cBHkmn/ItnaVvHLkV6v8ci73LbuI8qVhK9udZ+ZId2H2sz90UQBblc2S58zkM86McoaNYyL5pyn3y1N9pF9GecrOpvlis5mnXMxQ'
    'WsDeu66nc8vG0znbZDp77yBVl0I/yKIP+kJHSv3iKRbbVZ5taVp5qvP70bmyseR953kK1Z+gUNO/yP/R29S87lYjnzh5P8hAFn3Q'
    'Fzqgq81+iYHNRp7s9TaGUuM6OnvfIPLt/V182I7jIDUvG6dyIVv347rm5eNEJm6JjHVBp8phTdUO2GzludpSzhG9qz+1rCmy8g6D'
    'Jz6lAOKYw2HBtXlJ4hxU5MJuXmrJoQ/6qrzIBtEpubup56rCZjNP05ZyjiMfI+eDd0jetBy797aQ57frrbVmz8tViXMxuc7z8hpr'
    'jRp90NfMwYZO6E4j19IWlWdpSzlHkfvKeWDmRAX8FDbi7cSOTTMT50ByHdpMv6WPEXMRPHlIdLaZgxkPbDbzBG3p5gS6Ny9WuU6t'
    'Ylw9L6wy8rpa9xkgba1jZaEDujLI/bNF5fnZMsmXc/Fn7v3TI+R/9yUKO5vUqdH4JdffTs33XMc2Xa/gsmvj7RRq+FLZzLLog77Q'
    'kWGuHmw289RsGeW7IXcOuYnIr3yt1vobQL6B+6l7yLOlSkDZykFAvibLtpj5fOifWa6ZTeWZSa6ZrWO5ZIPIWZpPgf2vx5xL0fFD'
    'VvHD7SIrNnQsV8wmtj8guWI2fqfMuZmP50ByPz4vNkcWedLB2L0DIANZla/VoTFhs5nnZet47tRg8u/6jWFomIIfv0OeXy4UUJbr'
    'PsJyWUblGnU4V8smti9GrtJgm8r7SYGYsc26m8m1ehKF/nXUilt3lU+x8rBQNuPKIQNZlaeURF9qwGbNhVyjxUNskq/TFpIPNFje'
    '3SvHC1IH29lGd80PrXyawJ4tqt7M6+Ey6sz8GciijykTo88Yo117lM2aaylyZYbaGGoTjFM5lfzvPEehk58JyGf01P2EfC/Y1Dli'
    'nOvBQ3vJtXxUJLeJy0EzLphlIIscH/SFDksf68YYYn979iibNTdyXZYOszGUnKHkto2m4Ievx8dmuc5G4tSirj3+t54hT/X3BZTj'
    'cjy4j/RtfQ/IY2AslY/Tlk1is5mnYmszrwP5Ao/P5Zsdl3UOR+fUqe+kRgp9/oG8mzF3yDOXPHUjNi9OJip3z/zbwRgYC2O2k2sC'
    'mzVPGRhhYygZ0OX7dallR+CNxwVzL4zgX14h76Yfk2flGPI9vyxhvg3q/NwGGciij7kHR4w+HgNjuSU/Y0Rb2MR2lSdiazOvomwY'
    'eR/+qXXckMtv5vOjTmzHeCI7nLwbb6NgVB4R8ji8D96mcj8gg8+T+yTVx2NZORPJsUXledjazQ2wFUicfUxeA5dVXk5BrGzpEDnW'
    'Ko8pTP4XlktdxvoSA5vNPAVb+7H9Rl7CS3yt+dtWAWWJl1/RKk+Aj53/RZs1VxE5fIaZ6kuMLSrPwJZyjDpi+xOVo2LpkTMguURW'
    'HsUeI48gP319ybFFxcnbshYLv6ZQ8l7iYuC5Dm1ZjIG3RcW527IWy464bSNnPXz8oGDltnNbFmPYbVFx2rZsxWIHXlwemQfselYw'
    'v6/QlsUYbJuKsxZsDHUYxFL/nK+z505H5gDG9y7q0KZiqLMwVvlY2KwFJFZ4bGn2YpDHUej1OiJPS+Tk5zLqrFjh7FAqtlci1ndc'
    'sYqxzQKwEfGUzy2gEJ87AGUVw5ylMRTFynaJUy4IVI13ZjUGt/Xxym4srpP15fO7GWPbhdkfXDOBLgpgq7IZsaGaETdYdhHFu5Yh'
    'rjO4VuJ7xX7mGq47cBHEah5Qtk4U2/HyL883YzSnMw2hdZPpAqXBsJGv+flR8YUSW6n51k9DLNpMpuECjJWETTN9NbeIrbA5Nk5U'
    'xdERt4erp0xnDlxAMX+wZTpVfw/xm2JrCvF91zBlVFO4n3Geh3g9jLkfNogtKcbroT1Y9z2JbwtJzJfEgBUwxUwpsyLHlBpjFWDs'
    'kBknWHdLWvF2Kl5tihFnFx3DlWPixipsM15O4od0TZO4om9rmsQZfVPTVBiREZf0n+iv9OK4Lou8m8fRPK7mcTaPOyJRuhm/6WPF'
    'aV2ZPE4rKj5Ia8Tvwszs0ZnRmWs7CHR0bjB0J/ptkZjfEJnVM4+pODOr527mCHOsg0DHLugU3cZvdpi/7dFg/tZHca9OzAzGkcN4'
    'IUf9bB5jdq9O6rc11NiNKsZmBte1MJRT5vAYGEvG7G3GyOQxjq/xdwUcjWpMTeJFSvIqzkO8RwXia5rm9+vM7G5z/3PEMSAmA/tx'
    'm7EZcTL9Wsnktben+i4Z+87+OnMk+d7m/ensohHk+f1D5P/bNtnbHGv6reVQhzbIQBZ9JJ4i+Z7mh5vuvA57Ondn7InX9FVcgnfb'
    'Y+qZKJ5fBPzkfm5Z7Fo+l1En62nyjCMsfay4g8Tr9Biz+7l7BgB70vXwBTdR4LO9FHafI9/uF+V5g2/3C3SOdUT2U75e6lTbiyKL'
    'Pujbxjq7Xca+9wZgb2tNG3tK43mfuZ7u/eMjsWvp2M+Z66z1c2Mf6nbWyTFm9+YFNwJ78j1iB1JL2Wjybt1EgY/fkbW+4IlPyFk+'
    '1doPFuXg8U/Unrcf7xJZ9DH3yE0CxuzesnAQsLe5Jot9VLG2uGgI+d54UsVpfPIu+Xb+Sgh8slvq0AYZkW1/71W7jH3/TcCe8nru'
    'ygkU+uIz69mT+UwKdWhLY/0WY3Z3LhoM7Mn3PryZnA9E7U350B1qveOrz8nzi4UCyqhDm7UH5QNRa3+JwZjdXYuHAHvCtTSswy0r'
    'IPfqSeRaOkzWHH0vV6jllK215Fw4UEBZ6rhN1iWxDoQ+3Nfa8y8eu4y9dCiwJ1qX89T9WPYVDJ12UGDvK+Tf8ZS1515g36vkXl4g'
    'BIz9atEGGciiD/pCR5J1N4zZ3V06nBlmj9tzjfUGD76t1sOi9gINN30lyHrfoT2C7Plt1kftCYq+0CF2xu/pZsfYnmUjgD12XWY4'
    'eVaPl7VdxDOZ63vB/dvIW11E3kdmUOiz96z92FD2/nyGtAWNvSvRB33VXmfjI2s0Eewy9vKRwJ5oLSOw7eHIc8rGL8n32GzylA5V'
    'a0HY54uPN/Cum670c5vvsWKRNZ9zQkeSdRKM2d27Ih/YE65FYB3j10so8Kc68j06K2YvJ9+G71v7saAcvacSZNEHfdW6R8J1DozZ'
    '3bdyFLAnfe6P/Y9WjGDyI3VVkyn00RuRNYCP3pQ6aw0AstJnZFvrAnYZe9VoYE/9WT6f70/Nk33Ewic+FlBGnYyV+nN6jNndv3oM'
    'sKf8fHzVKAo8OoPI2STPruWZNpdRh7Y0nrNjzO6BinE6cyStPSkq+Rr8+iY+z74QUEZdmntR8Jhj9UDl+M7M7rT3hKgaT8G62wT1'
    'bDbtvSAwZuegel5WmdnzzvGKzJ6XViCn2sijz+N3x9eY146xMKY8mwqqZ4QzQusntzCUY1owVnCdypnF8zLJNa2e0omZwThy+LzL'
    'YYzRKRz1rC4mh7emMI+poJrC3cwRxt5BoGM366wU3eLvlLjc2qjna1qoejKes3RmdKZ7B4GOzsHqyUZuZ+yzsp0qJ++y8/A8A7lo'
    'nTAL/66RU2Y9p/hW/HMKY44unJlxbaczs3r0PjOzRyHz/TQplL6sw3rmgbn4XJWrw//Xmbr64p7H6mf1dDGeNHFxX4fS0UtvMHWr'
    'OT7+vzOL8/mdopN1N87L68Tz6bpsz9V5jlwH3Y3z+vVmHAl/I25uH6a3ek+nTeh3jOnF89FCxpVortpS/SPy8PyqpW6W9ZtX5m9j'
    'oU7aWCbJPBc6C3muWcR44n4/adlYNXfCbyqcOU7Nld9TcfaIq+cy6tAGGcgm+D0m6CziuRzwxMZWX08tqwvltxqwBzXie50b71Bz'
    'R8Rdb7xD6mQvbJaBrMxrY+eJ0FnEczngiYtX5vmO5zcrKHjkrxLr43mpkud2qg1l1KENMs0S2xsX7wydRTxvAp6k878lw8n39maJ'
    '+8JvtsjvtnAZdWhrY74HnUU8HwIemRfFcJPQwvMYzxN3yv7VwSPvCyijDm2mXHx/0VnEcxngiZ3jDCaXbZzsLY65GOLtcKxdqyYI'
    'KKNO4jxZRmQltjBmnuQR3UuHAk/0/Mj72BzZX1T2Mf1gq8RQym+wPDFPkDg5rkObKYc+reZD0FnkLhsOPG6137DMURDrJfOaxpMq'
    'TuGtpymE48JzTZmDchl1ch8IGZZFH5nfmHqUziK+1weeyJ68w8n/hxqJNQQoIxbLW8Xn6+d/FVCWmC2Ra4rIYa4RmUdAZ5HXVgA8'
    'MXudYv7w7ELBjH/yrZkqe1UDlK14qRi5mHgk6Czie3XgiZ8j5CuMuUHw7aeJED/JoGzd/0fLxQKdRXwvDDxt33uPptC+V3heVy+g'
    'LPsjtn2fDZ1FfL9byLjavCcuH8P38T+j8N/fFFCWurbvo6GzkO9DezOOdvez4vtka70b5Xb3v4JO6J7Qie9TN2X7XpR11kG3sU6t'
    '8/3hzizea+4UneuM/ZrUfabO1IWrCx18P+RiPGnikr7VUzZBl6z5GvfR5r0VbZzWiWqm9ub7rkKmKE0KpS/rsO4JU9yHpSOv3mp5'
    'SO7ArPuwbyS+D+N7p8v5PqfgzKye5UwdU5sEtJWLLPqoNY/L+b7lbi6fTiNH+TT68H3U5Y0leQWNJX1PWzmnuE+Z3Ysa5/SO5KEi'
    'Jxh1c2NyU0+jb9P8/uWRXMN+dHbBYHI+Op/OrZ5mPZtHGXVoU3VWbmI5f9fXxuSuPb2QQnyd97//Gn9XDxRQRh3aWuW81fJ3bW10'
    '7pKz+jZ5lhr8/ANqWTlRQDnw6bvS1irnqbbl/ptq434vqTSf/Hu2UNC+X0BZ5bLE/R5SrXPx4NpIrsEQ9V24rIACf/kt+f64SUBZ'
    'nh1ym/UbKopa99JhtRJnvmQweZ+cTyGMefgv8gw0sOdlAWWp4zbIQNaITa/1LBtRK8+/+DvK//xy+d7CszJv7e0U5GsekDKen3Eb'
    'ZCBrPDOr5e+CWvO7wVc+nvxPlpBv/S38vcH3cR9uE1BGnbSxTNR3SS1fi2sj1+bRKm4RPMz3YqfsAspW/eqY63ttoHJcecLYtjWT'
    'KPRqlYBykpi2cp73F/C193TC+KOqcYrEsUmn0ZevZZfzNeduviacTiNG5TT68DXwcolF2Tjtcr6OFfC8tJypbYdykUWfLFyH/h+V'
    'j56/'
)    # Windows icon (icon.ico)
VERSION = '2026.11.04.1629'        # build.py stamps each build with its date and time, e.g. 2026.10.19.1534
UPDATE_URL = 'https://raw.githubusercontent.com/WMBanner/spider-diagram/main/dist/'        # build.py: where published builds live (a folder holding version.json); '' = no updates
PORT = int(os.environ.get('SPIDER_DIAGRAM_PORT') or 47615)   # fixed, so the browser's autosave survives restarts
TOKEN = secrets.token_urlsafe(24)  # only pages served by us know it, so other sites can't use the API
IDLE_EXIT = 120
DIAGRAM_SUFFIXES = {'.spider', '.json'}
SYSTEM = platform.system()   # 'Linux', 'Darwin' (macOS) or 'Windows'
DIAGRAM_FILTERS = [('Spider diagrams', ['*.spider', '*.json']), ('All files', ['*'])]
EXPORT_FILTERS = {  # kind -> (file-dialog filters, default extension)
    'png': ([('PNG images', ['*.png'])], '.png'),
    'md': ([('Markdown', ['*.md'])], '.md'),
    'txt': ([('Text files', ['*.txt'])], '.txt'),
    'docx': ([('Word documents', ['*.docx'])], '.docx'),
    'zip': ([('Zip archives', ['*.zip'])], '.zip'),
}

def config_dir():
    if SYSTEM == 'Windows':
        return Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Spider Diagram'
    return Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config') / 'spider-diagram'


def documents_dir():
    """The user's Documents folder. On Windows, ask the system: it's often redirected into OneDrive."""
    if SYSTEM == 'Windows':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD), ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
            documents = GUID(0xFDD39AD0, 0x238F, 0x46AF, (ctypes.c_ubyte * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7))
            found = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(documents), 0, None, ctypes.byref(found)) == 0:
                path = Path(found.value)
                ctypes.windll.ole32.CoTaskMemFree(found)
                if path.is_dir():
                    return path
        except Exception:
            pass
    docs = Path.home() / 'Documents'
    return docs if docs.is_dir() else Path.home()


CONFIG = config_dir() / 'library.json'
SKIP_DIRS = {'node_modules', '__pycache__', 'venv', 'site-packages', 'Trash'}
MAX_DEPTH, MAX_FILES = 6, 3000

last_seen = time.time()
live, closed_at = 0, None   # tabs connected right now, and when the last one went
lock = threading.Lock()
summaries = {}   # path -> ((mtime, size), summary): files are only re-read when they change
last_dir = documents_dir()


def applescript(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"') + '"'


def pick(mode, title, start_dir, suggested='', filters=None):
    """A native file chooser. mode: 'open', 'save' or 'folder'. Returns a path string, or None if cancelled."""
    start_dir, filters = str(start_dir), filters or []
    if SYSTEM == 'Darwin':
        where = f'default location (POSIX file {applescript(start_dir)})'
        ask = {'open': f'choose file with prompt {applescript(title)} {where}',
               'save': f'choose file name with prompt {applescript(title)} default name {applescript(suggested)} {where}',
               'folder': f'choose folder with prompt {applescript(title)} {where}'}[mode]
        # 'activate' brings the dialog in front of the browser; cancelling exits non-zero.
        r = subprocess.run(['osascript', '-e', 'activate', '-e', f'POSIX path of ({ask})'], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('zenity'):
        args = ['zenity', '--file-selection', f'--title={title}']
        if mode == 'folder':
            args += ['--directory', f'--filename={start_dir}/']
        elif mode == 'save':
            args += ['--save', f'--filename={Path(start_dir) / suggested}']
        else:
            args.append(f'--filename={start_dir}/')
        args += [f'--file-filter={label} | {" ".join(pats)}' for label, pats in filters if mode != 'folder']
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    if SYSTEM != 'Windows' and shutil.which('kdialog'):
        spec = ' '.join(f'{" ".join(pats)}|{label}' for label, pats in filters)
        args = {'open': ['kdialog', '--title', title, '--getopenfilename', start_dir, spec],
                'save': ['kdialog', '--title', title, '--getsavefilename', str(Path(start_dir) / suggested), spec],
                'folder': ['kdialog', '--title', title, '--getexistingdirectory', start_dir]}[mode]
        r = subprocess.run(args, capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    try:   # Windows, or anything else: Tk's dialogs (bundled with most Python installs)
        import tkinter
        from tkinter import filedialog
    except ImportError:
        raise RuntimeError('No file dialog available here; on Linux, install zenity')
    root = tkinter.Tk()
    root.withdraw()
    root.attributes('-topmost', True)
    root.lift()
    root.focus_force()
    try:
        types = [(label, ' '.join(pats)) for label, pats in filters]
        if mode == 'open':
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=start_dir, filetypes=types)
        elif mode == 'save':
            chosen = filedialog.asksaveasfilename(parent=root, title=title, initialdir=start_dir, initialfile=suggested, filetypes=types)
        else:
            chosen = filedialog.askdirectory(parent=root, title=title, initialdir=start_dir)
    finally:
        root.destroy()
    return chosen or None


def dialog(title, save=False, suggested=None, kind=None):
    """Choose a diagram (kind=None) or export file; returns a Path or None if cancelled."""
    global last_dir
    filters, ext = EXPORT_FILTERS[kind] if kind else (DIAGRAM_FILTERS, '.spider')
    chosen = pick('save' if save else 'open', title, last_dir, suggested or '', filters)
    if not chosen:
        return None
    p = Path(chosen)
    if save and not p.suffix:
        p = p.with_suffix(ext)
    last_dir = p.parent
    return p


def reveal(p: Path):
    """Show a file in the system file manager."""
    if SYSTEM == 'Darwin':
        args = ['open', '-R', str(p)]
    elif SYSTEM == 'Windows':
        args = ['explorer', '/select,', str(p)]
    else:
        args = ['xdg-open', str(p.parent)]
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def write_atomic(path: Path, data: bytes):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name, suffix='.tmp')
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def diagram_path(raw) -> Path:
    p = Path(raw or '').expanduser()
    if not p.is_absolute() or p.suffix.lower() not in DIAGRAM_SUFFIXES:
        raise ValueError('Only .spider files can be saved or opened this way')
    return p


def info(p: Path, **extra):
    return {'path': str(p), 'name': p.name, **extra}


# ---------- library ----------

def tiny_png():
    """A 1x1 grey PNG: stands in for bubble pictures in homepage thumbnails (keeps the list light)."""
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b'\x00\xc4\xc4\xc4')) + chunk(b'IEND', b''))
    return 'data:image/png;base64,' + base64.b64encode(png).decode()


PLACEHOLDER_IMG = tiny_png()
PREVIEW_KEYS = ('text', 'x', 'y', 'parent', 'kind', 'color', 'order', 'collapsed', 'bold', 'italic', 'size', 'shape', 'fill', 'imgSize', 'line')


def load_config():
    try:
        cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cfg = {}
    if not isinstance(cfg.get('folders'), list):
        docs = documents_dir()
        cfg['folders'] = [str(docs)] if docs != Path.home() else []
    if not isinstance(cfg.get('recent'), list):
        cfg['recent'] = []
    return cfg


def save_config(cfg):
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(CONFIG, json.dumps(cfg, indent=1).encode())


def remember(p: Path):
    """Note a diagram you've opened or saved, so the homepage lists it wherever it lives."""
    with lock:
        cfg = load_config()
        cfg['recent'] = [str(p)] + [r for r in cfg['recent'] if r != str(p)][:199]
        save_config(cfg)


def scan(folder: Path):
    """.spider files under a folder, skipping hidden and bulky directories."""
    base = len(folder.parts)
    for root, dirs, files in os.walk(folder):
        depth = len(Path(root).parts) - base
        dirs[:] = [] if depth >= MAX_DEPTH else [d for d in dirs if not d.startswith('.') and d not in SKIP_DIRS]
        for f in files:
            if f.endswith('.spider'):
                yield Path(root) / f


def strip_html(text):
    """Notes as plain text: block tags become spaces, inline ones (bold, links…) just disappear."""
    text = re.sub(r'</?(p|div|li|h\d|br|tr|td|th|blockquote|pre|hr|ul|ol|table)\b[^>]*>', ' ', text or '', flags=re.I)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', text))).strip()


def summarize(p: Path):
    """Title, counts, searchable text and a lightweight copy for the thumbnail (no pictures, no notes)."""
    st = p.stat()
    key = (st.st_mtime_ns, st.st_size)
    cached = summaries.get(str(p))
    if cached and cached[0] == key:
        return cached[1]
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        return None
    # Version 3+ keeps bubbles under "bubbles" (several main ideas possible); older files under "nodes"
    # with bubble 0 as the one centre. The app itself upgrades files; here we only need to read them.
    key_name = 'bubbles' if isinstance(data.get('bubbles'), dict) else 'nodes'
    nodes = data.get(key_name)
    if not isinstance(nodes, dict) or not nodes or (key_name == 'nodes' and not isinstance(nodes.get('0'), dict)):
        return None
    texts, preview, with_notes = [], {}, 0
    for k, n in nodes.items():
        if not isinstance(n, dict):
            continue
        if isinstance(n.get('text'), str):
            texts.append(n['text'])
        notes = n.get('notes') if isinstance(n.get('notes'), str) else ''
        note_text = strip_html(notes)
        if note_text:
            texts.append(note_text)
        pn = {key: n[key] for key in PREVIEW_KEYS if key in n}
        if isinstance(n.get('img'), dict):
            pn['img'] = {'src': PLACEHOLDER_IMG, 'w': n['img'].get('w', 4), 'h': n['img'].get('h', 3)}
        if note_text or '<img' in notes or '<table' in notes:
            pn['notes'] = '<p>notes</p>'
            with_notes += 1
        preview[k] = pn
    if key_name == 'nodes':
        mains = [nodes['0']]
    else:
        def sort_key(item):
            k, n = item
            order = n.get('order')
            return (order if isinstance(order, (int, float)) else int(k) if str(k).isdigit() else 0, str(k))
        mains = [n for k, n in sorted(nodes.items(), key=sort_key)
                 if isinstance(n, dict) and n.get('parent') is None and n.get('kind') != 'free']
    names = [' '.join(m['text'].split()) if isinstance(m.get('text'), str) and m['text'].strip() else 'Untitled' for m in mains]
    if isinstance(data.get('title'), str) and data['title'].strip():   # the diagram's own name, if it has one
        title = ' '.join(data['title'].split())[:200]
    elif not names:
        title = p.stem
    elif len(names) <= 3:   # matches docTitle() in the app
        title = ', '.join(names[:-1]) + ' and ' + names[-1] if len(names) > 1 else names[0]
    else:
        title = f"{', '.join(names[:2])} and {len(names) - 2} more"
    links = data.get('links') if isinstance(data.get('links'), dict) else {}
    preview = {key_name: preview, 'links': links, 'settings': data.get('settings', {}), 'nextId': data.get('nextId', 1)}
    for k in ('format', 'version'):   # so the app knows which version to upgrade the thumbnail from
        if k in data:
            preview[k] = data[k]
    summary = {
        'path': str(p), 'name': p.name, 'folder': str(p.parent), 'mtime': st.st_mtime, 'bytes': st.st_size,
        'title': title, 'count': len(preview[key_name]), 'notes': with_notes, 'mains': max(1, len(mains)),
        'links': len(links), 'text': '\n'.join(texts)[:50000], 'preview': preview,
    }
    summaries[str(p)] = (key, summary)
    return summary


def library():
    with lock:
        cfg = load_config()
        paths = {}
        for folder in cfg['folders']:
            f = Path(folder)
            if f.is_dir():
                for p in scan(f):
                    paths[str(p)] = p
                    if len(paths) >= MAX_FILES:
                        break
        alive = [r for r in cfg['recent'] if Path(r).is_file()]
        if alive != cfg['recent']:   # forget recent files that have since been deleted or moved
            cfg['recent'] = alive
            save_config(cfg)
        for r in alive:
            paths.setdefault(r, Path(r))
    files = []
    for p in paths.values():
        try:
            s = summarize(p)
        except (OSError, ValueError):
            continue
        if s:
            files.append(s)
    files.sort(key=lambda s: s['mtime'], reverse=True)
    return {'folders': cfg['folders'], 'home': str(Path.home()), 'files': files}


def route(path, req):
    if path == '/api/ping':
        return {'ok': True}
    if path == '/api/open':
        p = dialog('Open spider diagram')
        if not p:
            return {'cancelled': True}
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/open-path':
        p = diagram_path(req.get('path'))
        text = p.read_text(encoding='utf-8')
        remember(p)
        return info(p, text=text)
    if path == '/api/save':
        p = diagram_path(req.get('path'))
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/save-as':
        p = dialog('Save spider diagram as', save=True, suggested=req.get('suggested'))
        if not p:
            return {'cancelled': True}
        write_atomic(p, req['data'].encode('utf-8'))
        remember(p)
        return info(p)
    if path == '/api/library':
        return library()
    if path == '/api/library/add-folder':
        folder = pick('folder', 'Add a folder to your library', Path.home())
        if not folder:
            return {'cancelled': True}
        folder = str(Path(folder))   # drops the trailing slash macOS adds
        with lock:
            cfg = load_config()
            if folder not in cfg['folders']:
                cfg['folders'].append(folder)
                save_config(cfg)
        return library()
    if path == '/api/library/remove-folder':
        with lock:
            cfg = load_config()
            cfg['folders'] = [f for f in cfg['folders'] if f != req.get('path')]
            save_config(cfg)
        return library()
    if path == '/api/reveal':
        p = diagram_path(req.get('path'))
        if not p.is_file():
            raise ValueError('That file no longer exists')
        reveal(p)
        return {'ok': True}
    if path in ('/api/export', '/api/export-png'):
        kind = req.get('kind', 'png')
        if kind not in EXPORT_FILTERS:
            raise ValueError('Unknown export type')
        p = dialog('Export ' + ('PNG' if kind == 'png' else 'outline'), save=True, suggested=req.get('suggested'), kind=kind)
        if not p:
            return {'cancelled': True}
        write_atomic(p, base64.b64decode(req['data']))
        return info(p)
    if path == '/api/about':
        return about()
    if path == '/api/install':
        return {'message': install()}
    if path == '/api/update/check':
        return check_update()
    if path == '/api/update/apply':
        return apply_update()
    raise LookupError('unknown endpoint')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def host_ok(self):
        # Blocks DNS-rebinding: the page must be addressed as localhost.
        return self.headers.get('Host') in (f'127.0.0.1:{PORT}', f'localhost:{PORT}')

    def send(self, code, body, ctype='application/json'):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.path.startswith('/api/alive?'):
            return self.alive()
        if self.path.split('?')[0] not in ('/', '/index.html'):
            return self.send(404, {'error': 'not found'})
        last_seen = time.time()
        html = app_html()
        html = html.replace('<!--spider-host-->', f'<script>window.SPIDER_HOST = {json.dumps({"token": TOKEN})};</script>', 1)
        self.send(200, html.encode(), 'text/html; charset=utf-8')

    def alive(self):
        """Each open tab keeps this connection open. Closing the tab (or the browser) drops it, which is
        how the launcher knows when nothing is using it any more, whatever the browser."""
        global live, closed_at
        if parse_qs(urlsplit(self.path).query).get('token') != [TOKEN]:
            return self.send(403, {'error': 'forbidden'})
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        with lock:
            live += 1
        try:
            while True:
                self.wfile.write(b': still here\n\n')
                self.wfile.flush()
                time.sleep(1)
        except OSError:
            pass
        finally:
            with lock:
                live -= 1
                if not live:
                    closed_at = time.time()

    def do_POST(self):
        global last_seen
        if not self.host_ok():
            return self.send(403, {'error': 'forbidden'})
        if self.headers.get('X-Spider-Token') != TOKEN:
            return self.send(403, {'error': 'forbidden'})
        last_seen = time.time()
        try:
            req = json.loads(self.rfile.read(int(self.headers.get('Content-Length') or 0)) or b'{}')
            self.send(200, route(self.path, req))
        except LookupError as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            self.send(500, {'error': str(e)})


def unpack(blob, text=True):
    data = zlib.decompress(base64.b64decode(''.join(blob)))
    return data.decode('utf-8') if text else data


def app_html():
    return unpack(EMBEDDED_HTML) if EMBEDDED_HTML else (HERE / 'index.html').read_text(encoding='utf-8')


# ---------- Linux desktop integration ----------

DATA = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
INSTALLED = {
    'program': Path.home() / '.local' / 'bin' / 'spider-diagram',
    'desktop': DATA / 'applications' / 'spider-diagram.desktop',
    'mime': DATA / 'mime' / 'packages' / 'spider-diagram.xml',
    'icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'apps' / 'spider-diagram.svg',
    'mime-icon': DATA / 'icons' / 'hicolor' / 'scalable' / 'mimetypes' / 'application-x-spider-diagram.svg',
}
MIME_XML = """<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="application/x-spider-diagram">
    <comment>Spider diagram</comment>
    <sub-class-of type="application/json"/>
    <icon name="application-x-spider-diagram"/>
    <glob pattern="*.spider" weight="80"/>
  </mime-type>
</mime-info>
"""


def refresh_desktop_caches():
    for cmd in (['update-mime-database', str(DATA / 'mime')], ['update-desktop-database', str(DATA / 'applications')],
                ['kbuildsycoca6'], ['kbuildsycoca5']):
        if shutil.which(cmd[0]):
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def install():
    if SYSTEM == 'Windows':
        return windows_install()
    if SYSTEM != 'Linux':
        raise RuntimeError('Installing is for Linux and Windows. On a Mac, just double-click spider-diagram-mac.command.')
    me, prog = Path(__file__).resolve(), INSTALLED['program']
    for p in INSTALLED.values():
        p.parent.mkdir(parents=True, exist_ok=True)
    if me != prog:
        shutil.copyfile(me, prog)
    prog.chmod(0o755)
    icon = unpack(EMBEDDED_ICON) if EMBEDDED_ICON else (HERE / 'icon.svg').read_text(encoding='utf-8')
    INSTALLED['icon'].write_text(icon, encoding='utf-8')
    INSTALLED['mime-icon'].write_text(icon, encoding='utf-8')
    # Some launchers skip an icon folder that has no index.theme; borrow the system one.
    theme = DATA / 'icons' / 'hicolor' / 'index.theme'
    if not theme.exists() and Path('/usr/share/icons/hicolor/index.theme').exists():
        theme.symlink_to('/usr/share/icons/hicolor/index.theme')
    INSTALLED['mime'].write_text(MIME_XML, encoding='utf-8')
    INSTALLED['desktop'].write_text(f"""[Desktop Entry]
Type=Application
Name=Spider Diagram
GenericName=Mind map editor
Comment=Create spider diagrams and export them as pictures or documents
Exec="{prog}" %f
Icon=spider-diagram
Terminal=false
Categories=Office;
MimeType=application/x-spider-diagram;
Keywords=mind map;mindmap;spider;diagram;brainstorm;notes;
StartupNotify=false
""", encoding='utf-8')
    refresh_desktop_caches()
    if shutil.which('xdg-mime'):
        subprocess.run(['xdg-mime', 'default', 'spider-diagram.desktop', 'application/x-spider-diagram'])
    return (f'Installed. Spider Diagram is in your app menu, .spider files open with it, and the program\n'
            f'itself is at {prog}. Remove it again with:  spider-diagram --uninstall')


# ---------- Windows: Start menu shortcut and .spider file type (current user only, no admin needed) ----------

WIN_APP_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local') / 'Programs' / 'Spider Diagram'
WIN_SHORTCUT = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming') / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs' / 'Spider Diagram.lnk'
WIN_CLASSES = r'Software\Classes'
WIN_KEYS = [r'.spider', r'SpiderDiagram.File\shell\open\command', r'SpiderDiagram.File\shell\open',
            r'SpiderDiagram.File\shell', r'SpiderDiagram.File\DefaultIcon', r'SpiderDiagram.File']   # deepest first


def windows_refresh_icons():
    try:
        import ctypes
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def windows_install():
    import winreg
    WIN_APP_DIR.mkdir(parents=True, exist_ok=True)
    prog, ico, me = WIN_APP_DIR / 'Spider Diagram.cmd', WIN_APP_DIR / 'spider-diagram.ico', Path(__file__).resolve()
    if me != prog:
        shutil.copyfile(me, prog)
    ico.write_bytes(unpack(EMBEDDED_ICO, text=False) if EMBEDDED_ICO else (HERE / 'icon.ico').read_bytes())
    # Start menu shortcut, starting minimised: the app itself lives in your browser.
    script = ('$s = (New-Object -ComObject WScript.Shell).CreateShortcut($env:SD_LINK); $s.TargetPath = $env:SD_PROG; '
              '$s.IconLocation = $env:SD_ICON; $s.WindowStyle = 7; $s.Description = "Spider Diagram"; $s.Save()')
    WIN_SHORTCUT.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], check=True,
                   env={**os.environ, 'SD_LINK': str(WIN_SHORTCUT), 'SD_PROG': str(prog), 'SD_ICON': str(ico)})
    # .spider files: their own icon, and double-click opens them in Spider Diagram.
    values = {r'.spider': 'SpiderDiagram.File', r'SpiderDiagram.File': 'Spider diagram',
              r'SpiderDiagram.File\DefaultIcon': f'"{ico}"', r'SpiderDiagram.File\shell\open\command': f'"{prog}" "%1"'}
    for key, value in values.items():
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key) as k:
            winreg.SetValueEx(k, '', 0, winreg.REG_SZ, value)
    windows_refresh_icons()
    return ('Installed. Spider Diagram is in your Start menu and .spider files open with it.\n'
            f'The program itself is in {WIN_APP_DIR}. Remove it again with:  "{prog}" --uninstall')


def windows_uninstall():
    import winreg
    for key in WIN_KEYS:
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, WIN_CLASSES + '\\' + key)
        except OSError:
            pass
    WIN_SHORTCUT.unlink(missing_ok=True)
    (WIN_APP_DIR / 'spider-diagram.ico').unlink(missing_ok=True)
    windows_refresh_icons()
    # The program file may be the one running right now, so it's left for Windows to tidy away.
    print(f'Removed Spider Diagram from your Start menu and file types. You can delete {WIN_APP_DIR} too.\n'
          'Your diagrams and library settings are untouched.')


def uninstall():
    if SYSTEM == 'Windows':
        return windows_uninstall()
    for p in INSTALLED.values():
        p.unlink(missing_ok=True)
    refresh_desktop_caches()
    print('Removed Spider Diagram from your app menu. Your diagrams and library settings are untouched.')


# ---------- installing from the app, and updates ----------

def installed_program():
    return WIN_APP_DIR / 'Spider Diagram.cmd' if SYSTEM == 'Windows' else INSTALLED['program']


def shown_version():
    """The version to show. The source folder counts as a release when it's exactly the last published
    version (checked out at the release commit, with nothing changed since); otherwise it's 'dev'."""
    if EMBEDDED_HTML is not None or VERSION != 'dev':
        return VERSION
    try:
        git = lambda *a: subprocess.run(['git', '-C', str(HERE), *a], capture_output=True, text=True, timeout=5).stdout.strip()
        released = json.loads((HERE / 'dist' / 'version.json').read_text())['version']
        if git('rev-parse', 'HEAD') == git('log', '-1', '--format=%H', '--', 'dist/version.json') and not git('status', '--porcelain'):
            return released
    except Exception:
        pass
    return 'dev'


def about():
    packed = EMBEDDED_HTML is not None   # a built single-file copy (not the source folder)
    return {'version': shown_version(), 'system': SYSTEM, 'updates': bool(UPDATE_URL) and packed,
            'canInstall': packed and SYSTEM in ('Linux', 'Windows'),
            'installed': Path(__file__).resolve() == installed_program()}


def fetch(url, limit=20_000_000):
    with urlopen(Request(url, headers={'User-Agent': 'Spider Diagram/' + VERSION, 'Cache-Control': 'no-cache'}), timeout=20) as r:
        return r.read(limit)


def latest():
    return json.loads(fetch(UPDATE_URL + 'version.json?t=' + str(int(time.time())), 100_000))


def check_update():
    if not about()['updates']:
        return {'available': False}
    info = latest()
    return {'available': str(info.get('version', '')) > VERSION, 'version': info.get('version'), 'current': VERSION,
            'summary': str(info.get('summary', ''))}


RESTART = False


def apply_update():
    """Download the newest build for this computer, check it, and put it in place of this program."""
    global RESTART
    if not about()['updates']:
        raise RuntimeError('Updates are not set up for this copy')
    info = latest()
    name = 'spider-diagram-windows.cmd' if SYSTEM == 'Windows' else 'spider-diagram-linux'   # Mac uses the Linux file
    data = fetch(UPDATE_URL + name + '?v=' + str(info['version']))
    if hashlib.sha256(data).hexdigest() != info['sha256'][name]:
        raise RuntimeError('The download was damaged; nothing was changed. Try again later')
    if b'Spider Diagram launcher.' not in data[:4000]:
        raise RuntimeError("That download doesn't look like Spider Diagram; nothing was changed")
    me = Path(__file__).resolve()
    mode = me.stat().st_mode
    write_atomic(me, data)
    if SYSTEM != 'Windows':
        me.chmod(mode | 0o755)
    RESTART = True
    threading.Thread(target=lambda: (time.sleep(0.5), SERVER.shutdown()), daemon=True).start()
    return {'version': info['version']}


def restart():
    """Start the freshly updated program in place of this one (no new browser tab: the page reloads itself)."""
    me = str(Path(__file__).resolve())
    if SYSTEM == 'Windows':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 7   # minimised, like the Start menu shortcut
        subprocess.Popen([sys.executable, '-x', me, '--no-browser'], creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=si)
    else:
        os.execv(sys.executable, [sys.executable, me, '--no-browser'])


SERVER = None


def main():
    global SERVER
    args = sys.argv[1:]
    browser = '--no-browser' not in args
    args = [a for a in args if a != '--no-browser']
    if args and args[0] in ('-h', '--help'):
        return print(__doc__)
    if args and args[0] == '--install':
        try:
            return print(install())
        except RuntimeError as e:
            sys.exit(str(e))
    if args and args[0] == '--uninstall':
        return uninstall()
    url = f'http://127.0.0.1:{PORT}/'
    if args:
        url += '#open=' + quote(str(Path(args[0]).expanduser().resolve()))
    for attempt in range(1 if browser else 40):   # after an update, the old copy may still be letting go of the port
        try:
            server = SERVER = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
            break
        except OSError:
            time.sleep(0.25)
    else:
        # Already running (e.g. another window): just open another tab on it.
        if browser:
            webbrowser.open(url)
        return

    def watchdog():
        # Stops a few seconds after the last tab closes (a reload is back well within that). A tab from
        # an older version, without the connection, just checks in now and then: then it's IDLE_EXIT.
        global last_seen
        before = time.time()
        while True:
            time.sleep(1)
            now = time.time()
            if now - before > 20:   # the computer was asleep: give the tabs a chance to reconnect
                last_seen = now
            before = now
            if live:
                continue
            if (closed_at is not None and now - closed_at > 3 and last_seen < closed_at) or now - last_seen > IDLE_EXIT:
                server.shutdown()
                return

    threading.Thread(target=watchdog, daemon=True).start()
    print(f'Spider Diagram is running at {url}\nYou can minimise this window. It stops by itself a few seconds '
          'after you close the browser tab.')
    if browser:
        def open_tab():
            # A tab left open from last time reconnects by itself within a second or two: then use that
            # one rather than opening another. (Opening a file always gets a tab to open it in.)
            if not args:
                for _ in range(30):
                    time.sleep(0.1)
                    if live:
                        return
            webbrowser.open(url)
        threading.Thread(target=open_tab, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()
    if RESTART:
        restart()


if __name__ == '__main__':
    main()
